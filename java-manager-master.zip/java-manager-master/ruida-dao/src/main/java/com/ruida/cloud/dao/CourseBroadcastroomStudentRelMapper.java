package com.ruida.cloud.dao;

import com.ruida.cloud.model.CourseBroadcastroomStudentRel;
import com.ruida.cloud.model.CourseBroadcastroomStudentRelExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface CourseBroadcastroomStudentRelMapper {
    long countByExample(CourseBroadcastroomStudentRelExample example);

    int deleteByExample(CourseBroadcastroomStudentRelExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(CourseBroadcastroomStudentRel record);

    int insertSelective(CourseBroadcastroomStudentRel record);

    List<CourseBroadcastroomStudentRel> selectByExample(CourseBroadcastroomStudentRelExample example);

    CourseBroadcastroomStudentRel selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") CourseBroadcastroomStudentRel record, @Param("example") CourseBroadcastroomStudentRelExample example);

    int updateByExample(@Param("record") CourseBroadcastroomStudentRel record, @Param("example") CourseBroadcastroomStudentRelExample example);

    int updateByPrimaryKeySelective(CourseBroadcastroomStudentRel record);

    int updateByPrimaryKey(CourseBroadcastroomStudentRel record);

    /**
     * 校区 未排班 学生信息
     */
    List<Map<String, Object>> listFreeCBSRByCampusId(Map condition);

    /**
     * 学生端 已排班 学生信息
     */
    List<Map<String, Object>> listSurplusCBSRByRoomId(Map condition);

    /**
     * 批量移出
     */
    int moveStudentOut(Map condition);

    /**
     * 批量移入
     */
    int moveStuToBroadcast(Map condition);

    /**
     * 单独移入
     */
    int moveStuToBroadcastSingle(Map condition);

    /**
     * 删除
     * @param condition
     * @return
     */
    int deleteBroadcastStuRelByCourseId(Map condition);

    List<String> getBroadcastroomByWeiduClassId(String classId);

    /**
     * 批量插入排班
     */
    int insertBatch(List<CourseBroadcastroomStudentRel> list);

    int deleteBroadcastroomStudentByUserIdCourseId(Map condition);

    int updateByCourseId(@Param("broadcastRoomId") Integer broadcastRoomId,@Param("courseId") Integer courseId);
}