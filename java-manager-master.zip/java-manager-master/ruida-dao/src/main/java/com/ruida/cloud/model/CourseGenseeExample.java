package com.ruida.cloud.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class CourseGenseeExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public CourseGenseeExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andCourseGenseeIdIsNull() {
            addCriterion("course_gensee_id is null");
            return (Criteria) this;
        }

        public Criteria andCourseGenseeIdIsNotNull() {
            addCriterion("course_gensee_id is not null");
            return (Criteria) this;
        }

        public Criteria andCourseGenseeIdEqualTo(Integer value) {
            addCriterion("course_gensee_id =", value, "courseGenseeId");
            return (Criteria) this;
        }

        public Criteria andCourseGenseeIdNotEqualTo(Integer value) {
            addCriterion("course_gensee_id <>", value, "courseGenseeId");
            return (Criteria) this;
        }

        public Criteria andCourseGenseeIdGreaterThan(Integer value) {
            addCriterion("course_gensee_id >", value, "courseGenseeId");
            return (Criteria) this;
        }

        public Criteria andCourseGenseeIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("course_gensee_id >=", value, "courseGenseeId");
            return (Criteria) this;
        }

        public Criteria andCourseGenseeIdLessThan(Integer value) {
            addCriterion("course_gensee_id <", value, "courseGenseeId");
            return (Criteria) this;
        }

        public Criteria andCourseGenseeIdLessThanOrEqualTo(Integer value) {
            addCriterion("course_gensee_id <=", value, "courseGenseeId");
            return (Criteria) this;
        }

        public Criteria andCourseGenseeIdIn(List<Integer> values) {
            addCriterion("course_gensee_id in", values, "courseGenseeId");
            return (Criteria) this;
        }

        public Criteria andCourseGenseeIdNotIn(List<Integer> values) {
            addCriterion("course_gensee_id not in", values, "courseGenseeId");
            return (Criteria) this;
        }

        public Criteria andCourseGenseeIdBetween(Integer value1, Integer value2) {
            addCriterion("course_gensee_id between", value1, value2, "courseGenseeId");
            return (Criteria) this;
        }

        public Criteria andCourseGenseeIdNotBetween(Integer value1, Integer value2) {
            addCriterion("course_gensee_id not between", value1, value2, "courseGenseeId");
            return (Criteria) this;
        }

        public Criteria andRoomIdIsNull() {
            addCriterion("room_id is null");
            return (Criteria) this;
        }

        public Criteria andRoomIdIsNotNull() {
            addCriterion("room_id is not null");
            return (Criteria) this;
        }

        public Criteria andRoomIdEqualTo(String value) {
            addCriterion("room_id =", value, "roomId");
            return (Criteria) this;
        }

        public Criteria andRoomIdNotEqualTo(String value) {
            addCriterion("room_id <>", value, "roomId");
            return (Criteria) this;
        }

        public Criteria andRoomIdGreaterThan(String value) {
            addCriterion("room_id >", value, "roomId");
            return (Criteria) this;
        }

        public Criteria andRoomIdGreaterThanOrEqualTo(String value) {
            addCriterion("room_id >=", value, "roomId");
            return (Criteria) this;
        }

        public Criteria andRoomIdLessThan(String value) {
            addCriterion("room_id <", value, "roomId");
            return (Criteria) this;
        }

        public Criteria andRoomIdLessThanOrEqualTo(String value) {
            addCriterion("room_id <=", value, "roomId");
            return (Criteria) this;
        }

        public Criteria andRoomIdLike(String value) {
            addCriterion("room_id like", value, "roomId");
            return (Criteria) this;
        }

        public Criteria andRoomIdNotLike(String value) {
            addCriterion("room_id not like", value, "roomId");
            return (Criteria) this;
        }

        public Criteria andRoomIdIn(List<String> values) {
            addCriterion("room_id in", values, "roomId");
            return (Criteria) this;
        }

        public Criteria andRoomIdNotIn(List<String> values) {
            addCriterion("room_id not in", values, "roomId");
            return (Criteria) this;
        }

        public Criteria andRoomIdBetween(String value1, String value2) {
            addCriterion("room_id between", value1, value2, "roomId");
            return (Criteria) this;
        }

        public Criteria andRoomIdNotBetween(String value1, String value2) {
            addCriterion("room_id not between", value1, value2, "roomId");
            return (Criteria) this;
        }

        public Criteria andNumberIsNull() {
            addCriterion("number is null");
            return (Criteria) this;
        }

        public Criteria andNumberIsNotNull() {
            addCriterion("number is not null");
            return (Criteria) this;
        }

        public Criteria andNumberEqualTo(String value) {
            addCriterion("number =", value, "number");
            return (Criteria) this;
        }

        public Criteria andNumberNotEqualTo(String value) {
            addCriterion("number <>", value, "number");
            return (Criteria) this;
        }

        public Criteria andNumberGreaterThan(String value) {
            addCriterion("number >", value, "number");
            return (Criteria) this;
        }

        public Criteria andNumberGreaterThanOrEqualTo(String value) {
            addCriterion("number >=", value, "number");
            return (Criteria) this;
        }

        public Criteria andNumberLessThan(String value) {
            addCriterion("number <", value, "number");
            return (Criteria) this;
        }

        public Criteria andNumberLessThanOrEqualTo(String value) {
            addCriterion("number <=", value, "number");
            return (Criteria) this;
        }

        public Criteria andNumberLike(String value) {
            addCriterion("number like", value, "number");
            return (Criteria) this;
        }

        public Criteria andNumberNotLike(String value) {
            addCriterion("number not like", value, "number");
            return (Criteria) this;
        }

        public Criteria andNumberIn(List<String> values) {
            addCriterion("number in", values, "number");
            return (Criteria) this;
        }

        public Criteria andNumberNotIn(List<String> values) {
            addCriterion("number not in", values, "number");
            return (Criteria) this;
        }

        public Criteria andNumberBetween(String value1, String value2) {
            addCriterion("number between", value1, value2, "number");
            return (Criteria) this;
        }

        public Criteria andNumberNotBetween(String value1, String value2) {
            addCriterion("number not between", value1, value2, "number");
            return (Criteria) this;
        }

        public Criteria andAssistanttokenIsNull() {
            addCriterion("assistantToken is null");
            return (Criteria) this;
        }

        public Criteria andAssistanttokenIsNotNull() {
            addCriterion("assistantToken is not null");
            return (Criteria) this;
        }

        public Criteria andAssistanttokenEqualTo(String value) {
            addCriterion("assistantToken =", value, "assistanttoken");
            return (Criteria) this;
        }

        public Criteria andAssistanttokenNotEqualTo(String value) {
            addCriterion("assistantToken <>", value, "assistanttoken");
            return (Criteria) this;
        }

        public Criteria andAssistanttokenGreaterThan(String value) {
            addCriterion("assistantToken >", value, "assistanttoken");
            return (Criteria) this;
        }

        public Criteria andAssistanttokenGreaterThanOrEqualTo(String value) {
            addCriterion("assistantToken >=", value, "assistanttoken");
            return (Criteria) this;
        }

        public Criteria andAssistanttokenLessThan(String value) {
            addCriterion("assistantToken <", value, "assistanttoken");
            return (Criteria) this;
        }

        public Criteria andAssistanttokenLessThanOrEqualTo(String value) {
            addCriterion("assistantToken <=", value, "assistanttoken");
            return (Criteria) this;
        }

        public Criteria andAssistanttokenLike(String value) {
            addCriterion("assistantToken like", value, "assistanttoken");
            return (Criteria) this;
        }

        public Criteria andAssistanttokenNotLike(String value) {
            addCriterion("assistantToken not like", value, "assistanttoken");
            return (Criteria) this;
        }

        public Criteria andAssistanttokenIn(List<String> values) {
            addCriterion("assistantToken in", values, "assistanttoken");
            return (Criteria) this;
        }

        public Criteria andAssistanttokenNotIn(List<String> values) {
            addCriterion("assistantToken not in", values, "assistanttoken");
            return (Criteria) this;
        }

        public Criteria andAssistanttokenBetween(String value1, String value2) {
            addCriterion("assistantToken between", value1, value2, "assistanttoken");
            return (Criteria) this;
        }

        public Criteria andAssistanttokenNotBetween(String value1, String value2) {
            addCriterion("assistantToken not between", value1, value2, "assistanttoken");
            return (Criteria) this;
        }

        public Criteria andStudenttokenIsNull() {
            addCriterion("studentToken is null");
            return (Criteria) this;
        }

        public Criteria andStudenttokenIsNotNull() {
            addCriterion("studentToken is not null");
            return (Criteria) this;
        }

        public Criteria andStudenttokenEqualTo(String value) {
            addCriterion("studentToken =", value, "studenttoken");
            return (Criteria) this;
        }

        public Criteria andStudenttokenNotEqualTo(String value) {
            addCriterion("studentToken <>", value, "studenttoken");
            return (Criteria) this;
        }

        public Criteria andStudenttokenGreaterThan(String value) {
            addCriterion("studentToken >", value, "studenttoken");
            return (Criteria) this;
        }

        public Criteria andStudenttokenGreaterThanOrEqualTo(String value) {
            addCriterion("studentToken >=", value, "studenttoken");
            return (Criteria) this;
        }

        public Criteria andStudenttokenLessThan(String value) {
            addCriterion("studentToken <", value, "studenttoken");
            return (Criteria) this;
        }

        public Criteria andStudenttokenLessThanOrEqualTo(String value) {
            addCriterion("studentToken <=", value, "studenttoken");
            return (Criteria) this;
        }

        public Criteria andStudenttokenLike(String value) {
            addCriterion("studentToken like", value, "studenttoken");
            return (Criteria) this;
        }

        public Criteria andStudenttokenNotLike(String value) {
            addCriterion("studentToken not like", value, "studenttoken");
            return (Criteria) this;
        }

        public Criteria andStudenttokenIn(List<String> values) {
            addCriterion("studentToken in", values, "studenttoken");
            return (Criteria) this;
        }

        public Criteria andStudenttokenNotIn(List<String> values) {
            addCriterion("studentToken not in", values, "studenttoken");
            return (Criteria) this;
        }

        public Criteria andStudenttokenBetween(String value1, String value2) {
            addCriterion("studentToken between", value1, value2, "studenttoken");
            return (Criteria) this;
        }

        public Criteria andStudenttokenNotBetween(String value1, String value2) {
            addCriterion("studentToken not between", value1, value2, "studenttoken");
            return (Criteria) this;
        }

        public Criteria andTeachertokenIsNull() {
            addCriterion("teacherToken is null");
            return (Criteria) this;
        }

        public Criteria andTeachertokenIsNotNull() {
            addCriterion("teacherToken is not null");
            return (Criteria) this;
        }

        public Criteria andTeachertokenEqualTo(String value) {
            addCriterion("teacherToken =", value, "teachertoken");
            return (Criteria) this;
        }

        public Criteria andTeachertokenNotEqualTo(String value) {
            addCriterion("teacherToken <>", value, "teachertoken");
            return (Criteria) this;
        }

        public Criteria andTeachertokenGreaterThan(String value) {
            addCriterion("teacherToken >", value, "teachertoken");
            return (Criteria) this;
        }

        public Criteria andTeachertokenGreaterThanOrEqualTo(String value) {
            addCriterion("teacherToken >=", value, "teachertoken");
            return (Criteria) this;
        }

        public Criteria andTeachertokenLessThan(String value) {
            addCriterion("teacherToken <", value, "teachertoken");
            return (Criteria) this;
        }

        public Criteria andTeachertokenLessThanOrEqualTo(String value) {
            addCriterion("teacherToken <=", value, "teachertoken");
            return (Criteria) this;
        }

        public Criteria andTeachertokenLike(String value) {
            addCriterion("teacherToken like", value, "teachertoken");
            return (Criteria) this;
        }

        public Criteria andTeachertokenNotLike(String value) {
            addCriterion("teacherToken not like", value, "teachertoken");
            return (Criteria) this;
        }

        public Criteria andTeachertokenIn(List<String> values) {
            addCriterion("teacherToken in", values, "teachertoken");
            return (Criteria) this;
        }

        public Criteria andTeachertokenNotIn(List<String> values) {
            addCriterion("teacherToken not in", values, "teachertoken");
            return (Criteria) this;
        }

        public Criteria andTeachertokenBetween(String value1, String value2) {
            addCriterion("teacherToken between", value1, value2, "teachertoken");
            return (Criteria) this;
        }

        public Criteria andTeachertokenNotBetween(String value1, String value2) {
            addCriterion("teacherToken not between", value1, value2, "teachertoken");
            return (Criteria) this;
        }

        public Criteria andStudentclienttokenIsNull() {
            addCriterion("studentClientToken is null");
            return (Criteria) this;
        }

        public Criteria andStudentclienttokenIsNotNull() {
            addCriterion("studentClientToken is not null");
            return (Criteria) this;
        }

        public Criteria andStudentclienttokenEqualTo(String value) {
            addCriterion("studentClientToken =", value, "studentclienttoken");
            return (Criteria) this;
        }

        public Criteria andStudentclienttokenNotEqualTo(String value) {
            addCriterion("studentClientToken <>", value, "studentclienttoken");
            return (Criteria) this;
        }

        public Criteria andStudentclienttokenGreaterThan(String value) {
            addCriterion("studentClientToken >", value, "studentclienttoken");
            return (Criteria) this;
        }

        public Criteria andStudentclienttokenGreaterThanOrEqualTo(String value) {
            addCriterion("studentClientToken >=", value, "studentclienttoken");
            return (Criteria) this;
        }

        public Criteria andStudentclienttokenLessThan(String value) {
            addCriterion("studentClientToken <", value, "studentclienttoken");
            return (Criteria) this;
        }

        public Criteria andStudentclienttokenLessThanOrEqualTo(String value) {
            addCriterion("studentClientToken <=", value, "studentclienttoken");
            return (Criteria) this;
        }

        public Criteria andStudentclienttokenLike(String value) {
            addCriterion("studentClientToken like", value, "studentclienttoken");
            return (Criteria) this;
        }

        public Criteria andStudentclienttokenNotLike(String value) {
            addCriterion("studentClientToken not like", value, "studentclienttoken");
            return (Criteria) this;
        }

        public Criteria andStudentclienttokenIn(List<String> values) {
            addCriterion("studentClientToken in", values, "studentclienttoken");
            return (Criteria) this;
        }

        public Criteria andStudentclienttokenNotIn(List<String> values) {
            addCriterion("studentClientToken not in", values, "studentclienttoken");
            return (Criteria) this;
        }

        public Criteria andStudentclienttokenBetween(String value1, String value2) {
            addCriterion("studentClientToken between", value1, value2, "studentclienttoken");
            return (Criteria) this;
        }

        public Criteria andStudentclienttokenNotBetween(String value1, String value2) {
            addCriterion("studentClientToken not between", value1, value2, "studentclienttoken");
            return (Criteria) this;
        }

        public Criteria andStartdateIsNull() {
            addCriterion("startDate is null");
            return (Criteria) this;
        }

        public Criteria andStartdateIsNotNull() {
            addCriterion("startDate is not null");
            return (Criteria) this;
        }

        public Criteria andStartdateEqualTo(Date value) {
            addCriterion("startDate =", value, "startdate");
            return (Criteria) this;
        }

        public Criteria andStartdateNotEqualTo(Date value) {
            addCriterion("startDate <>", value, "startdate");
            return (Criteria) this;
        }

        public Criteria andStartdateGreaterThan(Date value) {
            addCriterion("startDate >", value, "startdate");
            return (Criteria) this;
        }

        public Criteria andStartdateGreaterThanOrEqualTo(Date value) {
            addCriterion("startDate >=", value, "startdate");
            return (Criteria) this;
        }

        public Criteria andStartdateLessThan(Date value) {
            addCriterion("startDate <", value, "startdate");
            return (Criteria) this;
        }

        public Criteria andStartdateLessThanOrEqualTo(Date value) {
            addCriterion("startDate <=", value, "startdate");
            return (Criteria) this;
        }

        public Criteria andStartdateIn(List<Date> values) {
            addCriterion("startDate in", values, "startdate");
            return (Criteria) this;
        }

        public Criteria andStartdateNotIn(List<Date> values) {
            addCriterion("startDate not in", values, "startdate");
            return (Criteria) this;
        }

        public Criteria andStartdateBetween(Date value1, Date value2) {
            addCriterion("startDate between", value1, value2, "startdate");
            return (Criteria) this;
        }

        public Criteria andStartdateNotBetween(Date value1, Date value2) {
            addCriterion("startDate not between", value1, value2, "startdate");
            return (Criteria) this;
        }

        public Criteria andWebjoinIsNull() {
            addCriterion("webJoin is null");
            return (Criteria) this;
        }

        public Criteria andWebjoinIsNotNull() {
            addCriterion("webJoin is not null");
            return (Criteria) this;
        }

        public Criteria andWebjoinEqualTo(Byte value) {
            addCriterion("webJoin =", value, "webjoin");
            return (Criteria) this;
        }

        public Criteria andWebjoinNotEqualTo(Byte value) {
            addCriterion("webJoin <>", value, "webjoin");
            return (Criteria) this;
        }

        public Criteria andWebjoinGreaterThan(Byte value) {
            addCriterion("webJoin >", value, "webjoin");
            return (Criteria) this;
        }

        public Criteria andWebjoinGreaterThanOrEqualTo(Byte value) {
            addCriterion("webJoin >=", value, "webjoin");
            return (Criteria) this;
        }

        public Criteria andWebjoinLessThan(Byte value) {
            addCriterion("webJoin <", value, "webjoin");
            return (Criteria) this;
        }

        public Criteria andWebjoinLessThanOrEqualTo(Byte value) {
            addCriterion("webJoin <=", value, "webjoin");
            return (Criteria) this;
        }

        public Criteria andWebjoinIn(List<Byte> values) {
            addCriterion("webJoin in", values, "webjoin");
            return (Criteria) this;
        }

        public Criteria andWebjoinNotIn(List<Byte> values) {
            addCriterion("webJoin not in", values, "webjoin");
            return (Criteria) this;
        }

        public Criteria andWebjoinBetween(Byte value1, Byte value2) {
            addCriterion("webJoin between", value1, value2, "webjoin");
            return (Criteria) this;
        }

        public Criteria andWebjoinNotBetween(Byte value1, Byte value2) {
            addCriterion("webJoin not between", value1, value2, "webjoin");
            return (Criteria) this;
        }

        public Criteria andClientjoinIsNull() {
            addCriterion("clientJoin is null");
            return (Criteria) this;
        }

        public Criteria andClientjoinIsNotNull() {
            addCriterion("clientJoin is not null");
            return (Criteria) this;
        }

        public Criteria andClientjoinEqualTo(Byte value) {
            addCriterion("clientJoin =", value, "clientjoin");
            return (Criteria) this;
        }

        public Criteria andClientjoinNotEqualTo(Byte value) {
            addCriterion("clientJoin <>", value, "clientjoin");
            return (Criteria) this;
        }

        public Criteria andClientjoinGreaterThan(Byte value) {
            addCriterion("clientJoin >", value, "clientjoin");
            return (Criteria) this;
        }

        public Criteria andClientjoinGreaterThanOrEqualTo(Byte value) {
            addCriterion("clientJoin >=", value, "clientjoin");
            return (Criteria) this;
        }

        public Criteria andClientjoinLessThan(Byte value) {
            addCriterion("clientJoin <", value, "clientjoin");
            return (Criteria) this;
        }

        public Criteria andClientjoinLessThanOrEqualTo(Byte value) {
            addCriterion("clientJoin <=", value, "clientjoin");
            return (Criteria) this;
        }

        public Criteria andClientjoinIn(List<Byte> values) {
            addCriterion("clientJoin in", values, "clientjoin");
            return (Criteria) this;
        }

        public Criteria andClientjoinNotIn(List<Byte> values) {
            addCriterion("clientJoin not in", values, "clientjoin");
            return (Criteria) this;
        }

        public Criteria andClientjoinBetween(Byte value1, Byte value2) {
            addCriterion("clientJoin between", value1, value2, "clientjoin");
            return (Criteria) this;
        }

        public Criteria andClientjoinNotBetween(Byte value1, Byte value2) {
            addCriterion("clientJoin not between", value1, value2, "clientjoin");
            return (Criteria) this;
        }

        public Criteria andInvaliddateIsNull() {
            addCriterion("invalidDate is null");
            return (Criteria) this;
        }

        public Criteria andInvaliddateIsNotNull() {
            addCriterion("invalidDate is not null");
            return (Criteria) this;
        }

        public Criteria andInvaliddateEqualTo(Date value) {
            addCriterion("invalidDate =", value, "invaliddate");
            return (Criteria) this;
        }

        public Criteria andInvaliddateNotEqualTo(Date value) {
            addCriterion("invalidDate <>", value, "invaliddate");
            return (Criteria) this;
        }

        public Criteria andInvaliddateGreaterThan(Date value) {
            addCriterion("invalidDate >", value, "invaliddate");
            return (Criteria) this;
        }

        public Criteria andInvaliddateGreaterThanOrEqualTo(Date value) {
            addCriterion("invalidDate >=", value, "invaliddate");
            return (Criteria) this;
        }

        public Criteria andInvaliddateLessThan(Date value) {
            addCriterion("invalidDate <", value, "invaliddate");
            return (Criteria) this;
        }

        public Criteria andInvaliddateLessThanOrEqualTo(Date value) {
            addCriterion("invalidDate <=", value, "invaliddate");
            return (Criteria) this;
        }

        public Criteria andInvaliddateIn(List<Date> values) {
            addCriterion("invalidDate in", values, "invaliddate");
            return (Criteria) this;
        }

        public Criteria andInvaliddateNotIn(List<Date> values) {
            addCriterion("invalidDate not in", values, "invaliddate");
            return (Criteria) this;
        }

        public Criteria andInvaliddateBetween(Date value1, Date value2) {
            addCriterion("invalidDate between", value1, value2, "invaliddate");
            return (Criteria) this;
        }

        public Criteria andInvaliddateNotBetween(Date value1, Date value2) {
            addCriterion("invalidDate not between", value1, value2, "invaliddate");
            return (Criteria) this;
        }

        public Criteria andTeacherjoinurlIsNull() {
            addCriterion("teacherJoinUrl is null");
            return (Criteria) this;
        }

        public Criteria andTeacherjoinurlIsNotNull() {
            addCriterion("teacherJoinUrl is not null");
            return (Criteria) this;
        }

        public Criteria andTeacherjoinurlEqualTo(String value) {
            addCriterion("teacherJoinUrl =", value, "teacherjoinurl");
            return (Criteria) this;
        }

        public Criteria andTeacherjoinurlNotEqualTo(String value) {
            addCriterion("teacherJoinUrl <>", value, "teacherjoinurl");
            return (Criteria) this;
        }

        public Criteria andTeacherjoinurlGreaterThan(String value) {
            addCriterion("teacherJoinUrl >", value, "teacherjoinurl");
            return (Criteria) this;
        }

        public Criteria andTeacherjoinurlGreaterThanOrEqualTo(String value) {
            addCriterion("teacherJoinUrl >=", value, "teacherjoinurl");
            return (Criteria) this;
        }

        public Criteria andTeacherjoinurlLessThan(String value) {
            addCriterion("teacherJoinUrl <", value, "teacherjoinurl");
            return (Criteria) this;
        }

        public Criteria andTeacherjoinurlLessThanOrEqualTo(String value) {
            addCriterion("teacherJoinUrl <=", value, "teacherjoinurl");
            return (Criteria) this;
        }

        public Criteria andTeacherjoinurlLike(String value) {
            addCriterion("teacherJoinUrl like", value, "teacherjoinurl");
            return (Criteria) this;
        }

        public Criteria andTeacherjoinurlNotLike(String value) {
            addCriterion("teacherJoinUrl not like", value, "teacherjoinurl");
            return (Criteria) this;
        }

        public Criteria andTeacherjoinurlIn(List<String> values) {
            addCriterion("teacherJoinUrl in", values, "teacherjoinurl");
            return (Criteria) this;
        }

        public Criteria andTeacherjoinurlNotIn(List<String> values) {
            addCriterion("teacherJoinUrl not in", values, "teacherjoinurl");
            return (Criteria) this;
        }

        public Criteria andTeacherjoinurlBetween(String value1, String value2) {
            addCriterion("teacherJoinUrl between", value1, value2, "teacherjoinurl");
            return (Criteria) this;
        }

        public Criteria andTeacherjoinurlNotBetween(String value1, String value2) {
            addCriterion("teacherJoinUrl not between", value1, value2, "teacherjoinurl");
            return (Criteria) this;
        }

        public Criteria andStudentjoinurlIsNull() {
            addCriterion("studentJoinUrl is null");
            return (Criteria) this;
        }

        public Criteria andStudentjoinurlIsNotNull() {
            addCriterion("studentJoinUrl is not null");
            return (Criteria) this;
        }

        public Criteria andStudentjoinurlEqualTo(String value) {
            addCriterion("studentJoinUrl =", value, "studentjoinurl");
            return (Criteria) this;
        }

        public Criteria andStudentjoinurlNotEqualTo(String value) {
            addCriterion("studentJoinUrl <>", value, "studentjoinurl");
            return (Criteria) this;
        }

        public Criteria andStudentjoinurlGreaterThan(String value) {
            addCriterion("studentJoinUrl >", value, "studentjoinurl");
            return (Criteria) this;
        }

        public Criteria andStudentjoinurlGreaterThanOrEqualTo(String value) {
            addCriterion("studentJoinUrl >=", value, "studentjoinurl");
            return (Criteria) this;
        }

        public Criteria andStudentjoinurlLessThan(String value) {
            addCriterion("studentJoinUrl <", value, "studentjoinurl");
            return (Criteria) this;
        }

        public Criteria andStudentjoinurlLessThanOrEqualTo(String value) {
            addCriterion("studentJoinUrl <=", value, "studentjoinurl");
            return (Criteria) this;
        }

        public Criteria andStudentjoinurlLike(String value) {
            addCriterion("studentJoinUrl like", value, "studentjoinurl");
            return (Criteria) this;
        }

        public Criteria andStudentjoinurlNotLike(String value) {
            addCriterion("studentJoinUrl not like", value, "studentjoinurl");
            return (Criteria) this;
        }

        public Criteria andStudentjoinurlIn(List<String> values) {
            addCriterion("studentJoinUrl in", values, "studentjoinurl");
            return (Criteria) this;
        }

        public Criteria andStudentjoinurlNotIn(List<String> values) {
            addCriterion("studentJoinUrl not in", values, "studentjoinurl");
            return (Criteria) this;
        }

        public Criteria andStudentjoinurlBetween(String value1, String value2) {
            addCriterion("studentJoinUrl between", value1, value2, "studentjoinurl");
            return (Criteria) this;
        }

        public Criteria andStudentjoinurlNotBetween(String value1, String value2) {
            addCriterion("studentJoinUrl not between", value1, value2, "studentjoinurl");
            return (Criteria) this;
        }

        public Criteria andSceneIsNull() {
            addCriterion("scene is null");
            return (Criteria) this;
        }

        public Criteria andSceneIsNotNull() {
            addCriterion("scene is not null");
            return (Criteria) this;
        }

        public Criteria andSceneEqualTo(Byte value) {
            addCriterion("scene =", value, "scene");
            return (Criteria) this;
        }

        public Criteria andSceneNotEqualTo(Byte value) {
            addCriterion("scene <>", value, "scene");
            return (Criteria) this;
        }

        public Criteria andSceneGreaterThan(Byte value) {
            addCriterion("scene >", value, "scene");
            return (Criteria) this;
        }

        public Criteria andSceneGreaterThanOrEqualTo(Byte value) {
            addCriterion("scene >=", value, "scene");
            return (Criteria) this;
        }

        public Criteria andSceneLessThan(Byte value) {
            addCriterion("scene <", value, "scene");
            return (Criteria) this;
        }

        public Criteria andSceneLessThanOrEqualTo(Byte value) {
            addCriterion("scene <=", value, "scene");
            return (Criteria) this;
        }

        public Criteria andSceneIn(List<Byte> values) {
            addCriterion("scene in", values, "scene");
            return (Criteria) this;
        }

        public Criteria andSceneNotIn(List<Byte> values) {
            addCriterion("scene not in", values, "scene");
            return (Criteria) this;
        }

        public Criteria andSceneBetween(Byte value1, Byte value2) {
            addCriterion("scene between", value1, value2, "scene");
            return (Criteria) this;
        }

        public Criteria andSceneNotBetween(Byte value1, Byte value2) {
            addCriterion("scene not between", value1, value2, "scene");
            return (Criteria) this;
        }

        public Criteria andCodeIsNull() {
            addCriterion("code is null");
            return (Criteria) this;
        }

        public Criteria andCodeIsNotNull() {
            addCriterion("code is not null");
            return (Criteria) this;
        }

        public Criteria andCodeEqualTo(String value) {
            addCriterion("code =", value, "code");
            return (Criteria) this;
        }

        public Criteria andCodeNotEqualTo(String value) {
            addCriterion("code <>", value, "code");
            return (Criteria) this;
        }

        public Criteria andCodeGreaterThan(String value) {
            addCriterion("code >", value, "code");
            return (Criteria) this;
        }

        public Criteria andCodeGreaterThanOrEqualTo(String value) {
            addCriterion("code >=", value, "code");
            return (Criteria) this;
        }

        public Criteria andCodeLessThan(String value) {
            addCriterion("code <", value, "code");
            return (Criteria) this;
        }

        public Criteria andCodeLessThanOrEqualTo(String value) {
            addCriterion("code <=", value, "code");
            return (Criteria) this;
        }

        public Criteria andCodeLike(String value) {
            addCriterion("code like", value, "code");
            return (Criteria) this;
        }

        public Criteria andCodeNotLike(String value) {
            addCriterion("code not like", value, "code");
            return (Criteria) this;
        }

        public Criteria andCodeIn(List<String> values) {
            addCriterion("code in", values, "code");
            return (Criteria) this;
        }

        public Criteria andCodeNotIn(List<String> values) {
            addCriterion("code not in", values, "code");
            return (Criteria) this;
        }

        public Criteria andCodeBetween(String value1, String value2) {
            addCriterion("code between", value1, value2, "code");
            return (Criteria) this;
        }

        public Criteria andCodeNotBetween(String value1, String value2) {
            addCriterion("code not between", value1, value2, "code");
            return (Criteria) this;
        }

        public Criteria andMessageIsNull() {
            addCriterion("message is null");
            return (Criteria) this;
        }

        public Criteria andMessageIsNotNull() {
            addCriterion("message is not null");
            return (Criteria) this;
        }

        public Criteria andMessageEqualTo(String value) {
            addCriterion("message =", value, "message");
            return (Criteria) this;
        }

        public Criteria andMessageNotEqualTo(String value) {
            addCriterion("message <>", value, "message");
            return (Criteria) this;
        }

        public Criteria andMessageGreaterThan(String value) {
            addCriterion("message >", value, "message");
            return (Criteria) this;
        }

        public Criteria andMessageGreaterThanOrEqualTo(String value) {
            addCriterion("message >=", value, "message");
            return (Criteria) this;
        }

        public Criteria andMessageLessThan(String value) {
            addCriterion("message <", value, "message");
            return (Criteria) this;
        }

        public Criteria andMessageLessThanOrEqualTo(String value) {
            addCriterion("message <=", value, "message");
            return (Criteria) this;
        }

        public Criteria andMessageLike(String value) {
            addCriterion("message like", value, "message");
            return (Criteria) this;
        }

        public Criteria andMessageNotLike(String value) {
            addCriterion("message not like", value, "message");
            return (Criteria) this;
        }

        public Criteria andMessageIn(List<String> values) {
            addCriterion("message in", values, "message");
            return (Criteria) this;
        }

        public Criteria andMessageNotIn(List<String> values) {
            addCriterion("message not in", values, "message");
            return (Criteria) this;
        }

        public Criteria andMessageBetween(String value1, String value2) {
            addCriterion("message between", value1, value2, "message");
            return (Criteria) this;
        }

        public Criteria andMessageNotBetween(String value1, String value2) {
            addCriterion("message not between", value1, value2, "message");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}