package com.ruida.cloud.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;

public class Distributor implements Serializable {

    /**
     * 分销商ID,自增长
     */
    private Integer distributorId;

    /**
     * 父ID
     */
    private Integer fid;

    /**
     * 经销商名称
     */
    private String distributorName;

    /**
     * 绑定的用户Id
     */
    private Integer bindAccount;

    /**
     * 绑定的用户姓名
     */
    private String bindName;

    /**
     * 二维码地址
     */
    private String ticket;

    /**
     * 创建者ID
     */
    private Integer createBy;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改者ID
     */
    private Integer updateBy;

    /**
     * 修改时间
     */
    private Date updateTime;

    /**
     * 是否删除
     */
    private Byte isdelete;

    /**
     * 子经销商信息
     */
    private ArrayList<Distributor> children;

    /**
     * 层级
     */
    private Byte level;

    private static final long serialVersionUID = 1L;

    public Byte getLevel() { return level; }

    public void setLevel(Byte level) { this.level = level; }

    public ArrayList<Distributor> getChildren() { return children; }

    public void setChildren(ArrayList<Distributor> children) { this.children = children; }

    public Integer getDistributorId() {
        return distributorId;
    }

    public void setDistributorId(Integer distributorId) {
        this.distributorId = distributorId;
    }

    public Integer getFid() {
        return fid;
    }

    public void setFid(Integer fid) {
        this.fid = fid;
    }

    public String getDistributorName() {
        return distributorName;
    }

    public void setDistributorName(String distributorName) {
        this.distributorName = distributorName == null ? null : distributorName.trim();
    }

    public String getTicket() {
        return ticket;
    }

    public void setTicket(String ticket) {
        this.ticket = ticket == null ? null : ticket.trim();
    }

    public Integer getCreateBy() {
        return createBy;
    }

    public void setCreateBy(Integer createBy) {
        this.createBy = createBy;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(Integer updateBy) {
        this.updateBy = updateBy;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Byte getIsdelete() {
        return isdelete;
    }

    public void setIsdelete(Byte isdelete) {
        this.isdelete = isdelete;
    }

    public Integer getBindAccount() { return bindAccount; }

    public void setBindAccount(Integer bindAccount) { this.bindAccount = bindAccount; }

    public String getBindName() { return bindName; }

    public void setBindName(String bindName) { this.bindName = bindName; }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", distributorId=").append(distributorId);
        sb.append(", fid=").append(fid);
        sb.append(", distributorName=").append(distributorName);
        sb.append(", ticket=").append(ticket);
        sb.append(", createBy=").append(createBy);
        sb.append(", createTime=").append(createTime);
        sb.append(", updateBy=").append(updateBy);
        sb.append(", updateTime=").append(updateTime);
        sb.append(", isdelete=").append(isdelete);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}
