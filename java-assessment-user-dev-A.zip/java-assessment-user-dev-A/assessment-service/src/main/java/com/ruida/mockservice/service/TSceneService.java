package com.ruida.mockservice.service;

import com.baomidou.mybatisplus.service.IService;
import com.ruida.mockdao.model.TScene;
import com.ruida.mockdao.vo.SceneDetailInfoVO;
import com.ruida.mockdao.vo.SceneInfoVO;

import java.util.List;

/**
 * <p>
 * 场次表 服务类
 * </p>
 *
 * @author szl
 * @since 2021-07-22
 */
public interface TSceneService extends IService<TScene> {
    String getSceneId(Integer productId, Integer testPaperId);

    Boolean checkStudentInScene(Integer stuId, String sceneId);

    /**
     * 查询五分钟内结束的场次
     * @return
     */
    List<TScene> selectIn5MinuteEnd();
    List<SceneInfoVO> getSceneListByStudent();
    SceneDetailInfoVO getSceneDetailByStudent(String sceneId);
}
