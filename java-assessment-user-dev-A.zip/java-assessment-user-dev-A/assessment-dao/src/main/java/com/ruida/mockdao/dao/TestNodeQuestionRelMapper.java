package com.ruida.mockdao.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.model.TestNodeQuestionRel;
import com.ruida.mockdao.vo.NodeVO;
import com.ruida.mockdao.vo.TestNodeQuestionVo;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * 小节试题关联表 Mapper 接口
 * </p>
 *
 * @author chenjy
 * @since 2020-07-15
 */
public interface TestNodeQuestionRelMapper extends BaseMapper<TestNodeQuestionRel> {

    Double queryQuestionScore(@Param("testPaperId") Integer testPaperId, @Param("questionId") String questionId);
    Double queryQuestionRegressionScore(@Param("testPaperId") Integer testPaperId, @Param("questionId") String questionId);

    List<NodeVO> analysisTestPaper(Map<String,Object> param);

    List<TestNodeQuestionVo> queryTestNodeQuestion(@Param("testPaperId") Integer testPaperId, @Param("questionIds")List<String> questionIds);

}
