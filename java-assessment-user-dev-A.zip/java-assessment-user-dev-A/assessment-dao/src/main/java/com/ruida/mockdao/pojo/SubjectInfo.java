package com.ruida.mockdao.pojo;

import java.math.BigDecimal;

/**
 * @description: 科目选考-科目信息
 * @author: chenjy
 * @create: 2021-01-18 10:07
 */
public class SubjectInfo extends BasicSubjectInfo{

    /**
     * 1--进步 0--不变 -1--退步
     */
    private Integer type = 0;

    private BigDecimal range = BigDecimal.ZERO;

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public BigDecimal getRange() {
        return range;
    }

    public void setRange(BigDecimal range) {
        this.range = range;
    }
}
