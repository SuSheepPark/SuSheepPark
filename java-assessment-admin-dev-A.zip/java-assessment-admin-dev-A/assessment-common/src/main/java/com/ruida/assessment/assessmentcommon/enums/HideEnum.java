package com.ruida.assessment.assessmentcommon.enums;

/**
 * @description: 隐藏枚举类
 * @author: wy
 * @date: 2021/7/2
 */
public enum HideEnum {
    NOHIDE(0,"显示"),
    HIDE(1,"隐藏"),
    ;

    private Integer K;
    private String V;

    HideEnum(Integer k, String v) {
        K = k;
        V = v;
    }

    public Integer getK() {
        return K;
    }

    public void setK(Integer k) {
        K = k;
    }

    public String getV() {
        return V;
    }

    public void setV(String v) {
        V = v;
    }

    public static HideEnum getValueById(Integer K){
        if(K != null){
            for(HideEnum deleteStatusEnum : HideEnum.values() ){
                if(deleteStatusEnum.getK().equals(K)){
                    return  deleteStatusEnum;
                }
            }
        }
        return null;
    }

}
