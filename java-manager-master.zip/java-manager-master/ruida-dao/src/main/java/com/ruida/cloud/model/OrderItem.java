package com.ruida.cloud.model;

import java.math.BigDecimal;
import java.util.Date;

public class OrderItem {
    /**
     * 订单详情主键ID
     */
    private Integer orderItemId;

    /**
     * 订单ID
     */
    private Integer orderId;

    /**
     * 课程ID
     */
    private Integer courseId;

    /**
     * 课程类型名称
     */
    private String courseTypeName;

    /**
     * 课程名称
     */
    private String courseName;

    /**
     * 课程单价
     */
    private BigDecimal coursePrice;

    /**
     * 优惠额度（85，表示打八五折）
     */
    private Byte courseSale;

    /**
     * 学段名称
     */
    private String periodName;

    /**
     * 年级名称
     */
    private String stageName;

    /**
     * 班级名称
     */
    private String subjectName;

    /**
     * 封面图片路径
     */
    private String coverPath;

    /**
     * 课程有效期（1个月；3个月；6个月；12个月；3年；无限期）
     */
    private String validTime;

    /**
     * 开课次间
     */
    private Date startTime;

    /**
     * 课次数
     */
    private Integer courseLessonNum;

    /**
     * 授课方式
     */
    private Integer teachingMethod;

    /**
     * 直播间id
     */
    private Integer broadcastRoomId;

    /**
     * 校区id
     */
    private Integer campusId;

    /**
     * 校区名称
     */
    private String campusName;
    private  String schoolName;
    private Date endTime;

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public String getSchoolName() {
        return schoolName;
    }

    public void setSchoolName(String schoolName) {
        this.schoolName = schoolName;
    }

    public Integer getOrderItemId() {
        return orderItemId;
    }

    public void setOrderItemId(Integer orderItemId) {
        this.orderItemId = orderItemId;
    }

    public Integer getOrderId() {
        return orderId;
    }

    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    public Integer getCourseId() {
        return courseId;
    }

    public void setCourseId(Integer courseId) {
        this.courseId = courseId;
    }

    public String getCourseTypeName() {
        return courseTypeName;
    }

    public void setCourseTypeName(String courseTypeName) {
        this.courseTypeName = courseTypeName == null ? null : courseTypeName.trim();
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName == null ? null : courseName.trim();
    }

    public BigDecimal getCoursePrice() {
        return coursePrice;
    }

    public void setCoursePrice(BigDecimal coursePrice) {
        this.coursePrice = coursePrice;
    }

    public Byte getCourseSale() {
        return courseSale;
    }

    public void setCourseSale(Byte courseSale) {
        this.courseSale = courseSale;
    }

    public String getPeriodName() {
        return periodName;
    }

    public void setPeriodName(String periodName) {
        this.periodName = periodName == null ? null : periodName.trim();
    }

    public String getStageName() {
        return stageName;
    }

    public void setStageName(String stageName) {
        this.stageName = stageName == null ? null : stageName.trim();
    }

    public String getSubjectName() {
        return subjectName;
    }

    public void setSubjectName(String subjectName) {
        this.subjectName = subjectName == null ? null : subjectName.trim();
    }

    public String getCoverPath() {
        return coverPath;
    }

    public void setCoverPath(String coverPath) {
        this.coverPath = coverPath == null ? null : coverPath.trim();
    }

    public String getValidTime() {
        return validTime;
    }

    public void setValidTime(String validTime) {
        this.validTime = validTime == null ? null : validTime.trim();
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Integer getcourseLessonNum() {
        return courseLessonNum;
    }

    public void setcourseLessonNum(Integer courseLessonNum) {
        this.courseLessonNum = courseLessonNum;
    }

    public Integer getTeachingMethod() {
        return teachingMethod;
    }

    public void setTeachingMethod(Integer teachingMethod) {
        this.teachingMethod = teachingMethod;
    }

    public Integer getBroadcastRoomId() {
        return broadcastRoomId;
    }

    public void setBroadcastRoomId(Integer broadcastRoomId) {
        this.broadcastRoomId = broadcastRoomId;
    }

    public Integer getCampusId() {
        return campusId;
    }

    public void setCampusId(Integer campusId) {
        this.campusId = campusId;
    }

    public String getCampusName() {
        return campusName;
    }

    public void setCampusName(String campusName) {
        this.campusName = campusName;
    }
}