package com.ruida.cloud.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ruida.common.SystemConstant;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 * 双师听课教室请求类
 */
@Data
public class DoubleStudentClassRequest {


    /**
     * 校区id
     */
    private String zoneId;

    /**
     * 听课教室id
     */
    private String studentClassId;

    /**
     * 听课教室名称
     */
    private String studentClassName;

}