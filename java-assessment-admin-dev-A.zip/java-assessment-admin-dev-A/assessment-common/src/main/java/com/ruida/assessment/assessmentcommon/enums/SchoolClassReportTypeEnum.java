package com.ruida.assessment.assessmentcommon.enums;

/**
 * @description: 班级学校报告类型
 * @author: kgz
 * @date: 2021/9/9
 */
public enum SchoolClassReportTypeEnum {
    SCHOOL(1, "学校报告"),
    CLASS(2, "班级报告"),
    GRADE_ONLINE_UNION(3, "在线统考的年级报告"),
    CLASS_ONLINE_UNION(4, "在线统考的班级报告"),
    SCENE_ONLINE_UNION(5, "在线统考的平台报告"),
    ;


    private Integer K;
    private String V;

    SchoolClassReportTypeEnum(Integer k, String v) {
        K = k;
        V = v;
    }

    public Integer getK() {
        return K;
    }

    public void setK(Integer k) {
        K = k;
    }

    public String getV() {
        return V;
    }

    public void setV(String v) {
        V = v;
    }


    public static SchoolClassReportTypeEnum getValueById(String K) {
        for (SchoolClassReportTypeEnum schoolClassReportTypeEnum : SchoolClassReportTypeEnum.values()) {
            if (schoolClassReportTypeEnum.getK().equals(K)) {
                return schoolClassReportTypeEnum;
            }
        }
        return null;

    }
}