package com.ruida.assessment.assessmentquestionbank.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ruida.assessment.assessmentcommon.result.Page;
import com.ruida.assessment.assessmentquestionbank.SystemConstant;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 * @author wy
 * @description 查询学校请求类
 * @date 2020/7/24
 */
@Data
public class SchoolRequest {

    private Integer schoolId;

    /*学校名称*/
    private String schoolName;

    /*学校代码*/
    private String schoolCode;

    /*查询字段*/
    private String searchWord;

    /*学校来源*/
    private String source;

    /*学校类型/学段ID*/
    private String periodId;

    private String periodName;

    /*省份*/
    private Integer province;

    /**
     * 城市ID
     */
    private Integer city;
    /**
     * 地区ID
     */
    private Integer district;

    /**
     * 状态（0—禁用；1—启用 ）
     */
    private Integer status;

    private String personInCharge;

    private String personInChargePosition;

    private String telephone;
    /*
      创建时间起
      */
    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern= "yyyy-MM-dd HH:mm:ss",timezone= SystemConstant.TIME_ZONE)
    private Date startTime;
    /*
     创建时间止
     */
    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern= "yyyy-MM-dd HH:mm:ss",timezone=SystemConstant.TIME_ZONE)
    private Date endTime;

    private Page page;
    private Integer isdelete = 0;

    /*分页*/
    private Integer start;
    private Integer size;

    private void setSearchWord(String searchWord){
        //正则匹配 查询的是学校代码还是学校名称
        if(searchWord.matches("school_code")){
            this.setSchoolCode(searchWord);
        }else{
            this.setSchoolName(searchWord);
        }
        this.searchWord = searchWord;
    }
}
