package com.ruida.mockdao.model;

import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 小节试题关联表
 * </p>
 *
 * @author chenjy
 * @since 2020-07-15
 */
@TableName("t_test_node_question_rel")
public class TestNodeQuestionRel extends Model<TestNodeQuestionRel> {

    private static final long serialVersionUID = 1L;

    /**
     * 小节试题引用id
     */
    @TableId(value = "rel_id", type = IdType.AUTO)
    private Integer relId;
    /**
     * 小节id
     */
    @TableField("node_id")
    private Integer nodeId;
    /**
     * 试卷id
     */
    @TableField("test_paper_id")
    private Integer testPaperId;
    /**
     * 试题id
     */
    @TableField("question_id")
    private String questionId;
    /**
     * 题型
     */
    @TableField("question_type_id")
    private Integer questionTypeId;
    /**
     * 父级试题id
     */
    @TableField("parent_id")
    private String parentId;
    /**
     * 分值
     */
    private Double score;
    /**
     * 每空分值，逗号分隔，填空题使用
     */
    private String scoreEachBlank;
    /**
     * 赋分类型，填空题使用，0-每空给分，1-单空给分
     */
    private Integer scoreType;
    /**
     * 小节中的试题顺序
     */
    private Integer sort;
    /**
     * 更新时间
     */
    @TableField("update_time")
    private Date updateTime;
    /**
     * 更新人
     */
    @TableField("update_by")
    private Integer updateBy;
    /**
     * 创建时间
     */
    @TableField("create_time")
    private Date createTime;
    /**
     * 创建人
     */
    @TableField("create_by")
    private Integer createBy;
    /**
     * 是否删除
     */
    private Integer isdelete;


    public Integer getRelId() {
        return relId;
    }

    public void setRelId(Integer relId) {
        this.relId = relId;
    }

    public Integer getNodeId() {
        return nodeId;
    }

    public void setNodeId(Integer nodeId) {
        this.nodeId = nodeId;
    }

    public Integer getTestPaperId() {
        return testPaperId;
    }

    public void setTestPaperId(Integer testPaperId) {
        this.testPaperId = testPaperId;
    }

    public String getQuestionId() {
        return questionId;
    }

    public void setQuestionId(String questionId) {
        this.questionId = questionId;
    }

    public Integer getQuestionTypeId() {
        return questionTypeId;
    }

    public void setQuestionTypeId(Integer questionTypeId) {
        this.questionTypeId = questionTypeId;
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public String getScoreEachBlank() {
        return scoreEachBlank;
    }

    public void setScoreEachBlank(String scoreEachBlank) {
        this.scoreEachBlank = scoreEachBlank;
    }

    public Integer getScoreType() {
        return scoreType;
    }

    public void setScoreType(Integer scoreType) {
        this.scoreType = scoreType;
    }

    public Double getScore() {
        return score;
    }

    public void setScore(Double score) {
        this.score = score;
    }

    public Integer getSort() {
        return sort;
    }

    public void setSort(Integer sort) {
        this.sort = sort;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(Integer updateBy) {
        this.updateBy = updateBy;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getCreateBy() {
        return createBy;
    }

    public void setCreateBy(Integer createBy) {
        this.createBy = createBy;
    }

    public Integer getIsdelete() {
        return isdelete;
    }

    public void setIsdelete(Integer isdelete) {
        this.isdelete = isdelete;
    }

    @Override
    protected Serializable pkVal() {
        return this.relId;
    }

    @Override
    public String toString() {
        return "TestNodeQuestionRel{" +
        ", relId=" + relId +
        ", nodeId=" + nodeId +
        ", testPaperId=" + testPaperId +
        ", questionId=" + questionId +
        ", questionTypeId=" + questionTypeId +
        ", parentId=" + parentId +
        ", score=" + score +
        ", sort=" + sort +
        ", updateTime=" + updateTime +
        ", updateBy=" + updateBy +
        ", createTime=" + createTime +
        ", createBy=" + createBy +
        ", isdelete=" + isdelete +
        "}";
    }
}
