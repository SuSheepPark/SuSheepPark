package com.ruida.assessment.assessmentcommon.result;

import lombok.Data;

@Data
public class KnowledgeEntity {
    int status;
    String msg;
    int count;
    Object knowledgeInfo;
}
