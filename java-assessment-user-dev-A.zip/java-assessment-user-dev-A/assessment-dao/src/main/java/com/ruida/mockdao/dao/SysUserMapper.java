package com.ruida.mockdao.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.dto.UserDTO;
import com.ruida.mockdao.model.SysUser;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * 用户表 Mapper 接口
 * </p>
 *
 * @author Bhj
 * @since 2020-07-09
 */
public interface SysUserMapper extends BaseMapper<SysUser> {

    List<Map<String, Object>> selectUserInfos(@Param("userId")String userId);

    Map<String, Object> selectUserInfo(@Param("userId")String userId);

    void insertSysUser(SysUser sysUser);

    Integer updatePassword(@Param("userId") String userId,@Param("password") String password);

    Integer updatePasswordByfind(@Param("password") String password,@Param("telephone") String telephone);

    Integer selectStuIdByUserId(@Param("userId")Integer userId);

    UserDTO queryUserInfo(Integer userId);

    SysUser selectOneByTelephone(@Param("telephone") String telephone);

    void updateByUnionId(@Param("userId") Integer userId,@Param("unionId") String unionId);

    List<SysUser> selectByUnionId(@Param("unionId") String unionId);
}
