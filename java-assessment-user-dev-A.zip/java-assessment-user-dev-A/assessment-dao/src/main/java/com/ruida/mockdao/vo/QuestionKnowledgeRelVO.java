package com.ruida.mockdao.vo;

import lombok.Data;

/**
 * @description: 试题和知识点关联VO
 * @author: chenjy
 * @create: 2020-07-20 16:39
 */
@Data
public class QuestionKnowledgeRelVO {

    /**
     * 试题和知识点关联id
     */
    private Integer id;

    /**
     * 知识点id
     */
    private Integer knowledgeId;

    /**
     * 知识点名称
     */
    private String knowledgeName;

}
