package com.ruida.mockservice.service.impl;

import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.ruida.mockdao.dao.ExamNoticeMapper;
import com.ruida.mockdao.model.ExamNotice;
import com.ruida.mockservice.service.ExamNoticeService;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 考试注意事项表 服务实现类
 * </p>
 *
 * @author chenjy
 * @since 2020-08-03
 */
@Service
public class ExamNoticeServiceImpl extends ServiceImpl<ExamNoticeMapper, ExamNotice> implements ExamNoticeService {

}
