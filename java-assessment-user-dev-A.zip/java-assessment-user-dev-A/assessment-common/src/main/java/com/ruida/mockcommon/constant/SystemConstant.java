package com.ruida.mockcommon.constant;

public class SystemConstant {
	public static final String DEFAULT_PASSWORD = "123456";
	public static final String MD5_SALT = "8F4470DB788FB93DFAF8D91393155921";
	public static final String MD5_SALT_phone = "ruid4acepin'gmsgco3de6793";
	// 前端AES加密密钥
	public static final String AES_SECRET_KEY = "750EAD44034E5FEC";
	public static final String KAPTCHA_KEY = "KAPTCHA_%s";
	public static final int KAPTCHA_KEY_TIME = 60 * 2;
	public static final String SENDMSG_REDIS_KEY = "sendmsg_%s_%s_%s";
	public static final String CODE_REDIS_KEY = "code_%s_%s";
	public static final int PARENT_MODE_TIMEOUT = 10 * 30;
	// 家长模式key+手机号码
	public static final String PARENT_MODE_KEY = "parent_mode_%s";
	// 发送账号和初始化密码短信模板
	public static final String DEFAULT_USER_MSG = "恭喜您已成功注册睿达云测评，您的账号为%s,默认密码%s，请尽快前往账号中心修改密码";

	// 头像名称
	public static final String HEAD_IMG_NAME = "head-img-%s.%s";

	// 答案图片名称
	public static final String ANSWER_IMG_NAME = "answer-img-%s.%s";

	public static final String IMG_PATH = "%s/student/headImg/%s";
	public static final int COURSE_PAGE_SIZE = 15;
	public static final int PAGE_DEFAULT_NUM = 1;
	public static final int USER_PAGE_SIZE = 6;
	public static final int USER_ORDER_PAGE_SIZE = 5;
	public static final int APP_PAGE_SIZE = 10;
	public static final int DEFAULT_PAGESIZE = 10;

	public static final String DATE_FORMAT = "yyyy-MM-dd HH:mm";
	public static final String TIME_ZONE = "GMT+8";
	// webToken
	public static final String TOKEN_KEY = "token_key:user:%s";
	// 微信小程序Token
	public static final String TOKEN_KEY_WX = "token_key:user_wx:%s";
	// 微信小程序Token
	public static final String TOKEN_KEY_STU = "token_key:stu:%s";
	public static final String STAT_KEY = "stat_%s";

	public static final String ORDER_STATUS_TOPIC = "order-status-topic";
	public static final String ORDER_STATUS_GROUPID = "order_status_tag";

	public static final String ORDER_PAY_TOPIC = "order-pay-attention";
	public static final String ORDER_PAY_GROUPID = "GID-order-pay-attention";

	public static final String SEARCH_CITY = "SEARCH_CITY_";

	public static final String producers = "GID-order-status-assessment-" + ",GID-exam-report-stat-" + ",GID-report-unified-";

	// WeiXin小程序ID
	public static final String AppID = "wxc4323dbfadbef318";
	// WeiXin小程序密钥
	public static final String AppSecret = "07e20ebb3d47bc4fb015e7cfdf0f77d8";

}
