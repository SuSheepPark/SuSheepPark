package com.ruida.mockdao.vo;

import com.ruida.mockdao.pojo.BasicSubjectInfo;
import com.ruida.mockdao.pojo.SubjectInfo;

import java.math.BigDecimal;
import java.util.List;

/**
 * @description: 考试成绩小节
 * @author: kgz
 * @date: 2021/2/24
 */
public class ExamRecoreSummaryVO {

    /**
     * 平均分排序
     */
    private List<BasicSubjectInfo> subjectScoreList;

    /**
     * 进步幅度排序
     */
    private List<SubjectInfo> subjectRankList;

    /**
     * 预估总分
     */
    private BigDecimal score;

    public List<BasicSubjectInfo> getSubjectScoreList() {
        return subjectScoreList;
    }

    public void setSubjectScoreList(List<BasicSubjectInfo> subjectScoreList) {
        this.subjectScoreList = subjectScoreList;
    }

    public List<SubjectInfo> getSubjectRankList() {
        return subjectRankList;
    }

    public void setSubjectRankList(List<SubjectInfo> subjectRankList) {
        this.subjectRankList = subjectRankList;
    }

    public BigDecimal getScore() {
        return score;
    }

    public void setScore(BigDecimal score) {
        this.score = score;
    }
}
