package com.ruida.assessment.assessmentquestionbank.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * @description: 订单查询条件
 * @author: kgz
 * @date: 2020/7/31
 */
@ApiModel(description = "订单查询条件")
public class OrderQueryDTO extends QueryBaseDTO {

    @ApiModelProperty(value = "关键字，订单编号、学员账号、联系方式", name = "keyWords")
    private String keyWords;

    @ApiModelProperty(value = "状态", name = "status")
    private Integer status;

    /**
     * @see com.ruida.assessment.assessmentcommon.enums.OrderTypeEnum
     */
    @ApiModelProperty(value = "订单类型", name = "productType")
    private Integer productType;

    @ApiModelProperty(value = "支付方式（0—微信支付；1—支付宝；2—QQ钱包；3—网银支付；4—线下支付；5—免费; 6—学币抵扣）", name = "paymentType")
    private Integer paymentType;

    @ApiModelProperty(value = "是否已退费", name = "refund")
    private Integer refund;

    @ApiModelProperty(value = "下单时间开始", name = "createTimeStart")
    private String createTimeStart;

    @ApiModelProperty(value = "下单时间结束", name = "createTimeEnd")
    private String createTimeEnd;

    @ApiModelProperty(value = "支付时间开始", name = "paymentTimeStart")
    private String paymentTimeStart;

    @ApiModelProperty(value = "支付时间结束", name = "paymentTimeEnd")
    private String paymentTimeEnd;

    @ApiModelProperty(value = "手机号", name = "telephone")
    private String telephone;

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getPaymentType() {
        return paymentType;
    }

    public void setPaymentType(Integer paymentType) {
        this.paymentType = paymentType;
    }

    public Integer getRefund() {
        return refund;
    }

    public void setRefund(Integer refund) {
        this.refund = refund;
    }

    public String getCreateTimeStart() {
        return createTimeStart;
    }

    public void setCreateTimeStart(String createTimeStart) {
        this.createTimeStart = createTimeStart;
    }

    public String getCreateTimeEnd() {
        return createTimeEnd;
    }

    public void setCreateTimeEnd(String createTimeEnd) {
        this.createTimeEnd = createTimeEnd;
    }

    public String getPaymentTimeStart() {
        return paymentTimeStart;
    }

    public void setPaymentTimeStart(String paymentTimeStart) {
        this.paymentTimeStart = paymentTimeStart;
    }

    public String getPaymentTimeEnd() {
        return paymentTimeEnd;
    }

    public void setPaymentTimeEnd(String paymentTimeEnd) {
        this.paymentTimeEnd = paymentTimeEnd;
    }

    public String getKeyWords() {
        return keyWords;
    }

    public void setKeyWords(String keyWords) {
        this.keyWords = keyWords;
    }

    public Integer getProductType() {
        return productType;
    }

    public void setProductType(Integer productType) {
        this.productType = productType;
    }

    @Override
    public String toString() {
        return "OrderQueryDTO{" +
                "keyWords='" + keyWords + '\'' +
                ", status=" + status +
                ", productType=" + productType +
                ", paymentType=" + paymentType +
                ", refund=" + refund +
                ", createTimeStart='" + createTimeStart + '\'' +
                ", createTimeEnd='" + createTimeEnd + '\'' +
                ", paymentTimeStart='" + paymentTimeStart + '\'' +
                ", paymentTimeEnd='" + paymentTimeEnd + '\'' +
                '}';
    }
}
