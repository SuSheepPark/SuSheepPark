package com.ruida.mockservice.service.impl;

import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.ruida.mockdao.dao.MaterialVersionMapper;
import com.ruida.mockdao.model.TMaterialVersion;
import com.ruida.mockservice.service.MaterialVersionService;
import org.springframework.stereotype.Service;


@Service
public class MaterialVersionServiceImpl extends ServiceImpl<MaterialVersionMapper, TMaterialVersion> implements MaterialVersionService {

}
