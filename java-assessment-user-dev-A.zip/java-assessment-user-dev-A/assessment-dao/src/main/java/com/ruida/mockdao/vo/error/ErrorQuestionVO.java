package com.ruida.mockdao.vo.error;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.ruida.mockdao.model.ExamImage;
import com.ruida.mockdao.pojo.Choice;
import com.ruida.mockdao.vo.QuestionKnowledgeRelVO;
import lombok.Data;

import java.util.List;

/**
 * @description:
 * @author: chenjy
 * @create: 2020-10-19 11:29
 */
@Data
public class ErrorQuestionVO {

    /**
     * 试题id
     */
    private String questionId;

    /**
     * 试题名称
     */
    private String questionTitle;

    /**
     * 分析
     */
    @JsonInclude(value = JsonInclude.Include.NON_NULL)
    private String analysis;

    /**
     * 题型
     */
    private String questionTypeName;

    /**
     * 小题排序(组合题的小题有值)
     */
    private String questionSort;

    /**
     * 中间参数，转换成选项对象
     */
    @JsonIgnore
    private String stem;

    /**
     * 中间参数，用于计算答案数量(多空填空题)
     */
    @JsonIgnore
    private String answer;

    /**
     * 中间参数，转换成参考答案
     */
    @JsonIgnore
    private String tempAnswer;

    /**
     * 中间参数，转换成用户答案
     */
    @JsonIgnore
    private String examAnswer;

    /**
     * 参考答案
     */
    private List<Choice> stdAnswer;

    /**
     * 用户答案
     */
    private List<Choice> userAnswer;

    private String photograph;

    private String estimateDuration;

    private String questionAudioUrl;

    private String playCount;

    private Integer answerNum;

    /**
     * 试题状态
     */
    private Integer status;

    private List<Choice> option;

    @JsonIgnore
    private String imageId;

    private List<ExamImage> imageList;

    /**
     * 试题和知识点关联关系
     */
    @JsonInclude(value = JsonInclude.Include.NON_NULL)
    private List<QuestionKnowledgeRelVO> questionKnowledgeRelList;

    private List<ErrorQuestionVO> children;
}
