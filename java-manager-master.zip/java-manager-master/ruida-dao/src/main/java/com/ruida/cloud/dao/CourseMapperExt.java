package com.ruida.cloud.dao;


import com.ruida.cloud.model.CourseExt;
import com.ruida.cloud.model.CourseLive;

import java.util.List;
import java.util.Map;

public interface CourseMapperExt {
    int countCourseByExample(Map condition);

    List<CourseExt> selectCourseByExample(Map condition);

    List<CourseExt> listCourseByExample(Map condition);
    List<CourseLive> listCourseByLive(Map condition);

    Integer countByPublish(Map condtion);

    List<Map<String ,Object>> getCourseTeacher(Integer courseId);

    int countCourseTByExample(Map condition);

    List<CourseExt> selectCourseTByExample(Map condition);

    /**
     * 选课
     */
    List<Map<String, Object>> selectPormotionCourseByExample(Map condition);

    Map<String ,String> getTeachersByIds(String courseIds);

    Map<String ,String> getCampusByIds(String courseIds);

    List<Map<String, Object>> listValidChildCourse();

    List<Map<String, Object>> listValidCourseForDiscount();

    String listComposeAssistantTeacher(Integer courseId);

    int countPromotionCourseByExample(Map condition);

    /**
     * 引流课（公开课）
     * @return
     */
    List<Map<String, Object>> listAllDrainageCourse();
    String listAssistantTeacher(String courseId);
}