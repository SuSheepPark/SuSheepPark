/**   
 * Copyright © 2019 公司名. All rights reserved.
 * 
 * @Title: cmsContant.java 
 * @Prject: zhaowei-cms
 * @Package: com.zhaowei.cms.util 
 * @Description: TODO
 * @author: zw   
 * @date: 2019年9月20日 上午8:51:33 
 * @version: V1.0   
 */
package com.zhaowei.cms.util;

/** 
 * @ClassName: cmsContant 
 * @Description: 系统常量
 * @author: zw
 * @date: 2019年9月20日 上午8:51:33  
 */
public class CMSContant {

	public static final String ROLE_ASMIN="1";
	public static final String ROLE_USER="0";
	
}
