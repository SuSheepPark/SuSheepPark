package com.ruida.cloud.weidu.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.ruida.cloud.dao.WeiduSemesterRelMapper;
import com.ruida.cloud.model.WeiduSemesterRel;
import com.ruida.cloud.weidu.config.WeiduConfig;
import com.ruida.cloud.weidu.service.BaseVdyooService;
import com.ruida.cloud.weidu.vo.VdyooEntity;
import com.ruida.common.context.BaseContextHandle;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * @author mlzhang
 */
@Service
public class VdyootenantTermService extends BaseVdyooService {
    @Resource
    private WeiduSemesterRelMapper weiduSemesterRelMapper;

    /**
     * 创建学期（  eg：春季班 秋季班）
     * @param param
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    public boolean addTenantTerm(Map<String, Object> param) {
        VdyooEntity entity = this.vdyooFactory.post(param, WeiduConfig.addTenantTerm);
        boolean flag = false;
        if (entity.getSuccess()) {
            WeiduSemesterRel rel = new WeiduSemesterRel();
            JSONObject object = (JSONObject) JSON.toJSON(entity.getPayload());
            rel.setSemesterId(object.getInteger("pid"));
            rel.setWeiduSemesterId(object.getInteger("id"));
            rel.setUpdateTime(new Date());
            rel.setCreateBy(BaseContextHandle.getUserId());
            rel.setUpdateBy(BaseContextHandle.getUserId());
            rel.setIsdelete((byte) 0);
            rel.setUpdateTime(new Date());
            flag = weiduSemesterRelMapper.insert(rel) > 0;
        }
        return flag;
    }

    /**
     * 编辑学期
     * @param param
     * @return
     */
    public boolean editTenantTermById(Map<String ,Object> param ){
        return this.vdyooFactory.post(param, WeiduConfig.editTenantTermById).getSuccess();
    }

    /**
     *查看学期的信息
     * @param param
     * @return
     */
    public VdyooEntity findTenantTermById(Map<String ,Object> param ){
        return  this.vdyooFactory.post(param, WeiduConfig.findTenantTermById);
    }

    /**
     * 查看全部的学期信息
     * @return
     */
    public VdyooEntity findTenantTermByTenant(){
        return  this.vdyooFactory.post(WeiduConfig.findTenantTermByTenant);
    }

    /**
     * 时间段
     */
    public VdyooEntity findTimeSlotByTenant(){
        return this.vdyooFactory.post(WeiduConfig.findTimeSlotByTenant);
    }

    public int getTimeSlotId(){
        VdyooEntity entity = this.findTimeSlotByTenant();

        if( entity.getSuccess() ){
            List<Map<String, Object>> timeSlot = (List<Map<String, Object>>) entity.getPayload();
            for (Map<String, Object> map : timeSlot) {
                return (int) map.get("id");
            }
        }

        return 0;
    }
}
