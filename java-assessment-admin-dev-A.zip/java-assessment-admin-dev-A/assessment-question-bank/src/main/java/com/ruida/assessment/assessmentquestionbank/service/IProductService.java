package com.ruida.assessment.assessmentquestionbank.service;

import com.baomidou.mybatisplus.service.IService;
import com.ruida.assessment.assessmentcommon.result.BaseResult;
import com.ruida.assessment.assessmentcommon.result.PageData;
import com.ruida.assessment.assessmentcommon.result.PojoResult;
import com.ruida.assessment.assessmentquestionbank.dto.*;
import com.ruida.assessment.assessmentquestionbank.model.TProduct;
import com.ruida.assessment.assessmentquestionbank.vo.*;

import java.util.List;

/**
 * @author wy
 * @description 商品管理服务层接口
 * @date 2020/6/24
 */
public interface IProductService extends IService<TProduct> {
    /**
     * 根据productType获取商品列表
     * @param productType 0-试卷 1-套卷 2-职业兴趣问卷
     * @return
     */
    List<TProduct> getProductListByType(Integer productType);

    List<ProductVO> getFinishProductList(Integer testWay);

    /*
     *功能描述  查询商品列表
     * @param
     * @return
     */
    PageData<ProductListVo> queryProductList(ProductQueryRequest request);

    /*
     *功能描述 新增商品时查询默认商品图片
     * @param
     * @return
     */
    PojoResult queryDefaultImg();

    /*
     *功能描述  上架、下架商品
     * @param
     * @return
     */
    BaseResult updateProductStatus(ProductQueryRequest request);

    /*
     *功能描述  新增/修改商品
     * @param
     * @return
     */
    BaseResult saveProduct(ProductAddRequest request);


    /*
     *功能描述  查询个人报告模板列表
     * @param
     * @return
     */
    List<ReportTemplateVo> queryReportTemplate(Integer type);

    /*
     *功能描述  编辑时查询商品信息
     * @param
     * @return
     */
    ProductInfoVo queryProductInfo(Integer productId);

    /*
     *功能描述  退回商品
     * @param
     * @return
     */
    BaseResult rollbackProduct(ProductAddRequest request);

    /*
     *功能描述 列表提交、删除、置顶
     * @param
     * @return
     */
    BaseResult operateProductList(ProductAddRequest request);

    /**
     * 获取购买某个商品的学员id
     * @param productId
     * @return
     */
    List<Integer> getStudentIdByProduct(List<Integer> productId);

    /*
    根据商品id查询购买该商品的学员列表（废弃）
     */
    PageData<StudentInfoVo> queryProductStudentList(ProductQueryRequest request);

    /*
    根据商品id查询购买该商品的用户列表
     */
    PageData<UserVo> queryProductUserList(UserQueryRequest request);

    /*
    查询该商品已赠送学员列表（分页）（废弃）
     */
    PageData<StudentInfoVo> queryProductPresentStudentList(StudentRequest request);

    /*
    查询该商品已赠送用户列表（分页）
     */
    PageData<UserVo> queryProductPresentUserList(UserQueryRequest request);

    /*
    赠送单个商品给多个用户
     */
    BaseResult presentProductToUser(BatchOperationRequest request);

    /*
    赠送给单个用户多个商品
     */
    BaseResult presentUserProduct(BatchOperationRequest request);

    /*
    查询某用户已经拥有的（已支付/待支付,已赠送）所有商品
     */
    List<Integer> queryUserOwnProductList(Integer userId);

    /*
    查询某商品已经被拥有(已支付/待支付,已赠送)的所有用户
     */
    List<Integer> queryProductOwnedUserList(Integer productId);

    /*
    * 上架状态商品替换预售试卷为正常试卷
    * */
    BaseResult exchangePresellPaper(ExchangePresellPaperRequest request);

    /*
    赠送单个商品给全部用户
     */
    BaseResult presentProductToAllUser(UserQueryRequest request);

    /*
    通过试卷性质和测验形式查询报告类型和是否需要关联常模
    */
    List<TReportProductWayPaperTypeVO> queryReportTypeByPaperUseTypeAndProductTestWay(List<TReportProductWayPaperTypeRelDTO> tReportProductWayPaperTypeRel);

    /**
     * 商品是否被推荐
     * @param productId
     * @return
     */
    Boolean isRecommended(Integer productId);
}
