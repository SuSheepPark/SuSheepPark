package com.ruida.assessment.assessmentcommon.enums;

/**
 * @author xumingqi
 * @date 2021/2/22 17:29
 */
public enum ImageBannerTypeEnum {
    SUBJECT_SELECT(0, "科目选考封面"),
    HOLLAND(1, "霍兰德测试封面"),
    WISH_FILLING_HEAD(2, "志愿填报头部宣传图"),
    WISH_FILLING_SCORE(3, "志愿填报分数侧宣传图");

    private Integer K;
    private String V;

    ImageBannerTypeEnum(Integer k, String v) {
        K = k;
        V = v;
    }

    public Integer getK() {
        return K;
    }

    public void setK(Integer k) {
        K = k;
    }

    public String getV() {
        return V;
    }

    public void setV(String v) {
        V = v;
    }
}
