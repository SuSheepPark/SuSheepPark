package com.ruida.assessment.assessmentquestionbank.service;

import com.ruida.assessment.assessmentquestionbank.dto.ReportDTO;
import com.ruida.assessment.assessmentquestionbank.vo.*;
import org.apache.poi.xwpf.usermodel.XWPFDocument;

import java.util.List;
import java.util.Map;

/**
 * @description: 班级测试报告 业务层接口
 * @author: kgz
 * @date: 2020/10/19
 */
public interface ClassReportService {

    /**
     * 查询本校班级考试得分整体情况
     * @param reportDTO
     * @return
     */
	List<ClassReportVO> getClassScoreInfo(ReportDTO reportDTO, Map<String, Object> cache);

    /**
     * 查询本校班级得分分布情况
     * @param reportDTO
     * @return
     */
    Map<Integer, Map<String, Integer>> getClassScoreDistribution(ReportDTO reportDTO);

    /**
     * 查询试题得分情况
     * @param reportDTO
     * @return
     */
    List<QuestionScoreVO> getQuestionScoreInfo(ReportDTO reportDTO,Map<String, Object> cache);

    /**
     * 选择题选项分析情况
     * @param reportDTO
     * @return
     */
    ChoiceQuestionVO  getChoiceQuestionAnalysis(ReportDTO reportDTO);

    /**
     * 知识点掌握情况统计
     * @param reportDTO
     * @return
     */
    ReportKnowledgeVO getKnowledgeStatistics(ReportDTO reportDTO, Map<String, Object> cache);

    /**
     * 考察目标统计
     * @param reportDTO
     * @return
     */
    ReportTargetVO getTargetStatistics(ReportDTO reportDTO, Map<String, Object> cache);

    /**
     * 生成班级报告
     * @param productId
     * @param testpaperId
     * @param schoolId
     * @param classId
     * @param cache 
     * @return
     */
	XWPFDocument getReportDocument(Integer testpaperId,Integer productId, Integer schoolId, Integer classId,
			Integer constRangeId, Map<String, Object> cache);
}
