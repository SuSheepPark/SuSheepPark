package com.ruida.mockservice.service.impl;


import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.ruida.mockcommon.exception.CoreException;
import com.ruida.mockcommon.util.ValidateMT;
import com.ruida.mockdao.dao.BottomUrlMapper;
import com.ruida.mockdao.model.BottomUrl;
import com.ruida.mockservice.service.BottomUrlService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * <p>
 * PC端底部网站链接表 服务实现类
 * </p>
 *
 * @author Bhj
 * @since 2020-08-07
 */
@Service
public class BottomUrlServiceImpl extends ServiceImpl<BottomUrlMapper, BottomUrl> implements BottomUrlService {

    @Resource
    BottomUrlMapper bottomUrlMapper;
    @Override
    public List<BottomUrl> listBottomUrl(Integer column) {
        EntityWrapper<BottomUrl> entityWrapper=new EntityWrapper<>();
        entityWrapper.eq("isdelete",0)
                .eq("status",1)
                .eq("bottom_column",column)
                .orderBy("sort");
        List<BottomUrl> list=bottomUrlMapper.selectList(entityWrapper);
        return list;
    }

    @Override
    public BottomUrl getBottomUrl(Integer bottomUrlId) {
        BottomUrl bottomUrl=bottomUrlMapper.selectById(bottomUrlId);
        if(ValidateMT.isNull(bottomUrl)){
            throw new CoreException("500","网站信息不存在");
        }
        return bottomUrl;
    }
}
