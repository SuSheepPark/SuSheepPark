package com.ruida.assessment.assessmentquestionbank.imports.domain.model;

import java.util.ArrayList;
import java.util.List;

public class QuestionKnowledge {

	private List<QuestionKnowledgeItem> items;

	public List<QuestionKnowledgeItem> getItems() {
		return items;
	}

	public void setItems(List<QuestionKnowledgeItem> items) {
		this.items = items;
	}

	public void addItem(QuestionKnowledgeItem item) {
		if (this.items == null) {
			this.items = new ArrayList<QuestionKnowledgeItem>();
		}
		items.add(item);
	}
}
