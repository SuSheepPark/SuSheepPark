package com.ruida.mockdao.model;

import com.baomidou.mybatisplus.enums.IdType;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.Date;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableName;
import java.io.Serializable;

/**
 * <p>
 * 首页资讯文章列表
 * </p>
 *
 * @author wy
 * @since 2021-08-16
 */
@TableName("t_information_column_content")
public class TInformationColumnContent extends Model<TInformationColumnContent> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;
    /**
     * 所属栏目id
     */
    private Integer columnId;
    /**
     * 标题
     */
    private String title;
    /**
     * 副标题
     */
    @TableField("second_title")
    @JsonIgnore
    private String secondTitle;
    /**
     * 文章来源
     */
    private String source;
    /**
     * web端封面图url
     */
    @TableField("web_img_url")
    private String webImgUrl;
    /**
     * 小程序封面图url
     */
    @TableField("applet_img_url")
    private String appletImgUrl;
    /**
     * 文章内容 html文件url
     */
    private String content;
    /**
     * 状态，0-下架，1-上架
     */
    @JsonIgnore
    private Integer status;
    /**
     * 上架时间
     */
    @TableField("up_time")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date upTime;
    /**
     * 下架时间
     */
    @TableField("down_time")
    @JsonIgnore
    private Date downTime;
    @TableField("create_by")
    @JsonIgnore
    private Integer createBy;
    @TableField("create_time")
    @JsonIgnore
    private Date createTime;
    @TableField("update_by")
    @JsonIgnore
    private Integer updateBy;
    @TableField("update_time")
    @JsonIgnore
    private Date updateTime;
    @JsonIgnore
    private Integer isdelete;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getColumnId() {
        return columnId;
    }

    public void setColumnId(Integer columnId) {
        this.columnId = columnId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getSecondTitle() {
        return secondTitle;
    }

    public void setSecondTitle(String secondTitle) {
        this.secondTitle = secondTitle;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getWebImgUrl() {
        return webImgUrl;
    }

    public void setWebImgUrl(String webImgUrl) {
        this.webImgUrl = webImgUrl;
    }

    public String getAppletImgUrl() {
        return appletImgUrl;
    }

    public void setAppletImgUrl(String appletImgUrl) {
        this.appletImgUrl = appletImgUrl;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Date getUpTime() {
        return upTime;
    }

    public void setUpTime(Date upTime) {
        this.upTime = upTime;
    }

    public Date getDownTime() {
        return downTime;
    }

    public void setDownTime(Date downTime) {
        this.downTime = downTime;
    }

    public Integer getCreateBy() {
        return createBy;
    }

    public void setCreateBy(Integer createBy) {
        this.createBy = createBy;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(Integer updateBy) {
        this.updateBy = updateBy;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getIsdelete() {
        return isdelete;
    }

    public void setIsdelete(Integer isdelete) {
        this.isdelete = isdelete;
    }

    @Override
    protected Serializable pkVal() {
        return this.id;
    }

    @Override
    public String toString() {
        return "TInformationColumnContent{" +
        ", id=" + id +
        ", title=" + title +
        ", secondTitle=" + secondTitle +
        ", source=" + source +
        ", webImgUrl=" + webImgUrl +
        ", appletImgUrl=" + appletImgUrl +
        ", content=" + content +
        ", status=" + status +
        ", upTime=" + upTime +
        ", downTime=" + downTime +
        ", createBy=" + createBy +
        ", createTime=" + createTime +
        ", updateBy=" + updateBy +
        ", updateTime=" + updateTime +
        ", isdelete=" + isdelete +
        "}";
    }
}
