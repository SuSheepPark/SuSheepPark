package com.ruida.mockservice.service;


import com.baomidou.mybatisplus.service.IService;
import com.ruida.mockcommon.result.*;
import com.ruida.mockdao.model.SysUserStudyCoin;

import java.math.BigDecimal;
import java.util.Map;

/**
 * <p>
 * IOS用户学币表 服务类
 * </p>
 *
 * @author Bhj
 * @since 2020-07-29
 */
public interface SysUserStudyCoinService extends IService<SysUserStudyCoin> {

    PojoResult<BigDecimal> getStudyCoin();

    BaseResult reduceStudyCoin(String orderNo);

    ListResult<Map<String, Object>> listStudyCoinPrice();

    PageResult<Map<String, Object>> listStudyCoinRecord(Page<Map<String, Object>> recordPage);
}
