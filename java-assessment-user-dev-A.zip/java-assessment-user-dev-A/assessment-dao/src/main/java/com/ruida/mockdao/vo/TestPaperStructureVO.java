package com.ruida.mockdao.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ruida.mockdao.model.ExamNotice;
import lombok.Data;

import java.util.Date;
import java.util.List;

/**
 * @description: 试卷结构
 * @author: chenjy
 * @create: 2020-08-03 11:54
 */
@Data
public class TestPaperStructureVO {

    /**
     * 试卷名称
     */
    private String testPaperName;

    /**
     * 题目总量
     */
    private Integer totalAmount;

    /**
     * 考试时长（单位：分钟）
     */
    private Integer testDuration;

    /**
     * 考试方式（0-练习 1-纸考 2-机房考 3-统考）
     */
    private Integer testWay;

    /**
     * 考试开始时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",locale = "zh",timezone = "GMT+8")
    private Date testStartTime;

    /**
     * 考试结束时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",locale = "zh",timezone = "GMT+8")
    private Date testEndTime;

    /**
     * 系统时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",locale = "zh",timezone = "GMT+8")
    private Date systemTime;

    /**
     * 注意事项
     */
    private List<ExamNotice> noticeList;

    /**
     * 题型信息
     */
    private List<QuestionTypeVO> questionTypeList;
}

