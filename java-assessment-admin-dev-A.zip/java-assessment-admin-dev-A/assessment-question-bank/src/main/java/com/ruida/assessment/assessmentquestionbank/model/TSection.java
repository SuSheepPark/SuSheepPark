package com.ruida.assessment.assessmentquestionbank.model;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;


/**
 * @author wy
 * @description  章节数据库实体类
 * @date 2020/6/10
 */
@Data
@ApiModel(description = "章节数据库实体")
@TableName("t_section")
public class TSection extends BaseColumn implements Serializable {

    private static final long serialVersionUID = -8789145755431701463L;
    @TableId
    @ApiModelProperty(value = "章节id", name = "sectionId", required = false)
    private Integer sectionId;

    @ApiModelProperty(value = "章节名称", name = "sectionName", required = true)
    private String sectionName;

    @ApiModelProperty(value = "父级id", name = "pid", required = true)
    private Integer pid;

    @ApiModelProperty(value = "排序值", name = "sort", required = true)
    private Integer sort;

    @ApiModelProperty(value = "教材id", name = "materialId", required = true)
    private Integer materialId;

    @ApiModelProperty(value = "状态 0—禁用；1—启用", name = "status", required = true)
    private Integer status;
}
