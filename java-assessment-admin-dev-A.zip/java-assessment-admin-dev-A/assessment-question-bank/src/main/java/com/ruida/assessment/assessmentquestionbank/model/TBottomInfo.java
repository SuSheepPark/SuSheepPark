package com.ruida.assessment.assessmentquestionbank.model;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import io.swagger.annotations.ApiModel;
import lombok.Data;

import java.io.Serializable;

/**
 * @author wy
 * @description 网站信息数据库实体类
 * @date 2020/7/31
 */
@Data
@ApiModel(description = "网站信息数据库实体")
@TableName("t_bottom_info")
public class TBottomInfo extends BaseColumn implements Serializable {


    private static final long serialVersionUID = 1331539272153046929L;

    /**
     * 主键ID
     */
    @TableId
    private Integer id;

    /*
    网站title
     */
    private String websiteTitle;

    private String appname;

    private String slogan;

    /*
    运营机构
     */
    private String operatingAgency;

    private String websiteAuthor;

    private String websiteKeyword;

    private String websiteDescription;

    private String email;

    private String telephone;

    private String workTime;

    /*
    版权以及备案号（网站底部）
     */
    private String version;


}
