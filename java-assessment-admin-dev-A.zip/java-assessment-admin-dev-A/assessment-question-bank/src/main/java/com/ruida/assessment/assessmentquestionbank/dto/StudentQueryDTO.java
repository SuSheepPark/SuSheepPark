package com.ruida.assessment.assessmentquestionbank.dto;

import com.ruida.assessment.assessmentcommon.result.Page;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

@Data
@ApiModel(description = "学员查询条件")
public class StudentQueryDTO {

    /* 地区id */
    @ApiModelProperty(value = "地区id", name = "parentId")
    private Integer parentId;

    /* 学校类型 */
    @ApiModelProperty(value = "学校类型", name = "periodId")
    private Integer periodId;

    /* 学校id */
    @ApiModelProperty(value = "学校id", name = "schoolId")
    private Integer schoolId;

    /* 年级id */
    @ApiModelProperty(value = "年级id", name = "gradeId")
    private Integer gradeId;

    /* 班级id */
    @ApiModelProperty(value = "班级id", name = "classId")
    private Integer classId;

    /* 是否禁用 */
    @ApiModelProperty(value = "是否禁用", name = "status")
    private Integer status;

    @ApiModelProperty(value = "注册时间-开始时间", name = "startTime")
    private String startTime;

    @ApiModelProperty(value = "注册时间-结束时间", name = "endTime")
    private String endTime;

    /* 模糊查询字段  姓名/账号/联系方式/学 号 */
    @ApiModelProperty(value = "模糊查询字段", name = "searchWord")
    private String searchWord;

    /* 用户id集合 */
    @ApiModelProperty(value = "用户id集合", name = "userIds")
    List<Integer> userIds;

    @ApiModelProperty(value = "注册来源", name = "startTime")
    private Integer sourceChannel;

    @ApiModelProperty(value = "最后登录时间-开始时间", name = "loginTimeStart")
    private String loginTimeStart;

    @ApiModelProperty(value = "最后登录时间-结束时间", name = "loginTimeEnd")
    private String loginTimeEnd;

    @ApiModelProperty(value = "手机号-用于查询", name = "telephone")
    private String telephone;

    @ApiModelProperty(value = "身份证号-用于查询", name = "idCard")
    private String idCard;


    /* 分页 */
    private Page page;
    private Integer start;
    private Integer size;

}
