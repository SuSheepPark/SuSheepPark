package com.ruida.assessment.assessmentcommon.enums;

import lombok.Getter;

/**
 * Created by xumingqi on 2021/8/16 10:06
 */
@Getter
public enum RotationChartLocationTypeEnum {
    INDEX_BANNER(1, "首页banner", "此位置为web和小程序首页广告图的配置");

    private final Integer id;
    private final String name;
    private final String desc;

    RotationChartLocationTypeEnum(Integer id, String name, String desc) {
        this.id = id;
        this.name = name;
        this.desc = desc;
    }

    public static String getValueById(Integer id) {
        for (RotationChartLocationTypeEnum typeEnum : RotationChartLocationTypeEnum.values()) {
            if (typeEnum.getId().equals(id)) {
                return typeEnum.getName();
            }
        }
        return null;
    }
}
