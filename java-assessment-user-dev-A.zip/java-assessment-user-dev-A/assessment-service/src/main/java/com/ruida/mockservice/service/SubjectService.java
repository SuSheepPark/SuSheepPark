package com.ruida.mockservice.service;

import com.baomidou.mybatisplus.service.IService;
import com.ruida.mockdao.model.Subject;

/**
 * Created by xumingqi on 2021/7/1 13:16
 */
public interface SubjectService extends IService<Subject> {

}
