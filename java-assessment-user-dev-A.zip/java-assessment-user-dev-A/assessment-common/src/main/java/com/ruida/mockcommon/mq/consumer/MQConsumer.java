package com.ruida.mockcommon.mq.consumer;



import com.aliyun.openservices.shade.com.alibaba.rocketmq.common.protocol.heartbeat.MessageModel;

import java.lang.annotation.*;


/**
 * Created by jinhu on 2020/8/11.
 * topic cid 必填
 */
@Target(ElementType.TYPE)
@Documented
@Retention(RetentionPolicy.RUNTIME)
public @interface MQConsumer {
    String consumer();

    String topic();

    String tags() default "*";

    MessageModel messageModel() default MessageModel.CLUSTERING;
}
