package com.ruida.assessment.assessmentquestionbank.ruidacloudDao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.assessment.assessmentquestionbank.dto.UserQueryRequest;
import com.ruida.assessment.assessmentquestionbank.model.SysUser;
import com.ruida.assessment.assessmentquestionbank.vo.UserVo;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * 用户表 Mapper 接口
 * </p>
 *
 * @author mlzhang
 * @since 2019-02-28
 */
public interface SysUserMapper extends BaseMapper<SysUser> {
//     @Insert("")
//     @Options(useGeneratedKeys=true, keyProperty="userId", keyColumn="user_id")
     void insertSysUser(SysUser sysUser);
      Map<String ,Object> selectUserInfo(@Param("userId") String user_id) ;
     @Update("update sys_user  set user_password =#{password} where user_id = #{userId}")
     Integer updatePassword(@Param("userId") String userId, @Param("password") String password);
     @Update("update sys_user  set user_password =#{password} where telephone = #{telephone}")
     Integer updatePasswordByfind(@Param("password") String password, @Param("telephone") String telephone);

    /* @Select("select count(*) from t_course_purchase where  purchaser_id = #{userId}")
     Integer getuserByCourse(@Param("userId") Integer userId);*/
     List<SysUser> getUserList(Map param);

     @Select("SELECT\n" +
             "\ta.*, role.role_name AS roleName,\n" +
             "\tCASE\n" +
             "WHEN FIND_IN_SET(2, role.role_type)\n" +
             "AND c.teacher_type = 0 THEN\n" +
             "\t'主讲老师'\n" +
             "WHEN FIND_IN_SET(2, role.role_type)\n" +
             "AND c.teacher_type = 0\n" +
             "AND c.assistant_teacher_type = 0 THEN\n" +
             "\t'校区助教'\n" +
             "WHEN FIND_IN_SET(2, role.role_type)\n" +
             "AND c.teacher_type = 0\n" +
             "AND c.assistant_teacher_type = 1 THEN\n" +
             "\t'总部助教'\n" +
             "ELSE\n" +
             "\trole.role_type\n" +
             "END AS roleType\n" +
             "FROM\n" +
             "\t(\n" +
             "\t\tSELECT\n" +
             "\t\t\ta.user_id,\n" +
             "\t\t\tGROUP_CONCAT(b.role_type) AS role_type,\n" +
             "\t\t\tGROUP_CONCAT(b.role_name) AS role_name\n" +
             "\t\tFROM\n" +
             "\t\t\tsys_user_role a\n" +
             "\t\tLEFT JOIN sys_role b ON a.role_id = b.role_id\n" +
             "\t\tWHERE\n" +
             "\t\t\tb.isdelete = 0\n" +
             "\t\tAND b.role_type != 3\n" +
             "\t\tAND b.role_type != 4\n" +
             "\t\tGROUP BY\n" +
             "\t\t\ta.user_id\n" +
             "\t) role\n" +
             "LEFT JOIN sys_user a ON a.user_id = b.role.user_id\n" +
             "LEFT JOIN t_teacher c ON a.user_id = c.user_id\n" +
             "WHERE\n" +
             "\ta.isdelete = 0\n" +
             "AND (\n" +
             "\ta.user_name = #{username} \n" +
             "\tOR a.telephone = #{username} \n" +
             ")")
     Map<String,Object> getUserInfo(@Param("username") String username);

     @Select("SELECT real_name FROM sys_user where user_id=#{userId} and isdelete=0")
     String getUserNameById(@Param("userId")Integer bindAccount);

     @Select("SELECT\n" +
             "  c.user_id as userId,\n" +
             "  c.real_name as realName,\n" +
             "  c.telephone\n" +
             "FROM\n" +
             "  sys_role a\n" +
             "LEFT JOIN sys_user_role b ON a.role_id = b.role_id\n" +
             "LEFT JOIN sys_user c ON b.user_id = c.user_id\n" +
             "AND c.isdelete = 0\n" +
             "LEFT JOIN t_distributor d ON c.user_id = d.bind_account\n" +
             "WHERE\n" +
             "  a.role_name = #{roleName}\n" +
             "AND d.bind_account IS NULL")
     List<Map<String, Object>> getUserInfoByRoleName(@Param("roleName")String roleName);

     @Select("SELECT\n" +
             "  c.user_id as userId,\n" +
             "  c.real_name as realName,\n" +
             "  c.telephone\n" +
             "FROM\n" +
             "  sys_user c\n" +
             "LEFT JOIN t_distributor d ON c.user_id = d.bind_account\n" +
             "WHERE\n" +
             "  c.isdelete=0 And d.distributor_id=#{id}")
     Map<String, Object> getUserInfoById(@Param("id") Integer id);

     Integer getUserInfoByUserId(@Param("userId") Integer userId);

    /**
     * 获取老师列表
     * @return
     */
     List<Map<String,Object>> getTeacherUserList();
     @Select("SELECT\n" +
             "a.real_name as realName,\n" +
             "a.telephone,\n" +
             " b.role_id as roleId,\n" +
             "c.role_name as roleName,\n" +
             " DATE_FORMAT(b.deadline,'%Y-%m-%d %H:%i:%s') as deadline ,\n" +
             "g.department_name as departmentName,\n" +
             "GROUP_CONCAT( DISTINCT CONCAT(f.period_name,e.subject_name)) AS subjectInfo\n" +
             "FROM\n" +
             "\tsys_user a\n" +
             "LEFT JOIN sys_user_role b ON a.user_id = b.user_id\n" +
             "LEFT JOIN t_user_period_subject d ON  d.user_id = a.user_id AND d.role_id = b.role_id\n" +
             "LEFT JOIN t_department g ON b.department_id = g.department_id\n" +
             "LEFT JOIN sys_role c ON c.role_id = b.role_id\n" +
             "LEFT JOIN t_subject e ON e.id = d.subject_id\n" +
             "LEFT JOIN t_period f ON f.id = d.period_id\n" +
             "WHERE a.user_id = #{userId}\n" +
             "GROUP BY  b.role_id")
     List<Map<String,Object>> listUserRoleInfo(@Param("userId") Integer userId);
     @Select("SELECT\n" +
             "\ta.user_id AS userId,\n" +
             "\ta.user_name AS userName, a.real_name as realName,\n" +
             "\ta.telephone,\n" +
             "\tc.security_level_name AS securityLevelName\n" +
             "FROM\n" +
             "\tsys_user a\n" +
             "LEFT JOIN t_user_security_level_rel b ON a.user_id = b.user_id\n" +
             "LEFT JOIN t_security_level c ON c.id = b.security_level\n" +
             "WHERE\n" +
             "\ta.isdelete = 0\n" +
             "AND a.`status` = 1 AND a.user_id = #{userId} GROUP BY b.user_id")
     Map<String,Object> getUserDetailInfo(@Param("userId") Integer userId);

     /*
     条件查询用户列表
      */
    List<UserVo> queryUserList(@Param("dto") UserQueryRequest request);

    /*
    查询满足条件用户数
     */
    Integer countUserList(@Param("dto") UserQueryRequest request);

    /*
    条件查询满足条件的购买该商品的用户列表
     */
    List<UserVo> queryBuyProductUserList(@Param("dto") UserQueryRequest request);

    /*
    查询满足条件的购买该商品的用户数
     */
    Integer queryBuyProductUserCount(@Param("dto") UserQueryRequest request);


}
