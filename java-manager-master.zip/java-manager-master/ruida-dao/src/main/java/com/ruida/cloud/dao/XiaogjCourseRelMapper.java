package com.ruida.cloud.dao;

import com.ruida.cloud.model.XiaogjCourseRel;
import com.ruida.cloud.model.XiaogjCourseRelExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface XiaogjCourseRelMapper {
    int countByExample(XiaogjCourseRelExample example);

    int deleteByExample(XiaogjCourseRelExample example);

    int deleteByPrimaryKey(Integer rid);

    int insert(XiaogjCourseRel record);

    int insertSelective(XiaogjCourseRel record);

    List<XiaogjCourseRel> selectByExample(XiaogjCourseRelExample example);

    XiaogjCourseRel selectByPrimaryKey(Integer rid);

    int updateByExampleSelective(@Param("record") XiaogjCourseRel record, @Param("example") XiaogjCourseRelExample example);

    int updateByExample(@Param("record") XiaogjCourseRel record, @Param("example") XiaogjCourseRelExample example);

    int updateByPrimaryKeySelective(XiaogjCourseRel record);

    int updateByPrimaryKey(XiaogjCourseRel record);
}