package com.ruida.mockservice.service;


import com.baomidou.mybatisplus.service.IService;
import com.ruida.mockcommon.result.Page;
import com.ruida.mockdao.model.SchemaReport;
import com.ruida.mockdao.vo.report.SchemaReportListVO;
import com.ruida.mockservice.vo.SchemaReportVO;

import javax.validation.constraints.NotNull;

/**
 * <p>
 * 选科方案报告 服务类
 * </p>
 *
 * @author chenjy
 * @since 2021-02-23
 */
public interface SchemaReportService extends IService<SchemaReport> {

    /**
     * 是否有选科方案报告
     *
     * @param userId
     * @return
     */
    Boolean checkHaveSchemaReport(Integer userId);

    SchemaReport getReportByOrderNo(String orderNo);

    Page<SchemaReportListVO> getReportList(Integer userId, Integer currentPage, Integer pageSize);

    /**
     * 生成选科方案前状态检查
     *
     * @param userId
     * @return true：有变化，false：无变化
     */
    Boolean checkBeforeGenSchema(@NotNull Integer userId);

    /**
     * 保存选科方案报告
     * @param userId 用户id
     * @param orderNo 订单id
     * @param type 类型(1-推荐；2-自选)
     * @param subject 推荐科目
     * @return
     */
    Integer saveSchemaReport(@NotNull Integer userId, @NotNull String orderNo, @NotNull Integer type, String subject);

    /**
     * 获取选科方案报告
     * @param userId 用户id
     * @param schemaReportId 报告id
     * @return
     */
    SchemaReportVO getSchemaReportInfo(@NotNull Integer userId, @NotNull Integer schemaReportId);
}
