package com.ruida.cloud.dao;

import com.ruida.cloud.model.TAppVersion;
import com.ruida.cloud.model.TAppVersionExample;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;
import java.util.Map;

public interface TAppVersionMapper {
    long countByExample(TAppVersionExample example);

    int deleteByExample(TAppVersionExample example);

    int deleteByPrimaryKey(Integer appVersionId);

    int insert(TAppVersion record);

    int insertSelective(TAppVersion record);

    List<TAppVersion> selectByExample(TAppVersionExample example);

    TAppVersion selectByPrimaryKey(Integer appVersionId);

    int updateByExampleSelective(@Param("record") TAppVersion record, @Param("example") TAppVersionExample example);

    int updateByExample(@Param("record") TAppVersion record, @Param("example") TAppVersionExample example);

    int updateByPrimaryKeySelective(TAppVersion record);

    int updateByPrimaryKey(TAppVersion record);

    @Select("SELECT\n" +
            "\tapp_version_id AS appVersionId,\n" +
            "\ttype,\n" +
            "\tversion_code AS versionCode,\n" +
            "  version,\n" +
            "  url,\n" +
            "  file_name AS fileName,\n" +
            "  isupdate,\n" +
            "  remark\n" +
            "FROM\n" +
            "\tt_app_version\n" +
            "WHERE\n" +
            "\tisdelete = 0 ORDER BY create_time desc LIMIT #{pageIndex} ,#{pageSize} ")
    List<Map<String, Object>> list(@Param("pageSize") Integer pageSize, @Param("pageIndex") Integer pageIndex);

    @Select("select count(*) from t_app_version where isdelete = 0 ")
    Integer count();

    @Update("update  t_app_version set isdelete = 1 where app_version_id =#{id} ")
    Integer delete(@Param("id") Integer id);
}