package com.ruida.mockdao.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.dto.ExamRecordDTO;
import com.ruida.mockdao.model.ExamRecord;
import com.ruida.mockdao.vo.ExamRecordVO;
import com.ruida.mockdao.vo.MyTestPaperExamRecordVO;
import com.ruida.mockdao.vo.QueryScoreProductVO;
import com.ruida.mockdao.vo.report.UnionExamRecordVO;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 考试记录表 Mapper 接口
 * </p>
 *
 * @author chenjy
 * @since 2020-07-15
 */
public interface ExamRecordMapper extends BaseMapper<ExamRecord> {

    ExamRecordVO queryLatestExamInfo(@Param("userId") String userId,@Param("testWayArray")Integer[] testWayArray);

    Integer countExamTimes(@Param("sceneId") String sceneId, @Param("stuId") String stuId);

    /*
     * 目前是第几次考试
     */
    Integer countNowTimes(@Param("sceneId") String sceneId, @Param("stuId") Integer stuId);

    /**
     * 根据场次和考生查询未提交的统考试卷
     * @param sceneId
     * @param studentId
     * @return
     */
    ExamRecord selectUnSubmitExam(@Param("sceneId") String sceneId,@Param("studentId") Integer studentId);

    List<QueryScoreProductVO> queryScore(@Param("userId")Integer userId, @Param("offset")Integer offset,@Param("pageSize")Integer pageSize);
    Integer queryScoreCount(@Param("userId")Integer userId);

    /**
     * 查询9+1考试记录
     * @param userId
     * @param testWays
     * @return
     */
    List<ExamRecordDTO> queryNineOne(@Param("userId") Integer userId,@Param("list") List<Integer> testWays);

    /**
     * 查询9+1考试
     * @param userId
     * @return
     */
    List<ExamRecordDTO> queryNineOneExam(Integer userId);

    List<UnionExamRecordVO> queryUnionExamRecord(@Param("productId") Integer productId,@Param("testPaperId") Integer testPaperId);

    /*
    查询商品试卷考试次数列表
     */
    List<MyTestPaperExamRecordVO> queryMyTestPaperExamRecord(@Param("productId")Integer productId, @Param("testPaperId")Integer testPaperId, @Param("userId")Integer userId);
}
