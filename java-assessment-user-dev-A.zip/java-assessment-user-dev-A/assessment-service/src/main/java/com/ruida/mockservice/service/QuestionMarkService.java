package com.ruida.mockservice.service;

import com.baomidou.mybatisplus.service.IService;
import com.ruida.mockcommon.result.Page;
import com.ruida.mockdao.dto.PersonCenterDTO;
import com.ruida.mockdao.model.QuestionMark;
import com.ruida.mockdao.vo.QuestionVO;

import java.util.Map;

/**
 * <p>
 * 试题标记表 服务类
 * </p>
 *
 * @author chenjy
 * @since 2020-07-09
 */
public interface QuestionMarkService extends IService<QuestionMark> {

    /**
     * 标记/取消标记试题
     * @param testPaperId 试卷id
     * @param questionId  试题id
     * @param type        操作类型(0-标记；1-取消标记)
     * @return
     */
    boolean markQuestion(Integer testPaperId,String questionId,Integer type);

    /**
     * 按科目分类标记的试题
     * @param gradeId
     * @return
     */
    Map<String,Object> listSubjectMarks(Integer gradeId);

    boolean deleteMarkedQuestion(String questionIds);

    /**
     * 分页查询标记的试题
     * @param page
     * @param req
     * @return
     */
    Page<QuestionVO> listMarkedQuestion(Page page, PersonCenterDTO req);

    /**
     * 查询标记试题详情
     * @param questionId
     * @return
     */
    QuestionVO getMarkedQuestionDetail(String questionId);

}
