package com.ruida.mockdao.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.model.SchemaReport;

/**
 * <p>
 * 选科方案报告 Mapper 接口
 * </p>
 *
 * @author chenjy
 * @since 2021-02-23
 */
public interface SchemaReportMapper extends BaseMapper<SchemaReport> {

}
