package com.ruida.mockdao.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.model.QuestionKnowledgeRelation;

/**
 * <p>
 * 试题知识点关系表 Mapper 接口
 * </p>
 *
 * @author chenjy
 * @since 2020-08-11
 */
public interface QuestionKnowledgeRelationMapper extends BaseMapper<QuestionKnowledgeRelation> {

}
