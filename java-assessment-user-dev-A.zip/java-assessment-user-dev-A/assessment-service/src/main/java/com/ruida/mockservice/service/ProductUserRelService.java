package com.ruida.mockservice.service;

import com.baomidou.mybatisplus.service.IService;
import com.ruida.mockdao.model.ProductUserRel;
import com.ruida.mockdao.model.TestPaperProductRel;

import java.util.List;

/**
 * <p>
 * 用户商品关联表 服务类
 * </p>
 *
 * @author jinhu
 * @since 2020-07-14
 */
public interface ProductUserRelService extends IService<ProductUserRel> {
    boolean saveProductAndPaperRelation(Integer userId, Integer stuId, Integer productId,
                                        List<Integer> testPaperIdList, List<Integer> presellTestPaperIdList,
                                        List<Integer> reportIdList, List<Integer> presellReportIdList, List<TestPaperProductRel> relList);
}
