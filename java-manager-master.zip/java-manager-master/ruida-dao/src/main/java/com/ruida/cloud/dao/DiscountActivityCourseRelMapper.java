package com.ruida.cloud.dao;

import com.ruida.cloud.model.DiscountActivityCourseRel;
import com.ruida.cloud.model.DiscountActivityCourseRelExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface DiscountActivityCourseRelMapper {
    long countByExample(DiscountActivityCourseRelExample example);

    int deleteByExample(DiscountActivityCourseRelExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(DiscountActivityCourseRel record);

    int insertSelective(DiscountActivityCourseRel record);

    List<DiscountActivityCourseRel> selectByExample(DiscountActivityCourseRelExample example);

    DiscountActivityCourseRel selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") DiscountActivityCourseRel record, @Param("example") DiscountActivityCourseRelExample example);

    int updateByExample(@Param("record") DiscountActivityCourseRel record, @Param("example") DiscountActivityCourseRelExample example);

    int updateByPrimaryKeySelective(DiscountActivityCourseRel record);

    int updateByPrimaryKey(DiscountActivityCourseRel record);
}