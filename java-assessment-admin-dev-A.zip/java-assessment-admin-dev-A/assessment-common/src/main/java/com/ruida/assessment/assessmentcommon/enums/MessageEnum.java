package com.ruida.assessment.assessmentcommon.enums;

public enum MessageEnum {

    FIND_PWD("1", "find", "找回密码"),
    REGISRER_USER("2", "register", "用户注册"),
    BIND_MOBILE("3", "bind", "账户绑定");

    MessageEnum(String typeCode, String type, String typeDesc) {
        this.typeCode = typeCode;
        this.type = type;
        this.typeDesc = typeDesc;
    }

    private String typeCode;
    private String type;
    private String typeDesc;


    public static String getMsgtypeBycode(String typeCode) {
        MessageEnum messageEnum[] = MessageEnum.values();

        for (MessageEnum msg : messageEnum) {
            if (msg.getTypeCode().equals(typeCode)) {
                return msg.getType();
            }
        }
        return null;
    }


    public String getTypeCode() {
        return typeCode;
    }

    public void setTypeCode(String typeCode) {
        this.typeCode = typeCode;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getTypeDesc() {
        return typeDesc;
    }

    public void setTypeDesc(String typeDesc) {
        this.typeDesc = typeDesc;
    }
}
