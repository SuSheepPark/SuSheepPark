package com.ruida.mockcommon.enums;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * 订单状态枚举
 */
public enum OrderStatusEnum {

    WAITING(0, "待支付"),
    PAID(1, "已支付"),
    CLOSED(2, "已取消"),
    TBC(3, "待确认"),
    REFUNDING(4, "退费中"),
    REFUNDED(5, "已退费");

    public static final String SOURCE_KEY = "Bool";
    private Integer k;
    private String v;

    OrderStatusEnum(Integer k, String v) {
        this.k = k;
        this.v = v;
    }

    public static Map<Integer,String> map = new LinkedHashMap<>(2);
    static
    {
        for(OrderStatusEnum type : OrderStatusEnum.values())
        {
            map.put(type.getK(),type.getV());
        }
    }

    public Integer getK() {
        return k;
    }

    public void setK(Integer k) {
        this.k = k;
    }

    public String getV() {
        return v;
    }

    public void setV(String v) {
        this.v = v;
    }

    public static OrderStatusEnum getValueById(Integer K) {
        if (K != null) {
            for (OrderStatusEnum orderStatusEnum : OrderStatusEnum.values()) {
                if (orderStatusEnum.getK().equals(K)) {
                    return orderStatusEnum;
                }
            }
        }
        return null;
    }
}
