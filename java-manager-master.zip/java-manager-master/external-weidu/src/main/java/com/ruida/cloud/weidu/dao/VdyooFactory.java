package com.ruida.cloud.weidu.dao;

import com.alibaba.fastjson.JSONObject;
import com.ruida.cloud.weidu.config.WeiduBasicInfo;
import com.ruida.cloud.weidu.exception.VdyooException;
import com.ruida.cloud.weidu.utils.HMAC_SHA1;
import com.ruida.cloud.weidu.vo.VdyooEntity;
import com.ruida.common.exception.CoreException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.map.HashedMap;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.Map;

/**
 * @author 发送请求工厂
 */
@Component("vdyooFactory")
@Slf4j
public class VdyooFactory {
    @Resource
    private RestTemplate restTemplate;
    @Resource
    private WeiduBasicInfo weiduBasicInfo;

    public VdyooEntity get(String url) {
        Map<String, Object> params = new HashedMap();
        return this.get(params, url);
    }

    public VdyooEntity get(Map<String, Object> params, String url) {
        url = weiduBasicInfo.vdyooTestApi + url;
        VdyooEntity vdyooEntity = null;

        //数据验签
        this.createSign(params);
        //参数拼接
        log.debug("weidu get params is {}", params.toString());
        //设置头部信息 ,如果没有则不需传递什么
        //发送请求
        ResponseEntity responseEntity = restTemplate.getForEntity(url, VdyooEntity.class, params);
        //获取相应参数
        this.getVdyooEntity(responseEntity, vdyooEntity);

        return vdyooEntity;
    }

    public VdyooEntity post(String url) {
        Map<String, Object> params = new HashedMap();
        return this.post(params, url);
    }

    public VdyooEntity post(Map<String, Object> params, String url) {
        url = weiduBasicInfo.vdyooTestApi + url;

        VdyooEntity vdyooEntity = null;
        //数据验签s
        this.createSign(params);
        //参数拼接

        // 封装参数，千万不要替换为Map与HashMap，否则参数无法传递
        MultiValueMap<String, String> paramMap = new LinkedMultiValueMap<String, String>();
        for (Map.Entry<String, Object> entry : params.entrySet()) {
            paramMap.add(entry.getKey(), entry.getValue().toString());
        }

        log.debug("weidu post params is {}", paramMap.toString());
        //设置头部信息 ,如果没有则不需传递什么
        HttpHeaders headers = new HttpHeaders();
        //    MediaType type = MediaType.parseMediaType("application/json;charset=UTF-8");
//            headers.setContentType(type);
        headers.setAccept(MediaType.parseMediaTypes("application/json;charset=UTF-8"));
        HttpEntity httpEntity = new HttpEntity(paramMap, headers);
        //发送请求
        ResponseEntity responseEntity = restTemplate.postForEntity(url, httpEntity, VdyooEntity.class);
        log.info("威渡数据返回:" + JSONObject.toJSONString(responseEntity));

        //获取相应参数
        VdyooEntity resultEntity = this.getVdyooEntity(responseEntity, vdyooEntity);
        if (!resultEntity.getSuccess()) {
            if(Integer.valueOf(resultEntity.getError()).equals(200808)){
                throw new CoreException(Integer.valueOf(resultEntity.getError()),"威渡教师账号已存在");
            }
            throw new CoreException(Integer.valueOf(resultEntity.getError()), resultEntity.getMessage());
        }

        return resultEntity;
    }


    private VdyooEntity getVdyooEntity(ResponseEntity responseEntity, VdyooEntity vdyooEntity) {
        if (responseEntity.getStatusCode() == HttpStatus.OK) {
            log.info("威渡response is {}", responseEntity.getBody());
            vdyooEntity = (VdyooEntity) responseEntity.getBody();
            if (vdyooEntity.getError().equals("200805")) {
                throw new CoreException(500, "老师账号已存在");
            }
        }
        return vdyooEntity;
    }

    /**
     * 数据验签
     *
     * @param params
     */
    private void createSign(Map<String, Object> params) {
        StringBuffer stringBuffer = new StringBuffer();
        long timestamp = System.currentTimeMillis();
        stringBuffer.append("appkey=")
                .append(weiduBasicInfo.vdyooAppkey)
                .append("&tenantkey=")
                .append(weiduBasicInfo.vdyooTenantkey).append("&timestamp=")
                .append(timestamp);
        String sign = HMAC_SHA1.genHMAC(stringBuffer.toString(), weiduBasicInfo.vdyooAppsecret);
        log.debug("wei do  request param sign is {}", sign);
        params.put("tenantkey", weiduBasicInfo.vdyooTenantkey);
        params.put("appkey", weiduBasicInfo.vdyooAppkey);
        params.put("sign", sign);
        params.put("timestamp", "" + timestamp);
        params.put("v", weiduBasicInfo.vdyooV);
    }

}
