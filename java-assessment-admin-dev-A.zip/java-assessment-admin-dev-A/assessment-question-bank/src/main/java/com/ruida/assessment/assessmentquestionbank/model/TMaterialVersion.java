package com.ruida.assessment.assessmentquestionbank.model;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;

import java.io.Serializable;

/**
 * @description: 教材版本数据库实体
 * @author: kgz
 * @date: 2020/6/29
 */
@TableName("t_material_version")
public class TMaterialVersion extends BaseColumn implements Serializable {
    private static final long serialVersionUID = -2986592538140184266L;

    /**
     * 教材版本id
     */
    @TableId
    private Integer id;

    /**
     * 教材版本名称
     */
    private String materialVersionName;

    /**
     * 状态（0—禁用；1—启用）
     */
    private Integer status;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getMaterialVersionName() {
        return materialVersionName;
    }

    public void setMaterialVersionName(String materialVersionName) {
        this.materialVersionName = materialVersionName;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "TMaterialVersion{" +
                "id=" + id +
                ", materialVersionName='" + materialVersionName + '\'' +
                ", status=" + status +
                super.toString() +
                '}';
    }
}
