package com.ruida.mockdao.dto;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * Created by xumingqi on 2021/8/16 17:56
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class SaveQuestionDTO extends QuestionDTO {
    private String sceneId;
    private Integer examRecordId;
    private Integer nodeId;
}
