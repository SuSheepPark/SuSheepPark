package com.ruida.assessment.assessmentcommon.util;

import org.springframework.util.CollectionUtils;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.NumberFormat;
import java.util.List;
import java.util.Locale;

/**
 * @description: 数字处理工具类
 * @author: kgz
 * @date: 2020/8/5
 */
public class NumberUtil {

    /**
     * 两个double类型的数相除及保留小数的位数
     * 四舍五入
     * @param a
     * @param b
     * @param scale
     * @return
     */
    public static double divide(double a, double b, int scale){
        if(a == 0 || b == 0){
            return new BigDecimal(0).setScale(scale).doubleValue();
        }
         BigDecimal bd1 = new BigDecimal(Double.toString(a));
         BigDecimal bd2 = new BigDecimal(Double.toString(b));
         return bd1.divide(bd2, scale, BigDecimal.ROUND_HALF_UP).doubleValue();
    }

    /**
     * double转百分数
     * @param a
     * @param scale
     * @return
     */
    public static String format(double a, int scale){
        NumberFormat nf = NumberFormat.getPercentInstance(Locale.CHINA);
        //整数部分不会每隔三个，就会有 " ,"
        nf.setGroupingUsed(false);
        // 保留两位小数
        nf.setMinimumFractionDigits(scale);
        // 如果不需要四舍五入，可以使用RoundingMode.DOWN
        nf.setRoundingMode(RoundingMode.HALF_UP);
        return nf.format(a);
    }

    /**
     * 获取两数相除的百分比结果
     * @param a
     * 被除数
     * @param b
     * 除数
     * @param scale
     * 百分数小数位数
     * @return
     */
    public static String percentDivide(double a, double b, int scale){
        if(a == 0 || b == 0){
            return format(0, scale);
        }
        double x = divide(a,b,scale+2);
        return format(x, scale);
    }

    /**
     * 标准差σ=sqrt(s^2)
     * s^2=[(x1-x)^2 +...(xn-x)^2]/n 或者s^2=[(x1-x)^2 +...(xn-x)^2]/(n-1)
     * @param x
     * @return
     */
    public static double standardDiviation(List<Double> x) {
        if(!CollectionUtils.isEmpty(x)){
            int m = x.size();
            double sum = 0;
            for (int i = 0; i < m; i++) {//求和
                sum += x.get(i);
            }
            double avg = sum / m;//求平均值
            double var = 0;
            for (int i = 0; i < m; i++) {//求方差
                var += (x.get(i) - avg) * (x.get(i) - avg);
            }
            double result = Math.sqrt(var/m);
            BigDecimal b = new BigDecimal(result);
            result = b.setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
            return result;
        }
        return 0;
    }
}
