package com.zhaowei.cms.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.zhaowei.cms.domain.User;
/**
 * 
 * @ClassName: UserMapper 
 * @Description: TODO
 * @author: zw
 * @date: 2019年9月10日 下午8:17:39
 */
public interface UserMapper {
	/**
	 * @Title: selects 
	 * @Description: 用户的列表查询
	 * @param name
	 * @return
	 * @return: List<User>
	 */
	List<User> selects(@Param("username")String username);
	/**
	 * 
	 * @Title: insertSelective 
	 * @Description: 注册用户
	 * @param record
	 * @return
	 * @return: int
	 */
    int insertSelective(User record);
/**
 * 
 * 
 * @Title: selectByPrimaryKey 
 * @Description: 单查用户
 * @param id
 * @return
 * @return: User
 */
    User selectByPrimaryKey(Integer id);
/**
 * 
 * @Title: updateByPrimaryKeySelective 
 * @Description: 修改用户信息
 * @param record
 * @return
 * @return: int
 */
    
    int updateByPrimaryKeySelective(User record);

    /**
     * 
     * @Title: selectsByUsername 
     * @Description:根据用户名查询用户
     * @param username
     * @return
     * @return: User
     */
    User selectsByUsername(String username);
	/** 
	 * @Title: selectByUsername 
	 * @Description: TODO
	 * @param username
	 * @return
	 * @return: User
	 */
	User selectByUsername(String username);

    
}