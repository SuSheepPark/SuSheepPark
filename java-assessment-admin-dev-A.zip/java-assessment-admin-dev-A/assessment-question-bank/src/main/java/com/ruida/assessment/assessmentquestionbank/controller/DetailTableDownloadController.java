package com.ruida.assessment.assessmentquestionbank.controller;

import com.ruida.assessment.util.DownloadUtil;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@Controller
@RequestMapping("/testPaper")
public class DetailTableDownloadController {
    /**
     * 下载细目表导入模板
     *
     * @param request
     * @param response
     * @throws Exception
     */
    @RequestMapping("/downloadDetailTable")
    public void downloadFile(HttpServletRequest request,
                             HttpServletResponse response) throws Exception {
        String fileName = "细目表导入模板.xlsx";
        DownloadUtil.downloadFile(request, response, fileName);

    }
}
