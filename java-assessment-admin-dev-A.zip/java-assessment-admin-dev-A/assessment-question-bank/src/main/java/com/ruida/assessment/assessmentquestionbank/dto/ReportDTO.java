package com.ruida.assessment.assessmentquestionbank.dto;

/**
 * @description: 测评报告DTO
 * @author: chenjy
 * @create: 2020-08-05 16:38
 */
public class ReportDTO {

    /*商品id*/
    private Integer productId;

    /*9+1商品id*/
    private Integer nineOneProductId;

    /*试卷id*/
    private Integer testPaperId;

    /*学校id*/
    private Integer schoolId;

    /*班级id*/
    private Integer classId;

    /*类型，0代表本班，1代表本校，2代表9+1学校，3-全体学校*/
    private int type;

    /*试题id*/
    private String questionId;

    /*知识点id*/
    private Integer knowledgeId;

    /*考察目标id*/
    private Integer targetId;

    /*考试方式*/
    private Integer testWay;

    /*商品试卷对应的常模id*/
    private Integer constRangeId;

    /*科目id*/
    private Boolean isNineOneStudent;

    public Integer getProductId() {
        return productId;
    }

    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    public Integer getTestPaperId() {
        return testPaperId;
    }

    public void setTestPaperId(Integer testPaperId) {
        this.testPaperId = testPaperId;
    }

    public Integer getClassId() {
        return classId;
    }

    public void setClassId(Integer classId) {
        this.classId = classId;
    }

    public Integer getSchoolId() {
        return schoolId;
    }

    public void setSchoolId(Integer schoolId) {
        this.schoolId = schoolId;
    }

    public Integer getTestWay() {
        return testWay;
    }

    public void setTestWay(Integer testWay) {
        this.testWay = testWay;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getQuestionId() {
        return questionId;
    }

    public void setQuestionId(String questionId) {
        this.questionId = questionId;
    }

    public Integer getKnowledgeId() {
        return knowledgeId;
    }

    public void setKnowledgeId(Integer knowledgeId) {
        this.knowledgeId = knowledgeId;
    }

    public Integer getTargetId() {
        return targetId;
    }

    public void setTargetId(Integer targetId) {
        this.targetId = targetId;
    }

	public Integer getConstRangeId() {
		return constRangeId;
	}

	public void setConstRangeId(Integer constRangeId) {
		this.constRangeId = constRangeId;
	}

    public Boolean getIsNineOneStudent() {
        return isNineOneStudent;
    }

    public void setIsNineOneStudent(Boolean nineOneStudent) {
        isNineOneStudent = nineOneStudent;
    }

    public Integer getNineOneProductId() {
        return nineOneProductId;
    }

    public void setNineOneProductId(Integer nineOneProductId) {
        this.nineOneProductId = nineOneProductId;
    }
}
