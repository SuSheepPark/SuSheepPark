package com.ruida.cloud.daoTmp;

import lombok.Data;

import java.io.Serializable;

/**
 * @author taosh
 * @create 2019-05-08 10:15
 */
@Data
public class VdyooClassRoom implements Serializable {
    private String vId;

    private String id;

    private String address;

    private String name;

    private String roomType;
}
