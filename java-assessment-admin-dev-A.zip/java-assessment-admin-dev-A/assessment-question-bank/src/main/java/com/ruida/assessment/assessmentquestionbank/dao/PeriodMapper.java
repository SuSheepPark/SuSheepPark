package com.ruida.assessment.assessmentquestionbank.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.assessment.assessmentquestionbank.dto.BaseFieldDTO;
import com.ruida.assessment.assessmentquestionbank.model.TPeriod;
import com.ruida.assessment.assessmentquestionbank.vo.BaseFieldVO;
import com.ruida.assessment.assessmentquestionbank.vo.PeriodVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @description: 学段dao层接口
 * @author: kgz
 * @date: 2020/6/18
 */
@Mapper
public interface PeriodMapper extends BaseMapper<TPeriod> {
    /**
     * 获取学段下拉框数据
     * @return
     */
    List<PeriodVO> getPeriodList(@Param("userId") Integer userId);

    /**
     * 获取学段下拉框所有选项列表
     * @return
     */
    List getAllList();

    /**
     * 分页查询列表
     * @param baseFieldDTO
     * @return
     */
    List<BaseFieldVO> queryList(@Param("baseFieldDTO") BaseFieldDTO baseFieldDTO);

    /**
     * 列表数据条数
     * @return
     */
    Integer countQuerList();

    TPeriod getPeriodByGrade(@Param("stageId") Integer stageId);
}
