package com.ruida.mockdao.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.model.TMaterialVersion;
import org.apache.ibatis.annotations.Mapper;


@Mapper
public interface MaterialVersionMapper extends BaseMapper<TMaterialVersion> {


}
