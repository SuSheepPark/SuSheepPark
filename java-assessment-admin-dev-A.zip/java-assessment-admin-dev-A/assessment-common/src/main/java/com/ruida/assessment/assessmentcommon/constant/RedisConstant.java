package com.ruida.assessment.assessmentcommon.constant;

public class RedisConstant {
    //rotation_chart:{locationType}:{source}
    public static final String ROTATION_CHART_LIST_KEY = "rotation_chart:%s:%s";

    public static final String ROTATION_CHART_MANAGE_ADD_KEY = "rotation_chart_mange:add:%s:%s";
    public static final String ROTATION_CHART_MANAGE_UPDATE_KEY = "rotation_chart_mange:update:%s:%s";
    public static final String INFORMATION_COLUMN_OPERATE_KEY = "information_column:operate:%s:%s";
    public static final String INFORMATION_COLUMN_ADD_KEY = "information_column:add:%s";
    public static final String INFORMATION_COLUMN_UPDATE_KEY = "information_column:update:%s:%s";
    public static final String INFORMATION_CONTENT_OPERATE_KEY = "information_content:operate:%s:%s";
    public static final String INFORMATION_CONTENT_ADD_KEY = "information_content:add:%s";
    public static final String INFORMATION_CONTENT_UPDATE_KEY = "information_content:update:%s:%s";
    public static final String INFORMATION_CONTENT_NEWEST="information:newest:%s";
    
    public static final String RECOMMENED_PRODUCTS="recommend:front_page_products";
    
    public static final String EXAM_TESTPAPER_BASE = "paperBaseInfo:testPaperVO:%s";
	public static final String EXAM_TESTPAPER_REL = "paperBaseInfo:TestPaperProductRel:product_%s:testPaper_%s";
    public static final String PRESENT_PRODUCT_TO_USER = "present:product:%s";
    public static final String PRESENT_USER_PRODUCT= "present:user:%s";
}
