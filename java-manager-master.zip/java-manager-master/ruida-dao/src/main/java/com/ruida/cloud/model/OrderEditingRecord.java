package com.ruida.cloud.model;

import java.math.BigDecimal;
import java.util.Date;

public class OrderEditingRecord {
    /**
     * 订单编辑记录主键ID
     */
    private Integer id;

    /**
     * 订单ID
     */
    private Integer orderId;

    /**
     * 订单编号
     */
    private String orderNo;

    /**
     * 操作类型（0—修改；1—删除）
     */
    private Byte editType;

    /**
     * 实际订单金额（修改前）
     */
    private BigDecimal realOrderAmountOld;

    /**
     * 实际订单金额（修改后）
     */
    private BigDecimal realOrderAmountNew;

    /**
     * 折扣金额（修改前）
     */
    private BigDecimal saleAmountOld;

    /**
     * 折扣金额（修改后）
     */
    private BigDecimal saleAmountNew;

    /**
     * 课程类型名称（修改前）
     */
    private String courseTypeNameOld;

    /**
     * 课程类型名称（修改后）
     */
    private String courseTypeNameNew;

    /**
     * 授课方式（0—线下双师；1—录播课堂；2—线上直播）（修改前）
     */
    private Byte teachingMethodOld;

    /**
     * 授课方式（0—线下双师；1—录播课堂；2—线上直播）（修改后）
     */
    private Byte teachingMethodNew;

    /**
     * 创建者ID
     */
    private Integer createBy;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新者ID
     */
    private Integer updateBy;

    /**
     * 更新时间
     */
    private Date updateTime;

    /**
     * 是否删除（0：未删除；1：删除）
     */
    private Byte isdelete;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getOrderId() {
        return orderId;
    }

    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo == null ? null : orderNo.trim();
    }

    public Byte getEditType() {
        return editType;
    }

    public void setEditType(Byte editType) {
        this.editType = editType;
    }

    public BigDecimal getRealOrderAmountOld() {
        return realOrderAmountOld;
    }

    public void setRealOrderAmountOld(BigDecimal realOrderAmountOld) {
        this.realOrderAmountOld = realOrderAmountOld;
    }

    public BigDecimal getRealOrderAmountNew() {
        return realOrderAmountNew;
    }

    public void setRealOrderAmountNew(BigDecimal realOrderAmountNew) {
        this.realOrderAmountNew = realOrderAmountNew;
    }

    public BigDecimal getSaleAmountOld() {
        return saleAmountOld;
    }

    public void setSaleAmountOld(BigDecimal saleAmountOld) {
        this.saleAmountOld = saleAmountOld;
    }

    public BigDecimal getSaleAmountNew() {
        return saleAmountNew;
    }

    public void setSaleAmountNew(BigDecimal saleAmountNew) {
        this.saleAmountNew = saleAmountNew;
    }

    public String getCourseTypeNameOld() {
        return courseTypeNameOld;
    }

    public void setCourseTypeNameOld(String courseTypeNameOld) {
        this.courseTypeNameOld = courseTypeNameOld == null ? null : courseTypeNameOld.trim();
    }

    public String getCourseTypeNameNew() {
        return courseTypeNameNew;
    }

    public void setCourseTypeNameNew(String courseTypeNameNew) {
        this.courseTypeNameNew = courseTypeNameNew == null ? null : courseTypeNameNew.trim();
    }

    public Byte getTeachingMethodOld() {
        return teachingMethodOld;
    }

    public void setTeachingMethodOld(Byte teachingMethodOld) {
        this.teachingMethodOld = teachingMethodOld;
    }

    public Byte getTeachingMethodNew() {
        return teachingMethodNew;
    }

    public void setTeachingMethodNew(Byte teachingMethodNew) {
        this.teachingMethodNew = teachingMethodNew;
    }

    public Integer getCreateBy() {
        return createBy;
    }

    public void setCreateBy(Integer createBy) {
        this.createBy = createBy;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(Integer updateBy) {
        this.updateBy = updateBy;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Byte getIsdelete() {
        return isdelete;
    }

    public void setIsdelete(Byte isdelete) {
        this.isdelete = isdelete;
    }
}