package com.ruida.cloud.model;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

@Data
public class BaijiayunDownloadVideoRecord implements Serializable {
    private String video_id;

    private String name;

    private Integer product_type;//1:教育直播(大班课)，2，小班课，3：双师，4，企业直播

    private Date bjy_create_time;

    private Integer isacquire;

    private Date create_time;

    private Date update_time;

    private Integer isdelete;


}