package com.ruida.mockcommon.enums;

/**
 * Created by xumingqi on 2021/9/2 16:13
 */
public enum ImplementPlanStatusEnum {
    NOT_START(1, "未开始"),
    STARTED(2, "进行中"),
    FINISHED(3, "已结束");

    private Integer K;
    private String V;

    ImplementPlanStatusEnum(Integer k, String v) {
        K = k;
        V = v;
    }

    public Integer getK() {
        return K;
    }

    public void setK(Integer k) {
        K = k;
    }

    public String getV() {
        return V;
    }

    public void setV(String v) {
        V = v;
    }
}
