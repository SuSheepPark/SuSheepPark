package com.ruida.assessment.assessmentquestionbank.model;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;

import java.io.Serializable;

/**
 * @description: 网站访客数数据库实体
 * @author: kgz
 * @date: 2020/8/4
 */

@TableName("t_uv")
public class TUniqueVisitor extends BaseColumn implements Serializable {
    private static final long serialVersionUID = -7082998594804243361L;
    /**
     * 主键ID
     */
    @TableId
    private Integer id;

    /**
     * 访客信息
     */
    private String visitor;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getVisitor() {
        return visitor;
    }

    public void setVisitor(String visitor) {
        this.visitor = visitor;
    }

    @Override
    public String toString() {
        return "TUniqueVisitor{" +
                "id=" + id +
                ", visitor='" + visitor + '\'' +
                super.toString() +
                '}';
    }
}
