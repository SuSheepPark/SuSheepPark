package com.ruida.assessment.assessmentquestionbank.controller;

import com.ruida.assessment.assessmentcommon.constant.RedisConstant;
import com.ruida.assessment.assessmentcommon.enums.AppErrorEnum;
import com.ruida.assessment.assessmentcommon.enums.OperateModuleEnum;
import com.ruida.assessment.assessmentcommon.enums.OperateTypeEnum;
import com.ruida.assessment.assessmentcommon.enums.ResultStatusCode;
import com.ruida.assessment.assessmentcommon.exception.CoreException;
import com.ruida.assessment.assessmentcommon.result.BaseResult;
import com.ruida.assessment.assessmentcommon.result.PageData;
import com.ruida.assessment.assessmentcommon.result.PojoResult;
import com.ruida.assessment.assessmentquestionbank.annotaion.OperateLog;
import com.ruida.assessment.assessmentquestionbank.annotaion.UserAuth;
import com.ruida.assessment.assessmentquestionbank.dto.*;
import com.ruida.assessment.assessmentquestionbank.service.IProductService;
import com.ruida.assessment.assessmentquestionbank.vo.ProductInfoVo;
import com.ruida.assessment.assessmentquestionbank.vo.ProductListVo;
import com.ruida.assessment.assessmentquestionbank.vo.TReportProductWayPaperTypeVO;
import com.ruida.assessment.assessmentquestionbank.vo.UserVo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

/**
 * @author wy
 * @description 商品管理业务层
 * @date 2020/6/24
 */
@Slf4j
@RequestMapping("/product")
@RestController
public class ProductController {

    @Resource
    private IProductService productService;
    @Resource
    protected RedisTemplate redisTemplate;

    /*
     *功能描述  查询商品列表（分页）
     * @param
     * @return
     */
    @UserAuth
    @PostMapping("query/productList")
    public PojoResult queryProductList(@RequestBody ProductQueryRequest request) {
        PageData<ProductListVo> pageList = productService.queryProductList(request);
        PojoResult<PageData> result = new PojoResult<>();
        result.setContent(pageList);
        return result;
    }

    /*
     *功能描述  新增商品时查询默认商品图片
     * @param
     * @return
     */
    @GetMapping("query/defaultImg")
    public PojoResult queryProductList() {
        PojoResult result = productService.queryDefaultImg();
        return result;
    }

    /*
     *功能描述  上架、下架商品
     * @param
     * @return
     */
    @UserAuth
    @PostMapping("update/updateProductStatus")
    public BaseResult updateProductStatus(@RequestBody ProductQueryRequest request) {
        return productService.updateProductStatus(request);
    }

    /*
     *功能描述  新增/修改 商品
     * @param
     * @return
     */
    @UserAuth
    @PostMapping("add/saveProduct")
    public BaseResult saveProduct(@RequestBody ProductAddRequest request) {
        return productService.saveProduct(request);
    }

    /*
     * 功能描述   查询报告模板列表
     * @param
     * @return
     */
  /*  @UserAuth
    @GetMapping("query/reportTemplate")
    public ListResult queryReportTemplate(Integer type){

        ListResult result = new ListResult();
        List<ReportTemplateVo> list = productService.queryReportTemplate(type);
        result.setContent(list);
        result.setTotalCount(list.size());
        return result;
    }*/

    /*
     * 功能描述   编辑时查询商品信息
     * @param
     * @return
     */
    @UserAuth
    @GetMapping("query/productInfo")
    public PojoResult queryProductInfo(@RequestParam Integer productId) {
        ProductInfoVo productInfoVo = productService.queryProductInfo(productId);
        PojoResult<ProductInfoVo> result = new PojoResult<>();
        result.setContent(productInfoVo);
        return result;
    }

    /*
     *功能描述  退回
     * @param
     * @return
     */
    @UserAuth
    @PostMapping("update/rollbackProduct")
    public BaseResult rollbackProduct(@RequestBody ProductAddRequest request) {
        return productService.rollbackProduct(request);
    }


    /*
     *功能描述  列表提交/删除/置顶/取消置顶/隐藏/显示
     * @param
     * @return
     */
    @UserAuth
    @PostMapping("update/operateProductList")
    public BaseResult operateProductList(@RequestBody ProductAddRequest request) {
        return productService.operateProductList(request);
    }

    /*
     *功能描述  查询购买该商品的学员列表（含已赠送 分页）（废弃）
     * @param
     * @return
     */
 /*   @UserAuth
    @PostMapping("query/productStudentList")
    public PojoResult queryProductStudentList(@RequestBody ProductQueryRequest request) {
        PageData<StudentInfoVo> pageList = productService.queryProductStudentList(request);
        PojoResult<PageData> result = new PojoResult<>();
        result.setContent(pageList);
        return result;
    }*/

    /*
     *功能描述  查询购买该商品的用户列表（含已赠送 分页）
     * @param
     * @return
     */
    @UserAuth
    @PostMapping("query/productUserList")
    public PojoResult queryProductUserList(@RequestBody UserQueryRequest request) {
        PageData<UserVo> pageList = productService.queryProductUserList(request);
        PojoResult<PageData> result = new PojoResult<>();
        result.setContent(pageList);
        return result;
    }

    /*
     *功能描述  查询该商品已赠送学员列表（分页）（废弃）
     * @param
     * @return
     */
   /* @UserAuth
    @PostMapping("query/productPresentStudentList")
    public PojoResult queryProductPresentStudentList(@RequestBody StudentRequest request) {
        PageData<StudentInfoVo> pageList = productService.queryProductPresentStudentList(request);
        PojoResult<PageData> result = new PojoResult<>();
        result.setContent(pageList);
        return result;
    }
*/
    /*
     *功能描述  查询该商品已赠送用户列表（分页）
     * @param
     * @return
     */
    @UserAuth
    @PostMapping("query/productPresentUserList")
    public PojoResult queryProductPresentUserList(@RequestBody UserQueryRequest request) {
        PageData<UserVo> pageList = productService.queryProductPresentUserList(request);
        PojoResult<PageData> result = new PojoResult<>();
        result.setContent(pageList);
        return result;
    }

    /*
     *功能描述  赠送单个商品给多个用户（批量）
     * @param
     * @return
     */
    @UserAuth
    @PostMapping("save/presentProductToUser")
    @OperateLog(module = OperateModuleEnum.PRODUCT, operateType = OperateTypeEnum.PRESENT)
    public BaseResult presentProductToUser(@RequestBody BatchOperationRequest request) {
        BaseResult result = new BaseResult();
        String key = String.format(RedisConstant.PRESENT_PRODUCT_TO_USER, request.getProductId());
        String value = UUID.randomUUID().toString();
        Boolean lock = redisTemplate.opsForValue().setIfAbsent(key, value, 5, TimeUnit.SECONDS);
        //重复请求 提示请勿重复赠送
        if (!lock) {
            return result.setErrorMessage(ResultStatusCode.PRESENT_PRODUCT_FAIL.getCode(), "赠送中，请勿重复赠送！");
        }
        try {
            result = productService.presentProductToUser(request);
            return result;
        } catch (DuplicateKeyException e) {
            log.info("method:[{}] has exception", "persentProductToUser", e);
            return result.setErrorMessage(ResultStatusCode.PRESENT_PRODUCT_FAIL.getCode(), "赠送创建订单异常，请稍后重试！");
        } finally {
            if (value.equals(redisTemplate.opsForValue().get(key))) {
                redisTemplate.delete(key);
            }
        }
    }

    /*
     *功能描述  赠送单个商品给全部用户（批量）
     * @param
     * @return
     */
    @UserAuth
    @PostMapping("save/presentProductToAllUser")
    @OperateLog(module = OperateModuleEnum.PRODUCT, operateType = OperateTypeEnum.PRESENT)
    public BaseResult presentProductToAllUser(@RequestBody UserQueryRequest request){
        String key = String.format(RedisConstant.PRESENT_PRODUCT_TO_USER, request.getProductId());
        String value = UUID.randomUUID().toString();
        Boolean lock = redisTemplate.opsForValue().setIfAbsent(key, value, 6, TimeUnit.SECONDS);
        //重复请求 提示操作频繁
        if (!lock) {
            throw new CoreException(AppErrorEnum.E_40026);
        }
        try {
            return productService.presentProductToAllUser(request);
        } finally {
            if (value.equals(redisTemplate.opsForValue().get(key))) {
                redisTemplate.delete(key);
            }
        }
    }

    /*
     *功能描述  赠送给单个用户多个商品（批量）
     * @param
     * @return
     */
    @UserAuth
    @PostMapping("save/presentUserProduct")
    @OperateLog(module = OperateModuleEnum.PRODUCT, operateType = OperateTypeEnum.PRESENT)
    public BaseResult presentUserProduct(@RequestBody BatchOperationRequest request) {
        BaseResult result = new BaseResult();
        String key = String.format(RedisConstant.PRESENT_USER_PRODUCT, request.getUserId());
        String value = UUID.randomUUID().toString();
        Boolean lock = redisTemplate.opsForValue().setIfAbsent(key, value, 3, TimeUnit.SECONDS);
        //重复请求 提示请勿重复赠送
        if (!lock) {
            return result.setErrorMessage(ResultStatusCode.PRESENT_PRODUCT_FAIL.getCode(), "赠送中，请勿重复赠送！");
        }
        try {
            return productService.presentUserProduct(request);
        } catch (DuplicateKeyException e) {
            log.info("method:[{}] has exception", "presentUserProduct", e);
            return result.setErrorMessage(ResultStatusCode.PRESENT_PRODUCT_FAIL.getCode(), "赠送创建订单异常，请稍后重试！");
        } finally {
            if (value.equals(redisTemplate.opsForValue().get(key))) {
                redisTemplate.delete(key);
            }
        }
    }

    /*
     *功能描述  查询某用户已经拥有的（已支付/待支付,已赠送）所有商品id
     * @param
     * @return
     */
    @UserAuth
    @GetMapping("query/userOwnProductList")
    public PojoResult queryUserOwnProductList(@RequestParam Integer userId) {
        List<Integer> ownProductList = productService.queryUserOwnProductList(userId);
        PojoResult result = new PojoResult<>();
        result.setContent(ownProductList);
        return result;
    }

    /*
     *功能描述  查询某商品已经被拥有(已支付/待支付,已赠送)的所有用户id
     * @param
     * @return
     */
    @UserAuth
    @GetMapping("query/productOwnedUserList")
    public PojoResult queryProductOwnedUserList(@RequestParam Integer productId) {
        List<Integer> studentList = productService.queryProductOwnedUserList(productId);
        PojoResult result = new PojoResult<>();
        result.setContent(studentList);
        return result;
    }

    /*
     *功能描述  上架状态商品替换预售试卷为正常试卷
     * @param
     * @return
     */
    @UserAuth
    @PostMapping("update/exchangePresellPaper")
    public BaseResult exchangePresellPaper(@RequestBody ExchangePresellPaperRequest request) {
        return productService.exchangePresellPaper(request);
    }


    /**
     * 通过试卷性质和测验形式查询报告类型和是否需要关联常模
     *
     * @param tReportProductWayPaperTypeRel
     * @return
     */
    @UserAuth
    @PostMapping("query/ReportTypeByPaperUseTypeAndProductTestWay")
    public PojoResult queryReportTypeByPaperUseTypeAndProductTestWay(@RequestBody List<TReportProductWayPaperTypeRelDTO> tReportProductWayPaperTypeRel) {
        List<TReportProductWayPaperTypeVO> list = productService.queryReportTypeByPaperUseTypeAndProductTestWay(tReportProductWayPaperTypeRel);
        PojoResult result = new PojoResult();
        result.setContent(list);
        return result;
    }

    /*
     *功能描述  商品是否是推荐商品
     * @param
     * @return
     */
    @UserAuth
    @PostMapping("isRecommended/{productId}")
    public PojoResult isRecommended(@PathVariable Integer productId) {
        PojoResult result = new PojoResult();
        result.setContent(productService.isRecommended(productId));
        return result;
    }
}
