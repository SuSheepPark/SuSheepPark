package com.ruida.cloud.dao;

import com.ruida.cloud.model.WeiduCourseLessonRel;
import com.ruida.cloud.model.WeiduCourseLessonRelExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface WeiduCourseLessonRelMapper {
    long countByExample(WeiduCourseLessonRelExample example);

    int deleteByExample(WeiduCourseLessonRelExample example);

    int deleteByPrimaryKey(Integer rid);

    int insert(WeiduCourseLessonRel record);

    int insertSelective(WeiduCourseLessonRel record);

    List<WeiduCourseLessonRel> selectByExample(WeiduCourseLessonRelExample example);

    WeiduCourseLessonRel selectByPrimaryKey(Integer rid);

    int updateByExampleSelective(@Param("record") WeiduCourseLessonRel record, @Param("example") WeiduCourseLessonRelExample example);

    int updateByExample(@Param("record") WeiduCourseLessonRel record, @Param("example") WeiduCourseLessonRelExample example);

    int updateByPrimaryKeySelective(WeiduCourseLessonRel record);

    int updateByPrimaryKey(WeiduCourseLessonRel record);
}