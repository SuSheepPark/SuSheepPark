package com.ruida.common.enums;

/**
 * datebase enum 定义字段常量值
 *
 * @author szl
 */
public enum DBE {
    ;

    /**
     * 删除标志
     *
     * @author szl
     */
    public enum IsDeleted {
        /**
         * 已删除
         **/
        Y("y"),
        /**
         * 未删除
         **/
        N("n");
        String value = "";

        public String value() {
            return value;
        }

        private IsDeleted(String value) {
            this.value = value;
        }
    }

    /**
     * 课程状态
     *
     * @author szl
     */
    public enum CourseStatus {

        /**
         * 取消
         **/
        CANCEL("0"),
        /**
         * 开启
         **/
        START("1");
        String value = "";

        public String value() {
            return value;
        }

        private CourseStatus(String value) {
            this.value = value;
        }
    }


    /**
     * 是否四舍五入标志
     *
     * @author szl
     */
    public enum IsRoundUp {
        /**
         * 四舍五入
         **/
        Y("1"),
        /**
         * 不四舍五入
         **/
        N("0");
        String value = "";

        public String value() {
            return value;
        }

        private IsRoundUp(String value) {
            this.value = value;
        }
    }

    /**
     * 课程是否收费
     */
    public enum IsCharge {
        /**
         * 收费课程
         */
        Y(1),
        /**
         * 不收费
         */
        N(0);
        public Integer value = 0;

        private IsCharge(Integer value) {
            this.value = value;
        }
    }

    /**
     * 课程是否公开
     */
    public enum Ispublic {
        /**
         * 公开
         */
        Y(1),

        /**
         * 不公开
         */
        N(0);
        public Integer value;

        private Ispublic(Integer value) {
            this.value = value;
        }


    }

    /**
     * 课程是否发布
     */
    public enum IsPublish {
        /**
         * 已发布
         */
        Y(1),
        /**
         * 未发布
         */
        N(0);
        public Integer value;

        private IsPublish(Integer value) {
            this.value = value;
        }
    }

}
