package com.ruida.cloud.dao;


import com.ruida.cloud.model.CourseLessonExt;

import java.util.List;
import java.util.Map;

public interface CourseLessonMapperExt {
    List<CourseLessonExt> listCourseLessonExtByCourseId(Integer courseId);

    List<CourseLessonExt> selectCourseLessonByExample(Map condition);

    int countCourseLessonByExample(Map condition);

    int countRecordCourseLessonByExample(Map condition);

    List<CourseLessonExt> selectRecordCourseLessonByExample(Map condition);

    List<CourseLessonExt> listTwoMoveUpLesson(Map condition);

    List<CourseLessonExt> listTwoMoveDownLesson(Map condition);

    CourseLessonExt getLastCourseLesson(Integer courseId);

    CourseLessonExt getFirstCourseLesson(Integer courseId);

    List<CourseLessonExt> getNowCourseLesson(Integer courseId);

    List<Map<String, Object>> listCourseLessonForTeacher(Map condition);

    List<Map<String, Object>> listCourseLessonForAssistantTeacher(Map condition);

    int deleteCourseLessonByCourseId(Integer courseId);

    int countRemainCourseLesson(Integer courseId);

    List<Map<String, Object>> listCourseLessonInfo(Integer courseId);

}