package com.ruida.mockdao.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.model.ImageBanner;

/**
 * <p>
 * banner图 Mapper 接口
 * </p>
 *
 * @author xumingqi
 * @since 2021-01-07
 */
public interface ImageBannerMapper extends BaseMapper<ImageBanner> {

}
