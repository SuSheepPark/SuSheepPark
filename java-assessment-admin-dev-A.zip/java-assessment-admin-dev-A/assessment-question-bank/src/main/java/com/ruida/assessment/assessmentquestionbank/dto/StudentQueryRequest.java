package com.ruida.assessment.assessmentquestionbank.dto;

import com.ruida.assessment.assessmentcommon.result.Page;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel(description = "考生查询条件")
public class StudentQueryRequest {

    /* 地区id */
    @ApiModelProperty(value = "地区id", name = "parentId")
    private Integer parentId;

    /* 学校类型 */
    @ApiModelProperty(value = "学校类型", name = "periodId")
    private Integer periodId;

    /* 学校id */
    @ApiModelProperty(value = "学校id", name = "schoolId")
    private Integer schoolId;

    /* 年级id */
    @ApiModelProperty(value = "年级id", name = "gradeId")
    private Integer gradeId;

    /* 班级id */
    @ApiModelProperty(value = "班级id", name = "classId")
    private Integer classId;

    /* 是否绑定 */
    @ApiModelProperty(value = "是否绑定用户", name = "isbound")
    private Integer isbound;

    @ApiModelProperty(value = "导入时间-开始时间", name = "startTime")
    private String startTime;

    @ApiModelProperty(value = "导入时间-结束时间", name = "endTime")
    private String endTime;

    /* 模糊查询字段  姓名/准考证号 */
    @ApiModelProperty(value = "模糊查询字段", name = "searchWord")
    private String searchWord;


    /* 分页 */
    private Page page;
    private Integer start;
    private Integer size;

}
