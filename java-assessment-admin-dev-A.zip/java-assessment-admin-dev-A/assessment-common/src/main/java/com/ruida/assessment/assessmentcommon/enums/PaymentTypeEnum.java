package com.ruida.assessment.assessmentcommon.enums;

/**
 * @description:
 * @author: kgz
 * @date: 2020/8/14
 */
public enum PaymentTypeEnum {
    WECHAT(0, "微信支付"),
    ALIPAY(1, "支付宝"),
    /*    QQ(2,"QQ钱包"),
        CYBER_BANK(3,"网银支付"),
        OFFLINE(4,"线下支付"),*/
    FREE(5, "免费领取"),
    LEARN_CURRENCY(6, "学币抵扣"),
    PRESENT(7, "平台赠送"),
    ;
    private Integer K;
    private String V;

    PaymentTypeEnum(Integer k, String v) {
        K = k;
        V = v;
    }

    public Integer getK() {
        return K;
    }

    public void setK(Integer k) {
        K = k;
    }

    public String getV() {
        return V;
    }

    public void setV(String v) {
        V = v;
    }

    public static PaymentTypeEnum getValueById(Integer K){
        if(K != null){
            for(PaymentTypeEnum paymentTypeEnum : PaymentTypeEnum.values() ){
                if(paymentTypeEnum.getK().equals(K)){
                    return  paymentTypeEnum;
                }
            }
        }
        return null;
    }

}
