package com.ruida.mockdao.model;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @description: 学段数据库实体
 * @author: kgz
 * @date: 2020/6/18
 */
@TableName("t_period")
@Data
public class TPeriod implements Serializable {
    private static final long serialVersionUID = 4988017036536477851L;

    /**
     * 学段id
     */
    @TableId
    private Integer id;

    /**
     * 学段名称
     */
    private String periodName;

    private String stage;

    private String gradeIds;

    private List<TStage> stages;

    /**
     * 状态（0—禁用；1—启用）
     */
    private String status;


}
