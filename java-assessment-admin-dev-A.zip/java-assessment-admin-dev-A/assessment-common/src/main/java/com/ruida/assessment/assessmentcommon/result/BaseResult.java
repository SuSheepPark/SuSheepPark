package com.ruida.assessment.assessmentcommon.result;

import java.io.Serializable;


public class BaseResult implements Serializable {

	private static final long serialVersionUID = 7220877209535559537L;

	private static final int SUCCESS_CODE = 0;


	private Boolean success;

	/** 错误码 */
	private Integer code;

	/** 错误信息，默认操作成功 */
	private String msg = "操作成功";

	private Object devMsg = "操作成功";

	public BaseResult() {
		setCode(SUCCESS_CODE);
		this.success = true;
	}

	@SuppressWarnings("unchecked")
	public <R extends BaseResult> R setErrorMessage(Integer code, String message) {
		setCode(code);
		setMsg(message);
		this.success = false;
		return (R) this;
	}


	public void setSuccess(boolean success) {
		this.success = success;
	}

	public Object getDevMsg() {
		return devMsg;
	}

	public void setDevMsg(Object devMsg) {
		this.devMsg = devMsg;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}
	public Integer getCode() {
		return code;
	}

	public Boolean getSuccess() {
		return success;
	}

	public void setCode(Integer code) {
		this.code = code;
	}

}
