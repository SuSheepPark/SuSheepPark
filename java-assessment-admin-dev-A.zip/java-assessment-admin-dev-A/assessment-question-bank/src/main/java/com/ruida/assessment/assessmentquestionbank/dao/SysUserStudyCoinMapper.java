package com.ruida.assessment.assessmentquestionbank.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.assessment.assessmentquestionbank.model.TSysUserStudyCoin;
import org.mapstruct.Mapper;

/**
 * @author wy
 * @description 学习币mapper
 * @date 2020/8/3
 */
@Mapper
public interface SysUserStudyCoinMapper extends BaseMapper<TSysUserStudyCoin> {

}
