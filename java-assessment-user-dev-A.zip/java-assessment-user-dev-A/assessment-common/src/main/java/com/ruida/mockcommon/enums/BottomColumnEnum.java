package com.ruida.mockcommon.enums;

import java.util.LinkedHashMap;
import java.util.Map;

public enum BottomColumnEnum {
    GYZR(0,"关于正睿"),
    XSZN(1,"新手指南"),
    ZFFS(2,"支付方式"),
    YQLJ(3,"友情链接");

    public static final String SOURCE_KEY = "Bool";
    private Integer k;
    private String v;

    BottomColumnEnum(Integer k, String v) {
        this.k = k;
        this.v = v;
    }

    public static Map<Integer,String> map = new LinkedHashMap<>(2);
    static
    {
        for(BottomColumnEnum type : BottomColumnEnum.values())
        {
            map.put(type.getK(),type.getV());
        }
    }

    public Integer getK() {
        return k;
    }

    public void setK(Integer k) {
        this.k = k;
    }

    public String getV() {
        return v;
    }

    public void setV(String v) {
        this.v = v;
    }
}
