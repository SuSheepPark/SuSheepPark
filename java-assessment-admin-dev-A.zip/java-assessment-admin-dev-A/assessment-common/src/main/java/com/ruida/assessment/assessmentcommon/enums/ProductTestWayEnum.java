package com.ruida.assessment.assessmentcommon.enums;

/**
 * @description: 商品测验方式枚举类
 * @author: wy
 * @date: 2021/7/2
 */
public enum ProductTestWayEnum {
    EXERCISE(0,"平时练习"),
    OFFLINE(1,"线下联考"),
    COMPUTER(2,"机房统考"),
    ONLINT(3,"在线统考"),

    ;

    private Integer K;
    private String V;

    ProductTestWayEnum(Integer k, String v) {
        K = k;
        V = v;
    }

    public Integer getK() {
        return K;
    }

    public void setK(Integer k) {
        K = k;
    }

    public String getV() {
        return V;
    }

    public void setV(String v) {
        V = v;
    }

    public static ProductTestWayEnum getValueById(Integer K){
        if(K != null){
            for(ProductTestWayEnum deleteStatusEnum : ProductTestWayEnum.values() ){
                if(deleteStatusEnum.getK().equals(K)){
                    return  deleteStatusEnum;
                }
            }
        }
        return null;
    }

}
