package com.ruida.assessment.assessmentquestionbank.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.assessment.assessmentquestionbank.model.TClass;
import com.ruida.assessment.assessmentquestionbank.model.TClassGradeSchoolRel;
import com.ruida.assessment.assessmentquestionbank.model.TGrade;
import com.ruida.assessment.assessmentquestionbank.vo.ClassVo;
import com.ruida.assessment.assessmentquestionbank.vo.SchoolClassTaskVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author wy
 * @description 学校班级关联关系Mapper
 * @date 2020/7/27
 */
@Mapper
public interface ClassGradeSchoolRelMapper extends BaseMapper<TClassGradeSchoolRel> {



    /*下拉框获取年级班级列表*/
    List<ClassVo> queryClassByGradeId(@Param("gradeId") Integer gradeId, @Param("schoolId") Integer schoolId);

    /**
     * 获取学校班级待办信息
     * @param size
     * @return
     */
    List<SchoolClassTaskVO> getTask(@Param("size") Integer size);
}
