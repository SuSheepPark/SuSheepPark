package com.ruida.cloud.dao;

import com.ruida.cloud.model.XiaogjCampusRel;
import com.ruida.cloud.model.XiaogjCampusRelExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface XiaogjCampusRelMapper {
    int countByExample(XiaogjCampusRelExample example);

    int deleteByExample(XiaogjCampusRelExample example);

    int deleteByPrimaryKey(Integer rid);

    int insert(XiaogjCampusRel record);

    int insertSelective(XiaogjCampusRel record);

    List<XiaogjCampusRel> selectByExample(XiaogjCampusRelExample example);

    XiaogjCampusRel selectByPrimaryKey(Integer rid);

    int updateByExampleSelective(@Param("record") XiaogjCampusRel record, @Param("example") XiaogjCampusRelExample example);

    int updateByExample(@Param("record") XiaogjCampusRel record, @Param("example") XiaogjCampusRelExample example);

    int updateByPrimaryKeySelective(XiaogjCampusRel record);

    int updateByPrimaryKey(XiaogjCampusRel record);
}