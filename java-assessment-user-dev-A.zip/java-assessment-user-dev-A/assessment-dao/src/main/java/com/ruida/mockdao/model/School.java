package com.ruida.mockdao.model;

import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 学校信息表
 * </p>
 *
 * @author Bhj
 * @since 2020-07-13
 */
@TableName("t_school")
public class School extends Model<School> {

    private static final long serialVersionUID = 1L;

    /**
     * 学校主键ID
     */
    @TableId(value = "school_id", type = IdType.AUTO)
    private Integer schoolId;
    /**
     * 学校名称
     */
    @TableField("school_name")
    private String schoolName;
    /**
     * 学校logo图片路径
     */
    @TableField("logo_path")
    private String logoPath;
    /**
     * 学段ID(以逗号拼接)
     */
    @TableField("period_id")
    private String periodId;
    /**
     * 省份ID
     */
    private Integer province;
    /**
     * 城市ID
     */
    private Integer city;
    /**
     * 地区ID
     */
    private Integer district;
    private String email;
    /**
     * 学校详细地址
     */
    private String address;
    /**
     * 学校简介
     */
    private String summary;
    /**
     * 负责人
     */
    @TableField("person_in_charge")
    private String personInCharge;
    /**
     * 联系方式
     */
    private String telephone;
    /**
     * 状态（0—禁用；1—启用）
     */
    private Integer status;
    /**
     * 创建者ID
     */
    @TableField("create_by")
    private Integer createBy;
    /**
     * 创建时间
     */
    @TableField("create_time")
    private Date createTime;
    /**
     * 更新者ID
     */
    @TableField("update_by")
    private Integer updateBy;
    /**
     * 更新时间
     */
    @TableField("update_time")
    private Date updateTime;
    /**
     * 是否删除（0：未删除；1：删除）
     */
    private Integer isdelete;


    public Integer getSchoolId() {
        return schoolId;
    }

    public void setSchoolId(Integer schoolId) {
        this.schoolId = schoolId;
    }

    public String getSchoolName() {
        return schoolName;
    }

    public void setSchoolName(String schoolName) {
        this.schoolName = schoolName;
    }

    public String getLogoPath() {
        return logoPath;
    }

    public void setLogoPath(String logoPath) {
        this.logoPath = logoPath;
    }

    public String getPeriodId() {
        return periodId;
    }

    public void setPeriodId(String periodId) {
        this.periodId = periodId;
    }

    public Integer getProvince() {
        return province;
    }

    public void setProvince(Integer province) {
        this.province = province;
    }

    public Integer getCity() {
        return city;
    }

    public void setCity(Integer city) {
        this.city = city;
    }

    public Integer getDistrict() {
        return district;
    }

    public void setDistrict(Integer district) {
        this.district = district;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public String getPersonInCharge() {
        return personInCharge;
    }

    public void setPersonInCharge(String personInCharge) {
        this.personInCharge = personInCharge;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getCreateBy() {
        return createBy;
    }

    public void setCreateBy(Integer createBy) {
        this.createBy = createBy;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(Integer updateBy) {
        this.updateBy = updateBy;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getIsdelete() {
        return isdelete;
    }

    public void setIsdelete(Integer isdelete) {
        this.isdelete = isdelete;
    }

    @Override
    protected Serializable pkVal() {
        return this.schoolId;
    }

    @Override
    public String toString() {
        return "School{" +
        ", schoolId=" + schoolId +
        ", schoolName=" + schoolName +
        ", logoPath=" + logoPath +
        ", periodId=" + periodId +
        ", province=" + province +
        ", city=" + city +
        ", district=" + district +
        ", email=" + email +
        ", address=" + address +
        ", summary=" + summary +
        ", personInCharge=" + personInCharge +
        ", telephone=" + telephone +
        ", status=" + status +
        ", createBy=" + createBy +
        ", createTime=" + createTime +
        ", updateBy=" + updateBy +
        ", updateTime=" + updateTime +
        ", isdelete=" + isdelete +
        "}";
    }
}
