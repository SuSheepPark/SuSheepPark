package com.ruida.assessment.assessmentcommon.enums;

public enum ButtonEnum {

    FIRST(0,"添加首个"),
    SAME(1,"同级"),
    SUN(2,"子级"),
    PARENT(3,"父级"),
    SAVE(4,"暂存"),
    COMMIT(5,"提交"),
    DELETE(6,"删除"),
    TOP(7,"置顶"),
    TOP_OFF(8,"取消置顶"),
    HIDE(9,"隐藏"),
    REVEAL(10,"显示"),
    ;

    private Integer K;
    private String V;

    ButtonEnum(Integer k, String v) {
        K = k;
        V = v;
    }

    public Integer getK() {
        return K;
    }

    public void setK(Integer k) {
        K = k;
    }

    public String getV() {
        return V;
    }

    public void setV(String v) {
        V = v;
    }

    public static DeleteStatusEnum getValueById(Integer K){
        for(DeleteStatusEnum deleteStatusEnum : DeleteStatusEnum.values() ){
            if(deleteStatusEnum.getK().equals(K)){
                return  deleteStatusEnum;
            }
        }
        return null;
    }
}
