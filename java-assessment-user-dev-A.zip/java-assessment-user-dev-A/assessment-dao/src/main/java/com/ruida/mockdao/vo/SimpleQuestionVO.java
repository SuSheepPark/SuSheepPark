package com.ruida.mockdao.vo;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

/**
 * @description:
 * @author: chenjy
 * @create: 2020-07-23 08:54
 */
@Data
public class SimpleQuestionVO {

    /**
     * 考试记录id
     */
    @JsonInclude(value = JsonInclude.Include.NON_NULL)
    private Integer examRecordId;

    /**
     * 试题id
     */
    private String questionId;

    /**
     * 题干
     */
    private String questionTitle;

    /**
     * 题型id
     */
    private Integer questionTypeId;

    /**
     * 题型名称
     */
    private String questionTypeName;

    /**
     * 分值
     */
    private Double score;
}
