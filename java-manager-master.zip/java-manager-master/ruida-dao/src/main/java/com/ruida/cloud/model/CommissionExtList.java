package com.ruida.cloud.model;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

/**
 * @description: 佣金扩展类
 * @author: chenjy
 * @create: 2020-04-16 11:43
 */
@Data
public class CommissionExtList implements Serializable {

    private List<CommissionExt> oldCommissionList;

    private List<CommissionExt> newCommissionList;
}
