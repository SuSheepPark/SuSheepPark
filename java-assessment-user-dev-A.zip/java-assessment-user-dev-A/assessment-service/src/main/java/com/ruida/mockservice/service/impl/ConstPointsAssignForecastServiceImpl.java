package com.ruida.mockservice.service.impl;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.ruida.mockdao.dao.ConstPointsAssignForecastMapper;
import com.ruida.mockdao.model.ConstPointsAssignForecast;
import com.ruida.mockservice.service.ConstPointsAssignForecastService;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

/**
 * <p>
 * 赋分预估常模表 服务实现类
 * </p>
 *
 * @author chenjy
 * @since 2021-03-11
 */
@Service
public class ConstPointsAssignForecastServiceImpl extends ServiceImpl<ConstPointsAssignForecastMapper, ConstPointsAssignForecast> implements ConstPointsAssignForecastService {

    @Override
    public Double convertScore(List<Double> standard, Double originScore, Integer subjectId,Integer constRangeId) {
        if(CollectionUtils.isEmpty(standard)){
            return originScore;
        }

        List<Double> gt = standard.stream().filter(
                e -> new BigDecimal(String.valueOf(e)).compareTo(new BigDecimal(String.valueOf(originScore))) > 0
        ).collect(Collectors.toList());

        double rank = new BigDecimal(gt.size()).divide(new BigDecimal(standard.size()), 4, 4).multiply(new BigDecimal("100")).doubleValue();

        List<ConstPointsAssignForecast> assignList = this.selectList(new EntityWrapper<ConstPointsAssignForecast>()
                .eq("range_id", constRangeId)
                .eq("subject_id", subjectId)
                .ge("rate", rank)
                .orderBy("rate"));

        if(!CollectionUtils.isEmpty(assignList)){
            return Double.valueOf(assignList.get(0).getLevel());
        }else {
            return originScore;
        }
    }
}
