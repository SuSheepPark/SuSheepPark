package com.ruida.mockservice.service;

import java.util.List;

import com.baomidou.mybatisplus.service.IService;
import com.ruida.mockcommon.result.Page;
import com.ruida.mockdao.model.TInformationColumnContent;
import com.ruida.mockdao.vo.information.InformationContentListVO;
import com.ruida.mockdao.vo.information.InformationContentSimpleVO;

/**
 * <p>
 * 首页资讯文章列表 服务类
 * </p>
 *
 * @author wy
 * @since 2021-08-16
 */
public interface TInformationColumnContentService extends IService<TInformationColumnContent> {

	/**
	 * 根据分页获取栏目内的资讯列表。 返回的对象根据业务的展示数据做了相应的调整
	 * 
	 * @param columnId 栏目id
	 * @param page
	 * @return
	 */
	Page<InformationContentListVO> selectByColumnPage(Integer columnId, Page<InformationContentListVO> page);

	/**
	 * 取最新的n条资讯，根据上架时间排序。 用于首页展示所以返回了精简的vo对象
	 * 
	 * @param limit 返回的资讯数量
	 * @return
	 */
	List<InformationContentSimpleVO> selectByDescLimit(Integer limit);
}
