package com.ruida.mockservice.service;

/**
 * 此服务的主要作用是进行密码托管
 * @author mazhuang
 *
 */
public interface SysCryptoService {
	/**
	 * 系统统一的加密服务
	 * @param content
	 * @return
	 */
	public String AESEncode(String content);

	/*
	 * 解密 
	 */
	public String AESDncode(String content);


	/**
	 *	解密(专用于前端接收的加密数据解密)
	 * @param content
	 * @return
	 */
	public String AESDncode(String content,String key);


}
