package com.ruida.cloud.dao;

import com.ruida.cloud.model.DiscountActivityItem;
import com.ruida.cloud.model.DiscountActivityItemExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface DiscountActivityItemMapper {
    long countByExample(DiscountActivityItemExample example);

    int deleteByExample(DiscountActivityItemExample example);

    int deleteByPrimaryKey(Integer discountActivityItemId);

    int insert(DiscountActivityItem record);

    int insertSelective(DiscountActivityItem record);

    List<DiscountActivityItem> selectByExample(DiscountActivityItemExample example);

    DiscountActivityItem selectByPrimaryKey(Integer discountActivityItemId);

    int updateByExampleSelective(@Param("record") DiscountActivityItem record, @Param("example") DiscountActivityItemExample example);

    int updateByExample(@Param("record") DiscountActivityItem record, @Param("example") DiscountActivityItemExample example);

    int updateByPrimaryKeySelective(DiscountActivityItem record);

    int updateByPrimaryKey(DiscountActivityItem record);
}