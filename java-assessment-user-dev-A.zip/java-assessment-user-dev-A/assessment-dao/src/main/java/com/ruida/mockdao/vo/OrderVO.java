package com.ruida.mockdao.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;

/**
 * @description: 订单实体类VO
 * @author: Bhj
 * @create: 2020-07-20
 */
@Data
public class OrderVO {
    /**
     * 订单ID
     */
    private Integer orderId;
    /**
     * 订单编号
     */
    private String orderNo;
    /**
     * 订单名称
     */
    private String orderName;
    /**
     * 订单类型（0-试卷 1-套卷 2-报告）
     */
    private Integer orderType;
    /**
     * 订单类型名称（0-试卷 8-志愿填报）
     */
    private String orderTypeName;
    /**
     * 订单金额
     */
    private BigDecimal orderAmount;
    /**
     * 订单金额，转换字符串格式
     */
    private String orderAmountStr;
    /**
     * 商品id
     */
    private Integer productId;
    /**
     * 报告id
     */
    private Integer reportId;
    /**
     * 折扣金额
     */
    private BigDecimal saleAmount;
    /**
     * 实付金额
     */
    private BigDecimal payAmount;
    /**
     * 实付金额，转换字符串格式
     */
    private String payAmountStr;

    /**
     * 支付方式
     */
    private Integer paymentType;

    /**
     * 支付方式名称
     */
    private String paymentTypeName;

    /**
     * 购买人姓名
     */
    private String purchaserName;
    /**
     * 购买人联系电话
     */
    private String telephone;
    /**
     * 订单状态（0—待支付；1—已支付；2—已关闭; 3-待确认；4-退款中；5-已退款）
     */
    private Integer status;
    /**
     * 订单创建时间
     */
    @JsonFormat(pattern= "yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date createTime;
    /**
     * 订单付款时间
     */
    @JsonFormat(pattern= "yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date paymentTime;
    /**
     * 商品原价
     */
    private BigDecimal productOriginPrice;
    /**
     * 商品现价(安卓和PC端)
     */
    private BigDecimal productPrice;
    /**
     * 商品现价(IOS)
     */
    private BigDecimal productIosPrice;
    /**
     * 商品图片
     */
    private String productImg;
    /**
     * 是否是套卷
     */
    private Integer iscompose;

    /**
     * 年级
     */
    private String stageName;

    /**
     * 年级名
     */
    private String gradeName;
    /**
     * 科目
     */
    private String subjectName;
    /**
     * 年份
     */
    private String years;
    /**
     * 版本
     */
    private String versionName;
    /**
     * 已购买人数
     */
    private Integer purchaseNum;
    private Integer realBuyNum;
    /**
     * 剩余学币(IOS)
     */
    private BigDecimal studyCoin;
    /**
     * 商品包含的试卷
     */
    private ArrayList testPaper;

}
