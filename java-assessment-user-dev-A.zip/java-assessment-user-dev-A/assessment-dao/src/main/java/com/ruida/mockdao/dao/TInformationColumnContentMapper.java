package com.ruida.mockdao.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.model.TInformationColumnContent;

/**
 * <p>
 * 首页资讯文章列表 Mapper 接口
 * </p>
 *
 * @author wy
 * @since 2021-08-16
 */
public interface TInformationColumnContentMapper extends BaseMapper<TInformationColumnContent> {

}
