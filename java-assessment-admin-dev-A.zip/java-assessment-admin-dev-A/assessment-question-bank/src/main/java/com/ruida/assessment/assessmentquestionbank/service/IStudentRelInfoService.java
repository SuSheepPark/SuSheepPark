package com.ruida.assessment.assessmentquestionbank.service;
import com.baomidou.mybatisplus.service.IService;
import com.ruida.assessment.assessmentcommon.result.MapResult;
import com.ruida.assessment.assessmentquestionbank.model.SysUser;
import com.ruida.assessment.assessmentquestionbank.model.TStudentRelInfo;

import java.util.List;

/**
 * <p>
 * 学员关联信息表 服务类
 * </p>
 *
 * @author wy
 * @since 2020/8/13
 */
public interface IStudentRelInfoService extends IService<TStudentRelInfo> {

}
