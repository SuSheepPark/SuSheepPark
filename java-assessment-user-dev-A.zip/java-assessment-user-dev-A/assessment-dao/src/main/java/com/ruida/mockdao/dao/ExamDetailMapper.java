package com.ruida.mockdao.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.model.ExamDetail;
import com.ruida.mockdao.vo.NodeVO;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * 考试详情表 Mapper 接口
 * </p>
 *
 * @author chenjy
 * @since 2020-07-15
 */
public interface ExamDetailMapper extends BaseMapper<ExamDetail> {

    List<NodeVO> getAnswerSheet(@Param("examRecordId") Integer examRecordId);

    List<NodeVO> getAnalysis(Map<String,Object> param);

    /*
     * 统计做题总量
     * @param userId
     * @return
     */
    Integer countTotalNum(@Param("userId") Integer userId);

    /*
     * 更新答题记录明细表
     * @param detail
     * @return
     */
    Integer updateExamDetailById(@Param("req") ExamDetail detail);

    /*
     * 根据考试记录id查询考试明细
     * @param examRecordId
     * @return
     */
    List<ExamDetail> selectExamDetailByRecordId(@Param("examRecordId") int examRecordId);
}
