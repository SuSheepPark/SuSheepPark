package com.ruida.common;

import lombok.Data;


@Data
public class XiaoGuanJiaParam {

    //提供给校管家的token
    public static String XIAOGJ_TOKEN = "Ds54v9b28s912f42m59so1ruidacloud";

    //加密签名，signature结合了开发者填写的token参数和请求中的timestamp参数、nonce参数
    private String signature;

    //时间戳
    private String timestamp;

    //随机数
    private String nonce;

    //公司ID
    private String companyid;

    //应用ID
    private String appid;

    //事件类型，对应上述事件代码，开发者根据此类型处理对应业务。
    private String eventkey;

    //业务数据id，开发者根据此id调用相应业务接口获取所需数据。
    private String eventid;

    //事件产生时间(格式yyyyMMddHHmmssfff)
    private String eventtime;

    private String customwone;


}
