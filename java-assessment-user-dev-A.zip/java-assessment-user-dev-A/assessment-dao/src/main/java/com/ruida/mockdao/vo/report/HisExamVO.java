package com.ruida.mockdao.vo.report;

import java.io.Serializable;
import java.util.List;

/**
 * @description: 历次统一测试成绩
 * @author: kgz
 * @date: 2020/12/24
 */
public class HisExamVO implements Serializable {

    /**
     * 历次统一测试名称
     */
    private List<String> historyExamName;

    /**
     * 历次统一测试成绩信息
     */
    private List<HisSubjectScoreInfoVO> historyScoreInfo;

    /**
     * 历次统一测试成绩所有科目总分
     */
    private HisSubjectScoreInfoVO allSubjectScoreInfo;

    public List<String> getHistoryExamName() {
        return historyExamName;
    }

    public void setHistoryExamName(List<String> historyExamName) {
        this.historyExamName = historyExamName;
    }

    public List<HisSubjectScoreInfoVO> getHistoryScoreInfo() {
        return historyScoreInfo;
    }

    public void setHistoryScoreInfo(List<HisSubjectScoreInfoVO> historyScoreInfo) {
        this.historyScoreInfo = historyScoreInfo;
    }

    public HisSubjectScoreInfoVO getAllSubjectScoreInfo() {
        return allSubjectScoreInfo;
    }

    public void setAllSubjectScoreInfo(HisSubjectScoreInfoVO allSubjectScoreInfo) {
        this.allSubjectScoreInfo = allSubjectScoreInfo;
    }
}
