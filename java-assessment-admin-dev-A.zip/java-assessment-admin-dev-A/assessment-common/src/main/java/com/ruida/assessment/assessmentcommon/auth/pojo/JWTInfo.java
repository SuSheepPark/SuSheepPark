package com.ruida.assessment.assessmentcommon.auth.pojo;

import java.io.Serializable;

/**
 * JWTInfo  带的用户信息
 * @author mlzhang
 */
public class JWTInfo implements Serializable {
    private String username;
    private String userId;
    private String source;
    //学生id
    private String stuId;
    //用户密码
    private String password;
    private String roleId;
    private String roleType ;
    private String roleName ;
    private String personId;
    private String deptId;


    public JWTInfo(){}

    public JWTInfo(String username, String userId, String source , String personId,String roleType,String deptId) {
        this.username = username;
        this.userId = userId;
        this.source = source;
        this.personId = personId;
        this.roleType = roleType;
        this.deptId = deptId;
    }

    public String getPersonId() {
        return personId;
    }

    public void setPersonId(String personId) {
        this.personId = personId;
    }

    public String getRoleId() {
        return roleId;
    }

    public void setRoleId(String roleId) {
        this.roleId = roleId;
    }

    public String getRoleType() {
        return roleType;
    }

    public void setRoleType(String roleType) {
        this.roleType = roleType;
    }

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getStuId() {
        return stuId;
    }

    public void setStuId(String stuId) {
        this.stuId = stuId;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getDeptId() {
        return deptId;
    }

    public void setDeptId(String deptId) {
        this.deptId = deptId;
    }

    @Override
    public String toString() {
        return "JWTInfo{" +
                "username='" + username + '\'' +
                ", userId='" + userId + '\'' +
                ", source='" + source + '\'' +
                '}';
    }


}
