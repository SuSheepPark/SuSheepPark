package com.ruida.assessment.assessmentquestionbank.imports.domain.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.xwpf.usermodel.IBodyElement;

import com.ruida.assessment.assessmentquestionbank.imports.application.Docx2HTMLProcessingFactory;
import com.ruida.assessment.assessmentquestionbank.imports.docx.DocxReader;
import com.ruida.assessment.assessmentquestionbank.imports.docx.DocxService;
import com.ruida.assessment.assessmentquestionbank.imports.domain.model.ErrorMsgException;
import com.ruida.assessment.assessmentquestionbank.imports.domain.model.QuestionAnswer;
import com.ruida.assessment.assessmentquestionbank.imports.domain.model.QuestionAnswerItem;
import com.ruida.assessment.assessmentquestionbank.imports.domain.model.QuestionBaseConfig;
import com.ruida.assessment.assessmentquestionbank.imports.domain.model.QuestionBlock;
import com.ruida.assessment.assessmentquestionbank.imports.domain.model.QuestionConfig;
import com.ruida.assessment.assessmentquestionbank.imports.domain.model.QuestionContent;
import com.ruida.assessment.assessmentquestionbank.imports.domain.model.QuestionContentItem;
import com.ruida.assessment.assessmentquestionbank.imports.domain.model.QuestionExplain;
import com.ruida.assessment.assessmentquestionbank.imports.domain.model.QuestionKnowledge;
import com.ruida.assessment.assessmentquestionbank.imports.domain.model.QuestionKnowledgeItem;
import com.ruida.assessment.assessmentquestionbank.imports.domain.model.QuestionRemark;

public abstract class QuestionProtocol {

	public static final String QUESTION_START = "####";
	public static final String BLOCK_START = "###";
	public static final String CONTENT_START = "#试题内容#";
	public static final String OPTION_ITEM = "#选项#";
	public static final String ANSWER_START = "#答案#";
	public static final String EXPLAIN_START = "#试题分析#";
	public static final String REMARK_START = "#备注#";
	public static final String KNOWLEGDE_START = "#知识点#";
	public static final String MODEL = "#";
	public static final String SPLIT = "\\|";
	public static final String OR = "|||";

	protected DocxReader reader;

	public QuestionProtocol(DocxReader reader) {
		this.reader = reader;
	}

	public static Boolean checkStart(String line) {
		return (!StringUtils.isEmpty(line)) && line.startsWith(QUESTION_START);
	}

	public abstract Boolean checkIdentification();

	protected abstract String formatAnswerItem(String lineString);

	public static void step2Question(DocxReader reader) {
		reader.stepTo(QUESTION_START);
	}

	public static String getQuestionName(DocxReader reader) {
		String lineString = DocxService.getLineText(reader.getLine());
		return lineString.substring(QUESTION_START.length());
	}

	public static QuestionConfig getQuestionConfig(DocxReader reader) throws ErrorMsgException {
		String lineString = DocxService.getLineText(reader.getLine());
		while ((StringUtils.isEmpty(lineString) || lineString.startsWith(MODEL)) && reader.next()) {
			lineString = DocxService.getLineText(reader.getLine());
		}
		String[] split = lineString.split(SPLIT, -1);
		if (split.length != 9) {
			throw new ErrorMsgException(reader.getLineNum(), "试题配置缺相，需要9项但实际收到为" + split.length);
		}
		String questionType = split[0];
		if (StringUtils.isEmpty(questionType)) {
			throw new ErrorMsgException(reader.getLineNum(), "试题类型为必填项");
		}
		String difficulty = split[1];
//		if (StringUtils.isEmpty(difficulty)) {
//			throw new ErrorMsgException(reader.getLineNum(), "难度为必填项");
//		}
		String publicLevel = split[2];
//		if (StringUtils.isEmpty(publicLevel)) {
//			throw new ErrorMsgException(reader.getLineNum(), "保密等级为必填项");
//		}
		String uploadPhoto = split[3];
		String autoCorrection = split[4];
		String score = split[5];
		String source = split[6];
		String use = split[7];
		String length = split[8];

		QuestionConfig config = new QuestionConfig();
		config.setQuestionType(questionType);
		config.setDifficulty(difficulty);
		config.setPublicLevel(publicLevel);
		config.setScore(score);
		config.setSource(source);
		config.setUse(use);
		config.setLength(length);
		config.setAutoCorrection(autoCorrection);
		config.setUploadPhoto(uploadPhoto);
		return config;
	}

	public abstract QuestionBlock parseBlock(QuestionBaseConfig config) throws ErrorMsgException;

	protected abstract QuestionContent getContent() throws ErrorMsgException;

	protected String getContentString() {
		StringBuffer sb = new StringBuffer();
		String lineString = "";
		do {
			IBodyElement element = reader.getLine();
			lineString = DocxService.getLineText(element);
			if (lineString.startsWith(MODEL) && !lineString.startsWith(CONTENT_START)) {
				break;
			}
			String textHTML = Docx2HTMLProcessingFactory.element2HTML(element, CONTENT_START);
			if (!StringUtils.isEmpty(textHTML)) {
				sb.append(textHTML);
			}
		} while (reader.next());
		return sb.toString();
	}

	protected List<QuestionContentItem> getContentItems() {
		int number = 1;
		StringBuffer sb;
		String lineString = DocxService.getLineText(reader.getLine());
		List<QuestionContentItem> items = new ArrayList<QuestionContentItem>();
		while (lineString != null && !lineString.startsWith(ANSWER_START)) {
			sb = new StringBuffer();
			do {
				IBodyElement element = reader.getLine();

				String textHTML = Docx2HTMLProcessingFactory.element2HTML(element, OPTION_ITEM);
				if (!StringUtils.isEmpty(textHTML)) {
					sb.append(textHTML);
				}
				if (!reader.next()) {
					break;
				}
				lineString = DocxService.getLineText(reader.getLine());
			} while (!lineString.startsWith(MODEL));
			QuestionContentItem contentItem = new QuestionContentItem();
			contentItem.setItemContent(sb.toString());
			contentItem.setNumber(number);
			items.add(contentItem);
			number++;
			if (!reader.hasNext()) {
				break;
			}
		}
		return items;
	}

	protected QuestionAnswer getAnswer(Boolean isSupportRichText) throws ErrorMsgException {
		String lineString = reader.stepTo(ANSWER_START, QUESTION_START);
		QuestionAnswer answer = new QuestionAnswer();

		reader.next();
		String nextLineString = DocxService.getLineText(reader.getLine());
		if (nextLineString.startsWith(EXPLAIN_START)) {
			if (isSupportRichText) {
				IBodyElement element = reader.getLine();
				lineString = Docx2HTMLProcessingFactory.element2HTML(element, MODEL);
			} else {
				lineString = formatAnswerItem(lineString.substring(ANSWER_START.length()));
			}
			if (!StringUtils.isEmpty(lineString)) {
				QuestionAnswerItem answerItem = new QuestionAnswerItem();
				answerItem.setAnswer(lineString);
				answer.addItem(answerItem);
			}
		} else {
			if (ANSWER_START.length() < lineString.length()) {
				lineString = lineString.substring(ANSWER_START.length());
				answer.setAnswerType(lineString);
			}
			do {
//				lineString = DocxService.getLineText(reader.getLine());
				if (lineString.startsWith(EXPLAIN_START) || lineString.startsWith(REMARK_START)
						|| lineString.startsWith(QUESTION_START) || lineString.startsWith(BLOCK_START)) {
					break;
				}

				StringBuffer sb = new StringBuffer();
				do {
					IBodyElement element = reader.getLine();

					if (isSupportRichText) {
						String textHTML = Docx2HTMLProcessingFactory.element2HTML(element, MODEL);
						if (!StringUtils.isEmpty(textHTML)) {
							sb.append(textHTML);
						}
					} else {
						lineString = DocxService.getLineText(reader.getLine());
						if (lineString.startsWith(MODEL)) {
							lineString = lineString.substring(MODEL.length());
						}
						sb.append(lineString);
					}
					if (!reader.next()) {
						break;
					}
					lineString = DocxService.getLineText(reader.getLine());
				} while (!lineString.startsWith(MODEL));

				String sbString = sb.toString();
				if (StringUtils.isEmpty(sbString)) {
					continue;
				}
				QuestionAnswerItem answerItem = new QuestionAnswerItem();
				answerItem.setAnswer(formatAnswerItem(sbString));
				answer.addItem(answerItem);
			} while (reader.hasNext());
		}

		return answer;
	}

	protected QuestionExplain getExplain() throws ErrorMsgException {
		String lineString = reader.stepTo(EXPLAIN_START + ".*|" + BLOCK_START + ".*|" + QUESTION_START);
		StringBuffer sb = new StringBuffer();
		do {
			IBodyElement element = reader.getLine();
			lineString = DocxService.getLineText(element);
			if (lineString.startsWith(REMARK_START) || lineString.startsWith(QUESTION_START)
					|| lineString.startsWith(BLOCK_START)) {
				break;
			}
			String textHTML = Docx2HTMLProcessingFactory.element2HTML(element, EXPLAIN_START);
			if (!StringUtils.isEmpty(textHTML)) {
				sb.append(textHTML);
			}
		} while (reader.next());
		QuestionExplain explain = new QuestionExplain();
		explain.setExplain(sb.toString());
		return explain;
	}

	protected QuestionRemark getRemark() throws ErrorMsgException {
		String lineString = reader.stepTo(REMARK_START + ".*|" + BLOCK_START + ".*|" + QUESTION_START);
		if (StringUtils.isEmpty(lineString)) {
			return null;
		}
		StringBuffer sb = new StringBuffer();
		do {
			lineString = DocxService.getLineText(reader.getLine());
			if (lineString.startsWith(KNOWLEGDE_START) || lineString.startsWith(BLOCK_START)
					|| lineString.startsWith(QUESTION_START)) {
				break;
			}
			if (lineString.startsWith(REMARK_START)) {
				lineString = lineString.substring(REMARK_START.length());
			}
			sb.append(lineString);

		} while (reader.next());
		QuestionRemark remark = new QuestionRemark();
		remark.setRemark(sb.toString());
		return remark;
	}

	protected QuestionKnowledge getKnowledge() throws ErrorMsgException {
		String lineString = reader.stepTo(KNOWLEGDE_START + ".*|" + BLOCK_START + ".*|" + QUESTION_START);
		if (StringUtils.isEmpty(lineString)) {
			return null;
		}
		QuestionKnowledge knowledge = null;
		if (lineString.startsWith(KNOWLEGDE_START)) {
			knowledge = new QuestionKnowledge();
			while (reader.next()) {
				lineString = DocxService.getLineText(reader.getLine());
				if (!lineString.startsWith(MODEL)) {
					continue;
				}
				if (lineString.startsWith(QUESTION_START)) {
					break;
				}
				if (lineString.startsWith(BLOCK_START)) {
					break;
				}
				lineString = lineString.substring(MODEL.length());
				String[] split = lineString.split(SPLIT);
				if (split.length != 2) {
					throw new ErrorMsgException(reader.getLineNum(), "知识点格式错误，应该为'#xxx-yyy|d',实际为：" + lineString);
				}
				QuestionKnowledgeItem knowledgeItem = new QuestionKnowledgeItem();
				knowledgeItem.setKnowledgeString(split[0]);
				knowledgeItem.setWeight(split[1]);
				knowledge.addItem(knowledgeItem);

			}
		}
		return knowledge;
	}

	public static QuestionBaseConfig getQuestionBlockConfig(DocxReader reader) throws ErrorMsgException {
		String lineString = DocxService.getLineText(reader.getLine());
		while ((StringUtils.isEmpty(lineString) || lineString.startsWith(MODEL)) && reader.next()) {
			lineString = DocxService.getLineText(reader.getLine());
		}
		String[] split = lineString.split(SPLIT, -1);
		if (split.length != 3) {
			throw new ErrorMsgException(reader.getLineNum(), "组合题子题目配置缺相，需要3项但实际收到为" + split.length);
		}
		String questionType = split[0];
		if (StringUtils.isEmpty(questionType)) {
			throw new ErrorMsgException(reader.getLineNum(), "试题类型为必填项");
		}
		String uploadPhoto = split[1];
		if (StringUtils.isEmpty(uploadPhoto)) {
			throw new ErrorMsgException(reader.getLineNum(), "批改方式为必填项");
		}
		String autoCorrection = split[2];
		if (StringUtils.isEmpty(autoCorrection)) {
			throw new ErrorMsgException(reader.getLineNum(), "是否支持拍照上传答案为必填项");
		}
		QuestionBaseConfig config = new QuestionBaseConfig();
		config.setQuestionType(questionType);
		config.setAutoCorrection(autoCorrection);
		config.setUploadPhoto(uploadPhoto);
		return config;
	}
}
