package com.ruida.mockdao.vo.report;

import lombok.Data;

/**
 * @author chenjy
 * @date 2021/3/9
 */
@Data
public class UnionExamRecordVO {

    private Integer userId;

    private Double score;

    private Integer schoolId;

    private Integer classId;

    private Integer testWay;
}
