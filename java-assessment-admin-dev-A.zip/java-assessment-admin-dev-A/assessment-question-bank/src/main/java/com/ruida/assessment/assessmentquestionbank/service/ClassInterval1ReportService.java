package com.ruida.assessment.assessmentquestionbank.service;

import java.util.Map;

import org.apache.poi.xwpf.usermodel.XWPFDocument;

/**
 * @description: 班级测试报告 业务层接口
 * @author: kgz
 * @date: 2020/10/19
 */
public interface ClassInterval1ReportService {

	/**
	 * 生成班级报告
	 * 
	 * @param productId
	 * @param testpaperId
	 * @param schoolId
	 * @param classId
	 * @param cache
	 * @return
	 */
	XWPFDocument getReportDocument(Integer testpaperId,Integer productId, Integer schoolId, Integer classId, Integer constRangeId,
			Map<String, Object> cache);
}
