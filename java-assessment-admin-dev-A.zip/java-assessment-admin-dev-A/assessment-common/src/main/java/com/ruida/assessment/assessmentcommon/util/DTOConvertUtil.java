package com.ruida.assessment.assessmentcommon.util;

import com.alibaba.fastjson.JSON;
import lombok.extern.slf4j.Slf4j;

/**
 * @author xumingqi
 * @date 2020/12/15 16:17
 */
@Slf4j
public class DTOConvertUtil {
    public static <T> T convertSourceToTarget(Object source, Class<T> targetClazz) {
        T result;
        JSON json = (JSON) JSON.toJSON(source);
        result = JSON.toJavaObject(json, targetClazz);
        if (result == null) {
            try {
                result = targetClazz.newInstance();
            } catch (Exception e) {
                log.info("convertSourceToTarget failed! source:" + JSON.toJSONString(source) + ", targetClazz:" + targetClazz.getName());
            }
        }
        return result;
    }
}
