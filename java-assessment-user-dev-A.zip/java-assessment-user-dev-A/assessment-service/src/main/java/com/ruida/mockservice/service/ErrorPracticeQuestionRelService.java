package com.ruida.mockservice.service;

import com.baomidou.mybatisplus.service.IService;
import com.ruida.mockdao.dto.ErrorPracticeReq;
import com.ruida.mockdao.model.ErrorPracticeQuestionRel;
import com.ruida.mockdao.vo.error.QuestionTypeVO;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

/**
 * <p>
 * 错题练习和试题关联表 服务类
 * </p>
 *
 * @author chenjy
 * @since 2020-10-16
 */
@Service
public interface ErrorPracticeQuestionRelService extends IService<ErrorPracticeQuestionRel> {

    Integer createErrorPractice(@RequestBody ErrorPracticeReq req);

    List<QuestionTypeVO> queryErrorPracticeDetail(Integer practiceId);
}
