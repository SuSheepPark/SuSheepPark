package com.ruida.assessment.assessmentquestionbank.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.assessment.assessmentcommon.result.Page;
import com.ruida.assessment.assessmentquestionbank.model.TQuestionPurpose;
import com.ruida.assessment.assessmentquestionbank.vo.BaseFieldVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @description: 试题用途dao层接口
 * @author: kgz
 * @date: 2020/6/10
 */
@Mapper
public interface QuestionPurposeMapper extends BaseMapper<TQuestionPurpose> {

    /**
     * 分页查询列表
     * @param page
     * @return
     */
    List<BaseFieldVO> queryList(@Param("page") Page page);

    /**
     * 列表数据条数
     * @return
     */
    Integer countQueryList();

}
