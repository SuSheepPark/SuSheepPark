/**   
 * Copyright © 2019 公司名. All rights reserved.
 * 
 * @Title: ChannelController.java 
 * @Prject: zhaowei-cms
 * @Package: com.zhaowei.cms.controller 
 * @Description: TODO
 * @author: zw   
 * @date: 2019年9月17日 下午8:45:53 
 * @version: V1.0   
 */
package com.zhaowei.cms.controller;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.zhaowei.cms.domain.Channel;
import com.zhaowei.cms.service.ChannelService;

/** 
 * @ClassName: ChannelController 
 * @Description: 栏目的controller
 * @author: zw
 * @date: 2019年9月17日 下午8:45:53  
 */
@RequestMapping("channel")
@Controller
public class ChannelController {

	@Resource
	private ChannelService channelService;
	
	@ResponseBody
	@GetMapping("selects")
	public List<Channel> selects(){
		return channelService.selects();
	}
	
	
}
