package com.ruida.mockservice.service.impl;

import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.ruida.mockcommon.enums.QuestionTypeEnum;
import com.ruida.mockcommon.exception.CoreException;
import com.ruida.mockdao.dao.ErrorPracticeQuestionRelMapper;
import com.ruida.mockdao.dto.ErrorPracticeReq;
import com.ruida.mockdao.model.ErrorPracticeQuestionRel;
import com.ruida.mockdao.vo.error.QuestionTypeVO;
import com.ruida.mockservice.service.ErrorPracticeQuestionRelService;
import com.ruida.mockservice.service.TestPaperService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;

/**
 * <p>
 * 错题练习和试题关联表 服务实现类
 * </p>
 *
 * @author chenjy
 * @since 2020-10-16
 */
@Service
public class ErrorPracticeQuestionRelServiceImpl extends ServiceImpl<ErrorPracticeQuestionRelMapper, ErrorPracticeQuestionRel> implements ErrorPracticeQuestionRelService {

    @Resource
    private ErrorPracticeQuestionRelMapper errorPracticeQuestionRelMapper;
    @Resource
    private TestPaperService testPaperService;
    @Resource
    private PracticeServiceRandomImpl practiceServiceRandom;
    @Resource
    private PracticeServiceKnowledgeImpl practiceServiceKnowledge;

    @Transactional(rollbackFor = Exception.class)
    @Override
    public Integer createErrorPractice(ErrorPracticeReq req) {
        //1-随机抽题;2-根据知识点抽题
        Integer type = req.getType();
        if (type == 1) {
            return practiceServiceRandom.createPractice(req);
        } else if (type == 2) {
            return practiceServiceKnowledge.createPractice(req);
        } else {
            throw new CoreException("500", "参数错误");
        }
    }

    @Override
    public List<QuestionTypeVO> queryErrorPracticeDetail(Integer practiceId) {
        List<QuestionTypeVO> questionTypeList = errorPracticeQuestionRelMapper.queryErrorPracticeDetail(practiceId);
        //处理组合题
        questionTypeList.forEach(x -> {
            if (x.getQuestionTypeId().equals(QuestionTypeEnum.CQT.getK())) {
                x.getQuestionList().forEach(y -> y.setChild(errorPracticeQuestionRelMapper.querySubQuestionInfo(y.getQuestionId())));
            }
        });

        questionTypeList.forEach(x -> x.getQuestionList().forEach(y -> testPaperService.handleQuestionVO(y)));

        return questionTypeList;
    }
}
