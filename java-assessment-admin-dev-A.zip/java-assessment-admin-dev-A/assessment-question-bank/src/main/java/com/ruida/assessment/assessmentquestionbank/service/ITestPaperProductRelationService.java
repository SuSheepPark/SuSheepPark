package com.ruida.assessment.assessmentquestionbank.service;

import com.baomidou.mybatisplus.service.IService;
import com.ruida.assessment.assessmentquestionbank.model.TTestPaperProductRel;

import java.util.List;

/**
 * @author wy
 * @description  试卷-商品关联管理服务层接口
 * @date 2020/6/24
 */
public interface ITestPaperProductRelationService extends IService<TTestPaperProductRel> {

	/*
     *功能描述 根据浏览量返回试卷id的排序列表
     * @param
     * @return
     */
    List<Integer> selectTestPaperIdsOrderByBrowse();

    /**
     * 查询引用某个试卷的商品数量
     * @param testPaperId
     * @param status
     * @return
     */
    int getProductUsedTestPaper(Integer testPaperId, Integer status);
}
