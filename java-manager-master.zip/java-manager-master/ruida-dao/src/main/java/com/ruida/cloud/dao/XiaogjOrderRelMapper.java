package com.ruida.cloud.dao;

import com.ruida.cloud.model.XiaogjOrderRel;
import com.ruida.cloud.model.XiaogjOrderRelExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface XiaogjOrderRelMapper {
    int countByExample(XiaogjOrderRelExample example);

    int deleteByExample(XiaogjOrderRelExample example);

    int deleteByPrimaryKey(Integer rid);

    int insert(XiaogjOrderRel record);

    int insertSelective(XiaogjOrderRel record);

    List<XiaogjOrderRel> selectByExample(XiaogjOrderRelExample example);

    XiaogjOrderRel selectByPrimaryKey(Integer rid);

    int updateByExampleSelective(@Param("record") XiaogjOrderRel record, @Param("example") XiaogjOrderRelExample example);

    int updateByExample(@Param("record") XiaogjOrderRel record, @Param("example") XiaogjOrderRelExample example);

    int updateByPrimaryKeySelective(XiaogjOrderRel record);

    int updateByPrimaryKey(XiaogjOrderRel record);
}