package com.ruida.assessment.assessmentquestionbank.dto;

import lombok.Data;

@Data
public class TReportProductWayPaperTypeRelDTO {


    //试卷Id
    private Integer testPaperId;

    //试卷性质(1-练习卷 2-高中联考卷1分1赋 3-高中联考卷3分1赋 4-高中联考卷必考科目 5-初中联考卷)
    private Integer paperUseType;

    //商品测验形式(0-平时练习 1-纸考(线下联考) 2-机房统考 3-在线统考)
    private Integer productTestWay;

}
