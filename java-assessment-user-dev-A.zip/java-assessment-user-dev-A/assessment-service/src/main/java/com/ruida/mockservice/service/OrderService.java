package com.ruida.mockservice.service;


import com.baomidou.mybatisplus.service.IService;
import com.ruida.mockcommon.result.Page;
import com.ruida.mockcommon.result.PageResult;
import com.ruida.mockcommon.result.PojoResult;
import com.ruida.mockdao.model.Order;
import com.ruida.mockdao.vo.OrderVO;
import com.ruida.mockdao.vo.order.OrderConfirmDetailVO;
import com.ruida.mockdao.vo.order.OrderDetailVO;

import java.math.BigDecimal;

/**
 * <p>
 * 订单信息表 服务类
 * </p>
 *
 * @author Bhj
 * @since 2020-07-20
 */
public interface OrderService extends IService<Order> {

    OrderConfirmDetailVO getConfirmOrderDetail(Integer productId, String testPaperIds, String presellTestPaperIds,
                                               String reportIds, String presellReportIds);

    Order createOrderV2(Integer productId, String testPaperIds, String presellTestPaperIds,
                        String reportIds, String presellReportIds, Integer source);

    Order getFreePaperAndReport(Integer productId, String testPaperIds, String presellTestPaperIds,
                                String reportIds, String presellReportIds, Integer source);

    PageResult<OrderVO> listUserOrder(Page<OrderVO> orderPage, Integer orderStatus, String orderName, Integer orderType, Integer payType, String createTime);

    PojoResult<OrderVO> getUserOrderDetail(String orderNo);

    OrderDetailVO getUserOrderDetailV2(String orderNo);

    Boolean cancelOrderById(Integer orderId);

    PojoResult<Order> createOrder(Integer productId, Integer source);

    Boolean addBuyNumAndRel(Order order);

    PojoResult<Order> createStudyCoinOrder(BigDecimal studyCoinNum);

    Boolean updateOrderStudyCoinStatus(Order checkOrder);

    PojoResult<Order> createReportOrder(Integer productId, Integer source, Integer testPaperId, Integer recordId);

    PojoResult<Order> createReportOrderNew(Integer productId, Integer reportId, Integer source);

    Boolean deleteOrder(Integer orderId);

    void createStudyCoinOrder(String transactionId, String productId, Integer isSandbox);
}
