package com.ruida.cloud.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ruida.common.SystemConstant;

import java.io.Serializable;
import java.util.Date;

public class CourseVideo implements Serializable {
    private Integer courseVideoId;

    private Integer courseId;

    /**
     * 课次ID
     */
    private Integer courseLessonId;
    /**
     * 视频类型（0—录播课视频；1—课次录播回看视频；2—课次作业讲解视频）
     */
    private Integer courseVideoType;

    private String vid;

    private String title;

    private String tag;

    private String swfLink;

    private String sourcefile;

    private String mp4;

    private Integer playerwidth;

    private Integer playerheight;

    private String duration;

    private String filesize;

    private String firstImage;

    private Integer times;

    private String context;

    private String originalDefinition;

    private String previewvid;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone= SystemConstant.TIME_ZONE)
    private Date ptime;

    private String cataid;

    private String defaultVideo;

    private Integer df;

    private String flv1;

    private String flv2;

    private String flv3;

    private String mp4_1;

    private String mp4_2;

    private String mp4_3;

    private String hls1;

    private String hls2;

    private String hls3;

    private String hlsindex;

    private Byte seed;

    private String status;

    private Integer sourceFilesize;

    private String md5checksum;

    private String images1;

    private String images2;

    private String images3;

    private String images4;

    private String images5;

    private String images6;

    private String imagesB1;

    private String imagesB2;

    private String imagesB3;

    private String imagesB4;

    private String imagesB5;

    private String imagesB6;

    private Integer createBy;

    @JsonFormat(pattern= SystemConstant.DATE_FORMAT,timezone=SystemConstant.TIME_ZONE)
    private Date createTime;

    private Integer updateBy;

    @JsonFormat(pattern= SystemConstant.DATE_FORMAT,timezone=SystemConstant.TIME_ZONE)
    private Date updateTime;

    private Byte isdelete;

    private static final long serialVersionUID = 1L;

    public Integer getCourseLessonId() {
        return courseLessonId;
    }

    public void setCourseLessonId(Integer courseLessonId) {
        this.courseLessonId = courseLessonId;
    }

    public Integer getCourseVideoType() {
        return courseVideoType;
    }

    public void setCourseVideoType(Integer courseVideoType) {
        this.courseVideoType = courseVideoType;
    }

    public Integer getCourseVideoId() {
        return courseVideoId;
    }

    public void setCourseVideoId(Integer courseVideoId) {
        this.courseVideoId = courseVideoId;
    }

    public Integer getCourseId() {
        return courseId;
    }

    public void setCourseId(Integer courseId) {
        this.courseId = courseId;
    }

    public String getVid() {
        return vid;
    }

    public void setVid(String vid) {
        this.vid = vid == null ? null : vid.trim();
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title == null ? null : title.trim();
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag == null ? null : tag.trim();
    }

    public String getSwfLink() {
        return swfLink;
    }

    public void setSwfLink(String swfLink) {
        this.swfLink = swfLink == null ? null : swfLink.trim();
    }

    public String getSourcefile() {
        return sourcefile;
    }

    public void setSourcefile(String sourcefile) {
        this.sourcefile = sourcefile == null ? null : sourcefile.trim();
    }

    public String getMp4() {
        return mp4;
    }

    public void setMp4(String mp4) {
        this.mp4 = mp4 == null ? null : mp4.trim();
    }

    public Integer getPlayerwidth() {
        return playerwidth;
    }

    public void setPlayerwidth(Integer playerwidth) {
        this.playerwidth = playerwidth;
    }

    public Integer getPlayerheight() {
        return playerheight;
    }

    public void setPlayerheight(Integer playerheight) {
        this.playerheight = playerheight;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration == null ? null : duration.trim();
    }

    public String getFilesize() {
        return filesize;
    }

    public void setFilesize(String filesize) {
        this.filesize = filesize == null ? null : filesize.trim();
    }

    public String getFirstImage() {
        return firstImage;
    }

    public void setFirstImage(String firstImage) {
        this.firstImage = firstImage == null ? null : firstImage.trim();
    }

    public Integer getTimes() {
        return times;
    }

    public void setTimes(Integer times) {
        this.times = times;
    }

    public String getContext() {
        return context;
    }

    public void setContext(String context) {
        this.context = context == null ? null : context.trim();
    }

    public String getOriginalDefinition() {
        return originalDefinition;
    }

    public void setOriginalDefinition(String originalDefinition) {
        this.originalDefinition = originalDefinition == null ? null : originalDefinition.trim();
    }

    public String getPreviewvid() {
        return previewvid;
    }

    public void setPreviewvid(String previewvid) {
        this.previewvid = previewvid == null ? null : previewvid.trim();
    }

    public Date getPtime() {
        return ptime;
    }

    public void setPtime(Date ptime) {
        this.ptime = ptime;
    }

    public String getCataid() {
        return cataid;
    }

    public void setCataid(String cataid) {
        this.cataid = cataid == null ? null : cataid.trim();
    }

    public String getDefaultVideo() {
        return defaultVideo;
    }

    public void setDefaultVideo(String defaultVideo) {
        this.defaultVideo = defaultVideo == null ? null : defaultVideo.trim();
    }

    public Integer getDf() {
        return df;
    }

    public void setDf(Integer df) {
        this.df = df;
    }

    public String getFlv1() {
        return flv1;
    }

    public void setFlv1(String flv1) {
        this.flv1 = flv1 == null ? null : flv1.trim();
    }

    public String getFlv2() {
        return flv2;
    }

    public void setFlv2(String flv2) {
        this.flv2 = flv2 == null ? null : flv2.trim();
    }

    public String getFlv3() {
        return flv3;
    }

    public void setFlv3(String flv3) {
        this.flv3 = flv3 == null ? null : flv3.trim();
    }

    public String getMp4_1() {
        return mp4_1;
    }

    public void setMp4_1(String mp4_1) {
        this.mp4_1 = mp4_1 == null ? null : mp4_1.trim();
    }

    public String getMp4_2() {
        return mp4_2;
    }

    public void setMp4_2(String mp4_2) {
        this.mp4_2 = mp4_2 == null ? null : mp4_2.trim();
    }

    public String getMp4_3() {
        return mp4_3;
    }

    public void setMp4_3(String mp4_3) {
        this.mp4_3 = mp4_3 == null ? null : mp4_3.trim();
    }

    public String getHls1() {
        return hls1;
    }

    public void setHls1(String hls1) {
        this.hls1 = hls1 == null ? null : hls1.trim();
    }

    public String getHls2() {
        return hls2;
    }

    public void setHls2(String hls2) {
        this.hls2 = hls2 == null ? null : hls2.trim();
    }

    public String getHls3() {
        return hls3;
    }

    public void setHls3(String hls3) {
        this.hls3 = hls3 == null ? null : hls3.trim();
    }

    public String getHlsindex() {
        return hlsindex;
    }

    public void setHlsindex(String hlsindex) {
        this.hlsindex = hlsindex == null ? null : hlsindex.trim();
    }

    public Byte getSeed() {
        return seed;
    }

    public void setSeed(Byte seed) {
        this.seed = seed;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status == null ? null : status.trim();
    }

    public Integer getSourceFilesize() {
        return sourceFilesize;
    }

    public void setSourceFilesize(Integer sourceFilesize) {
        this.sourceFilesize = sourceFilesize;
    }

    public String getMd5checksum() {
        return md5checksum;
    }

    public void setMd5checksum(String md5checksum) {
        this.md5checksum = md5checksum == null ? null : md5checksum.trim();
    }

    public String getImages1() {
        return images1;
    }

    public void setImages1(String images1) {
        this.images1 = images1 == null ? null : images1.trim();
    }

    public String getImages2() {
        return images2;
    }

    public void setImages2(String images2) {
        this.images2 = images2 == null ? null : images2.trim();
    }

    public String getImages3() {
        return images3;
    }

    public void setImages3(String images3) {
        this.images3 = images3 == null ? null : images3.trim();
    }

    public String getImages4() {
        return images4;
    }

    public void setImages4(String images4) {
        this.images4 = images4 == null ? null : images4.trim();
    }

    public String getImages5() {
        return images5;
    }

    public void setImages5(String images5) {
        this.images5 = images5 == null ? null : images5.trim();
    }

    public String getImages6() {
        return images6;
    }

    public void setImages6(String images6) {
        this.images6 = images6 == null ? null : images6.trim();
    }

    public String getImagesB1() {
        return imagesB1;
    }

    public void setImagesB1(String imagesB1) {
        this.imagesB1 = imagesB1 == null ? null : imagesB1.trim();
    }

    public String getImagesB2() {
        return imagesB2;
    }

    public void setImagesB2(String imagesB2) {
        this.imagesB2 = imagesB2 == null ? null : imagesB2.trim();
    }

    public String getImagesB3() {
        return imagesB3;
    }

    public void setImagesB3(String imagesB3) {
        this.imagesB3 = imagesB3 == null ? null : imagesB3.trim();
    }

    public String getImagesB4() {
        return imagesB4;
    }

    public void setImagesB4(String imagesB4) {
        this.imagesB4 = imagesB4 == null ? null : imagesB4.trim();
    }

    public String getImagesB5() {
        return imagesB5;
    }

    public void setImagesB5(String imagesB5) {
        this.imagesB5 = imagesB5 == null ? null : imagesB5.trim();
    }

    public String getImagesB6() {
        return imagesB6;
    }

    public void setImagesB6(String imagesB6) {
        this.imagesB6 = imagesB6 == null ? null : imagesB6.trim();
    }

    public Integer getCreateBy() {
        return createBy;
    }

    public void setCreateBy(Integer createBy) {
        this.createBy = createBy;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(Integer updateBy) {
        this.updateBy = updateBy;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Byte getIsdelete() {
        return isdelete;
    }

    public void setIsdelete(Byte isdelete) {
        this.isdelete = isdelete;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", courseVideoId=").append(courseVideoId);
        sb.append(", courseId=").append(courseId);
        sb.append(", vid=").append(vid);
        sb.append(", title=").append(title);
        sb.append(", tag=").append(tag);
        sb.append(", swfLink=").append(swfLink);
        sb.append(", sourcefile=").append(sourcefile);
        sb.append(", mp4=").append(mp4);
        sb.append(", playerwidth=").append(playerwidth);
        sb.append(", playerheight=").append(playerheight);
        sb.append(", duration=").append(duration);
        sb.append(", filesize=").append(filesize);
        sb.append(", firstImage=").append(firstImage);
        sb.append(", times=").append(times);
        sb.append(", context=").append(context);
        sb.append(", originalDefinition=").append(originalDefinition);
        sb.append(", previewvid=").append(previewvid);
        sb.append(", ptime=").append(ptime);
        sb.append(", cataid=").append(cataid);
        sb.append(", defaultVideo=").append(defaultVideo);
        sb.append(", df=").append(df);
        sb.append(", flv1=").append(flv1);
        sb.append(", flv2=").append(flv2);
        sb.append(", flv3=").append(flv3);
        sb.append(", mp4_1=").append(mp4_1);
        sb.append(", mp4_2=").append(mp4_2);
        sb.append(", mp4_3=").append(mp4_3);
        sb.append(", hls1=").append(hls1);
        sb.append(", hls2=").append(hls2);
        sb.append(", hls3=").append(hls3);
        sb.append(", hlsindex=").append(hlsindex);
        sb.append(", seed=").append(seed);
        sb.append(", status=").append(status);
        sb.append(", sourceFilesize=").append(sourceFilesize);
        sb.append(", md5checksum=").append(md5checksum);
        sb.append(", images1=").append(images1);
        sb.append(", images2=").append(images2);
        sb.append(", images3=").append(images3);
        sb.append(", images4=").append(images4);
        sb.append(", images5=").append(images5);
        sb.append(", images6=").append(images6);
        sb.append(", imagesB1=").append(imagesB1);
        sb.append(", imagesB2=").append(imagesB2);
        sb.append(", imagesB3=").append(imagesB3);
        sb.append(", imagesB4=").append(imagesB4);
        sb.append(", imagesB5=").append(imagesB5);
        sb.append(", imagesB6=").append(imagesB6);
        sb.append(", createBy=").append(createBy);
        sb.append(", createTime=").append(createTime);
        sb.append(", updateBy=").append(updateBy);
        sb.append(", updateTime=").append(updateTime);
        sb.append(", isdelete=").append(isdelete);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}