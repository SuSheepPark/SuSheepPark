package com.ruida.assessment.assessmentquestionbank.controller;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.ruida.assessment.assessmentcommon.enums.AppTypeEnum;
import com.ruida.assessment.assessmentcommon.enums.DeleteStatusEnum;
import com.ruida.assessment.assessmentcommon.result.PojoResult;
import com.ruida.assessment.assessmentquestionbank.annotaion.UserAuth;
import com.ruida.assessment.assessmentquestionbank.dto.AppVersionDetailDTO;
import com.ruida.assessment.assessmentquestionbank.model.TAppVersion;
import com.ruida.assessment.assessmentquestionbank.service.AppVersionService;
import com.ruida.assessment.assessmentquestionbank.vo.AppVersionDetailVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * @description: APP更新业务层
 * @author: kgz
 * @date: 2020/8/17
 */
@RequestMapping("/appVersion")
@Controller
@Api(value ="APP更新相关接口")
public class AppVersionController {

    @Resource
    private AppVersionService appVersionService;

    @UserAuth
    @ResponseBody
    @GetMapping("/getDetail/{type}")
    @ApiOperation(value = "根据类型获取APP更新信息详情", notes = "根据类型获取APP更新信息详情")
    public PojoResult getDetail(@PathVariable Integer type) {
        PojoResult pojoResult = new PojoResult();
        AppVersionDetailVO appVersionDetailVO = appVersionService.getAppVersionDetail(type);
        pojoResult.setContent(appVersionDetailVO);
        return pojoResult;
    }

    @UserAuth
    @ResponseBody
    @PostMapping("/save")
    @ApiOperation(value = "保存APP更新信息", notes = "保存APP更新信息")
    @ApiImplicitParam(name = "appVersionDTO", value = "查询条件",
            required = true, dataType = "AppVersionDTO", paramType = "body")
    public PojoResult save(@RequestBody AppVersionDetailDTO appVersionDetailDTO) {
        PojoResult pojoResult = new PojoResult();
        appVersionService.saveAppVersion(appVersionDetailDTO);
        return pojoResult;
    }

    @ApiOperation(value = "跳转APP下载页面", notes = "跳转APP下载页面")
    @RequestMapping(value = "/pushDownloadPage")
    public String pushDownloadPage(Model model) {
        //安卓
        EntityWrapper<TAppVersion> entityWrapper = new EntityWrapper<>();
        entityWrapper.andNew().eq("type", AppTypeEnum.ANDROID.getK())
                .eq("isdelete", DeleteStatusEnum.DELETE_FALSE.getK()).orderBy("app_version_id", false);
        List<TAppVersion> list = appVersionService.selectList(entityWrapper);
        TAppVersion tAppVersion = new TAppVersion();
        if (CollectionUtils.isNotEmpty(list)) {
            tAppVersion = list.get(0);
        }

        //iOS
        EntityWrapper<TAppVersion> entityWrapperIos = new EntityWrapper<>();
        entityWrapperIos.andNew().eq("type", AppTypeEnum.IOS.getK())
                .eq("isdelete",DeleteStatusEnum.DELETE_FALSE.getK()).orderBy("app_version_id", false);
        List<TAppVersion> ioslist = appVersionService.selectList(entityWrapperIos);
        TAppVersion tAppVersionIos = new TAppVersion();
        if (CollectionUtils.isNotEmpty(ioslist)) {
            tAppVersionIos = ioslist.get(0);
        }
        model.addAttribute("appPath", tAppVersion.getUrl());
        model.addAttribute("iosAppPath", tAppVersionIos.getUrl());
        return "appDownload";
    }
}