package com.ruida.mockdao.dto;

import lombok.Data;

@Data
public class WechatLoginDTO {

    /**
     * 登录code
     */
    private String code;

    /**
     * 手机号
     */
    private String telephone;

    /**
     * 加密数据
     */
    private String encryptedData;

    /**
     * 签名
     */
    private String signature;

    /**
     * 偏移向量 用于解密的IV
     */
    private String iv;

    /**
     * 不包括敏感信息的原始数据字符串，用于计算签名
     */
    private String rawData;

}
