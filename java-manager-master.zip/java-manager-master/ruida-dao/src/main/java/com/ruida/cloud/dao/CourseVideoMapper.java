package com.ruida.cloud.dao;

import com.ruida.cloud.model.CourseVideo;
import com.ruida.cloud.model.CourseVideoExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface CourseVideoMapper {
    int countByExample(CourseVideoExample example);

    int deleteByExample(CourseVideoExample example);

    int deleteByPrimaryKey(Integer courseVideoId);

    int insert(CourseVideo record);

    int insertSelective(CourseVideo record);

    List<CourseVideo> selectByExample(CourseVideoExample example);

    CourseVideo selectByPrimaryKey(Integer courseVideoId);

    int updateByExampleSelective(@Param("record") CourseVideo record, @Param("example") CourseVideoExample example);

    int updateByExample(@Param("record") CourseVideo record, @Param("example") CourseVideoExample example);

    int updateByPrimaryKeySelective(CourseVideo record);

    int updateByPrimaryKey(CourseVideo record);


    List<Map<String, Object>> listRecordVideoListByLessonId(Integer lessonId);
}