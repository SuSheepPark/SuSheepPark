package com.ruida.mockservice.service.impl;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.ruida.mockcommon.auth.context.BaseContextHandle;
import com.ruida.mockcommon.auth.pojo.JWTInfo;
import com.ruida.mockcommon.constant.Constants;
import com.ruida.mockcommon.constant.RedisConstant;
import com.ruida.mockcommon.enums.QuestionTypeEnum;
import com.ruida.mockcommon.redis.RedisManager;
import com.ruida.mockcommon.util.ValidateMT;
import com.ruida.mockdao.dao.ExamImageMapper;
import com.ruida.mockdao.dao.ExamRecordMapper;
import com.ruida.mockdao.dao.QuestionLibraryMapper;
import com.ruida.mockdao.dao.TestPaperMapper;
import com.ruida.mockdao.model.ExamDetail;
import com.ruida.mockdao.model.ExamRecord;
import com.ruida.mockdao.model.QuestionMark;
import com.ruida.mockdao.model.TScene;
import com.ruida.mockdao.pojo.Choice;
import com.ruida.mockdao.vo.QuestionVO;
import com.ruida.mockservice.service.*;
import net.sf.json.JSONArray;
import net.sf.json.JsonConfig;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Service
public class ExamQuestionLibraryDetailServiceImpl implements ExamQuestionLibraryDetailService {
    @Resource
    TestPaperMapper testPaperMapper;
    @Resource
    QuestionLibraryMapper questionLibraryMapper;
    @Resource
    ExamRecordMapper examRecordMapper;

    @Resource
    ExamImageMapper examImageMapper;

    @Resource
    RichTextService richTextService;

    @Resource
    private RedisManager redisManager;

    @Resource
    StringRedisTemplate stringRedisTemplate;

    @Resource
    TestPaperService testPaperService;
    @Resource
    TSceneService sceneService;
    @Resource
    ExamDetailService examDetailService;
    @Resource
    QuestionMarkService questionMarkService;


    public List<QuestionVO> getQuestionDetailList(String sceneId, String questionIds) {
        //参数校验
        Assert.notNull(sceneId, "场次id不能为空");
        Assert.notNull(questionIds, "试题id不能为空");
        JWTInfo jwt = BaseContextHandle.getJWTInfo();
        Integer stuId = Integer.valueOf(jwt.getStuId());
        TScene scene = sceneService.selectById(sceneId);
        Integer testPaperId = scene.getTestPaperId();
        //校验
        testPaperService.checkSceneInfo(scene, stuId);

        List<QuestionVO> resultList = new ArrayList<>();
        Integer userId = jwt.getUserId() == null ? null : Integer.valueOf(jwt.getUserId());

        Integer examRecordId = null;
        //获取缓存 根据场次id和学生id获取考试记录id
        String examRecordIdStr = stringRedisTemplate.opsForValue()
                .get(String.format(RedisConstant.GET_EXAM_RECORD_ID_KEY, sceneId, stuId));
        if (ValidateMT.isNotNull(examRecordIdStr)) {
            examRecordId = Integer.valueOf(examRecordIdStr);
        } else {  //获取未交卷的考试记录
            EntityWrapper<ExamRecord> wrapper = new EntityWrapper<>();
            wrapper.andNew().eq("scene_id", sceneId).eq("status", 1)
                    .eq("stu_id", stuId);
            List<ExamRecord> list = examRecordMapper.selectList(wrapper);
            if (!CollectionUtils.isEmpty(list)) {
                examRecordId = list.get(0).getId();
            }
        }

        String[] questionIdAry = questionIds.split(",");
        // 遍历id获取试题
        for (String questionId : questionIdAry) {
            QuestionVO detailVO;
            String questionRedisKey = String.format(RedisConstant.QUESTION_DETAIL, questionId);
            String questionVOStr = stringRedisTemplate.opsForValue().get(questionRedisKey);
            if (StringUtils.isNotEmpty(questionVOStr)) {
                detailVO = JSON.parseObject(questionVOStr, QuestionVO.class);
            } else {
                //获取试题详情(不包含答题信息)
                detailVO = questionLibraryMapper.getQuestionDetail(testPaperId,
                        questionId);
                //子题
                if (QuestionTypeEnum.CQT.getK().equals(detailVO.getQuestionTypeId())) {
                    detailVO.setChild(questionLibraryMapper.getChildQuestionDetail(testPaperId, questionId));
                }
                stringRedisTemplate.opsForValue().set(questionRedisKey, JSON.toJSONString(detailVO));
            }
            detailVO.setMark(0);
            //试题是否标记，只有c端用户使用时才有
            if (userId != null) {
                EntityWrapper<QuestionMark> entityWrapper = new EntityWrapper<>();
                entityWrapper.andNew().eq("question_id", questionId).eq("create_by", userId);
                if (questionMarkService.selectCount(entityWrapper) > 0) {
                    detailVO.setMark(1);
                }
            }

            //获取用户历史答题记录
            if (examRecordId != null) {
                if (CollectionUtils.isEmpty(detailVO.getChild())) {
                    EntityWrapper<ExamDetail> wrapper = new EntityWrapper<>();
                    wrapper.eq("exam_record_id", examRecordId).eq("question_id", questionId).eq("isdelete", 0);
                    ExamDetail examDetail = examDetailService.selectOne(wrapper);
                    if (examDetail != null) {
                        detailVO.setTempAnswer(examDetail.getAnswer());
                        detailVO.setAudioPlayCount(examDetail.getAudioPlayCount());
                    }
                } else {
                    //查询子题答案
                    for (QuestionVO childVO : detailVO.getChild()) {
                        EntityWrapper<ExamDetail> wrapper = new EntityWrapper<>();
                        wrapper.eq("exam_record_id", examRecordId).eq("question_id", childVO.getQuestionId()).eq("isdelete", 0);
                        ExamDetail examDetail = examDetailService.selectOne(wrapper);
                        if (examDetail != null) {
                            childVO.setTempAnswer(examDetail.getAnswer());
                            childVO.setAudioPlayCount(examDetail.getAudioPlayCount());
                        }
                    }
                }
            }

            //处理题干、选项、答案富文本等
            handleQuestionDetailVO(detailVO);

            resultList.add(detailVO);
        }
        return resultList;
    }

    private void handleQuestionDetailVO(QuestionVO detailVO) {

        // 处理富文本字段
        detailVO.setQuestionTitle(richTextService.getHtmlRTF(detailVO.getQuestionTitle()));

        // 处理选项
        if (StringUtils.isNotEmpty(detailVO.getStem())
                && !Constants.NULL_STR.equalsIgnoreCase(detailVO.getStem())) {
            JsonConfig cfg = new JsonConfig();
            cfg.setExcludes(new String[]{"isAnswer"});

            JSONArray jsonArray = JSONArray.fromObject(detailVO.getStem(), cfg);
            List<Choice> option = JSONArray.toList(jsonArray, new Choice(), cfg);
            detailVO.setOption(option);
        }

        Optional.ofNullable(detailVO.getOption()).orElseGet(ArrayList::new).stream().filter(Objects::nonNull).forEach(x -> x.setVal(richTextService.getHtmlRTF(x.getVal())));

        // 用户答案
        if (!StringUtils.isEmpty(detailVO.getTempAnswer())) {
            detailVO.setUserAnswer(JSON.parseArray(detailVO.getTempAnswer(), Choice.class));
        }

        JSONArray answer = JSONArray.fromObject(detailVO.getAnswer());
        detailVO.setAnswerNum(answer.size());


        // 子题递归调用
        if (CollectionUtils.isNotEmpty(detailVO.getChild())) {
            detailVO.getChild().forEach(this::handleQuestionDetailVO);
        }
    }
}
