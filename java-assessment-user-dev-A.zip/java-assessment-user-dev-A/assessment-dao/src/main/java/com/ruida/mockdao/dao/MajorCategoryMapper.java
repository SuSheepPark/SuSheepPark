package com.ruida.mockdao.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.model.MajorCategory;
import com.ruida.mockdao.vo.major.MajorGroupVO;

import java.util.List;

/**
 * <p>
 * 大学专业类表（不是专业表） Mapper 接口
 * </p>
 *
 * @author xumingqi
 * @since 2021-01-14
 */
public interface MajorCategoryMapper extends BaseMapper<MajorCategory> {
    List<MajorGroupVO> getAllMajorGroup();
    List<MajorGroupVO> getAllMajorGroupByUser(Integer userId);
    Integer countAllMajorGroupByUser(Integer userId);

}
