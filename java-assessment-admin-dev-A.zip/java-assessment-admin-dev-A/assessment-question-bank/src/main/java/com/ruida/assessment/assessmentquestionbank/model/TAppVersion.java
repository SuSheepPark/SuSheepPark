package com.ruida.assessment.assessmentquestionbank.model;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;

import java.io.Serializable;

/**
 * @description: APP版本信息数据库实体
 * @author: kgz
 * @date: 2020/8/17
 */
@TableName("t_app_version")
public class TAppVersion extends BaseColumn implements Serializable {
    private static final long serialVersionUID = -3504955218806584043L;
    /**
     * 主键ID
     */
    @TableId
    private Integer appVersionId;

    /**
     * 类型（1—安卓；2—IOS）
     */
    private Integer type;

    /**
     * 大版本号
     */
    private String versionCode;

    /**
     * 详细版本号
     */
    private String version;

    /**
     * 下载路径
     */
    private String url;

    /**
     * 下载路径配置方式(0-本地上传地址;1-第三方商店地址)
     */
    private Integer pathConfigMethod;

    /**
     * 文件名称
     */
    private String fileName;

    /**
     * 是否强制更新（0：不强制；1：强制）
     */
    private Integer isupdate;

    /**
     * 更新描述
     */
    private String remark;

    public Integer getAppVersionId() {
        return appVersionId;
    }

    public void setAppVersionId(Integer appVersionId) {
        this.appVersionId = appVersionId;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public String getVersionCode() {
        return versionCode;
    }

    public void setVersionCode(String versionCode) {
        this.versionCode = versionCode;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Integer getPathConfigMethod() {
        return pathConfigMethod;
    }

    public void setPathConfigMethod(Integer pathConfigMethod) {
        this.pathConfigMethod = pathConfigMethod;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public Integer getIsupdate() {
        return isupdate;
    }

    public void setIsupdate(Integer isupdate) {
        this.isupdate = isupdate;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    @Override
    public String toString() {
        return "TAppVersion{" +
                "appVersionId=" + appVersionId +
                ", type=" + type +
                ", versionCode='" + versionCode + '\'' +
                ", version='" + version + '\'' +
                ", url='" + url + '\'' +
                ", pathConfigMethod=" + pathConfigMethod +
                ", fileName='" + fileName + '\'' +
                ", isupdate=" + isupdate +
                ", remark='" + remark + '\'' +
                '}';
    }
}
