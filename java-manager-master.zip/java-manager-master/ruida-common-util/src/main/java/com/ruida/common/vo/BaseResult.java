package com.ruida.common.vo;

import com.ruida.common.enums.ResultStatusCode;

import java.io.Serializable;

/**
 * @description:
 * @author szl
 * @Date 2018年12月10日
 * @verion 1.0
 */
public class BaseResult implements Serializable {

	private static final long serialVersionUID = 7220877209535559537L;

	private int code;		//返回的代码，0表示成功，其他表示失败
	private String msg;		//成功或失败时返回的错误信息
	private Object data;	//成功时返回的数据信息

	public BaseResult(int code, String msg, Object data){
		this.code = code;
		this.msg = msg;
		this.data = data;
	}

	public BaseResult(ResultStatusCode resultStatusCode, Object data){
		this(resultStatusCode.getCode(), resultStatusCode.getMsg(), data);
	}

	public BaseResult(int code, String msg){
		this(code, msg, null);
	}

	public BaseResult(ResultStatusCode resultStatusCode){
		this(resultStatusCode, null);
	}

	public static BaseResult error(int code, String msg){
		return new BaseResult(code,msg);

	}

	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public Object getData() {
		return data;
	}
	public void setData(Object data) {
		this.data = data;
	}
}
