package com.ruida.assessment.assessmentquestionbank.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.assessment.assessmentquestionbank.dto.BatchOperationRequest;
import com.ruida.assessment.assessmentquestionbank.dto.MaterialRequest;
import com.ruida.assessment.assessmentquestionbank.model.TMaterial;
import com.ruida.assessment.assessmentquestionbank.model.TSection;
import com.ruida.assessment.assessmentquestionbank.vo.MaterialVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import java.util.List;

/**
 * @author wy
 * @description 教材管理Mapper
 * @date 2020/6/12
 */
@Mapper
public interface MaterialMapper extends BaseMapper<TMaterial> {

    /*
        分页条件查询教材列表（条件的学段科目必须）
     */
    List<MaterialVo> queryMaterialList(@Param("vo") MaterialRequest req);

    /*
        条件查询教材列表总条数
     */
    Integer queryMaterialCount(@Param("vo") MaterialRequest req);

    /*
        根据教材id查询该教材下对应的所有关联了知识点的章节列表
     */
    List<TSection> selectRelationKnowledge(@Param("vo") BatchOperationRequest request);

    //根据教材版本id查询关联数据
    List<TMaterial> selectListByVersionId(@Param("versionId") Integer versionId);
}
