package com.ruida.cloud.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ruida.common.SystemConstant;
import com.ruida.common.util.excel.ExcelAnnotation;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author szl
 * @description: 订单扩展
 * @Date 2019/1/22
 * @verion 1.0
 */
public class OrderExt extends  Order {
    private static final long serialVersionUID = 1301348948907189683L;
    /**
     * 订单主键ID
     */
    private Integer orderId;

    /**
     * 订单编号
     */
    @ExcelAnnotation(title = "订单编号")
    private String orderNo;

    /**购买人名字*/
    @ExcelAnnotation(title = "购买人")
    private String purchaseName;

    /**
     * 订单交易号
     */
    private String orderTransNo;

    /**
     * 订单名称
     */
    @ExcelAnnotation(title = "课程名称")
    private String orderName;

    /**
     * 授课方式
     */
    @ExcelAnnotation(title = "授课方式")
    private String teachingMethodName;

    /**
     * 校区名称
     */
    @ExcelAnnotation(title = "校区")
    private String campusName;

    @ExcelAnnotation(title = "主讲老师")
    private String teacherName;

    @ExcelAnnotation(title = "助教")
    private String assistantTeacherName;

    /**
     * 原价
     */
    @ExcelAnnotation(title = "原价")
    private BigDecimal orderAmount;

    /**
     * 订单金额
     */
    @ExcelAnnotation(title = "订单金额")
    private BigDecimal realOrderAmount;

    /**
     * 优惠金额
     */
    @ExcelAnnotation(title = "优惠价")
    private BigDecimal saleAmount;

    /**
     * 实付金额
     */
    @ExcelAnnotation(title = "支付价")
    private BigDecimal payAmount;


    /**
     * 购买人ID（关联sys_user表的user_id）
     */
    private Integer purchaserId;

    /**
     * 购买人联系电话
     */
    private String telephone;

    /**
     * 支付方式（0—微信支付；1—支付宝；2—Q钱包；3—网银支付）
     */
    private Byte paymentType;

    /**
     * 支付方式名字
     */
    @ExcelAnnotation(title = "支付方式")
    private  String paymentTypeName;

    /**
     * 订单状态（0—待支付；1—已支付；2—已关闭）
     */
    private Byte status;

    /**
     * 订单来源（0—PC端；1—IOS端；2—Android端）
     */
    private Byte source;

    /**
     * 订单创建时间
     */
    @JsonFormat(pattern= SystemConstant.DATE_FORMAT,timezone=SystemConstant.TIME_ZONE)
    private Date createTime;

    /**
     * 订单更新时间
     */
    @JsonFormat(pattern= "yyyy-MM-dd HH:mm:ss",timezone=SystemConstant.TIME_ZONE)
    private Date updateTime;

    /**
     * 订单付款时间
     */
    @JsonFormat(pattern=SystemConstant.DATE_FORMAT,timezone=SystemConstant.TIME_ZONE)
    private Date paymentTime;

    /**
     * 交易完成时间（保留字段，暂时不使用）
     */
    @JsonFormat(pattern=SystemConstant.DATE_FORMAT,timezone=SystemConstant.TIME_ZONE)
    private Date endTime;

    /**
     * 交易关闭时间
     */
    @JsonFormat(pattern=SystemConstant.DATE_FORMAT,timezone=SystemConstant.TIME_ZONE)
    private Date closeTime;

    /**
     * 是否删除（0：未删除；1：删除）
     */
    private Byte isdelete;
    /**教师名字*/

    /**搜索关键词*/
    private  String searchWord;
    /**时间节点搜索类型（0今天 1最近七天  2最近30天）*/
    private  Integer type;
    /**订单状态名*/
    @ExcelAnnotation(title = "订单状态")
    private String statusName;
    /**
     * 课程id
     */
    private Integer courseId;
    //筛选开始时间
    private long searchStartTime;
    //帅选结束时间
    private long searchEndTime;
    //筛选开始时间
    private long searchStartDate;
    //帅选结束时间
    private long searchEndDate;
    private String courseName;

    /**
     * 授课方式
     */
    private Byte teachingMethod;
    /**
     * 校区id
     */
    private Integer campusId;

    /**
     * 授课方式
     */
    private  Integer findType;

    private String validTime;

    //订单类型
    private byte orderType;

    /**
     * 分销商名称
     */
    private String distributorName;

    /**
     * 课程类型名称
     */
    private String courseTypeName;

    /**
     * 课时数
     */
    private Integer courseLessonNum;

    /**
     * 已上课时数
     */
    private Integer usedCourseLessonNum;

    /**
     * 科目
     */
    private String subjectName;

    /**
     * 年级
     */
    private String stageName;

    /**
     * 上课时长
     */
    private Integer classLength;

    /**
     * 学期id
     */
    private Integer semesterId;

    /**
     * 期段id
     */
    private Integer segmentId;

    /**
     * 班级类型
     */
    private String classTypeName;

    /**
     * 收货地址
     */
    private String shipAddr;

    /**
     * 学期
     */
    private String semesterName;

    /**
     * 期段
     */
    private String segmentName;

    @Override
    public BigDecimal getRealOrderAmount() {
        return realOrderAmount;
    }

    @Override
    public void setRealOrderAmount(BigDecimal realOrderAmount) {
        this.realOrderAmount = realOrderAmount;
    }

    @Override
    public byte getOrderType() {
        return orderType;
    }

    @Override
    public void setOrderType(byte orderType) {
        this.orderType = orderType;
    }

    public String getValidTime() {
        return validTime;
    }

    public void setValidTime(String validTime) {
        this.validTime = validTime;
    }

    public Integer getFindType() {
        return findType;
    }

    public void setFindType(Integer findType) {
        this.findType = findType;
    }

    public long getSearchStartTime() {
        return searchStartTime;
    }

    public void setSearchStartTime(long searchStartTime) {
        this.searchStartTime = searchStartTime;
    }

    public long getSearchEndTime() {
        return searchEndTime;
    }

    public void setSearchEndTime(long searchEndTime) {
        this.searchEndTime = searchEndTime;
    }

    public String getSearchWord() {
        return searchWord;
    }

    public void setSearchWord(String searchWord) {
        this.searchWord = searchWord;
    }

    public String getTeacherName() {
        return teacherName;
    }

    public void setTeacherName(String teacherName) {
        this.teacherName = teacherName;
    }

    public String getPurchaseName() {
        return purchaseName;
    }

    public void setPurchaseName(String purchaseName) {
        this.purchaseName = purchaseName;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public String getStatusName() {
       switch (this.getStatus()){
           case 0:
               this.setStatusName("待支付");
               break;
           case 1:
               this.setStatusName("已支付");
               break;
           case 2:
               this.setStatusName("已关闭");
               break;
           case 3:
               this.setStatusName("待确认");
               break;
           case 4:
               this.setStatusName("退款中");
               break;
           case 5:
               this.setStatusName("已退款");
               break;
                   default:

       }
        return statusName;
    }

    public void setStatusName(String statusName) {
        this.statusName = statusName;
    }

    @Override
    public Integer getOrderId() {
        return orderId;
    }

    @Override
    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    @Override
    public String getOrderNo() {
        return orderNo;
    }

    @Override
    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public String getOrderTransNo() {
        return orderTransNo;
    }

    public void setOrderTransNo(String orderTransNo) {
        this.orderTransNo = orderTransNo;
    }

    public String getOrderName() {
        return orderName;
    }

    public void setOrderName(String orderName) {
        this.orderName = orderName;
    }

    public BigDecimal getOrderAmount() {
        return orderAmount;
    }

    public void setOrderAmount(BigDecimal orderAmount) {
        this.orderAmount = orderAmount;
    }

    public BigDecimal getPayAmount() {
        return payAmount;
    }

    public void setPayAmount(BigDecimal payAmount) {
        this.payAmount = payAmount;
    }

    public Integer getPurchaserId() {
        return purchaserId;
    }

    public void setPurchaserId(Integer purchaserId) {
        this.purchaserId = purchaserId;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public Byte getPaymentType() {
        return paymentType;
    }

    public void setPaymentType(Byte paymentType) {
        this.paymentType = paymentType;
    }

    public Byte getStatus() {
        return status;
    }

    public void setStatus(Byte status) {
        this.status = status;
    }

    public Byte getSource() {
        return source;
    }

    public void setSource(Byte source) {
        this.source = source;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Date getPaymentTime() {
        return paymentTime;
    }

    public void setPaymentTime(Date paymentTime) {
        this.paymentTime = paymentTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public Date getCloseTime() {
        return closeTime;
    }

    public void setCloseTime(Date closeTime) {
        this.closeTime = closeTime;
    }

    public Byte getIsdelete() {
        return isdelete;
    }

    public void setIsdelete(Byte isdelete) {
        this.isdelete = isdelete;
    }

    public Integer getCourseId() {
        return courseId;
    }

    public void setCourseId(Integer courseId) {
        this.courseId = courseId;
    }

    public long getSearchStartDate() {
        return searchStartDate;
    }

    public void setSearchStartDate(long searchStartDate) {
        this.searchStartDate = searchStartDate;
    }

    public long getSearchEndDate() {
        return searchEndDate;
    }

    public void setSearchEndDate(long searchEndDate) {
        this.searchEndDate = searchEndDate;
    }

    public String getPaymentTypeName() {
        return paymentTypeName;
    }

    public void setPaymentTypeName(String paymentTypeName) {
        this.paymentTypeName = paymentTypeName;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public BigDecimal getSaleAmount() {
        return saleAmount;
    }

    @Override
    public void setSaleAmount(BigDecimal saleAmount) {
        this.saleAmount = saleAmount;
    }

    public Byte getTeachingMethod() {
        return teachingMethod;
    }

    public void setTeachingMethod(Byte teachingMethod) {
        this.teachingMethod = teachingMethod;
    }

    @Override
    public Integer getCampusId() {
        return campusId;
    }

    @Override
    public void setCampusId(Integer campusId) {
        this.campusId = campusId;
    }

    public String getCampusName() {
        return campusName;
    }

    public void setCampusName(String campusName) {
        this.campusName = campusName;
    }

    public String getTeachingMethodName() {
        return teachingMethodName;
    }

    public void setTeachingMethodName(String teachingMethodName) {
        this.teachingMethodName = teachingMethodName;
    }

    @Override
    public String getAssistantTeacherName() {
        return assistantTeacherName;
    }

    @Override
    public void setAssistantTeacherName(String assistantTeacherName) {
        this.assistantTeacherName = assistantTeacherName;
    }

    public String getDistributorName() {
        return distributorName;
    }

    public void setDistributorName(String distributorName) {
        this.distributorName = distributorName;
    }

    public String getCourseTypeName() {
        return courseTypeName;
    }

    public void setCourseTypeName(String courseTypeName) {
        this.courseTypeName = courseTypeName;
    }

    public Integer getCourseLessonNum() {
        return courseLessonNum;
    }

    public void setCourseLessonNum(Integer courseLessonNum) {
        this.courseLessonNum = courseLessonNum;
    }

    public Integer getUsedCourseLessonNum() {
        return usedCourseLessonNum;
    }

    public void setUsedCourseLessonNum(Integer usedCourseLessonNum) {
        this.usedCourseLessonNum = usedCourseLessonNum;
    }

    public String getSubjectName() {
        return subjectName;
    }

    public void setSubjectName(String subjectName) {
        this.subjectName = subjectName;
    }

    public String getStageName() {
        return stageName;
    }

    public void setStageName(String stageName) {
        this.stageName = stageName;
    }

    public Integer getClassLength() {
        return classLength;
    }

    public void setClassLength(Integer classLength) {
        this.classLength = classLength;
    }

    public Integer getSemesterId() {
        return semesterId;
    }

    public void setSemesterId(Integer semesterId) {
        this.semesterId = semesterId;
    }

    public Integer getSegmentId() {
        return segmentId;
    }

    public void setSegmentId(Integer segmentId) {
        this.segmentId = segmentId;
    }

    public String getClassTypeName() {
        return classTypeName;
    }

    public void setClassTypeName(String classTypeName) {
        this.classTypeName = classTypeName;
    }

    public String getShipAddr() {
        return shipAddr;
    }

    public void setShipAddr(String shipAddr) {
        this.shipAddr = shipAddr;
    }

    public String getSemesterName() {
        return semesterName;
    }

    public void setSemesterName(String semesterName) {
        this.semesterName = semesterName;
    }

    public String getSegmentName() {
        return segmentName;
    }

    public void setSegmentName(String segmentName) {
        this.segmentName = segmentName;
    }

    @Override
    public String toString() {
        return "OrderExt{" +
                "teacherName='" + teacherName + '\'' +
                ", purchaseName='" + purchaseName + '\'' +
                ", searchWord='" + searchWord + '\'' +
                ", type=" + type +
                ", statusName='" + statusName + '\'' +
                '}';
    }

}
