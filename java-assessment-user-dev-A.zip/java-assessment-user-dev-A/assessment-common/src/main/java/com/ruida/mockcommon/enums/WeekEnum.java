package com.ruida.mockcommon.enums;

import java.util.UUID;

/**
 * 周枚举类
 *
 * @author szl
 */
public enum WeekEnum {
	/**
	 * 周一
	 */
	MONDAY(0, "monday", "星期一"),
	/**
	 * 周二
	 */
	TUESDAY(1, "tuesday", "星期二"),
	/**
	 * 周三
	 */
	WEDNESDAY(2, "wednesday", "星期三"),
	/**
	 * 周四
	 */
	THURSDAY(3, "thursday", "星期四"),
	/**
	 * 周五
	 */
	FRIDAY(4, "friday", "星期五"),
	/**
	 * 周六
	 */
	SATURDAY(5, "saturday", "星期六"),
	/**
	 * 周日
	 */
	SUNDAY(6, "sunday", "星期日");

	private Integer id;
	private String code;
	private String name;

	WeekEnum(int id, String code, String name) {
		this.id = id;
		this.code = code;
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * 根据code获取Name
	 * @param code
	 * @return
	 */
	public static String getNameByCode(String code) {
		WeekEnum[] list = WeekEnum.values();
		for (WeekEnum one : list) {
			if (one.getCode().equals(code)) {
				return one.getName();
			}
		}
		return "";
	}

	/***
	 * 根据Name获取code
	 * @param code
	 * @return
	 */
	public static String getCodeByName(String code) {
		WeekEnum[] list = WeekEnum.values();
		for (WeekEnum one : list) {
			if (one.getCode().equals(code)) {
				return one.getCode();
			}
		}
		return "";
	}

	/**
	 * 根据code获取Id
	 * @param code
	 * @return
	 */
	public static Integer getIdByCode(String code) {
		WeekEnum[] list = WeekEnum.values();
		for (WeekEnum one : list) {
			if (one.getCode().equalsIgnoreCase(code)) {
				return one.getId();
			}
		}
		return 0;
	}

	/**
	 * 根据Name获取ID
	 * @param name
	 * @return
	 */
	public static Integer getIdByName(String name) {
		WeekEnum[] list = WeekEnum.values();
		for (WeekEnum one : list) {
			if (one.getName().equalsIgnoreCase(name)) {
				return one.getId();
			}
		}
		return 0;
	}

	/**
	 * 根据ID获取code
	 * @param id
	 * @return
	 */
	public static String getCodeById(Integer id) {
		WeekEnum[] list = WeekEnum.values();
		for (WeekEnum one : list) {
			if (one.getId() == id) {
				return one.getCode();
			}
		}
		return "";
	}

	/**
	 * 根据ID获取name
	 * @param id
	 * @return
	 */
	public static String getNameById(Integer id) {
		WeekEnum[] list = WeekEnum.values();
		for (WeekEnum one : list) {
			if (one.getId() == id) {
				return one.getName();
			}
		}
		return "";
	}

	public static void main(String[] args) {
		System.out.println(UUID.randomUUID());
		System.out.println(getNameByCode("monday"));
		System.out.println(getIdByCode("MONDAY"));
		System.out.println(getCodeById(1));
		System.out.println(getNameById(1));
	}

}
