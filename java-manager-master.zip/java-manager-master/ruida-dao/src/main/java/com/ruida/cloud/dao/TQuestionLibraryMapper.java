package com.ruida.cloud.dao;

import com.ruida.cloud.model.TQuestionLibrary;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 题库表 Mapper 接口
 * </p>
 *
 * @author mlzhang
 * @since 2019-12-16
 */
public interface TQuestionLibraryMapper {
    Integer insert(TQuestionLibrary tQuestionLibrary);

    Integer updateById(TQuestionLibrary tQuestionLibrary);

    TQuestionLibrary selectById(@Param("questionLibraryId") Integer questionLibraryId);

    List<TQuestionLibrary>  selectListByParentId(@Param("questionLibraryId") Integer questionLibraryId);
    List<TQuestionLibrary>  selectListByParentIdAndMyself(@Param("questionLibraryId") Integer questionLibraryId);

    Integer updateByPrimaryKeySelective(TQuestionLibrary tQuestionLibrary);
}
