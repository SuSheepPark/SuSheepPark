package com.ruida.assessment.assessmentcommon.enums;

/**
 * @description: 订单操作枚举
 * @author: kgz
 * @date: 2020/8/3
 */
public enum OrderOperationEnum {
    CLOSE(1,"关闭订单"),
    ;

    private Integer K;
    private String V;

    OrderOperationEnum(Integer k, String v) {
        K = k;
        V = v;
    }

    public Integer getK() {
        return K;
    }

    public void setK(Integer k) {
        K = k;
    }

    public String getV() {
        return V;
    }

    public void setV(String v) {
        V = v;
    }

}
