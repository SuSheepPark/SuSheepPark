package com.ruida.common.enums;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Created by  on 2018/3/1.
 */
public enum RefundType {

    STUDY_COIN(0,"学习币"), CASH(1,"现金");
    public static final String SOURCE_KEY = "Bool";
    private Integer k;
    private String v;

    RefundType(Integer k, String v) {
        this.k = k;
        this.v = v;
    }

    public static Map<Integer,String> map = new LinkedHashMap<>(2);
    static
    {
        for(RefundType type : RefundType.values())
        {
            map.put(type.getK(),type.getV());
        }
    }

    public Integer getK() {
        return k;
    }

    public void setK(Integer k) {
        this.k = k;
    }

    public String getV() {
        return v;
    }

    public void setV(String v) {
        this.v = v;
    }

    /***
     * 根据k获取v的值
     * @param k
     * @return
     */
    public static String getvByk(int k) {
        RefundType[] list = RefundType.values();
        for (RefundType valid : list) {
            if (valid.getK() == k ) {
                return valid.getV();
            }
        }
        return "";
    }
}
