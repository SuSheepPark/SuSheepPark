package com.ruida.mockdao.vo;

import com.ruida.mockdao.pojo.BasicSubjectInfo;
import com.ruida.mockdao.pojo.SubjectInfo;

import java.util.List;

/**
 * @description: 商品科目考试情况
 * @author: kgz
 * @date: 2021/2/23
 */
public class ExamProductSubjectRecordVO {

    private Integer productId;

    private String productName;

    private String examTime;

    List<SubjectInfo> subjectInfo;

    public Integer getProductId() {
        return productId;
    }

    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public List<SubjectInfo> getSubjectInfo() {
        return subjectInfo;
    }

    public void setSubjectInfo(List<SubjectInfo> subjectInfo) {
        this.subjectInfo = subjectInfo;
    }

    public String getExamTime() {
        return examTime;
    }

    public void setExamTime(String examTime) {
        this.examTime = examTime;
    }
}
