/**   
 * Copyright © 2019 公司名. All rights reserved.
 * 
 * @Title: IndexController.java 
 * @Prject: zhaowei-cms
 * @Package: com.zhaowei.cms.controller 
 * @Description: TODO
 * @author: zw   
 * @date: 2019年9月19日 下午8:15:30 
 * @version: V1.0   
 */
package com.zhaowei.cms.controller;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.github.pagehelper.PageInfo;
import com.zhaowei.cms.domain.Article;
import com.zhaowei.cms.domain.Category;
import com.zhaowei.cms.domain.Channel;
import com.zhaowei.cms.domain.Slide;
import com.zhaowei.cms.service.ArticleService;
import com.zhaowei.cms.service.CategoryService;
import com.zhaowei.cms.service.ChannelService;
import com.zhaowei.cms.service.SlideService;
import com.zhaowei.cms.util.PageUtil;

/** 
 * @ClassName: IndexController 
 * @Description: TODO
 * @author: zw
 * @date: 2019年9月19日 下午8:15:30  
 */
@RequestMapping(value= {"index","","/"})
@Controller
public class IndexController {
	@Resource
	private ChannelService channelService;

	
	@Resource
	private CategoryService categoryService;
	@Resource
	private ArticleService articleService;
	
	@Resource
	private SlideService slideService;
	
	//进入系统首页
	@GetMapping(value = "")
	public String index(Model model,Article article,@RequestParam(defaultValue = "1")Integer page,@RequestParam(defaultValue = "5")Integer pageSize) {
		
		//设置查询条件
		article.setStatus(1);//查询审过的文章
		article.setDeleted(0);//查询的文章是没用被删除的
		// 1查询出所有栏目
		List<Channel> channels = channelService.selects();
		model.addAttribute("channels", channels);
		// 2.如果栏目为null 则查询热门文章
		if (article.getChannelId() == null) {
			article.setHot(1);
			PageInfo<Article> info = articleService.selects(article, page, pageSize);
			model.addAttribute("hotArticles", info.getList());
			String pages = PageUtil.page(page, info.getPages(), "/", pageSize);
			model.addAttribute("pages", pages);
			//广告数据--轮播图
			List<Slide> selects = slideService.selects();
			model.addAttribute("slides", selects);
		}

		// 3.如果栏目不为null 则查询栏目下的分类及文章
		if (article.getChannelId() != null) {
			//查询栏目下所有的分类
			List<Category> categorys= categoryService.selectsByChannelId(article.getChannelId());
			model.addAttribute("categorys", categorys);
			//栏目或分类下 的文章
			PageInfo<Article> info = articleService.selects(article, page, pageSize);
			String pages = PageUtil.page(page, info.getPages(), "/", pageSize);
			model.addAttribute("articles", info.getList());
			model.addAttribute("pages", pages);

		}
		model.addAttribute("article", article);

		// 3.最新文章.--按照文章发布日期倒序显示最近的5篇文章
		Article article2 = new Article();
		article2.setStatus(1);
		article2.setDeleted(0);
		
		
			PageInfo<Article> info2 = articleService.selectsByComments(article2, 1, 5);
			model.addAttribute("commentsArticles", info2.getList());
			PageInfo<Article> info3 = articleService.selectsByclick(article2, 1, 5);
			model.addAttribute("clickArticles", info3.getList());
		
		return "index/index";
	}
	
	
}
