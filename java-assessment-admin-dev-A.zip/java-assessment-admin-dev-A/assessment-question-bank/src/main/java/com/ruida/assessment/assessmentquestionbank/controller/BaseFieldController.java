package com.ruida.assessment.assessmentquestionbank.controller;

import com.ruida.assessment.assessmentcommon.result.PageData;
import com.ruida.assessment.assessmentcommon.result.PojoResult;
import com.ruida.assessment.assessmentquestionbank.annotaion.UserAuth;
import com.ruida.assessment.assessmentquestionbank.dto.BaseFieldDTO;
import com.ruida.assessment.assessmentquestionbank.service.BaseFieldService;
import com.ruida.assessment.assessmentquestionbank.vo.BaseFieldVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

@RequestMapping("/base")
@RestController
@Api(value ="基础字段维护")
public class BaseFieldController {

    @Resource
    private BaseFieldService baseFieldService;

    /**
     * 基础字段维护 查询
     * @param baseFieldDTO
     * @throws Exception
     */
    @UserAuth
    @RequestMapping("field/query")
    public PojoResult queryBaseField(@RequestBody BaseFieldDTO baseFieldDTO) throws Exception {

        PageData list = baseFieldService.queryBaseField(baseFieldDTO);
        PojoResult<Object> objectPojoResult = new PojoResult<>();
        objectPojoResult.setErrorMessage(0,"成功");
        objectPojoResult.setSuccess(true);
        objectPojoResult.setContent(list);
        return objectPojoResult;

    }

    /**
     * 基础字段维护 增加/修改
     * @param baseFieldDTO
     * @throws Exception
     */
    @UserAuth
    @ApiOperation(value = "基础字段维护 增加/修改", notes = "基础字段维护 增加/修改")
    @RequestMapping("field/operation")
    public PojoResult operationBaseField(@RequestBody BaseFieldDTO baseFieldDTO) throws Exception {

        boolean operation = false;

        if(baseFieldDTO.getId() == null){
            /* 添加 */
            operation = baseFieldService.insertBaseField(baseFieldDTO);
        }else if(baseFieldDTO.getId() != null){
            /* 修改 */
            operation = baseFieldService.updateBaseField(baseFieldDTO);
        }
        PojoResult<Object> objectPojoResult = new PojoResult<>();
        if(operation){
            objectPojoResult.setSuccess(true);
            objectPojoResult.setMsg("成功");
            objectPojoResult.setCode(0);
        }else{
            objectPojoResult.setSuccess(false);
            objectPojoResult.setErrorMessage(1,"失败");
        }
        objectPojoResult.setContent(operation);
        return objectPojoResult;

    }

    @UserAuth
    @ApiOperation(value = "基础字段维护 编辑时查询详细信息", notes = "基础字段维护 编辑时查询详细信息")
    @RequestMapping("field/queryInfo")
    public PojoResult queryBaseFieldInfo(@RequestBody BaseFieldDTO baseFieldDTO) throws Exception {
        PojoResult result = new PojoResult();
        result.setMsg("成功");
        BaseFieldVO baseFieldVO = baseFieldService.queryBaseFieldInfo(baseFieldDTO);
        result.setContent(baseFieldVO);
        return result;

    }

    /**
     * 基础字段维护 删除
     * @param baseFieldDTO
     * @throws Exception
     */
    /*@UserAuth
    @RequestMapping("field/delete")
    public PojoResult deleteBaseField(@RequestBody BaseFieldDTO baseFieldDTO) throws Exception {

        boolean operation = baseFieldService.deleteBaseField(baseFieldDTO);
        PojoResult<Object> objectPojoResult = new PojoResult<>();
        if(operation){
            objectPojoResult.setSuccess(true);
            objectPojoResult.setMsg("成功");
            objectPojoResult.setCode(0);
        }else{
            objectPojoResult.setSuccess(false);
            objectPojoResult.setErrorMessage(1,"失败");
        }
        objectPojoResult.setContent(operation);
        return objectPojoResult;

    }*/


}
