package com.ruida.assessment.assessmentquestionbank.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.List;

/**
 * @description: 试卷DTO
 * @author: kgz
 * @date: 2020/6/29
 */
@ApiModel(description = "试卷信息")
public class TestPaperDTO {

    @ApiModelProperty(value = "操作id，0-暂存，1-提交", name = "operationId")
    private Integer operationId;

    @ApiModelProperty(value = "学段id", name = "periodId")
    private Integer periodId;

    @ApiModelProperty(value = "试卷id", name = "testPaperId")
    private Integer testPaperId;

    @ApiModelProperty(value = "试卷名称", name = "testPaperName", required = true)
    private String testPaperName;

    @ApiModelProperty(value = "年级id", name = "stageId", required = true)
    private Integer stageId;

    @ApiModelProperty(value = "科目id", name = "subjectId", required = true)
    private Integer subjectId;

    @ApiModelProperty(value = "教材版本id", name = "materialVersionId", required = true)
    private Integer materialVersionId;

    @ApiModelProperty(value = "年份", name = "year", required = true)
    private Integer year;

    @ApiModelProperty(value = "省份id", name = "provinceId", required = true)
    private Integer provinceId;

    @ApiModelProperty(value = "考试类型", name = "testTypeId", required = true)
    private Integer testTypeId;

    @ApiModelProperty(value = "试卷类型", name = "testPaperTypeId", required = true)
    private Integer testPaperTypeId;

    @ApiModelProperty(value = "试卷难度", name = "difficultyId", required = true)
    private Integer difficultyId;

    @ApiModelProperty(value = "测试时常，单位分钟", name = "testDruation", required = true)
    private Integer testDruation;

    @ApiModelProperty(value = "试卷号", name = "testPaperNo", required = true)
    private String testPaperNo;

    @ApiModelProperty(value = "小节", name = "testNode", required = false)
    private List<TestNodeDTO> testNode;

    @ApiModelProperty(value = "试卷用途ID", name = "questionPurposeId", required = true)
    private Integer questionPurposeId;

    @ApiModelProperty(value = "试卷性质ID", name = "paperUseType", required = true)
    private Integer paperUseType;

    @ApiModelProperty(value = "答题方式ID", name = "answerWay", required = true)
    private Integer answerWay;

    public Integer getOperationId() {
        return operationId;
    }

    public void setOperationId(Integer operationId) {
        this.operationId = operationId;
    }

    public Integer getTestPaperId() {
        return testPaperId;
    }

    public void setTestPaperId(Integer testPaperId) {
        this.testPaperId = testPaperId;
    }

    public String getTestPaperName() {
        return testPaperName;
    }

    public void setTestPaperName(String testPaperName) {
        this.testPaperName = testPaperName;
    }

    public Integer getStageId() {
        return stageId;
    }

    public void setStageId(Integer stageId) {
        this.stageId = stageId;
    }

    public Integer getSubjectId() {
        return subjectId;
    }

    public void setSubjectId(Integer subjectId) {
        this.subjectId = subjectId;
    }

    public Integer getMaterialVersionId() {
        return materialVersionId;
    }

    public void setMaterialVersionId(Integer materialVersionId) {
        this.materialVersionId = materialVersionId;
    }

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    public Integer getProvinceId() {
        return provinceId;
    }

    public void setProvinceId(Integer provinceId) {
        this.provinceId = provinceId;
    }

    public Integer getTestTypeId() {
        return testTypeId;
    }

    public void setTestTypeId(Integer testTypeId) {
        this.testTypeId = testTypeId;
    }

    public Integer getTestPaperTypeId() {
        return testPaperTypeId;
    }

    public void setTestPaperTypeId(Integer testPaperTypeId) {
        this.testPaperTypeId = testPaperTypeId;
    }

    public Integer getDifficultyId() {
        return difficultyId;
    }

    public void setDifficultyId(Integer difficultyId) {
        this.difficultyId = difficultyId;
    }

    public Integer getTestDruation() {
        return testDruation;
    }

    public void setTestDruation(Integer testDruation) {
        this.testDruation = testDruation;
    }

    public String getTestPaperNo() {
        return testPaperNo;
    }

    public void setTestPaperNo(String testPaperNo) {
        this.testPaperNo = testPaperNo;
    }

    public List<TestNodeDTO> getTestNode() {
        return testNode;
    }

    public void setTestNode(List<TestNodeDTO> testNode) {
        this.testNode = testNode;
    }

    public Integer getPeriodId() {
        return periodId;
    }

    public void setPeriodId(Integer periodId) {
        this.periodId = periodId;
    }

    public Integer getQuestionPurposeId() {
        return questionPurposeId;
    }

    public void setQuestionPurposeId(Integer questionPurposeId) {
        this.questionPurposeId = questionPurposeId;
    }

    public Integer getPaperUseType() {
        return paperUseType;
    }

    public void setPaperUseType(Integer paperUseType) {
        this.paperUseType = paperUseType;
    }

    public Integer getAnswerWay() {
        return answerWay;
    }

    public void setAnswerWay(Integer answerWay) {
        this.answerWay = answerWay;
    }

    @Override
    public String toString() {
        return "TestPaperDTO{" +
                "operationId=" + operationId +
                ", periodId=" + periodId +
                ", testPaperId=" + testPaperId +
                ", testPaperName='" + testPaperName + '\'' +
                ", stageId=" + stageId +
                ", subjectId=" + subjectId +
                ", materialVersionId=" + materialVersionId +
                ", year=" + year +
                ", provinceId=" + provinceId +
                ", testTypeId=" + testTypeId +
                ", testPaperTypeId=" + testPaperTypeId +
                ", difficultyId=" + difficultyId +
                ", testDruation=" + testDruation +
                ", testPaperNo='" + testPaperNo + '\'' +
                ", testNode=" + testNode +
                ", questionPurposeId=" + questionPurposeId +
                ", paperUseType=" + paperUseType +
                ", answerWay=" + answerWay +
                '}';
    }
}
