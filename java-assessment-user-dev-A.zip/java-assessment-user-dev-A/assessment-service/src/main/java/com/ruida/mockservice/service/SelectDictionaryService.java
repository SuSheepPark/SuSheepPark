package com.ruida.mockservice.service;


import com.baomidou.mybatisplus.service.IService;
import com.ruida.mockdao.model.TMaterialVersion;
import com.ruida.mockdao.model.TPeriod;
import com.ruida.mockdao.model.TQuestionDifficulty;
import com.ruida.mockdao.vo.SelectDictionaryVO;

import java.util.List;

/**
 * <p>
 * 商品表 服务类
 * </p>
 *
 * @author jinhu
 * @since 2020-07-08
 */
public interface SelectDictionaryService extends IService<TQuestionDifficulty> {



    SelectDictionaryVO getSelectDictionary();



    List<TPeriod> getHomeSelectDictionary();


    SelectDictionaryVO getSelectByStage(Integer stageId);


    SelectDictionaryVO getSelectBySubject(Integer subjectId);


    SelectDictionaryVO getSelectByPeriod(Integer periodId);
}
