package com.ruida.polyv.util;

public interface Progress {
	public void run(long offset, long max) ;
}
