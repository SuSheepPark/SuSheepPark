package com.ruida.mockdao.dao;

import com.ruida.mockdao.model.TCollegePreference;
import com.baomidou.mybatisplus.mapper.BaseMapper;

/**
 * <p>
 * 志愿填报报告 Mapper 接口
 * </p>
 *
 * @author szl
 * @since 2021-03-02
 */
public interface TCollegePreferenceMapper extends BaseMapper<TCollegePreference> {

}
