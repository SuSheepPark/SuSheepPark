package com.ruida.cloud.model;

import java.util.List;
import java.util.Map;

/**
 * @author taosh
 * @create 2019-07-26 16:16
 */
public class PeriodExt {
    private int periodId;

    private String periodName;

    private String subject;

    private List<Map<String, Object>> subjectList;

    private String stage;

    private List<Map<String, Object>> stageList;

    public int getPeriodId() {
        return periodId;
    }

    public void setPeriodId(int periodId) {
        this.periodId = periodId;
    }

    public String getPeriodName() {
        return periodName;
    }

    public void setPeriodName(String periodName) {
        this.periodName = periodName;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public List<Map<String, Object>> getSubjectList() {
        return subjectList;
    }

    public void setSubjectList(List<Map<String, Object>> subjectList) {
        this.subjectList = subjectList;
    }

    public String getStage() {
        return stage;
    }

    public void setStage(String stage) {
        this.stage = stage;
    }

    public List<Map<String, Object>> getStageList() {
        return stageList;
    }

    public void setStageList(List<Map<String, Object>> stageList) {
        this.stageList = stageList;
    }
}
