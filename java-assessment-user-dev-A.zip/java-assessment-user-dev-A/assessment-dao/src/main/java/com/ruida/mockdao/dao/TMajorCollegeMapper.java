package com.ruida.mockdao.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.model.TMajorCollege;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * 学校专业录取信息 Mapper 接口
 * </p>
 *
 * @author szl
 * @since 2021-02-23
 */
public interface TMajorCollegeMapper extends BaseMapper<TMajorCollege> {
    List<TMajorCollege> getMajorRecommentList(Map<String,Object> param);

}
