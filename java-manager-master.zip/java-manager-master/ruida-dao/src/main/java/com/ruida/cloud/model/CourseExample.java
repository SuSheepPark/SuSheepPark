package com.ruida.cloud.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class CourseExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public CourseExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andCourseIdIsNull() {
            addCriterion("course_id is null");
            return (Criteria) this;
        }

        public Criteria andCourseIdIsNotNull() {
            addCriterion("course_id is not null");
            return (Criteria) this;
        }

        public Criteria andCourseIdEqualTo(Integer value) {
            addCriterion("course_id =", value, "courseId");
            return (Criteria) this;
        }

        public Criteria andCourseIdNotEqualTo(Integer value) {
            addCriterion("course_id <>", value, "courseId");
            return (Criteria) this;
        }

        public Criteria andCourseIdGreaterThan(Integer value) {
            addCriterion("course_id >", value, "courseId");
            return (Criteria) this;
        }

        public Criteria andCourseIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("course_id >=", value, "courseId");
            return (Criteria) this;
        }

        public Criteria andCourseIdLessThan(Integer value) {
            addCriterion("course_id <", value, "courseId");
            return (Criteria) this;
        }

        public Criteria andCourseIdLessThanOrEqualTo(Integer value) {
            addCriterion("course_id <=", value, "courseId");
            return (Criteria) this;
        }

        public Criteria andCourseIdIn(List<Integer> values) {
            addCriterion("course_id in", values, "courseId");
            return (Criteria) this;
        }

        public Criteria andCourseIdNotIn(List<Integer> values) {
            addCriterion("course_id not in", values, "courseId");
            return (Criteria) this;
        }

        public Criteria andCourseIdBetween(Integer value1, Integer value2) {
            addCriterion("course_id between", value1, value2, "courseId");
            return (Criteria) this;
        }

        public Criteria andCourseIdNotBetween(Integer value1, Integer value2) {
            addCriterion("course_id not between", value1, value2, "courseId");
            return (Criteria) this;
        }

        public Criteria andCourseNameIsNull() {
            addCriterion("course_name is null");
            return (Criteria) this;
        }

        public Criteria andCourseNameIsNotNull() {
            addCriterion("course_name is not null");
            return (Criteria) this;
        }

        public Criteria andCourseNameEqualTo(String value) {
            addCriterion("course_name =", value, "courseName");
            return (Criteria) this;
        }

        public Criteria andCourseNameNotEqualTo(String value) {
            addCriterion("course_name <>", value, "courseName");
            return (Criteria) this;
        }

        public Criteria andCourseNameGreaterThan(String value) {
            addCriterion("course_name >", value, "courseName");
            return (Criteria) this;
        }

        public Criteria andCourseNameGreaterThanOrEqualTo(String value) {
            addCriterion("course_name >=", value, "courseName");
            return (Criteria) this;
        }

        public Criteria andCourseNameLessThan(String value) {
            addCriterion("course_name <", value, "courseName");
            return (Criteria) this;
        }

        public Criteria andCourseNameLessThanOrEqualTo(String value) {
            addCriterion("course_name <=", value, "courseName");
            return (Criteria) this;
        }

        public Criteria andCourseNameLike(String value) {
            addCriterion("course_name like", value, "courseName");
            return (Criteria) this;
        }

        public Criteria andCourseNameNotLike(String value) {
            addCriterion("course_name not like", value, "courseName");
            return (Criteria) this;
        }

        public Criteria andCourseNameIn(List<String> values) {
            addCriterion("course_name in", values, "courseName");
            return (Criteria) this;
        }

        public Criteria andCourseNameNotIn(List<String> values) {
            addCriterion("course_name not in", values, "courseName");
            return (Criteria) this;
        }

        public Criteria andCourseNameBetween(String value1, String value2) {
            addCriterion("course_name between", value1, value2, "courseName");
            return (Criteria) this;
        }

        public Criteria andCourseNameNotBetween(String value1, String value2) {
            addCriterion("course_name not between", value1, value2, "courseName");
            return (Criteria) this;
        }

        public Criteria andTeachingMethodIsNull() {
            addCriterion("teaching_method is null");
            return (Criteria) this;
        }

        public Criteria andTeachingMethodIsNotNull() {
            addCriterion("teaching_method is not null");
            return (Criteria) this;
        }

        public Criteria andTeachingMethodEqualTo(Byte value) {
            addCriterion("teaching_method =", value, "teachingMethod");
            return (Criteria) this;
        }

        public Criteria andTeachingMethodNotEqualTo(Byte value) {
            addCriterion("teaching_method <>", value, "teachingMethod");
            return (Criteria) this;
        }

        public Criteria andTeachingMethodGreaterThan(Byte value) {
            addCriterion("teaching_method >", value, "teachingMethod");
            return (Criteria) this;
        }

        public Criteria andTeachingMethodGreaterThanOrEqualTo(Byte value) {
            addCriterion("teaching_method >=", value, "teachingMethod");
            return (Criteria) this;
        }

        public Criteria andTeachingMethodLessThan(Byte value) {
            addCriterion("teaching_method <", value, "teachingMethod");
            return (Criteria) this;
        }

        public Criteria andTeachingMethodLessThanOrEqualTo(Byte value) {
            addCriterion("teaching_method <=", value, "teachingMethod");
            return (Criteria) this;
        }

        public Criteria andTeachingMethodIn(List<Byte> values) {
            addCriterion("teaching_method in", values, "teachingMethod");
            return (Criteria) this;
        }

        public Criteria andTeachingMethodNotIn(List<Byte> values) {
            addCriterion("teaching_method not in", values, "teachingMethod");
            return (Criteria) this;
        }

        public Criteria andTeachingMethodBetween(Byte value1, Byte value2) {
            addCriterion("teaching_method between", value1, value2, "teachingMethod");
            return (Criteria) this;
        }

        public Criteria andTeachingMethodNotBetween(Byte value1, Byte value2) {
            addCriterion("teaching_method not between", value1, value2, "teachingMethod");
            return (Criteria) this;
        }

        public Criteria andCoverPathIsNull() {
            addCriterion("cover_path is null");
            return (Criteria) this;
        }

        public Criteria andCoverPathIsNotNull() {
            addCriterion("cover_path is not null");
            return (Criteria) this;
        }

        public Criteria andCoverPathEqualTo(String value) {
            addCriterion("cover_path =", value, "coverPath");
            return (Criteria) this;
        }

        public Criteria andCoverPathNotEqualTo(String value) {
            addCriterion("cover_path <>", value, "coverPath");
            return (Criteria) this;
        }

        public Criteria andCoverPathGreaterThan(String value) {
            addCriterion("cover_path >", value, "coverPath");
            return (Criteria) this;
        }

        public Criteria andCoverPathGreaterThanOrEqualTo(String value) {
            addCriterion("cover_path >=", value, "coverPath");
            return (Criteria) this;
        }

        public Criteria andCoverPathLessThan(String value) {
            addCriterion("cover_path <", value, "coverPath");
            return (Criteria) this;
        }

        public Criteria andCoverPathLessThanOrEqualTo(String value) {
            addCriterion("cover_path <=", value, "coverPath");
            return (Criteria) this;
        }

        public Criteria andCoverPathLike(String value) {
            addCriterion("cover_path like", value, "coverPath");
            return (Criteria) this;
        }

        public Criteria andCoverPathNotLike(String value) {
            addCriterion("cover_path not like", value, "coverPath");
            return (Criteria) this;
        }

        public Criteria andCoverPathIn(List<String> values) {
            addCriterion("cover_path in", values, "coverPath");
            return (Criteria) this;
        }

        public Criteria andCoverPathNotIn(List<String> values) {
            addCriterion("cover_path not in", values, "coverPath");
            return (Criteria) this;
        }

        public Criteria andCoverPathBetween(String value1, String value2) {
            addCriterion("cover_path between", value1, value2, "coverPath");
            return (Criteria) this;
        }

        public Criteria andCoverPathNotBetween(String value1, String value2) {
            addCriterion("cover_path not between", value1, value2, "coverPath");
            return (Criteria) this;
        }

        public Criteria andSemesterIdIsNull() {
            addCriterion("semester_id is null");
            return (Criteria) this;
        }

        public Criteria andSemesterIdIsNotNull() {
            addCriterion("semester_id is not null");
            return (Criteria) this;
        }

        public Criteria andSemesterIdEqualTo(String value) {
            addCriterion("semester_id =", value, "semesterId");
            return (Criteria) this;
        }

        public Criteria andSemesterIdNotEqualTo(String value) {
            addCriterion("semester_id <>", value, "semesterId");
            return (Criteria) this;
        }

        public Criteria andSemesterIdGreaterThan(String value) {
            addCriterion("semester_id >", value, "semesterId");
            return (Criteria) this;
        }

        public Criteria andSemesterIdGreaterThanOrEqualTo(String value) {
            addCriterion("semester_id >=", value, "semesterId");
            return (Criteria) this;
        }

        public Criteria andSemesterIdLessThan(String value) {
            addCriterion("semester_id <", value, "semesterId");
            return (Criteria) this;
        }

        public Criteria andSemesterIdLessThanOrEqualTo(String value) {
            addCriterion("semester_id <=", value, "semesterId");
            return (Criteria) this;
        }

        public Criteria andSemesterIdLike(String value) {
            addCriterion("semester_id like", value, "semesterId");
            return (Criteria) this;
        }

        public Criteria andSemesterIdNotLike(String value) {
            addCriterion("semester_id not like", value, "semesterId");
            return (Criteria) this;
        }

        public Criteria andSemesterIdIn(List<String> values) {
            addCriterion("semester_id in", values, "semesterId");
            return (Criteria) this;
        }

        public Criteria andSemesterIdNotIn(List<String> values) {
            addCriterion("semester_id not in", values, "semesterId");
            return (Criteria) this;
        }

        public Criteria andSemesterIdBetween(String value1, String value2) {
            addCriterion("semester_id between", value1, value2, "semesterId");
            return (Criteria) this;
        }

        public Criteria andSemesterIdNotBetween(String value1, String value2) {
            addCriterion("semester_id not between", value1, value2, "semesterId");
            return (Criteria) this;
        }

        public Criteria andSegmentIdIsNull() {
            addCriterion("segment_id is null");
            return (Criteria) this;
        }

        public Criteria andSegmentIdIsNotNull() {
            addCriterion("segment_id is not null");
            return (Criteria) this;
        }

        public Criteria andSegmentIdEqualTo(Byte value) {
            addCriterion("segment_id =", value, "segmentId");
            return (Criteria) this;
        }

        public Criteria andSegmentIdNotEqualTo(Byte value) {
            addCriterion("segment_id <>", value, "segmentId");
            return (Criteria) this;
        }

        public Criteria andSegmentIdGreaterThan(Byte value) {
            addCriterion("segment_id >", value, "segmentId");
            return (Criteria) this;
        }

        public Criteria andSegmentIdGreaterThanOrEqualTo(Byte value) {
            addCriterion("segment_id >=", value, "segmentId");
            return (Criteria) this;
        }

        public Criteria andSegmentIdLessThan(Byte value) {
            addCriterion("segment_id <", value, "segmentId");
            return (Criteria) this;
        }

        public Criteria andSegmentIdLessThanOrEqualTo(Byte value) {
            addCriterion("segment_id <=", value, "segmentId");
            return (Criteria) this;
        }

        public Criteria andSegmentIdIn(List<Byte> values) {
            addCriterion("segment_id in", values, "segmentId");
            return (Criteria) this;
        }

        public Criteria andSegmentIdNotIn(List<Byte> values) {
            addCriterion("segment_id not in", values, "segmentId");
            return (Criteria) this;
        }

        public Criteria andSegmentIdBetween(Byte value1, Byte value2) {
            addCriterion("segment_id between", value1, value2, "segmentId");
            return (Criteria) this;
        }

        public Criteria andSegmentIdNotBetween(Byte value1, Byte value2) {
            addCriterion("segment_id not between", value1, value2, "segmentId");
            return (Criteria) this;
        }

        public Criteria andClassLengthIsNull() {
            addCriterion("class_length is null");
            return (Criteria) this;
        }

        public Criteria andClassLengthIsNotNull() {
            addCriterion("class_length is not null");
            return (Criteria) this;
        }

        public Criteria andClassLengthEqualTo(Integer value) {
            addCriterion("class_length =", value, "classLength");
            return (Criteria) this;
        }

        public Criteria andClassLengthNotEqualTo(Integer value) {
            addCriterion("class_length <>", value, "classLength");
            return (Criteria) this;
        }

        public Criteria andClassLengthGreaterThan(Integer value) {
            addCriterion("class_length >", value, "classLength");
            return (Criteria) this;
        }

        public Criteria andClassLengthGreaterThanOrEqualTo(Integer value) {
            addCriterion("class_length >=", value, "classLength");
            return (Criteria) this;
        }

        public Criteria andClassLengthLessThan(Integer value) {
            addCriterion("class_length <", value, "classLength");
            return (Criteria) this;
        }

        public Criteria andClassLengthLessThanOrEqualTo(Integer value) {
            addCriterion("class_length <=", value, "classLength");
            return (Criteria) this;
        }

        public Criteria andClassLengthIn(List<Integer> values) {
            addCriterion("class_length in", values, "classLength");
            return (Criteria) this;
        }

        public Criteria andClassLengthNotIn(List<Integer> values) {
            addCriterion("class_length not in", values, "classLength");
            return (Criteria) this;
        }

        public Criteria andClassLengthBetween(Integer value1, Integer value2) {
            addCriterion("class_length between", value1, value2, "classLength");
            return (Criteria) this;
        }

        public Criteria andClassLengthNotBetween(Integer value1, Integer value2) {
            addCriterion("class_length not between", value1, value2, "classLength");
            return (Criteria) this;
        }

        public Criteria andPeriodIdIsNull() {
            addCriterion("period_id is null");
            return (Criteria) this;
        }

        public Criteria andPeriodIdIsNotNull() {
            addCriterion("period_id is not null");
            return (Criteria) this;
        }

        public Criteria andPeriodIdEqualTo(Integer value) {
            addCriterion("period_id =", value, "periodId");
            return (Criteria) this;
        }

        public Criteria andPeriodIdNotEqualTo(Integer value) {
            addCriterion("period_id <>", value, "periodId");
            return (Criteria) this;
        }

        public Criteria andPeriodIdGreaterThan(Integer value) {
            addCriterion("period_id >", value, "periodId");
            return (Criteria) this;
        }

        public Criteria andPeriodIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("period_id >=", value, "periodId");
            return (Criteria) this;
        }

        public Criteria andPeriodIdLessThan(Integer value) {
            addCriterion("period_id <", value, "periodId");
            return (Criteria) this;
        }

        public Criteria andPeriodIdLessThanOrEqualTo(Integer value) {
            addCriterion("period_id <=", value, "periodId");
            return (Criteria) this;
        }

        public Criteria andPeriodIdIn(List<Integer> values) {
            addCriterion("period_id in", values, "periodId");
            return (Criteria) this;
        }

        public Criteria andPeriodIdNotIn(List<Integer> values) {
            addCriterion("period_id not in", values, "periodId");
            return (Criteria) this;
        }

        public Criteria andPeriodIdBetween(Integer value1, Integer value2) {
            addCriterion("period_id between", value1, value2, "periodId");
            return (Criteria) this;
        }

        public Criteria andPeriodIdNotBetween(Integer value1, Integer value2) {
            addCriterion("period_id not between", value1, value2, "periodId");
            return (Criteria) this;
        }

        public Criteria andStageIdIsNull() {
            addCriterion("stage_id is null");
            return (Criteria) this;
        }

        public Criteria andStageIdIsNotNull() {
            addCriterion("stage_id is not null");
            return (Criteria) this;
        }

        public Criteria andStageIdEqualTo(Integer value) {
            addCriterion("stage_id =", value, "stageId");
            return (Criteria) this;
        }

        public Criteria andStageIdNotEqualTo(Integer value) {
            addCriterion("stage_id <>", value, "stageId");
            return (Criteria) this;
        }

        public Criteria andStageIdGreaterThan(Integer value) {
            addCriterion("stage_id >", value, "stageId");
            return (Criteria) this;
        }

        public Criteria andStageIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("stage_id >=", value, "stageId");
            return (Criteria) this;
        }

        public Criteria andStageIdLessThan(Integer value) {
            addCriterion("stage_id <", value, "stageId");
            return (Criteria) this;
        }

        public Criteria andStageIdLessThanOrEqualTo(Integer value) {
            addCriterion("stage_id <=", value, "stageId");
            return (Criteria) this;
        }

        public Criteria andStageIdIn(List<Integer> values) {
            addCriterion("stage_id in", values, "stageId");
            return (Criteria) this;
        }

        public Criteria andStageIdNotIn(List<Integer> values) {
            addCriterion("stage_id not in", values, "stageId");
            return (Criteria) this;
        }

        public Criteria andStageIdBetween(Integer value1, Integer value2) {
            addCriterion("stage_id between", value1, value2, "stageId");
            return (Criteria) this;
        }

        public Criteria andStageIdNotBetween(Integer value1, Integer value2) {
            addCriterion("stage_id not between", value1, value2, "stageId");
            return (Criteria) this;
        }

        public Criteria andCourseTypeIdIsNull() {
            addCriterion("course_type_id is null");
            return (Criteria) this;
        }

        public Criteria andCourseTypeIdIsNotNull() {
            addCriterion("course_type_id is not null");
            return (Criteria) this;
        }

        public Criteria andCourseTypeIdEqualTo(Integer value) {
            addCriterion("course_type_id =", value, "courseTypeId");
            return (Criteria) this;
        }

        public Criteria andCourseTypeIdNotEqualTo(Integer value) {
            addCriterion("course_type_id <>", value, "courseTypeId");
            return (Criteria) this;
        }

        public Criteria andCourseTypeIdGreaterThan(Integer value) {
            addCriterion("course_type_id >", value, "courseTypeId");
            return (Criteria) this;
        }

        public Criteria andCourseTypeIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("course_type_id >=", value, "courseTypeId");
            return (Criteria) this;
        }

        public Criteria andCourseTypeIdLessThan(Integer value) {
            addCriterion("course_type_id <", value, "courseTypeId");
            return (Criteria) this;
        }

        public Criteria andCourseTypeIdLessThanOrEqualTo(Integer value) {
            addCriterion("course_type_id <=", value, "courseTypeId");
            return (Criteria) this;
        }

        public Criteria andCourseTypeIdIn(List<Integer> values) {
            addCriterion("course_type_id in", values, "courseTypeId");
            return (Criteria) this;
        }

        public Criteria andCourseTypeIdNotIn(List<Integer> values) {
            addCriterion("course_type_id not in", values, "courseTypeId");
            return (Criteria) this;
        }

        public Criteria andCourseTypeIdBetween(Integer value1, Integer value2) {
            addCriterion("course_type_id between", value1, value2, "courseTypeId");
            return (Criteria) this;
        }

        public Criteria andCourseTypeIdNotBetween(Integer value1, Integer value2) {
            addCriterion("course_type_id not between", value1, value2, "courseTypeId");
            return (Criteria) this;
        }

        public Criteria andClassTypeIdIsNull() {
            addCriterion("class_type_id is null");
            return (Criteria) this;
        }

        public Criteria andClassTypeIdIsNotNull() {
            addCriterion("class_type_id is not null");
            return (Criteria) this;
        }

        public Criteria andClassTypeIdEqualTo(Integer value) {
            addCriterion("class_type_id =", value, "classTypeId");
            return (Criteria) this;
        }

        public Criteria andClassTypeIdNotEqualTo(Integer value) {
            addCriterion("class_type_id <>", value, "classTypeId");
            return (Criteria) this;
        }

        public Criteria andClassTypeIdGreaterThan(Integer value) {
            addCriterion("class_type_id >", value, "classTypeId");
            return (Criteria) this;
        }

        public Criteria andClassTypeIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("class_type_id >=", value, "classTypeId");
            return (Criteria) this;
        }

        public Criteria andClassTypeIdLessThan(Integer value) {
            addCriterion("class_type_id <", value, "classTypeId");
            return (Criteria) this;
        }

        public Criteria andClassTypeIdLessThanOrEqualTo(Integer value) {
            addCriterion("class_type_id <=", value, "classTypeId");
            return (Criteria) this;
        }

        public Criteria andClassTypeIdIn(List<Integer> values) {
            addCriterion("class_type_id in", values, "classTypeId");
            return (Criteria) this;
        }

        public Criteria andClassTypeIdNotIn(List<Integer> values) {
            addCriterion("class_type_id not in", values, "classTypeId");
            return (Criteria) this;
        }

        public Criteria andClassTypeIdBetween(Integer value1, Integer value2) {
            addCriterion("class_type_id between", value1, value2, "classTypeId");
            return (Criteria) this;
        }

        public Criteria andClassTypeIdNotBetween(Integer value1, Integer value2) {
            addCriterion("class_type_id not between", value1, value2, "classTypeId");
            return (Criteria) this;
        }

        public Criteria andLiveTypeIsNull() {
            addCriterion("live_type is null");
            return (Criteria) this;
        }

        public Criteria andLiveTypeIsNotNull() {
            addCriterion("live_type is not null");
            return (Criteria) this;
        }

        public Criteria andLiveTypeEqualTo(Byte value) {
            addCriterion("live_type =", value, "liveType");
            return (Criteria) this;
        }

        public Criteria andLiveTypeNotEqualTo(Byte value) {
            addCriterion("live_type <>", value, "liveType");
            return (Criteria) this;
        }

        public Criteria andLiveTypeGreaterThan(Byte value) {
            addCriterion("live_type >", value, "liveType");
            return (Criteria) this;
        }

        public Criteria andLiveTypeGreaterThanOrEqualTo(Byte value) {
            addCriterion("live_type >=", value, "liveType");
            return (Criteria) this;
        }

        public Criteria andLiveTypeLessThan(Byte value) {
            addCriterion("live_type <", value, "liveType");
            return (Criteria) this;
        }

        public Criteria andLiveTypeLessThanOrEqualTo(Byte value) {
            addCriterion("live_type <=", value, "liveType");
            return (Criteria) this;
        }

        public Criteria andLiveTypeIn(List<Byte> values) {
            addCriterion("live_type in", values, "liveType");
            return (Criteria) this;
        }

        public Criteria andLiveTypeNotIn(List<Byte> values) {
            addCriterion("live_type not in", values, "liveType");
            return (Criteria) this;
        }

        public Criteria andLiveTypeBetween(Byte value1, Byte value2) {
            addCriterion("live_type between", value1, value2, "liveType");
            return (Criteria) this;
        }

        public Criteria andLiveTypeNotBetween(Byte value1, Byte value2) {
            addCriterion("live_type not between", value1, value2, "liveType");
            return (Criteria) this;
        }

        public Criteria andGroupNumIsNull() {
            addCriterion("group_num is null");
            return (Criteria) this;
        }

        public Criteria andGroupNumIsNotNull() {
            addCriterion("group_num is not null");
            return (Criteria) this;
        }

        public Criteria andGroupNumEqualTo(Integer value) {
            addCriterion("group_num =", value, "groupNum");
            return (Criteria) this;
        }

        public Criteria andGroupNumNotEqualTo(Integer value) {
            addCriterion("group_num <>", value, "groupNum");
            return (Criteria) this;
        }

        public Criteria andGroupNumGreaterThan(Integer value) {
            addCriterion("group_num >", value, "groupNum");
            return (Criteria) this;
        }

        public Criteria andGroupNumGreaterThanOrEqualTo(Integer value) {
            addCriterion("group_num >=", value, "groupNum");
            return (Criteria) this;
        }

        public Criteria andGroupNumLessThan(Integer value) {
            addCriterion("group_num <", value, "groupNum");
            return (Criteria) this;
        }

        public Criteria andGroupNumLessThanOrEqualTo(Integer value) {
            addCriterion("group_num <=", value, "groupNum");
            return (Criteria) this;
        }

        public Criteria andGroupNumIn(List<Integer> values) {
            addCriterion("group_num in", values, "groupNum");
            return (Criteria) this;
        }

        public Criteria andGroupNumNotIn(List<Integer> values) {
            addCriterion("group_num not in", values, "groupNum");
            return (Criteria) this;
        }

        public Criteria andGroupNumBetween(Integer value1, Integer value2) {
            addCriterion("group_num between", value1, value2, "groupNum");
            return (Criteria) this;
        }

        public Criteria andGroupNumNotBetween(Integer value1, Integer value2) {
            addCriterion("group_num not between", value1, value2, "groupNum");
            return (Criteria) this;
        }

        public Criteria andCourseVideoIdIsNull() {
            addCriterion("course_video_id is null");
            return (Criteria) this;
        }

        public Criteria andCourseVideoIdIsNotNull() {
            addCriterion("course_video_id is not null");
            return (Criteria) this;
        }

        public Criteria andCourseVideoIdEqualTo(Integer value) {
            addCriterion("course_video_id =", value, "courseVideoId");
            return (Criteria) this;
        }

        public Criteria andCourseVideoIdNotEqualTo(Integer value) {
            addCriterion("course_video_id <>", value, "courseVideoId");
            return (Criteria) this;
        }

        public Criteria andCourseVideoIdGreaterThan(Integer value) {
            addCriterion("course_video_id >", value, "courseVideoId");
            return (Criteria) this;
        }

        public Criteria andCourseVideoIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("course_video_id >=", value, "courseVideoId");
            return (Criteria) this;
        }

        public Criteria andCourseVideoIdLessThan(Integer value) {
            addCriterion("course_video_id <", value, "courseVideoId");
            return (Criteria) this;
        }

        public Criteria andCourseVideoIdLessThanOrEqualTo(Integer value) {
            addCriterion("course_video_id <=", value, "courseVideoId");
            return (Criteria) this;
        }

        public Criteria andCourseVideoIdIn(List<Integer> values) {
            addCriterion("course_video_id in", values, "courseVideoId");
            return (Criteria) this;
        }

        public Criteria andCourseVideoIdNotIn(List<Integer> values) {
            addCriterion("course_video_id not in", values, "courseVideoId");
            return (Criteria) this;
        }

        public Criteria andCourseVideoIdBetween(Integer value1, Integer value2) {
            addCriterion("course_video_id between", value1, value2, "courseVideoId");
            return (Criteria) this;
        }

        public Criteria andCourseVideoIdNotBetween(Integer value1, Integer value2) {
            addCriterion("course_video_id not between", value1, value2, "courseVideoId");
            return (Criteria) this;
        }

        public Criteria andIstestIsNull() {
            addCriterion("istest is null");
            return (Criteria) this;
        }

        public Criteria andIstestIsNotNull() {
            addCriterion("istest is not null");
            return (Criteria) this;
        }

        public Criteria andIstestEqualTo(Byte value) {
            addCriterion("istest =", value, "istest");
            return (Criteria) this;
        }

        public Criteria andIstestNotEqualTo(Byte value) {
            addCriterion("istest <>", value, "istest");
            return (Criteria) this;
        }

        public Criteria andIstestGreaterThan(Byte value) {
            addCriterion("istest >", value, "istest");
            return (Criteria) this;
        }

        public Criteria andIstestGreaterThanOrEqualTo(Byte value) {
            addCriterion("istest >=", value, "istest");
            return (Criteria) this;
        }

        public Criteria andIstestLessThan(Byte value) {
            addCriterion("istest <", value, "istest");
            return (Criteria) this;
        }

        public Criteria andIstestLessThanOrEqualTo(Byte value) {
            addCriterion("istest <=", value, "istest");
            return (Criteria) this;
        }

        public Criteria andIstestIn(List<Byte> values) {
            addCriterion("istest in", values, "istest");
            return (Criteria) this;
        }

        public Criteria andIstestNotIn(List<Byte> values) {
            addCriterion("istest not in", values, "istest");
            return (Criteria) this;
        }

        public Criteria andIstestBetween(Byte value1, Byte value2) {
            addCriterion("istest between", value1, value2, "istest");
            return (Criteria) this;
        }

        public Criteria andIstestNotBetween(Byte value1, Byte value2) {
            addCriterion("istest not between", value1, value2, "istest");
            return (Criteria) this;
        }

        public Criteria andIspublicIsNull() {
            addCriterion("ispublic is null");
            return (Criteria) this;
        }

        public Criteria andIspublicIsNotNull() {
            addCriterion("ispublic is not null");
            return (Criteria) this;
        }

        public Criteria andIspublicEqualTo(Byte value) {
            addCriterion("ispublic =", value, "ispublic");
            return (Criteria) this;
        }

        public Criteria andIspublicNotEqualTo(Byte value) {
            addCriterion("ispublic <>", value, "ispublic");
            return (Criteria) this;
        }

        public Criteria andIspublicGreaterThan(Byte value) {
            addCriterion("ispublic >", value, "ispublic");
            return (Criteria) this;
        }

        public Criteria andIspublicGreaterThanOrEqualTo(Byte value) {
            addCriterion("ispublic >=", value, "ispublic");
            return (Criteria) this;
        }

        public Criteria andIspublicLessThan(Byte value) {
            addCriterion("ispublic <", value, "ispublic");
            return (Criteria) this;
        }

        public Criteria andIspublicLessThanOrEqualTo(Byte value) {
            addCriterion("ispublic <=", value, "ispublic");
            return (Criteria) this;
        }

        public Criteria andIspublicIn(List<Byte> values) {
            addCriterion("ispublic in", values, "ispublic");
            return (Criteria) this;
        }

        public Criteria andIspublicNotIn(List<Byte> values) {
            addCriterion("ispublic not in", values, "ispublic");
            return (Criteria) this;
        }

        public Criteria andIspublicBetween(Byte value1, Byte value2) {
            addCriterion("ispublic between", value1, value2, "ispublic");
            return (Criteria) this;
        }

        public Criteria andIspublicNotBetween(Byte value1, Byte value2) {
            addCriterion("ispublic not between", value1, value2, "ispublic");
            return (Criteria) this;
        }

        public Criteria andIschargeIsNull() {
            addCriterion("ischarge is null");
            return (Criteria) this;
        }

        public Criteria andIschargeIsNotNull() {
            addCriterion("ischarge is not null");
            return (Criteria) this;
        }

        public Criteria andIschargeEqualTo(Byte value) {
            addCriterion("ischarge =", value, "ischarge");
            return (Criteria) this;
        }

        public Criteria andIschargeNotEqualTo(Byte value) {
            addCriterion("ischarge <>", value, "ischarge");
            return (Criteria) this;
        }

        public Criteria andIschargeGreaterThan(Byte value) {
            addCriterion("ischarge >", value, "ischarge");
            return (Criteria) this;
        }

        public Criteria andIschargeGreaterThanOrEqualTo(Byte value) {
            addCriterion("ischarge >=", value, "ischarge");
            return (Criteria) this;
        }

        public Criteria andIschargeLessThan(Byte value) {
            addCriterion("ischarge <", value, "ischarge");
            return (Criteria) this;
        }

        public Criteria andIschargeLessThanOrEqualTo(Byte value) {
            addCriterion("ischarge <=", value, "ischarge");
            return (Criteria) this;
        }

        public Criteria andIschargeIn(List<Byte> values) {
            addCriterion("ischarge in", values, "ischarge");
            return (Criteria) this;
        }

        public Criteria andIschargeNotIn(List<Byte> values) {
            addCriterion("ischarge not in", values, "ischarge");
            return (Criteria) this;
        }

        public Criteria andIschargeBetween(Byte value1, Byte value2) {
            addCriterion("ischarge between", value1, value2, "ischarge");
            return (Criteria) this;
        }

        public Criteria andIschargeNotBetween(Byte value1, Byte value2) {
            addCriterion("ischarge not between", value1, value2, "ischarge");
            return (Criteria) this;
        }

        public Criteria andSaleIsNull() {
            addCriterion("sale is null");
            return (Criteria) this;
        }

        public Criteria andSaleIsNotNull() {
            addCriterion("sale is not null");
            return (Criteria) this;
        }

        public Criteria andSaleEqualTo(Byte value) {
            addCriterion("sale =", value, "sale");
            return (Criteria) this;
        }

        public Criteria andSaleNotEqualTo(Byte value) {
            addCriterion("sale <>", value, "sale");
            return (Criteria) this;
        }

        public Criteria andSaleGreaterThan(Byte value) {
            addCriterion("sale >", value, "sale");
            return (Criteria) this;
        }

        public Criteria andSaleGreaterThanOrEqualTo(Byte value) {
            addCriterion("sale >=", value, "sale");
            return (Criteria) this;
        }

        public Criteria andSaleLessThan(Byte value) {
            addCriterion("sale <", value, "sale");
            return (Criteria) this;
        }

        public Criteria andSaleLessThanOrEqualTo(Byte value) {
            addCriterion("sale <=", value, "sale");
            return (Criteria) this;
        }

        public Criteria andSaleIn(List<Byte> values) {
            addCriterion("sale in", values, "sale");
            return (Criteria) this;
        }

        public Criteria andSaleNotIn(List<Byte> values) {
            addCriterion("sale not in", values, "sale");
            return (Criteria) this;
        }

        public Criteria andSaleBetween(Byte value1, Byte value2) {
            addCriterion("sale between", value1, value2, "sale");
            return (Criteria) this;
        }

        public Criteria andSaleNotBetween(Byte value1, Byte value2) {
            addCriterion("sale not between", value1, value2, "sale");
            return (Criteria) this;
        }

        public Criteria andIstryvideoIsNull() {
            addCriterion("istryvideo is null");
            return (Criteria) this;
        }

        public Criteria andIstryvideoIsNotNull() {
            addCriterion("istryvideo is not null");
            return (Criteria) this;
        }

        public Criteria andIstryvideoEqualTo(Byte value) {
            addCriterion("istryvideo =", value, "istryvideo");
            return (Criteria) this;
        }

        public Criteria andIstryvideoNotEqualTo(Byte value) {
            addCriterion("istryvideo <>", value, "istryvideo");
            return (Criteria) this;
        }

        public Criteria andIstryvideoGreaterThan(Byte value) {
            addCriterion("istryvideo >", value, "istryvideo");
            return (Criteria) this;
        }

        public Criteria andIstryvideoGreaterThanOrEqualTo(Byte value) {
            addCriterion("istryvideo >=", value, "istryvideo");
            return (Criteria) this;
        }

        public Criteria andIstryvideoLessThan(Byte value) {
            addCriterion("istryvideo <", value, "istryvideo");
            return (Criteria) this;
        }

        public Criteria andIstryvideoLessThanOrEqualTo(Byte value) {
            addCriterion("istryvideo <=", value, "istryvideo");
            return (Criteria) this;
        }

        public Criteria andIstryvideoIn(List<Byte> values) {
            addCriterion("istryvideo in", values, "istryvideo");
            return (Criteria) this;
        }

        public Criteria andIstryvideoNotIn(List<Byte> values) {
            addCriterion("istryvideo not in", values, "istryvideo");
            return (Criteria) this;
        }

        public Criteria andIstryvideoBetween(Byte value1, Byte value2) {
            addCriterion("istryvideo between", value1, value2, "istryvideo");
            return (Criteria) this;
        }

        public Criteria andIstryvideoNotBetween(Byte value1, Byte value2) {
            addCriterion("istryvideo not between", value1, value2, "istryvideo");
            return (Criteria) this;
        }

        public Criteria andStartDateIsNull() {
            addCriterion("start_date is null");
            return (Criteria) this;
        }

        public Criteria andStartDateIsNotNull() {
            addCriterion("start_date is not null");
            return (Criteria) this;
        }

        public Criteria andStartDateEqualTo(Date value) {
            addCriterion("start_date =", value, "startDate");
            return (Criteria) this;
        }

        public Criteria andStartDateNotEqualTo(Date value) {
            addCriterion("start_date <>", value, "startDate");
            return (Criteria) this;
        }

        public Criteria andStartDateGreaterThan(Date value) {
            addCriterion("start_date >", value, "startDate");
            return (Criteria) this;
        }

        public Criteria andStartDateGreaterThanOrEqualTo(Date value) {
            addCriterion("start_date >=", value, "startDate");
            return (Criteria) this;
        }

        public Criteria andStartDateLessThan(Date value) {
            addCriterion("start_date <", value, "startDate");
            return (Criteria) this;
        }

        public Criteria andStartDateLessThanOrEqualTo(Date value) {
            addCriterion("start_date <=", value, "startDate");
            return (Criteria) this;
        }

        public Criteria andStartDateIn(List<Date> values) {
            addCriterion("start_date in", values, "startDate");
            return (Criteria) this;
        }

        public Criteria andStartDateNotIn(List<Date> values) {
            addCriterion("start_date not in", values, "startDate");
            return (Criteria) this;
        }

        public Criteria andStartDateBetween(Date value1, Date value2) {
            addCriterion("start_date between", value1, value2, "startDate");
            return (Criteria) this;
        }

        public Criteria andStartDateNotBetween(Date value1, Date value2) {
            addCriterion("start_date not between", value1, value2, "startDate");
            return (Criteria) this;
        }

        public Criteria andEndDateIsNull() {
            addCriterion("end_date is null");
            return (Criteria) this;
        }

        public Criteria andEndDateIsNotNull() {
            addCriterion("end_date is not null");
            return (Criteria) this;
        }

        public Criteria andEndDateEqualTo(Date value) {
            addCriterion("end_date =", value, "endDate");
            return (Criteria) this;
        }

        public Criteria andEndDateNotEqualTo(Date value) {
            addCriterion("end_date <>", value, "endDate");
            return (Criteria) this;
        }

        public Criteria andEndDateGreaterThan(Date value) {
            addCriterion("end_date >", value, "endDate");
            return (Criteria) this;
        }

        public Criteria andEndDateGreaterThanOrEqualTo(Date value) {
            addCriterion("end_date >=", value, "endDate");
            return (Criteria) this;
        }

        public Criteria andEndDateLessThan(Date value) {
            addCriterion("end_date <", value, "endDate");
            return (Criteria) this;
        }

        public Criteria andEndDateLessThanOrEqualTo(Date value) {
            addCriterion("end_date <=", value, "endDate");
            return (Criteria) this;
        }

        public Criteria andEndDateIn(List<Date> values) {
            addCriterion("end_date in", values, "endDate");
            return (Criteria) this;
        }

        public Criteria andEndDateNotIn(List<Date> values) {
            addCriterion("end_date not in", values, "endDate");
            return (Criteria) this;
        }

        public Criteria andEndDateBetween(Date value1, Date value2) {
            addCriterion("end_date between", value1, value2, "endDate");
            return (Criteria) this;
        }

        public Criteria andEndDateNotBetween(Date value1, Date value2) {
            addCriterion("end_date not between", value1, value2, "endDate");
            return (Criteria) this;
        }

        public Criteria andStartTimeIsNull() {
            addCriterion("start_time is null");
            return (Criteria) this;
        }

        public Criteria andStartTimeIsNotNull() {
            addCriterion("start_time is not null");
            return (Criteria) this;
        }

        public Criteria andStartTimeEqualTo(String value) {
            addCriterion("start_time =", value, "startTime");
            return (Criteria) this;
        }

        public Criteria andStartTimeNotEqualTo(String value) {
            addCriterion("start_time <>", value, "startTime");
            return (Criteria) this;
        }

        public Criteria andStartTimeGreaterThan(String value) {
            addCriterion("start_time >", value, "startTime");
            return (Criteria) this;
        }

        public Criteria andStartTimeGreaterThanOrEqualTo(String value) {
            addCriterion("start_time >=", value, "startTime");
            return (Criteria) this;
        }

        public Criteria andStartTimeLessThan(String value) {
            addCriterion("start_time <", value, "startTime");
            return (Criteria) this;
        }

        public Criteria andStartTimeLessThanOrEqualTo(String value) {
            addCriterion("start_time <=", value, "startTime");
            return (Criteria) this;
        }

        public Criteria andStartTimeLike(String value) {
            addCriterion("start_time like", value, "startTime");
            return (Criteria) this;
        }

        public Criteria andStartTimeNotLike(String value) {
            addCriterion("start_time not like", value, "startTime");
            return (Criteria) this;
        }

        public Criteria andStartTimeIn(List<String> values) {
            addCriterion("start_time in", values, "startTime");
            return (Criteria) this;
        }

        public Criteria andStartTimeNotIn(List<String> values) {
            addCriterion("start_time not in", values, "startTime");
            return (Criteria) this;
        }

        public Criteria andStartTimeBetween(String value1, String value2) {
            addCriterion("start_time between", value1, value2, "startTime");
            return (Criteria) this;
        }

        public Criteria andStartTimeNotBetween(String value1, String value2) {
            addCriterion("start_time not between", value1, value2, "startTime");
            return (Criteria) this;
        }

        public Criteria andEndTimeIsNull() {
            addCriterion("end_time is null");
            return (Criteria) this;
        }

        public Criteria andEndTimeIsNotNull() {
            addCriterion("end_time is not null");
            return (Criteria) this;
        }

        public Criteria andEndTimeEqualTo(String value) {
            addCriterion("end_time =", value, "endTime");
            return (Criteria) this;
        }

        public Criteria andEndTimeNotEqualTo(String value) {
            addCriterion("end_time <>", value, "endTime");
            return (Criteria) this;
        }

        public Criteria andEndTimeGreaterThan(String value) {
            addCriterion("end_time >", value, "endTime");
            return (Criteria) this;
        }

        public Criteria andEndTimeGreaterThanOrEqualTo(String value) {
            addCriterion("end_time >=", value, "endTime");
            return (Criteria) this;
        }

        public Criteria andEndTimeLessThan(String value) {
            addCriterion("end_time <", value, "endTime");
            return (Criteria) this;
        }

        public Criteria andEndTimeLessThanOrEqualTo(String value) {
            addCriterion("end_time <=", value, "endTime");
            return (Criteria) this;
        }

        public Criteria andEndTimeLike(String value) {
            addCriterion("end_time like", value, "endTime");
            return (Criteria) this;
        }

        public Criteria andEndTimeNotLike(String value) {
            addCriterion("end_time not like", value, "endTime");
            return (Criteria) this;
        }

        public Criteria andEndTimeIn(List<String> values) {
            addCriterion("end_time in", values, "endTime");
            return (Criteria) this;
        }

        public Criteria andEndTimeNotIn(List<String> values) {
            addCriterion("end_time not in", values, "endTime");
            return (Criteria) this;
        }

        public Criteria andEndTimeBetween(String value1, String value2) {
            addCriterion("end_time between", value1, value2, "endTime");
            return (Criteria) this;
        }

        public Criteria andEndTimeNotBetween(String value1, String value2) {
            addCriterion("end_time not between", value1, value2, "endTime");
            return (Criteria) this;
        }

        public Criteria andIntervalDaysIsNull() {
            addCriterion("interval_days is null");
            return (Criteria) this;
        }

        public Criteria andIntervalDaysIsNotNull() {
            addCriterion("interval_days is not null");
            return (Criteria) this;
        }

        public Criteria andIntervalDaysEqualTo(Integer value) {
            addCriterion("interval_days =", value, "intervalDays");
            return (Criteria) this;
        }

        public Criteria andIntervalDaysNotEqualTo(Integer value) {
            addCriterion("interval_days <>", value, "intervalDays");
            return (Criteria) this;
        }

        public Criteria andIntervalDaysGreaterThan(Integer value) {
            addCriterion("interval_days >", value, "intervalDays");
            return (Criteria) this;
        }

        public Criteria andIntervalDaysGreaterThanOrEqualTo(Integer value) {
            addCriterion("interval_days >=", value, "intervalDays");
            return (Criteria) this;
        }

        public Criteria andIntervalDaysLessThan(Integer value) {
            addCriterion("interval_days <", value, "intervalDays");
            return (Criteria) this;
        }

        public Criteria andIntervalDaysLessThanOrEqualTo(Integer value) {
            addCriterion("interval_days <=", value, "intervalDays");
            return (Criteria) this;
        }

        public Criteria andIntervalDaysIn(List<Integer> values) {
            addCriterion("interval_days in", values, "intervalDays");
            return (Criteria) this;
        }

        public Criteria andIntervalDaysNotIn(List<Integer> values) {
            addCriterion("interval_days not in", values, "intervalDays");
            return (Criteria) this;
        }

        public Criteria andIntervalDaysBetween(Integer value1, Integer value2) {
            addCriterion("interval_days between", value1, value2, "intervalDays");
            return (Criteria) this;
        }

        public Criteria andIntervalDaysNotBetween(Integer value1, Integer value2) {
            addCriterion("interval_days not between", value1, value2, "intervalDays");
            return (Criteria) this;
        }

        public Criteria andValidTimeIsNull() {
            addCriterion("valid_time is null");
            return (Criteria) this;
        }

        public Criteria andValidTimeIsNotNull() {
            addCriterion("valid_time is not null");
            return (Criteria) this;
        }

        public Criteria andValidTimeEqualTo(Byte value) {
            addCriterion("valid_time =", value, "validTime");
            return (Criteria) this;
        }

        public Criteria andValidTimeNotEqualTo(Byte value) {
            addCriterion("valid_time <>", value, "validTime");
            return (Criteria) this;
        }

        public Criteria andValidTimeGreaterThan(Byte value) {
            addCriterion("valid_time >", value, "validTime");
            return (Criteria) this;
        }

        public Criteria andValidTimeGreaterThanOrEqualTo(Byte value) {
            addCriterion("valid_time >=", value, "validTime");
            return (Criteria) this;
        }

        public Criteria andValidTimeLessThan(Byte value) {
            addCriterion("valid_time <", value, "validTime");
            return (Criteria) this;
        }

        public Criteria andValidTimeLessThanOrEqualTo(Byte value) {
            addCriterion("valid_time <=", value, "validTime");
            return (Criteria) this;
        }

        public Criteria andValidTimeIn(List<Byte> values) {
            addCriterion("valid_time in", values, "validTime");
            return (Criteria) this;
        }

        public Criteria andValidTimeNotIn(List<Byte> values) {
            addCriterion("valid_time not in", values, "validTime");
            return (Criteria) this;
        }

        public Criteria andValidTimeBetween(Byte value1, Byte value2) {
            addCriterion("valid_time between", value1, value2, "validTime");
            return (Criteria) this;
        }

        public Criteria andValidTimeNotBetween(Byte value1, Byte value2) {
            addCriterion("valid_time not between", value1, value2, "validTime");
            return (Criteria) this;
        }

        public Criteria andTeacherIdIsNull() {
            addCriterion("teacher_id is null");
            return (Criteria) this;
        }

        public Criteria andTeacherIdIsNotNull() {
            addCriterion("teacher_id is not null");
            return (Criteria) this;
        }

        public Criteria andTeacherIdEqualTo(Integer value) {
            addCriterion("teacher_id =", value, "teacherId");
            return (Criteria) this;
        }

        public Criteria andTeacherIdNotEqualTo(Integer value) {
            addCriterion("teacher_id <>", value, "teacherId");
            return (Criteria) this;
        }

        public Criteria andTeacherIdGreaterThan(Integer value) {
            addCriterion("teacher_id >", value, "teacherId");
            return (Criteria) this;
        }

        public Criteria andTeacherIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("teacher_id >=", value, "teacherId");
            return (Criteria) this;
        }

        public Criteria andTeacherIdLessThan(Integer value) {
            addCriterion("teacher_id <", value, "teacherId");
            return (Criteria) this;
        }

        public Criteria andTeacherIdLessThanOrEqualTo(Integer value) {
            addCriterion("teacher_id <=", value, "teacherId");
            return (Criteria) this;
        }

        public Criteria andTeacherIdIn(List<Integer> values) {
            addCriterion("teacher_id in", values, "teacherId");
            return (Criteria) this;
        }

        public Criteria andTeacherIdNotIn(List<Integer> values) {
            addCriterion("teacher_id not in", values, "teacherId");
            return (Criteria) this;
        }

        public Criteria andTeacherIdBetween(Integer value1, Integer value2) {
            addCriterion("teacher_id between", value1, value2, "teacherId");
            return (Criteria) this;
        }

        public Criteria andTeacherIdNotBetween(Integer value1, Integer value2) {
            addCriterion("teacher_id not between", value1, value2, "teacherId");
            return (Criteria) this;
        }

        public Criteria andBroadcastRoomIdIsNull() {
            addCriterion("broadcast_room_id is null");
            return (Criteria) this;
        }

        public Criteria andBroadcastRoomIdIsNotNull() {
            addCriterion("broadcast_room_id is not null");
            return (Criteria) this;
        }

        public Criteria andBroadcastRoomIdEqualTo(Integer value) {
            addCriterion("broadcast_room_id =", value, "broadcastRoomId");
            return (Criteria) this;
        }

        public Criteria andBroadcastRoomIdNotEqualTo(Integer value) {
            addCriterion("broadcast_room_id <>", value, "broadcastRoomId");
            return (Criteria) this;
        }

        public Criteria andBroadcastRoomIdGreaterThan(Integer value) {
            addCriterion("broadcast_room_id >", value, "broadcastRoomId");
            return (Criteria) this;
        }

        public Criteria andBroadcastRoomIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("broadcast_room_id >=", value, "broadcastRoomId");
            return (Criteria) this;
        }

        public Criteria andBroadcastRoomIdLessThan(Integer value) {
            addCriterion("broadcast_room_id <", value, "broadcastRoomId");
            return (Criteria) this;
        }

        public Criteria andBroadcastRoomIdLessThanOrEqualTo(Integer value) {
            addCriterion("broadcast_room_id <=", value, "broadcastRoomId");
            return (Criteria) this;
        }

        public Criteria andBroadcastRoomIdIn(List<Integer> values) {
            addCriterion("broadcast_room_id in", values, "broadcastRoomId");
            return (Criteria) this;
        }

        public Criteria andBroadcastRoomIdNotIn(List<Integer> values) {
            addCriterion("broadcast_room_id not in", values, "broadcastRoomId");
            return (Criteria) this;
        }

        public Criteria andBroadcastRoomIdBetween(Integer value1, Integer value2) {
            addCriterion("broadcast_room_id between", value1, value2, "broadcastRoomId");
            return (Criteria) this;
        }

        public Criteria andBroadcastRoomIdNotBetween(Integer value1, Integer value2) {
            addCriterion("broadcast_room_id not between", value1, value2, "broadcastRoomId");
            return (Criteria) this;
        }

        public Criteria andIscomposeIsNull() {
            addCriterion("iscompose is null");
            return (Criteria) this;
        }

        public Criteria andIscomposeIsNotNull() {
            addCriterion("iscompose is not null");
            return (Criteria) this;
        }

        public Criteria andIscomposeEqualTo(Byte value) {
            addCriterion("iscompose =", value, "iscompose");
            return (Criteria) this;
        }

        public Criteria andIscomposeNotEqualTo(Byte value) {
            addCriterion("iscompose <>", value, "iscompose");
            return (Criteria) this;
        }

        public Criteria andIscomposeGreaterThan(Byte value) {
            addCriterion("iscompose >", value, "iscompose");
            return (Criteria) this;
        }

        public Criteria andIscomposeGreaterThanOrEqualTo(Byte value) {
            addCriterion("iscompose >=", value, "iscompose");
            return (Criteria) this;
        }

        public Criteria andIscomposeLessThan(Byte value) {
            addCriterion("iscompose <", value, "iscompose");
            return (Criteria) this;
        }

        public Criteria andIscomposeLessThanOrEqualTo(Byte value) {
            addCriterion("iscompose <=", value, "iscompose");
            return (Criteria) this;
        }

        public Criteria andIscomposeIn(List<Byte> values) {
            addCriterion("iscompose in", values, "iscompose");
            return (Criteria) this;
        }

        public Criteria andIscomposeNotIn(List<Byte> values) {
            addCriterion("iscompose not in", values, "iscompose");
            return (Criteria) this;
        }

        public Criteria andIscomposeBetween(Byte value1, Byte value2) {
            addCriterion("iscompose between", value1, value2, "iscompose");
            return (Criteria) this;
        }

        public Criteria andIscomposeNotBetween(Byte value1, Byte value2) {
            addCriterion("iscompose not between", value1, value2, "iscompose");
            return (Criteria) this;
        }

        public Criteria andIsprepublishIsNull() {
            addCriterion("isprepublish is null");
            return (Criteria) this;
        }

        public Criteria andIsprepublishIsNotNull() {
            addCriterion("isprepublish is not null");
            return (Criteria) this;
        }

        public Criteria andIsprepublishEqualTo(Byte value) {
            addCriterion("isprepublish =", value, "isprepublish");
            return (Criteria) this;
        }

        public Criteria andIsprepublishNotEqualTo(Byte value) {
            addCriterion("isprepublish <>", value, "isprepublish");
            return (Criteria) this;
        }

        public Criteria andIsprepublishGreaterThan(Byte value) {
            addCriterion("isprepublish >", value, "isprepublish");
            return (Criteria) this;
        }

        public Criteria andIsprepublishGreaterThanOrEqualTo(Byte value) {
            addCriterion("isprepublish >=", value, "isprepublish");
            return (Criteria) this;
        }

        public Criteria andIsprepublishLessThan(Byte value) {
            addCriterion("isprepublish <", value, "isprepublish");
            return (Criteria) this;
        }

        public Criteria andIsprepublishLessThanOrEqualTo(Byte value) {
            addCriterion("isprepublish <=", value, "isprepublish");
            return (Criteria) this;
        }

        public Criteria andIsprepublishIn(List<Byte> values) {
            addCriterion("isprepublish in", values, "isprepublish");
            return (Criteria) this;
        }

        public Criteria andIsprepublishNotIn(List<Byte> values) {
            addCriterion("isprepublish not in", values, "isprepublish");
            return (Criteria) this;
        }

        public Criteria andIsprepublishBetween(Byte value1, Byte value2) {
            addCriterion("isprepublish between", value1, value2, "isprepublish");
            return (Criteria) this;
        }

        public Criteria andIsprepublishNotBetween(Byte value1, Byte value2) {
            addCriterion("isprepublish not between", value1, value2, "isprepublish");
            return (Criteria) this;
        }

        public Criteria andIspublishIsNull() {
            addCriterion("ispublish is null");
            return (Criteria) this;
        }

        public Criteria andIspublishIsNotNull() {
            addCriterion("ispublish is not null");
            return (Criteria) this;
        }

        public Criteria andIspublishEqualTo(Byte value) {
            addCriterion("ispublish =", value, "ispublish");
            return (Criteria) this;
        }

        public Criteria andIspublishNotEqualTo(Byte value) {
            addCriterion("ispublish <>", value, "ispublish");
            return (Criteria) this;
        }

        public Criteria andIspublishGreaterThan(Byte value) {
            addCriterion("ispublish >", value, "ispublish");
            return (Criteria) this;
        }

        public Criteria andIspublishGreaterThanOrEqualTo(Byte value) {
            addCriterion("ispublish >=", value, "ispublish");
            return (Criteria) this;
        }

        public Criteria andIspublishLessThan(Byte value) {
            addCriterion("ispublish <", value, "ispublish");
            return (Criteria) this;
        }

        public Criteria andIspublishLessThanOrEqualTo(Byte value) {
            addCriterion("ispublish <=", value, "ispublish");
            return (Criteria) this;
        }

        public Criteria andIspublishIn(List<Byte> values) {
            addCriterion("ispublish in", values, "ispublish");
            return (Criteria) this;
        }

        public Criteria andIspublishNotIn(List<Byte> values) {
            addCriterion("ispublish not in", values, "ispublish");
            return (Criteria) this;
        }

        public Criteria andIspublishBetween(Byte value1, Byte value2) {
            addCriterion("ispublish between", value1, value2, "ispublish");
            return (Criteria) this;
        }

        public Criteria andIspublishNotBetween(Byte value1, Byte value2) {
            addCriterion("ispublish not between", value1, value2, "ispublish");
            return (Criteria) this;
        }

        public Criteria andIshotIsNull() {
            addCriterion("ishot is null");
            return (Criteria) this;
        }

        public Criteria andIshotIsNotNull() {
            addCriterion("ishot is not null");
            return (Criteria) this;
        }

        public Criteria andIshotEqualTo(Byte value) {
            addCriterion("ishot =", value, "ishot");
            return (Criteria) this;
        }

        public Criteria andIshotNotEqualTo(Byte value) {
            addCriterion("ishot <>", value, "ishot");
            return (Criteria) this;
        }

        public Criteria andIshotGreaterThan(Byte value) {
            addCriterion("ishot >", value, "ishot");
            return (Criteria) this;
        }

        public Criteria andIshotGreaterThanOrEqualTo(Byte value) {
            addCriterion("ishot >=", value, "ishot");
            return (Criteria) this;
        }

        public Criteria andIshotLessThan(Byte value) {
            addCriterion("ishot <", value, "ishot");
            return (Criteria) this;
        }

        public Criteria andIshotLessThanOrEqualTo(Byte value) {
            addCriterion("ishot <=", value, "ishot");
            return (Criteria) this;
        }

        public Criteria andIshotIn(List<Byte> values) {
            addCriterion("ishot in", values, "ishot");
            return (Criteria) this;
        }

        public Criteria andIshotNotIn(List<Byte> values) {
            addCriterion("ishot not in", values, "ishot");
            return (Criteria) this;
        }

        public Criteria andIshotBetween(Byte value1, Byte value2) {
            addCriterion("ishot between", value1, value2, "ishot");
            return (Criteria) this;
        }

        public Criteria andIshotNotBetween(Byte value1, Byte value2) {
            addCriterion("ishot not between", value1, value2, "ishot");
            return (Criteria) this;
        }

        public Criteria andIsshowIsNull() {
            addCriterion("isshow is null");
            return (Criteria) this;
        }

        public Criteria andIsshowIsNotNull() {
            addCriterion("isshow is not null");
            return (Criteria) this;
        }

        public Criteria andIsshowEqualTo(Byte value) {
            addCriterion("isshow =", value, "isshow");
            return (Criteria) this;
        }

        public Criteria andIsshowNotEqualTo(Byte value) {
            addCriterion("isshow <>", value, "isshow");
            return (Criteria) this;
        }

        public Criteria andIsshowGreaterThan(Byte value) {
            addCriterion("isshow >", value, "isshow");
            return (Criteria) this;
        }

        public Criteria andIsshowGreaterThanOrEqualTo(Byte value) {
            addCriterion("isshow >=", value, "isshow");
            return (Criteria) this;
        }

        public Criteria andIsshowLessThan(Byte value) {
            addCriterion("isshow <", value, "isshow");
            return (Criteria) this;
        }

        public Criteria andIsshowLessThanOrEqualTo(Byte value) {
            addCriterion("isshow <=", value, "isshow");
            return (Criteria) this;
        }

        public Criteria andIsshowIn(List<Byte> values) {
            addCriterion("isshow in", values, "isshow");
            return (Criteria) this;
        }

        public Criteria andIsshowNotIn(List<Byte> values) {
            addCriterion("isshow not in", values, "isshow");
            return (Criteria) this;
        }

        public Criteria andIsshowBetween(Byte value1, Byte value2) {
            addCriterion("isshow between", value1, value2, "isshow");
            return (Criteria) this;
        }

        public Criteria andIsshowNotBetween(Byte value1, Byte value2) {
            addCriterion("isshow not between", value1, value2, "isshow");
            return (Criteria) this;
        }

        public Criteria andCourseMaximumIsNull() {
            addCriterion("course_maximum is null");
            return (Criteria) this;
        }

        public Criteria andCourseMaximumIsNotNull() {
            addCriterion("course_maximum is not null");
            return (Criteria) this;
        }

        public Criteria andCourseMaximumEqualTo(Integer value) {
            addCriterion("course_maximum =", value, "courseMaximum");
            return (Criteria) this;
        }

        public Criteria andCourseMaximumNotEqualTo(Integer value) {
            addCriterion("course_maximum <>", value, "courseMaximum");
            return (Criteria) this;
        }

        public Criteria andCourseMaximumGreaterThan(Integer value) {
            addCriterion("course_maximum >", value, "courseMaximum");
            return (Criteria) this;
        }

        public Criteria andCourseMaximumGreaterThanOrEqualTo(Integer value) {
            addCriterion("course_maximum >=", value, "courseMaximum");
            return (Criteria) this;
        }

        public Criteria andCourseMaximumLessThan(Integer value) {
            addCriterion("course_maximum <", value, "courseMaximum");
            return (Criteria) this;
        }

        public Criteria andCourseMaximumLessThanOrEqualTo(Integer value) {
            addCriterion("course_maximum <=", value, "courseMaximum");
            return (Criteria) this;
        }

        public Criteria andCourseMaximumIn(List<Integer> values) {
            addCriterion("course_maximum in", values, "courseMaximum");
            return (Criteria) this;
        }

        public Criteria andCourseMaximumNotIn(List<Integer> values) {
            addCriterion("course_maximum not in", values, "courseMaximum");
            return (Criteria) this;
        }

        public Criteria andCourseMaximumBetween(Integer value1, Integer value2) {
            addCriterion("course_maximum between", value1, value2, "courseMaximum");
            return (Criteria) this;
        }

        public Criteria andCourseMaximumNotBetween(Integer value1, Integer value2) {
            addCriterion("course_maximum not between", value1, value2, "courseMaximum");
            return (Criteria) this;
        }

        public Criteria andCreateByIsNull() {
            addCriterion("create_by is null");
            return (Criteria) this;
        }

        public Criteria andCreateByIsNotNull() {
            addCriterion("create_by is not null");
            return (Criteria) this;
        }

        public Criteria andCreateByEqualTo(Integer value) {
            addCriterion("create_by =", value, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByNotEqualTo(Integer value) {
            addCriterion("create_by <>", value, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByGreaterThan(Integer value) {
            addCriterion("create_by >", value, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByGreaterThanOrEqualTo(Integer value) {
            addCriterion("create_by >=", value, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByLessThan(Integer value) {
            addCriterion("create_by <", value, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByLessThanOrEqualTo(Integer value) {
            addCriterion("create_by <=", value, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByIn(List<Integer> values) {
            addCriterion("create_by in", values, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByNotIn(List<Integer> values) {
            addCriterion("create_by not in", values, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByBetween(Integer value1, Integer value2) {
            addCriterion("create_by between", value1, value2, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByNotBetween(Integer value1, Integer value2) {
            addCriterion("create_by not between", value1, value2, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNull() {
            addCriterion("create_time is null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNotNull() {
            addCriterion("create_time is not null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeEqualTo(Date value) {
            addCriterion("create_time =", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotEqualTo(Date value) {
            addCriterion("create_time <>", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThan(Date value) {
            addCriterion("create_time >", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("create_time >=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThan(Date value) {
            addCriterion("create_time <", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThanOrEqualTo(Date value) {
            addCriterion("create_time <=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIn(List<Date> values) {
            addCriterion("create_time in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotIn(List<Date> values) {
            addCriterion("create_time not in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeBetween(Date value1, Date value2) {
            addCriterion("create_time between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotBetween(Date value1, Date value2) {
            addCriterion("create_time not between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andUpdateByIsNull() {
            addCriterion("update_by is null");
            return (Criteria) this;
        }

        public Criteria andUpdateByIsNotNull() {
            addCriterion("update_by is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateByEqualTo(Integer value) {
            addCriterion("update_by =", value, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByNotEqualTo(Integer value) {
            addCriterion("update_by <>", value, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByGreaterThan(Integer value) {
            addCriterion("update_by >", value, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByGreaterThanOrEqualTo(Integer value) {
            addCriterion("update_by >=", value, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByLessThan(Integer value) {
            addCriterion("update_by <", value, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByLessThanOrEqualTo(Integer value) {
            addCriterion("update_by <=", value, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByIn(List<Integer> values) {
            addCriterion("update_by in", values, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByNotIn(List<Integer> values) {
            addCriterion("update_by not in", values, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByBetween(Integer value1, Integer value2) {
            addCriterion("update_by between", value1, value2, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByNotBetween(Integer value1, Integer value2) {
            addCriterion("update_by not between", value1, value2, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNull() {
            addCriterion("update_time is null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNotNull() {
            addCriterion("update_time is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeEqualTo(Date value) {
            addCriterion("update_time =", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotEqualTo(Date value) {
            addCriterion("update_time <>", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThan(Date value) {
            addCriterion("update_time >", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("update_time >=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThan(Date value) {
            addCriterion("update_time <", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThanOrEqualTo(Date value) {
            addCriterion("update_time <=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIn(List<Date> values) {
            addCriterion("update_time in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotIn(List<Date> values) {
            addCriterion("update_time not in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeBetween(Date value1, Date value2) {
            addCriterion("update_time between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotBetween(Date value1, Date value2) {
            addCriterion("update_time not between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andPublishByIsNull() {
            addCriterion("publish_by is null");
            return (Criteria) this;
        }

        public Criteria andPublishByIsNotNull() {
            addCriterion("publish_by is not null");
            return (Criteria) this;
        }

        public Criteria andPublishByEqualTo(Integer value) {
            addCriterion("publish_by =", value, "publishBy");
            return (Criteria) this;
        }

        public Criteria andPublishByNotEqualTo(Integer value) {
            addCriterion("publish_by <>", value, "publishBy");
            return (Criteria) this;
        }

        public Criteria andPublishByGreaterThan(Integer value) {
            addCriterion("publish_by >", value, "publishBy");
            return (Criteria) this;
        }

        public Criteria andPublishByGreaterThanOrEqualTo(Integer value) {
            addCriterion("publish_by >=", value, "publishBy");
            return (Criteria) this;
        }

        public Criteria andPublishByLessThan(Integer value) {
            addCriterion("publish_by <", value, "publishBy");
            return (Criteria) this;
        }

        public Criteria andPublishByLessThanOrEqualTo(Integer value) {
            addCriterion("publish_by <=", value, "publishBy");
            return (Criteria) this;
        }

        public Criteria andPublishByIn(List<Integer> values) {
            addCriterion("publish_by in", values, "publishBy");
            return (Criteria) this;
        }

        public Criteria andPublishByNotIn(List<Integer> values) {
            addCriterion("publish_by not in", values, "publishBy");
            return (Criteria) this;
        }

        public Criteria andPublishByBetween(Integer value1, Integer value2) {
            addCriterion("publish_by between", value1, value2, "publishBy");
            return (Criteria) this;
        }

        public Criteria andPublishByNotBetween(Integer value1, Integer value2) {
            addCriterion("publish_by not between", value1, value2, "publishBy");
            return (Criteria) this;
        }

        public Criteria andPublishTimeIsNull() {
            addCriterion("publish_time is null");
            return (Criteria) this;
        }

        public Criteria andPublishTimeIsNotNull() {
            addCriterion("publish_time is not null");
            return (Criteria) this;
        }

        public Criteria andPublishTimeEqualTo(Date value) {
            addCriterion("publish_time =", value, "publishTime");
            return (Criteria) this;
        }

        public Criteria andPublishTimeNotEqualTo(Date value) {
            addCriterion("publish_time <>", value, "publishTime");
            return (Criteria) this;
        }

        public Criteria andPublishTimeGreaterThan(Date value) {
            addCriterion("publish_time >", value, "publishTime");
            return (Criteria) this;
        }

        public Criteria andPublishTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("publish_time >=", value, "publishTime");
            return (Criteria) this;
        }

        public Criteria andPublishTimeLessThan(Date value) {
            addCriterion("publish_time <", value, "publishTime");
            return (Criteria) this;
        }

        public Criteria andPublishTimeLessThanOrEqualTo(Date value) {
            addCriterion("publish_time <=", value, "publishTime");
            return (Criteria) this;
        }

        public Criteria andPublishTimeIn(List<Date> values) {
            addCriterion("publish_time in", values, "publishTime");
            return (Criteria) this;
        }

        public Criteria andPublishTimeNotIn(List<Date> values) {
            addCriterion("publish_time not in", values, "publishTime");
            return (Criteria) this;
        }

        public Criteria andPublishTimeBetween(Date value1, Date value2) {
            addCriterion("publish_time between", value1, value2, "publishTime");
            return (Criteria) this;
        }

        public Criteria andPublishTimeNotBetween(Date value1, Date value2) {
            addCriterion("publish_time not between", value1, value2, "publishTime");
            return (Criteria) this;
        }

        public Criteria andIsdeleteIsNull() {
            addCriterion("isdelete is null");
            return (Criteria) this;
        }

        public Criteria andIsdeleteIsNotNull() {
            addCriterion("isdelete is not null");
            return (Criteria) this;
        }

        public Criteria andIsdeleteEqualTo(Byte value) {
            addCriterion("isdelete =", value, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteNotEqualTo(Byte value) {
            addCriterion("isdelete <>", value, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteGreaterThan(Byte value) {
            addCriterion("isdelete >", value, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteGreaterThanOrEqualTo(Byte value) {
            addCriterion("isdelete >=", value, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteLessThan(Byte value) {
            addCriterion("isdelete <", value, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteLessThanOrEqualTo(Byte value) {
            addCriterion("isdelete <=", value, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteIn(List<Byte> values) {
            addCriterion("isdelete in", values, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteNotIn(List<Byte> values) {
            addCriterion("isdelete not in", values, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteBetween(Byte value1, Byte value2) {
            addCriterion("isdelete between", value1, value2, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteNotBetween(Byte value1, Byte value2) {
            addCriterion("isdelete not between", value1, value2, "isdelete");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}