package com.ruida.mockdao.vo.report;

import lombok.Data;

import java.math.BigDecimal;

/**
 * @author chenjy
 * @since 2021/1/28 17:19
 */
@Data
public class InputScoreVO {

    private Integer subjectId;

    private BigDecimal score;
}
