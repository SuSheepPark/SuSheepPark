package com.ruida.cloud.model;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @author admin
 * @description: ${TODO}
 * @Date 2020/4/16
 * @verion 1.0
 */
@Data
public class PromotionActDisSta implements Serializable {
    private Integer promotionActivityId;
    private String distributorName;
    private Integer distributorId;
    /**
     * 订单总数
     */
    private Long totalOrderCount;
    /**
     * 总流量
     */
    private Long totalUv;
    /**
     * 有效流量
     */
    private Long totalEu;
    /**
     * 获得佣金总数
     */
    private BigDecimal totalCommission;
    /**
     * 平台总收入
     */
    private BigDecimal totalAmount;

    /**
     * 佣金比例
     */
    private String commissionRate;

}
