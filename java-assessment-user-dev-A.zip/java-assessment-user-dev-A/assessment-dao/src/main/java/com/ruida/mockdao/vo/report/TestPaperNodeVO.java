package com.ruida.mockdao.vo.report;

import lombok.Data;

import java.util.List;

@Data
public class TestPaperNodeVO {
	private Integer nodeId;
    private String nodeName;
    private Double score;
    private Double totalScore;
    private Double avgScore;
    private Double topScore;
    private List<TestPaperQuestionVO> questions;
}