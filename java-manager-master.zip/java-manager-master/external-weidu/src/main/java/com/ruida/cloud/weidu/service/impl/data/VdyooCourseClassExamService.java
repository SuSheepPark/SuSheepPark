package com.ruida.cloud.weidu.service.impl.data;

import com.ruida.cloud.weidu.utils.PropertyUtil;
import com.ruida.cloud.weidu.utils.VdyooUtil;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * @author taosh
 * @create 2019-04-24 10:56
 */
@Service
public class VdyooCourseClassExamService {
    private String vdyooPath = PropertyUtil.getProperty("vdyooTestApi");

    /**
     * 获取学生全部答题数据通过学生的ID来查询学生的答题情况
     */
    public void findCourseClassExam(){
        String path = vdyooPath+"/api/business/courseclassexam/findCourseClassExam";

        Map<String, String> param = VdyooUtil.getSignMap();

//        String response = HttpClientUtil.postMap(path, param);
//        System.out.println(response);
    }

    /**
     * 通过题号和教学计划查询发题信息
     */
    public void findCourseClassExamByExamNumBySchedule(String examNum, String scheduleId){
        String path = vdyooPath+"/api/business/courseclassexam/findCourseClassExamByExamNumBySchedule";

        Map<String, String> param = VdyooUtil.getSignMap();

        //题号
        param.put("examNum", examNum);
        //计划Id
        param.put("scheduleId", scheduleId);


//        String response = HttpClientUtil.postMap(path, param);
//        System.out.println(response);
    }

    /**
     * 教学计划不是必填项 但课程班是必填项
     * 第一：通过课程班查询发题信息
     * 第二：通过课程班和教学计划查询发题信息
     */
    public void findCourseClassExamByIdBySchedule(String courseClassId, String scheduleId){
        String path = vdyooPath+"/api/business/courseclassexam/findCourseClassExamByIdBySchedule";

        Map<String, String> param = VdyooUtil.getSignMap();

        //课程班ID
        param.put("courseClassId", courseClassId);
        //计划Id    非必填
        param.put("scheduleId", scheduleId);


//        String response = HttpClientUtil.postMap(path, param);
//        System.out.println(response);
    }
}
