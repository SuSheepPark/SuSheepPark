package com.ruida.cloud.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.util.Date;

@Data
public class DoubleClass {
    /**
     * 班级ID
     */
    private Integer classId;

    /**
     * 校管家班级ID
     */
    private String classIdXgj;

    /**
     * 班级名称
     */
    private String className;

    /**
     * 校区ID
     */
    private String campusId;

    /**
     * 校区名称
     */
    private String campusName;

    /**
     * 助教ID
     */
    private Integer assistantTeacherId;

    /*
       班级结业时间
     */
    private Date finishedDate;

    /**
     * 助教名称
     */
    private String assistantTeacherName;

    /**
     * 开班日期
     */
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    private Date openDate;

    /**
     * 校管家同步时间
     */
    private Date syncTimeXgj;

    /**
     * 百家云同步时间
     */
    private Date syncTimeBjy;

    /**
     * 状态
     */
    private Byte status;

    /**
     * 班级来源（0：校管家；1：本地创建）
     */
    private Byte source;

    /**
     * 直接返回来源给前端
     */
    private String sourceStr;

    /**
     * 创建者ID（关联user_id）
     */
    private Integer createBy;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新者ID（关联user_id）
     */
    private Integer updateBy;

    /**
     * 更新时间
     */
    private Date updateTime;

    /**
     * 是否删除（0：未删除；1：删除）
     */
    private Byte isdelete;

    /**
     * 学生总数
     */
    private Integer studentSum;

}