package com.ruida.cloud.dao;

import com.ruida.cloud.model.CourseCourseLessonRel;
import com.ruida.cloud.model.CourseCourseLessonRelExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface CourseCourseLessonRelMapper {
    int countByExample(CourseCourseLessonRelExample example);

    int deleteByExample(CourseCourseLessonRelExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(CourseCourseLessonRel record);

    int insertSelective(CourseCourseLessonRel record);

    List<CourseCourseLessonRel> selectByExample(CourseCourseLessonRelExample example);

    CourseCourseLessonRel selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") CourseCourseLessonRel record, @Param("example") CourseCourseLessonRelExample example);

    int updateByExample(@Param("record") CourseCourseLessonRel record, @Param("example") CourseCourseLessonRelExample example);

    int updateByPrimaryKeySelective(CourseCourseLessonRel record);

    int updateByPrimaryKey(CourseCourseLessonRel record);

    /**
     * 批量新增关联表
     */
    int insertLessonRelBatch(List<CourseCourseLessonRel> relList);

    List<String> listWeiduTeachPlanRel(Integer courseId);

    List<String> listWeiduCourseLessonRel(Integer courseId);
}