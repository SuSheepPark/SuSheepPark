package com.ruida.cloud.dao;

import com.ruida.cloud.model.SysUserDisableReason;
import com.ruida.cloud.model.SysUserDisableReasonExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface SysUserDisableReasonMapper {
    int countByExample(SysUserDisableReasonExample example);

    int deleteByExample(SysUserDisableReasonExample example);

    int deleteByPrimaryKey(Integer userDisableReasonId);

    int insert(SysUserDisableReason record);

    int insertSelective(SysUserDisableReason record);

    List<SysUserDisableReason> selectByExample(SysUserDisableReasonExample example);

    SysUserDisableReason selectByPrimaryKey(Integer userDisableReasonId);

    int updateByExampleSelective(@Param("record") SysUserDisableReason record, @Param("example") SysUserDisableReasonExample example);

    int updateByExample(@Param("record") SysUserDisableReason record, @Param("example") SysUserDisableReasonExample example);

    int updateByPrimaryKeySelective(SysUserDisableReason record);

    int updateByPrimaryKey(SysUserDisableReason record);
}