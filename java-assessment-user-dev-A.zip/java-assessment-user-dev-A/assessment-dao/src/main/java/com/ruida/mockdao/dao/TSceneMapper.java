package com.ruida.mockdao.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.model.TScene;
import com.ruida.mockdao.vo.SceneInfoVO;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 场次表 Mapper 接口
 * </p>
 *
 * @author szl
 * @since 2021-07-22
 */
public interface TSceneMapper extends BaseMapper<TScene> {

    /**
     * 查询五分钟内结束的场次
     * @return
     */
    List<TScene> selectIn5MinuteEnd();

    /**
     * 获取场次列表
     * @return
     */
    List<SceneInfoVO> getSceneList(@Param("stuId") Integer stuId);

}
