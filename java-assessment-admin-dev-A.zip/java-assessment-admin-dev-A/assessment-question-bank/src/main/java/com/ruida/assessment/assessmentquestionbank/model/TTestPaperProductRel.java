package com.ruida.assessment.assessmentquestionbank.model;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @author wy
 * @description 商品关联试题实体类
 * @date 2020/6/29
 */
@Data
@TableName("t_test_paper_product_rel")
public class TTestPaperProductRel extends BaseColumn implements Serializable {

	private static final long serialVersionUID = -9042595461705129547L;
	@TableId
	private Integer id;

	/**
	 * 试卷id
	 */
	private Integer testPaperId;


	/**
	 * 商品id
	 */
	private Integer productId;

	/**
	 * 初始化测试人数
	 */
	private Integer initTestNum = 0;

	/**
	 * 可测试次数
	 */
	private Integer allowTestNum;

	/**
	 * 试卷关联个人报告模板id，多个模板id用,拼接
	 */
	private String paperReportIds;

	/*
	 * 试卷关联班级学校报告模板id，多个id用 , 拼接
	 */
	private String paperScReportIds;

	/*
	 * 是否需要人工阅卷 0-否 1-是
	 */
	private Integer isartificial;

	/* 考试开始时间 */
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
	private Date testStartTime;

	/* 考试结束时间 */
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
	private Date testEndTime;

	/* 考试方式 0-练习 1-纸考 2-机房考 3-统考 */
	private Integer testWay;

	/* 是否是预售试卷 0-正常试卷 1-预售试卷 */
	private Integer ispresell = 0;

	/**
	 * 对应常模的id
	 */
	private Integer constRangeId;

	/**
	 * 试卷价格
	 */
	private BigDecimal paperPrice;

	/**
	 * 试卷ios价格
	 */
	private BigDecimal paperIosPrice;

	/**
	 * 报告价格
	 */
	private BigDecimal reportPrice;

	/**
	 * 报告ios价格
	 */
	private BigDecimal reportIosPrice;

	/**
	 * 阅卷方式(1-自动批阅 2-后台批阅 3-自主批阅) 多个用英文逗号分隔
	 */
	private String correctWay;


}
