package com.ruida.mockdao.vo.report;

import java.io.Serializable;

/**
 * @description: 科目得分情况VO
 * @author: kgz
 * @date: 2020/12/15
 */
public class SubjectScoreInfoVO implements Serializable {

    /*科目id*/
    private Integer subjectId;

    /*科目名称*/
    private String subjectName;

    /*年级id*/
    private Integer stageId;

    /*年级名称*/
    private String stageName;

    /*得分*/
    private Double score;

    /*满分*/
    private Double totalScore;

    /*本校平均分*/
    private Double schoolAvg;

    /*本校最高分*/
    private Double schoolTop;

    /*本校排名*/
    private Integer schoolRank;

    /*本校人数*/
    private Integer schoolNum;

    /*得分在本校的百分位*/
    private String schoolScorePercent;

    /*全体学生平均分*/
    private Double allAvg;

    /*全体学生最高分*/
    private Double allTop;

    /*在全体学生中的名次*/
    private Integer allRank;

    /*全体学生人数*/
    private Integer allNum;

    /*得分在全体学生中的百分位*/
    private String allScorePercent;

    /**
     * 预期可能达到的选考赋分或高考分数
     */
    private int calculateScore;

    /**
     * 成绩预期可能达到的高校层次
     */
    private String calculateCollegeLevel;

    public String getSubjectName() {
        return subjectName;
    }

    public void setSubjectName(String subjectName) {
        this.subjectName = subjectName;
    }

    public Double getScore() {
        return score;
    }

    public void setScore(Double score) {
        this.score = score;
    }

    public Double getTotalScore() {
        return totalScore;
    }

    public void setTotalScore(Double totalScore) {
        this.totalScore = totalScore;
    }

    public Double getSchoolAvg() {
        return schoolAvg;
    }

    public void setSchoolAvg(Double schoolAvg) {
        this.schoolAvg = schoolAvg;
    }

    public Double getSchoolTop() {
        return schoolTop;
    }

    public void setSchoolTop(Double schoolTop) {
        this.schoolTop = schoolTop;
    }

    public Integer getSchoolRank() {
        return schoolRank;
    }

    public void setSchoolRank(Integer schoolRank) {
        this.schoolRank = schoolRank;
    }

    public Integer getSchoolNum() {
        return schoolNum;
    }

    public void setSchoolNum(Integer schoolNum) {
        this.schoolNum = schoolNum;
    }

    public String getSchoolScorePercent() {
        return schoolScorePercent;
    }

    public void setSchoolScorePercent(String schoolScorePercent) {
        this.schoolScorePercent = schoolScorePercent;
    }

    public Double getAllAvg() {
        return allAvg;
    }

    public void setAllAvg(Double allAvg) {
        this.allAvg = allAvg;
    }

    public Double getAllTop() {
        return allTop;
    }

    public void setAllTop(Double allTop) {
        this.allTop = allTop;
    }

    public Integer getAllRank() {
        return allRank;
    }

    public void setAllRank(Integer allRank) {
        this.allRank = allRank;
    }

    public Integer getAllNum() {
        return allNum;
    }

    public void setAllNum(Integer allNum) {
        this.allNum = allNum;
    }

    public String getAllScorePercent() {
        return allScorePercent;
    }

    public void setAllScorePercent(String allScorePercent) {
        this.allScorePercent = allScorePercent;
    }

    public int getCalculateScore() {
        return calculateScore;
    }

    public void setCalculateScore(int calculateScore) {
        this.calculateScore = calculateScore;
    }

    public String getCalculateCollegeLevel() {
        return calculateCollegeLevel;
    }

    public void setCalculateCollegeLevel(String calculateCollegeLevel) {
        this.calculateCollegeLevel = calculateCollegeLevel;
    }

    public Integer getSubjectId() {
        return subjectId;
    }

    public void setSubjectId(Integer subjectId) {
        this.subjectId = subjectId;
    }

    public Integer getStageId() {
        return stageId;
    }

    public void setStageId(Integer stageId) {
        this.stageId = stageId;
    }

    public String getStageName() {
        return stageName;
    }

    public void setStageName(String stageName) {
        this.stageName = stageName;
    }

}
