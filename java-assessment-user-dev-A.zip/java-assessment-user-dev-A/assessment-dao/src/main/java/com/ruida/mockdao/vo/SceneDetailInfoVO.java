package com.ruida.mockdao.vo;

import lombok.Data;

import java.util.Date;

@Data
public class SceneDetailInfoVO {
    private String sceneId;
    private String sceneName;
    private Date startTime;
    private Date endTime;
    private Integer duration;
    private String examTime;
    private Integer status;
    private Integer allowLate;
    private String remainTime;
    private String attentionPath;


}
