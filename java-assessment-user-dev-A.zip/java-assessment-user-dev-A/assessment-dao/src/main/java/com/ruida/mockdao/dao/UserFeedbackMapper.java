package com.ruida.mockdao.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.model.UserFeedback;

/**
 * Created by xumingqi on 2021/5/26 9:00
 */
public interface UserFeedbackMapper extends BaseMapper<UserFeedback> {
}
