package com.ruida.assessment.assessmentcommon.enums;

/**
 * @description: 资讯栏目文章状态
 * @author: wy
 * @date: 2021/8/17
 */
public enum ColumnContentStatusEnum {
    DOWN(0,"下架"),
    UP(1,"上架"),
    DRAFT(2,"草稿"),

    ;

    private Integer K;
    private String V;

    ColumnContentStatusEnum(Integer k, String v) {
        K = k;
        V = v;
    }

    public Integer getK() {
        return K;
    }

    public void setK(Integer k) {
        K = k;
    }

    public String getV() {
        return V;
    }

    public void setV(String v) {
        V = v;
    }

    public static ColumnContentStatusEnum getValueById(Integer K){
        if(K != null){
            for(ColumnContentStatusEnum deleteStatusEnum : ColumnContentStatusEnum.values() ){
                if(deleteStatusEnum.getK().equals(K)){
                    return  deleteStatusEnum;
                }
            }
        }
        return null;
    }

}
