package com.ruida.assessment.assessmentquestionbank.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @description: 试卷操作DTO
 * @author: kgz
 * @date: 2020/7/2
 */
@ApiModel(description = "试卷操作信息")
public class TestPaperOperationDTO {
    @ApiModelProperty(value = "试卷id，逗号分隔", name = "testPaperIds", required = true)
    private String testPaperId;

    @ApiModelProperty(value = "操作id", name = "operationId", required = true)
    private Integer operationId;

    @ApiModelProperty(value = "退回原因", name = "rejectReason")
    private String rejectReason;

    /**
     * 获取试卷id
     * @return
     */
    public List<Integer> getTestPaperIdList(){
        List<String> list = Arrays.asList(testPaperId.split(","));
        List<Integer> testPaperIdlist = list.stream().map(item->Integer.valueOf(item)).collect(Collectors.toList());
        return testPaperIdlist;
    }

    public String getTestPaperId() {
        return testPaperId;
    }

    public void setTestPaperId(String testPaperId) {
        this.testPaperId = testPaperId;
    }

    public Integer getOperationId() {
        return operationId;
    }

    public void setOperationId(Integer operationId) {
        this.operationId = operationId;
    }

    public String getRejectReason() {
        return rejectReason;
    }

    public void setRejectReason(String rejectReason) {
        this.rejectReason = rejectReason;
    }

    @Override
    public String toString() {
        return "TestPaperOperationDTO{" +
                "testPaperId='" + testPaperId + '\'' +
                ", operationId=" + operationId +
                ", rejectReason='" + rejectReason + '\'' +
                '}';
    }
}
