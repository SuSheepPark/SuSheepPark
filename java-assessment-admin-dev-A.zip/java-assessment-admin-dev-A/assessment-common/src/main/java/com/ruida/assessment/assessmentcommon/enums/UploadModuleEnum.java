package com.ruida.assessment.assessmentcommon.enums;

/**
 * 阿里云上传文件模块
 */
public enum UploadModuleEnum {

    // 模块
    DEFAULT("DEFAULT", "assessment/", "默认区域"),
    NEWS_MODULE("NEWS_MODULE", "assessment/news/", "新闻资讯"),
    TEST_PAPER_MODULE("TEST_PAPER_MODULE", "assessment/testPaper/", "试卷"),
    BANNER_MODULE("BANNER_MODULE", "assessment/banner/", "banner图配置"),
    SCENE_MODULE("SCENE_MODULE", "assessment/scene/", "场次管理");


    String code = "";
    String path = "";
    String description = "";

    public String getCode() {
        return code;
    }

    public String getPath() {
        return path;
    }

    public String getDescription() {
        return description;
    }

    UploadModuleEnum(String code, String path, String description) {
        this.code = code;
        this.path = path;
        this.description = description;
    }

    public static String getPathByCode(String code){
        UploadModuleEnum[] enums = UploadModuleEnum.values();
        for(UploadModuleEnum uploadModuleEnum:enums){
            if(uploadModuleEnum.getCode().equals(code) ){
                return uploadModuleEnum.getPath();
            }
        }
        return "";
    }
}
