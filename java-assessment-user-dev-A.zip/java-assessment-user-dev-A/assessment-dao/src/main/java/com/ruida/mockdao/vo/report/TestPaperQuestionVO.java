package com.ruida.mockdao.vo.report;

import lombok.Data;

@Data
public class TestPaperQuestionVO {
	private String questionId;
    private String questionNum;
    private Integer questionTypeId;
    private Integer status;
    private Double percent;
    private Double totalScore;
    private Double avgScore;
    private Double score;
}