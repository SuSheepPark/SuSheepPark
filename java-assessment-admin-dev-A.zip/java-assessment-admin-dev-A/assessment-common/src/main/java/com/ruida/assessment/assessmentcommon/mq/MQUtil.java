package com.ruida.assessment.assessmentcommon.mq;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;


@Component
public class MQUtil {

    public static String env;

    @Value("${spring.profiles.active}")
    public void setEnv(String env) {
        MQUtil.env = env;
    }

    /**
     * 得到线上环境真实ID
     *
     * @param id
     * @return
     */
    public static String getRealId(String id) {
        return id + env;
    }

}
