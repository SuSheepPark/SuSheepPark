package com.ruida.common.enums;


import java.util.LinkedHashMap;
import java.util.Map;

public enum XiaoGuanJiaEventEnum {

    base_dept_create("base_dept_create","新增部门"),

    base_dept_modify("base_dept_modify","更新部门"),

    base_dept_remove("base_dept_remove","删除部门"),

    user_student_create("user_student_create","新增学员"),

    user_student_modify("user_student_modify","更新学员"),

    user_student_remove("user_student_remove","删除学员"),

    user_student_attend("user_student_attend","学员考勤"),

    edu_shift_create("edu_shift_create","新增课程"),

    edu_shift_modify("edu_shift_modify","更新课程"),

    edu_shift_remove("edu_shift_remove","删除课程"),

    edu_class_create("edu_class_create","新增班级"),

    edu_class_modify("edu_class_modify","更新班级"),

    edu_class_remove("edu_class_remove","删除班级"),

    edu_class_finish("edu_class_finish","班级结业"),

    edu_class_student_modify("edu_class_student_modify","班级学员变更"),

    edu_course_create("edu_course_create","新增排课"),

    edu_course_modify("edu_course_modify","更新排课"),

    edu_course_remove("edu_course_remove","删除排课"),

    edu_course_cancel("edu_course_cancel","取消排课"),

    edu_course_attend("edu_course_attend","点名上课"),

    edu_course_attendcancel("edu_course_attendcancel","撤销点名"),

    edu_course_student_modify("edu_course_student_modify","排课学员变更"),

    org_employee_create("org_employee_create","新增员工"),

    org_employee_modify("org_employee_modify","更新员工"),

    org_employee_remove("org_employee_remove","删除员工"),

    fin_fee_pay("fin_fee_pay","新增收费"),

    fin_receipt_cancel("fin_receipt_cancel","作废收据"),

    fin_receipt_refund("fin_receipt_refund","退费收据"),

    fin_receipt_trans("fin_receipt_trans","结转收据"),

    fin_fee_modify("fin_fee_modify","更新收据"),

    fin_account_create("fin_account_create","新增收款账户"),

    fin_account_modify("fin_account_modify","更新收款账户"),

    fin_account_remove("fin_account_remove","删除收款账户"),

    repo_goods_create("repo_goods_create","新增物品"),

    repo_goods_modify("repo_goods_modify","更新物品"),

    repo_goods_remove("repo_goods_remove","删除物品");




    private String k;
    private String v;

    XiaoGuanJiaEventEnum(String k, String v) {
        this.k = k;
        this.v = v;
    }

    public static Map<String,String> map = new LinkedHashMap<>(2);
    static
    {
        for(XiaoGuanJiaEventEnum type : XiaoGuanJiaEventEnum.values())
        {
            map.put(type.getK(),type.getV());
        }
    }

    public String getK() {
        return k;
    }

    public void setK(String k) {
        this.k = k;
    }

    public String getV() {
        return v;
    }

    public void setV(String v) {
        this.v = v;
    }

    public static XiaoGuanJiaEventEnum getXiaoGJk(String k) {
        XiaoGuanJiaEventEnum[] list = XiaoGuanJiaEventEnum.values();
        for (XiaoGuanJiaEventEnum valid : list) {
            if (valid.getK().equals(k)) {
                return valid;
            }
        }
        return null;
    }
}
