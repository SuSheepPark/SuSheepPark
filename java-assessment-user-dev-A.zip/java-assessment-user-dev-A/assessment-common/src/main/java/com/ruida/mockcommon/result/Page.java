package com.ruida.mockcommon.result;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @description:
 * @author szl
 * @Date 2018年12月10日
 * @verion 1.0
 */
public class Page<T> implements Serializable {

	private static final long serialVersionUID = -7645446638990972888L;
	
	/** 总记录数*/
	private Integer total;
	/** 当前页*/
	private Integer currentPage = 1;
	/** 页大小*/
	private Integer pageSize = 10;
	/** 总页数*/
	private Integer totalPage;
	/** 结果集*/
	private List<T> result;
	/**当前服务器时间**/
	@JsonFormat(pattern= "yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
	private Date nowTime;

	public Date getNowTime() {
		return nowTime;
	}

	public void setNowTime(Date nowTime) {
		this.nowTime = nowTime;
	}

	public Integer getTotalCount() {
		return total;
	}
	
	public void setTotalCount(Integer total) {
		this.total = total;
	}
	
	public Integer getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(Integer currentPage) {
		this.currentPage = currentPage;
	}

	public Integer getPageSize() {
		return pageSize;
	}

	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;

	}

	public List<T> getResult() {
		if (result == null) {
			return new ArrayList<T>();
		}
		return result;
	}

	public void setResult(List<T> result) {
		this.result = result;
	}

	public int getTotalPage() {
		if (pageSize == 0 || total == 0 || total == null || pageSize == null) {
			return 0;
		}
		totalPage = total % pageSize == 0 ? (total / pageSize) : (total / pageSize) + 1;
		return totalPage;
	}

	public void setTotalPage(int totalPage) {
		this.totalPage = totalPage;
	}

	public int getOffset() {
		return (currentPage - 1) * pageSize;
	}
	
	public void setPageNum(int pageNum) {
		this.currentPage=pageNum;
	}
}
