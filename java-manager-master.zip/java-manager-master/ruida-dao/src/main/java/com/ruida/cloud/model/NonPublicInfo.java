package com.ruida.cloud.model;

import java.io.Serializable;

/**
 * @author taosh
 * @create 2019-04-08 16:25
 */
public class NonPublicInfo implements Serializable {
    //班级id
    private Integer classId;
    //辅课教师id
    private Integer teacherId;

    public Integer getClassId() {
        return classId;
    }

    public void setClassId(Integer classId) {
        this.classId = classId;
    }

    public Integer getTeacherId() {
        return teacherId;
    }

    public void setTeacherId(Integer teacherId) {
        this.teacherId = teacherId;
    }
}
