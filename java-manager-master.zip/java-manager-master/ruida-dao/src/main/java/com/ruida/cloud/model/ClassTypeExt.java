package com.ruida.cloud.model;

import java.util.List;
import java.util.Map;

/**
 * @author taosh
 * @create 2019-07-26 17:13
 */
public class ClassTypeExt {
    private int classTypeId;

    private String classTypeName;

    private String period;

    private int difficulty;

    private List<Map<String, Object>> periodList;

    private String forCrowd;

    private String classForm;

    private String courseFeature;

    private String learningGoal;

    public String getForCrowd() {
        return forCrowd;
    }

    public void setForCrowd(String forCrowd) {
        this.forCrowd = forCrowd;
    }

    public String getClassForm() {
        return classForm;
    }

    public void setClassForm(String classForm) {
        this.classForm = classForm;
    }

    public String getCourseFeature() {
        return courseFeature;
    }

    public void setCourseFeature(String courseFeature) {
        this.courseFeature = courseFeature;
    }

    public String getLearningGoal() {
        return learningGoal;
    }

    public void setLearningGoal(String learningGoal) {
        this.learningGoal = learningGoal;
    }

    public int getClassTypeId() {
        return classTypeId;
    }

    public void setClassTypeId(int classTypeId) {
        this.classTypeId = classTypeId;
    }

    public String getClassTypeName() {
        return classTypeName;
    }

    public void setClassTypeName(String classTypeName) {
        this.classTypeName = classTypeName;
    }

    public String getPeriod() {
        return period;
    }

    public void setPeriod(String period) {
        this.period = period;
    }

    public List<Map<String, Object>> getPeriodList() {
        return periodList;
    }

    public void setPeriodList(List<Map<String, Object>> periodList) {
        this.periodList = periodList;
    }

    public int getDifficulty() {
        return difficulty;
    }

    public void setDifficulty(int difficulty) {
        this.difficulty = difficulty;
    }
}
