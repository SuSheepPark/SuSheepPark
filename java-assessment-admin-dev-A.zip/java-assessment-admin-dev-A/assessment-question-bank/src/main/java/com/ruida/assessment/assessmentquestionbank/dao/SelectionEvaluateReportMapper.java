package com.ruida.assessment.assessmentquestionbank.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.assessment.assessmentquestionbank.model.TEvaluateReport;
import com.ruida.assessment.assessmentquestionbank.vo.*;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @description:
 * @author: kgz
 * @date: 2020/12/18
 */
@Mapper
public interface SelectionEvaluateReportMapper extends BaseMapper<TEvaluateReport> {

    /**
     * 获取学生导入的成绩
     * @param uploadRecordId
     * @return
     */
    List<StuUploadExamRecordVO> getStuUploadExamRecord(Integer uploadRecordId);

    /**
     * 获取学校科目汇总成绩情况
     * @param currentExamUploadId
     * @param subjectListThree
     * @return
     */
    List<SchoolUploadExamRecordVO> getSchoolUploadExamRecord(@Param("currentExamUploadId") Integer currentExamUploadId, @Param("subjectList") List<Integer> subjectListThree);

    /**
     * 获取升学报告的所有科目
     * @param currentExamUploadId
     * @return
     */
    List<Integer> getSubject(Integer currentExamUploadId);

    /**
     * 获取学校科目得分情况
     * @param currentExamUploadId
     * @return
     */
    List<SchoolSubjectScoreVO> getSchoolSubjectUploadExamRecord(Integer currentExamUploadId);

    /**
     * 获取科目满分
     * @param stageId
     * @param subjectList
     * @return
     */
    Double getSubjectScoreSum(@Param("stageId") Integer stageId, @Param("subjectList") List<Integer> subjectList);

    /**
     * 获取商品所有成绩
     * @param productId
     * @return
     */
    List<StuUploadExamRecordVO> getExamRecord(Integer productId);

    /**
     * 获取学校科目汇总成绩
     * @param productId
     * @param subjectList
     * @return
     */
    List<SchoolUploadExamRecordVO> getSubjectExamRecord(@Param("productId") Integer productId, @Param("subjectList") List<Integer> subjectList);

    /**
     * 获取商品的所有科目
     * @param productId
     * @return
     */
    List<Integer> getExamSubject(@Param("productId") Integer productId);

    /**
     * 获取商品的学校科目成绩
     * @param productId
     * @return
     */
    List<SchoolSubjectScoreVO> getSchoolSubjectExamRecord(@Param("productId") Integer productId);

    /**
     * 获取报告对应的导入成绩
     * @param reportId
     * @return
     */
    List<EvaluateReportVO> getEvaluateReport(Integer reportId);

    /**
     * 获取导入的学校每科考试历史成绩
     * 按学校分组
     * @param subjectId
     * @param uploadIdList
     * @param currentUserIdList
     * @return
     */
    List<SchoolSubjectScoreVO> getHisSubjectScore(@Param("subjectId") Integer subjectId, @Param("uploadIdList") List<String> uploadIdList,
                                                  @Param("currentUserIdList") List<Integer> currentUserIdList);

    /**
     * 获取报告关联的商品id
     * @param reportId
     * @return
     */
    List<Integer> getRelProductId(Integer reportId);

    /**
     * 获取报告关联的商品的成绩
     * @param reportId
     * @param subjectId
     * @param currentUserIdList
     * @return
     */
    List<SchoolSubjectScoreVO> getProductSubjectScore(@Param("reportId") Integer reportId, @Param("subjectId") Integer subjectId,
                                                      @Param("currentUserIdList") List<Integer> currentUserIdList);

    /**
     * 获取当前报告所在年级的所有科目
     * @param stageId
     * @return
     */
    List<Integer> getAllSubject(Integer stageId);

    /**
     * 获取报告所在学段的所有年级
     * @param stageId
     * @return
     */
    List<StageVO> getStageId(Integer stageId);

    /**
     * 获取报告所在的学段
     * @param stageId
     * @return
     */
    Integer getPeriodId(Integer stageId);

    /**
     * 获取测试的名称
     * @param examIdList
     * @return
     */
    List<SchoolSubjectScoreVO> getExamName(@Param("examIdList") List<String> examIdList);

    /**
     * 获取学段的各科目满分
     * @param periodId
     * @return
     */
    List<SubjectSumScoreVO> getSubjectSumScoreByPeriod(Integer periodId);

    /**
     * 获取学生班级信息
     * @return
     */
    List<StudentInfoVo> getStudentClassInfo();

    /**
     * 获取历次测试的科目
     * @param reportId
     * @return
     */
    List<Integer> getHisSubjectId(Integer reportId);

    /**
     * 获取关联了平台数据的科目
     * @param reportId
     * @return
     */
    List<Integer> getPlatRelSubject(Integer reportId);
}
