package com.ruida.mockservice.service;

import com.baomidou.mybatisplus.service.IService;
import com.ruida.mockcommon.result.PojoResult;
import com.ruida.mockdao.model.MajorCategory;
import com.ruida.mockdao.vo.major.MajorGroupVO;

import java.util.List;

/**
 * <p>
 * 大学专业类表（不是专业表） 服务类
 * </p>
 *
 * @author xumingqi
 * @since 2021-01-14
 */
public interface MajorCategoryService extends IService<MajorCategory> {
    List<MajorGroupVO> getAllMajorGroup();
    PojoResult getAllMajorGroupByUser();
}
