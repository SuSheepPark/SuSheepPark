package com.ruida.cloud.model;

public class BaijiayunClass {
    /**
     * 主键
     */
    private Integer id;

    /**
     * 班级名称
     */
    private String className;

    /**
     * 校区id
     */
    private Integer zoneId;

    /**
     * 设备号
     */
    private String deviceUnique;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className == null ? null : className.trim();
    }

    public Integer getZoneId() {
        return zoneId;
    }

    public void setZoneId(Integer zoneId) {
        this.zoneId = zoneId;
    }

    public String getDeviceUnique() {
        return deviceUnique;
    }

    public void setDeviceUnique(String deviceUnique) {
        this.deviceUnique = deviceUnique == null ? null : deviceUnique.trim();
    }
}