package com.ruida.cloud.dao;

import com.ruida.cloud.model.SysUserStudyCoin;
import com.ruida.cloud.model.SysUserStudyCoinExample;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

public interface SysUserStudyCoinMapper {
    int countByExample(SysUserStudyCoinExample example);

    int deleteByExample(SysUserStudyCoinExample example);

    int deleteByPrimaryKey(Integer id);

    int insertSelective(SysUserStudyCoin record);

    List<SysUserStudyCoin> selectByExample(SysUserStudyCoinExample example);

    SysUserStudyCoin selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") SysUserStudyCoin record, @Param("example") SysUserStudyCoinExample example);

    int updateByExample(@Param("record") SysUserStudyCoin record, @Param("example") SysUserStudyCoinExample example);

    int updateByPrimaryKeySelective(SysUserStudyCoin record);

    int updateByPrimaryKey(SysUserStudyCoin record);

    /**
     * 用户学习币表添加
     *
     * @param record
     */
    int insert(SysUserStudyCoin record);

    /**
     * 更新用户学习币表数据
     *
     * @param sysUserStudyCoin1
     */
    int updateBySysUser(SysUserStudyCoin sysUserStudyCoin1);
}