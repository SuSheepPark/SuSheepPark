package com.ruida.mockservice.service.impl;

import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.ruida.mockdao.dao.ConstConfigMapper;
import com.ruida.mockdao.model.ConstConfig;
import com.ruida.mockservice.service.ConstConfigService;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 常模配置 服务实现类
 * </p>
 *
 * @author xumingqi
 * @since 2021-02-05
 */
@Service
public class ConstConfigServiceImpl extends ServiceImpl<ConstConfigMapper, ConstConfig> implements ConstConfigService {
}
