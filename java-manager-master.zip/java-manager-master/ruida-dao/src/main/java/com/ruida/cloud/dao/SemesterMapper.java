package com.ruida.cloud.dao;

import com.ruida.cloud.model.Semester;
import com.ruida.cloud.model.SemesterExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface SemesterMapper {
    long countByExample(SemesterExample example);

    int deleteByExample(SemesterExample example);

    int deleteByPrimaryKey(Integer semesterId);

    int insert(Semester record);

    int insertSelective(Semester record);

    List<Semester> selectByExample(SemesterExample example);

    Semester selectByPrimaryKey(Integer semesterId);

    int updateByExampleSelective(@Param("record") Semester record, @Param("example") SemesterExample example);

    int updateByExample(@Param("record") Semester record, @Param("example") SemesterExample example);

    int updateByPrimaryKeySelective(Semester record);

    int updateByPrimaryKey(Semester record);
}