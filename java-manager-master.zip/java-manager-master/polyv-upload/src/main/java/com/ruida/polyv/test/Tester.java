package com.ruida.polyv.test;

import com.ruida.common.polyvparam.PolyvParam;
import com.ruida.common.vo.Result;
import com.ruida.polyv.sdk.PolyvSDKClient;
import com.ruida.polyv.sdk.Video;
import com.ruida.polyv.util.Progress;
import com.ruida.polyv.util.UploadListener;

import java.util.List;

public class Tester {
	public static void main(String[] args) {
        PolyvSDKClient client = PolyvSDKClient.getInstance();
//        client.setReadtoken(PolyvParam.READTOKEN);
//        client.setWritetoken(PolyvParam.WRITETOKEN);
//        client.setSecretkey(PolyvParam.SECRETKEY);
//        client.setUserid(PolyvParam.USERID);
		
        //testResumableUpload();
		// TODO Auto-generated method stub
		long start = System.currentTimeMillis();
		testUpload();
		long end = System.currentTimeMillis();
		System.out.println(end-start);
		//testResumableUpload();
        //testDeleteVideo();
		//testUpload();
	}
	/**
	 * 断点续传上传实例
	 */
	public static void testResumableUpload(){
		
	    PolyvSDKClient client = PolyvSDKClient.getInstance();

		String vid = "";
		try {
			vid = client.resumableUpload("/Users/hhl/Desktop/videos/share.mp4", "标题11", "", "", 1,new Progress(){
				@Override
				public void run(long offset, long max) {
					// TODO Auto-generated method stub
					int percent = (int)(offset*100/max);
					System.out.println(percent);
				}
			},new UploadListener() {
				
				@Override
				public void success(String body) {
					System.out.println("上传成功："+body);
				}
				
				@Override
				public void fail(Exception ex) {
					System.out.println("上传失败："+ex.getLocalizedMessage());
				}
			});
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.out.println(vid);
	}

	public static void testGet() {
		try {
			Video v = PolyvSDKClient.getInstance().getVideo("01b768ec8cd3226845437dd10b93fc06_0");
			System.out.println(v.getStatus());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void testUpload() {
		Thread t = new Thread(new Runnable() {
			@Override
			public void run() {
				Video v;
				try {
					v = PolyvSDKClient.getInstance().upload("D:\\Tool\\apache-tomcat-8.5.28\\temp\\不要让任何人打乱你的节奏.flv",
							"我的标题", "tag", "desc", 0);

					System.out.println(v.getVid()+"   "+v.getFirstImage());
				} catch (Exception e) {
					// TODO Auto-generated catch block
					System.out.println(e.getMessage());
					e.printStackTrace();
				}
			}
		});
		t.start();

		while(true){
			int percent = PolyvSDKClient.getInstance().getPercent();
			if(percent==100){
				break;
			}
			System.out.println("upload percent: " + percent + "%");
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}


	}

	public static void testDeleteVideo() {
		try {

			boolean result = PolyvSDKClient.getInstance().deleteVideo(
					"sl8da4jjbxa1077082a56e35adef93c4_s");
			System.out.println(result);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void testListVideo() {
		try {
			List<Video> list = PolyvSDKClient.getInstance().getVideoList(1, 20);
			for (int i = 0; i < list.size(); i++) {
				Video v = list.get(i);
				System.out.println(v.getVid() + "/" + v.getTitle());
			}
			System.out.println("----查看结束----");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
