package com.ruida.cloud.daoTmp;

import com.ruida.cloud.model.CourseCampusRel;
import com.ruida.cloud.model.TeachingClassExt;

import java.io.Serializable;
import java.util.List;

/**
 * @author taosh
 * @create 2019-05-28 16:13
 */
public class CourseCampusInfo extends CourseCampusRel implements Serializable {
    /**课程id*/
    private Integer courseId;

    /**校区id*/
    private Integer campusId;

    private String campusName;

    /**剩余坐席*/
    private Integer surplusNum;

    /***/
    private Integer alreadyNum;

    /**未排班人数*/
    private Integer freeNum;

    private Integer maximum;

    /**学生端信息(1:n)*/
    private List<TeachingClassExt> teachingClassList;

    /**线上可报名人数*/
    private Integer campusOnlineStuNum;

    /**线下 还可以 报名人数*/
    private Integer campusUnderlineStuNum;

    public Integer getCampusUnderlineStuNum() {
        return campusUnderlineStuNum;
    }

    public void setCampusUnderlineStuNum(Integer campusUnderlineStuNum) {
        this.campusUnderlineStuNum = campusUnderlineStuNum;
    }

    public Integer getMaximum() {
        return maximum;
    }

    public void setMaximum(Integer maximum) {
        this.maximum = maximum;
    }

    public Integer getAlreadyNum() {
        return alreadyNum;
    }

    public void setAlreadyNum(Integer alreadyNum) {
        this.alreadyNum = alreadyNum;
    }

    @Override
    public Integer getCourseId() {
        return courseId;
    }

    @Override
    public void setCourseId(Integer courseId) {
        this.courseId = courseId;
    }

    @Override
    public Integer getCampusId() {
        return campusId;
    }

    @Override
    public void setCampusId(Integer campusId) {
        this.campusId = campusId;
    }

    public String getCampusName() {
        return campusName;
    }

    public void setCampusName(String campusName) {
        this.campusName = campusName;
    }

    public Integer getSurplusNum() {
        return surplusNum;
    }

    public void setSurplusNum(Integer surplusNum) {
        this.surplusNum = surplusNum;
    }

    public Integer getFreeNum() {
        return freeNum;
    }

    public void setFreeNum(Integer freeNum) {
        this.freeNum = freeNum;
    }

    public List<TeachingClassExt> getTeachingClassList() {
        return teachingClassList;
    }

    public void setTeachingClassList(List<TeachingClassExt> teachingClassList) {
        this.teachingClassList = teachingClassList;
    }

    @Override
    public Integer getCampusOnlineStuNum() {
        return campusOnlineStuNum;
    }

    @Override
    public void setCampusOnlineStuNum(Integer campusOnlineStuNum) {
        this.campusOnlineStuNum = campusOnlineStuNum;
    }
}
