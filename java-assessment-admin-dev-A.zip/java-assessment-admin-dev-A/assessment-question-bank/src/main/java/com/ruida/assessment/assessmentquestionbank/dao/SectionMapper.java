package com.ruida.assessment.assessmentquestionbank.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.assessment.assessmentquestionbank.dto.BatchOperationRequest;
import com.ruida.assessment.assessmentquestionbank.dto.KnowledgeRequest;
import com.ruida.assessment.assessmentquestionbank.dto.SectionRequest;
import com.ruida.assessment.assessmentquestionbank.model.TKnowledge;
import com.ruida.assessment.assessmentquestionbank.model.TSection;
import com.ruida.assessment.assessmentquestionbank.model.TSectionKnowledge;
import com.ruida.assessment.assessmentquestionbank.vo.KnowledgeTreeVo;
import com.ruida.assessment.assessmentquestionbank.vo.SectionTreeVo;
import org.apache.ibatis.annotations.Param;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * @author wy
 * @description 章节mapper
 * @date 2020/6/10
 */
@Mapper
public interface SectionMapper extends BaseMapper<TSection> {

    /*
        查询所有跟知识点关联的章节id集合
     */
    List<Integer> selectAllSectionRelationKnowledgeIds();

    /*
        根据章节id查询关联的知识点
     */
    List<TSectionKnowledge> selectRelationKnowledgeBySectionId(@Param("sectionId") Integer sectionId);

    /*
        单条插入章节-知识点关联数据
     */
    Integer insertKnowledgeRelation(@Param("item") TSectionKnowledge sectionKnowledges);

    Integer deleteKnowledgeByRelationId(@Param("vo") BatchOperationRequest request);
}
