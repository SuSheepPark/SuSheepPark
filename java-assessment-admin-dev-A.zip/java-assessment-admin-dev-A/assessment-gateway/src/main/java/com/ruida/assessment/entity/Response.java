package com.ruida.assessment.entity;

import lombok.Data;

import java.io.Serializable;
@Data
public class Response implements Serializable {
 private String message;
 private String  code;
}
