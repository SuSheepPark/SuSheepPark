package com.ruida.mockdao.vo.product;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * Created by xumingqi on 2021/7/1 8:42
 */
@Data
@ApiModel("试卷、报告信息")
public class PaperReportVO {
    @ApiModelProperty("试卷id")
    Integer testPaperId;

    @ApiModelProperty("是否预售")
    Integer ispresell;

    @ApiModelProperty("科目名")
    String subjectName;

    @ApiModelProperty("试卷名")
    String testPaperName;

    @ApiModelProperty("年级名，如高一上")
    String stageName;

    @ApiModelProperty("年份")
    Integer year;

    @ApiModelProperty("教材版本")
    private String materialVersionName;

    @ApiModelProperty("答题试卷，如60分钟")
    String answerTime;

    @ApiModelProperty("试卷价格")
    String testPaperPrice;

    @ApiModelProperty("试卷ios价格")
    String testPaperIosPrice;

    @ApiModelProperty("试卷是否已购买")
    boolean paperHaveBuy;

    @ApiModelProperty("试卷是否已领取")
    boolean paperFreeGet;

    //以下是报告的信息

    @ApiModelProperty("报告id(取值来自t_test_paper_product_rel表的主键)")
    Integer reportId;

    @ApiModelProperty("报告名称")
    String reportName;

    @ApiModelProperty("报告价格")
    String reportPrice;

    @ApiModelProperty("报告ios价格")
    String reportIosPrice;

    @ApiModelProperty("报告是否已购买")
    boolean reportHaveBuy;

    @ApiModelProperty(value = "答题方式(1-在线答题 2-纸面答题)")
    private Integer answerWay;
}
