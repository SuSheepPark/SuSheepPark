package com.ruida.cloud.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class PromotionActivityCommission implements Serializable {
    private Integer commissionId;

    private Integer promotionActivityId;

    private Integer distributorLevelOne;

    private BigDecimal distributorLevelOneRate;

    private Integer distributorLevelTwo;

    private BigDecimal distributorLevelTwoRate;

    private Integer createBy;

    private Date createTime;

    private Integer updateBy;

    private Date updateTime;

    private Byte isdelete;

    /**以及分销商自己佣金比例*/
    private BigDecimal distributorLevelOneRateSelf;

    private static final long serialVersionUID = 1L;

    public Integer getCommissionId() {
        return commissionId;
    }

    public void setCommissionId(Integer commissionId) {
        this.commissionId = commissionId;
    }

    public Integer getPromotionActivityId() {
        return promotionActivityId;
    }

    public void setPromotionActivityId(Integer promotionActivityId) {
        this.promotionActivityId = promotionActivityId;
    }

    public Integer getDistributorLevelOne() {
        return distributorLevelOne;
    }

    public void setDistributorLevelOne(Integer distributorLevelOne) {
        this.distributorLevelOne = distributorLevelOne;
    }

    public BigDecimal getDistributorLevelOneRate() {
        return distributorLevelOneRate;
    }

    public void setDistributorLevelOneRate(BigDecimal distributorLevelOneRate) {
        this.distributorLevelOneRate = distributorLevelOneRate;
    }

    public Integer getDistributorLevelTwo() {
        return distributorLevelTwo;
    }

    public void setDistributorLevelTwo(Integer distributorLevelTwo) {
        this.distributorLevelTwo = distributorLevelTwo;
    }

    public BigDecimal getDistributorLevelTwoRate() {
        return distributorLevelTwoRate;
    }

    public void setDistributorLevelTwoRate(BigDecimal distributorLevelTwoRate) {
        this.distributorLevelTwoRate = distributorLevelTwoRate;
    }

    public Integer getCreateBy() {
        return createBy;
    }

    public void setCreateBy(Integer createBy) {
        this.createBy = createBy;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(Integer updateBy) {
        this.updateBy = updateBy;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Byte getIsdelete() {
        return isdelete;
    }

    public void setIsdelete(Byte isdelete) {
        this.isdelete = isdelete;
    }

    public BigDecimal getDistributorLevelOneRateSelf() {
        return distributorLevelOneRateSelf;
    }

    public void setDistributorLevelOneRateSelf(BigDecimal distributorLevelOneRateSelf) {
        this.distributorLevelOneRateSelf = distributorLevelOneRateSelf;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", commissionId=").append(commissionId);
        sb.append(", promotionActivityId=").append(promotionActivityId);
        sb.append(", distributorLevelOne=").append(distributorLevelOne);
        sb.append(", distributorLevelOneRate=").append(distributorLevelOneRate);
        sb.append(", distributorLevelTwo=").append(distributorLevelTwo);
        sb.append(", distributorLevelTwoRate=").append(distributorLevelTwoRate);
        sb.append(", createBy=").append(createBy);
        sb.append(", createTime=").append(createTime);
        sb.append(", updateBy=").append(updateBy);
        sb.append(", updateTime=").append(updateTime);
        sb.append(", isdelete=").append(isdelete);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}