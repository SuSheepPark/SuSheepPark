package com.ruida.mockcommon.enums;

/**
 * @author xumingqi
 * @date 2021/2/7 9:53
 */
public enum ProductTypeEnum {
    TEST_PAPER(0, "试卷"),
    JOB_INTEREST_QUESTIONNAIRE(2, "职业兴趣测试问卷"),
    SUBJECT_CHOOSE_REPORT(3, "选科推荐报告"),
    WISH_FILLING_REPORT(4, "志愿填报报告");

    private Integer k;
    private String v;

    ProductTypeEnum(Integer k, String v) {
        this.k = k;
        this.v = v;
    }

    public Integer getK() {
        return k;
    }

    public void setK(Integer k) {
        this.k = k;
    }

    public String getV() {
        return v;
    }

    public void setV(String v) {
        this.v = v;
    }
}
