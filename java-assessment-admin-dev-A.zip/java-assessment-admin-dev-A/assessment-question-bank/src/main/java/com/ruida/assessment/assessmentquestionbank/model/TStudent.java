package com.ruida.assessment.assessmentquestionbank.model;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import io.swagger.annotations.ApiModel;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @author wy
 * @description 考生数据库实体类
 * @date 2020/7/31
 */
@Data
@ApiModel(description = "考生数据库实体")
@TableName("t_student")
public class TStudent extends BaseColumn implements Serializable {


    private static final long serialVersionUID = -4943224407008545172L;
    /**
     * 主键ID
     */
    @TableId
    private Integer stuId;

    /*
    用户id
     */
    private Integer userId;

    /*
    考生准考证号
     */
    private String stuNo;

    /*
    考生姓名
     */
    private String stuName;

    /*
  学生账号
   */
    private String stuAccount;

    private Integer age;

    private Integer sex;

    /*
    身份证号
     */
    private String idCard;

    private String telephone;

    private Integer sourceChannel;

    /*
    考生类型 0-默认用户生成的虚拟考生 1-导入的考生
     */
    private Integer stuType;

}
