package com.ruida.mockdao.dao;


import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.dto.MyExamPaperRequest;
import com.ruida.mockdao.dto.TestPaperQueryRequest;
import com.ruida.mockdao.model.TestPaper;
import com.ruida.mockdao.vo.*;
import com.ruida.mockdao.vo.product.PaperReportVO;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 试卷表 Mapper 接口
 * </p>
 *
 * @author jinhu
 * @since 2020-07-08
 */
public interface TestPaperMapper extends BaseMapper<TestPaper> {

    /**
     * 查询试卷详情.只包含题号列表，无题目详情
     *
     * @param testPaperId
     * @return
     */
    TestPaperVO queryPaperBaseInfo(@Param("testPaperId") Integer testPaperId);

    /**
     * 查询自主阅卷试卷详情
     *
     * @param testPaperId 试卷id
     */
    SelfCheckPaperVO querySelfCheckPaperInfo(@Param("testPaperId") Integer testPaperId);

    /*
     *功能描述
     * @param 查询商品列表
     * @return
     */
    List<TestPaperInProductVO> queryPaperList(@Param("vo") TestPaperQueryRequest req);

    /*
     *功能描述
     * @param 查询商品列表
     * @return
     */
    List<PaperReportVO> queryPaperListNew(@Param("vo") TestPaperQueryRequest req);


    /*
     *功能描述
     * @param 查询我的考试记录列表
     * @return
     */
    List<MyExamRecordVO> queryMyExamList(@Param("vo") MyExamPaperRequest req);

    /*
     *功能描述
     * @param  查询我的考试记录列表总数
     * @return
     */
    Integer queryMyExamCount(@Param("vo") MyExamPaperRequest req);

    /**
     * 查询题型信息
     * @param testPaperId
     * @return
     */
    List<QuestionTypeVO> queryQuestionTypeInfo(@Param("testPaperId") Integer testPaperId);

    /*
     *功能描述
     * @param 查询预售试卷列表
     * @return
     */
    List<TestPaperInProductVO> queryPreSellPaperList(@Param("vo") TestPaperQueryRequest req);

    /**
     * 获取选科兴趣测试题目数量
     * @return
     */
    Integer getInterestQuestionCount();

    /**
     * 获取职业兴趣测试题目数量
     * @return
     */
    Integer getVocationalInterestQuestionCount();
}
