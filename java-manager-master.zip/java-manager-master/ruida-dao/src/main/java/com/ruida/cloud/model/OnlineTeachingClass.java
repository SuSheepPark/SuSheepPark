package com.ruida.cloud.model;

import java.io.Serializable;
import java.util.Date;

public class OnlineTeachingClass implements Serializable {
    private Integer onlineTeachingClassId;

    private Integer courseId;

    private Integer courseLessonId;

    private String onlineTeachingClassName;

    private Integer assistantTeacherId;

    private Integer province;

    private Integer city;

    private Integer district;

    private Integer createBy;

    private Date createTime;

    private Integer updateBy;

    private Date updateTime;

    private Byte isdelete;

    private static final long serialVersionUID = 1L;

    private Integer onlineTeachingClassIdNew;

    public Integer getOnlineTeachingClassIdNew() {
        return onlineTeachingClassIdNew;
    }

    public void setOnlineTeachingClassIdNew(Integer onlineTeachingClassIdNew) {
        this.onlineTeachingClassIdNew = onlineTeachingClassIdNew;
    }

    public Integer getOnlineTeachingClassId() {
        return onlineTeachingClassId;
    }

    public void setOnlineTeachingClassId(Integer onlineTeachingClassId) {
        this.onlineTeachingClassId = onlineTeachingClassId;
    }

    public Integer getCourseId() {
        return courseId;
    }

    public void setCourseId(Integer courseId) {
        this.courseId = courseId;
    }

    public Integer getCourseLessonId() {
        return courseLessonId;
    }

    public void setCourseLessonId(Integer courseLessonId) {
        this.courseLessonId = courseLessonId;
    }

    public String getOnlineTeachingClassName() {
        return onlineTeachingClassName;
    }

    public void setOnlineTeachingClassName(String onlineTeachingClassName) {
        this.onlineTeachingClassName = onlineTeachingClassName == null ? null : onlineTeachingClassName.trim();
    }

    public Integer getAssistantTeacherId() {
        return assistantTeacherId;
    }

    public void setAssistantTeacherId(Integer assistantTeacherId) {
        this.assistantTeacherId = assistantTeacherId;
    }

    public Integer getProvince() {
        return province;
    }

    public void setProvince(Integer province) {
        this.province = province;
    }

    public Integer getCity() {
        return city;
    }

    public void setCity(Integer city) {
        this.city = city;
    }

    public Integer getDistrict() {
        return district;
    }

    public void setDistrict(Integer district) {
        this.district = district;
    }

    public Integer getCreateBy() {
        return createBy;
    }

    public void setCreateBy(Integer createBy) {
        this.createBy = createBy;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(Integer updateBy) {
        this.updateBy = updateBy;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Byte getIsdelete() {
        return isdelete;
    }

    public void setIsdelete(Byte isdelete) {
        this.isdelete = isdelete;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", onlineTeachingClassId=").append(onlineTeachingClassId);
        sb.append(", courseId=").append(courseId);
        sb.append(", courseLessonId=").append(courseLessonId);
        sb.append(", onlineTeachingClassName=").append(onlineTeachingClassName);
        sb.append(", assistantTeacherId=").append(assistantTeacherId);
        sb.append(", province=").append(province);
        sb.append(", city=").append(city);
        sb.append(", district=").append(district);
        sb.append(", createBy=").append(createBy);
        sb.append(", createTime=").append(createTime);
        sb.append(", updateBy=").append(updateBy);
        sb.append(", updateTime=").append(updateTime);
        sb.append(", isdelete=").append(isdelete);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}