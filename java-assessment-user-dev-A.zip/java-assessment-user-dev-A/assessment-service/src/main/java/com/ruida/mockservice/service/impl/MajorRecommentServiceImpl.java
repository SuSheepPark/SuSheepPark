package com.ruida.mockservice.service.impl;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.baomidou.mybatisplus.toolkit.CollectionUtils;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.ruida.mockcommon.enums.CollegeLevelNewEnum;
import com.ruida.mockcommon.exception.CoreException;
import com.ruida.mockcommon.util.ValidateMT;
import com.ruida.mockdao.dao.TMajorCollegeMapper;
import com.ruida.mockdao.dao.TMajorRecommendMapper;
import com.ruida.mockdao.model.*;
import com.ruida.mockdao.vo.OptionalSubjectReportVO;
import com.ruida.mockservice.service.*;
import com.ruida.mockservice.vo.preference.RecommendMajorVO;
import lombok.Data;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.*;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

@Service
public class MajorRecommentServiceImpl extends ServiceImpl<TMajorRecommendMapper, TMajorRecommend> implements MajorRecommentService {
    @Resource
    MajorSelectRecordService majorSelectRecordService;
    @Resource
    MajorSelectDetailService majorSelectDetailService;
    @Resource
    TMajorRecommendMapper majorRecommendMapper;
    @Resource
    TMajorCollegeMapper collegeMapper;
    @Resource
    ReportService reportService;
    @Resource
    SchemaReportService schemaReportService;
    @Resource
    ISysConfigService sysConfigService;
    @Resource
    TCeeRankService ceeRankService;
    @Override
    @Transactional(rollbackFor = Exception.class)
    public List<CollegeVO> getMajorRecommentList(Integer reportId, List<String> subjectNames, String userId) {
        subjectNames.forEach(a -> {
            if (StringUtils.equals("政治", a)) {
                a = "思想政治";
            }
        });

        SchemaReport schemaReport = schemaReportService.selectById(reportId);
        if (schemaReport == null) {
            throw new CoreException("500", "报告不存在");
        }
        OptionalSubjectReportVO reportVO = reportService.getOptionalSubjectReport(schemaReport.getFormerRecordId());
        BigDecimal dealScore = reportVO.getExamRecoreSummary().getScore();
        Double totalScore = dealScore.doubleValue();//高考预估分数
        //检查是否已经生成过此报告的专业推荐
        EntityWrapper<TMajorRecommend> checkEntityWr = new EntityWrapper<>();
        checkEntityWr.eq("report_id", reportId)
                .eq("type", 0)
                .eq("user_id", Integer.valueOf(userId)).eq("isdelete", 0);
        List<TMajorRecommend> existList = majorRecommendMapper.selectList(checkEntityWr);
        if (CollectionUtils.isNotEmpty(existList)) {
            return dealMajorRecommentData(existList);
        }

        //获取最新专业兴趣选择列表
        EntityWrapper<MajorSelectRecord> selectRecordWrapper = new EntityWrapper<>();
        selectRecordWrapper.eq("user_id", userId).
                eq("isdelete", 0).orderBy("create_time", false);
        List<MajorSelectRecord> selectRecords = majorSelectRecordService.selectList(selectRecordWrapper);
        if (CollectionUtils.isEmpty(selectRecords)) {
            throw new CoreException("500", "请参加专业兴趣测试");
        }
        MajorSelectRecord selectRecord = selectRecords.get(0);
        EntityWrapper<MajorSelectDetail> entityWrapper = new EntityWrapper<>();
        entityWrapper.eq("user_id", userId).eq("isdelete", 0)
                .eq("record_id", selectRecord.getId());
        List<MajorSelectDetail> majorSelectDetailList = majorSelectDetailService.selectList(entityWrapper);
        List<TMajorCollege> recommendMajorList = new ArrayList<>();
        List<String> codeList = new ArrayList<>();
        majorSelectDetailList.forEach(a -> {
            codeList.add(a.getMajorCategoryCode());
        });
        Map<String, Object> param = new HashMap<>();
        param.put("codeList", codeList);
        List<TMajorCollege> collegeList = collegeMapper.getMajorRecommentList(param);
        collegeList.forEach(b -> {
            String subjectLimitStr = b.getSubjectLimits();
            if (StringUtils.isNotBlank(subjectLimitStr) && subjectLimitStr.contains("(")) {
                int end = subjectLimitStr.indexOf("(");
                String substr = subjectLimitStr.substring(0, end);
                String[] subjects = substr.split(",");
                for (int i = 0; i < subjects.length; i++) {
                    String subject = subjects[i];
                    if (subjectLimitStr.contains("即可") && subjectNames.contains(subject)) {
                        recommendMajorList.add(b);
                        break;
                    } else if (subjectLimitStr.contains("方可")) {
                        if (!subjectNames.contains(subject)) {
                            break;
                        } else if (i == subjects.length - 1) {
                            recommendMajorList.add(b);
                        }

                    }
                }
            } else {
                recommendMajorList.add(b);
            }
        });

        if (CollectionUtils.isEmpty(recommendMajorList)) {
            throw new CoreException("500", "暂无符合条件的专业可推荐，请调整专业类后再来生成报告吧");
        }
        Map<String, List<TMajorCollege>> recommendMajorMap = recommendMajorList.stream().collect(Collectors.groupingBy(TMajorCollege::getCollegeCode));
        List<College> collegeInfoList = new ArrayList<>();
        recommendMajorMap.forEach((k, v) -> {
            College collegeInfo = new College();
            TMajorCollege college = v.get(0);//最小分数专业
            collegeInfo.setCollegeLevel(college.getCollegeLevel());
            collegeInfo.setMinAdmitScore(college.getAdmitScore());
            collegeInfo.setCollegeCode(k);
            collegeInfo.setCollegeList(v);
            collegeInfo.setCollegeName(college.getCollegeName());
            collegeInfo.setCollegeLevelName(college.getCollegeLevelName());
            collegeInfo.setPlanNum(college.getPlanNum());
            collegeInfoList.add(collegeInfo);
        });
        Map<Integer, List<College>> collegeMap = collegeInfoList.stream().collect(Collectors.groupingBy(College::getCollegeLevel));
        Map<Integer, List<College>> sortCollegeMap = orderByKey(collegeMap, false);//按层级排序
        AtomicReference<Integer> sort = new AtomicReference<>(0);//专业顺序
        AtomicReference<Double> eqScore = new AtomicReference<>(0.0);
        List<TMajorRecommend> collegeVOList = new ArrayList<>();

        Integer finalReportId = reportId;
        String finalUserId = userId;
        sortCollegeMap.forEach((k, v) -> {
            //同层次按录取分数线排序
            v = v.stream().sorted(Comparator.comparing(College::getMinAdmitScore).reversed()).collect(Collectors.toList());
            //学校里面的专业选择
            v.forEach(a -> {
                a.getCollegeList().removeIf(i -> {
                    //删除未达到分数线的
                    return i.getMinScore() > totalScore;
                });
                //同一个学校的专业按概率从大到小排序
                Map<Double, TMajorCollege> sortMap = new TreeMap<>(Comparator.reverseOrder());
                a.getCollegeList().forEach(b -> {
                    //每一分录取概率
                    Double perRate = 50 / (b.getMaxScore() - b.getMinScore());
                    if (totalScore >= b.getMinScore()) {
                        Double admitRate = (totalScore - b.getMinScore()) * perRate;//录取概率
                        sortMap.put(admitRate, b);
                    }
                });
                sortMap.forEach((admit, college) -> {
                    if (sort.get() < 80 || (sort.get() >= 80 && eqScore.get().equals(college.getMinScore()))) {
                        if (sort.get() == 79 ){
                            eqScore.set(college.getMinScore());
                        }
                        sort.getAndSet(sort.get() + 1);
                        //todo 推荐出来的数据做数据库存储
                        TMajorRecommend majorRecommend = new TMajorRecommend();
                        majorRecommend.setAdmitScore(college.getMinScore());
                        majorRecommend.setCode(college.getCode());
                        majorRecommend.setCollegeName(college.getCollegeName());
                        majorRecommend.setSubjectCategoryName(college.getSubjectCategoryName());
                        majorRecommend.setMajorCategoryName(college.getMajorCategoryName());
                        majorRecommend.setMajorName(college.getMajorName());
                        majorRecommend.setUserId(Integer.valueOf(finalUserId));
                        majorRecommend.setReportId(finalReportId);
                        majorRecommend.setCreateTime(new Date());
                        majorRecommend.setUpdateTime(new Date());
                        majorRecommend.setSort(sort.get());
                        majorRecommend.setCollegeLevel(college.getCollegeLevel());
                        majorRecommend.setCollegeLevelName(college.getCollegeLevelName());
                        majorRecommend.setPlanNum(college.getPlanNum());
                        majorRecommend.setProvince(college.getProvince());
                        majorRecommend.setType(0);
                        majorRecommendMapper.insert(majorRecommend);
                        collegeVOList.add(majorRecommend);
                    }

                });
            });
        });


        List<CollegeVO> resultCollegeVOs = dealMajorRecommentData(collegeVOList);
        return resultCollegeVOs;
    }

    /**
     * 获取高校层次信息
     *
     * @return
     */
    @Override
    public List<Map<String, Object>> getCollegeLevelList(Integer reportId, Integer userId) {
        List<Map<String, Object>> list = handleCollegeLevelList(reportId, userId, 0);
        return list;
    }


    @Override
    public LinkedHashMap<Integer, List<RecommendMajorVO>> getMajorRecommendListByPreference(Integer reportId, List<String> subjectNames, String userId, Double totalScore) {
        LinkedHashMap<Integer, List<RecommendMajorVO>> resultMap = new LinkedHashMap<>(4);

        AtomicReference<Double> atomicTotalScore = new AtomicReference<>(totalScore);
        List<String> subjectList = Lists.newArrayList();
        subjectNames.forEach(a -> {
            if (StringUtils.equals("政治", a)) {
                a = "思想政治";
            }
            subjectList.add(a);
        });
        //检查是否已经生成过此报告的专业推荐
        EntityWrapper<TMajorRecommend> checkEntityWr = new EntityWrapper<>();
        checkEntityWr.eq("report_id", reportId)
                .eq("type", 1)
                .eq("user_id", Integer.valueOf(userId)).eq("isdelete", 0);
        List<TMajorRecommend> existList = majorRecommendMapper.selectList(checkEntityWr);
        if (CollectionUtils.isNotEmpty(existList)) {
            LinkedHashMap<Integer, List<TMajorRecommend>> startColleageMap = existList.stream().collect(Collectors.groupingBy(TMajorRecommend::getStar, LinkedHashMap::new, Collectors.toList()));//按星星排序
            startColleageMap.forEach((k, v) -> {
                List<RecommendMajorVO> recommendMajorVOList = this.getRecommendMajorVOList(v);
                resultMap.put(k, recommendMajorVOList);
            });
            return resultMap;
        }

        Map<String,Object> rankMap = ceeRankService.thisYearRank(totalScore);
        Double lastMaxScore =   (Double)  rankMap.get("lastMaxScore");//去年最高分
        Integer thisYearRank =  (Integer) rankMap.get("thisRank"); //今年排名
        Double lastYearMaxScore = lastMaxScore+1d;//去年最高分
        //是否用去年一分一段分数转换
        String isSwitch = sysConfigService.getValueByKey("score_conversion_open");
        if (ValidateMT.isNotNull(isSwitch) && StringUtils.equals("1",isSwitch)) {
            totalScore =    ceeRankService.getScoreConversion(totalScore);
            atomicTotalScore.set(totalScore);
        }
        //获取最新专业兴趣选择列表
        EntityWrapper<MajorSelectRecord> selectRecordWrapper = new EntityWrapper<>();
        selectRecordWrapper.eq("user_id", userId).
                eq("isdelete", 0).orderBy("create_time", false);
        List<MajorSelectRecord> selectRecords = majorSelectRecordService.selectList(selectRecordWrapper);
        if (CollectionUtils.isEmpty(selectRecords)) {
            throw new CoreException("500", "请参加专业兴趣测试");
        }
        MajorSelectRecord selectRecord = selectRecords.get(0);
        EntityWrapper<MajorSelectDetail> entityWrapper = new EntityWrapper<>();
        entityWrapper.eq("user_id", userId).eq("isdelete", 0)
                .eq("record_id", selectRecord.getId());
        List<MajorSelectDetail> majorSelectDetailList = majorSelectDetailService.selectList(entityWrapper);
        List<TMajorCollege> recommendMajorList = new ArrayList<>();
        List<String> codeList = new ArrayList<>();
        majorSelectDetailList.forEach(a -> {
            codeList.add(a.getMajorCategoryCode());
        });
        Map<String, Object> param = new HashMap<>();
        param.put("codeList", codeList);
        List<TMajorCollege> collegeList = collegeMapper.getMajorRecommentList(param);
        collegeList.forEach(b -> {
            String subjectLimitStr = b.getSubjectLimits();
            if (StringUtils.isNotBlank(subjectLimitStr) && subjectLimitStr.contains("(")) {
                int end = subjectLimitStr.indexOf("(");
                String substr = subjectLimitStr.substring(0, end);
                String[] subjects = substr.split(",");
                for (int i = 0; i < subjects.length; i++) {
                    String subject = subjects[i];
                    if (subjectLimitStr.contains("即可") && subjectList.contains(subject)) {
                        recommendMajorList.add(b);
                        break;
                    } else if (subjectLimitStr.contains("方可")) {
                        if (!subjectList.contains(subject)) {
                            break;
                        } else if (i == subjects.length - 1) {
                            recommendMajorList.add(b);
                        }

                    }
                }
            } else {
                recommendMajorList.add(b);
            }
        });

        if (CollectionUtils.isEmpty(recommendMajorList)) {
            return resultMap;
        }
        Map<String, List<TMajorCollege>> recommendMajorMap = recommendMajorList.stream().collect(Collectors.groupingBy(TMajorCollege::getCollegeCode));
        List<College> collegeInfoList = new ArrayList<>();
        recommendMajorMap.forEach((k, v) -> {
            College collegeInfo = new College();
            TMajorCollege college = v.get(0);//最小分数专业
            collegeInfo.setCollegeLevel(college.getCollegeLevel());
            collegeInfo.setMinAdmitScore(college.getAdmitScore());
            collegeInfo.setCollegeCode(k);
            collegeInfo.setCollegeList(v);
            collegeInfo.setCollegeName(college.getCollegeName());
            collegeInfo.setCollegeLevelName(college.getCollegeLevelName());
            collegeInfo.setPlanNum(college.getPlanNum());
            collegeInfoList.add(collegeInfo);
        });
        Map<Integer, List<College>> collegeMap = collegeInfoList.stream().collect(Collectors.groupingBy(College::getCollegeLevel));
        Map<Integer, List<College>> sortCollegeMap = orderByKey(collegeMap, false);//按层级排序
        AtomicReference<Integer> sort = new AtomicReference<>(0);
        AtomicReference<Integer> sort1 = new AtomicReference<>(0);
        AtomicReference<Integer> sort2 = new AtomicReference<>(0);
        AtomicReference<Integer> sort3 = new AtomicReference<>(0);
        AtomicReference<Double> eqScore1 = new AtomicReference<>(0.0);
        AtomicReference<Double> eqScore2 =  new AtomicReference<>(0.0);
        AtomicReference<Double> eqScore3 =  new AtomicReference<>(0.0);
        AtomicReference<Integer> eqScoreLevel1 = new AtomicReference<>(1);
        AtomicReference<Integer> eqScoreLevel2 =  new AtomicReference<>(1);
        AtomicReference<Integer> eqScoreLevel3 =  new AtomicReference<>(1);
        List<TMajorRecommend> collegeVOList = new ArrayList<>();

        Integer finalReportId = reportId;
        String finalUserId = userId;
        sortCollegeMap.forEach((k, v) -> {
            //同层次按录取分数线排序
            v = v.stream().sorted(Comparator.comparing(College::getMinAdmitScore).reversed()).collect(Collectors.toList());
            //学校里面的专业选择
            v.forEach(a -> {
//                a.getCollegeList().removeIf(i -> {
//                    //删除未达到分数线的
//                    Double firtScore = i.getMinScore() - 40.0; //概率0.4时候的分数
//                    firtScore = dealScore(firtScore);
//                    return firtScore > atomicTotalScore.get();
//                });
                //同一个学校的专业按概率从大到小排序
//                Map<Double, TMajorCollege> firstSortMap = new TreeMap<>(Comparator.reverseOrder());
//                Map<Double, TMajorCollege> secondSortMap = new TreeMap<>(Comparator.reverseOrder());
//                Map<Double, TMajorCollege> lastSortMap = new TreeMap<>(Comparator.reverseOrder());
                Map<TMajorCollege,Double> firstSortMap = new LinkedHashMap<>();
                Map<TMajorCollege,Double > secondSortMap = new LinkedHashMap<>();
                Map<TMajorCollege,Double> lastSortMap = new LinkedHashMap<>();
                List<TMajorRecommend> firstList = new ArrayList<>();
                List<TMajorRecommend> secondList = new ArrayList<>();
                List<TMajorRecommend> lastList = new ArrayList<>();
                a.getCollegeList().forEach(b -> {
                    //新录取概率
                    //概率计算
                    Double perRate = thisYearRank/(lastYearMaxScore-atomicTotalScore.get());
                    Double rate = 50+(b.getAdmitRank()-thisYearRank)/perRate;
                    Double firstLine = 5.00;
                    Double secondLine = 45.00;
                    Double thirdLine = 110.00;
                    Double diffLine = 100.00;
                    if (atomicTotalScore.get()<500){
                         firstLine = 5.00;
                         secondLine = 45.00;
                         thirdLine = 75.00;
                         diffLine = 150.00;
                    }
                    if (atomicTotalScore.get()<400){
                        firstLine = 30.00;
                        secondLine = 50.00;
                        thirdLine = 60.00;
                        diffLine = 200.00;
                    }
                    if (atomicTotalScore.get()<300){
                        Double diffScore = atomicTotalScore.get() - b.getMinScore();
                        if (diffScore<=0 && diffScore > -50 && b.getCollegeLevel().equals(k)){
                            firstSortMap.put(b,diffScore);
                        }else if (diffScore>0 && diffScore<50 && b.getCollegeLevel().equals(k)){
                            secondSortMap.put(b,diffScore);
                        }else if (diffScore>50 && b.getCollegeLevel().equals(k)){
                            lastSortMap.put(b,diffScore);
                        }
                    }else {
                        if (rate>=firstLine && rate<secondLine && b.getCollegeLevel().equals(k)){
                            firstSortMap.put(b,rate);
                        }else if (rate>=secondLine && rate <thirdLine && b.getCollegeLevel().equals(k)){
                            secondSortMap.put(b,rate);
                        }else if (rate >=thirdLine && (atomicTotalScore.get() - b.getMinScore())<diffLine && b.getCollegeLevel().equals(k)){
                            lastSortMap.put(b,rate);
                        }
                    }


                    //每一分录取概率
/*                    BigDecimal perRate = BigDecimal.ONE;
                    Double firtScore = b.getMinScore() - 20.0; //概率0.4时候的分数
                    Double secondScore = b.getMinScore() + 0.9 * (b.getMaxScore() - b.getMinScore());//概率0.8的分数
                    if (!b.getMaxScore().equals(b.getMinScore())) {
                        perRate = new BigDecimal(0.5).divide(new BigDecimal(b.getMaxScore() - b.getMinScore()), BigDecimal.ROUND_HALF_UP);
                        firtScore = dealScore(firtScore);
                        secondScore = dealScore(secondScore);
                    } else {
                        firtScore = b.getMinScore();
                        secondScore = b.getMinScore();
                    }
                    if (atomicTotalScore.get() >= firtScore && atomicTotalScore.get() < b.getMinScore()) {
                        BigDecimal firstPerRate = new BigDecimal(0.005);
                        Double admitRate = new BigDecimal(atomicTotalScore.get() - b.getMinScore()).multiply(firstPerRate).doubleValue();//录取概率
                        firstSortMap.put(admitRate, b);
                    } else if ((atomicTotalScore.get() >= b.getMinScore()) && (atomicTotalScore.get() < secondScore)
                            && (atomicTotalScore.get()-b.getMinScore()<=30)) {
                        Double admitRate = new BigDecimal(atomicTotalScore.get() - b.getMinScore()).multiply(perRate).doubleValue();//录取概率
                        secondSortMap.put(admitRate, b);
                    } else if ((atomicTotalScore.get() >= secondScore) && (atomicTotalScore.get()-b.getMinScore()<=50)) {
                        Double admitRate = new BigDecimal(atomicTotalScore.get() - b.getMinScore()).multiply(perRate).doubleValue();//录取概率
                        lastSortMap.put(admitRate, b);
                    }*/
                });
                Map<TMajorCollege,Double>     eachFirstSortMap = orderByValue(firstSortMap);
                Map<TMajorCollege,Double>   eachSecondSortMap = orderByValue(secondSortMap);
                Map<TMajorCollege,Double>   eachLastSortMap = orderByValue(lastSortMap);
                eachFirstSortMap.forEach((college,admit ) -> {
                    if (sort1.get() < 40 || (sort1.get() >= 40 && eqScore1.get().equals(college.getMinScore())
                            && eqScoreLevel1.get().equals(college.getCollegeLevel()))) {
                        if (sort1.get() == 39){
                            eqScore1.set(college.getMinScore());
                            eqScoreLevel1.set(college.getCollegeLevel());
                        }
                        sort.getAndSet(sort.get() + 1);
                        sort1.getAndSet(sort1.get() + 1);
                        //todo 推荐出来的数据做数据库存储
                        TMajorRecommend majorRecommend = new TMajorRecommend();
                        majorRecommend.setAdmitScore(college.getMinScore());
                        majorRecommend.setCode(college.getCode());
                        majorRecommend.setCollegeName(college.getCollegeName());
                        majorRecommend.setSubjectCategoryName(college.getSubjectCategoryName());
                        majorRecommend.setMajorCategoryName(college.getMajorCategoryName());
                        majorRecommend.setMajorName(college.getMajorName());
                        majorRecommend.setUserId(Integer.valueOf(finalUserId));
                        majorRecommend.setReportId(finalReportId);
                        majorRecommend.setCreateTime(new Date());
                        majorRecommend.setUpdateTime(new Date());
                        majorRecommend.setSort(sort.get());
                        majorRecommend.setType(1);
                        majorRecommend.setStar(2);
                        majorRecommend.setCollegeLevel(college.getCollegeLevel());
                        majorRecommend.setCollegeLevelName(college.getCollegeLevelName());
                        majorRecommend.setPlanNum(college.getPlanNum());
                        majorRecommend.setProvince(college.getProvince());
                        firstList.add(majorRecommend);
                        collegeVOList.add(majorRecommend);
                    }
                });
                if (CollectionUtils.isNotEmpty(firstList)){
                    this.insertBatch(firstList);
                }

                eachSecondSortMap.forEach((college,admit ) -> {
                    if (sort2.get() < 80 || (sort2.get() >= 80 && eqScore2.get().equals(college.getMinScore())
                            && eqScoreLevel2.get().equals(college.getCollegeLevel()))) {
                        if (sort2.get() == 79){
                            eqScore2.set(college.getMinScore());
                            eqScoreLevel2.set(college.getCollegeLevel());
                        }
                        sort.getAndSet(sort.get() + 1);
                        sort2.getAndSet(sort2.get() + 1);
                        //todo 推荐出来的数据做数据库存储
                        TMajorRecommend majorRecommend = new TMajorRecommend();
                        majorRecommend.setAdmitScore(college.getMinScore());
                        majorRecommend.setCode(college.getCode());
                        majorRecommend.setCollegeName(college.getCollegeName());
                        majorRecommend.setSubjectCategoryName(college.getSubjectCategoryName());
                        majorRecommend.setMajorCategoryName(college.getMajorCategoryName());
                        majorRecommend.setMajorName(college.getMajorName());
                        majorRecommend.setUserId(Integer.valueOf(finalUserId));
                        majorRecommend.setReportId(finalReportId);
                        majorRecommend.setCreateTime(new Date());
                        majorRecommend.setUpdateTime(new Date());
                        majorRecommend.setSort(sort.get());
                        majorRecommend.setType(1);
                        majorRecommend.setStar(3);
                        majorRecommend.setCollegeLevel(college.getCollegeLevel());
                        majorRecommend.setCollegeLevelName(college.getCollegeLevelName());
                        majorRecommend.setPlanNum(college.getPlanNum());
                        majorRecommend.setProvince(college.getProvince());
                        secondList.add(majorRecommend);
                        collegeVOList.add(majorRecommend);
                    }
                });
                if (CollectionUtils.isNotEmpty(secondList)){
                    this.insertBatch(secondList);
                }
                eachLastSortMap.forEach((college,admit) -> {
                    if (sort3.get() < 40 || (sort3.get() >= 40 && eqScore3.get().equals(college.getMinScore())
                            && eqScoreLevel3.get().equals(college.getCollegeLevel()))) {
                        if (sort3.get() == 39){
                            eqScore3.set(college.getMinScore());
                            eqScoreLevel3.set(college.getCollegeLevel());
                        }
                        sort.getAndSet(sort.get() + 1);
                        sort3.getAndSet(sort3.get() + 1);
                        //todo 推荐出来的数据做数据库存储
                        TMajorRecommend majorRecommend = new TMajorRecommend();
                        majorRecommend.setAdmitScore(college.getMinScore());
                        majorRecommend.setCode(college.getCode());
                        majorRecommend.setCollegeName(college.getCollegeName());
                        majorRecommend.setSubjectCategoryName(college.getSubjectCategoryName());
                        majorRecommend.setMajorCategoryName(college.getMajorCategoryName());
                        majorRecommend.setMajorName(college.getMajorName());
                        majorRecommend.setUserId(Integer.valueOf(finalUserId));
                        majorRecommend.setReportId(finalReportId);
                        majorRecommend.setCreateTime(new Date());
                        majorRecommend.setUpdateTime(new Date());
                        majorRecommend.setStar(1);
                        majorRecommend.setSort(sort.get());
                        majorRecommend.setType(1);
                        majorRecommend.setCollegeLevel(college.getCollegeLevel());
                        majorRecommend.setCollegeLevelName(college.getCollegeLevelName());
                        majorRecommend.setPlanNum(college.getPlanNum());
                        majorRecommend.setProvince(college.getProvince());
                        lastList.add(majorRecommend);
                        collegeVOList.add(majorRecommend);
                    }
                });
                if (CollectionUtils.isNotEmpty(lastList)){
                    this.insertBatch(lastList);
                }
            });
        });
        LinkedHashMap<Integer, List<TMajorRecommend>> startColleageMap = collegeVOList.stream().collect(Collectors.groupingBy(TMajorRecommend::getStar, LinkedHashMap::new, Collectors.toList()));//按星星排序
        startColleageMap.forEach((k, v) -> {
            List<RecommendMajorVO> recommendMajorVOList = this.getRecommendMajorVOList(v);
            resultMap.put(k, recommendMajorVOList);
        });
        return resultMap;
    }

    /**
     * 把TMajorRecommend转换成RecommendMajorVO
     */
    private List<RecommendMajorVO> getRecommendMajorVOList(List<TMajorRecommend> majorRecommendList) {
        List<RecommendMajorVO> recommendMajorVOList = Lists.newArrayList();
        for (TMajorRecommend majorRecommend : majorRecommendList) {
            RecommendMajorVO majorVO = new RecommendMajorVO();
            majorVO.setCollegeName(majorRecommend.getCollegeName());
            majorVO.setCollegeLevelName(CollegeLevelNewEnum.getValueById(majorRecommend.getCollegeLevel()));
            majorVO.setProvince(majorRecommend.getProvince());
            majorVO.setSubjectCategoryName(majorRecommend.getSubjectCategoryName());
            majorVO.setMajorCategoryName(majorRecommend.getMajorCategoryName());
            majorVO.setMajorName(majorRecommend.getMajorName());
            majorVO.setScore(majorRecommend.getAdmitScore());
            majorVO.setPlanNum(majorRecommend.getPlanNum());
            recommendMajorVOList.add(majorVO);
        }
        return recommendMajorVOList;
    }

    @Override
    public List<Map<String, Object>> getCollegeLevelListByPreference(Integer reportId, Integer userId) {
        List<Map<String, Object>> list = handleCollegeLevelList(reportId, userId, 1);
        return list;
    }


    /**
     * 返回数据结构处理
     *
     * @param list
     * @return
     */
    @Override
    public List<CollegeVO> dealMajorRecommentData(List<TMajorRecommend> list) {
        List<CollegeVO> resultCollegeVOs = new ArrayList<>();//返回结果数据结构
        LinkedHashMap<String, List<TMajorRecommend>> colleageMap = list.stream().collect(Collectors.groupingBy(TMajorRecommend::getCollegeName, LinkedHashMap::new, Collectors.toList()));
        colleageMap.forEach((k, v) -> {
            //---返回结果结构处理
            CollegeVO resultCollegeVO = new CollegeVO();
            resultCollegeVOs.add(resultCollegeVO);
            List<SubjectCategory> subjectCategoryList = new ArrayList<>();
            resultCollegeVO.setSubjectCategoryList(subjectCategoryList);
            resultCollegeVO.setCollegeName(k);//---返回结果结构处理
            String collegeLevelName = v.get(0).getCollegeLevelName();
            resultCollegeVO.setCollegeLevelName(StringUtils.isNotEmpty(collegeLevelName) ? collegeLevelName
                    : CollegeLevelNewEnum.getValueById(v.get(0).getCollegeLevel()));
            resultCollegeVO.setProvince(v.get(0).getProvince());

            LinkedHashMap<String, List<TMajorRecommend>> subjectMap = v.stream().collect(Collectors.groupingBy(TMajorRecommend::getSubjectCategoryName, LinkedHashMap::new, Collectors.toList()));
            subjectMap.forEach((k1, v1) -> {
                SubjectCategory subjectCategory = new SubjectCategory();
                subjectCategoryList.add(subjectCategory);
                List<MajorCategory> majorCategoryList = new ArrayList<>();
                subjectCategory.setSubjectCategoryName(k1);
                subjectCategory.setMajorCategoryList(majorCategoryList);

                LinkedHashMap<String, List<TMajorRecommend>> MajorCMap = v1.stream().collect(Collectors.groupingBy(TMajorRecommend::getMajorCategoryName, LinkedHashMap::new, Collectors.toList()));
                MajorCMap.forEach((k2, v2) -> {
                    MajorCategory majorCategory = new MajorCategory();
                    majorCategoryList.add(majorCategory);
                    List<Major> majors = new ArrayList<>();
                    majorCategory.setMajorCategoryName(k2);
                    majorCategory.setMajorList(majors);
                    v2.forEach(a -> {
                        Major major = new Major();
                        majors.add(major);
                        major.setMajorName(a.getMajorName());
                        major.setScore(a.getAdmitScore());
                        major.setPlanNum(a.getPlanNum());
                        major.setStar(a.getStar());
                    });

                });
            });
        });

        return resultCollegeVOs;

    }

    /**
     * 高校层次信息公用
     *
     * @param reportId
     * @param userId
     * @return
     */
    private List<Map<String, Object>> handleCollegeLevelList(Integer reportId, Integer userId, Integer type) {
        List<Map<String, Object>> list = new ArrayList<>();
        EntityWrapper<TMajorRecommend> entityWrapper = new EntityWrapper<>();
        entityWrapper.eq("report_id", reportId)
                .eq("user_id", Integer.valueOf(userId))
                .eq("type", type)
                .eq("isdelete", 0);
        List<TMajorRecommend> majorRecommendList = majorRecommendMapper.selectList(entityWrapper);
        Map<Integer, List<TMajorRecommend>> majorRecommendMap = majorRecommendList.stream().collect(Collectors.groupingBy(TMajorRecommend::getCollegeLevel));
        Map<String, List<TMajorRecommend>> collegeCountMap = majorRecommendList.stream().collect(Collectors.groupingBy(TMajorRecommend::getCollegeName));
        Integer totalCount = collegeCountMap.size();
        AtomicReference<Integer> sort = new AtomicReference<>(0);//专业顺序
        List<BigDecimal> rateList = new ArrayList<>();
        majorRecommendMap.forEach((k, v) -> {
            sort.getAndSet(sort.get() + 1);
            Map<String, Object> levelMap = new HashMap<>();
            Map<String, List<TMajorRecommend>> collegeMap = v.stream().collect(Collectors.groupingBy(TMajorRecommend::getCollegeName));
            Integer count = collegeMap.size();
            levelMap.put("level", CollegeLevelNewEnum.getValueById(k));
            levelMap.put("count", count);
            BigDecimal countCA = BigDecimal.valueOf(count);
            BigDecimal totalcountCA = BigDecimal.valueOf(totalCount);
            BigDecimal rate = countCA.divide(totalcountCA, 2, BigDecimal.ROUND_HALF_UP);
            if (sort.get() == majorRecommendMap.size()) {
                BigDecimal check = rateList.stream().reduce(BigDecimal.ZERO, BigDecimal::add);
                rate = BigDecimal.ONE.subtract(check);
            }
            levelMap.put("rate", rate);
            rateList.add(rate);
            list.add(levelMap);
        });
        return list;
    }

    /**
     * map排序
     *
     * @param map
     * @param isDesc
     * @param <K>
     * @param <V>
     * @return
     */
    private <K extends Comparable<? super K>, V> Map<K, V> orderByKey(Map<K, V> map, boolean isDesc) {
        if (map == null || map.isEmpty()) {
            return null;
        }
        Map<K, V> result = Maps.newLinkedHashMap();
        if (isDesc) {
            map.entrySet().stream().sorted(Map.Entry.<K, V>comparingByKey().reversed())
                    .forEachOrdered(e -> result.put(e.getKey(), e.getValue()));
        } else {
            map.entrySet().stream().sorted(Map.Entry.<K, V>comparingByKey())
                    .forEachOrdered(e -> result.put(e.getKey(), e.getValue()));
        }
        return result;
    }

    /**
     * map排序
     * @param map
     * @param <K>
     * @param <V>
     * @return
     */
    public <K, V extends Comparable<? super V>> Map<K, V> orderByValue(Map<K, V> map) {
        Map<K, V> result = new LinkedHashMap<>();

        map.entrySet().stream()
                .sorted(Map.Entry.<K, V>comparingByValue()).forEachOrdered(e -> result.put(e.getKey(), e.getValue()));
        return result;
    }

    @Data
    private class College {
        private Integer collegeLevel;
        private String collegeLevelName;
        private String collegeName;
        /**
         * 学校录取最低分
         */
        private Double minAdmitScore;
        private Integer planNum;
        private List<TMajorCollege> collegeList;
        private String collegeCode;
    }

    @Data
    public static class CollegeVO {
        String collegeName;
        String collegeLevelName;
        String province;
        List<SubjectCategory> subjectCategoryList;
    }

    @Data
    public static class SubjectCategory {
        String subjectCategoryName;
        List<MajorCategory> majorCategoryList;
    }

    @Data
    public static class MajorCategory {
        String majorCategoryName;
        List<Major> majorList;
    }

    @Data
    public static class Major {
        String majorName;
        Double score;
        Integer planNum;
        Integer star;
    }

    private static Double dealScore(Double a) {
        Double b = Math.floor(a);
        Double c = a - b;
        if (c == 0) {
            return b;
        } else if (c <= 0.5) {
            return b + 0.5;
        } else {
            return b + 1;
        }
    }
}
