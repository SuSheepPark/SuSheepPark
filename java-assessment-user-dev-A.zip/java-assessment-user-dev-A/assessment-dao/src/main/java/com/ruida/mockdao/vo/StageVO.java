package com.ruida.mockdao.vo;

import lombok.Data;

/**
 * @description: 年级VO
 * @author: chenjy
 * @create: 2020-08-03 17:45
 */
@Data
public class StageVO {
    /**
     * 年级id
     */
    private Integer stageId;

    /**
     * 年级名称
     */
    private String stageName;
}
