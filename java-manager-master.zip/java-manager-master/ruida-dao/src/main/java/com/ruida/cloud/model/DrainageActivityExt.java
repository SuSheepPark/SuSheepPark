package com.ruida.cloud.model;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Map;

@Data
public class DrainageActivityExt extends DrainageActivity {
    private Integer drainageActivityId;

    private String drainageActivityName;

    /**关联课程ids*/
    private String activityCourseIds;

    /**分销商ids*/
    private String activityDistributorIds;

    private String superDistributorIds;

    private List<Map<String, Object>> secondaryDistributorIds;

    private Byte relateAllCourse;

    private Byte relateAllDistributor;

    /**
     * 引流活动和分销商关联关系
     */
    private List<Map<String,Object>> drainageActivityDistributorRelList;

    /**
     * 引流活动和课程关联关系
     */
    private List<Map<String,Object>> drainageActivityCourseRelList;
}