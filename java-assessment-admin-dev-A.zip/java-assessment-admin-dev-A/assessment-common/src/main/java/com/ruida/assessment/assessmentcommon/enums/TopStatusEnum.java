package com.ruida.assessment.assessmentcommon.enums;

/**
 * @description: 置顶状态枚举类
 * @author: wy
 * @date: 2020/7/20
 */
public enum TopStatusEnum {
    NOT_TOP(0,"不置顶"),
    TOP(1,"置顶"),
    ;

    private Integer K;
    private String V;

    TopStatusEnum(Integer k, String v) {
        K = k;
        V = v;
    }

    public Integer getK() {
        return K;
    }

    public void setK(Integer k) {
        K = k;
    }

    public String getV() {
        return V;
    }

    public void setV(String v) {
        V = v;
    }

    public static TopStatusEnum getValueById(Integer K){
        for(TopStatusEnum deleteStatusEnum : TopStatusEnum.values() ){
            if(deleteStatusEnum.getK().equals(K)){
                return  deleteStatusEnum;
            }
        }
        return null;
    }

}
