package com.ruida.assessment.assessmentquestionbank.dto;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.List;

/**
 * @description: 试题信息DTO
 * @author: kgz
 * @date: 2020/6/8
 */
@ApiModel(description = "试题信息")
public class QuestionInfoDTO {

    @ApiModelProperty(value = "操作id", name = "operationId", required = true)
    private int operationId;

    @ApiModelProperty(value = "子级试题集合", name = "children", required = false)
    private List<QuestionInfoDTO> children;

    @ApiModelProperty(value = "试题id", name = "id", required = false)
    private String id;

    @ApiModelProperty(value = "学段id", name = "periodId", required = false)
    private Integer periodId;

    @ApiModelProperty(value = "科目id", name = "subjectId", required = false)
    private Integer subjectId;

    @ApiModelProperty(value = "试题类型id", name = "questionTypeId", required = true)
    private Integer questionTypeId;

    @ApiModelProperty(value = "父级id", name = "parentId", required = true)
    private String parentId;

    @ApiModelProperty(value = "难度等级id", name = "difficultyId", required = true)
    private Integer difficultyId;

    @ApiModelProperty(value = "保密等级id", name = "securityLevelId", required = true)
    private Integer securityLevelId;

    @ApiModelProperty(value = "考核目标id", name = "assessmentTargetId", required = true)
    private Integer assessmentTargetId;

    @ApiModelProperty(value = "试题来源id", name = "questionSourceId", required = true)
    private Integer questionSourceId;

    @ApiModelProperty(value = "试题用途id", name = "questionPurposeId", required = true)
    private Integer questionPurposeId;

    @ApiModelProperty(value = "预计时长，分钟", name = "estimateDuration", required = true)
    private Integer estimateDuration;

    @ApiModelProperty(value = "试题内容", name = "questionTitle", required = true)
    private String questionTitle;

    @ApiModelProperty(value = "试题音频地址", name = "questionAudioUrl")
    private String questionAudioUrl;

    @ApiModelProperty(value = "试题音频名称", name = "questionAudioName")
    private String questionAudioName;

    @ApiModelProperty(value = "试题音频时长", name = "questionAudioDuration")
    private String questionAudioDuration;

    @ApiModelProperty(value = "试题音频来源", name = "questionAudioSource")
    private Integer questionAudioSource;

    @ApiModelProperty(value = "可播放次数", name = "playCount")
    private Integer playCount;

    @ApiModelProperty(value = "题目设置", name = "questionTitleSetting")
    private Integer questionTitleSetting;

    @ApiModelProperty(value = "题目序号（组合题使用）", name = "questionSort")
    private Integer questionSort;

    @ApiModelProperty(value = "批改类型（0—主观题；1—客观题）", name = "correctType")
    private Integer correctType;

    @ApiModelProperty(value = "试题选项", name = "stem")
    private String stem;

    @ApiModelProperty(value = "答案", name = "answer")
    private String answer;

    @ApiModelProperty(value = "是否支持拍照上传答案", name = "answerPhotographId")
    private Integer answerPhotographId;

    @ApiModelProperty(value = "试题分析", name = "analysis")
    private String analysis;

    @ApiModelProperty(value = "备注(已废弃)", name = "note")
    private String note;

    @ApiModelProperty(value = "备注", name = "remark")
    private String remark;

    @ApiModelProperty(value = "试题与知识点关联关系", name = "questionKnowledgeRelation")
    private List<QuestionKnowledgeRelationDTO> questionKnowledgeRelation;

    @ApiModelProperty(value = "试题与考察要求关联关系", name = "questionAssessmentRelation")
    private List<QuestionAssessmentRelationDTO> questionAssessmentRelation;

    public List<QuestionAssessmentRelationDTO> getQuestionAssessmentRelation() {
        return questionAssessmentRelation;
    }

    public void setQuestionAssessmentRelation(List<QuestionAssessmentRelationDTO> questionAssessmentRelation) {
        this.questionAssessmentRelation = questionAssessmentRelation;
    }

    @ApiModelProperty(value = "试题状态（0-草稿；1-提交（待审核）；2-已发布；3-取消发布）", name = "questionStatus")
    private Integer questionStatus;

    public int getOperationId() {
        return operationId;
    }

    public void setOperationId(int operationId) {
        this.operationId = operationId;
    }
    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public List<QuestionInfoDTO> getChildren() {
        return children;
    }

    public void setChildren(List<QuestionInfoDTO> children) {
        this.children = children;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getQuestionTypeId() {
        return questionTypeId;
    }

    public void setQuestionTypeId(Integer questionTypeId) {
        this.questionTypeId = questionTypeId;
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public Integer getDifficultyId() {
        return difficultyId;
    }

    public void setDifficultyId(Integer difficultyId) {
        this.difficultyId = difficultyId;
    }

    public Integer getSecurityLevelId() {
        return securityLevelId;
    }

    public void setSecurityLevelId(Integer securityLevelId) {
        this.securityLevelId = securityLevelId;
    }

    public Integer getAssessmentTargetId() {
        return assessmentTargetId;
    }

    public void setAssessmentTargetId(Integer assessmentTargetId) {
        this.assessmentTargetId = assessmentTargetId;
    }

    public Integer getQuestionSourceId() {
        return questionSourceId;
    }

    public void setQuestionSourceId(Integer questionSourceId) {
        this.questionSourceId = questionSourceId;
    }

    public Integer getQuestionPurposeId() {
        return questionPurposeId;
    }

    public void setQuestionPurposeId(Integer questionPurposeId) {
        this.questionPurposeId = questionPurposeId;
    }

    public Integer getEstimateDuration() {
        return estimateDuration;
    }

    public void setEstimateDuration(Integer estimateDuration) {
        this.estimateDuration = estimateDuration;
    }

    public String getQuestionTitle() {
        return questionTitle;
    }

    public void setQuestionTitle(String questionTitle) {
        this.questionTitle = questionTitle;
    }

    public Integer getQuestionSort() {
        return questionSort;
    }

    public void setQuestionSort(Integer questionSort) {
        this.questionSort = questionSort;
    }

    public Integer getCorrectType() {
        return correctType;
    }

    public void setCorrectType(Integer correctType) {
        this.correctType = correctType;
    }

    public String getStem() {
        return stem;
    }

    public void setStem(String stem) {
        this.stem = stem;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public Integer getAnswerPhotographId() {
        return answerPhotographId;
    }

    public void setAnswerPhotographId(Integer answerPhotographId) {
        this.answerPhotographId = answerPhotographId;
    }

    public String getAnalysis() {
        return analysis;
    }

    public void setAnalysis(String analysis) {
        this.analysis = analysis;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public Integer getQuestionStatus() {
        return questionStatus;
    }

    public void setQuestionStatus(Integer questionStatus) {
        this.questionStatus = questionStatus;
    }

    public List<QuestionKnowledgeRelationDTO> getQuestionKnowledgeRelation() {
        return questionKnowledgeRelation;
    }

    public void setQuestionKnowledgeRelation(List<QuestionKnowledgeRelationDTO> questionKnowledgeRelation) {
        this.questionKnowledgeRelation = questionKnowledgeRelation;
    }

    public Integer getQuestionTitleSetting() {
        return questionTitleSetting;
    }

    public void setQuestionTitleSetting(Integer questionTitleSetting) {
        this.questionTitleSetting = questionTitleSetting;
    }

    public Integer getPeriodId() {
        return periodId;
    }

    public void setPeriodId(Integer periodId) {
        this.periodId = periodId;
    }

    public Integer getSubjectId() {
        return subjectId;
    }

    public void setSubjectId(Integer subjectId) {
        this.subjectId = subjectId;
    }

    public String getQuestionAudioUrl() {
        return questionAudioUrl;
    }

    public void setQuestionAudioUrl(String questionAudioUrl) {
        this.questionAudioUrl = questionAudioUrl;
    }

    public Integer getPlayCount() {
        return playCount;
    }

    public void setPlayCount(Integer playCount) {
        this.playCount = playCount;
    }

    public Integer getQuestionAudioSource() {
        return questionAudioSource;
    }

    public void setQuestionAudioSource(Integer questionAudioSource) {
        this.questionAudioSource = questionAudioSource;
    }

    public String getQuestionAudioName() {
        return questionAudioName;
    }

    public void setQuestionAudioName(String questionAudioName) {
        this.questionAudioName = questionAudioName;
    }

    public String getQuestionAudioDuration() {
        return questionAudioDuration;
    }

    public void setQuestionAudioDuration(String questionAudioDuration) {
        this.questionAudioDuration = questionAudioDuration;
    }

    @Override
    public String toString() {
        return "QuestionInfoDTO{" +
                "operationId=" + operationId +
                ", children=" + children +
                ", id='" + id + '\'' +
                ", periodId=" + periodId +
                ", subjectId=" + subjectId +
                ", questionTypeId=" + questionTypeId +
                ", parentId='" + parentId + '\'' +
                ", difficultyId=" + difficultyId +
                ", securityLevelId=" + securityLevelId +
                ", assessmentTargetId=" + assessmentTargetId +
                ", questionSourceId=" + questionSourceId +
                ", questionPurposeId=" + questionPurposeId +
                ", estimateDuration=" + estimateDuration +
                ", questionTitle='" + questionTitle + '\'' +
                ", questionAudioUrl='" + questionAudioUrl + '\'' +
                ", questionAudioName='" + questionAudioName + '\'' +
                ", questionAudioDuration='" + questionAudioDuration + '\'' +
                ", questionAudioSource=" + questionAudioSource +
                ", playCount=" + playCount +
                ", questionTitleSetting=" + questionTitleSetting +
                ", questionSort=" + questionSort +
                ", correctType=" + correctType +
                ", stem='" + stem + '\'' +
                ", answer='" + answer + '\'' +
                ", answerPhotographId=" + answerPhotographId +
                ", analysis='" + analysis + '\'' +
                ", note='" + note + '\'' +
                ", questionKnowledgeRelation=" + questionKnowledgeRelation +
                ", questionStatus=" + questionStatus +
                '}';
    }
}
