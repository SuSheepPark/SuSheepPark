package com.ruida.assessment.assessmentquestionbank.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.assessment.assessmentquestionbank.model.TMsgTemplate;
import org.apache.ibatis.annotations.Mapper;

/**
 * @description:
 * @author: kgz
 * @date: 2020/7/21
 */
@Mapper
public interface MsgTemplateMapper extends BaseMapper<TMsgTemplate> {

}
