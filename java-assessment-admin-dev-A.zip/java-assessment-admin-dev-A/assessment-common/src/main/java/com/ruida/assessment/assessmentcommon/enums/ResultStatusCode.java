package com.ruida.assessment.assessmentcommon.enums;

public enum ResultStatusCode {
    OK(0, "操作成功"),
    DEAL_FAIL(1, "操作失败"),
    SIGN_ERROR(120, "签名错误"),
    TIME_OUT(130, "访问超时"),
    BAD_REQUEST(400, "参数解析失败"),
    INVALID_TOKEN(401, "无效的授权码"),
    INVALID_CLIENTID(402, "无效的密钥"),
    METHOD_NOT_ALLOWED(405, "不支持当前请求方法"),
    SYSTEM_ERR(500, "服务器运行异常"),
    NOT_EXIST_USER_OR_ERROR_PWD(10000, "该用户不存在或密码错误"),
    LOGINED_IN(10001, "该用户已登录"),
    NOT_EXIST_BUSINESS(10002, "该商家不存在"),
    SHIRO_ERROR(10003, "登录异常"),
    UNAUTHO_ERROR(10004, "您没有该权限"),
    ERROR_PWD(10005, "原密码错误"),
    ERROR_REGEX(10006, "新密码格式有误"),
    BIND_PHONE(10010, "请绑定手机号"),
    UPLOAD_ERROR(20000, "上传文件异常"),
    INVALID_CAPTCHA(30005, "无效的验证码"),
    USER_FROZEN(40000, "该用户已被冻结"),
    PERFECT_GOOD_INFORMATION(50000, "请完善课程信息后再发布"),
    TEACHER_INFO_FAIL(50001, "获取教师信息失败"),
    UPLOAD_EMPTY_FILE(50003, "上传文件为空"),
    UPLOAD_FAIL(50004, "上传失败"),
    UPLOAD_OVERSIZE(50005, "上传文件过大"),
    UPLOAD_SUCCESS(50006, "上传成功"),
    DELETE_LESSON_PUBLISH(60001, "课程已上线，不可删除"),
    FORBIDDEN_SUCCESS(700001,"禁用成功"),
    FORBIDDEN_FAIL(70002,"禁用失败"),
    USING_SUCCESS(700003,"启用成功"),
    USING_FAIL(70004,"启用失败"),
    RELEASE_SUCCESS(70005, "上架成功"),
    RELEASE_FAIL(70006, "上架失败"),
    PRE_SUCCESS(70007, "发布成功"),
    PRE_FAIL(70008, "发布失败"),
    RELATION_FAIL(70009, "有关联关系无法删除"),
    MATERIAL_NOT_EXIT(70010, "教材不存在"),
    MATERIAL_EXIT(70011, "该教材已存在,请勿重复添加！"),
    TOP_FILE(70012, "置顶失败,最多置顶5个"),
    HAVE_NO_PUBLISH(70013, "商品中有未发布的试卷，上架失败"),
    SAME_NAME(70014, "同名"),
    HAVE_CHECK_CLASS(70015, "禁用失败，该学校尚有待审核的班级，请先处理待审核班级！"),
    SCHOOL_HAVE_STUDENT(70016, "该学校下存在考生，请先删除考生！"),
    IS_BUY(70017, "该商品已被购买,无法下架"),
    SAME_TELEPHONE(70018, "该手机号已被其他学员使用，请核对正确后再输入！"),
    EXPORT_NULL(70019, "请重新选择查询数据条件！当前无数据"),
    HAVE_UNPAID(70020, "该商品存在待支付的订单，无法下架，请稍后再试！"),
    REPORT_NOT_BUY(70021, "该商品的报告不需要单独购买，无需赠送！"),
    PRODUCT_NO_REPORT(70022, "该商品暂无报告，无法赠送！"),
    CURRENT_EXL_REPORT(70023, "请选择正确模板导入！"),
    IMPORT_EXL_FAIL(70024, "批量导入失败！"),
    PRESENT_PRODUCT_FAIL(70025, "赠送失败，请稍后重试！"),
    REPET_PRESENT_FAIL(70026, "请勿重复赠送!"),
    PRESENT_PRODUCT_ING(70027, "%s人赠送处理中，稍后将自动生效"),
    PRESENT_PRODUCT_SUCCESS(70028, "%s人赠送成功，%s人赠送失败！"),
    RESET_PASSWORD(70029, "重置密码成功，密码重置为123456！"),
    IMPORT_SUCCESS(70030, "批量导入成功！学员初始密码为123456！"),
    INSERT_SUCCESS(70031, "新增成功！学员初始密码为123456！"),
    CLASS_HAVE_STUDENT(70032, "该班级下存在考生，请先删除考生！"),
    ;


    private int code;
    private String msg;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    private ResultStatusCode(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }
}
