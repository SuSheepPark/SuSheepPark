/**   
 * Copyright © 2019 公司名. All rights reserved.
 * 
 * @Title: ArticleServiceImplTest.java 
 * @Prject: zhaowei-cms
 * @Package: com.zhaowei.cms.service.impl 
 * @Description: TODO
 * @author: zw   
 * @date: 2019年9月11日 上午10:40:27 
 * @version: V1.0   
 */
package com.zhaowei.cms.service.impl;

import static org.junit.Assert.*;

import java.io.File;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.zhaowei.cms.domain.Article;
import com.zhaowei.cms.domain.Category;
import com.zhaowei.cms.service.ArticleService;
import com.zhaowei.cms.service.CategoryService;
import com.zhaowei.common.utils.DateUtil;
import com.zhaowei.common.utils.RandomUtil;
import com.zhaowei.common.utils.StreamUtil;

/** 
 * @ClassName: ArticleServiceImplTest 
 * @Description: TODO
 * @author: zw
 * @date: 2019年9月11日 上午10:40:27  
 */
public class ArticleServiceImplTest extends JunitParent{

	@Resource
	private CategoryService categoryServicce;
	
	@Resource
	private ArticleService articleService;
	
	
	
	@Test
	public void testSelects() {
	}
	
	//读取文本文件，插入文章数据 
	@Test
	public void testInsertSelective() {
		//读取一个目录下的多个文件
		File file = new File("F:/yuekao");
		//获取目录下的所有文件
		File[] files = file.listFiles();
		//遍历文件
		for (File file2 : files) {
			//读取文件内容
			 String content = StreamUtil.readTextFile(file2);
			 System.out.println(content+"asdasdaddsssssssssssssssssssssssssssssss");
			 Article article = new Article();
			String name = file2.getName();//文件名在这时还包含后缀
			
			//去掉文件名的后缀
			
			// String title = name.substring(0, file2.getName().lastIndexOf("."));
			 
			 article.setTitle(name);//1.文章标题
			 article.setContent(content);
			 
			 //String summary = content.substring(0, 140); //在正文中截取140个字作为摘要
			// article.setSummary(summary);//摘要
			 
			//点击量 和 热门 ，频道字段要使用随机值
			 article.setHits(RandomUtil.random(0, 100000));//点击率
			 article.setHot(RandomUtil.random(0, 1));//是否热门
			 
			 int channelId = RandomUtil.random(1, 9);
			 article.setChannelId(channelId);
			 //根据栏目id查询分类
			// List<Category> list = categoryServicce.selectsByChannelId(channelId);
			 //从集合中随机获取一个
			// Category category = list.get(RandomUtil.random(0, list.size()-1));
			// article.setCategoryId(category.getId());//分类
			 //文章发布日期
			 Calendar c = Calendar.getInstance();
			 c.set(2019, 0, 1, 0, 0, 0);//初始化日历类
			 article.setCreated(DateUtil.randomDate(c.getTime(), new Date()));
			
			 
			 
			 //随机发布人发布文章
			 article.setUserId(137);
			
			 
			 article.setStatus(1);//初始化状态 1 是已经审核
			 article.setDeleted(0);//未删除
			 System.out.println("-----------------------------------------------------------------------------------");
			 articleService.insertSelective(article);//从文件添加文章到数据库
		}
	}

	@Test
	public void testSelectByPrimaryKey() {
	}

	@Test
	public void testUpdateByPrimaryKeyWithBLOBs() {
	}

}
