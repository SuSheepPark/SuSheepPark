package com.ruida.cloud.dao;

import com.ruida.cloud.model.PromotionActivityDistributorRel;
import com.ruida.cloud.model.PromotionActivityDistributorRelExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface PromotionActivityDistributorRelMapper {
    long countByExample(PromotionActivityDistributorRelExample example);

    int deleteByExample(PromotionActivityDistributorRelExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(PromotionActivityDistributorRel record);

    int insertSelective(PromotionActivityDistributorRel record);

    List<PromotionActivityDistributorRel> selectByExample(PromotionActivityDistributorRelExample example);

    PromotionActivityDistributorRel selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") PromotionActivityDistributorRel record, @Param("example") PromotionActivityDistributorRelExample example);

    int updateByExample(@Param("record") PromotionActivityDistributorRel record, @Param("example") PromotionActivityDistributorRelExample example);

    int updateByPrimaryKeySelective(PromotionActivityDistributorRel record);

    int updateByPrimaryKey(PromotionActivityDistributorRel record);

    /**
     * 批量插入数据
     */
    public int insertBatch(List<PromotionActivityDistributorRel> list);

    /**
     * 查询推广活动分销商信息
     * @param id
     * @return
     */
    List<Map<String,Object>> selectDistributorByCondition(@Param("id") int id);
}