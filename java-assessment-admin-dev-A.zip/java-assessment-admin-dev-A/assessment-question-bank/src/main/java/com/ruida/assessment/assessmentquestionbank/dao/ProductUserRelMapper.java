package com.ruida.assessment.assessmentquestionbank.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.assessment.assessmentquestionbank.model.TProductUserRel;

/**
 * @author wy
 * @description 商品-学员关联Mapper
 * @date 2020/8/5
 */
@Mapper
public interface ProductUserRelMapper extends BaseMapper<TProductUserRel> {

	void insertBatchBySQL(List<TProductUserRel> rels);
}
