package com.ruida.assessment.assessmentcommon.result;

/**
 * @author admin
 * @description: ${TODO}
 * @Date 2019/6/12
 * @verion 1.0
 */
public class BoolAlertResult {
    private Integer code;//业务状态码
    private String msgPrefix;//开头提示语
    private Boolean issuccess;//是否成功
    private String msg;//完成提示语
    public BoolAlertResult(){

    }

    public Integer getCode() {
        if(this.issuccess){
            this.code = 0;
        }else {
            this.code = 500;
        }
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getMsgPrefix() {
        return msgPrefix;
    }

    public void setMsgPrefix(String msgPrefix) {
        this.msgPrefix = msgPrefix;
    }

    public Boolean getIssuccess() {
        return issuccess;
    }

    public void setIssuccess(Boolean issuccess) {
        this.issuccess = issuccess;
    }

    public String getMsg() {
        if (this.issuccess) {
            this.msg = this.msgPrefix + "成功";
        } else {
            this.msg = this.msgPrefix + "失败";
        }
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}
