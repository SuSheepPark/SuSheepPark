/**   
 * Copyright © 2019 公司名. All rights reserved.
 * 
 * @Title: UserService.java 
 * @Prject: zhaowei-cms
 * @Package: com.zhaowei.cms.service 
 * @Description: TODO
 * @author: zw   
 * @date: 2019年9月10日 下午8:45:30 
 * @version: V1.0   
 */
package com.zhaowei.cms.service;

import java.util.List;

import com.github.pagehelper.PageInfo;
import com.zhaowei.cms.domain.User;
import com.zhaowei.cms.vo.UserVO;

/** 
 * @ClassName: UserService 
 * @Description: TODO
 * @author: zw
 * @date: 2019年9月10日 下午8:45:30  
 */
public interface UserService {
	/**
	 * @Title: selects 
	 * @Description: 用户的列表查询
	 * @param name
	 * @return
	 * @return: List<User>
	 */
	PageInfo<User> selects(String name,Integer page,Integer pageSize);
	/**
	 * 
	 * @Title: insertSelective 
	 * @Description: 注册用户
	 * @param record
	 * @return
	 * @return: int
	 */
    int insertSelective(User record);
/**
 * 
 * 
 * @Title: selectByPrimaryKey 
 * @Description: 单查用户
 * @param id
 * @return
 * @return: User
 */
    User selectByPrimaryKey(Integer id);
/**
 * 
 * @Title: updateByPrimaryKeySelective 
 * @Description: 修改用户信息
 * @param record
 * @return
 * @return: int
 */
    
    int updateByPrimaryKeySelective(User record);
/** 
 * @Title: insertSelective 
 * @Description: TODO
 * @param userVO
 * @return
 * @return: int
 */
int insertSelective(UserVO userVO);
/** 
 * @Title: login 
 * @Description:登陆
 * @param user
 * @return: void
 */
User login(User user);
}
