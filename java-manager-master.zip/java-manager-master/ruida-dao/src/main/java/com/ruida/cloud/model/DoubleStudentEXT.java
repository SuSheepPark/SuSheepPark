package com.ruida.cloud.model;

import com.ruida.common.util.excel.ExportEntityMap;
import lombok.Data;


@Data
public class DoubleStudentEXT {

    /**
     * 学生ID
     */
    @ExportEntityMap(CnName="id",EnName="studentId")
    private Integer studentId;

    /**
     * 学生姓名
     */
    @ExportEntityMap(CnName="姓名",EnName="studentName")
    private String studentName;

    /**
     * 学号
     */
    @ExportEntityMap(CnName="学号",EnName="studentNo")
    private String studentNo;

    /**
     * 联系方式
     */
    @ExportEntityMap(CnName="联系方式",EnName="telephone")
    private String telephone;

    /**
     * 班级总数
     */
    private Integer classSum;

    /**
     * 学生性别（0：未知；1：男；2：女）
     */
    private byte sex;

    /**
     * 学生来源
     */
    @ExportEntityMap(CnName="来源",EnName="source")
    private String source;

    /**
     * 性别
     */
    @ExportEntityMap(CnName="性别",EnName="natureSex")
    private String natureSex;

    /**
     * 学生年级关联id
     */
    private Integer id;

    /**
     * 创建时间
     */
    @ExportEntityMap(CnName="创建/同步时间",EnName="createTime")
    private String createTime;

    /**
     * 班级id
     */
    private Integer classId;

}
