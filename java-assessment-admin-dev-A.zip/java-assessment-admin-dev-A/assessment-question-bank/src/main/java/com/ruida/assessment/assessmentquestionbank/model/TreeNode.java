package com.ruida.assessment.assessmentquestionbank.model;

import lombok.Data;

/**
 * @author admin
 * @description: 菜单树
 * @Date 2019/5/30
 * @verion 1.0
 */
@Data
public class TreeNode {
    private Long menuId;         //节点id

    private Long pId;        //父节点id

    private String menuName;     //节点名称

    private Boolean isOpen;    //是否打开节点


    private Boolean checked; //是否被选中
    /**
     * 菜单URL
     */
    private String url;

    /**
     * 菜单授权（多个用逗号分隔，如：user:list,user:create）
     */
    private String menuPerms;

    /**
     * 菜单类型（0—目录；1—菜单；2—按钮）
     */
    private Byte menuType;

    /**
     * 菜单图标
     */
    private String icon;

    /**
     * 排序
     */
    private Integer orderNum;
    /**
     * 备注
     */
    private String remark;

    private Byte  status;

    private String menuCode;
    public static TreeNode createParent() {
        TreeNode treeNode = new TreeNode();
        treeNode.setChecked(true);
        treeNode.setMenuId(0L);
        treeNode.setMenuName("顶级");
        treeNode.setIsOpen(true);
        treeNode.setMenuId(0L);
        return treeNode;
    }
}
