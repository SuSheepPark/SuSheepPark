package com.ruida.cloud.model;

import lombok.Data;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;

@Data
public class DistributorExt extends Distributor {

}