package com.ruida.mockservice.service;

import com.baomidou.mybatisplus.service.IService;
import com.ruida.mockdao.model.TMaterialVersion;


public interface MaterialVersionService extends IService<TMaterialVersion> {

}
