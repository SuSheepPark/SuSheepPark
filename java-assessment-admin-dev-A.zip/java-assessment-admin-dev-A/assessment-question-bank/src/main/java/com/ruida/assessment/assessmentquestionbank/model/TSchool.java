package com.ruida.assessment.assessmentquestionbank.model;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @author wy
 * @description 学校数据库实体类
 * @date 2020/6/12
 */
@Data
@ApiModel(description = "学校数据库实体")
@TableName("t_school")
public class TSchool extends BaseColumn implements Serializable {

    private static final long serialVersionUID = 3108742639304950290L;

    /*学校id*/
    @TableId
    private Integer schoolId;

    /*学校名称*/
    private String schoolName;

    /*学校代码*/
    private String schoolCode;

    /*学校logo图片路径*/
    private String logoPath;

    /*学校类型/学段ID(多个以逗号拼接)*/
    private String periodId;

    /*省份*/
    private Integer province;

    /**
     * 城市ID
     */
    private Integer city;
    /**
     * 地区ID
     */
    private Integer district;

    private String email;
    /**
     * 学校详细地址
     */
    private String address;
    /**
     * 学校简介
     */
    private String summary;

    /**
     * 学校来源
     */
    private String source;

    /**
     * 负责人
     */
    private String personInCharge;

    /*负责人职位*/
    private String personInChargePosition;
    /**
     * 联系方式
     */
    private String telephone;
    /**
     * 状态（0—禁用；1—启用）
     */
    private Integer status;

}
