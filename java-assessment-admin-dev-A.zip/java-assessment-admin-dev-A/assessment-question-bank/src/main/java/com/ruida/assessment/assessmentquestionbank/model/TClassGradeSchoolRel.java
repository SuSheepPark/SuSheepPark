package com.ruida.assessment.assessmentquestionbank.model;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.models.auth.In;
import lombok.Data;

import java.io.Serializable;

/**
 * @author wy
 * @description 学校-班级关联数据库实体类
 * @date 2020/7/27
 */
@Data
@ApiModel(description = "班级-年级-学校数据库实体")
@TableName("t_class_grade_school_rel")
public class TClassGradeSchoolRel implements Serializable {

    private static final long serialVersionUID = -1333977032634756009L;

    private Integer id;

    private Integer classId;

    private Integer gradeId;

    private Integer schoolId;

    public TClassGradeSchoolRel(Integer classId, Integer gradeId, Integer schoolId) {
        this.classId = classId;
        this.gradeId = gradeId;
        this.schoolId = schoolId;
    }

    public TClassGradeSchoolRel() {
    }
}
