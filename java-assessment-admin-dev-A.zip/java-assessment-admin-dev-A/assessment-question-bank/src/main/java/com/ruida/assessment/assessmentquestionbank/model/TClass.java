package com.ruida.assessment.assessmentquestionbank.model;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.models.auth.In;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @author wy
 * @description 班级数据库实体类
 * @date 2020/6/12
 */
@Data
@ApiModel(description = "班级数据库实体")
@TableName("t_class")
public class TClass extends BaseColumn implements Serializable {

    private static final long serialVersionUID = 3726897450554263864L;

    /**
     * 班级主键ID
     */
    @TableId
    private Integer classId;
    /**
     * 班级名称
     */
    private String className;
    /**
     * 班级代码
     */
    private String classCode;
    /**
     * 状态（0—禁用；1—启用; 2—待审核）
     */
    private Integer status;

    public TClass() {
    }

    public TClass(String className, String classCode, Integer status, Integer createBy){
        this.className = className;
        this.classCode = classCode;
        this.status = status;
        this.setCreateBy(createBy);
        this.setCreateTime(new Date());
    }
}
