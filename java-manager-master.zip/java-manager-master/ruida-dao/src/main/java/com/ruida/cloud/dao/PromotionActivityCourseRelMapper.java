package com.ruida.cloud.dao;

import com.ruida.cloud.model.PromotionActivityCourseRel;
import com.ruida.cloud.model.PromotionActivityCourseRelExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface PromotionActivityCourseRelMapper {
    long countByExample(PromotionActivityCourseRelExample example);

    int deleteByExample(PromotionActivityCourseRelExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(PromotionActivityCourseRel record);

    int insertSelective(PromotionActivityCourseRel record);

    List<PromotionActivityCourseRel> selectByExample(PromotionActivityCourseRelExample example);

    PromotionActivityCourseRel selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") PromotionActivityCourseRel record, @Param("example") PromotionActivityCourseRelExample example);

    int updateByExample(@Param("record") PromotionActivityCourseRel record, @Param("example") PromotionActivityCourseRelExample example);

    int updateByPrimaryKeySelective(PromotionActivityCourseRel record);

    int updateByPrimaryKey(PromotionActivityCourseRel record);

    /**
     * 批量插入关联信息
     */
    public int insertBatch(List<PromotionActivityCourseRel> list);

    /**
     * 查询推广活动关联课程信息
     * @param id 活动id
     * @return
     */
    List<Map<String,Object>> selectCourseRel(int id);

    PromotionActivityCourseRel selectCourseRelByIdAndCourseId(@Param("id") String id,@Param("courseId") String courseId);

}