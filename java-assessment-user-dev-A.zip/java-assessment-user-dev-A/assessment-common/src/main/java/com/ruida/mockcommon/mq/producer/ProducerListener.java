package com.ruida.mockcommon.mq.producer;



import com.aliyun.openservices.ons.api.ONSFactory;
import com.aliyun.openservices.ons.api.Producer;
import com.aliyun.openservices.ons.api.PropertyKeyConst;
import com.google.common.base.Strings;
import com.ruida.mockcommon.constant.SystemConstant;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

/**
 * Created by jinhu on 2020/8/3.
 * 生产者初始化 区分profile
 */
@Component
@Slf4j
public class ProducerListener implements ApplicationListener<ApplicationReadyEvent> {

    @Resource
    RMQConfig rmqConfig;

    private static Map<String, Producer> producerMap = new HashMap<>();

    public void onApplicationEvent(ApplicationReadyEvent applicationReadyEvent) {
        if (Strings.isNullOrEmpty(SystemConstant.producers)) {
            return;
        }

        String[] producerArray = SystemConstant.producers.split(",");
        if (producerArray == null) {
            throw new IllegalArgumentException("can not found valid mq.producers in properties file");
        }

        Properties properties = rmqConfig.getProperties();


        // 初始化所有的producer
        for (String producerId : producerArray) {

            //设置group
            String realProducerId = MQUtil.getRealId(producerId);
            properties.setProperty(PropertyKeyConst.GROUP_ID,realProducerId);

            Producer producer = ONSFactory.createProducer(properties);
            producer.start();

            producerMap.put(realProducerId, producer);
            log.info("init producer producerId:{}", realProducerId);
        }
    }


    /**
     * 去掉static,防止未加载完成时候就去调用
     * @param producerId
     * @return
     */
    public Producer getProducer(String producerId) {
        return producerMap.get(producerId);
    }


}

