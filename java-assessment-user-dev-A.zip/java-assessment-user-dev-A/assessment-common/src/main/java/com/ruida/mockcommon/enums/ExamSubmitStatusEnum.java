package com.ruida.mockcommon.enums;


/**
 * Created by xumingqi on 2021/7/21 10:59
 */
public enum ExamSubmitStatusEnum {
    SUBMIT(0, "已交卷"),
    UN_SUBMIT(1, "未交卷");

    private int k;
    private String v;

    ExamSubmitStatusEnum(int k, String v) {
        this.k = k;
        this.v = v;
    }


    public int getK() {
        return k;
    }

    public void setK(int k) {
        this.k = k;
    }

    public String getV() {
        return v;
    }

    public void setV(String v) {
        this.v = v;
    }
}
