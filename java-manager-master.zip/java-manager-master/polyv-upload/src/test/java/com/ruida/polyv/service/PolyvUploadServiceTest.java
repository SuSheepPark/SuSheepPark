package com.ruida.polyv.service;

import com.ruida.common.enums.AppErrorEnum;
import com.ruida.common.exception.CoreException;
import com.ruida.polyv.sdk.PolyvSDKClient;
import com.ruida.polyv.sdk.Video;
import lombok.Data;
import org.junit.Test;

public class PolyvUploadServiceTest {

    @Test
    public void polyvUpload() {
        String filePath = "D:\\Tool\\apache-tomcat-8.5.28\\temp\\不要让任何人打乱你的节奏.flv";
        long start = System.currentTimeMillis();
        Runnable runnable = new UploadCallable(filePath, "测试上传速度");
        runnable.run();

        while(true){
            PolyvSDKClient client = PolyvSDKClient.getInstance();
            System.out.println(client);

            int percent = client.getPercent();

            System.out.println("percent:=========="+percent+"%");
            //result.put("vid", video.getVid());
            //result.put("image", video.getFirstImage());
            //result.put("video", video);
            //result.put("percent", percent);

            if(percent==100){
                Video video = ((UploadCallable) runnable).video;
                long end = System.currentTimeMillis();
                System.out.println("上传时间："+(end-start));
                break;
            }else {
                try {
                    Thread.sleep(100);
                    break;
                } catch (Exception e) {
                    throw new CoreException(AppErrorEnum.E_70001.getErrorCode(),AppErrorEnum.E_70001.getErrorMessage()+e.getMessage());
                }
            }
        }
    }

    @Data
    class UploadCallable implements Runnable {
        Video video;
        String filePath;
        String title;

        public UploadCallable(String filePath, String title) {
            this.filePath = filePath;
            this.title = title;
        }

        @Override
        public void run() {
            Video v;
            try {
                PolyvSDKClient client = PolyvSDKClient.getInstance();
                v = client.upload( filePath, title, "tag", "desc", 0);

                video = v;
            } catch (Exception e) {
                throw new CoreException(AppErrorEnum.E_70001.getErrorCode(),AppErrorEnum.E_70001.getErrorMessage()+e.getMessage());
            }
        }
    }
}