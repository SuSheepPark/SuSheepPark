package com.ruida.assessment.assessmentcommon.mq;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.aliyun.openservices.ons.api.Message;
import com.aliyun.openservices.ons.api.ONSFactory;
import com.aliyun.openservices.ons.api.Producer;
import com.aliyun.openservices.ons.api.SendResult;

public class MQSender {
	private static Logger logger=LoggerFactory.getLogger(MQSender.class);
	
	public static void send(Message msg,String groupId) {
		Producer producer = null;
		try {

			producer = ONSFactory.createProducer(RMQConfig.getProperties(groupId));
			producer.start();
			for (int i = 0; i < 4; i++) {
				try {
					// 发送消息到一个Broker
					SendResult sendResult = producer.send(msg);
					// 通过sendResult返回消息是否成功送达
					logger.info("发送消息成功"+msg.toString()+"---"+groupId);
					break;
				} catch (Exception e) {
					e.printStackTrace();
					try {
						Thread.sleep(6 ^ i * 600000);
					} catch (InterruptedException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			}
		} finally {
			if (producer != null) {
				producer.shutdown();
			}
		}
	}
}
