package com.ruida.common.model;

import java.util.HashMap;
import java.util.Map;

public class Page {

    public static final int PAGE_SIZE_DEFAULT = 10;
    public static final String PAGE_ORDER_DEFAULT_DIRECTION = "asc";

    private String order;

    private long totalCount = -1;
    // pageNo 从 1 开始
    private int pageNo = 1;
    private int pageSize = PAGE_SIZE_DEFAULT;

    private int prePage;
    private int nextPage;

    public Page(){
    }

    public Page(int pageNo, int pageSize){
        this.pageNo = pageNo < 1 ? 1 : pageNo;
        this.pageSize = pageSize <= 0 ? PAGE_SIZE_DEFAULT : pageSize;
    }

    public int getPageNo() {
        return pageNo;
    }

    public void setPageNo(int pageNo) {
        this.pageNo = pageNo;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public String getOrder() {
        return order;
    }


    public void setOrder(String order) {
        this.order = order;
    }

    public long getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(long totalCount) {
        this.totalCount = totalCount < 0 ? -1 : totalCount;
    }

    // 通过一些参数计算出来的东西
    public long getTotalPage() throws Exception {
        if(totalCount == -1){
            throw new Exception("请先查询总记录数！");
        }
        if(totalCount <= 0){
            return 0;
        }
        return (totalCount - 1)/pageSize + 1;
    }

    public long getNextPage() throws Exception{
        long totalPage = getTotalPage();
        return (totalPage - pageNo > 1) ? pageNo + 1 : totalPage;
    }

    public long getPrePage() throws Exception{
        long totalPage = getTotalPage();
        return pageNo > 1 ? (pageNo -1 ) : 1;
    }

    public long getLimit() {
        return pageSize;
    }

    public long getOffset() {
        return (pageNo - 1) * pageSize;
    }

    public long getEnd() {
        long end = getOffset() + getLimit();
        if(end > totalCount){
            return totalCount;
        }else{
            return end;
        }
    }

    public Map<String,Object> toMap(){
        long start = getOffset();
        long end = getOffset() + getLimit();

        Map<String,Object> map = new HashMap<String,Object>();
        map.put("pageSize", getLimit());
        map.put("order", order);
        map.put("start", start);
        map.put("end", end);

        return map;
    }

}
