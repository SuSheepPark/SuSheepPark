package com.ruida.common.enums;

import java.util.Objects;

/**
 * @author szl
 * @description: 营销活动进行状态
 * @Date 2020/04/16
 * @verion 1.0
 */
public enum PromotionStatusEnum {
    WAIT(0,"未开始"),
    STARTED(1,"进行中"),
    END(2,"已结束"),
    NO_STARTED(3,"非进行中"),
    NO_END(4,"非未开始"),
    NO_WAIT(5,"非已结束");
    private Integer type;
    private String name;
    PromotionStatusEnum(Integer type, String name){
        this.type = type;
        this.name = name;
    }

    /**
     * 根据type获取name
     * @param type
     * @return
     */
    String getNameForK(Integer type){
        PromotionStatusEnum[] arys = PromotionStatusEnum.values();
        for (PromotionStatusEnum assistant : arys) {
            if (Objects.equals(assistant.type,type)){
                return assistant.name;
            }
        }
        return "";
    }
    /**
     * 根据type获取name
     * @param name
     * @return
     */
   public static Integer getKForName(String name){
        PromotionStatusEnum[] arys = PromotionStatusEnum.values();
        for (PromotionStatusEnum assistant : arys) {
            if (Objects.equals(assistant.name,name)){
                return assistant.type;
            }
        }
        return null;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }}
