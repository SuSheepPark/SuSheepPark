package com.ruida.assessment.assessmentquestionbank.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.assessment.assessmentquestionbank.model.TClass;
import com.ruida.assessment.assessmentquestionbank.model.TGrade;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author wy
 * @description 年级管理Mapper
 * @date 2020/7/29
 */
@Mapper
public interface GradeMapper extends BaseMapper<TGrade> {

}
