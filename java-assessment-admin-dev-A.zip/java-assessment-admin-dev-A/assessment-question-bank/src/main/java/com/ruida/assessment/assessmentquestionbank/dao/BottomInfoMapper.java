package com.ruida.assessment.assessmentquestionbank.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.assessment.assessmentquestionbank.dto.SchoolRequest;
import com.ruida.assessment.assessmentquestionbank.model.TBottomInfo;
import com.ruida.assessment.assessmentquestionbank.model.TSchool;
import com.ruida.assessment.assessmentquestionbank.vo.SchoolVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author wy
 * @description 网站信息管理Mapper
 * @date 2020/8/14
 */
@Mapper
public interface BottomInfoMapper extends BaseMapper<TBottomInfo> {



}
