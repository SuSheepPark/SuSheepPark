package com.ruida.assessment.assessmentcommon.enums;

/**
 * Created by xumingqi on 2021/5/25 16:47
 */
public enum CollegeLevelNewEnum {
    FIRST(1, "清华北大"),
    SECOND(2, "华东五校"),
    THIRD(3, "一流大学（985）"),
    FOURTH(4, "一流学科（211）"),
    FIFTH(5, "一般本科院校"),
    SIXTH(6, "独立院校（三本）"),
    SEVENTH(7, "高等职业院校");


    private Integer K;
    private String V;

    CollegeLevelNewEnum(Integer k, String v) {
        K = k;
        V = v;
    }

    public Integer getK() {
        return K;
    }

    public void setK(Integer k) {
        K = k;
    }

    public String getV() {
        return V;
    }

    public void setV(String v) {
        V = v;
    }


    public static String getValueById(Integer K) {
        for (CollegeLevelNewEnum collegeLevelEnum : CollegeLevelNewEnum.values()) {
            if (collegeLevelEnum.getK().equals(K)) {
                return collegeLevelEnum.getV();
            }
        }
        return null;
    }

    public static Integer getKeyByValue(String value) {
        for (CollegeLevelNewEnum newEnum : CollegeLevelNewEnum.values()) {
            if (newEnum.getV().equals(value)) {
                return newEnum.getK();
            }
        }
        return null;
    }
}