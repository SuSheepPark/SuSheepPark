package com.ruida.assessment.assessmentquestionbank.service;

import com.baomidou.mybatisplus.service.IService;
import com.ruida.assessment.assessmentquestionbank.model.TPresellTestPaper;
import com.ruida.assessment.assessmentquestionbank.model.TTestPaperProductRel;

import java.util.List;

/**
 * @author wy
 * @description  预售试卷-商品关联管理服务层接口
 * @date 2020/6/24
 */
public interface IPresellTestPaperService extends IService<TPresellTestPaper> {

}
