package com.ruida.cloud.weidu.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.ruida.cloud.dao.WeiduCourseLessonRelMapper;
import com.ruida.cloud.model.WeiduCourseLessonRel;
import com.ruida.cloud.weidu.config.WeiduConfig;
import com.ruida.cloud.weidu.exception.VdyooException;
import com.ruida.cloud.weidu.service.BaseVdyooService;
import com.ruida.cloud.weidu.vo.VdyooEntity;
import com.ruida.common.context.BaseContextHandle;
import com.ruida.common.util.ValidateMT;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * 课程班关联信息：         关联  课程+班级
 * <p>
 * 睿达管理后台-->创建课程时，添加的权限班级相当于 威渡的教室（直播间）的概念   1:n
 *
 * @author taosh
 * @create 2019-04-23 15:09
 */
@Service
@Slf4j
public class VdyooCourseClassService extends BaseVdyooService {
    @Resource
    private WeiduCourseLessonRelMapper weiduCourseLessonRelMapper;

    /**
     * 创建课程班
     * , propagation= Propagation.NESTED
     */
    @Transactional(rollbackFor = Exception.class, propagation = Propagation.NESTED)
    public String addCourseClass(Map<String, Object> params) {

        VdyooEntity vdyooEntity = this.vdyooFactory.post(params, WeiduConfig.addCourseClass);
        boolean flag = false;

        if (vdyooEntity.getSuccess()) {
            String id = null;
            try {
                WeiduCourseLessonRel courseLessonRel = new WeiduCourseLessonRel();
                courseLessonRel.setCourseLessonId(Integer.parseInt(params.get("pid").toString()));
                JSONObject object = (JSONObject) JSON.toJSON(vdyooEntity.getPayload());
                courseLessonRel.setWeiduCourseLessonId(object.getString("id"));
                id = object.getString("id");

                courseLessonRel.setCreateBy(BaseContextHandle.getUserId());
                courseLessonRel.setCreateTime(new Date());
                courseLessonRel.setIsdelete((byte) 0);
                courseLessonRel.setUpdateBy(BaseContextHandle.getUserId());
                courseLessonRel.setUpdateTime(new Date());
                flag = weiduCourseLessonRelMapper.insert(courseLessonRel) > 0;
                if (!flag) {
                    throw new VdyooException("500", "课程班信息关联失败，请联系管理员或稍后再试");
                } else {
                    return id;
                }
            } catch (Exception e) {
                //回滚
                e.printStackTrace();
                if (ValidateMT.isNotNull(id)) {
                    this.deleteCourseClassById(id);
                }
                throw new VdyooException("500", "课程班信息关联失败，请联系管理员或稍后再试");
            }
        } else {
            throw new VdyooException("500", vdyooEntity.getMessage());
        }
    }

    /**
     * 删除课程班
     *
     * @param id
     */
    public VdyooEntity deleteCourseClassById(String id) {
        Map<String, Object> param = new HashMap<>(1);
        //威渡ID
        param.put("id", id);

        return this.vdyooFactory.post(param, WeiduConfig.deleteCourseClassById);
    }

    /**
     * 编辑课程
     */
    public boolean editCourseClassById(Map<String, Object> param) {
        return this.vdyooFactory.post(param, WeiduConfig.editCourseClassById).getSuccess();
    }

    /**
     * 查询单个课程
     *
     * @param id
     */
    public VdyooEntity findCourseClassById(Integer id) {
        Map<String, Object> param = new HashMap<>();
        param.put("id", id);
        return this.vdyooFactory.post(param, WeiduConfig.findCourseClassById);
    }

    /**
     * 查询公司下的课程
     */
    public VdyooEntity findCourseClassByTenant() {
        return this.vdyooFactory.post(WeiduConfig.findCourseClassLessonTenant);
    }
}
