package com.ruida.common.util;

import com.ruida.common.SystemConstant;
import com.ruida.common.enums.AppErrorEnum;
import com.ruida.common.exception.CoreException;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Excel 导入工具类
 */
public class ExcelUtil implements Serializable {

    public static final String SPACE = "";

    private static int rowNum = 0;
    private static int colNum = 0;

    /**
     * 导入需要读取的Excel文件
     *
     * @param beanName
     * @param in
     * @param suffix
     * @return
     * @throws Exception
     */
    public static List upload(String beanName, InputStream in, String suffix) throws Exception {
        try {
            if (StringUtils.isNotEmpty(beanName)) {
                Class t = Class.forName(beanName);
                return readExcel(t, in, suffix);
            }
        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
        return null;
    }

    /**
     * 导入需要读取的Excel文件
     *
     * @param beanName
     * @param in
     * @param suffix
     * @return
     * @throws Exception
     */
    public static List uploadStuOrder(String beanName, InputStream in, String suffix) throws Exception {
        try {
            if (StringUtils.isNotEmpty(beanName)) {
                Class t = Class.forName(beanName);
                return readStuOrderExcel(t, in, suffix);
            }
        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
        return null;
    }

    public static List uploadDoubleStudent(String beanName, InputStream in) throws Exception {
        try {
            if (StringUtils.isNotEmpty(beanName)) {
                Class t = Class.forName(beanName);
                return readDoubleStuExcel(t, in);
            }
        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
        return null;
    }

    /**
     * 读取Excel实体数据
     *
     * @param beanClass
     * @param in
     * @param suffix
     * @param <T>
     * @return
     * @throws Exception
     */
    private static <T> List readExcel(Class beanClass, InputStream in, String suffix) throws Exception {
        List<Object> list = new ArrayList<>();
        Integer type = 0;
        int startRow = 0;
        if (beanClass.equals(Class.forName("com.ruida.cloud.model.StudentImportPOJO"))) {
            //学生导入
            type = 1;
             startRow = 1;
        } else if (beanClass.equals(Class.forName("com.ruida.cloud.model.KnowledgeImportPOJO"))) {
            type = 2;
        } else if (beanClass.equals(Class.forName("com.ruida.cloud.model.KnowledgeAddPOJO"))) {
            type = 3;
        }

        try {
            if ("xls".equals(suffix)) {
                HSSFWorkbook hssfWorkbook = new HSSFWorkbook(in);
                for (int numPage = 0; numPage < hssfWorkbook.getNumberOfSheets(); numPage++) {
                    HSSFSheet hssfSheet = hssfWorkbook.getSheetAt(numPage);
                    if (hssfSheet != null) {
                        /**第一行标题*/
                        HSSFRow row = hssfSheet.getRow(0);
                        if (row != null) {
                            if (type == 1){
                                String[] checkNames = new String[6];

                                for ( int i = 0; i < row.getLastCellNum(); i++) {
                                    checkNames[i] = getValueXls(row.getCell(i));
                                }
                                if( !Arrays.equals(checkNames, SystemConstant.orgStus) ){
                                    throw new Exception("模板格式有误，请下载最新模板重新导入");
                                }
                            }
                            Field[] declaredFields = beanClass.getDeclaredFields();
                            /**从第二行开始读取实体数据*/
                            for (rowNum = startRow; rowNum <= hssfSheet.getLastRowNum(); rowNum++) {
                                Map<String, String> map = new HashMap<String, String>();
                                HSSFRow hssfRow = hssfSheet.getRow(rowNum);
                                if (hssfRow != null && rowNum == 0) {
                                    //校验模板
                                    String value = getValueXls(hssfRow.getCell(0));

                                    if (type == 2 || type == 3) {
                                        Map<String, Object> map1 = new HashMap<>();
                                        map1.put("2", "一级知识点");
                                        Map<String, Object> map2 = new HashMap<>();
                                        map2.put("3", "父级知识点");
                                        Map<String, Object> map3 = new HashMap<>();
                                        map3.put(String.valueOf(type), value);

                                        if (map3.equals(map2) || map3.equals(map1)) {
                                            System.out.println("知识点模板匹配成功");
                                        } else {
                                            throw new CoreException(500, "模板错误");
                                        }
                                        continue;
                                    }

                                }

                                if (hssfRow != null) {
                                    Object obj = beanClass.newInstance();
                                    boolean flag = false;
                                    /**从第一列开始读取*/
                                    for (colNum = 0; colNum < hssfRow.getLastCellNum(); colNum++) {
                                        // String valueName = getValueXls(row.getCell(colNum));
                                        if (colNum >= declaredFields.length) {
                                            break;
                                        }
                                        String valueName = declaredFields[colNum].getName();
                                        if (hssfRow.getLastCellNum() < 6 && colNum > 0 && type == 1) {
                                            /**针对自定义学校定制处理*/
                                            valueName = declaredFields[colNum + 1].getName();
                                        }
                                        String value = getValueXls(hssfRow.getCell(colNum));
                                        if (StringUtils.isNotEmpty(value) && StringUtils.isNotEmpty(valueName)) {
                                            map.put(valueName, value);
                                            setBeanValue(valueName, value, obj, declaredFields, beanClass);
                                            flag = true;
                                        }
                                    }
                                    if (flag == true) {
                                        BeanUtils.populate(obj, map);
                                        list.add(obj);
                                    }

                                }
                            }
                        }
                    }
                }
                return list;
            } else if ("xlsx".equals(suffix)) {
                XSSFWorkbook xssfWorkbook = new XSSFWorkbook(in);
                if (xssfWorkbook != null) {
                    for (int numSheet = 0; numSheet < xssfWorkbook.getNumberOfSheets(); numSheet++) {
                        XSSFSheet xssfSheet = xssfWorkbook.getSheetAt(numSheet);
                        if (xssfSheet != null) {
                            XSSFRow row = xssfSheet.getRow(0);
                            if (row != null) {
                                if (type == 1){
                                    String[] checkNames = new String[6];

                                    for ( int i = 0; i < row.getLastCellNum(); i++) {
                                        checkNames[i] = getValueXlsx(row.getCell(i));
                                    }
                                    if( !Arrays.equals(checkNames, SystemConstant.orgStus) ){
                                        throw new Exception("模板格式有误，请下载最新模板重新导入");
                                    }
                                }

                                Field[] declaredFields = beanClass.getDeclaredFields();
                                for (rowNum = startRow; rowNum <= xssfSheet.getLastRowNum(); rowNum++) {
                                    Map<String, String> map = new HashMap<String, String>();
                                    XSSFRow xssfRow = xssfSheet.getRow(rowNum);

                                    if (xssfRow != null && rowNum == 0) {
                                        //校验模板
                                        String value = getValueXlsx(xssfRow.getCell(0));
                                        /**校验知识点模板*/
                                        if (type == 2 || type == 3) {
                                            Map<String, Object> map1 = new HashMap<>();
                                            map1.put("2", "一级知识点");
                                            Map<String, Object> map2 = new HashMap<>();
                                            map2.put("3", "父级知识点");
                                            Map<String, Object> map3 = new HashMap<>();
                                            map3.put(String.valueOf(type), value);

                                            if (map3.equals(map2) || map3.equals(map1)) {
                                                System.out.println("知识点模板匹配成功");
                                            } else {
                                                throw new CoreException(500, "模板错误");
                                            }
                                            continue;
                                        }

                                    }

                                    if (xssfRow != null) {
                                        Object obj = beanClass.newInstance();
                                        boolean flag = false;
                                        for (colNum = 0; colNum < xssfRow.getLastCellNum(); colNum++) {
                                            if (colNum >= declaredFields.length) {
                                                break;
                                            }
                                            String valueName = declaredFields[colNum].getName();
                                            if (xssfRow.getLastCellNum() < 6 && colNum > 0 && type == 1) {
                                                /**针对自定义学校定制处理*/
                                                valueName = declaredFields[colNum + 1].getName();
                                            }

                                            String value = getValueXlsx(xssfRow.getCell(colNum));
                                            if (StringUtils.isNotEmpty(value) && StringUtils.isNotEmpty(valueName)) {
                                                map.put(valueName, value);
                                                setBeanValue(valueName, value, obj, declaredFields, beanClass);
                                                flag = true;
                                            }

                                        }
                                        if (flag == true) {
                                            BeanUtils.populate(obj, map);
                                            list.add(obj);
                                        }
                                    }

                                }
                            }
                        }
                    }
                }
                return list;
            }
        } catch (FileNotFoundException e) {
            throw new Exception("文件未找到:" + e.getMessage() + ",第" + (rowNum + 1) + "行，" + (colNum + 1) + "列 异常");
        } catch (IOException e) {
            throw new Exception("读取或写入失败:" + e.getMessage() + ",第" + (rowNum + 1) + "行，" + (colNum + 1) + "列 异常");
        } catch (IllegalAccessException e) {
            throw new Exception("非法:" + e.getMessage() + ",第" + (rowNum + 1) + "行，" + (colNum + 1) + "列 异常");
        } catch (Exception e) {
            throw new Exception("读取失败:" + e.getMessage() + ",第" + (rowNum + 1) + "行，" + (colNum + 1) + "列 异常");
        }
        return list;
    }

    /**
     * 读取Excel实体数据
     *
     * @param beanClass
     * @param in
     * @param suffix
     * @param <T>
     * @return
     * @throws Exception
     */
    private static <T> List readStuOrderExcel(Class beanClass, InputStream in, String suffix) throws Exception {
        List<Object> list = new ArrayList<>();
        try {
            if ("xls".equals(suffix)) {
                HSSFWorkbook hssfWorkbook = new HSSFWorkbook(in);
                for (int numPage = 0; numPage < hssfWorkbook.getNumberOfSheets(); numPage++) {
                    HSSFSheet hssfSheet = hssfWorkbook.getSheetAt(numPage);
                    if (hssfSheet != null) {
                        /**第一行标题*/
                        HSSFRow row = hssfSheet.getRow(0);
                        //通过第0行，判断excel样式是否正确
                        String[] checkNames = new String[4];
                        for (colNum = 0; colNum < row.getLastCellNum(); colNum++) {
                            checkNames[colNum] = getValueXls(row.getCell(colNum));
                        }
                        if( !Arrays.equals(checkNames, SystemConstant.orderStus) ){
                            throw new Exception("模板格式有误，请下载最新模板重新导入");
                        }
                        if (row != null) {
                            Field[] declaredFields = beanClass.getDeclaredFields();

                            /**从第二行开始读取实体数据*/
                            for (rowNum = 1; rowNum <= hssfSheet.getLastRowNum(); rowNum++) {
                                Map<String, String> map = new HashMap<String, String>();
                                HSSFRow hssfRow = hssfSheet.getRow(rowNum);

                                if (hssfRow != null) {
                                    Object obj = beanClass.newInstance();
                                    boolean flag = false;
                                    /**从第一列开始读取*/
                                    for (colNum = 0; colNum < hssfRow.getLastCellNum(); colNum++) {
                                        String valueName = declaredFields[colNum].getName();
                                        String value = getValueXls(hssfRow.getCell(colNum));

                                        if (StringUtils.isNotEmpty(value) && StringUtils.isNotEmpty(valueName)) {
                                            map.put(valueName, value);
                                            setBeanValue(valueName, value, obj, declaredFields, beanClass);
                                            flag = true;
                                        }
                                    }
                                    if (flag == true) {
                                        BeanUtils.populate(obj, map);
                                        list.add(obj);
                                    }
                                }
                            }
                        }
                    }
                }
                return list;
            } else if ("xlsx".equals(suffix)) {
                XSSFWorkbook xssfWorkbook = new XSSFWorkbook(in);
                if (xssfWorkbook != null) {
                    for (int numSheet = 0; numSheet < xssfWorkbook.getNumberOfSheets(); numSheet++) {
                        XSSFSheet xssfSheet = xssfWorkbook.getSheetAt(numSheet);
                        if (xssfSheet != null) {
                            XSSFRow row = xssfSheet.getRow(0);
                            //通过第0行，判断excel样式是否正确
                            String[] checkNames = new String[4];
                            for (colNum = 0; colNum < row.getLastCellNum(); colNum++) {
                                checkNames[colNum] = getValueXlsxForCourseStu(row.getCell(colNum));
                            }
                            if( !Arrays.equals(checkNames, SystemConstant.orderStus) ){
                                throw new Exception("模板格式有误，请下载最新模板重新导入");
                            }
                            if (row != null) {
                                Field[] declaredFields = beanClass.getDeclaredFields();

                                for (rowNum = 1; rowNum <= xssfSheet.getLastRowNum(); rowNum++) {
                                    Map<String, String> map = new HashMap<String, String>();
                                    XSSFRow xssfRow = xssfSheet.getRow(rowNum);

                                    if (xssfRow != null) {
                                        Object obj = beanClass.newInstance();
                                        boolean flag = false;
                                        for (colNum = 0; colNum < xssfRow.getLastCellNum(); colNum++) {
                                            String valueName = declaredFields[colNum].getName();
                                            String value = getValueXlsxForCourseStu(xssfRow.getCell(colNum));

                                            System.out.println(valueName+"  ----  "+value);

                                            if (StringUtils.isNotEmpty(value) && StringUtils.isNotEmpty(valueName)) {
                                                map.put(valueName, value);
                                                setBeanValue(valueName, value, obj, declaredFields, beanClass);
                                                flag = true;
                                            }
                                        }
                                        if (flag == true) {
                                            BeanUtils.populate(obj, map);
                                            list.add(obj);
                                        }
                                    }

                                }
                            }
                        }
                    }
                }
                return list;
            }else {
                throw new Exception("模板格式有误，请下载最新模板重新导入");
            }
        } catch (Exception e) {
//            throw new Exception("文件未找到:" + e.getMessage() + ",第" + (rowNum + 1) + "行，" + (colNum + 1) + "列 异常");
//        } catch (IOException e) {
//            throw new Exception("读取或写入失败:" + e.getMessage()+ ",第" + (rowNum + 1) + "行，" + (colNum + 1) + "列 异常");
//        } catch (IllegalAccessException e) {
//            throw new Exception("非法:" + e.getMessage()+ ",第" + (rowNum + 1) + "行，" + (colNum + 1) + "列 异常");
//        } catch (Exception e) {
            throw new Exception("模板格式有误，请下载最新模板重新导入");
        }
//        return list;
    }




    private static <T> List readDoubleStuExcel(Class beanClass, InputStream in) throws Exception {
        List<Object> list = new ArrayList<>();
        try {
            XSSFWorkbook xssfWorkbook = new XSSFWorkbook(in);
            if (xssfWorkbook != null) {
                for (int numSheet = 0; numSheet < xssfWorkbook.getNumberOfSheets(); numSheet++) {
                    XSSFSheet xssfSheet = xssfWorkbook.getSheetAt(numSheet);
                    if (xssfSheet != null) {
                        XSSFRow row = xssfSheet.getRow(0);
                        String[] checkNames = new String[4];
                        for (colNum = 0; colNum < row.getLastCellNum(); colNum++) {
                            checkNames[colNum] = getValueXlsxForCourseDoubleStudent(row.getCell(colNum));
                        }
                        if( !Arrays.equals(checkNames, SystemConstant.doubleStudents) ){
                            throw new Exception("模板格式有误，请下载最新模板导入,并保证信息正确");
                        }
                        if (row != null) {
                            Field[] declaredFields = beanClass.getDeclaredFields();
                            for (rowNum = 1; rowNum <= xssfSheet.getLastRowNum(); rowNum++) {
                                Map<String, String> map = new HashMap<String, String>();
                                XSSFRow xssfRow = xssfSheet.getRow(rowNum);
                                if (xssfRow != null) {
                                    Object obj = beanClass.newInstance();
                                    boolean flag = false;
                                    for (colNum = 0; colNum < xssfRow.getLastCellNum(); colNum++) {
                                        String valueName = declaredFields[colNum].getName();
                                        String value = getValueXlsxForCourseDoubleStudent(xssfRow.getCell(colNum));
                                        if (StringUtils.isNotEmpty(value) && StringUtils.isNotEmpty(valueName)) {
                                            map.put(valueName, value);
                                            setBeanValue(valueName, value, obj, declaredFields, beanClass);
                                            flag = true;
                                        }
                                    }
                                    if (flag == true) {
                                        BeanUtils.populate(obj, map);
                                        list.add(obj);
                                    }
                                }
                            }
                        }
                    }
                }
                return list;
            }else {
                throw new Exception("模板格式有误，请下载最新模板导入,并保证信息正确");
            }
        } catch (Exception e) {
            throw new Exception("模板格式有误，请下载最新模板导入,并保证信息正确");
        }
    }



    private static String getValueXlsxForCourseDoubleStudent(XSSFCell cell) {
        if (cell != null) {
            CellType cellType = cell.getCellTypeEnum();
            switch (cellType) {
                case STRING:
                    return cell.getStringCellValue();
                case NUMERIC:
                    double random = cell.getNumericCellValue();
                    long l = new Double(random).longValue();
                    return l + "";
                default:
                    throw new CoreException(AppErrorEnum.E_10005.getErrorCode(), AppErrorEnum.E_10005.getErrorMessage());
            }
        }
        return null;
    }


    /**
     * 解决 BeanUtils.populate 对于属性对象空值报错问题
     *
     * @param valueName
     * @param value
     * @param newInstance
     * @param declaredFields
     * @param beanClass
     * @param <T>
     * @throws Exception
     */
    private static <T> void setBeanValue(String valueName, String value, T newInstance, Field[] declaredFields, Class<T> beanClass) throws Exception {
        for (Field field : declaredFields) {
            if (valueName.equalsIgnoreCase(field.getName())) {
                String methodName = "set" + valueName.substring(0, 1).toUpperCase() + valueName.substring(1);
                String typeName = field.getType().getName();
                try {
                    if ("java.lang.Double".equalsIgnoreCase(typeName)) {
                        Method method = beanClass.getMethod(methodName, Double.class);
                        method.invoke(newInstance, new Double[]{Double.valueOf(value)});
                    } else if ("java.lang.Float".equalsIgnoreCase(typeName)) {
                        Method method = beanClass.getMethod(methodName, Float.class);
                        method.invoke(newInstance, new Float[]{Float.valueOf(value)});
                    } else if ("java.lang.Boolean".equalsIgnoreCase(typeName)) {
                        Method method = beanClass.getMethod(methodName, Boolean.class);
                        method.invoke(newInstance, new Boolean[]{Boolean.valueOf(value)});
                    } else if ("java.lang.Integer".equalsIgnoreCase(typeName)) {
                        Method method = beanClass.getMethod(methodName, Integer.class);
                        method.invoke(newInstance, new Integer[]{Integer.valueOf(value)});
                    } else if ("java.math.BigDecimal".equalsIgnoreCase(typeName)) {
                        Method method = beanClass.getMethod(methodName, BigDecimal.class);
                        method.invoke(newInstance, new BigDecimal[]{new BigDecimal(value)});
                    } else if ("java.lang.Long".equalsIgnoreCase(typeName)) {
                        Method method = beanClass.getMethod(methodName, Long.class);
                        method.invoke(newInstance, new Long[]{Long.valueOf(value)});
                    } else {
                        Method method = beanClass.getMethod(methodName, String.class);
                        method.invoke(newInstance, new String[]{value});
                    }
                } catch (Exception e) {
                    throw new Exception("属性对象转换异常:" + e.getMessage() + ",第" + (rowNum + 1) + "行，" + (colNum + 1) + "列 异常");
                }
                break;
            }
        }
    }

    private static String getValueXlsx(XSSFCell cell) {
        DecimalFormat df = new DecimalFormat("0");// 格式化 number String 字符
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");// 格式化日期字符串
        DecimalFormat nf = new DecimalFormat("0");// 格式化数字

        if (cell != null) {
            CellType cellType = cell.getCellTypeEnum();
            switch (cellType) {
                case NUMERIC:
                    /** 如果有日期类型在这里处理*/
                    if ("@".equals(cell.getCellStyle().getDataFormatString())) {
                        return df.format(cell.getNumericCellValue());
                    } else if ("General".equals(cell.getCellStyle().getDataFormatString())) {
                        return nf.format(cell.getNumericCellValue());
                    } else {
                        return sdf.format(HSSFDateUtil.getJavaDate(cell.getNumericCellValue()));
                    }

                    //   return   String.valueOf(Double.valueOf(cell.getNumericCellValue()).intValue()) ;
                case STRING:
                    return cell.getStringCellValue();
                case BLANK:
                    return "";
                default:
                    throw new CoreException(AppErrorEnum.E_10005.getErrorCode(), AppErrorEnum.E_10005.getErrorMessage());
            }


        } else
            return "";
    }

    private static String getValueXls(HSSFCell cell) {
        if (cell != null)
            return cell.getStringCellValue();
        else
            return "";
    }

    private static String getValueXlsxForCourseStu(XSSFCell cell) {
        DecimalFormat df = new DecimalFormat("0.00");// 格式化 number String 字符
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");// 格式化日期字符串
        DecimalFormat nf = new DecimalFormat("0.00");// 格式化数字

        if (cell != null) {
            CellType cellType = cell.getCellTypeEnum();
            switch (cellType) {
                case NUMERIC:
                    /** 如果有日期类型在这里处理*/
                    if ("@".equals(cell.getCellStyle().getDataFormatString())) {
                        return df.format(cell.getNumericCellValue());
                    } else if ("General".equals(cell.getCellStyle().getDataFormatString())) {
                        return nf.format(cell.getNumericCellValue());
                    } else {
                        return sdf.format(HSSFDateUtil.getJavaDate(cell.getNumericCellValue()));
                    }

                    //   return   String.valueOf(Double.valueOf(cell.getNumericCellValue()).intValue()) ;
                case STRING:
                    return cell.getStringCellValue();
                case BLANK:
                    return "";
                default:
                    throw new CoreException(AppErrorEnum.E_10005.getErrorCode(), AppErrorEnum.E_10005.getErrorMessage());
            }


        } else
            return "";
    }
//    private static String getValueXlsx(XSSFCell cell) {
//        if (cell != null)
//            return cell.getStringCellValue();
//        else
//            return "";
//    }

}
