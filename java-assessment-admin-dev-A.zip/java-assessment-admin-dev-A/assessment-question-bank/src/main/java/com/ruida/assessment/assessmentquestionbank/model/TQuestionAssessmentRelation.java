package com.ruida.assessment.assessmentquestionbank.model;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import lombok.Data;

import java.io.Serializable;

/**
 * @description: 试题考察要求关联关系数据库实体
 * @author: wy
 * @date: 2021/3/2
 */
@Data
@TableName("t_question_assessment_relation")
public class TQuestionAssessmentRelation extends BaseColumn implements Serializable {
    private static final long serialVersionUID = -5661730526281579595L;

    /**
     * 关系id
     */
    @TableId
    private Integer id;

    /**
     * 试题id
     */
    private String questionLibraryId;

    /**
     * 考察要求id
     */
    private Integer assessmentId;

    /**
     * 权重值
     */
    private Integer assessmentPoints;


}
