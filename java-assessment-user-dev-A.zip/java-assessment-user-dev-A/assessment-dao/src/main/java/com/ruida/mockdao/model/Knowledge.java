package com.ruida.mockdao.model;

import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 知识点表
 * </p>
 *
 * @author chenjy
 * @since 2020-08-11
 */
@TableName("t_knowledge")
public class Knowledge extends Model<Knowledge> {

    private static final long serialVersionUID = 1L;

    /**
     * 知识点id
     */
    @TableId(value = "knowledge_id", type = IdType.AUTO)
    private Integer knowledgeId;
    /**
     * 知识点名称
     */
    @TableField("knowledge_name")
    private String knowledgeName;
    /**
     * 父id
     */
    private Integer pid;
    /**
     * 学段id
     */
    @TableField("period_id")
    private Integer periodId;
    /**
     * 科目id
     */
    @TableField("subject_id")
    private Integer subjectId;
    /**
     * 考点id
     */
    @TableField("examplace_id")
    private Integer examplaceId;
    /**
     * 考点名称
     */
    @TableField("examplace_name")
    private String examplaceName;
    /**
     * 知识点排序
     */
    private Integer sort;
    /**
     * 状态（0—禁用；1—启用）
     */
    private Integer status;
    /**
     * 创建者
     */
    @TableField("create_by")
    private Integer createBy;
    /**
     * 创建时间
     */
    @TableField("create_time")
    private Date createTime;
    /**
     * 修改者
     */
    @TableField("update_by")
    private Integer updateBy;
    /**
     * 修改时间
     */
    @TableField("update_time")
    private Date updateTime;
    /**
     * 是否删除（0：未删除；1：删除）
     */
    private Integer isdelete;


    public Integer getKnowledgeId() {
        return knowledgeId;
    }

    public void setKnowledgeId(Integer knowledgeId) {
        this.knowledgeId = knowledgeId;
    }

    public String getKnowledgeName() {
        return knowledgeName;
    }

    public void setKnowledgeName(String knowledgeName) {
        this.knowledgeName = knowledgeName;
    }

    public Integer getPid() {
        return pid;
    }

    public void setPid(Integer pid) {
        this.pid = pid;
    }

    public Integer getPeriodId() {
        return periodId;
    }

    public void setPeriodId(Integer periodId) {
        this.periodId = periodId;
    }

    public Integer getSubjectId() {
        return subjectId;
    }

    public void setSubjectId(Integer subjectId) {
        this.subjectId = subjectId;
    }

    public Integer getExamplaceId() {
        return examplaceId;
    }

    public void setExamplaceId(Integer examplaceId) {
        this.examplaceId = examplaceId;
    }

    public String getExamplaceName() {
        return examplaceName;
    }

    public void setExamplaceName(String examplaceName) {
        this.examplaceName = examplaceName;
    }

    public Integer getSort() {
        return sort;
    }

    public void setSort(Integer sort) {
        this.sort = sort;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getCreateBy() {
        return createBy;
    }

    public void setCreateBy(Integer createBy) {
        this.createBy = createBy;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(Integer updateBy) {
        this.updateBy = updateBy;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getIsdelete() {
        return isdelete;
    }

    public void setIsdelete(Integer isdelete) {
        this.isdelete = isdelete;
    }

    @Override
    protected Serializable pkVal() {
        return this.knowledgeId;
    }

    @Override
    public String toString() {
        return "Knowledge{" +
        ", knowledgeId=" + knowledgeId +
        ", knowledgeName=" + knowledgeName +
        ", pid=" + pid +
        ", periodId=" + periodId +
        ", subjectId=" + subjectId +
        ", examplaceId=" + examplaceId +
        ", examplaceName=" + examplaceName +
        ", sort=" + sort +
        ", status=" + status +
        ", createBy=" + createBy +
        ", createTime=" + createTime +
        ", updateBy=" + updateBy +
        ", updateTime=" + updateTime +
        ", isdelete=" + isdelete +
        "}";
    }
}
