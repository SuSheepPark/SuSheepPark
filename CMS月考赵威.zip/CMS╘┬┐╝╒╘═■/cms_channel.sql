/*
Navicat MySQL Data Transfer

Source Server         : my
Source Server Version : 50557
Source Host           : 127.0.0.1:3306
Source Database       : 1705e_cms

Target Server Type    : MYSQL
Target Server Version : 50557
File Encoding         : 65001

Date: 2019-09-25 11:40:00
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `cms_channel`
-- ----------------------------
DROP TABLE IF EXISTS `cms_channel`;
CREATE TABLE `cms_channel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) DEFAULT NULL,
  `description` varchar(50) DEFAULT NULL,
  `icon` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cms_channel
-- ----------------------------
INSERT INTO `cms_channel` VALUES ('1', '科技', null, null);
INSERT INTO `cms_channel` VALUES ('2', '财经', null, null);
INSERT INTO `cms_channel` VALUES ('3', '国际', null, null);
INSERT INTO `cms_channel` VALUES ('4', '汽车', null, null);
INSERT INTO `cms_channel` VALUES ('5', '体育', null, null);
INSERT INTO `cms_channel` VALUES ('6', '娱乐', null, null);
INSERT INTO `cms_channel` VALUES ('7', '搞笑', null, null);
INSERT INTO `cms_channel` VALUES ('8', '游戏', '', null);
INSERT INTO `cms_channel` VALUES ('9', '图片', null, null);
