package com.ruida.assessment.assessmentquestionbank.model;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import io.swagger.annotations.ApiModel;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;


/**
 * @author wy
 * @description  商品数据库实体类
 * @date 2020/6/24
 */
@Data
@ApiModel(description = "商品-学员关联数据库实体")
@TableName("t_product_user_rel")
public class TProductUserRel extends BaseColumn implements Serializable {


    private static final long serialVersionUID = 8718648542822110478L;
    /**
     * 主键id
     */
    @TableId
    private Integer relId;

    /*
    用户Id
    */
    private Integer userId;

    /*
    用户的虚拟考生id
   */
    private Integer stuId;

    /*
        商品id
     */
    private Integer productId;

    /*
    是否购买
     */
    private Integer isBuy;

    /*
    完成比例
     */
    private BigDecimal rate;
}
