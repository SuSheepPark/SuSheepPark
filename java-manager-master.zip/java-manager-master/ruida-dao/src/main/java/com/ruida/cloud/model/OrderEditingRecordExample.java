package com.ruida.cloud.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class OrderEditingRecordExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public OrderEditingRecordExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andIdIsNull() {
            addCriterion("id is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("id is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(Integer value) {
            addCriterion("id =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(Integer value) {
            addCriterion("id <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(Integer value) {
            addCriterion("id >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("id >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(Integer value) {
            addCriterion("id <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(Integer value) {
            addCriterion("id <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<Integer> values) {
            addCriterion("id in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<Integer> values) {
            addCriterion("id not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(Integer value1, Integer value2) {
            addCriterion("id between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(Integer value1, Integer value2) {
            addCriterion("id not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andOrderIdIsNull() {
            addCriterion("order_id is null");
            return (Criteria) this;
        }

        public Criteria andOrderIdIsNotNull() {
            addCriterion("order_id is not null");
            return (Criteria) this;
        }

        public Criteria andOrderIdEqualTo(Integer value) {
            addCriterion("order_id =", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdNotEqualTo(Integer value) {
            addCriterion("order_id <>", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdGreaterThan(Integer value) {
            addCriterion("order_id >", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("order_id >=", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdLessThan(Integer value) {
            addCriterion("order_id <", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdLessThanOrEqualTo(Integer value) {
            addCriterion("order_id <=", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdIn(List<Integer> values) {
            addCriterion("order_id in", values, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdNotIn(List<Integer> values) {
            addCriterion("order_id not in", values, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdBetween(Integer value1, Integer value2) {
            addCriterion("order_id between", value1, value2, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdNotBetween(Integer value1, Integer value2) {
            addCriterion("order_id not between", value1, value2, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderNoIsNull() {
            addCriterion("order_no is null");
            return (Criteria) this;
        }

        public Criteria andOrderNoIsNotNull() {
            addCriterion("order_no is not null");
            return (Criteria) this;
        }

        public Criteria andOrderNoEqualTo(String value) {
            addCriterion("order_no =", value, "orderNo");
            return (Criteria) this;
        }

        public Criteria andOrderNoNotEqualTo(String value) {
            addCriterion("order_no <>", value, "orderNo");
            return (Criteria) this;
        }

        public Criteria andOrderNoGreaterThan(String value) {
            addCriterion("order_no >", value, "orderNo");
            return (Criteria) this;
        }

        public Criteria andOrderNoGreaterThanOrEqualTo(String value) {
            addCriterion("order_no >=", value, "orderNo");
            return (Criteria) this;
        }

        public Criteria andOrderNoLessThan(String value) {
            addCriterion("order_no <", value, "orderNo");
            return (Criteria) this;
        }

        public Criteria andOrderNoLessThanOrEqualTo(String value) {
            addCriterion("order_no <=", value, "orderNo");
            return (Criteria) this;
        }

        public Criteria andOrderNoLike(String value) {
            addCriterion("order_no like", value, "orderNo");
            return (Criteria) this;
        }

        public Criteria andOrderNoNotLike(String value) {
            addCriterion("order_no not like", value, "orderNo");
            return (Criteria) this;
        }

        public Criteria andOrderNoIn(List<String> values) {
            addCriterion("order_no in", values, "orderNo");
            return (Criteria) this;
        }

        public Criteria andOrderNoNotIn(List<String> values) {
            addCriterion("order_no not in", values, "orderNo");
            return (Criteria) this;
        }

        public Criteria andOrderNoBetween(String value1, String value2) {
            addCriterion("order_no between", value1, value2, "orderNo");
            return (Criteria) this;
        }

        public Criteria andOrderNoNotBetween(String value1, String value2) {
            addCriterion("order_no not between", value1, value2, "orderNo");
            return (Criteria) this;
        }

        public Criteria andEditTypeIsNull() {
            addCriterion("edit_type is null");
            return (Criteria) this;
        }

        public Criteria andEditTypeIsNotNull() {
            addCriterion("edit_type is not null");
            return (Criteria) this;
        }

        public Criteria andEditTypeEqualTo(Byte value) {
            addCriterion("edit_type =", value, "editType");
            return (Criteria) this;
        }

        public Criteria andEditTypeNotEqualTo(Byte value) {
            addCriterion("edit_type <>", value, "editType");
            return (Criteria) this;
        }

        public Criteria andEditTypeGreaterThan(Byte value) {
            addCriterion("edit_type >", value, "editType");
            return (Criteria) this;
        }

        public Criteria andEditTypeGreaterThanOrEqualTo(Byte value) {
            addCriterion("edit_type >=", value, "editType");
            return (Criteria) this;
        }

        public Criteria andEditTypeLessThan(Byte value) {
            addCriterion("edit_type <", value, "editType");
            return (Criteria) this;
        }

        public Criteria andEditTypeLessThanOrEqualTo(Byte value) {
            addCriterion("edit_type <=", value, "editType");
            return (Criteria) this;
        }

        public Criteria andEditTypeIn(List<Byte> values) {
            addCriterion("edit_type in", values, "editType");
            return (Criteria) this;
        }

        public Criteria andEditTypeNotIn(List<Byte> values) {
            addCriterion("edit_type not in", values, "editType");
            return (Criteria) this;
        }

        public Criteria andEditTypeBetween(Byte value1, Byte value2) {
            addCriterion("edit_type between", value1, value2, "editType");
            return (Criteria) this;
        }

        public Criteria andEditTypeNotBetween(Byte value1, Byte value2) {
            addCriterion("edit_type not between", value1, value2, "editType");
            return (Criteria) this;
        }

        public Criteria andRealOrderAmountOldIsNull() {
            addCriterion("real_order_amount_old is null");
            return (Criteria) this;
        }

        public Criteria andRealOrderAmountOldIsNotNull() {
            addCriterion("real_order_amount_old is not null");
            return (Criteria) this;
        }

        public Criteria andRealOrderAmountOldEqualTo(BigDecimal value) {
            addCriterion("real_order_amount_old =", value, "realOrderAmountOld");
            return (Criteria) this;
        }

        public Criteria andRealOrderAmountOldNotEqualTo(BigDecimal value) {
            addCriterion("real_order_amount_old <>", value, "realOrderAmountOld");
            return (Criteria) this;
        }

        public Criteria andRealOrderAmountOldGreaterThan(BigDecimal value) {
            addCriterion("real_order_amount_old >", value, "realOrderAmountOld");
            return (Criteria) this;
        }

        public Criteria andRealOrderAmountOldGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("real_order_amount_old >=", value, "realOrderAmountOld");
            return (Criteria) this;
        }

        public Criteria andRealOrderAmountOldLessThan(BigDecimal value) {
            addCriterion("real_order_amount_old <", value, "realOrderAmountOld");
            return (Criteria) this;
        }

        public Criteria andRealOrderAmountOldLessThanOrEqualTo(BigDecimal value) {
            addCriterion("real_order_amount_old <=", value, "realOrderAmountOld");
            return (Criteria) this;
        }

        public Criteria andRealOrderAmountOldIn(List<BigDecimal> values) {
            addCriterion("real_order_amount_old in", values, "realOrderAmountOld");
            return (Criteria) this;
        }

        public Criteria andRealOrderAmountOldNotIn(List<BigDecimal> values) {
            addCriterion("real_order_amount_old not in", values, "realOrderAmountOld");
            return (Criteria) this;
        }

        public Criteria andRealOrderAmountOldBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("real_order_amount_old between", value1, value2, "realOrderAmountOld");
            return (Criteria) this;
        }

        public Criteria andRealOrderAmountOldNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("real_order_amount_old not between", value1, value2, "realOrderAmountOld");
            return (Criteria) this;
        }

        public Criteria andRealOrderAmountNewIsNull() {
            addCriterion("real_order_amount_new is null");
            return (Criteria) this;
        }

        public Criteria andRealOrderAmountNewIsNotNull() {
            addCriterion("real_order_amount_new is not null");
            return (Criteria) this;
        }

        public Criteria andRealOrderAmountNewEqualTo(BigDecimal value) {
            addCriterion("real_order_amount_new =", value, "realOrderAmountNew");
            return (Criteria) this;
        }

        public Criteria andRealOrderAmountNewNotEqualTo(BigDecimal value) {
            addCriterion("real_order_amount_new <>", value, "realOrderAmountNew");
            return (Criteria) this;
        }

        public Criteria andRealOrderAmountNewGreaterThan(BigDecimal value) {
            addCriterion("real_order_amount_new >", value, "realOrderAmountNew");
            return (Criteria) this;
        }

        public Criteria andRealOrderAmountNewGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("real_order_amount_new >=", value, "realOrderAmountNew");
            return (Criteria) this;
        }

        public Criteria andRealOrderAmountNewLessThan(BigDecimal value) {
            addCriterion("real_order_amount_new <", value, "realOrderAmountNew");
            return (Criteria) this;
        }

        public Criteria andRealOrderAmountNewLessThanOrEqualTo(BigDecimal value) {
            addCriterion("real_order_amount_new <=", value, "realOrderAmountNew");
            return (Criteria) this;
        }

        public Criteria andRealOrderAmountNewIn(List<BigDecimal> values) {
            addCriterion("real_order_amount_new in", values, "realOrderAmountNew");
            return (Criteria) this;
        }

        public Criteria andRealOrderAmountNewNotIn(List<BigDecimal> values) {
            addCriterion("real_order_amount_new not in", values, "realOrderAmountNew");
            return (Criteria) this;
        }

        public Criteria andRealOrderAmountNewBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("real_order_amount_new between", value1, value2, "realOrderAmountNew");
            return (Criteria) this;
        }

        public Criteria andRealOrderAmountNewNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("real_order_amount_new not between", value1, value2, "realOrderAmountNew");
            return (Criteria) this;
        }

        public Criteria andSaleAmountOldIsNull() {
            addCriterion("sale_amount_old is null");
            return (Criteria) this;
        }

        public Criteria andSaleAmountOldIsNotNull() {
            addCriterion("sale_amount_old is not null");
            return (Criteria) this;
        }

        public Criteria andSaleAmountOldEqualTo(BigDecimal value) {
            addCriterion("sale_amount_old =", value, "saleAmountOld");
            return (Criteria) this;
        }

        public Criteria andSaleAmountOldNotEqualTo(BigDecimal value) {
            addCriterion("sale_amount_old <>", value, "saleAmountOld");
            return (Criteria) this;
        }

        public Criteria andSaleAmountOldGreaterThan(BigDecimal value) {
            addCriterion("sale_amount_old >", value, "saleAmountOld");
            return (Criteria) this;
        }

        public Criteria andSaleAmountOldGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("sale_amount_old >=", value, "saleAmountOld");
            return (Criteria) this;
        }

        public Criteria andSaleAmountOldLessThan(BigDecimal value) {
            addCriterion("sale_amount_old <", value, "saleAmountOld");
            return (Criteria) this;
        }

        public Criteria andSaleAmountOldLessThanOrEqualTo(BigDecimal value) {
            addCriterion("sale_amount_old <=", value, "saleAmountOld");
            return (Criteria) this;
        }

        public Criteria andSaleAmountOldIn(List<BigDecimal> values) {
            addCriterion("sale_amount_old in", values, "saleAmountOld");
            return (Criteria) this;
        }

        public Criteria andSaleAmountOldNotIn(List<BigDecimal> values) {
            addCriterion("sale_amount_old not in", values, "saleAmountOld");
            return (Criteria) this;
        }

        public Criteria andSaleAmountOldBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("sale_amount_old between", value1, value2, "saleAmountOld");
            return (Criteria) this;
        }

        public Criteria andSaleAmountOldNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("sale_amount_old not between", value1, value2, "saleAmountOld");
            return (Criteria) this;
        }

        public Criteria andSaleAmountNewIsNull() {
            addCriterion("sale_amount_new is null");
            return (Criteria) this;
        }

        public Criteria andSaleAmountNewIsNotNull() {
            addCriterion("sale_amount_new is not null");
            return (Criteria) this;
        }

        public Criteria andSaleAmountNewEqualTo(BigDecimal value) {
            addCriterion("sale_amount_new =", value, "saleAmountNew");
            return (Criteria) this;
        }

        public Criteria andSaleAmountNewNotEqualTo(BigDecimal value) {
            addCriterion("sale_amount_new <>", value, "saleAmountNew");
            return (Criteria) this;
        }

        public Criteria andSaleAmountNewGreaterThan(BigDecimal value) {
            addCriterion("sale_amount_new >", value, "saleAmountNew");
            return (Criteria) this;
        }

        public Criteria andSaleAmountNewGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("sale_amount_new >=", value, "saleAmountNew");
            return (Criteria) this;
        }

        public Criteria andSaleAmountNewLessThan(BigDecimal value) {
            addCriterion("sale_amount_new <", value, "saleAmountNew");
            return (Criteria) this;
        }

        public Criteria andSaleAmountNewLessThanOrEqualTo(BigDecimal value) {
            addCriterion("sale_amount_new <=", value, "saleAmountNew");
            return (Criteria) this;
        }

        public Criteria andSaleAmountNewIn(List<BigDecimal> values) {
            addCriterion("sale_amount_new in", values, "saleAmountNew");
            return (Criteria) this;
        }

        public Criteria andSaleAmountNewNotIn(List<BigDecimal> values) {
            addCriterion("sale_amount_new not in", values, "saleAmountNew");
            return (Criteria) this;
        }

        public Criteria andSaleAmountNewBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("sale_amount_new between", value1, value2, "saleAmountNew");
            return (Criteria) this;
        }

        public Criteria andSaleAmountNewNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("sale_amount_new not between", value1, value2, "saleAmountNew");
            return (Criteria) this;
        }

        public Criteria andCourseTypeNameOldIsNull() {
            addCriterion("course_type_name_old is null");
            return (Criteria) this;
        }

        public Criteria andCourseTypeNameOldIsNotNull() {
            addCriterion("course_type_name_old is not null");
            return (Criteria) this;
        }

        public Criteria andCourseTypeNameOldEqualTo(String value) {
            addCriterion("course_type_name_old =", value, "courseTypeNameOld");
            return (Criteria) this;
        }

        public Criteria andCourseTypeNameOldNotEqualTo(String value) {
            addCriterion("course_type_name_old <>", value, "courseTypeNameOld");
            return (Criteria) this;
        }

        public Criteria andCourseTypeNameOldGreaterThan(String value) {
            addCriterion("course_type_name_old >", value, "courseTypeNameOld");
            return (Criteria) this;
        }

        public Criteria andCourseTypeNameOldGreaterThanOrEqualTo(String value) {
            addCriterion("course_type_name_old >=", value, "courseTypeNameOld");
            return (Criteria) this;
        }

        public Criteria andCourseTypeNameOldLessThan(String value) {
            addCriterion("course_type_name_old <", value, "courseTypeNameOld");
            return (Criteria) this;
        }

        public Criteria andCourseTypeNameOldLessThanOrEqualTo(String value) {
            addCriterion("course_type_name_old <=", value, "courseTypeNameOld");
            return (Criteria) this;
        }

        public Criteria andCourseTypeNameOldLike(String value) {
            addCriterion("course_type_name_old like", value, "courseTypeNameOld");
            return (Criteria) this;
        }

        public Criteria andCourseTypeNameOldNotLike(String value) {
            addCriterion("course_type_name_old not like", value, "courseTypeNameOld");
            return (Criteria) this;
        }

        public Criteria andCourseTypeNameOldIn(List<String> values) {
            addCriterion("course_type_name_old in", values, "courseTypeNameOld");
            return (Criteria) this;
        }

        public Criteria andCourseTypeNameOldNotIn(List<String> values) {
            addCriterion("course_type_name_old not in", values, "courseTypeNameOld");
            return (Criteria) this;
        }

        public Criteria andCourseTypeNameOldBetween(String value1, String value2) {
            addCriterion("course_type_name_old between", value1, value2, "courseTypeNameOld");
            return (Criteria) this;
        }

        public Criteria andCourseTypeNameOldNotBetween(String value1, String value2) {
            addCriterion("course_type_name_old not between", value1, value2, "courseTypeNameOld");
            return (Criteria) this;
        }

        public Criteria andCourseTypeNameNewIsNull() {
            addCriterion("course_type_name_new is null");
            return (Criteria) this;
        }

        public Criteria andCourseTypeNameNewIsNotNull() {
            addCriterion("course_type_name_new is not null");
            return (Criteria) this;
        }

        public Criteria andCourseTypeNameNewEqualTo(String value) {
            addCriterion("course_type_name_new =", value, "courseTypeNameNew");
            return (Criteria) this;
        }

        public Criteria andCourseTypeNameNewNotEqualTo(String value) {
            addCriterion("course_type_name_new <>", value, "courseTypeNameNew");
            return (Criteria) this;
        }

        public Criteria andCourseTypeNameNewGreaterThan(String value) {
            addCriterion("course_type_name_new >", value, "courseTypeNameNew");
            return (Criteria) this;
        }

        public Criteria andCourseTypeNameNewGreaterThanOrEqualTo(String value) {
            addCriterion("course_type_name_new >=", value, "courseTypeNameNew");
            return (Criteria) this;
        }

        public Criteria andCourseTypeNameNewLessThan(String value) {
            addCriterion("course_type_name_new <", value, "courseTypeNameNew");
            return (Criteria) this;
        }

        public Criteria andCourseTypeNameNewLessThanOrEqualTo(String value) {
            addCriterion("course_type_name_new <=", value, "courseTypeNameNew");
            return (Criteria) this;
        }

        public Criteria andCourseTypeNameNewLike(String value) {
            addCriterion("course_type_name_new like", value, "courseTypeNameNew");
            return (Criteria) this;
        }

        public Criteria andCourseTypeNameNewNotLike(String value) {
            addCriterion("course_type_name_new not like", value, "courseTypeNameNew");
            return (Criteria) this;
        }

        public Criteria andCourseTypeNameNewIn(List<String> values) {
            addCriterion("course_type_name_new in", values, "courseTypeNameNew");
            return (Criteria) this;
        }

        public Criteria andCourseTypeNameNewNotIn(List<String> values) {
            addCriterion("course_type_name_new not in", values, "courseTypeNameNew");
            return (Criteria) this;
        }

        public Criteria andCourseTypeNameNewBetween(String value1, String value2) {
            addCriterion("course_type_name_new between", value1, value2, "courseTypeNameNew");
            return (Criteria) this;
        }

        public Criteria andCourseTypeNameNewNotBetween(String value1, String value2) {
            addCriterion("course_type_name_new not between", value1, value2, "courseTypeNameNew");
            return (Criteria) this;
        }

        public Criteria andTeachingMethodOldIsNull() {
            addCriterion("teaching_method_old is null");
            return (Criteria) this;
        }

        public Criteria andTeachingMethodOldIsNotNull() {
            addCriterion("teaching_method_old is not null");
            return (Criteria) this;
        }

        public Criteria andTeachingMethodOldEqualTo(Byte value) {
            addCriterion("teaching_method_old =", value, "teachingMethodOld");
            return (Criteria) this;
        }

        public Criteria andTeachingMethodOldNotEqualTo(Byte value) {
            addCriterion("teaching_method_old <>", value, "teachingMethodOld");
            return (Criteria) this;
        }

        public Criteria andTeachingMethodOldGreaterThan(Byte value) {
            addCriterion("teaching_method_old >", value, "teachingMethodOld");
            return (Criteria) this;
        }

        public Criteria andTeachingMethodOldGreaterThanOrEqualTo(Byte value) {
            addCriterion("teaching_method_old >=", value, "teachingMethodOld");
            return (Criteria) this;
        }

        public Criteria andTeachingMethodOldLessThan(Byte value) {
            addCriterion("teaching_method_old <", value, "teachingMethodOld");
            return (Criteria) this;
        }

        public Criteria andTeachingMethodOldLessThanOrEqualTo(Byte value) {
            addCriterion("teaching_method_old <=", value, "teachingMethodOld");
            return (Criteria) this;
        }

        public Criteria andTeachingMethodOldIn(List<Byte> values) {
            addCriterion("teaching_method_old in", values, "teachingMethodOld");
            return (Criteria) this;
        }

        public Criteria andTeachingMethodOldNotIn(List<Byte> values) {
            addCriterion("teaching_method_old not in", values, "teachingMethodOld");
            return (Criteria) this;
        }

        public Criteria andTeachingMethodOldBetween(Byte value1, Byte value2) {
            addCriterion("teaching_method_old between", value1, value2, "teachingMethodOld");
            return (Criteria) this;
        }

        public Criteria andTeachingMethodOldNotBetween(Byte value1, Byte value2) {
            addCriterion("teaching_method_old not between", value1, value2, "teachingMethodOld");
            return (Criteria) this;
        }

        public Criteria andTeachingMethodNewIsNull() {
            addCriterion("teaching_method_new is null");
            return (Criteria) this;
        }

        public Criteria andTeachingMethodNewIsNotNull() {
            addCriterion("teaching_method_new is not null");
            return (Criteria) this;
        }

        public Criteria andTeachingMethodNewEqualTo(Byte value) {
            addCriterion("teaching_method_new =", value, "teachingMethodNew");
            return (Criteria) this;
        }

        public Criteria andTeachingMethodNewNotEqualTo(Byte value) {
            addCriterion("teaching_method_new <>", value, "teachingMethodNew");
            return (Criteria) this;
        }

        public Criteria andTeachingMethodNewGreaterThan(Byte value) {
            addCriterion("teaching_method_new >", value, "teachingMethodNew");
            return (Criteria) this;
        }

        public Criteria andTeachingMethodNewGreaterThanOrEqualTo(Byte value) {
            addCriterion("teaching_method_new >=", value, "teachingMethodNew");
            return (Criteria) this;
        }

        public Criteria andTeachingMethodNewLessThan(Byte value) {
            addCriterion("teaching_method_new <", value, "teachingMethodNew");
            return (Criteria) this;
        }

        public Criteria andTeachingMethodNewLessThanOrEqualTo(Byte value) {
            addCriterion("teaching_method_new <=", value, "teachingMethodNew");
            return (Criteria) this;
        }

        public Criteria andTeachingMethodNewIn(List<Byte> values) {
            addCriterion("teaching_method_new in", values, "teachingMethodNew");
            return (Criteria) this;
        }

        public Criteria andTeachingMethodNewNotIn(List<Byte> values) {
            addCriterion("teaching_method_new not in", values, "teachingMethodNew");
            return (Criteria) this;
        }

        public Criteria andTeachingMethodNewBetween(Byte value1, Byte value2) {
            addCriterion("teaching_method_new between", value1, value2, "teachingMethodNew");
            return (Criteria) this;
        }

        public Criteria andTeachingMethodNewNotBetween(Byte value1, Byte value2) {
            addCriterion("teaching_method_new not between", value1, value2, "teachingMethodNew");
            return (Criteria) this;
        }

        public Criteria andCreateByIsNull() {
            addCriterion("create_by is null");
            return (Criteria) this;
        }

        public Criteria andCreateByIsNotNull() {
            addCriterion("create_by is not null");
            return (Criteria) this;
        }

        public Criteria andCreateByEqualTo(Integer value) {
            addCriterion("create_by =", value, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByNotEqualTo(Integer value) {
            addCriterion("create_by <>", value, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByGreaterThan(Integer value) {
            addCriterion("create_by >", value, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByGreaterThanOrEqualTo(Integer value) {
            addCriterion("create_by >=", value, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByLessThan(Integer value) {
            addCriterion("create_by <", value, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByLessThanOrEqualTo(Integer value) {
            addCriterion("create_by <=", value, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByIn(List<Integer> values) {
            addCriterion("create_by in", values, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByNotIn(List<Integer> values) {
            addCriterion("create_by not in", values, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByBetween(Integer value1, Integer value2) {
            addCriterion("create_by between", value1, value2, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByNotBetween(Integer value1, Integer value2) {
            addCriterion("create_by not between", value1, value2, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNull() {
            addCriterion("create_time is null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNotNull() {
            addCriterion("create_time is not null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeEqualTo(Date value) {
            addCriterion("create_time =", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotEqualTo(Date value) {
            addCriterion("create_time <>", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThan(Date value) {
            addCriterion("create_time >", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("create_time >=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThan(Date value) {
            addCriterion("create_time <", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThanOrEqualTo(Date value) {
            addCriterion("create_time <=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIn(List<Date> values) {
            addCriterion("create_time in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotIn(List<Date> values) {
            addCriterion("create_time not in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeBetween(Date value1, Date value2) {
            addCriterion("create_time between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotBetween(Date value1, Date value2) {
            addCriterion("create_time not between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andUpdateByIsNull() {
            addCriterion("update_by is null");
            return (Criteria) this;
        }

        public Criteria andUpdateByIsNotNull() {
            addCriterion("update_by is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateByEqualTo(Integer value) {
            addCriterion("update_by =", value, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByNotEqualTo(Integer value) {
            addCriterion("update_by <>", value, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByGreaterThan(Integer value) {
            addCriterion("update_by >", value, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByGreaterThanOrEqualTo(Integer value) {
            addCriterion("update_by >=", value, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByLessThan(Integer value) {
            addCriterion("update_by <", value, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByLessThanOrEqualTo(Integer value) {
            addCriterion("update_by <=", value, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByIn(List<Integer> values) {
            addCriterion("update_by in", values, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByNotIn(List<Integer> values) {
            addCriterion("update_by not in", values, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByBetween(Integer value1, Integer value2) {
            addCriterion("update_by between", value1, value2, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByNotBetween(Integer value1, Integer value2) {
            addCriterion("update_by not between", value1, value2, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNull() {
            addCriterion("update_time is null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNotNull() {
            addCriterion("update_time is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeEqualTo(Date value) {
            addCriterion("update_time =", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotEqualTo(Date value) {
            addCriterion("update_time <>", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThan(Date value) {
            addCriterion("update_time >", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("update_time >=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThan(Date value) {
            addCriterion("update_time <", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThanOrEqualTo(Date value) {
            addCriterion("update_time <=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIn(List<Date> values) {
            addCriterion("update_time in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotIn(List<Date> values) {
            addCriterion("update_time not in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeBetween(Date value1, Date value2) {
            addCriterion("update_time between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotBetween(Date value1, Date value2) {
            addCriterion("update_time not between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andIsdeleteIsNull() {
            addCriterion("isdelete is null");
            return (Criteria) this;
        }

        public Criteria andIsdeleteIsNotNull() {
            addCriterion("isdelete is not null");
            return (Criteria) this;
        }

        public Criteria andIsdeleteEqualTo(Byte value) {
            addCriterion("isdelete =", value, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteNotEqualTo(Byte value) {
            addCriterion("isdelete <>", value, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteGreaterThan(Byte value) {
            addCriterion("isdelete >", value, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteGreaterThanOrEqualTo(Byte value) {
            addCriterion("isdelete >=", value, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteLessThan(Byte value) {
            addCriterion("isdelete <", value, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteLessThanOrEqualTo(Byte value) {
            addCriterion("isdelete <=", value, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteIn(List<Byte> values) {
            addCriterion("isdelete in", values, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteNotIn(List<Byte> values) {
            addCriterion("isdelete not in", values, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteBetween(Byte value1, Byte value2) {
            addCriterion("isdelete between", value1, value2, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteNotBetween(Byte value1, Byte value2) {
            addCriterion("isdelete not between", value1, value2, "isdelete");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}