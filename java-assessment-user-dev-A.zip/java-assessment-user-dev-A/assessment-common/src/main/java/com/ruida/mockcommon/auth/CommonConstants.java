package com.ruida.mockcommon.auth;

public interface CommonConstants {
    String CONTEXT_KEY_USER_ID = "currentUserId";
    String CONTEXT_KEY_USERNAME = "currentUserName";
    String CONTEXT_KEY_USER_NAME = "currentUser";
    String CONTEXT_KEY_USER_TOKEN = "currentUserToken";
    String CONTEXT_KEY_USER_JWTINFO="currentJWTinfo";
    String JWT_KEY_USER_ID = "userId";
    String JWT_KEY_NAME = "name";
    String JWT_KEY_SOURCE = "source";
    String JWT_KEY_PERSONID ="personId";
    String JWT_KEY_STUNO ="stuId";
    String JWT_KEY_TYPE ="type";
    String JWT_KEY_CLIENT ="client";
}
