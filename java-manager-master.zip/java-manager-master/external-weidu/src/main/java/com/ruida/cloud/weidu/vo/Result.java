package com.ruida.cloud.weidu.vo;

import com.ruida.common.enums.ResultStatusCode;
import com.ruida.common.vo.BaseResult;

public class Result extends BaseResult {

    public Result(int code, String msg, Object data) {
        super(code, msg, data);
    }
    public Result(ResultStatusCode resultStatusCode, Object data){
        super(resultStatusCode, data);
    }

    public Result(int code, String msg){
        super(code,msg);

    }

    public Result(ResultStatusCode resultStatusCode){
        super(resultStatusCode);
    }
}
