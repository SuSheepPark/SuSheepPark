package com.ruida.assessment.assessmentcommon.enums;

/**
 * @author xumingqi
 * @date 2021/2/7 11:14
 */
public enum TestReportPriceConfigTypeEnum {
    JOB_INTEREST_QUESTIONNAIRE(0, "职业兴趣测试问卷"),
    JOB_INTEREST_REPORT(1, "职业兴趣测试报告"),
    SUBJECT_CHOOSE_REPORT(2, "科目选考推荐科目组合报告"),
    WISH_REPORT(3, "志愿填报报告");

    private Integer k;
    private String v;

    TestReportPriceConfigTypeEnum(Integer k, String v) {
        this.k = k;
        this.v = v;
    }

    public Integer getK() {
        return k;
    }

    public void setK(Integer k) {
        this.k = k;
    }

    public String getV() {
        return v;
    }

    public void setV(String v) {
        this.v = v;
    }
}
