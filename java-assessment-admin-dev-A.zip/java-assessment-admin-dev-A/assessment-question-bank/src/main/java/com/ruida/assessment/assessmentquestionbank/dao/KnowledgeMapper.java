package com.ruida.assessment.assessmentquestionbank.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.assessment.assessmentquestionbank.dto.KnowledgeRequest;
import com.ruida.assessment.assessmentquestionbank.model.TKnowledge;
import com.ruida.assessment.assessmentquestionbank.model.TQuestionKnowledgeRelation;
import com.ruida.assessment.assessmentquestionbank.model.TSectionKnowledge;
import com.ruida.assessment.assessmentquestionbank.vo.KnowledgeTreeVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * @author wy
 * @description 知识点mapper
 * @date 2020/6/10
 */
@Mapper
public interface KnowledgeMapper extends BaseMapper<TKnowledge> {

    /*
     *功能描述  查询知识点树形结构所需数据集合
     * @param
     * @return
     */
    List<KnowledgeTreeVo> selectTreeColumnList(@Param("vo") KnowledgeRequest request);

    /*
     *功能描述 根据知识点id查询章节-知识点关联数据
     * @param
     * @return 
     */
    List<TSectionKnowledge> selectRelationSectionById(@Param("vo") KnowledgeRequest request);

    /*
        根据知识点id查询知识点-试题关联数据
     */
    List<TQuestionKnowledgeRelation> selectRelationQuestionById(@Param("vo") KnowledgeRequest request);

    /*
        查询所有章节-知识点关联数据
     */
    List<TSectionKnowledge> queryAllSectionRelationKnowledge();

    /*
        查询所有试题-知识点关联数据
     */
    List<TQuestionKnowledgeRelation> queryAllQuestionRelationKnowledge();

    List<Integer> queryAllExamRecordId(@Param("list") List<Integer> kidList);

    void deleteStatKnowledgeUserRel(List<Integer> kidList);
    @Select("SELECT\n" +
            "\tCONCAT(GROUP_CONCAT(b.knowledge_id),\",\",a.pid)  \n" +
            "FROM\n" +
            "\tt_knowledge a\n" +
            "LEFT   JOIN t_knowledge b ON a.pid = b.pid\n" +
            "WHERE\n" +
            "\ta.knowledge_id = #{id} and  a.pid > 0")
    String getEqPidKnowledgeIdsById(@Param("id") Integer id);
}
