package com.ruida.cloud.dao;

import com.ruida.cloud.model.WeiduStudentRel;
import com.ruida.cloud.model.WeiduStudentRelExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface WeiduStudentRelMapper {
    long countByExample(WeiduStudentRelExample example);

    int deleteByExample(WeiduStudentRelExample example);

    int deleteByPrimaryKey(Integer rid);

    int insert(WeiduStudentRel record);

    int insertSelective(WeiduStudentRel record);

    List<WeiduStudentRel> selectByExample(WeiduStudentRelExample example);

    WeiduStudentRel selectByPrimaryKey(Integer rid);

    int updateByExampleSelective(@Param("record") WeiduStudentRel record, @Param("example") WeiduStudentRelExample example);

    int updateByExample(@Param("record") WeiduStudentRel record, @Param("example") WeiduStudentRelExample example);

    int updateByPrimaryKeySelective(WeiduStudentRel record);

    int updateByPrimaryKey(WeiduStudentRel record);


    int insertList(List<WeiduStudentRel> list);

    List<String> listWeiduStudentIds(Map filter);
}