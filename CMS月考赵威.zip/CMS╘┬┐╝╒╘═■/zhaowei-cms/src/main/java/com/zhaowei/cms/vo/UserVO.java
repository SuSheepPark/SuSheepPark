/**   
 * Copyright © 2019 公司名. All rights reserved.
 * 
 * @Title: UserVO.java 
 * @Prject: zhaowei-cms
 * @Package: com.zhaowei.cms.vo 
 * @Description: TODO
 * @author: zw   
 * @date: 2019年9月18日 下午7:08:44 
 * @version: V1.0   
 */
package com.zhaowei.cms.vo;

import com.zhaowei.cms.domain.User;

/** 
 * @ClassName: UserVO 
 * @Description: TODO
 * @author: zw
 * @date: 2019年9月18日 下午7:08:44  
 */
public class UserVO extends User {

	/**
	 * @fieldName: serialVersionUID
	 * @fieldType: long
	 * @Description: TODO
	 */
	private static final long serialVersionUID = 7492535830421708194L;

	private String repassword;

	public String getRepassword() {
		return repassword;
	}

	public void setRepassword(String repassword) {
		this.repassword = repassword;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	


	
	
	
}
