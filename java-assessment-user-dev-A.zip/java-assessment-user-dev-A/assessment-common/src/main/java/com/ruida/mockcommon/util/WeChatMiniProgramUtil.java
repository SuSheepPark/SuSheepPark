package com.ruida.mockcommon.util;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.ruida.mockcommon.constant.SystemConstant;

import java.util.HashMap;
import java.util.Map;

public class WeChatMiniProgramUtil {

    //WeChatMiniProgram 登录凭证校验
    private static final String wXGetUserInfoURL = "https://api.weixin.qq.com/sns/jscode2session";



    /**
     * 通过小程序登录code获取用户数据
     * @param code
     * @return
     */
    public static JSONObject getDataByWXCode(String code){
        Map<String, String> requestUrlParam = new HashMap<>();
        // 小程序appId
        requestUrlParam.put("appid", SystemConstant.AppID);
        // 小程序secret
        requestUrlParam.put("secret", SystemConstant.AppSecret);
        // 小程序端返回的code
        requestUrlParam.put("js_code", code);
        // 默认参数
        requestUrlParam.put("grant_type", "authorization_code");
        // 请求数据
        String result = HttpClientUtil.postMap(wXGetUserInfoURL, requestUrlParam);
        return JSON.parseObject(result);
    }


}
