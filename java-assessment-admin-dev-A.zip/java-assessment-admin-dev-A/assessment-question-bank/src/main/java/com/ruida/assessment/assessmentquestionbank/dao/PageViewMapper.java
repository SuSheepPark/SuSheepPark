package com.ruida.assessment.assessmentquestionbank.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.assessment.assessmentquestionbank.model.TPageView;
import org.apache.ibatis.annotations.Mapper;

/**
 * @description: 网站访问量数据库层接口
 * @author: kgz
 * @date: 2020/8/4
 */
@Mapper
public interface PageViewMapper extends BaseMapper<TPageView> {
}
