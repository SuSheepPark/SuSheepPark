package com.ruida.mockdao.vo.order;

import com.ruida.mockdao.vo.product.PaperReportVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * Created by xumingqi on 2021/7/1 8:37
 */
@Data
@ApiModel(value = "订单确认页信息")
public class OrderConfirmDetailVO {
    @ApiModelProperty(value = "商品id")
    Integer productId;

    @ApiModelProperty(value = "商品名")
    String productName;

    @ApiModelProperty(value = "总价(pc和安卓)")
    String totalPrice;

    @ApiModelProperty(value = "iOS总价")
    String totalIosPrice;

    @ApiModelProperty(value = "试卷份数")
    Integer paperNum;

    @ApiModelProperty(value = "报告份数")
    Integer reportNum;

    @ApiModelProperty(value = "试卷列表")
    List<PaperReportVO> paperList;

    @ApiModelProperty(value = "账户余额(ios学币专用)")
    String balance;
}
