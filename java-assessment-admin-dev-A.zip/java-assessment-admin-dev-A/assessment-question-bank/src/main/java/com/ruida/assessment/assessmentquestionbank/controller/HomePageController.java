package com.ruida.assessment.assessmentquestionbank.controller;

import com.ruida.assessment.assessmentcommon.result.PojoResult;
import com.ruida.assessment.assessmentquestionbank.annotaion.UserAuth;
import com.ruida.assessment.assessmentquestionbank.dto.BasicDataDTO;
import com.ruida.assessment.assessmentquestionbank.service.HomePageService;
import com.ruida.assessment.assessmentquestionbank.vo.BasicDataVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

/**
 * @description: 首页控制层
 * @author: kgz
 * @date: 2020/8/5
 */
@RequestMapping("/homePage")
@RestController
@Api(value ="首页相关接口")
public class HomePageController {
    @Resource
    private HomePageService homePageService;

    @UserAuth
    @PostMapping("/basicData")
    @ApiOperation(value = "基础数据", notes = "基础数据")
    public PojoResult getBasicData(){
        PojoResult pojoResult = new PojoResult();
        pojoResult.setContent(homePageService.getBasicData());
        return pojoResult;
    }

    @UserAuth
    @PostMapping("/trend")
    @ApiOperation(value = "交易趋势", notes = "交易趋势")
    @ApiImplicitParam(name = "basicDataDTO", value = "查询条件",
            required = true , dataType  = "BasicDataDTO",paramType = "body")
    public PojoResult getTradeTrendData(@RequestBody BasicDataDTO basicDataDTO){
        PojoResult pojoResult = new PojoResult();
        pojoResult.setContent(homePageService.getAmountTrendData(basicDataDTO));
        return pojoResult;
    }

    @UserAuth
    @PostMapping("/task")
    @ApiOperation(value = "待办事项", notes = "待办事项")
    public PojoResult getTask(){
        PojoResult pojoResult = new PojoResult();
        pojoResult.setContent(homePageService.getTask());
        return pojoResult;
    }
}
