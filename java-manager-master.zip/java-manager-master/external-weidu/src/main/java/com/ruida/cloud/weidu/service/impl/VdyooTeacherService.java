package com.ruida.cloud.weidu.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.ruida.cloud.dao.WeiduTeacherRelMapper;
import com.ruida.cloud.model.WeiduTeacherRel;
import com.ruida.cloud.weidu.config.WeiduConfig;
import com.ruida.cloud.weidu.dao.VdyooFactory;
import com.ruida.cloud.weidu.exception.VdyooException;
import com.ruida.cloud.weidu.service.BaseVdyooService;
import com.ruida.cloud.weidu.vo.VdyooEntity;
import com.ruida.common.context.BaseContextHandle;
import com.ruida.common.util.ValidateMT;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * 教学老师
 * 关联表字段：
 * *  睿达教师id     pid
 * *  威渡id         id
 * *  威渡校区id     departmentId   暂无
 * *  教师类型       teacherType    暂无
 *
 * @author taosh
 * @create 2019-04-22 16:18
 */
@Service
public class VdyooTeacherService extends BaseVdyooService {
    @Resource
    WeiduTeacherRelMapper weiduTeacherRelMapper;

    /**
     * 创建教师
     */
    @Transactional(rollbackFor = Exception.class)
    public boolean addTeacher(Map<String, Object> param) {

        boolean flag = false;
        VdyooEntity vdyooEntity = vdyooFactory.post(param, WeiduConfig.addTeacher);
        if (vdyooEntity.getSuccess()) {
            Integer id = null;
            try {
                JSONObject object = (JSONObject)JSON.toJSON(vdyooEntity.getPayload());
                WeiduTeacherRel teacherRel = new WeiduTeacherRel();
                teacherRel.setTeacherId(object.getInteger("pid"));
                teacherRel.setWeiduTeacherId(object.getInteger("id"));
                id = object.getInteger("id");
                teacherRel.setCreateBy(BaseContextHandle.getUserId());
                teacherRel.setCreateTime(new Date());
                teacherRel.setIsdelete((byte) 0);
                teacherRel.setUpdateBy(BaseContextHandle.getUserId());
                teacherRel.setUpdateTime(new Date());
                flag = weiduTeacherRelMapper.insert(teacherRel) > 0;
            } catch (Exception e) {
                if (ValidateMT.isNotNull(id)) {
                    this.deleteTeacherById(id);
                }
                throw new VdyooException("500","操作失败");
            }
        }
        return flag;
    }

    /**
     * 删除教师
     */
    public boolean deleteTeacherById(Integer id) {
        Map<String, Object> param = new HashMap<>();
        //威渡id
        param.put("id", id);
        return vdyooFactory.post(param, WeiduConfig.deleteTeacherById).getSuccess();
    }

    /**
     * 编辑教师信息
     */
    public boolean editTeacherById(Map<String, Object> param) {

        return vdyooFactory.post(param, WeiduConfig.editTeacherById).getSuccess();
    }

    /**
     * 通过教师威渡id查询教师信息
     */
//    public void findTeacherById(String teacherId){
//        Map<String, Object> param = new HashMap<>(1);
//        //威渡id
//        param.put("id", teacherId);
//        vdyooFactory.post(param, WeiduConfig.findTeacherById);
//    }

    /**
     * 查询所有信息
     */
    public VdyooEntity findAllTeacher(){
        return vdyooFactory.post(WeiduConfig.findAllTeacher);
    }

}
