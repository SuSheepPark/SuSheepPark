package com.ruida.common.enums;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Created by gongbin on 2018/3/1.
 */
public enum BoolStatusType {

    Enable("1","正常"),disable("0","停用");
    public static final String SOURCE_KEY = "BoolStatus";
    private String k;
    private String v;

    BoolStatusType(String k, String v) {
        this.k = k;
        this.v = v;
    }

    public static Map<String,String> map = new LinkedHashMap<>(2);
    static
    {
        for(BoolStatusType type : BoolStatusType.values())
        {
            map.put(type.getK(),type.getV());
        }
     }

    public String getK() {
        return k;
    }

    public void setK(String k) {
        this.k = k;
    }

    public String getV() {
        return v;
    }

    public void setV(String v) {
        this.v = v;
    }
}
