package com.ruida.cloud.model;

import java.io.Serializable;
import java.util.Date;

public class DiscountActivityItem implements Serializable {
    private Integer discountActivityItemId;

    private Integer discountActivityId;

    private Byte discountMethod;

    private Integer discountNum;

    private Byte rangeTypeOne;

    private Integer rangeNumOne;

    private Byte rangeTypeTwo;

    private Integer rangeNumTwo;

    private Integer createBy;

    private Date createTime;

    private Integer updateBy;

    private Date updateTime;

    private Byte isdelete;

    private static final long serialVersionUID = 1L;

    public Integer getDiscountActivityItemId() {
        return discountActivityItemId;
    }

    public void setDiscountActivityItemId(Integer discountActivityItemId) {
        this.discountActivityItemId = discountActivityItemId;
    }

    public Integer getDiscountActivityId() {
        return discountActivityId;
    }

    public void setDiscountActivityId(Integer discountActivityId) {
        this.discountActivityId = discountActivityId;
    }

    public Byte getDiscountMethod() {
        return discountMethod;
    }

    public void setDiscountMethod(Byte discountMethod) {
        this.discountMethod = discountMethod;
    }

    public Integer getDiscountNum() {
        return discountNum;
    }

    public void setDiscountNum(Integer discountNum) {
        this.discountNum = discountNum;
    }

    public Byte getRangeTypeOne() {
        return rangeTypeOne;
    }

    public void setRangeTypeOne(Byte rangeTypeOne) {
        this.rangeTypeOne = rangeTypeOne;
    }

    public Integer getRangeNumOne() {
        return rangeNumOne;
    }

    public void setRangeNumOne(Integer rangeNumOne) {
        this.rangeNumOne = rangeNumOne;
    }

    public Byte getRangeTypeTwo() {
        return rangeTypeTwo;
    }

    public void setRangeTypeTwo(Byte rangeTypeTwo) {
        this.rangeTypeTwo = rangeTypeTwo;
    }

    public Integer getRangeNumTwo() {
        return rangeNumTwo;
    }

    public void setRangeNumTwo(Integer rangeNumTwo) {
        this.rangeNumTwo = rangeNumTwo;
    }

    public Integer getCreateBy() {
        return createBy;
    }

    public void setCreateBy(Integer createBy) {
        this.createBy = createBy;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(Integer updateBy) {
        this.updateBy = updateBy;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Byte getIsdelete() {
        return isdelete;
    }

    public void setIsdelete(Byte isdelete) {
        this.isdelete = isdelete;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", discountActivityItemId=").append(discountActivityItemId);
        sb.append(", discountActivityId=").append(discountActivityId);
        sb.append(", discountMethod=").append(discountMethod);
        sb.append(", discountNum=").append(discountNum);
        sb.append(", rangeTypeOne=").append(rangeTypeOne);
        sb.append(", rangeNumOne=").append(rangeNumOne);
        sb.append(", rangeTypeTwo=").append(rangeTypeTwo);
        sb.append(", rangeNumTwo=").append(rangeNumTwo);
        sb.append(", createBy=").append(createBy);
        sb.append(", createTime=").append(createTime);
        sb.append(", updateBy=").append(updateBy);
        sb.append(", updateTime=").append(updateTime);
        sb.append(", isdelete=").append(isdelete);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}