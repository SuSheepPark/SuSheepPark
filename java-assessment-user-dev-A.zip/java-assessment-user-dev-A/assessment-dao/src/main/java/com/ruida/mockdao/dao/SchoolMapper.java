package com.ruida.mockdao.dao;


import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.model.School;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * 学校信息表 Mapper 接口
 * </p>
 *
 * @author Bhj
 * @since 2020-07-13
 */
public interface SchoolMapper extends BaseMapper<School> {

    List<Map<String, Object>> listSchool(@Param("province") Integer province,
                                         @Param("city") Integer city, @Param("district") Integer district,
                                         @Param("searchName") String searchName);

    List<Map<String, Object>> listPeriodBySchoolId(Integer schoolId);

    List<Map<String, Object>> listStageByPeriod(Integer periodId);

    List<Map<String, Object>> listClassBySchoolStage(@Param("schoolId") Integer schoolId,@Param("stageId") Integer stageId);

    List<Map<String, Object>> listGradeBySchoolId(Integer schoolId);
}
