package com.ruida.assessment.assessmentquestionbank.service;

import com.baomidou.mybatisplus.service.IService;
import com.ruida.assessment.assessmentcommon.result.BaseResult;
import com.ruida.assessment.assessmentcommon.result.PojoResult;
import com.ruida.assessment.assessmentquestionbank.dto.ClassRequest;
import com.ruida.assessment.assessmentquestionbank.dto.ClassStuDTO;
import com.ruida.assessment.assessmentquestionbank.model.TClass;
import com.ruida.assessment.assessmentquestionbank.vo.ClassStuVO;
import com.ruida.assessment.assessmentquestionbank.vo.PeriodInfoVO;

import java.util.List;

/**
 * @author wy
 * @description
 * @date 2020/6/12  班级管理服务接口
 */

public interface IClassService extends IService<TClass> {

    /*
        查询学校班级列表
     */
    List<PeriodInfoVO> queryClassList(Integer schoolId);

    /*
        查询班级总数
     */
    Integer queryClassCount(Integer status);

    /*
        新增、编辑 班级
     */
    BaseResult saveClass(ClassRequest request);

    /*
       删除班级
     */
    BaseResult deleteClass(Integer classId);

    /**
     * 按学校升级班级学生
     * @param schoolIds
     * @return
     */
    PojoResult upRankBySchool(String schoolIds );

}
