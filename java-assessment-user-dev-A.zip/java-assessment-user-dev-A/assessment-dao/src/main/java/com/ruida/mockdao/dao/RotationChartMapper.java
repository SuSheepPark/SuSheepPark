package com.ruida.mockdao.dao;


import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.model.RotationChart;

/**
 * <p>
 * 轮播图表 Mapper 接口
 * </p>
 *
 * @author Bhj
 * @since 2020-07-10
 */
public interface RotationChartMapper extends BaseMapper<RotationChart> {

}
