package com.ruida.assessment.assessmentcommon.enums;

/**
 * @author xumingqi
 * @date 2021/2/25 10:14
 */
public enum QuestionnaireTypeEnum {
    SUBJECT(1, "科目兴趣测试"),
    MAJOR(2, "专业调查问卷"),
    JOB(3, "职业倾向测试");

    private Integer K;
    private String V;

    QuestionnaireTypeEnum(Integer k, String v) {
        K = k;
        V = v;
    }

    public Integer getK() {
        return K;
    }

    public void setK(Integer k) {
        K = k;
    }

    public String getV() {
        return V;
    }

    public void setV(String v) {
        V = v;
    }
}
