package com.ruida.mockdao.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.ruida.mockdao.model.*;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.poi.ss.formula.functions.T;

import java.util.List;

/**
 * <p>
 * 商品表 Mapper 接口
 * </p>
 *
 * @author jinhu
 * @since 2020-07-08
 */
public interface SelectDictionaryMapper extends BaseMapper<TQuestionDifficulty>{


    @Select("select * from t_question_difficulty where isdelete = 0 and status = 1")
    List<TQuestionDifficulty> getDifficultyList();


    @Select("select * from t_material_version where isdelete = 0 and status = 1")
    List<TMaterialVersion> getMaterialVersionList();


    @Select("select * from t_period where isdelete = 0 and status = 1")
    List<TPeriod> getPeriodList();

    @Select("select * from t_stage where isdelete = 0 and status = 1 and locate('2',`type`)")
    List<TStage> getStageList();

    @Select("select * from t_subject where isdelete = 0 and status = 1")
    List<TSubject> getSubjectList();

    @Select("select * from t_test_paper_type where isdelete = 0 and status = 1")
    List<TTestPaperType> getTestPaperTypeList();

    @Select("select * from t_test_type where isdelete = 0 and status = 1")
    List<TTestType> getTestTypeList();


    @Select("select * from t_grade where isdelete = 0 ${ew.getSqlSegment} ")
    List<TGrade> getStageListFromParam(@Param("ew") Wrapper<T> var1);

    @Select("select d.* FROM t_grade a \n" +
            "LEFT JOIN t_period b on a.period_id = b.id\n" +
            "LEFT JOIN t_period_subject_relation c on b.id = c.period_id\n" +
            "LEFT JOIN t_subject d on c.subject_id = d.id\n" +
            "WHERE a.grade_id = #{gradeId} \n" +
            "and b.isdelete = 0 \n" +
            "and d.isdelete = 0 \n" +
            "and c.isdelete = 0 \n" +
            "GROUP BY d.id")
    List<TSubject> getSubjectListByStage(@Param("gradeId") Integer gradeId);

    @Select("select DISTINCT t1.* from t_material_version t1 \n" +
            "left join t_material_version_period_subject_rel t2 on t1.id = t2.version_id\n" +
            "left join t_grade t3 on t2.period_id = t3.period_id\n" +
            "where t3.grade_id = #{gradeId} and t1.status = 1")
    List<TMaterialVersion> getMaterialVersionListByStage(@Param("gradeId") Integer gradeId);

    @Select("select DISTINCT t1.* from t_material_version t1 \n" +
            "left join t_material_version_period_subject_rel t2 on t1.id = t2.version_id\n" +
            "where t2.subject_id = #{subjectId} and t1.status = 1")
    List<TMaterialVersion> getMaterialVersionListBySubject(@Param("subjectId") Integer subjectId);


    @Select("select * from t_grade where isdelete = 0 and status = 1 ")
    List<TGrade> getGradeList();

    @Select("SELECT * FROM t_grade WHERE period_id = #{periodId} and status = 1 and isdelete = 0")
    List<TGrade> getSelectByPeriod(@Param("periodId") Integer periodId);

    @Select("select b.* FROM t_period_subject_relation a LEFT JOIN t_subject b on a.subject_id = b.id\n" +
            "WHERE a.isdelete = 0 and b.status = 1 and a.period_id = #{periodId} GROUP BY b.id")
    List<TSubject> getSubjectByPeriod(@Param("periodId")Integer periodId);
}
