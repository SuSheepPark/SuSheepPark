package com.ruida.mockdao.model;

import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 错题练习和试题关联表
 * </p>
 *
 * @author chenjy
 * @since 2020-10-16
 */
@TableName("t_error_practice_question_rel")
public class ErrorPracticeQuestionRel extends Model<ErrorPracticeQuestionRel> {

    private static final long serialVersionUID = 1L;

    /**
     * 关联id
     */
    @TableId(value = "rel_id", type = IdType.AUTO)
    private Integer relId;
    /**
     * 用户id
     */
    @TableField("user_id")
    private Integer userId;
    /**
     * 错题练习id
     */
    @TableField("practice_id")
    private Integer practiceId;
    /**
     * 试题id
     */
    @TableField("question_id")
    private String questionId;
    /**
     * 试题类型id
     */
    @TableField("question_type_id")
    private Integer questionTypeId;
    /**
     * 创建人
     */
    @TableField("create_by")
    private Integer createBy;
    /**
     * 创建时间
     */
    @TableField("create_time")
    private Date createTime;
    /**
     * 修改人
     */
    @TableField("update_by")
    private Integer updateBy;
    /**
     * 修改时间
     */
    @TableField("update_time")
    private Date updateTime;
    /**
     * 删除标志
     */
    private Integer isdelete;


    public Integer getRelId() {
        return relId;
    }

    public void setRelId(Integer relId) {
        this.relId = relId;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Integer getPracticeId() {
        return practiceId;
    }

    public void setPracticeId(Integer practiceId) {
        this.practiceId = practiceId;
    }

    public String getQuestionId() {
        return questionId;
    }

    public void setQuestionId(String questionId) {
        this.questionId = questionId;
    }

    public Integer getQuestionTypeId() {
        return questionTypeId;
    }

    public void setQuestionTypeId(Integer questionTypeId) {
        this.questionTypeId = questionTypeId;
    }

    public Integer getCreateBy() {
        return createBy;
    }

    public void setCreateBy(Integer createBy) {
        this.createBy = createBy;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(Integer updateBy) {
        this.updateBy = updateBy;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getIsdelete() {
        return isdelete;
    }

    public void setIsdelete(Integer isdelete) {
        this.isdelete = isdelete;
    }

    @Override
    protected Serializable pkVal() {
        return this.relId;
    }

    @Override
    public String toString() {
        return "ErrorPracticeQuestionRel{" +
        ", relId=" + relId +
        ", userId=" + userId +
        ", practiceId=" + practiceId +
        ", questionId=" + questionId +
        ", questionTypeId=" + questionTypeId +
        ", createBy=" + createBy +
        ", createTime=" + createTime +
        ", updateBy=" + updateBy +
        ", updateTime=" + updateTime +
        ", isdelete=" + isdelete +
        "}";
    }
}
