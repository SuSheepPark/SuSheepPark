package com.ruida.cloud.dao;

import com.ruida.cloud.model.SysRoleMenu;
import com.ruida.cloud.model.SysRoleMenuExample;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface SysRoleMenuMapper {
    int countByExample(SysRoleMenuExample example);

    int deleteByExample(SysRoleMenuExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(SysRoleMenu record);

    int insertSelective(SysRoleMenu record);

    List<SysRoleMenu> selectByExample(SysRoleMenuExample example);

    SysRoleMenu selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") SysRoleMenu record, @Param("example") SysRoleMenuExample example);

    int updateByExample(@Param("record") SysRoleMenu record, @Param("example") SysRoleMenuExample example);

    int updateByPrimaryKeySelective(SysRoleMenu record);

    int updateByPrimaryKey(SysRoleMenu record);


    @Select("select count(id) from sys_role_menu where role_id =#{roleId} and menu_id =#{menuId}")
    int selectCountBymenuIdAndRoleId(@Param("roleId") Integer roleId ,@Param("menuId") Integer menuId);

    @Delete("delete from sys_role_menu where role_id =#{roleId}  ")
    int deleteByByRoleId(@Param("roleId") Integer roleId );
}