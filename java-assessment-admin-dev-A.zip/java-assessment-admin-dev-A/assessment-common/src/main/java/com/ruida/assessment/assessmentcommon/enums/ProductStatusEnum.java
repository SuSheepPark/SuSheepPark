package com.ruida.assessment.assessmentcommon.enums;

/**
 * @description: 商品状态枚举类
 * @author: kgz
 * @date: 2020/6/9
 */
public enum ProductStatusEnum {
    DOWN(0,"下架"),
    UP(1,"上架"),
    DRAFT(2,"草稿"),
    CHECK(3,"待审核"),

    ;

    private Integer K;
    private String V;

    ProductStatusEnum(Integer k, String v) {
        K = k;
        V = v;
    }

    public Integer getK() {
        return K;
    }

    public void setK(Integer k) {
        K = k;
    }

    public String getV() {
        return V;
    }

    public void setV(String v) {
        V = v;
    }

    public static ProductStatusEnum getValueById(Integer K){
        if(K != null){
            for(ProductStatusEnum deleteStatusEnum : ProductStatusEnum.values() ){
                if(deleteStatusEnum.getK().equals(K)){
                    return  deleteStatusEnum;
                }
            }
        }
        return null;
    }

}
