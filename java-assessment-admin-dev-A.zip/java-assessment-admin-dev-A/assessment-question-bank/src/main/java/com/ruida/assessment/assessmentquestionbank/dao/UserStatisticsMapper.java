package com.ruida.assessment.assessmentquestionbank.dao;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * @description:
 * @author: kgz
 * @date: 2020/8/5
 */
@Mapper
public interface UserStatisticsMapper {
    /**
     * 获取付费用户数
     * @return
     * @param startTime
     * @param endTime
     * @param type
     * 付款用户类型，new-付款新用户，old-付款老用户，null默认所有付款用户
     */
    Integer getPaidUserCount(@Param("startTime") String startTime, @Param("endTime") String endTime, @Param("type") String type);

    /**
     * 获取今日活跃用户数
     * @return
     * @param startTime
     * @param endTime
     */
    Integer getActiveUserCount(@Param("startTime") String startTime, @Param("endTime") String endTime);

    /**
     * 获取下单用户数
     * @param startTime
     * @param endTime
     * @return
     */
    Integer getOrderUserCount(@Param("startTime") String startTime, @Param("endTime") String endTime);

    /**
     * 获取注册用户数
     * @param startTime
     * @param endTime
     * @return
     */
    Integer getRegisterCount(@Param("startTime") String startTime, @Param("endTime") String endTime);

    /**
     *
     * @param startTime
     * @param endTime
     * @param type
     * 付款用户类型，new-付款新用户，old-付款老用户，null默认所有付款用户
     * @return
     */
    Double getPayAmount(@Param("startTime") String startTime, @Param("endTime") String endTime, @Param("type") String type);

    /**
     * 未付款用户数
     * @param endTime
     * @return
     */
    Integer getNotPaidUserCount(@Param("endTime") String endTime);
}
