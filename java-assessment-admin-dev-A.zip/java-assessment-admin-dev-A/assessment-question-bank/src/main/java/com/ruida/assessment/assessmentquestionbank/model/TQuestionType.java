package com.ruida.assessment.assessmentquestionbank.model;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;

/**
 * @description: 题型数据库实体
 * @author: kgz
 * @date: 2020/6/9
 */
@TableName("t_question_type")
public class TQuestionType extends BaseColumn implements Serializable {

    private static final long serialVersionUID = -3225691455782124956L;

    /**
     * 题型id
     */
    @TableId
    private Integer id;

    /**
     * 题型名称
     */
    private String questionTypeName;

    /**
     * 状态（0—禁用；1—启用）
     */
    private String status;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getQuestionTypeName() {
        return questionTypeName;
    }

    public void setQuestionTypeName(String questionTypeName) {
        this.questionTypeName = questionTypeName;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "TQuestionTypeInfo{" +
                "id=" + id +
                ", questionTypeName='" + questionTypeName + '\'' +
                ", status='" + status + '\'' +
                super.toString() +
                '}';
    }
}
