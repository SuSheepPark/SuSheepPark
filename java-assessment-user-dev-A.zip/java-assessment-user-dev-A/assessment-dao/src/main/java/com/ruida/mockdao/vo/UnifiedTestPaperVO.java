package com.ruida.mockdao.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.util.Date;

/**
 * @description: 统考试卷VO
 * @author: chenjy
 * @create: 2020-09-25 13:46
 */
@Data
public class UnifiedTestPaperVO {

    private String productId;

    private String productName;

    private String testPaperId;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",locale = "zh",timezone = "GMT+8")
    private Date testStartTime;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",locale = "zh",timezone = "GMT+8")
    private Date testEndTime;

    private boolean canTest;
}
