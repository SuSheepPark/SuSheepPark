package com.ruida.mockdao.vo.report;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.List;

/**
 * @description: 历次学校组织测试成绩情况VO
 * @author: kgz
 * @date: 2020/12/24
 */
@ApiModel(description = "历次学校组织测试成绩情况VO")
public class HisSchoolSubjectScoreInfoVO {

    @ApiModelProperty(value = "科目id", name = "subjectId")
    private Integer subjectId;

    @ApiModelProperty(value = "科目名称", name = "subjectName")
    private String subjectName;

    @ApiModelProperty(value = "得分", name = "score")
    private Double score;

    @ApiModelProperty(value = "学校排名", name = "schoolRank")
    private Integer schoolRank;

    @ApiModelProperty(value = "测试人数", name = "schoolNum")
    private Integer schoolNum;

    @ApiModelProperty(value = "得分在本校的百分位", name = "schoolScorePercent")
    private String schoolScorePercent;

    @ApiModelProperty(value = "年级得分情况", name = "stageScore")
    private List<StageScoreVO> stageScore;

    public Integer getSubjectId() {
        return subjectId;
    }

    public void setSubjectId(Integer subjectId) {
        this.subjectId = subjectId;
    }

    public String getSubjectName() {
        return subjectName;
    }

    public void setSubjectName(String subjectName) {
        this.subjectName = subjectName;
    }

    public Double getScore() {
        return score;
    }

    public void setScore(Double score) {
        this.score = score;
    }

    public Integer getSchoolRank() {
        return schoolRank;
    }

    public void setSchoolRank(Integer schoolRank) {
        this.schoolRank = schoolRank;
    }

    public Integer getSchoolNum() {
        return schoolNum;
    }

    public void setSchoolNum(Integer schoolNum) {
        this.schoolNum = schoolNum;
    }

    public String getSchoolScorePercent() {
        return schoolScorePercent;
    }

    public void setSchoolScorePercent(String schoolScorePercent) {
        this.schoolScorePercent = schoolScorePercent;
    }

    public List<StageScoreVO> getStageScore() {
        return stageScore;
    }

    public void setStageScore(List<StageScoreVO> stageScore) {
        this.stageScore = stageScore;
    }
}
