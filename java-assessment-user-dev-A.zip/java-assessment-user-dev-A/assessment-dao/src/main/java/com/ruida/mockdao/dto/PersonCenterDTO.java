package com.ruida.mockdao.dto;

import lombok.Data;

/**
 * @description: 个人中心请求参数DTO
 * @author: chenjy
 * @create: 2020-07-23 09:10
 */
@Data
public class PersonCenterDTO {

    /**
     * 用户id
     */
    private Integer userId;

    /**
     * 科目id
     */
    private Integer subjectId;

    /**
     * 关键字
     */
    private String keyword;

    /**
     * 题型
     */
    private Integer questionType;

    /**
     * 知识点id
     */
    private Integer knowledgeId;

    /**
     * 分页相关
     */
    private Integer pageNo;

    private Integer pageStart;

    private Integer pageSize;

}
