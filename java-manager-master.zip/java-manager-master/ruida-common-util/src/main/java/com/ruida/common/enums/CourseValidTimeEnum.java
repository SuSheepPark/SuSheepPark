package com.ruida.common.enums;

import java.util.LinkedHashMap;
import java.util.Map;

public enum CourseValidTimeEnum {
    onemonth("0","1个月", 1),
    threemonth("1","3个月", 3),
    sixmonth("2","6个月", 6),
    ninemonth("3","9个月", 9),
    twelvemonth("4","12个月", 12),
    twoyear("5","2年", 24),
    threeyear("6","3年", 36),
    unlimited("7","无限期", 0);

    public static final String SOURCE_KEY = "CourseValidTimeEnum";

    private String k;
    private String v;
    private int month;

    CourseValidTimeEnum(String k, String v, int month) {
        this.k = k;
        this.v = v;
        this.month = month;
    }

    public static Map<String,String> map = new LinkedHashMap<>(2);
    static
    {
        for(CourseValidTimeEnum type : CourseValidTimeEnum.values())
        {
            map.put(type.getK(),type.getV());
        }
    }

    public String getK() {
        return k;
    }

    public void setK(String k) {
        this.k = k;
    }

    public String getV() {
        return v;
    }

    public void setV(String v) {
        this.v = v;
    }

    public int getMonth() {
        return month;
    }

    public void setMonth(int month) {
        this.month = month;
    }
    /***
     * 根据k获取v的值
     * @param k
     * @return
     */
    public static String getvByk(String k) {
        CourseValidTimeEnum[] list = CourseValidTimeEnum.values();
        for (CourseValidTimeEnum valid : list) {
            if (valid.getK().equals(k)) {
                return valid.getV();
            }
        }
        return "";
    }
}
