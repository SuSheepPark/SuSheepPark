package com.ruida.assessment.assessmentquestionbank.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * @description: APP版本信息DTO
 * @author: kgz
 * @date: 2020/8/17
 */
@ApiModel(description = "APP版本信息")
public class AppVersionDTO {

    @ApiModelProperty(value = "Android版本信息", name = "AndroidVersion")
    private AppVersionDetailDTO AndroidVersion;

    @ApiModelProperty(value = "IOS版本信息", name = "IOS版本信息")
    private AppVersionDetailDTO IOSVersion;

    public AppVersionDetailDTO getAndroidVersion() {
        return AndroidVersion;
    }

    public void setAndroidVersion(AppVersionDetailDTO androidVersion) {
        AndroidVersion = androidVersion;
    }

    public AppVersionDetailDTO getIOSVersion() {
        return IOSVersion;
    }

    public void setIOSVersion(AppVersionDetailDTO IOSVersion) {
        this.IOSVersion = IOSVersion;
    }
}
