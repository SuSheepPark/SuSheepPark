package com.ruida.common.util;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import org.apache.commons.io.FileUtils;
import org.apache.http.*;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.CharArrayBuffer;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.net.*;
import java.nio.charset.Charset;
import java.util.*;


/**
 * @description: HTTP请求处理类
 * @author szl
 * @Date 2018年12月7日
 * @verion 1.0
 */
public class HttpClientUtil {
	private static Logger LOGGER = LoggerFactory
			.getLogger(HttpClientUtil.class);

	public static String doGet(String url) {
		String result = null;
		try {
			HttpClient httpClient = HttpClients.createDefault();
			// Get请求
			HttpGet httpget = new HttpGet(url);
			// 设置参数
			// 发送请求
			HttpResponse httpresponse = httpClient.execute(httpget);
			// 获取返回数据
			HttpEntity entity = httpresponse.getEntity();
			result = EntityUtils.toString(entity);
			if (entity != null) {
				EntityUtils.consume(entity);
			}
		} catch (ParseException e) {
			LOGGER.error(e.getMessage(), e);
		} catch (UnsupportedEncodingException e) {
			LOGGER.error(e.getMessage(), e);
		} catch (IOException e) {
			LOGGER.error(e.getMessage(), e);
		}
		return result;

	}

	public static String doPost(String url, List<NameValuePair> params) {
		String result = "";
		CloseableHttpClient httpclient = HttpClients.createDefault();

		try {
			HttpPost httpost = new HttpPost(url);
			httpost.setEntity(new UrlEncodedFormEntity(params, "utf-8"));
			HttpResponse response = httpclient.execute(httpost);
			HttpEntity entity = response.getEntity();
			result = EntityUtils.toString(entity, "UTF-8");
			EntityUtils.consume(entity);
		} catch (Exception e1) {

			e1.printStackTrace();
		} finally {

			try {
				httpclient.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		return result;

	}

	/**
	 * HTTP请求处理
	 * 
	 * @param url
	 * @param params
	 * @return
	 * @throws IOException
	 */
	public static String readContentFromGet(String url,
			Map<String, String> params) throws IOException {

		StringBuffer buffer_URL = new StringBuffer(url);
		Set<String> pas = params.keySet();
		List<String> list = new ArrayList<String>();
		list.addAll(pas);
		for (int i = 0; i < list.size(); i++) {
			String pa = list.get(i);
			String va = params.get(pa);
			if (i == 0) {
				buffer_URL.append("?").append(pa).append("=")
						.append(URLEncoder.encode(va, "utf-8"));
			} else {
				buffer_URL.append("&").append(pa).append("=")
						.append(URLEncoder.encode(va, "utf-8"));
			}
		}
		URL getUrl = new URL(buffer_URL.toString());
		HttpURLConnection connection = (HttpURLConnection) getUrl
				.openConnection();
		connection.connect();
		BufferedReader reader = new BufferedReader(new InputStreamReader(
				connection.getInputStream()));
		StringBuffer lines = new StringBuffer("");
		String string;
		while ((string = reader.readLine()) != null) {
			lines.append(string);
		}
		reader.close();
		connection.disconnect();
		return lines.toString();
	}

	public static String httpPostBody(String url, Object params) {
		String body = null;
		if (url != null && params != null) {
			HttpClient httpclient = HttpClientBuilder.create().build();;
			HttpPost httpost = httpPost(url, params.toString());
			HttpResponse response = null;
			try {
				response = httpclient.execute(httpost);
			} catch (ClientProtocolException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
			HttpEntity entity = response.getEntity();
			String charset = EntityUtils.getContentCharSet(entity);
			try {
				body = EntityUtils.toString(entity);
			} catch (ParseException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return body;
	}

	private static HttpPost httpPost(String url, Object params) {
		if (url != null && params != null) {
			HttpPost httpost = new HttpPost(url);
			List<NameValuePair> nvps = new ArrayList<NameValuePair>();
			if (params instanceof Map) {
				Map<String, String> paramsMap = (Map<String, String>) params;
				Set<String> keySet = paramsMap.keySet();
				for (String key : keySet) {
					nvps.add(new BasicNameValuePair(key, paramsMap.get(key)));
				}
				try {
					httpost.setEntity(new UrlEncodedFormEntity(nvps, "UTF-8"));
				} catch (UnsupportedEncodingException e) {
					e.printStackTrace();
				}
				return httpost;
			} else if (params instanceof String) {
				httpost.addHeader("Content-type",
						"application/json; charset=utf-8");
				httpost.setHeader("Accept", "application/json");
				httpost.setEntity(new StringEntity(params.toString(), Charset
						.forName("UTF-8")));
				return httpost;
			}
		}
		return null;
	}
	
	/**
	 * @description get请求
	 * @param url
	 * @param param
	 * @return
	 */
	public static String doGet(String url, Map<String, String> param) {

		// 创建Httpclient对象
		CloseableHttpClient httpclient = HttpClients.createDefault();
		String resultString = "";
		CloseableHttpResponse response = null;
		try {
			// 创建uri
			URIBuilder builder = new URIBuilder(url);
			if (param != null) {
				for (String key : param.keySet()) {
					builder.addParameter(key, param.get(key));
				}
			}
			URI uri = builder.build();
			// 创建http GET请求
			HttpGet httpGet = new HttpGet(uri);

			// 执行请求
			response = httpclient.execute(httpGet);
			// 判断返回状态是否为200
			if (response.getStatusLine().getStatusCode() == 200) {
				resultString = EntityUtils.toString(response.getEntity(), "UTF-8");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (response != null) {
					response.close();
				}
				httpclient.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return resultString;
	}
	
	/**
	 * @description 真对直播课重定向敏感信息暴漏解决的重定向
	 * @param url
	 * @param params
	 * @param response
	 * @throws IOException
	 */
	public static void redirect(String url, Map<String,String> params, HttpServletResponse response) throws IOException {
	    response.setContentType("text/html");
	    PrintWriter out = response.getWriter();
	    out.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">");
	    out.println("<HTML>");
	    out.println(" <HEAD><TITLE>sender</TITLE></HEAD>");
	    out.println(" <BODY>");
	    out.println("<form name=\"submitForm\" action=\""+url+"\" method=\"post\">");
	    Iterator<String> it=params.keySet().iterator();
	    while(it.hasNext()){
	        String key=it.next();
	        out.println("<input type=\"hidden\" name=\""+key+"\" value=\""+params.get(key)+"\"/>");
	    }
	    out.println("</from>");
	    out.println("<script>window.document.submitForm.submit();</script>");
	    out.println(" </BODY>");
	    out.println("</HTML>");
	    out.flush();
	    out.close();
	}

	/**
	 * 发送post请求，参数用map接收
	 * @param url 地址
	 * @param map 参数
	 * @return 返回值
	 */
	public static String postMap(String url,Map<String,String> map) {
		String result = null;
		CloseableHttpClient httpClient = HttpClients.createDefault();
		HttpPost post = new HttpPost(url);
		List<NameValuePair> pairs = new ArrayList<NameValuePair>();
		for(Map.Entry<String,String> entry : map.entrySet())
		{
			pairs.add(new BasicNameValuePair(entry.getKey(),entry.getValue()));
		}
		CloseableHttpResponse response = null;
		try {
			post.setEntity(new UrlEncodedFormEntity(pairs,"UTF-8"));
			response = httpClient.execute(post);
			if(response != null && response.getStatusLine().getStatusCode() == 200)
			{
				HttpEntity entity = response.getEntity();
				result = entityToString(entity);
			}
			return result;
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}finally {
			try {
				httpClient.close();
				if(response != null)
				{
					response.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}

		}
		return null;
	}

	/**
	 * post请求，参数为json字符串
	 * @param url 请求地址
	 * @param jsonString json字符串
	 * @return 响应
	 */
	public static String postJson(String url,String jsonString)
	{
		String result = null;
		CloseableHttpClient httpClient = HttpClients.createDefault();
		HttpPost post = new HttpPost(url);
		CloseableHttpResponse response = null;
		try {
			post.setEntity(new ByteArrayEntity(jsonString.getBytes("UTF-8")));
			response = httpClient.execute(post);
			if(response != null && response.getStatusLine().getStatusCode() == 200)
			{
				HttpEntity entity = response.getEntity();
				result = entityToString(entity);
			}
			return result;
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}finally {
			try {
				httpClient.close();
				if(response != null)
				{
					response.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return null;
	}

	private static String entityToString(HttpEntity entity) throws IOException {
		String result = null;
		if(entity != null)
		{
			long lenth = entity.getContentLength();
			if(lenth != -1 && lenth < 2048)
			{
				result = EntityUtils.toString(entity,"UTF-8");
			}else {
				InputStreamReader reader1 = new InputStreamReader(entity.getContent(), "UTF-8");
				CharArrayBuffer buffer = new CharArrayBuffer(2048);
				char[] tmp = new char[1024];
				int l;
				while((l = reader1.read(tmp)) != -1) {
					buffer.append(tmp, 0, l);
				}
				result = buffer.toString();
			}
		}
		return result;
	}

	public static String postForForm(String url, Map<String, String> parms) {
		HttpPost httpPost = new HttpPost(url);
		ArrayList<BasicNameValuePair> list = new ArrayList<>();
		parms.forEach((key, value) -> list.add(new BasicNameValuePair(key, value)));
		CloseableHttpClient httpClient = HttpClients.createDefault();
		try {
			if (Objects.nonNull(parms) && parms.size() >0) {
				httpPost.setEntity(new UrlEncodedFormEntity(list, "UTF-8"));
			}
			InputStream content = httpPost.getEntity().getContent();
			InputStreamReader inputStreamReader = new InputStreamReader(content, "UTF-8");
			BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
			String readLine = bufferedReader.readLine();
			String s = URLDecoder.decode(readLine, "UTF-8");
//			System.out.println("请求参数:s======" + s);
			HttpResponse response = httpClient.execute(httpPost);
			HttpEntity entity = response.getEntity();
			JSONObject jsonObject = JSON.parseObject(EntityUtils.toString(entity, "UTF-8"));

			return jsonObject.toString();
		}catch (IOException e) {
			e.printStackTrace();
		}finally {
			if (Objects.nonNull(httpClient)){
				try {
					httpClient.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return null;
	}

	public static void getimage(String url) throws IOException {
		CloseableHttpClient closeableHttpClient=HttpClients.createDefault(); //1、创建实例
		HttpGet httpGet=new HttpGet(url); //2、创建请求

		CloseableHttpResponse closeableHttpResponse=closeableHttpClient.execute(httpGet); //3、执行
		HttpEntity httpEntity=closeableHttpResponse.getEntity(); //4、获取实体

		if(httpEntity!=null){
			System.out.println("ContentType:"+httpEntity.getContentType().getValue());
			InputStream inputStream=httpEntity.getContent();
			FileUtils.copyInputStreamToFile(inputStream, new File("D://add.jpg")); //将图片保存在本次磁盘D盘，命名为xxx.png
		}

		closeableHttpResponse.close();
		closeableHttpClient.close();
	}

	/**
	 * 百家云上传视频
	 * @param url
	 * @param file
	 * @return
	 */
	public static String uploadBaijiayun(String url, MultipartFile file) {
		CloseableHttpClient httpclient = HttpClients.createDefault();
		String res = null;
		try {
			//MultipartFile转换成file
			File toFile = null;
			if (file.equals("") || file.getSize() <= 0) {
				file = null;
			} else {
				InputStream ins = null;
				ins = file.getInputStream();
				toFile = new File(file.getOriginalFilename());
				//FileUtils.copyInputStreamToFile(ins,toFile);
				inputStreamToFile(ins, toFile);
				ins.close();
			}
			HttpPost httppost = new HttpPost(url);
			FileBody bin = new FileBody(toFile);
			StringBody comment = new StringBody("A binary file of some kind", ContentType.TEXT_PLAIN);
			HttpEntity reqEntity = MultipartEntityBuilder.create().addPart("bin", bin).addPart("comment", comment).build();
			httppost.setEntity(reqEntity);
			CloseableHttpResponse response = httpclient.execute(httppost);
			try {
				HttpEntity resEntity = response.getEntity();
				res = entityToString(resEntity);
				EntityUtils.consume(resEntity);
			} finally {
				response.close();
			}
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				httpclient.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return res;
	}

	private static void inputStreamToFile(InputStream ins, File file) {
		try {
			OutputStream os = new FileOutputStream(file);
			int bytesRead = 0;
			byte[] buffer = new byte[8192];
			while ((bytesRead = ins.read(buffer, 0, 8192)) != -1) {
				os.write(buffer, 0, bytesRead);
			}
			os.close();
			ins.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
