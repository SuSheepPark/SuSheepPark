package com.ruida.assessment.assessmentquestionbank.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.assessment.assessmentquestionbank.dto.QueryBaseDTO;
import com.ruida.assessment.assessmentquestionbank.model.TMessageCustom;
import com.ruida.assessment.assessmentquestionbank.vo.MessageCustomVO;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * @description:
 * @author: kgz
 * @date: 2020/7/27
 */
@Mapper
public interface MessageCustomMapper extends BaseMapper<TMessageCustom> {
    /**
     * 分页查询消息列表
     * @param queryBaseDTO
     * @return
     */
    List<MessageCustomVO> getMessageCustomList(QueryBaseDTO queryBaseDTO);

    /**
     * 查询消息总数
     * @param queryBaseDTO
     * @return
     */
    int getMessageCustomCount(QueryBaseDTO queryBaseDTO);
}
