package com.ruida.cloud.model;

import lombok.Data;

import java.util.Date;

@Data
public class DoubleClassStudentRel {
    /**
     * 班级学生关联ID
     */
    private Integer id;

    /**
     * 班级ID
     */
    private Integer classId;

    /**
     * 学生ID
     */
    private Integer studentId;

    /**
     * 学生来源（0：校管家；1：本地创建）
     */
    private Byte source;

    /**
     * 创建者ID（关联user_id）
     */
    private Integer createBy;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新者ID（关联user_id）
     */
    private Integer updateBy;

    /**
     * 更新时间
     */
    private Date updateTime;

    /**
     * 是否删除（0：未删除；1：删除）
     */
    private Byte isdelete;

}