package com.ruida.assessment.assessmentquestionbank.imports.domain.service;

import com.ruida.assessment.assessmentquestionbank.imports.docx.DocxReader;
import com.ruida.assessment.assessmentquestionbank.imports.domain.model.ErrorMsgException;
import com.ruida.assessment.assessmentquestionbank.imports.domain.model.QuestionAnswer;
import com.ruida.assessment.assessmentquestionbank.imports.domain.model.QuestionBaseConfig;
import com.ruida.assessment.assessmentquestionbank.imports.domain.model.QuestionBlock;
import com.ruida.assessment.assessmentquestionbank.imports.domain.model.QuestionContent;
import com.ruida.assessment.assessmentquestionbank.imports.domain.model.QuestionExplain;
import com.ruida.assessment.assessmentquestionbank.imports.domain.model.QuestionKnowledge;
import com.ruida.assessment.assessmentquestionbank.imports.domain.model.QuestionRemark;

public class ChoiceQuestionProtocol extends QuestionProtocol {

	public ChoiceQuestionProtocol(DocxReader reader) {
		super(reader);
	}

	@Override
	public Boolean checkIdentification() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected QuestionContent getContent() {
		QuestionContent content = new QuestionContent();

		content.setContent(getContentString());

		content.setItems(getContentItems());
		return content;
	}

	@Override
	protected String formatAnswerItem(String lineString) {
		if (lineString.length() > 1) {
			lineString = lineString.substring(0,1);
		}
		byte[] bytes = lineString.getBytes();
		for (int i = 0; i < bytes.length; i++) {
			if (bytes[i] > 96 && bytes[i] < 123) {
				bytes[i] = (byte) (bytes[i] - 32);
			}
		}
		return new String(bytes);
	}

	@Override
	public QuestionBlock parseBlock(QuestionBaseConfig config) throws ErrorMsgException {
		reader.stepTo(CONTENT_START, QUESTION_START);
		QuestionBlock block = new QuestionBlock();

		QuestionContent content = getContent();
		block.setContent(content);

		QuestionAnswer answer = getAnswer(false);
		if (answer.getAnswerItems() == null) {
			throw new ErrorMsgException(reader.getLineNum(), "未能读取到题目的答案，请检查格式");
		}
		block.setAnswer(answer);

		QuestionExplain explain = getExplain();
		block.setExplain(explain);
		QuestionRemark remark = getRemark();
		block.setRemark(remark);
		QuestionKnowledge knowledge = getKnowledge();
		block.setKnowledge(knowledge);
		return block;
	}
}
