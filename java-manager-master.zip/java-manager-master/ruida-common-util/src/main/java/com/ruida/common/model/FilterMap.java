package com.ruida.common.model;

import java.util.HashMap;
import java.util.Map;

/**
 * 流式MAP
 * Created by gongbin on 2018/3/7.
 */
public class FilterMap extends HashMap<String,String> {

    public static FilterMap newMap()
    {
        return new FilterMap();
    }

    public FilterMap iput(String key, String value)
    {
        super.put(key, value);
        return this;
    }

    public FilterMap iputAll(Map<? extends String, ? extends String> m)
    {
        super.putAll(m);
        return this;
    }
    public FilterMap iremove(Object key)
    {
        super.remove(key);
        return this;
    }

}
