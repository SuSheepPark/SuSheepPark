package com.ruida.cloud.model;

import java.util.ArrayList;
import java.util.Date;

public class Ability {
    /**
     * 能力主键ID，自增长
     */
    private Integer abilityId;

    /**
     * 父ID
     */
    private Integer pid;

    /**
     * 能力名称
     */
    private String abilityName;

    /**
     * 学科ID
     */
    private Integer subjectId;

    /**
     * 学段ID
     */
    private Integer periodId;
    /**
     * 学科名字
     */
    private String subjectName;

    /**
     * 学段名字
     */
    private String periodName;

    /**
     * 能力级别
     */
    private Byte abilityLevel;

    /**
     * 能力排序
     */
    private Integer abilitySort;

    /**
     * 状态（0—禁用；1—启用）
     */
    private Byte status;

    /**
     * 创建者ID
     */
    private Integer createBy;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新者ID
     */
    private Integer updateBy;

    /**
     * 更新时间
     */
    private Date updateTime;

    /**
     * 是否删除（0：未删除；1：删除）
     */
    private Byte isdelete;


    /**
     * 子知识点
     */
    private ArrayList<Ability> children;
    /**
     * title
     */
    private String title;
    private Integer key;
    private Integer value;
    /**
     * 0 上移 1下一
     */
    private Integer sort;
    private  Integer isEditable;

    public Integer getKey() {
        return key;
    }

    public void setKey(Integer key) {
        this.key = key;
    }

    public Integer getValue() {
        return value;
    }

    public void setValue(Integer value) {
        this.value = value;
    }

    public String getSubjectName() {
        return subjectName;
    }

    public void setSubjectName(String subjectName) {
        this.subjectName = subjectName;
    }

    public String getPeriodName() {
        return periodName;
    }

    public void setPeriodName(String periodName) {
        this.periodName = periodName;
    }

    public Integer getisEditable() {
        return isEditable;
    }

    public void setisEditable(Integer iseditable) {
        isEditable = iseditable;
    }

    public Integer getSort() {
        return sort;
    }

    public void setSort(Integer sort) {
        this.sort = sort;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public ArrayList<Ability> getChildren() {
        return children;
    }

    public void setChildren(ArrayList<Ability> children) {
        this.children = children;
    }

    public Integer getAbilityId() {
        return abilityId;
    }

    public void setAbilityId(Integer abilityId) {
        this.abilityId = abilityId;
    }

    public Integer getPid() {
        return pid;
    }

    public void setPid(Integer pid) {
        this.pid = pid;
    }

    public String getAbilityName() {
        return abilityName;
    }

    public void setAbilityName(String abilityName) {
        this.abilityName = abilityName == null ? null : abilityName.trim();
    }

    public Integer getSubjectId() {
        return subjectId;
    }

    public void setSubjectId(Integer subjectId) {
        this.subjectId = subjectId;
    }

    public Integer getPeriodId() {
        return periodId;
    }

    public void setPeriodId(Integer periodId) {
        this.periodId = periodId;
    }

    public Byte getAbilityLevel() {
        return abilityLevel;
    }

    public void setAbilityLevel(Byte abilityLevel) {
        this.abilityLevel = abilityLevel;
    }

    public Integer getAbilitySort() {
        return abilitySort;
    }

    public void setAbilitySort(Integer abilitySort) {
        this.abilitySort = abilitySort;
    }

    public Byte getStatus() {
        return status;
    }

    public void setStatus(Byte status) {
        this.status = status;
    }

    public Integer getCreateBy() {
        return createBy;
    }

    public void setCreateBy(Integer createBy) {
        this.createBy = createBy;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(Integer updateBy) {
        this.updateBy = updateBy;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Byte getIsdelete() {
        return isdelete;
    }

    public void setIsdelete(Byte isdelete) {
        this.isdelete = isdelete;
    }
}