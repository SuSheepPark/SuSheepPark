package com.ruida.cloud.dao;

import com.ruida.cloud.model.CourseDiscountUser;
import com.ruida.cloud.model.CourseDiscountUserExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface CourseDiscountUserMapper {
    int countByExample(CourseDiscountUserExample example);

    int deleteByExample(CourseDiscountUserExample example);

    int deleteByPrimaryKey(Integer discountId);

    int insert(CourseDiscountUser record);

    int insertSelective(CourseDiscountUser record);

    List<CourseDiscountUser> selectByExample(CourseDiscountUserExample example);

    CourseDiscountUser selectByPrimaryKey(Integer discountId);

    int updateByExampleSelective(@Param("record") CourseDiscountUser record, @Param("example") CourseDiscountUserExample example);

    int updateByExample(@Param("record") CourseDiscountUser record, @Param("example") CourseDiscountUserExample example);

    int updateByPrimaryKeySelective(CourseDiscountUser record);

    int updateByPrimaryKey(CourseDiscountUser record);

    //批量新建
    int insertBatch(List<CourseDiscountUser> userList);
}