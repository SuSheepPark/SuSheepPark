package com.ruida.assessment.assessmentquestionbank.model;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;

/**
 * @description: 试题来源数据库实体
 * @author: kgz
 * @date: 2020/6/10
 */
@TableName("t_question_source")
public class TQuestionSource extends BaseColumn implements Serializable {
    private static final long serialVersionUID = -6728415947450978702L;

    /**
     * 试题来源id
     */
    @TableId
    private Integer id;

    /**
     * 试题来源名称
     */
    private String questionSourceName;

    /**
     * 状态（0—禁用；1—启用）
     */
    private String status;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getQuestionSourceName() {
        return questionSourceName;
    }

    public void setQuestionSourceName(String questionSourceName) {
        this.questionSourceName = questionSourceName;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "TQuestionSource{" +
                "id=" + id +
                ", questionSourceName='" + questionSourceName + '\'' +
                ", status='" + status + '\'' +
                super.toString() +
                '}';
    }
}
