package com.ruida.assessment.assessmentquestionbank.service;

import com.baomidou.mybatisplus.service.IService;
import com.ruida.assessment.assessmentcommon.result.BaseResult;
import com.ruida.assessment.assessmentquestionbank.dto.BottomInfoRequest;
import com.ruida.assessment.assessmentquestionbank.model.TBottomInfo;
import com.ruida.assessment.assessmentquestionbank.vo.BottomInfoVo;

/**
 * @author wy
 * @description
 * @date 2020/8/14  网站信息管理服务接口
 */

public interface IBottomInfoService extends IService<TBottomInfo> {

    /*
    查询网站信息
     */
    BottomInfoVo queryWebsiteInfo(Integer id);

    /*
    新增、编辑网站信息
     */
    BaseResult saveWebsiteInfo(BottomInfoRequest request);
}
