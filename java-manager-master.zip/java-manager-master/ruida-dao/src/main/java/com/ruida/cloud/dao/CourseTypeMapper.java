package com.ruida.cloud.dao;

import com.ruida.cloud.model.CourseType;
import com.ruida.cloud.model.CourseTypeExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface CourseTypeMapper {
    int countByExample(CourseTypeExample example);

    int deleteByExample(CourseTypeExample example);

    int deleteByPrimaryKey(Integer courseTypeId);

    int insert(CourseType record);

    int insertSelective(CourseType record);

    List<CourseType> selectByExample(CourseTypeExample example);

    CourseType selectByPrimaryKey(Integer courseTypeId);

    int updateByExampleSelective(@Param("record") CourseType record, @Param("example") CourseTypeExample example);

    int updateByExample(@Param("record") CourseType record, @Param("example") CourseTypeExample example);

    int updateByPrimaryKeySelective(CourseType record);

    int updateByPrimaryKey(CourseType record);
}