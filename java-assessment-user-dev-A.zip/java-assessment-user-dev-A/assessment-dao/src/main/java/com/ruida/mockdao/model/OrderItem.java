package com.ruida.mockdao.model;

import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * <p>
 * 订单详情表
 * </p>
 *
 * @author Bhj
 * @since 2020-07-23
 */
@TableName("t_order_item")
public class OrderItem extends Model<OrderItem> {

    private static final long serialVersionUID = 1L;

    /**
     * 订单详情主键ID
     */
    @TableId(value = "order_item_id", type = IdType.AUTO)
    private Integer orderItemId;
    /**
     * 订单ID
     */
    @TableField("order_id")
    private Integer orderId;
    /**
     * 商品ID（即商品的product_id）
     */
    @TableField("product_id")
    private Integer productId;

    /**
     * 报告id(t_test_paper_product_rel表的主键，非计算好的报告的id)
     */
    @TableField("report_id")
    private Integer reportId;

    /**
     * 商品名称
     */
    @TableField("product_name")
    private String productName;

    /**
     * 商品图片
     */
    @TableField("product_image")
    private String productImage;

    /**
     * 试卷id
     */
    @TableField("test_paper_id")
    private Integer testPaperId;

    /**
     * 是否预售试卷 0-正常试卷 1-预售试卷
     */
    @TableField("ispresell")
    private Integer ispresell;

    /**
     * 试卷名称
     */
    @TableField("test_paper_name")
    private String testPaperName;

    /**
     * 试卷价格
     */
    @TableField("test_paper_price")
    private BigDecimal testPaperPrice;

    /**
     * 试卷ios价格
     */
    @TableField("test_paper_ios_price")
    private BigDecimal testPaperIosPrice;

    /**
     * 报告价格
     */
    @TableField("report_price")
    private BigDecimal reportPrice;

    /**
     * 报告ios价格
     */
    @TableField("report_ios_price")
    private BigDecimal reportIosPrice;

    /**
     * 是否购买试卷
     */
    @TableField("buy_paper")
    private Integer buyPaper;

    /**
     * 是否购买报告
     */
    @TableField("buy_report")
    private Integer buyReport;

    @TableField("create_time")
    private Date createTime;

    @TableField("create_by")
    private Integer createBy;

    @TableField("update_time")
    private Date updateTime;

    @TableField("update_by")
    private Integer updateBy;

    @TableField("isdelete")
    private Integer isdelete;

    public Integer getReportId() {
        return reportId;
    }

    public void setReportId(Integer reportId) {
        this.reportId = reportId;
    }

    public Integer getOrderItemId() {
        return orderItemId;
    }

    public void setOrderItemId(Integer orderItemId) {
        this.orderItemId = orderItemId;
    }

    public Integer getOrderId() {
        return orderId;
    }

    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    public Integer getProductId() {
        return productId;
    }

    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductImage() {
        return productImage;
    }

    public void setProductImage(String productImage) {
        this.productImage = productImage;
    }

    public Integer getTestPaperId() {
        return testPaperId;
    }

    public void setTestPaperId(Integer testPaperId) {
        this.testPaperId = testPaperId;
    }

    public Integer getIspresell() {
        return ispresell;
    }

    public void setIspresell(Integer ispresell) {
        this.ispresell = ispresell;
    }

    public String getTestPaperName() {
        return testPaperName;
    }

    public void setTestPaperName(String testPaperName) {
        this.testPaperName = testPaperName;
    }

    public BigDecimal getTestPaperPrice() {
        return testPaperPrice;
    }

    public void setTestPaperPrice(BigDecimal testPaperPrice) {
        this.testPaperPrice = testPaperPrice;
    }

    public BigDecimal getTestPaperIosPrice() {
        return testPaperIosPrice;
    }

    public void setTestPaperIosPrice(BigDecimal testPaperIosPrice) {
        this.testPaperIosPrice = testPaperIosPrice;
    }

    public BigDecimal getReportPrice() {
        return reportPrice;
    }

    public void setReportPrice(BigDecimal reportPrice) {
        this.reportPrice = reportPrice;
    }

    public BigDecimal getReportIosPrice() {
        return reportIosPrice;
    }

    public void setReportIosPrice(BigDecimal reportIosPrice) {
        this.reportIosPrice = reportIosPrice;
    }

    public Integer getBuyPaper() {
        return buyPaper;
    }

    public void setBuyPaper(Integer buyPaper) {
        this.buyPaper = buyPaper;
    }

    public Integer getBuyReport() {
        return buyReport;
    }

    public void setBuyReport(Integer buyReport) {
        this.buyReport = buyReport;
    }

    @Override
    protected Serializable pkVal() {
        return this.orderItemId;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getCreateBy() {
        return createBy;
    }

    public void setCreateBy(Integer createBy) {
        this.createBy = createBy;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(Integer updateBy) {
        this.updateBy = updateBy;
    }

    public Integer getIsdelete() {
        return isdelete;
    }

    public void setIsdelete(Integer isdelete) {
        this.isdelete = isdelete;
    }

    @Override
    public String toString() {
        return "OrderItem{" +
                "orderItemId=" + orderItemId +
                ", orderId=" + orderId +
                ", productId=" + productId +
                ", reportId=" + reportId +
                ", productName='" + productName + '\'' +
                ", productImage='" + productImage + '\'' +
                ", testPaperId=" + testPaperId +
                ", ispresell=" + ispresell +
                ", testPaperName='" + testPaperName + '\'' +
                ", testPaperPrice=" + testPaperPrice +
                ", testPaperIosPrice=" + testPaperIosPrice +
                ", reportPrice=" + reportPrice +
                ", reportIosPrice=" + reportIosPrice +
                ", buyPaper=" + buyPaper +
                ", buyReport=" + buyReport +
                ", createTime=" + createTime +
                ", createBy=" + createBy +
                ", updateTime=" + updateTime +
                ", updateBy=" + updateBy +
                ", isdelete=" + isdelete +
                '}';
    }
}
