package com.ruida.cloud.model;

import java.io.Serializable;
import java.util.Date;

public class CourseLesson implements Serializable {
    private Integer courseLessonId;

    private String courseLessonSn;

    private String courseLessonName;

    private Integer broadcastRoomId;

    private Date startDate;

    private String startTime;

    private String endTime;

    private Integer courseGenseeId;

    private Integer courseVideoId;

    private String roomId;
    private String studentCode;

    private Integer teacherId;

    private Byte status;

    private Integer orderNum;

    private Integer createBy;

    private Date createTime;

    private Integer updateBy;

    private Date updateTime;

    private Byte isdelete;

    private static final long serialVersionUID = 1L;

    public String getRoomId() {
        return roomId;
    }

    public void setRoomId(String roomId) {
        this.roomId = roomId;
    }

    public String getStudentCode() {
        return studentCode;
    }

    public void setStudentCode(String studentCode) {
        this.studentCode = studentCode;
    }

    public Integer getCourseLessonId() {
        return courseLessonId;
    }

    public void setCourseLessonId(Integer courseLessonId) {
        this.courseLessonId = courseLessonId;
    }

    public String getCourseLessonSn() {
        return courseLessonSn;
    }

    public void setCourseLessonSn(String courseLessonSn) {
        this.courseLessonSn = courseLessonSn == null ? null : courseLessonSn.trim();
    }

    public String getCourseLessonName() {
        return courseLessonName;
    }

    public void setCourseLessonName(String courseLessonName) {
        this.courseLessonName = courseLessonName == null ? null : courseLessonName.trim();
    }

    public Integer getBroadcastRoomId() {
        return broadcastRoomId;
    }

    public void setBroadcastRoomId(Integer broadcastRoomId) {
        this.broadcastRoomId = broadcastRoomId;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime == null ? null : startTime.trim();
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime == null ? null : endTime.trim();
    }

    public Integer getCourseGenseeId() {
        return courseGenseeId;
    }

    public void setCourseGenseeId(Integer courseGenseeId) {
        this.courseGenseeId = courseGenseeId;
    }

    public Integer getCourseVideoId() {
        return courseVideoId;
    }

    public void setCourseVideoId(Integer courseVideoId) {
        this.courseVideoId = courseVideoId;
    }

    public Integer getTeacherId() {
        return teacherId;
    }

    public void setTeacherId(Integer teacherId) {
        this.teacherId = teacherId;
    }

    public Byte getStatus() {
        return status;
    }

    public void setStatus(Byte status) {
        this.status = status;
    }

    public Integer getOrderNum() {
        return orderNum;
    }

    public void setOrderNum(Integer orderNum) {
        this.orderNum = orderNum;
    }

    public Integer getCreateBy() {
        return createBy;
    }

    public void setCreateBy(Integer createBy) {
        this.createBy = createBy;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(Integer updateBy) {
        this.updateBy = updateBy;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Byte getIsdelete() {
        return isdelete;
    }

    public void setIsdelete(Byte isdelete) {
        this.isdelete = isdelete;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", courseLessonId=").append(courseLessonId);
        sb.append(", courseLessonSn=").append(courseLessonSn);
        sb.append(", courseLessonName=").append(courseLessonName);
        sb.append(", broadcastRoomId=").append(broadcastRoomId);
        sb.append(", startDate=").append(startDate);
        sb.append(", startTime=").append(startTime);
        sb.append(", endTime=").append(endTime);
        sb.append(", courseGenseeId=").append(courseGenseeId);
        sb.append(", courseVideoId=").append(courseVideoId);
        sb.append(", teacherId=").append(teacherId);
        sb.append(", status=").append(status);
        sb.append(", orderNum=").append(orderNum);
        sb.append(", createBy=").append(createBy);
        sb.append(", createTime=").append(createTime);
        sb.append(", updateBy=").append(updateBy);
        sb.append(", updateTime=").append(updateTime);
        sb.append(", isdelete=").append(isdelete);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}