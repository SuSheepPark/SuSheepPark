package com.ruida.mockdao.dao;

import com.ruida.mockdao.model.Knowledge;
import com.ruida.mockdao.vo.KnowledgeVO;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface KnowledgeMapper {

    List<KnowledgeVO> queryBizKnowledge(@Param("tableName") String tableName,@Param("userId") Integer userId);

    Knowledge selectById(Integer knowledgeId);

}
