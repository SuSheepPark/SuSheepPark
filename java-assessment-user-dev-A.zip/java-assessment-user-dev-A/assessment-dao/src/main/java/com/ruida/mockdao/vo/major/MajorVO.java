package com.ruida.mockdao.vo.major;

import lombok.Data;

/**
 * @author xumingqi
 * @date 2021/1/14 13:12
 */
@Data
public class MajorVO {
    String majorCode;
    String majorName;
    Boolean checked;//是否被选中
}
