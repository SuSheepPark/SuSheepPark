package com.ruida.mockservice.service.impl;


import com.aliyun.oss.OSS;
import com.ruida.mockcommon.redis.RedisManager;
import com.ruida.mockcommon.util.AliYunOSSUtil;
import com.ruida.mockcommon.util.ValidateMT;
import com.ruida.mockservice.service.AliyunOSSService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.io.IOException;
import java.io.InputStream;
import java.util.Map;

@Service
public class AliyunOSSServiceImpl implements AliyunOSSService {
    @Value("${aliyunOSS.endpoint}")
    private   String endpoint;
    @Value("${aliyunOSS.accessKeyId}")
    private   String accessKeyId;
    @Value("${aliyunOSS.accessKeySecret}")
    private  String accessKeySecret;
    @Value("${aliyunOSS.bucketName}")
    private  String bucketName;
    //stsbucket相关
    @Value("${aliyunOSS.stsBucketName}")
    private  String stsBucketName;
    @Value("${aliyunOSS.stsEndpoint}")
    private  String stsEndpoint;
    @Value("${aliyunOSS.stsAccessKeyId}")
    private  String stsAccessKeyId;
    @Value("${aliyunOSS.stsAccessKeySecret}")
    private  String stsAccessKeySecret;
    @Value("${aliyunOSS.roleArn}")
    private  String roleArn;
    //sts产品标识
    private static final   String stsProduct = "Sts";
    // 自定义角色会话名称，用来区分不同的令牌，例如可填写为SessionTest。
    private static final  String roleSessionName = "002";

    @Resource
    RedisManager redisManager;
    private static final Long timeout = 3590L;

    @Override
    public void uploadOpenBucket(InputStream inputStream, String fileName, String uploadPath) {
        AliYunOSSUtil.uploadOpenBucket(inputStream,fileName,uploadPath,AliYunOSSUtil.getOssClient(endpoint,accessKeyId,accessKeySecret),bucketName);
    }

    @Override
    public String getOpenUrl(String objectName) {
        return String.format("https://"+bucketName+"."+endpoint.substring(8)+"/%s",objectName);
    }

    @Override
    public String uploadPic(InputStream inputStream, String fileName) throws IOException {
        return AliYunOSSUtil.uploadPic(inputStream,fileName,AliYunOSSUtil.getOssClient(endpoint,accessKeyId,accessKeySecret),bucketName);
    }

    @Override
    public void stsUpload(InputStream inputStream, String fileName, String uploadPath) {
        AliYunOSSUtil.upload(inputStream,fileName,uploadPath,getStsOSSClient(),stsBucketName);
    }

    @Override
    public String getStsURL(String objectName) {

        return AliYunOSSUtil.getURL(objectName,getStsOSSClient(),stsBucketName);
    }

    @Override
    public String uploadFile(InputStream inputStream, String fileName) {
        return AliYunOSSUtil.uploadFile(inputStream,fileName,AliYunOSSUtil.getOssClient(endpoint,accessKeyId,accessKeySecret),bucketName);
    }

    /**
     * 获取sts临时凭证
     */
    private void getstsTicket() {
        Map<String, String> resultMap = AliYunOSSUtil.getTempTickey(stsEndpoint,stsAccessKeyId,stsAccessKeySecret,stsProduct,roleArn,roleSessionName);
        redisManager.set("STSKeyId",resultMap.get("KeyId"),RedisManager.OSS_MODULE,timeout);
        redisManager.set("STSKeySecret",resultMap.get("KeySecret"),RedisManager.OSS_MODULE,timeout);
        redisManager.set("STSSecurityToken",resultMap.get("SecurityToken"),RedisManager.OSS_MODULE,timeout);
    }

    /**
     * 获取sts形式的OSS实例
     * @return
     */
    private OSS getStsOSSClient(){
        //从redis获取缓存的oss临时凭证
        String keyId = redisManager.get("STSKeyId", RedisManager.OSS_MODULE);
        if (ValidateMT.isNull(keyId)) {
            getstsTicket();
            keyId = redisManager.get("STSKeyId", RedisManager.OSS_MODULE);
        }
        String keySecret = redisManager.get("STSKeySecret", RedisManager.OSS_MODULE);
        String securityToken = redisManager.get("STSSecurityToken", RedisManager.OSS_MODULE);
        return AliYunOSSUtil.getOssClient(stsEndpoint,keyId,keySecret,securityToken);
    }
}
