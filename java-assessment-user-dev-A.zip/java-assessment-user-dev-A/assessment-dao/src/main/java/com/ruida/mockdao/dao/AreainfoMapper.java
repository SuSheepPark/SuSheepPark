package com.ruida.mockdao.dao;


import com.ruida.mockdao.model.Areainfo;
import com.ruida.mockdao.model.AreainfoExample;

import java.util.List;

public interface AreainfoMapper {

    List<Areainfo> selectByExample(AreainfoExample example);

}
