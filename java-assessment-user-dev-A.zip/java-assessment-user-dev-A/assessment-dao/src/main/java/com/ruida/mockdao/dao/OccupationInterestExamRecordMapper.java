package com.ruida.mockdao.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.model.OccupationInterestExamRecord;

/**
 * <p>
 * 霍兰德职业兴趣答题卡以及报告 Mapper 接口
 * </p>
 *
 * @author 
 * @since 2021-02-05
 */
public interface OccupationInterestExamRecordMapper extends BaseMapper<OccupationInterestExamRecord> {

}
