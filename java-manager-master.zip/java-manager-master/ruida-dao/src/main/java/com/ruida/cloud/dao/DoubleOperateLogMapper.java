package com.ruida.cloud.dao;

import com.ruida.cloud.model.DoubleOperateLogRequest;
import com.ruida.cloud.model.TDoubleOperateLog;
import com.ruida.cloud.model.DoubleOperateLogExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface DoubleOperateLogMapper {
    int countByExample(DoubleOperateLogExample example);

    int deleteByExample(DoubleOperateLogExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(TDoubleOperateLog record);

    int insertSelective(TDoubleOperateLog record);

    List<TDoubleOperateLog> selectByExample(DoubleOperateLogExample example);

    TDoubleOperateLog selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") TDoubleOperateLog record, @Param("example") DoubleOperateLogExample example);

    int updateByExample(@Param("record") TDoubleOperateLog record, @Param("example") DoubleOperateLogExample example);

    int updateByPrimaryKeySelective(TDoubleOperateLog record);

    int updateByPrimaryKey(TDoubleOperateLog record);

    List<TDoubleOperateLog> getDoubleOperateLogList(@Param("vo") DoubleOperateLogRequest request);

    Long getDoubleOperateLogListCount(@Param("vo") DoubleOperateLogRequest request);
}