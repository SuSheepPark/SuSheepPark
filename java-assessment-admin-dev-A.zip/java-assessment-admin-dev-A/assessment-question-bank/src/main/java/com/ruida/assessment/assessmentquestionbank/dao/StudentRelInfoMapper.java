package com.ruida.assessment.assessmentquestionbank.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.assessment.assessmentquestionbank.model.TStudentRelInfo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author wy
 * @description 学生关联信息Mapper
 * @date 2020/7/27
 */
@Mapper
public interface StudentRelInfoMapper extends BaseMapper<TStudentRelInfo> {


    /*
    查询班级下所有考生关联信息(不包含虚拟考生)
     */
    List<TStudentRelInfo> queryStudentListByClassId( @Param("classId")Integer classId);

    /*
    查询班级下所有考生数(不包含虚拟考生)
     */
    Integer queryStudentCountByClassId( @Param("classId")Integer classId);

    /*
    查询学校下所有考生数(不包含虚拟考生)
     */
    Integer queryStudentCountBySchoolId( @Param("schoolId")Integer schoolId);
}
