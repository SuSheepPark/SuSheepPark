package com.ruida.cloud.model;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


@Data
public class DoubleCourseLessonDTO {

    /**
     * 自增主键 课程id
     */
    private Integer courseId;

    /**
     * 课程名称
     */
    private String courseName;

    /**
     * 课次数量
     */
    private Integer lessonNum;

    /**
     * 课程开始日期时间
     */
    private String startDateTime;

    /**
     * 课程开始时间
     */
    private String startTime;

    /**
     * 课程结束时间
     */
    private String endTime;

    /**
     * 开课的间隔天数
     */
    private Integer intervalDays;

    /**
     * 校区id
     */
    private String schoolId;

    /**
     * 校区名称
     */
    private String schoolName;

    /**
     * 主讲老师名称
     */
    private String teacherId;

    /**
     * 主讲老师名称
     */
    private String teacherName;

    /**
     * 授课教室id
     */
    private String teacherClassId;

    /**
     * 授课教室名称
     */
    private String teacherClassName;


    /**
     * 是否直播（0—关闭；1—开启）
     */
    private Byte islive;

    /**
     * 授课教室列表
     */
    private List<DoubleStudentClassRequest> doubleStudentClassList;


}
