package com.ruida.mockservice.service;

import com.ruida.mockdao.vo.QuestionVO;

import java.util.List;

/**
 * 考试试题详情
 */
public interface ExamQuestionLibraryDetailService {
    /**
     * 获取考试试题详情列表
     *
     * @param sceneId     场次id
     * @param questionIds 题号id列表
     * @return
     */
    List<QuestionVO> getQuestionDetailList(String sceneId, String questionIds);
}
