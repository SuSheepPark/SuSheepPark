package com.ruida.mockservice.service.impl;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.google.common.collect.Maps;
import com.ruida.mockcommon.auth.context.BaseContextHandle;
import com.ruida.mockcommon.auth.pojo.JWTInfo;
import com.ruida.mockcommon.constant.SystemConstant;
import com.ruida.mockcommon.enums.AnswerStatusEnum;
import com.ruida.mockcommon.enums.CorrectTypeEnum;
import com.ruida.mockcommon.enums.QuestionTypeEnum;
import com.ruida.mockcommon.exception.CoreException;
import com.ruida.mockcommon.result.Page;
import com.ruida.mockcommon.result.PageData;
import com.ruida.mockcommon.util.StringUtil;
import com.ruida.mockdao.dao.*;
import com.ruida.mockdao.dto.ErrorBookDTO;
import com.ruida.mockdao.model.*;
import com.ruida.mockdao.pojo.Choice;
import com.ruida.mockdao.vo.QueryScoreProductVO;
import com.ruida.mockdao.vo.UnifiedTestPaperVO;
import com.ruida.mockservice.service.*;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.*;
import java.util.concurrent.TimeUnit;

/**
 * @description: 考试接口实现类
 * @author: chenjy
 * @create: 2020-07-15 11:01
 */
@Service
@Slf4j
public class ExamServiceImpl implements ExamService {

    public static final String REG_EX = "</?[^>]+>";

    @Resource
    QuestionLibraryMapper questionLibraryMapper;
    @Resource
    TestNodeQuestionRelMapper testNodeQuestionRelMapper;
    @Resource
    ExamDetailMapper examDetailMapper;
    @Resource
    ExamRecordMapper examRecordMapper;
    @Resource
    KnowledgeMapper knowledgeMapper;
    @Resource
    SysUserMapper sysUserMapper;
    @Resource
    QuestionKnowledgeRelationMapper questionKnowledgeRelationMapper;
    @Resource
    QuestionAssessmentRelationMapper questionAssessmentRelationMapper;
    @Resource
    QuestionAssessmentTargetMapper questionAssessmentTargetMapper;
    @Resource
    StatAssessmentTargetUserRelMapper statAssessmentTargetUserRelMapper;
    @Resource
    StatKnowledgeUserRelService statKnowledgeUserRelService;
    @Resource
    ErrorBookService errorBookService;
    @Resource
    TestNodeQuestionRelService testNodeQuestionRelService;
    @Resource
    OrderMapper orderMapper;
    @Resource
    SysUserService sysUserService;
    @Resource
    RedisTemplate<String, Object> redisTemplate;
    @Resource
    ExamDetailService examDetailService;


    /**
     * 自动批改试卷
     *
     * @param examDetailList 答题记录
     * @param isSelfCheck    是否自主阅卷
     */
    @Override
    public List<ExamDetail> correct(List<ExamDetail> examDetailList, boolean isSelfCheck) {
        // 先处理非组合题
        examDetailList.stream().filter(x -> !x.getQuestionTypeId().equals(QuestionTypeEnum.CQT.getK())).forEach(examDetail -> {
            QuestionLibrary question = questionLibraryMapper.selectById(examDetail.getQuestionId());
            Double score = testNodeQuestionRelMapper.queryQuestionScore(examDetail.getTestPaperId(), examDetail.getQuestionId());

            //自主阅卷
            if (isSelfCheck) {
                //主观题(包括简答题和填空题)需要根据用户打分情况设置status
                if (QuestionTypeEnum.SAT.getK().equals(examDetail.getQuestionTypeId())
                        || QuestionTypeEnum.CT.getK().equals(examDetail.getQuestionTypeId())) {
                    if (examDetail.getScore() == null || BigDecimal.valueOf(examDetail.getScore()).compareTo(BigDecimal.ZERO) == 0) {
                        examDetail.setStatus(AnswerStatusEnum.WRONG.getK());
                    } else if (score.compareTo(examDetail.getScore()) == 0) {
                        examDetail.setStatus(AnswerStatusEnum.RIGHT.getK());
                    } else if (score.compareTo(examDetail.getScore()) > 0) {
                        examDetail.setStatus(AnswerStatusEnum.HRHW.getK());
                    }
                } else {
                    //客观题进行自动批改
                    correctObjectiveQuestion(examDetail, question, score);
                }
            } else {
                //主观题(简答题或是人工批阅的填空题)则设置为未批阅状态
                if (QuestionTypeEnum.SAT.getK().equals(examDetail.getQuestionTypeId())
                        || (QuestionTypeEnum.CT.getK().equals(examDetail.getQuestionTypeId())
                        && CorrectTypeEnum.MANUAL.getK().equals(question.getCorrectType()))) {
                    examDetail.setStatus(AnswerStatusEnum.UC.getK());
                } else {
                    //客观题进行自动批改
                    correctObjectiveQuestion(examDetail, question, score);
                }
            }

            operateErrorBook(examDetail);
            examDetailMapper.updateById(examDetail);
        });

        // 处理组合题
        examDetailList.stream().filter(x -> x.getQuestionTypeId().equals(QuestionTypeEnum.CQT.getK())).forEach(this::handleComposeQuestion);
        return examDetailList;
    }

    /**
     * 自动批改客观题题目（包括单选题、多选题、不定项选择题、判断题、自动批阅的填空题）
     */
    private void correctObjectiveQuestion(ExamDetail examDetail, QuestionLibrary question, Double score) {
        // 参考答案
        List<Choice> answer = JSON.parseArray(question.getAnswer(), Choice.class);

        // 用户给出的答案
        List<Choice> userAnswer = JSON.parseArray(examDetail.getAnswer(), Choice.class);

        // 没有作答的题目状态直接置为错误
        if (CollectionUtils.isEmpty(userAnswer)) {
            examDetail.setStatus(AnswerStatusEnum.WRONG.getK());
            examDetail.setScore(0.0);
        } else {
            if (answer.size() == 1) {
                if (userAnswer.size() != 0 && answer.get(0).getKey().equals(userAnswer.get(0).getKey())) {
                    if (answer.get(0).getVal().replaceAll(REG_EX, "").trim().equals(userAnswer.get(0).getVal().trim())) {
                        userAnswer.get(0).setStatus(AnswerStatusEnum.RIGHT.getK());
                        examDetail.setStatus(AnswerStatusEnum.RIGHT.getK());
                        examDetail.setScore(score);
                    } else {
                        //不定项选择题漏选
                        if (question.getQuestionTypeId().equals(QuestionTypeEnum.ICT.getK())
                                || question.getQuestionTypeId().equals(QuestionTypeEnum.MCT.getK())) {
                            String answerICT = answer.get(0).getVal().replaceAll(REG_EX, "").trim();
                            String userAnswerICT = userAnswer.get(0).getVal().trim();
                            if (StringUtil.isAcontainsEveryB(answerICT, userAnswerICT)) {
                                Double regressionScore = testNodeQuestionRelMapper.queryQuestionRegressionScore(examDetail.getTestPaperId(), examDetail.getQuestionId());
                                userAnswer.get(0).setStatus(AnswerStatusEnum.HRHW.getK());
                                examDetail.setStatus(AnswerStatusEnum.HRHW.getK());
                                if (regressionScore == null || regressionScore.equals(0.0)) {
                                    examDetail.setStatus(AnswerStatusEnum.WRONG.getK());
                                }
                                examDetail.setScore(regressionScore);
                            } else {
                                userAnswer.get(0).setStatus(AnswerStatusEnum.WRONG.getK());
                                examDetail.setStatus(AnswerStatusEnum.WRONG.getK());
                                examDetail.setScore(0.0);
                            }
                        } else {
                            userAnswer.get(0).setStatus(AnswerStatusEnum.WRONG.getK());
                            examDetail.setStatus(AnswerStatusEnum.WRONG.getK());
                            examDetail.setScore(0.0);
                        }
                    }
                }
            } else {
                int count = 0; // 记录答对题的数量
                for (int i = 0; i < userAnswer.size(); i++) {
                    if (answer.get(i).getKey().equals(userAnswer.get(i).getKey())) {
                        if (answer.get(i).getVal().replaceAll(REG_EX, "").trim().equals(userAnswer.get(i).getVal().trim())) {
                            userAnswer.get(i).setStatus(AnswerStatusEnum.RIGHT.getK());
                            count++;
                        } else {
                            userAnswer.get(i).setStatus(AnswerStatusEnum.WRONG.getK());
                        }
                    }
                }
                if (count == answer.size()) {
                    // 本道题所有的空都答对
                    examDetail.setStatus(AnswerStatusEnum.RIGHT.getK());
                    examDetail.setScore(score);
                } else if (count == 0) {
                    // 本道题所有的空都答错
                    examDetail.setStatus(AnswerStatusEnum.WRONG.getK());
                    examDetail.setScore(0.0);
                } else {
                    // 部分对、部分错
                    BigDecimal ratio = BigDecimal.valueOf(count).divide(BigDecimal.valueOf(answer.size()), 2, 4);
                    examDetail.setStatus(AnswerStatusEnum.HRHW.getK());
                    examDetail.setScore(ratio.doubleValue() * score);
                }
            }
            examDetail.setAnswer(userAnswer.size() == 0 ? null : JSON.toJSONString(userAnswer));
        }
    }

    private void operateErrorBook(ExamDetail e) {
        // 没有答对的题目加入错题本(只加入一级试题)
        if ((AnswerStatusEnum.WRONG.getK() == e.getStatus() || AnswerStatusEnum.HRHW.getK() == e.getStatus()) && e.getPid() == null) {
            QuestionLibrary question = questionLibraryMapper.selectById(e.getQuestionId());
            ErrorBookDTO errorBookDTO = new ErrorBookDTO();
            errorBookDTO.setExamRecordId(e.getExamRecordId());
            errorBookDTO.setTestPaperId(e.getTestPaperId());
            errorBookDTO.setCreateBy(e.getCreateBy());
            errorBookDTO.setQuestionId(e.getQuestionId());
            errorBookDTO.setQuestionTypeId(question.getQuestionTypeId());
            errorBookDTO.setPeriodId(question.getPeriodId());
            errorBookDTO.setSubjectId(e.getSubjectId());
            errorBookService.addErrorBook(errorBookDTO);
        } else if (AnswerStatusEnum.RIGHT.getK() == e.getStatus()) {
            // 答对的题从错题题本中移除
            errorBookService.removeQuestionFromErrorBook(e.getQuestionId(),e.getCreateBy());
        }
    }

    private void handleComposeQuestion(ExamDetail examDetail){

        // 考试详情中该组合题下的子题
        EntityWrapper wrapper = new EntityWrapper();
        wrapper.andNew().eq("exam_record_id",examDetail.getExamRecordId())
                .eq("test_paper_id",examDetail.getTestPaperId())
                .eq("pid",examDetail.getQuestionId())
                .eq("create_by",examDetail.getCreateBy());
        List<ExamDetail> detailsList = examDetailMapper.selectList(wrapper);

        int status;
        if (detailsList.stream().allMatch(x -> x.getStatus() == AnswerStatusEnum.RIGHT.getK())) {
            // 子题全对，父题才对
            status = AnswerStatusEnum.RIGHT.getK();
        } else if (detailsList.stream().anyMatch(x -> x.getStatus() == AnswerStatusEnum.UC.getK())) {
            // 子题存在一个未批的，父题的状态就是未批
            status = AnswerStatusEnum.UC.getK();
        } else if (detailsList.stream().allMatch(x -> x.getStatus() == AnswerStatusEnum.WRONG.getK())) {
            // 子题全错，父题才错
            status = AnswerStatusEnum.WRONG.getK();
        } else {
            // 其他情况，父题是半对半错
            status = AnswerStatusEnum.HRHW.getK();
        }

        examDetail.setStatus(status);
        // 计算组合题分数
        examDetail.setScore(detailsList.stream().map(ExamDetail::getScore).reduce(Double::sum).get());

        operateErrorBook(examDetail);

        examDetailMapper.updateById(examDetail);
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public boolean handleQuestionStats(Integer recordId) {
        String redisKey = String.format(SystemConstant.STAT_KEY,recordId);
        if(Boolean.TRUE.equals(redisTemplate.hasKey(redisKey))){
            return true;
        }
        try {
            ExamRecord record = examRecordMapper.selectById(recordId);
            Integer studentId = sysUserMapper.selectStuIdByUserId(record.getCreateBy());
            List<ExamDetail> detailList = examDetailMapper.selectList(new EntityWrapper<ExamDetail>().eq("exam_record_id",recordId));

            Map<Integer,AssessmentDTO> assessmentMap = Maps.newHashMap();

            detailList.forEach(x -> {

                //试题知识点信息
                List<QuestionKnowledgeRelation> questionKnowledgeRelationList = questionKnowledgeRelationMapper.selectList(new EntityWrapper<QuestionKnowledgeRelation>()
                        .eq("question_library_id",x.getQuestionId()));

                //试题考察要求信息
                List<QuestionAssessmentRelation> questionAssessmentRelationList = questionAssessmentRelationMapper.selectList(new EntityWrapper<QuestionAssessmentRelation>().eq("question_library_id", x.getQuestionId()));

                TestNodeQuestionRel rel = testNodeQuestionRelService.selectOne(new EntityWrapper<TestNodeQuestionRel>()
                        .eq("test_paper_id",record.getTestPaperId())
                        .eq("question_id",x.getQuestionId()));

                int knowledgeTotalWeight = questionKnowledgeRelationList.stream().mapToInt(QuestionKnowledgeRelation::getKnowledgePoints).sum();
                //log.info("试题编号：{},知识点权重{}",x.getQuestionId(),weight);
                questionKnowledgeRelationList.forEach(r -> {

                    double knowledgeFullScore = (float) r.getKnowledgePoints()/knowledgeTotalWeight*rel.getScore();
                    double knowledgeRealScore = (float) r.getKnowledgePoints()/knowledgeTotalWeight*x.getScore();
                    //log.info("试题：{},分配到满分的分值：{}",x.getQuestionId(),knowledgeFullScore);
                    //log.info("试题：{},分配到得分的分值：{}",x.getQuestionId(),knowledgeRealScore);

                    // 末级知识点
                    StatKnowledgeUserRel t;
                    EntityWrapper<StatKnowledgeUserRel> wrapper = new EntityWrapper<>();
                    wrapper.eq("exam_record_id",recordId).eq("knowledge_id",r.getKnowledgeId());
                    t = statKnowledgeUserRelService.selectOne(wrapper);
                    if(t == null){
                        t = new StatKnowledgeUserRel();
                        Knowledge knowledge = knowledgeMapper.selectById(r.getKnowledgeId());
                        t.setExamRecordId(recordId);
                        t.setUserId(record.getCreateBy());
                        t.setStuId(studentId);
                        t.setCreateBy(record.getCreateBy());
                        t.setCreateTime(new Date());
                        t.setKnowledgeId(r.getKnowledgeId());
                        t.setKnowledgeName(knowledge.getKnowledgeName());
                        t.setFullScore((float) r.getKnowledgePoints()/knowledgeTotalWeight*rel.getScore());
                        t.setRealScore((float) r.getKnowledgePoints()/knowledgeTotalWeight*x.getScore());
                        statKnowledgeUserRelService.insert(t);
                    }else {
                        t.setFullScore(t.getFullScore() + knowledgeFullScore);
                        t.setRealScore(t.getRealScore() + knowledgeRealScore);
                        t.setUpdateBy(record.getCreateBy());
                        t.setUpdateTime(new Date());
                        statKnowledgeUserRelService.updateById(t);
                    }

                    recursiveKnowledge(t,knowledgeFullScore,knowledgeRealScore); // 递归插入/更新父级知识点信息

                });

                //处理考察要求
                int assessmentTotalWeight = questionAssessmentRelationList.stream().mapToInt(QuestionAssessmentRelation::getAssessmentPoints).sum();
                questionAssessmentRelationList.forEach(e ->{

                    Integer assessmentId = e.getAssessmentId();

                    double assessmentFullScore = (float) e.getAssessmentPoints() / assessmentTotalWeight * rel.getScore();
                    double assessmentRealScore = (float) e.getAssessmentPoints() / assessmentTotalWeight * x.getScore();
//                    log.info("考察要求id：{},分配到试题：{},满分的分值：{}",assessmentId,x.getQuestionId(),assessmentFullScore);
//                    log.info("考察要求id：{},分配到试题：{},得分的分值：{}",assessmentId,x.getQuestionId(),assessmentRealScore);

                    AssessmentDTO dto;
                    if(assessmentMap.containsKey(assessmentId)){
                        dto = assessmentMap.get(assessmentId);
                        dto.setFullScore(dto.getFullScore().add(new BigDecimal(String.valueOf(assessmentFullScore))));
                        dto.setRealScore(dto.getRealScore().add(new BigDecimal(String.valueOf(assessmentRealScore))));
                    }else {
                        dto = new AssessmentDTO();
                        dto.setAssessmentId(assessmentId);
                        dto.setFullScore(new BigDecimal(String.valueOf(assessmentFullScore)));
                        dto.setRealScore(new BigDecimal(String.valueOf(assessmentRealScore)));
                    }
                    assessmentMap.put(assessmentId,dto);
                });

            });

            assessmentMap.forEach((k,v) -> {
                QuestionAssessmentTarget questionAssessmentTarget = questionAssessmentTargetMapper.selectById(k);
                StatAssessmentTargetUserRel rel = new StatAssessmentTargetUserRel();
                rel.setExamRecordId(recordId);
                rel.setUserId(record.getCreateBy());
                rel.setStuId(studentId);
                rel.setCreateBy(record.getCreateBy());
                rel.setCreateTime(new Date());
                rel.setAssessmentTargetId(k);
                rel.setAssessmentTargetName(questionAssessmentTarget.getQuestionAssessmentTargetName());
                rel.setFullScore(v.getFullScore().doubleValue());
                rel.setRealScore(v.getRealScore().doubleValue());
                statAssessmentTargetUserRelMapper.insert(rel);
            });

        }catch (Exception e){
            e.printStackTrace();
        }

        redisTemplate.opsForValue().set(redisKey, System.currentTimeMillis(),60 * 3, TimeUnit.SECONDS);

        log.info("id为:{}的考试记录，知识点和考察要求分值计算成功",recordId);
        return true;

    }

    private void recursiveKnowledge(StatKnowledgeUserRel t,double knowledgeFullScore,double knowledgeRealScore){
        Knowledge k = knowledgeMapper.selectById(t.getKnowledgeId());
        while (k.getPid() != 0){
            Knowledge p = knowledgeMapper.selectById(k.getPid());
            StatKnowledgeUserRel s;
            EntityWrapper wrapper = new EntityWrapper();
            wrapper.eq("exam_record_id",t.getExamRecordId()).eq("knowledge_id",p.getKnowledgeId());
            s = statKnowledgeUserRelService.selectOne(wrapper);
            if(s == null){
                s = new StatKnowledgeUserRel();
                s.setExamRecordId(t.getExamRecordId());
                s.setUserId(t.getUserId());
                s.setStuId(t.getStuId());
                s.setCreateBy(t.getCreateBy());
                s.setCreateTime(new Date());
                s.setKnowledgeId(p.getKnowledgeId());
                s.setKnowledgeName(p.getKnowledgeName());
                s.setFullScore(knowledgeFullScore);
                s.setRealScore(knowledgeRealScore);
                statKnowledgeUserRelService.insert(s);
            }else{
                s.setFullScore(s.getFullScore() + knowledgeFullScore);
                s.setRealScore(s.getRealScore() + knowledgeRealScore);
                s.setUpdateBy(t.getUserId());
                s.setUpdateTime(new Date());
                statKnowledgeUserRelService.updateById(s);
            }

            k = p;
        }
    }

    @Override
    public List<UnifiedTestPaperVO> listUnifiedTestPaper() {
        List<UnifiedTestPaperVO> list = orderMapper.listUnifiedTestPaper(getUserId());

        List<UnifiedTestPaperVO> tbr = new ArrayList<>();//待移除的元素

        //移除已经参加过考试的试卷信息
        list.forEach(vo -> {
            List<ExamRecord> recordList = examRecordMapper.selectList(new EntityWrapper<ExamRecord>()
                    .eq("product_id",vo.getProductId())
                    .eq("test_paper_id",vo.getTestPaperId())
                    .eq("status",0)
                    .eq("create_by",getUserId()));
            if(!CollectionUtils.isEmpty(recordList)){
                tbr.add(vo);
            }
        });

        list.removeAll(tbr);

        list.forEach(vo -> {
            boolean canTest = checkIfCanTest(vo.getTestStartTime());
            vo.setCanTest(canTest);
        });

        return list;
    }

    private String getUserId(){
        JWTInfo userInfo = BaseContextHandle.getJWTInfo();
        if(userInfo == null){
            return null;
        }
        return userInfo.getUserId();
    }

    private boolean checkIfCanTest(Date testStartTime){
        Calendar startTime = Calendar.getInstance();
        startTime.setTime(testStartTime);

        Calendar nowTime = Calendar.getInstance();
        nowTime.setTime(new Date());

        nowTime.add(Calendar.MINUTE,5);

        //已经开考和五分钟之内开考的试卷都可以去考试
        return startTime.before(nowTime) || startTime.before(nowTime);
    }

    @Override
    public List<QueryScoreProductVO> queryScore(String username) {
        SysUser user = sysUserService.checkUser(username);
        if(user == null){
            throw new CoreException("500","请输入有效证件号");
        }
        return examRecordMapper.queryScore(user.getUserId(),null,null);
    }

    @Override
    public PageData<QueryScoreProductVO> queryMyScore(Page page) {
        PageData<QueryScoreProductVO> pageData = new PageData<>();
        pageData.setPageSize(page.getPageSize());
        pageData.setCurrentPage(page.getCurrentPage());
        String userId = BaseContextHandle.getJWTInfo().getUserId();
        List<QueryScoreProductVO> list = examRecordMapper.queryScore(Integer.valueOf(userId) ,page.getOffset(),page.getPageSize());
        Integer count = examRecordMapper.queryScoreCount(Integer.valueOf(userId));
        pageData.setRows(list);
        pageData.setTotal(count);
        return pageData;
    }

    @Data
    public static class AssessmentDTO{

        private Integer assessmentId;

        private BigDecimal fullScore;

        private BigDecimal realScore;
    }
}
