package com.ruida.assessment.assessmentquestionbank;

/**
 * 系统静态变量
 * @author Ciffer
 *
 */
public class SystemConstant {


	/**文件路径管理*/
	public  static final String OSS_TESTPAPER_PATH = "assessment/testPaper/";//主路径
	public  static final String OSS_NEWS_PATH = "assessment/news/";//新闻资讯路径
	public  static final String UPLOAD_ROOT = "/datadrive";//主路径
	public static final String CEPING_BASE_PATH = "/ruidaceping/upload";//项目路径
	public static final String COVER_PIC = CEPING_BASE_PATH + "/product/coverPic";//商品封面
	//	public  static final String DEFAULT_COVER_PIC = "/ruidaceping/upload/product/coverPic";//商品默认封面
	public static final String COVER_RICH = CEPING_BASE_PATH + "/product/richText";//商品富文本
	public static final String ANDROID_APK = CEPING_BASE_PATH + "/android";//安卓apk
	public static final String QUESTION_IMPORT_APK = CEPING_BASE_PATH + "/questionImport";//题库批量化导入
	public static final String DEFAULT_PASSWORD = "123456";
	public static final String DOWNLOAD_PROTOCAL = "application/x-download";
	public static final String UTF8 = "UTF-8";

	//商品默认封面图片路径 /datadrive/ruidaceping/upload/product/coverPic/default.png
	public static final String PRODUCT_DEFAULT_IMG = UPLOAD_ROOT + COVER_PIC + "/default.png";
	//商品编号起始字符串
	public static final String PRODUCT_ID_PREFIX = "P";
	public static final String TOKEN_KEY = "token_key:user:%s";
	public static final String WECHAT_TOKEN_KEY = "token_key:user_wx:%s";
	public static final String MD5_SALT = "8F4470DB788FB93DFAF8D91393155921";
	public static final Integer DEFAULT_PAGE_SIZE = 10;
	public static final String TIME_ZONE = "GMT+8";
	//订单编号前缀
	public static final String ORDER_PREFIX = "DEV";
	public static final String MAX_DATETIME = "2099-12-31 00:00:00";

	//前端AES加密密钥
	public static final String AES_SECRET_KEY = "750EAD44034E5FEC";

}
