package com.ruida.assessment.assessmentcommon.enums;

/**
 * @description: 是否赠送报告枚举类
 * @author: wy
 * @date: 2021/7/2
 */
public enum PresentReportEnum {
    NO_PRESENT(0,"不赠送"),
    PRESENT(1,"赠送"),
    ;

    private Integer K;
    private String V;

    PresentReportEnum(Integer k, String v) {
        K = k;
        V = v;
    }

    public Integer getK() {
        return K;
    }

    public void setK(Integer k) {
        K = k;
    }

    public String getV() {
        return V;
    }

    public void setV(String v) {
        V = v;
    }

    public static PresentReportEnum getValueById(Integer K){
        if(K != null){
            for(PresentReportEnum deleteStatusEnum : PresentReportEnum.values() ){
                if(deleteStatusEnum.getK().equals(K)){
                    return  deleteStatusEnum;
                }
            }
        }
        return null;
    }

}
