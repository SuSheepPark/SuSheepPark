package com.ruida.common.enums;

import java.util.LinkedHashMap;
import java.util.Map;

public enum FindTypeEnum {

    OFFLINE(0,"线下双师"),
    RECORD(1,"录播课堂"),
    LIVE(2,"线上直播");

    private int k;
    private String v;

    FindTypeEnum(int k, String v) {
        this.k = k;
        this.v = v;
    }

    public static Map<Integer,String> map = new LinkedHashMap<>();

    static {
        for (FindTypeEnum findType : FindTypeEnum.values()){
            map.put(findType.getK(),findType.getV());
        }
    }

    public static String getValueByKey(int k) {
        FindTypeEnum[] arr = FindTypeEnum.values();
        for (FindTypeEnum item : arr) {
            if (item.getK() == k ) {
                return item.getV();
            }
        }
        return "";
    }

    public int getK() {
        return k;
    }

    public void setK(int k) {
        this.k = k;
    }

    public String getV() {
        return v;
    }

    public void setV(String v) {
        this.v = v;
    }

}
