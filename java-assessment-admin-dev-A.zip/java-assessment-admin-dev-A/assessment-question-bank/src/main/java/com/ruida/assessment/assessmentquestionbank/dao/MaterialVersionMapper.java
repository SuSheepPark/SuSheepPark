package com.ruida.assessment.assessmentquestionbank.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.assessment.assessmentquestionbank.dto.BaseFieldDTO;
import com.ruida.assessment.assessmentquestionbank.model.TMaterialVersion;
import com.ruida.assessment.assessmentquestionbank.vo.MaterialVersionVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @description:
 * @author: kgz
 * @date: 2020/6/29
 */
@Mapper
public interface MaterialVersionMapper extends BaseMapper<TMaterialVersion> {

    /**
     * 分页查询列表
     * @param baseFieldDTO
     * @return
     */
    List<MaterialVersionVO> queryList(@Param("baseFieldDTO") BaseFieldDTO baseFieldDTO,@Param("pNameOrSName") String pNameOrSName);

    /**
     * 列表数据条数
     * @return
     */
    Integer countQueryList(@Param("baseFieldDTO") BaseFieldDTO baseFieldDTO,@Param("pNameOrSName") String pNameOrSName);

    /**
     * 根据学科学段获取教材版本
     * @param periodId
     * @param subjectId
     * @return
     */
    List getListByPeriodSubjectId(Integer periodId, Integer subjectId);

}
