package com.ruida.mockservice.service;


import com.baomidou.mybatisplus.service.IService;
import com.ruida.mockcommon.result.PageData;
import com.ruida.mockdao.dto.ProductQueryRequest;
import com.ruida.mockdao.model.Product;
import com.ruida.mockdao.vo.HomeProductNewVO;
import com.ruida.mockdao.vo.HomeProductVO;
import com.ruida.mockdao.vo.ProductNewVO;
import com.ruida.mockdao.vo.ProductVO;

import javax.servlet.http.HttpServletResponse;
import java.io.UnsupportedEncodingException;
import java.util.List;

/**
 * <p>
 * 商品表 服务类
 * </p>
 *
 * @author jinhu
 * @since 2020-07-08
 */
public interface ProductService extends IService<Product> {

    Product getProductById(Integer productId);

    /**
     * 根据productType获取商品列表
     *
     * @param productType 0-试卷 1-套卷 2-职业兴趣问卷
     * @return
     */
    List<Product> getProductListByType(Integer productType);

    @Deprecated
    HomeProductVO getHomeProduct(Integer gradeId);
    @Deprecated
    HomeProductNewVO getHomeProductNew(Integer gradeId);
    /**
     * 因版本更新，首页的推荐商品接口不再使用上面两个。
     * 使用了新的表存储推荐商品。
     * 固定返回最多12个商品.不补齐
     * 
     * @return
     */
    List<ProductNewVO> getHomeProduct3();

    /*
     *功能描述  查询商品列表
     * @param
     * @return
     */
    PageData<ProductVO> queryProductList(ProductQueryRequest request);
    /*
     *功能描述  查询商品列表(新)
     * @param
     * @return
     */
    PageData<ProductNewVO> queryProductListNew(ProductQueryRequest request);
    /*
     * 列出推荐的商品信息
     * @param request
     * @return
     */
    PageData<ProductVO> queryRecommendProducts(ProductQueryRequest request);

    /*
     *功能描述  查询用户商品列表
     * @param
     * @return
     */
    PageData<ProductVO> queryUserProductList(ProductQueryRequest request);


    ProductVO getProductDetail(Integer productId);

    ProductNewVO getProductDetailNew(Integer productId);

    /**
     * 支付成功后 保存用户商品信息
     * 返回false 需要回滚当前操作
     * @param productId
     * @param userId
     * @return
     */
    boolean saveProductRelation(Integer productId, Integer userId);


    /**
     * 查询推荐列表
     * @param request
     * @return
     */
    PageData<ProductVO> queryRecommendProductList(ProductQueryRequest request);
    /**
     * 查询推荐列表
     * @param request
     * @return
     */
    PageData<ProductNewVO> queryRecommendProductListNew(ProductQueryRequest request);


    Integer getCachedProductIdByType(Integer productType);

	Object getMyProductDetail(Integer productId);

    /**
     * 下载试卷
     * @param testPaperId
     */
	String downloadTestPaper(Integer testPaperId);
}
