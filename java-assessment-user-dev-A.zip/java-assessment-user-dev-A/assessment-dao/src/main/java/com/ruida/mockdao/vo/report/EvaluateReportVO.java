package com.ruida.mockdao.vo.report;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * @description: 升学选拔报告详情
 * @author: kgz
 * @date: 2020/12/17
 */
public class EvaluateReportVO implements Serializable {
    /**
     * 试卷id
     */
    private Integer id;

    /**
     * 报告id
     */
    private Integer reportId;

    /**
     * 报告名称
     */
    private String reportName;

    /**
     * 用户id
     */
    private Integer userId;

    /**
     * 用户名称
     */
    private String userName;

    /**
     * 科目名称
     */
    private String subjectName;

    /**
     * 班级名称
     */
    private String className;

    /**
     * 学校名称
     */
    private String schoolName;

    /**
     * 本次测试成绩信息
     */
    private CurrentScoreInfoVO currentScoreInfo;

    /**
     * 历次测试成绩信息
     */
    private HisExamVO historyScoreInfo;

    /**
     * 历次学校测试成绩信息
     */
    private List<HisSchoolSubjectScoreInfoVO> historySchoolScoreInfo;

    private Integer createBy;

    private Date createTime;

    private Integer updateBy;

    private Date updateTime;

    private Integer isdelete;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getReportId() {
        return reportId;
    }

    public void setReportId(Integer reportId) {
        this.reportId = reportId;
    }

    public String getReportName() {
        return reportName;
    }

    public void setReportName(String reportName) {
        this.reportName = reportName;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getSubjectName() {
        return subjectName;
    }

    public void setSubjectName(String subjectName) {
        this.subjectName = subjectName;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public String getSchoolName() {
        return schoolName;
    }

    public void setSchoolName(String schoolName) {
        this.schoolName = schoolName;
    }

    public CurrentScoreInfoVO getCurrentScoreInfo() {
        return currentScoreInfo;
    }

    public void setCurrentScoreInfo(CurrentScoreInfoVO currentScoreInfo) {
        this.currentScoreInfo = currentScoreInfo;
    }

    public Integer getCreateBy() {
        return createBy;
    }

    public void setCreateBy(Integer createBy) {
        this.createBy = createBy;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(Integer updateBy) {
        this.updateBy = updateBy;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getIsdelete() {
        return isdelete;
    }

    public void setIsdelete(Integer isdelete) {
        this.isdelete = isdelete;
    }

    public HisExamVO getHistoryScoreInfo() {
        return historyScoreInfo;
    }

    public void setHistoryScoreInfo(HisExamVO historyScoreInfo) {
        this.historyScoreInfo = historyScoreInfo;
    }

    public List<HisSchoolSubjectScoreInfoVO> getHistorySchoolScoreInfo() {
        return historySchoolScoreInfo;
    }

    public void setHistorySchoolScoreInfo(List<HisSchoolSubjectScoreInfoVO> historySchoolScoreInfo) {
        this.historySchoolScoreInfo = historySchoolScoreInfo;
    }
}
