/**   
 * Copyright © 2019 公司名. All rights reserved.
 * 
 * @Title: AdminController.java 
 * @Prject: zhaowei-cms
 * @Package: com.zhaowei.cms.controller 
 * @Description: TODO
 * @author: zw   
 * @date: 2019年9月11日 下午4:02:19 
 * @version: V1.0   
 */
package com.zhaowei.cms.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/** 
 * @ClassName: AdminController 
 * @Description: 管理员后台
 * @author: zw
 * @date: 2019年9月11日 下午4:02:19  
 */
@RequestMapping("admin")
@Controller
public class AdminController {

	/**
	 * @Title: index 
	 * @Description: 进入管理员后台首页
	 * @return
	 * @return: String
	 */
	@RequestMapping(value={"index","/",""})
	public String index() {
		return "admin/index";
	}
	
}
