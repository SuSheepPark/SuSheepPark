package com.ruida.mockdao.model;

import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 考试详情表
 * </p>
 *
 * @author chenjy
 * @since 2020-07-17
 */
@TableName("t_exam_detail")
public class ExamDetail extends Model<ExamDetail> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键ID
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;
    /**
     * 考试记录ID
     */
    @TableField("exam_record_id")
    private Integer examRecordId;

    /**
     * 考生id
     */
    @TableField("stu_id")
    private Integer stuId;

    /**
     * 试卷ID
     */
    @TableField("test_paper_id")
    private Integer testPaperId;
    /**
     * 小节ID
     */
    @TableField("node_id")
    private Integer nodeId;
    /**
     * 父级试题ID（组合题使用）
     */
    private String pid;
    /**
     * 试题ID
     */
    @TableField("question_id")
    private String questionId;
    /**
     * 试题类型
     */
    @TableField("question_type_id")
    private Integer questionTypeId;
    /**
     * 音频已经的播放次数
     */
    @TableField("audio_play_count")
    private Integer audioPlayCount;
    /**
     * 科目
     */
    @TableField("subject_id")
    private Integer subjectId;
    /**
     * 用户答案
     */
    private String answer;
    /**
     * 图片id，多个用逗号隔开
     */
    @TableField("image_id")
    private String imageId;
    /**
     * 答题状态（1-答对；2-答错；3-半对半错；4-未批）
     */
    private Integer status;
    /**
     * 得分
     */
    private Double score;
    /**
     * 创建人
     */
    @TableField("create_by")
    private Integer createBy;
    /**
     * 创建时间
     */
    @TableField("create_time")
    private Date createTime;
    /**
     * 修改人
     */
    @TableField("update_by")
    private Integer updateBy;
    /**
     * 修改时间
     */
    @TableField("update_time")
    private Date updateTime;
    /**
     * 删除标志（0：未删除；1-已删除）
     */
    private Integer isdelete;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getExamRecordId() {
        return examRecordId;
    }

    public void setExamRecordId(Integer examRecordId) {
        this.examRecordId = examRecordId;
    }

    public Integer getTestPaperId() {
        return testPaperId;
    }

    public void setTestPaperId(Integer testPaperId) {
        this.testPaperId = testPaperId;
    }

    public Integer getStuId() {
        return stuId;
    }

    public void setStuId(Integer stuId) {
        this.stuId = stuId;
    }

    public Integer getNodeId() {
        return nodeId;
    }

    public void setNodeId(Integer nodeId) {
        this.nodeId = nodeId;
    }

    public String getPid() {
        return pid;
    }

    public void setPid(String pid) {
        this.pid = pid;
    }

    public String getQuestionId() {
        return questionId;
    }

    public void setQuestionId(String questionId) {
        this.questionId = questionId;
    }

    public Integer getQuestionTypeId() {
        return questionTypeId;
    }

    public void setQuestionTypeId(Integer questionTypeId) {
        this.questionTypeId = questionTypeId;
    }

    public Integer getAudioPlayCount() {
        return audioPlayCount;
    }

    public void setAudioPlayCount(Integer audioPlayCount) {
        this.audioPlayCount = audioPlayCount;
    }

    public Integer getSubjectId() {
        return subjectId;
    }

    public void setSubjectId(Integer subjectId) {
        this.subjectId = subjectId;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public String getImageId() {
        return imageId;
    }

    public void setImageId(String imageId) {
        this.imageId = imageId;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Double getScore() {
        return score;
    }

    public void setScore(Double score) {
        this.score = score;
    }

    public Integer getCreateBy() {
        return createBy;
    }

    public void setCreateBy(Integer createBy) {
        this.createBy = createBy;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(Integer updateBy) {
        this.updateBy = updateBy;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getIsdelete() {
        return isdelete;
    }

    public void setIsdelete(Integer isdelete) {
        this.isdelete = isdelete;
    }

    @Override
    protected Serializable pkVal() {
        return this.id;
    }

    @Override
    public String toString() {
        return "ExamDetail{" +
        ", id=" + id +
        ", examRecordId=" + examRecordId +
        ", testPaperId=" + testPaperId +
        ", nodeId=" + nodeId +
        ", pid=" + pid +
        ", questionId=" + questionId +
        ", questionTypeId=" + questionTypeId +
        ", audioPlayCount=" + audioPlayCount +
        ", subjectId=" + subjectId +
        ", answer=" + answer +
        ", imageId=" + imageId +
        ", status=" + status +
        ", score=" + score +
        ", createBy=" + createBy +
        ", createTime=" + createTime +
        ", updateBy=" + updateBy +
        ", updateTime=" + updateTime +
        ", isdelete=" + isdelete +
        "}";
    }
}
