package com.ruida.mockdao.vo.error;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

/**
 * @description: 错题练习记录VO
 * @author: chenjy
 * @create: 2020-10-21 08:41
 */
@Data
public class PracticeRecordVO {

    private Integer recordId;

    private String practiceName;

    private String periodName;

    private String subjectName;

    private Integer duration;

    private String rate;

    private Integer total;

    private Integer finished;

    @JsonFormat(pattern = "yyyy-MM-dd",locale = "zh",timezone = "GMT+8")
    private String createTime;
}
