/**   
 * Copyright © 2019 公司名. All rights reserved.
 * 
 * @Title: UserController.java 
 * @Prject: zhaowei-cms
 * @Package: com.zhaowei.cms.controller 
 * @Description: TODO
 * @author: zw   
 * @date: 2019年9月11日 上午10:47:53 
 * @version: V1.0   
 */
package com.zhaowei.cms.controller;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.github.pagehelper.PageInfo;
import com.zhaowei.cms.domain.User;
import com.zhaowei.cms.service.UserService;
import com.zhaowei.cms.util.PageUtil;

/** 
 * @ClassName: UserController 
 * @Description: 用户模块
 * @author: zw
 * @date: 2019年9月11日 上午10:47:53  
 */
@RequestMapping("user")
@Controller
public class UserController {

	@Resource
	private UserService userService;
	
	/**
	 * @Title: selects 
	 * @Description: 用户列表
	 * @param name
	 * @param page
	 * @param pageSize
	 * @return
	 * @return: String
	 */
	@RequestMapping("selects")
	public String selects(Model model,@RequestParam(defaultValue = "")String username,@RequestParam(defaultValue = "1")Integer page,@RequestParam(defaultValue = "3")Integer pageSize) {
		
		System.out.println("--------------------------");
		
		
		PageInfo<User> info = userService.selects(username,page,pageSize);
		String pages = PageUtil.page(page, info.getPages(), "/user/selects?username="+username, pageSize);
		model.addAttribute("users", info.getList());
		model.addAttribute("username", username);//封装查询条件
		model.addAttribute("pages", pages);//封装分页
		return "admin/users";
	}

	@ResponseBody
	@PostMapping("update")
	public boolean update(User user) {
		return userService.updateByPrimaryKeySelective(user)>0;
	}
	
}

