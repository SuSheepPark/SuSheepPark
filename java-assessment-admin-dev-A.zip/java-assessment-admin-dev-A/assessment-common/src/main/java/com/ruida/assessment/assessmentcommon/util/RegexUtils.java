package com.ruida.assessment.assessmentcommon.util;

import java.util.regex.Pattern;

public class RegexUtils {

        /**
        * 正则表达式：验证11位数字 ，只验证11位数字，验证手机号可不能用这个！！！！！！
        */
        public static final String REGEX_MOBILE = "^[0-9]{11}$";

        /**
        * 正则表达式：验证手机号
        */
        public static final String REGEX_TELEPHONE = "^[1]\\d{10}$";

        /**
        * 正则表达式：验证邮箱
        */
        public static final String REGEX_EMAIL = "^([a-z0-9A-Z]+[-|\\.]?)+[a-z0-9A-Z]@([a-z0-9A-Z]+(-[a-z0-9A-Z]+)?\\.)+[a-zA-Z]{2,}$";

        /**
        * 正则表达式：验证汉字
        */
        public static final String REGEX_CHINESE = "^[\u4e00-\u9fa5],{0,}$";

        /**
        * 正则表达式：验证身份证
        */
        public static final String REGEX_ID_CARD = "^([1-6][1-9]|50)\\d{4}(18|19|20)\\d{2}((0[1-9])|10|11|12)(([0-2][1-9])|10|20|30|31)\\d{3}[0-9Xx]$";

        /**
        * 正则表达式：验证URL
        */
        public static final String REGEX_URL = "http(s)?://([\\w-]+\\.)+[\\w-]+(/[\\w- ./?%&=]*)?";

        /**
        * 正则表达式：验证IP地址
        */
        public static final String REGEX_IP_ADDR = "(25[0-5]|2[0-4]\\d|[0-1]\\d{2}|[1-9]?\\d)";


    /**
     * 只验证11位数字，验证手机号可不能用这个！！！！！！
     * @param mobile
     * @return
     */
    public static boolean isMobile(String mobile) {
        return Pattern.matches(REGEX_MOBILE, mobile);
    }

    /**
     * 验证身份证
     * @param idCard
     * @return
     */
    public static boolean isIDCard(String idCard) {
        return Pattern.matches(REGEX_ID_CARD, idCard);
    }


    /**
     * 验证手机号
     * @param telephone
     * @return
     */
    public static boolean isTelephone(String telephone) {
        return Pattern.matches(REGEX_TELEPHONE, telephone);
    }

}
