package com.ruida.cloud.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class PromotionActivityCommissionExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public PromotionActivityCommissionExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andCommissionIdIsNull() {
            addCriterion("commission_id is null");
            return (Criteria) this;
        }

        public Criteria andCommissionIdIsNotNull() {
            addCriterion("commission_id is not null");
            return (Criteria) this;
        }

        public Criteria andCommissionIdEqualTo(Integer value) {
            addCriterion("commission_id =", value, "commissionId");
            return (Criteria) this;
        }

        public Criteria andCommissionIdNotEqualTo(Integer value) {
            addCriterion("commission_id <>", value, "commissionId");
            return (Criteria) this;
        }

        public Criteria andCommissionIdGreaterThan(Integer value) {
            addCriterion("commission_id >", value, "commissionId");
            return (Criteria) this;
        }

        public Criteria andCommissionIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("commission_id >=", value, "commissionId");
            return (Criteria) this;
        }

        public Criteria andCommissionIdLessThan(Integer value) {
            addCriterion("commission_id <", value, "commissionId");
            return (Criteria) this;
        }

        public Criteria andCommissionIdLessThanOrEqualTo(Integer value) {
            addCriterion("commission_id <=", value, "commissionId");
            return (Criteria) this;
        }

        public Criteria andCommissionIdIn(List<Integer> values) {
            addCriterion("commission_id in", values, "commissionId");
            return (Criteria) this;
        }

        public Criteria andCommissionIdNotIn(List<Integer> values) {
            addCriterion("commission_id not in", values, "commissionId");
            return (Criteria) this;
        }

        public Criteria andCommissionIdBetween(Integer value1, Integer value2) {
            addCriterion("commission_id between", value1, value2, "commissionId");
            return (Criteria) this;
        }

        public Criteria andCommissionIdNotBetween(Integer value1, Integer value2) {
            addCriterion("commission_id not between", value1, value2, "commissionId");
            return (Criteria) this;
        }

        public Criteria andPromotionActivityIdIsNull() {
            addCriterion("promotion_activity_id is null");
            return (Criteria) this;
        }

        public Criteria andPromotionActivityIdIsNotNull() {
            addCriterion("promotion_activity_id is not null");
            return (Criteria) this;
        }

        public Criteria andPromotionActivityIdEqualTo(Integer value) {
            addCriterion("promotion_activity_id =", value, "promotionActivityId");
            return (Criteria) this;
        }

        public Criteria andPromotionActivityIdNotEqualTo(Integer value) {
            addCriterion("promotion_activity_id <>", value, "promotionActivityId");
            return (Criteria) this;
        }

        public Criteria andPromotionActivityIdGreaterThan(Integer value) {
            addCriterion("promotion_activity_id >", value, "promotionActivityId");
            return (Criteria) this;
        }

        public Criteria andPromotionActivityIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("promotion_activity_id >=", value, "promotionActivityId");
            return (Criteria) this;
        }

        public Criteria andPromotionActivityIdLessThan(Integer value) {
            addCriterion("promotion_activity_id <", value, "promotionActivityId");
            return (Criteria) this;
        }

        public Criteria andPromotionActivityIdLessThanOrEqualTo(Integer value) {
            addCriterion("promotion_activity_id <=", value, "promotionActivityId");
            return (Criteria) this;
        }

        public Criteria andPromotionActivityIdIn(List<Integer> values) {
            addCriterion("promotion_activity_id in", values, "promotionActivityId");
            return (Criteria) this;
        }

        public Criteria andPromotionActivityIdNotIn(List<Integer> values) {
            addCriterion("promotion_activity_id not in", values, "promotionActivityId");
            return (Criteria) this;
        }

        public Criteria andPromotionActivityIdBetween(Integer value1, Integer value2) {
            addCriterion("promotion_activity_id between", value1, value2, "promotionActivityId");
            return (Criteria) this;
        }

        public Criteria andPromotionActivityIdNotBetween(Integer value1, Integer value2) {
            addCriterion("promotion_activity_id not between", value1, value2, "promotionActivityId");
            return (Criteria) this;
        }

        public Criteria andDistributorLevelOneIsNull() {
            addCriterion("distributor_level_one is null");
            return (Criteria) this;
        }

        public Criteria andDistributorLevelOneIsNotNull() {
            addCriterion("distributor_level_one is not null");
            return (Criteria) this;
        }

        public Criteria andDistributorLevelOneEqualTo(Integer value) {
            addCriterion("distributor_level_one =", value, "distributorLevelOne");
            return (Criteria) this;
        }

        public Criteria andDistributorLevelOneNotEqualTo(Integer value) {
            addCriterion("distributor_level_one <>", value, "distributorLevelOne");
            return (Criteria) this;
        }

        public Criteria andDistributorLevelOneGreaterThan(Integer value) {
            addCriterion("distributor_level_one >", value, "distributorLevelOne");
            return (Criteria) this;
        }

        public Criteria andDistributorLevelOneGreaterThanOrEqualTo(Integer value) {
            addCriterion("distributor_level_one >=", value, "distributorLevelOne");
            return (Criteria) this;
        }

        public Criteria andDistributorLevelOneLessThan(Integer value) {
            addCriterion("distributor_level_one <", value, "distributorLevelOne");
            return (Criteria) this;
        }

        public Criteria andDistributorLevelOneLessThanOrEqualTo(Integer value) {
            addCriterion("distributor_level_one <=", value, "distributorLevelOne");
            return (Criteria) this;
        }

        public Criteria andDistributorLevelOneIn(List<Integer> values) {
            addCriterion("distributor_level_one in", values, "distributorLevelOne");
            return (Criteria) this;
        }

        public Criteria andDistributorLevelOneNotIn(List<Integer> values) {
            addCriterion("distributor_level_one not in", values, "distributorLevelOne");
            return (Criteria) this;
        }

        public Criteria andDistributorLevelOneBetween(Integer value1, Integer value2) {
            addCriterion("distributor_level_one between", value1, value2, "distributorLevelOne");
            return (Criteria) this;
        }

        public Criteria andDistributorLevelOneNotBetween(Integer value1, Integer value2) {
            addCriterion("distributor_level_one not between", value1, value2, "distributorLevelOne");
            return (Criteria) this;
        }

        public Criteria andDistributorLevelOneRateIsNull() {
            addCriterion("distributor_level_one_rate is null");
            return (Criteria) this;
        }

        public Criteria andDistributorLevelOneRateIsNotNull() {
            addCriterion("distributor_level_one_rate is not null");
            return (Criteria) this;
        }

        public Criteria andDistributorLevelOneRateEqualTo(BigDecimal value) {
            addCriterion("distributor_level_one_rate =", value, "distributorLevelOneRate");
            return (Criteria) this;
        }

        public Criteria andDistributorLevelOneRateNotEqualTo(BigDecimal value) {
            addCriterion("distributor_level_one_rate <>", value, "distributorLevelOneRate");
            return (Criteria) this;
        }

        public Criteria andDistributorLevelOneRateGreaterThan(BigDecimal value) {
            addCriterion("distributor_level_one_rate >", value, "distributorLevelOneRate");
            return (Criteria) this;
        }

        public Criteria andDistributorLevelOneRateGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("distributor_level_one_rate >=", value, "distributorLevelOneRate");
            return (Criteria) this;
        }

        public Criteria andDistributorLevelOneRateLessThan(BigDecimal value) {
            addCriterion("distributor_level_one_rate <", value, "distributorLevelOneRate");
            return (Criteria) this;
        }

        public Criteria andDistributorLevelOneRateLessThanOrEqualTo(BigDecimal value) {
            addCriterion("distributor_level_one_rate <=", value, "distributorLevelOneRate");
            return (Criteria) this;
        }

        public Criteria andDistributorLevelOneRateIn(List<BigDecimal> values) {
            addCriterion("distributor_level_one_rate in", values, "distributorLevelOneRate");
            return (Criteria) this;
        }

        public Criteria andDistributorLevelOneRateNotIn(List<BigDecimal> values) {
            addCriterion("distributor_level_one_rate not in", values, "distributorLevelOneRate");
            return (Criteria) this;
        }

        public Criteria andDistributorLevelOneRateBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("distributor_level_one_rate between", value1, value2, "distributorLevelOneRate");
            return (Criteria) this;
        }

        public Criteria andDistributorLevelOneRateNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("distributor_level_one_rate not between", value1, value2, "distributorLevelOneRate");
            return (Criteria) this;
        }

        public Criteria andDistributorLevelTwoIsNull() {
            addCriterion("distributor_level_two is null");
            return (Criteria) this;
        }

        public Criteria andDistributorLevelTwoIsNotNull() {
            addCriterion("distributor_level_two is not null");
            return (Criteria) this;
        }

        public Criteria andDistributorLevelTwoEqualTo(Integer value) {
            addCriterion("distributor_level_two =", value, "distributorLevelTwo");
            return (Criteria) this;
        }

        public Criteria andDistributorLevelTwoNotEqualTo(Integer value) {
            addCriterion("distributor_level_two <>", value, "distributorLevelTwo");
            return (Criteria) this;
        }

        public Criteria andDistributorLevelTwoGreaterThan(Integer value) {
            addCriterion("distributor_level_two >", value, "distributorLevelTwo");
            return (Criteria) this;
        }

        public Criteria andDistributorLevelTwoGreaterThanOrEqualTo(Integer value) {
            addCriterion("distributor_level_two >=", value, "distributorLevelTwo");
            return (Criteria) this;
        }

        public Criteria andDistributorLevelTwoLessThan(Integer value) {
            addCriterion("distributor_level_two <", value, "distributorLevelTwo");
            return (Criteria) this;
        }

        public Criteria andDistributorLevelTwoLessThanOrEqualTo(Integer value) {
            addCriterion("distributor_level_two <=", value, "distributorLevelTwo");
            return (Criteria) this;
        }

        public Criteria andDistributorLevelTwoIn(List<Integer> values) {
            addCriterion("distributor_level_two in", values, "distributorLevelTwo");
            return (Criteria) this;
        }

        public Criteria andDistributorLevelTwoNotIn(List<Integer> values) {
            addCriterion("distributor_level_two not in", values, "distributorLevelTwo");
            return (Criteria) this;
        }

        public Criteria andDistributorLevelTwoBetween(Integer value1, Integer value2) {
            addCriterion("distributor_level_two between", value1, value2, "distributorLevelTwo");
            return (Criteria) this;
        }

        public Criteria andDistributorLevelTwoNotBetween(Integer value1, Integer value2) {
            addCriterion("distributor_level_two not between", value1, value2, "distributorLevelTwo");
            return (Criteria) this;
        }

        public Criteria andDistributorLevelTwoRateIsNull() {
            addCriterion("distributor_level_two_rate is null");
            return (Criteria) this;
        }

        public Criteria andDistributorLevelTwoRateIsNotNull() {
            addCriterion("distributor_level_two_rate is not null");
            return (Criteria) this;
        }

        public Criteria andDistributorLevelTwoRateEqualTo(BigDecimal value) {
            addCriterion("distributor_level_two_rate =", value, "distributorLevelTwoRate");
            return (Criteria) this;
        }

        public Criteria andDistributorLevelTwoRateNotEqualTo(BigDecimal value) {
            addCriterion("distributor_level_two_rate <>", value, "distributorLevelTwoRate");
            return (Criteria) this;
        }

        public Criteria andDistributorLevelTwoRateGreaterThan(BigDecimal value) {
            addCriterion("distributor_level_two_rate >", value, "distributorLevelTwoRate");
            return (Criteria) this;
        }

        public Criteria andDistributorLevelTwoRateGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("distributor_level_two_rate >=", value, "distributorLevelTwoRate");
            return (Criteria) this;
        }

        public Criteria andDistributorLevelTwoRateLessThan(BigDecimal value) {
            addCriterion("distributor_level_two_rate <", value, "distributorLevelTwoRate");
            return (Criteria) this;
        }

        public Criteria andDistributorLevelTwoRateLessThanOrEqualTo(BigDecimal value) {
            addCriterion("distributor_level_two_rate <=", value, "distributorLevelTwoRate");
            return (Criteria) this;
        }

        public Criteria andDistributorLevelTwoRateIn(List<BigDecimal> values) {
            addCriterion("distributor_level_two_rate in", values, "distributorLevelTwoRate");
            return (Criteria) this;
        }

        public Criteria andDistributorLevelTwoRateNotIn(List<BigDecimal> values) {
            addCriterion("distributor_level_two_rate not in", values, "distributorLevelTwoRate");
            return (Criteria) this;
        }

        public Criteria andDistributorLevelTwoRateBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("distributor_level_two_rate between", value1, value2, "distributorLevelTwoRate");
            return (Criteria) this;
        }

        public Criteria andDistributorLevelTwoRateNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("distributor_level_two_rate not between", value1, value2, "distributorLevelTwoRate");
            return (Criteria) this;
        }

        public Criteria andCreateByIsNull() {
            addCriterion("create_by is null");
            return (Criteria) this;
        }

        public Criteria andCreateByIsNotNull() {
            addCriterion("create_by is not null");
            return (Criteria) this;
        }

        public Criteria andCreateByEqualTo(Integer value) {
            addCriterion("create_by =", value, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByNotEqualTo(Integer value) {
            addCriterion("create_by <>", value, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByGreaterThan(Integer value) {
            addCriterion("create_by >", value, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByGreaterThanOrEqualTo(Integer value) {
            addCriterion("create_by >=", value, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByLessThan(Integer value) {
            addCriterion("create_by <", value, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByLessThanOrEqualTo(Integer value) {
            addCriterion("create_by <=", value, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByIn(List<Integer> values) {
            addCriterion("create_by in", values, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByNotIn(List<Integer> values) {
            addCriterion("create_by not in", values, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByBetween(Integer value1, Integer value2) {
            addCriterion("create_by between", value1, value2, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByNotBetween(Integer value1, Integer value2) {
            addCriterion("create_by not between", value1, value2, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNull() {
            addCriterion("create_time is null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNotNull() {
            addCriterion("create_time is not null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeEqualTo(Date value) {
            addCriterion("create_time =", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotEqualTo(Date value) {
            addCriterion("create_time <>", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThan(Date value) {
            addCriterion("create_time >", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("create_time >=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThan(Date value) {
            addCriterion("create_time <", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThanOrEqualTo(Date value) {
            addCriterion("create_time <=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIn(List<Date> values) {
            addCriterion("create_time in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotIn(List<Date> values) {
            addCriterion("create_time not in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeBetween(Date value1, Date value2) {
            addCriterion("create_time between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotBetween(Date value1, Date value2) {
            addCriterion("create_time not between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andUpdateByIsNull() {
            addCriterion("update_by is null");
            return (Criteria) this;
        }

        public Criteria andUpdateByIsNotNull() {
            addCriterion("update_by is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateByEqualTo(Integer value) {
            addCriterion("update_by =", value, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByNotEqualTo(Integer value) {
            addCriterion("update_by <>", value, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByGreaterThan(Integer value) {
            addCriterion("update_by >", value, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByGreaterThanOrEqualTo(Integer value) {
            addCriterion("update_by >=", value, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByLessThan(Integer value) {
            addCriterion("update_by <", value, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByLessThanOrEqualTo(Integer value) {
            addCriterion("update_by <=", value, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByIn(List<Integer> values) {
            addCriterion("update_by in", values, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByNotIn(List<Integer> values) {
            addCriterion("update_by not in", values, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByBetween(Integer value1, Integer value2) {
            addCriterion("update_by between", value1, value2, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByNotBetween(Integer value1, Integer value2) {
            addCriterion("update_by not between", value1, value2, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNull() {
            addCriterion("update_time is null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNotNull() {
            addCriterion("update_time is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeEqualTo(Date value) {
            addCriterion("update_time =", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotEqualTo(Date value) {
            addCriterion("update_time <>", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThan(Date value) {
            addCriterion("update_time >", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("update_time >=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThan(Date value) {
            addCriterion("update_time <", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThanOrEqualTo(Date value) {
            addCriterion("update_time <=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIn(List<Date> values) {
            addCriterion("update_time in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotIn(List<Date> values) {
            addCriterion("update_time not in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeBetween(Date value1, Date value2) {
            addCriterion("update_time between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotBetween(Date value1, Date value2) {
            addCriterion("update_time not between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andIsdeleteIsNull() {
            addCriterion("isdelete is null");
            return (Criteria) this;
        }

        public Criteria andIsdeleteIsNotNull() {
            addCriterion("isdelete is not null");
            return (Criteria) this;
        }

        public Criteria andIsdeleteEqualTo(Byte value) {
            addCriterion("isdelete =", value, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteNotEqualTo(Byte value) {
            addCriterion("isdelete <>", value, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteGreaterThan(Byte value) {
            addCriterion("isdelete >", value, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteGreaterThanOrEqualTo(Byte value) {
            addCriterion("isdelete >=", value, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteLessThan(Byte value) {
            addCriterion("isdelete <", value, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteLessThanOrEqualTo(Byte value) {
            addCriterion("isdelete <=", value, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteIn(List<Byte> values) {
            addCriterion("isdelete in", values, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteNotIn(List<Byte> values) {
            addCriterion("isdelete not in", values, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteBetween(Byte value1, Byte value2) {
            addCriterion("isdelete between", value1, value2, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteNotBetween(Byte value1, Byte value2) {
            addCriterion("isdelete not between", value1, value2, "isdelete");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}