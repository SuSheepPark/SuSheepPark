package com.ruida.mockservice.service;


import com.baomidou.mybatisplus.service.IService;
import com.ruida.mockdao.model.MajorSelectDetail;

/**
 * <p>
 * 专业兴趣选择详情表 服务类
 * </p>
 *
 * @author xumingqi
 * @since 2021-01-14
 */
public interface MajorSelectDetailService extends IService<MajorSelectDetail> {
    Integer getMajorCountByRecordId(Integer recordId);
}
