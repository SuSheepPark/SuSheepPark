package com.ruida.common.enums;


/**
 * @author wy
 * @description 双师对接方类型 日志使用
 * @date 2021/6/8
 */
public enum DoubleOperateObjectEnum {

    BJY(1,"百家云"),
    XGJ(2,"校管家"),
    LOCAL(3,"本地"),
    XGJ_BJY(2,"校管家&百家云"),
    ;

    private Integer id;
    private String name;

    DoubleOperateObjectEnum(Integer id, String name) {
        this.id = id;
        this.name = name;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
