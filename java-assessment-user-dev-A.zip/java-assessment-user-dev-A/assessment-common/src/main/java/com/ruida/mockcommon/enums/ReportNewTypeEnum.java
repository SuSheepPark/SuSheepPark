package com.ruida.mockcommon.enums;

import lombok.Getter;

/**
 * Created by xumingqi on 2021/7/22 14:47
 */
@Getter
public enum ReportNewTypeEnum {
    PERSONAL(1, "个人成绩报告"),

    NINE_UNION_3(2, "9+1联考报告(3分1赋)"),

    JUNIOR_UNION(3, "初中联考报告"),

    NINE_UNION_1(4, "9+1联考报告(1分1赋)"),

    NINE_UNION_CME(5, "9+1联考报告(必考科目)"),

    NINE_UNION_1_PRACTICE(6, "9+1联考报告练习版(1分1赋)"),
    NINE_UNION_3_PRACTICE(7, "9+1联考报告练习版(3分1赋)"),
    NINE_UNION_CME_PRACTICE(8, "9+1联考报告练习版(必考科目)"),
    JUNIOR_UNION_PRACTICE(9, "初中联考报告练习版");

    private final int id;

    private final String name;

    ReportNewTypeEnum(int id, String name) {
        this.id = id;
        this.name = name;
    }

    public static ReportNewTypeEnum getTypeById(int id) {
        for (ReportNewTypeEnum item : ReportNewTypeEnum.values()) {
            if (item.getId() == id) {
                return item;
            }
        }
        return null;
    }
}
