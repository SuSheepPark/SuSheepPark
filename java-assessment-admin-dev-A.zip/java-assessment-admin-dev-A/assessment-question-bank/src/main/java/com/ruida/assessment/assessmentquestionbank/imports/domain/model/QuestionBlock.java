package com.ruida.assessment.assessmentquestionbank.imports.domain.model;

public class QuestionBlock {

	private Integer number;
	private QuestionContent content;
	private QuestionAnswer answer;
	private QuestionExplain explain;
	private QuestionRemark remark;
	private QuestionKnowledge knowledge;
	private QuestionBaseConfig blockConfig;
	public Integer getNumber() {
		return number;
	}
	public void setNumber(Integer number) {
		this.number = number;
	}
	public QuestionContent getContent() {
		return content;
	}
	public void setContent(QuestionContent content) {
		this.content = content;
	}
	public QuestionAnswer getAnswer() {
		return answer;
	}
	public void setAnswer(QuestionAnswer answer) {
		this.answer = answer;
	}
	public QuestionExplain getExplain() {
		return explain;
	}
	public void setExplain(QuestionExplain explain) {
		this.explain = explain;
	}
	public QuestionRemark getRemark() {
		return remark;
	}
	public void setRemark(QuestionRemark remark) {
		this.remark = remark;
	}
	public QuestionKnowledge getKnowledge() {
		return knowledge;
	}
	public void setKnowledge(QuestionKnowledge knowledge) {
		this.knowledge = knowledge;
	}
	public QuestionBaseConfig getBlockConfig() {
		return blockConfig;
	}
	public void setBlockConfig(QuestionBaseConfig blockConfig) {
		this.blockConfig = blockConfig;
	}
}
