package com.ruida.assessment.assessmentcommon.enums;

public enum UserAuthCEnum {
    PASS(1,"使用认证"),
    FORBID(2,"不使用认证");


    private Integer K;
    private String V;

    UserAuthCEnum(Integer k, String v) {
        K = k;
        V = v;
    }

    public Integer getK() {
        return K;
    }

    public void setK(Integer k) {
        K = k;
    }

    public String getV() {
        return V;
    }

    public void setV(String v) {
        V = v;
    }


    public static UserAuthCEnum getValueById(Integer K){
        for(UserAuthCEnum questionEnum : UserAuthCEnum.values() ){
            if(questionEnum.getK().equals(K)){
                return  questionEnum;
            }
        }
        return null;
    }

}
