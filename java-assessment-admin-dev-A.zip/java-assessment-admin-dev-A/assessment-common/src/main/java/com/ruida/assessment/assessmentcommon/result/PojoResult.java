package com.ruida.assessment.assessmentcommon.result;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * @description:
 * @author szl
 * @Date 2018年12月10日
 * @verion 1.0
 */
@ApiModel(value = "响应结果")
public class PojoResult<T> extends BaseResult {

	private static final long serialVersionUID = -3798855953342189365L;
	@ApiModelProperty(value = "响应体的内容")
	private T content;

	public T getContent() {
		return content;
	}

	public void setContent(T content) {
		this.content = content;
	}

}
