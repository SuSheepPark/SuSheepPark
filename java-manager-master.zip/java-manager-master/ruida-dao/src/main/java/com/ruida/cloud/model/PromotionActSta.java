package com.ruida.cloud.model;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author admin
 * @description: ${TODO}
 * @Date 2020/4/16
 * @verion 1.0
 */
@Data
public class PromotionActSta implements Serializable {
    private Integer promotionActivityId;
    private String promotionActivityName;
    private Date startTime;
    private Date endTime;
    private Date createTime;
    private String courseNames;
    private String distributorName;
    private String distributorIds;
    /**
     * 分销商数量
     */
    private Integer distributorCount;
    /**
     * 订单总数
     */
    private Long totalOrderCount;
    /**
     * 总流量
     */
    private Long totalUv;
    /**
     * 有效流量
     */
    private Long totalEu;
    /**
     * 获得佣金总数
     */
    private BigDecimal totalCommission;
    /**
     * 平台总收入
     */
    private BigDecimal totalAmount;
    /**
     * 时间开始结束区间
     */
    private String intervalStr;
    /**
     * 活动状态
     */
    private String promotionStatus;
    /**
     * 活动状态值
     */
    private Integer promotionStatusVul;
    /**
     * 0禁用 1启用
     */
    private Integer status;
    private Integer relateAllCourse;
    private Integer relateAllDistributor;


    private HashMap ext;

}
