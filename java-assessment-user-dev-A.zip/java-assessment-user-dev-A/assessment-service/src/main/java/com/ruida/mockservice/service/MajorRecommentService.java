package com.ruida.mockservice.service;

import com.baomidou.mybatisplus.service.IService;
import com.ruida.mockdao.model.TMajorRecommend;
import com.ruida.mockservice.service.impl.MajorRecommentServiceImpl;
import com.ruida.mockservice.vo.preference.RecommendMajorVO;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 专业推荐
 */
public interface MajorRecommentService extends IService<TMajorRecommend> {
    /**
     * 获取高校专业推荐列表
     *
     * @param reportId   报告id
     * @param subjectIds 学科ids
     * @param userId     用户id
     * @return
     */
    List<MajorRecommentServiceImpl.CollegeVO> getMajorRecommentList(Integer reportId, List<String> subjectIds, String userId);

    /**
     * 获取高校层次信息
     *
     * @return
     */
    List<Map<String, Object>> getCollegeLevelList(Integer reportId, Integer userId);

    /**
     * 志愿填报专业推荐
     *
     * @param reportId
     * @param subjectNames
     * @param userId
     * @param totalScore
     * @return
     */
    LinkedHashMap<Integer, List<RecommendMajorVO>> getMajorRecommendListByPreference(Integer reportId, List<String> subjectNames, String userId, Double totalScore);

    /**
     * 获取高校层次信息(志愿填报)
     *
     * @return
     */
    List<Map<String, Object>> getCollegeLevelListByPreference(Integer reportId, Integer userId);

    List<MajorRecommentServiceImpl.CollegeVO> dealMajorRecommentData(List<TMajorRecommend> list);

}
