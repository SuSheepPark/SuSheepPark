package com.ruida.assessment.assessmentquestionbank.controller;

import com.ruida.assessment.assessmentcommon.result.ListResult;
import com.ruida.assessment.assessmentcommon.result.PageResult;
import com.ruida.assessment.assessmentcommon.result.PojoResult;
import com.ruida.assessment.assessmentcommon.util.excel.ExportExcelUtils;
import com.ruida.assessment.assessmentquestionbank.annotaion.UserAuth;
import com.ruida.assessment.assessmentquestionbank.dto.OrderOperationDTO;
import com.ruida.assessment.assessmentquestionbank.dto.OrderQueryDTO;
import com.ruida.assessment.assessmentquestionbank.service.OrderService;
import com.ruida.assessment.assessmentquestionbank.vo.OrderDetailVO;
import com.ruida.assessment.assessmentquestionbank.vo.OrderVO;
import com.ruida.assessment.assessmentquestionbank.vo.StudyCoinRecordVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * @description: 订单管理控制层
 * @author: kgz
 * @date: 2020/7/31
 */
@RequestMapping("/orderManage")
@RestController
@Api(value ="用户消息相关接口")
public class OrderController {

    @Resource
    private OrderService orderService;

    @GetMapping("/getOrderType")
    @ApiOperation(value = "商品类型列表", notes = "商品类型列表")
    public ListResult getOrderType(){
        ListResult listResult = new ListResult();
        listResult.setContent(orderService.getOrderType());
        return listResult;
    }

    @UserAuth
    @PostMapping("/getSum")
    @ApiOperation(value = "订单数据概况", notes = "订单数据概况")
    @ApiImplicitParam(name = "orderQueryDTO", value = "查询条件",
            required = true , dataType  = "OrderQueryDTO",paramType = "body")
    public PojoResult getSum(@RequestBody OrderQueryDTO orderQueryDTO){
        PojoResult pojoResult = new PojoResult();
        pojoResult.setContent(orderService.getOrderSum(orderQueryDTO));
        return pojoResult;
    }

    @UserAuth
    @PostMapping("/getList")
    @ApiOperation(value = "分页查询订单列表", notes = "分页查询订单列表")
    @ApiImplicitParam(name = "orderQueryDTO", value = "查询条件",
            required = true , dataType  = "OrderQueryDTO",paramType = "body")
    public PageResult<OrderVO> getList(@RequestBody OrderQueryDTO orderQueryDTO){
        PageResult<OrderVO> pageResult = new PageResult();
        pageResult.setContent(orderService.getOrderList(orderQueryDTO));
        return pageResult;
    }

    @UserAuth
    @GetMapping("/export")
    @ApiOperation(value = "导出订单列表", notes = "导出订单列表")
    public void export(HttpServletResponse response, @RequestParam(required = false) String keyWords,
                       @RequestParam(required = false) Integer status, @RequestParam(required = false) Integer productType,
                       @RequestParam(required = false) Integer paymentType, @RequestParam(required = false) Integer refund,
                       @RequestParam(required = false) String createTimeStart, @RequestParam(required = false) String createTimeEnd,
                       @RequestParam(required = false) String paymentTimeStart, @RequestParam(required = false) String paymentTimeEnd) {
        OrderQueryDTO orderQueryDTO = new OrderQueryDTO();
        orderQueryDTO.setKeyWords(keyWords);
        orderQueryDTO.setStatus(status);
        orderQueryDTO.setProductType(productType);
        orderQueryDTO.setPaymentType(paymentType);
        orderQueryDTO.setRefund(refund);
        orderQueryDTO.setCreateTimeStart(createTimeStart);
        orderQueryDTO.setCreateTimeEnd(createTimeEnd);
        orderQueryDTO.setPaymentTimeStart(paymentTimeStart);
        orderQueryDTO.setPaymentTimeEnd(paymentTimeEnd);
        List<OrderVO> orderList = orderService.getExportOrderList(orderQueryDTO);
        String excelName = "订单列表";
        ExportExcelUtils.export(excelName, orderList, OrderVO.class, response);
    }

    @UserAuth
    @GetMapping("/getDetail/{id}")
    @ApiOperation(value = "获取订单详情", notes = "获取订单详情")
    @ApiImplicitParam(name = "id", value = "订单id",
            required = true, dataType = "integer", paramType = "path")
    public PojoResult<OrderDetailVO> getDetail(@PathVariable Integer id) {
        PojoResult<OrderDetailVO> pojoResult = new PojoResult<>();
        pojoResult.setContent(orderService.getOrderDetail(id));
        return pojoResult;
    }

    @UserAuth
    @PostMapping("/operation")
    @ApiOperation(value = "订单操作", notes = "订单操作")
    @ApiImplicitParam(name = "orderOperation", value = "订单操作",
            required = true , dataType  = "OrderOperationDTO",paramType = "body")
    public PojoResult sendMessage(@RequestBody OrderOperationDTO orderOperation){
        PojoResult pojoResult = new PojoResult();
        orderService.orderOperation(orderOperation);
        pojoResult.setContent(orderOperation);
        return pojoResult;
    }

    @UserAuth
    @PostMapping("/getRechargeList")
    @ApiOperation(value = "分页查询充值记录列表", notes = "分页查询充值记录列表")
    @ApiImplicitParam(name = "orderQueryDTO", value = "查询条件",
            required = true , dataType  = "OrderQueryDTO",paramType = "body")
    public PageResult<StudyCoinRecordVO> getRechargeList(@RequestBody OrderQueryDTO orderQueryDTO){
        PageResult<StudyCoinRecordVO> pageResult = new PageResult();
        pageResult.setContent(orderService.getRechargeList(orderQueryDTO));
        return pageResult;
    }
}
