package com.ruida.mockdao.dto;

import com.ruida.mockcommon.result.Page;
import lombok.Data;

/**
 * 我的 考试记录 查询条件
 */
@Data
public class MyExamPaperRequest {


    /**
     * 用户id
     */
    private String userId;

    private String stuId;

    private String testPaperName;

    /*
   年级id
    */
    private Integer stageId;

    /*
 科目id
  */
    private Integer subjectId;


    /*
        排序字段  默认创建时间排序倒序     */
    private String  orderStr = "j.update_time";

    /*
        排序方式 0-降序 1-升序 默认创建时间排序倒序
     */
    private Integer orderType = 0;


    private Page page;

    /*分页*/
    private Integer start;
    private Integer size;


    private Integer isdelete = 0;


}
