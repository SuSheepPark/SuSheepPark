package com.ruida.cloud.dao;

import com.ruida.cloud.model.CourseVideoExt;

import java.util.List;
import java.util.Map;

/**
 * @author admin
 * @description: ${TODO}
 * @Date 2019/1/24
 * @verion 1.0
 */
public interface CourseVideoMapperExt {
    int countByExampleSearch();
    List<CourseVideoExt> selectByExampleSearch(Map condtion);
    CourseVideoExt selectById(Integer id);

}
