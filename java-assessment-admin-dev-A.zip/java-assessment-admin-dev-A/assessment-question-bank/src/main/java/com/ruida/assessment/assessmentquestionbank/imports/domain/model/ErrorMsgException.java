package com.ruida.assessment.assessmentquestionbank.imports.domain.model;

public class ErrorMsgException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Integer lineNum;
	private String desc;

	public ErrorMsgException(Integer lineNum, String desc) {
		this.lineNum = lineNum;
		this.desc = desc;
	}

	public Integer getLineNum() {
		return lineNum;
	}

	public void setLineNum(Integer lineNum) {
		this.lineNum = lineNum;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}
}
