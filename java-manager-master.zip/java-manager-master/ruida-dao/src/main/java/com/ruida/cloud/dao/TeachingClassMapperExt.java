package com.ruida.cloud.dao;

import com.ruida.cloud.model.TeachingClass;
import com.ruida.cloud.model.TeachingClassExt;

import java.util.List;
import java.util.Map;

public interface TeachingClassMapperExt {

    int insertTeachingClassBatch(List<TeachingClass> classList);

    List<TeachingClassExt> listTeachingClass(Integer courseId);

    List<TeachingClassExt> listTeachingClassExt(Integer courseId);

    List<TeachingClassExt> listTeachingClassByInfo(Map condition);

    List<TeachingClassExt> listTeachingClassByCampusId(Integer courseId);

    List<TeachingClassExt> listTeachingClassGroupByRoomId(Integer courseId);

    int deleteTeachingClassByLessonId(Map condition);

    int deleteClassRecordByLessonId(Map condition);

    int deleteTeachingClassByCourseId(Integer courseId);

    int updateTeachingClassByCourseId(Integer courseId);

    List<TeachingClassExt> listTeachingClassNoClass(Map condition);

    List<TeachingClassExt> listDeletedTeachingClassByCourseId(Integer courseId);

    public int updateSchoolTaskBatch(List<TeachingClassExt> list);

    public int updateStudentSchoolTaskRelBatch(List<TeachingClassExt> list);

    public int updateClassRecordBatch(List<TeachingClassExt> list);

    int deleteDeletedTeachingClass(Integer courseId);

    int countNewTeachingClass(Integer courseId);

    int updateDeletedTeachingClass(Integer courseId);

    int updateTeacherCommendStudentBatch(List<TeachingClassExt> list);

    int updateStudentCommendTeacherBatch(List<TeachingClassExt> list);

    List<TeachingClass> listTeachingClassByCourseId(Integer courseId);
}