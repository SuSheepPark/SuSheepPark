package com.ruida.assessment.assessmentquestionbank.dao;

import com.ruida.assessment.assessmentquestionbank.dto.PreferenceEventStatDTO;
import com.ruida.assessment.assessmentquestionbank.dto.PreferenceFeedbackDTO;
import com.ruida.assessment.assessmentquestionbank.dto.PreferenceReportDataDTO;
import com.ruida.assessment.assessmentquestionbank.vo.PreferenceEventStatVO;
import com.ruida.assessment.assessmentquestionbank.vo.PreferenceFeedbackVO;
import com.ruida.assessment.assessmentquestionbank.vo.PreferenceReportDataVO;

import java.util.List;

/**
 * 报告统计
 */
public interface PreferenceDataMapper {
   /**
    * 获取报告信息统计列表
    * @param dto
    * @return
    */
   List<PreferenceReportDataVO> getPreferenceReportDataList(PreferenceReportDataDTO dto);
   Integer countPreferenceReportDataList(PreferenceReportDataDTO dto);

   /**
    * 获取志愿填报评分反馈列表
    * @param dto
    * @return
    */
   List<PreferenceFeedbackVO> getFeedbackList(PreferenceFeedbackDTO dto);
   Integer countFeedbackList(PreferenceFeedbackDTO dto);

   /**
    * 获取点击事件统计列表
    * @param dto
    * @return
    */
   List<PreferenceEventStatVO> clickEventStatList(PreferenceEventStatDTO dto);
   Integer countClickEventStat(PreferenceEventStatDTO dto);
}
