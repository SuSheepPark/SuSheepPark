package com.ruida.mockdao.vo.report;

import com.alibaba.fastjson.JSONArray;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @description: 报告试题VO
 * @author: chenjy
 * @create: 2020-08-11 11:18
 */
@Data
public class ReportQuestionKnowledgeVO implements Serializable {

    /*试题Id*/
    private String questionId;

    /*题号*/
    private String questionNum;

    /*父级Id*/
    private String pid;

    @JsonIgnore
    private Integer questionTypeId;

    /*满分*/
    @JsonIgnore
    private Double totalScore;

    /*得分*/
    @JsonIgnore
    private Double score;

    /*班级平均分*/
    @JsonIgnore
    private Double classAvg;

    /*学校平均分*/
    @JsonIgnore
    private Double schoolAvg;

    /*9+1学校平均分*/
    @JsonIgnore
    private Double nineOneSchoolAvg;

    /**联考学校平均分*/
    private Double unionAvg;

    /*知识点*/
//    private List<ReportKnowledgeVO> knowledgeList;

    /*知识点*/
    private JSONArray knowledgeList;

}
