package com.ruida.cloud.weidu.service.impl.data;

import com.ruida.cloud.weidu.config.WeiduConfig;
import com.ruida.cloud.weidu.service.BaseVdyooService;
import com.ruida.cloud.weidu.utils.PropertyUtil;
import com.ruida.cloud.weidu.utils.VdyooUtil;
import com.ruida.cloud.weidu.vo.VdyooEntity;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * @author taosh
 * @create 2019-04-24 11:49
 */
@Service
public class VdyooStudentRedGiftService extends BaseVdyooService {
    /**
     * 获取学生全部答题数据通过学生的ID来查询学生的答题情况
     */
    public VdyooEntity findStudentRedGiftBySchedule(Map<String, Object> param){
//        String path = vdyooPath+"/api/business/studentredgift/findStudentRedGiftBySchedule";
//
//        Map<String, String> param = VdyooUtil.getSignMap();
//
//        //课表ID
//        param.put("scheduleId", scheduleId);

//        String response = HttpClientUtil.postMap(path, param);
//        System.out.println(response);
      return   this.vdyooFactory.post(param, WeiduConfig.findStudentRedGiftBySchedule);
    }
}
