package com.ruida.mockservice.service.impl;

import com.alibaba.fastjson.JSON;
import com.ruida.mockcommon.auth.context.BaseContextHandle;
import com.ruida.mockcommon.auth.pojo.JWTInfo;
import com.ruida.mockcommon.constant.SystemConstant;
import com.ruida.mockcommon.enums.AppErrorEnum;
import com.ruida.mockcommon.exception.CoreException;
import com.ruida.mockcommon.result.Page;
import com.ruida.mockcommon.util.StringUtil;
import com.ruida.mockdao.dao.EvaluateReportMapper;
import com.ruida.mockdao.model.TEvaluateReport;
import com.ruida.mockdao.vo.report.*;
import com.ruida.mockservice.service.EvaluateReportService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @description:
 * @author: kgz
 * @date: 2020/12/15
 */
@Service
@Slf4j
public class EvaluateReportServiceImpl implements EvaluateReportService {

    @Resource
    EvaluateReportMapper evaluateReportMapper;

    @Override
    public Page<UpgradeReportRecordVO> getEvaluateReportList(Integer pageNum, Integer pageSize, String keyWords) {
        pageNum = pageNum == null ? SystemConstant.PAGE_DEFAULT_NUM : pageNum;
        pageSize = pageSize == null ? SystemConstant.USER_ORDER_PAGE_SIZE : pageSize;
        int pageIndex = (pageNum - 1) * pageSize;
        Page<UpgradeReportRecordVO> page = new Page<>();
        Integer userId = getUserId();
//        Integer userId = 90440;
        page.setResult(evaluateReportMapper.getUpgradeReportRecordList(pageIndex, pageSize, keyWords, userId));
        page.setCurrentPage(pageNum);
        page.setNowTime(new Date());
        page.setPageSize(pageSize);
        page.setTotalCount(evaluateReportMapper.getUpgradeReportRecordCount(keyWords, userId));
        return page;
    }

    @Override
    public EvaluateReportVO getEvaluateReportDetail(Integer reportId, Integer type) {
        EvaluateReportVO evaluateReportVO = new EvaluateReportVO();
        TEvaluateReport evaluateReport = new TEvaluateReport();
        evaluateReport.setUserId(getUserId());
//        evaluateReport.setUserId(90440);
        evaluateReport.setReportId(reportId);
        evaluateReport.setIsdelete(0);
        evaluateReport = evaluateReportMapper.selectOne(evaluateReport);
        if(evaluateReport != null ){
            evaluateReportVO.setReportName(evaluateReport.getReportName());
            evaluateReportVO.setSubjectName(evaluateReport.getSubjectName());
            evaluateReportVO.setUserName(evaluateReport.getUserName());
            evaluateReportVO.setClassName(evaluateReport.getClassName());
            evaluateReportVO.setSchoolName(evaluateReport.getSchoolName());
            //综合报告有本次测试成绩
            if(type.equals(1) && StringUtil.isNotEmpty(evaluateReport.getCurrentScoreInfo())){
                CurrentScoreInfoVO currentScoreInfo = JSON.parseObject(evaluateReport.getCurrentScoreInfo(), CurrentScoreInfoVO.class);
                evaluateReportVO.setCurrentScoreInfo(currentScoreInfo);
            }
            //历次统一测试成绩
            if(StringUtil.isNotEmpty(evaluateReport.getHistoryScoreInfo())){
                HisExamVO historyScoreInfo = JSON.parseObject(evaluateReport.getHistoryScoreInfo(), HisExamVO.class);
                historyScoreInfo.setAllSubjectScoreInfo(getAllSubjectScore(historyScoreInfo));
                //设置每科的平均分
                setEachSubjectScoreAvg(historyScoreInfo.getHistoryScoreInfo());
                evaluateReportVO.setHistoryScoreInfo(historyScoreInfo);
            }
            //历次学校组织的测试成绩
            if(StringUtil.isNotEmpty(evaluateReport.getHistorySchoolScoreInfo())){
                HisSchoolScoreInfoVO historySchoolScoreInfo = JSON.parseObject(evaluateReport.getHistorySchoolScoreInfo(), HisSchoolScoreInfoVO.class);
                evaluateReportVO.setHistorySchoolScoreInfo(historySchoolScoreInfo.getEachSubjectScoreInfo());
            }
        }
        return evaluateReportVO;
    }

    /**
     * 设置每个科目的平均分
     * @param historyScoreInfo
     */
    private void setEachSubjectScoreAvg(List<HisSubjectScoreInfoVO> historyScoreInfo) {
        historyScoreInfo.stream().forEach(x ->{
            if(!CollectionUtils.isEmpty(x.getSubjectScoreInfo())){
                Double avg = x.getSubjectScoreInfo().stream().mapToDouble(SubjectScoreInfoVO::getCalculateScore).average().getAsDouble();
                x.setCalculateScoreAvg(new BigDecimal(avg).setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue());
            }
        });
    }

    /**
     * 获取每次测试的所有科目总分
     * @param hisExamVO
     * @return
     */
    private HisSubjectScoreInfoVO getAllSubjectScore(HisExamVO hisExamVO) {
        List<HisSubjectScoreInfoVO> historyScoreInfo = hisExamVO.getHistoryScoreInfo();
        HisSubjectScoreInfoVO hisSubjectScoreInfoVO = new HisSubjectScoreInfoVO();
        hisSubjectScoreInfoVO.setSubjectName("所有科目总分");
        List<SubjectScoreInfoVO> subjectScoreInfoList = new ArrayList<>();
        for(int i=0;i<hisExamVO.getHistoryExamName().size();i++){
            Integer allSubjectScore = 0;
            for(int j=0;j<historyScoreInfo.size();j++){
                //每个科目的多次测试成绩，-1为语数英三科总分科目
                if(historyScoreInfo.get(j) != null && historyScoreInfo.get(j).getSubjectId() != -1){
                    List<SubjectScoreInfoVO> subjectScoreInfo = historyScoreInfo.get(j).getSubjectScoreInfo();
                    if(!CollectionUtils.isEmpty(subjectScoreInfo)){
                        Integer score = subjectScoreInfo.get(i).getCalculateScore();
                        if(score != null){
                            allSubjectScore += score;
                        }
                    }
                }
            }
            SubjectScoreInfoVO subjectScoreInfoVO = new SubjectScoreInfoVO();
            subjectScoreInfoVO.setCalculateScore(allSubjectScore);
            subjectScoreInfoList.add(subjectScoreInfoVO);
        }
        hisSubjectScoreInfoVO.setSubjectScoreInfo(subjectScoreInfoList);
        Double avg = subjectScoreInfoList.stream().mapToDouble(SubjectScoreInfoVO::getCalculateScore).average().getAsDouble();
        hisSubjectScoreInfoVO.setCalculateScoreAvg(new BigDecimal(avg).setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue());
        return hisSubjectScoreInfoVO;
    }

    @Override
    public EvaluateReportVO setEvaluateReportDetailForTest() {
/*        TEvaluateReport evaluateReport = new TEvaluateReport();
        evaluateReport.setReportId(1111111);
        evaluateReport.setReportName("KKKKK测试");
        evaluateReport.setUserId(90320);
        evaluateReport.setUserName("大哥卢一");
        evaluateReport.setSubjectName("综合");
        evaluateReport.setClassName("高一三班");
        evaluateReport.setSchoolName("富阳中学");
        //本次成绩
        CurrentScoreInfoVO currentScoreInfo = new CurrentScoreInfoVO();
        SubjectScoreInfoVO threeSubjectScoreInfo = setThreeSubjectScoreInfo();
        SubjectScoreInfoVO allSubjectScoreInfo = setAllSubjectScoreInfo();
        List<SubjectScoreInfoVO> eachSubjectScoreInfo = setEachSubjectScoreInfo();
        currentScoreInfo.setThreeSubjectScoreInfo(threeSubjectScoreInfo);
        currentScoreInfo.setAllSubjectScoreInfo(allSubjectScoreInfo);
        currentScoreInfo.setEachSubjectScoreInfo(eachSubjectScoreInfo);
        evaluateReport.setCurrentScoreInfo(JSON.toJSONString(currentScoreInfo));
        //历次成绩
        HisExamVO hisExamVO = new HisExamVO();
        List<String> historyExamName = Arrays.asList("第一次测试","第二次测试");
        List<HisSubjectScoreInfoVO> historyScoreInfo = setHistoryScoreInfo();
        hisExamVO.setHistoryExamName(historyExamName);
        hisExamVO.setHistoryScoreInfo(historyScoreInfo);
        evaluateReport.setHistoryScoreInfo(JSON.toJSONString(hisExamVO));
        //历次学校组织的测试成绩
        List<HisSchoolSubjectScoreInfoVO> historySchoolScoreInfo = setHisSchoolSubjectScoreInfo();
        evaluateReport.setHistorySchoolScoreInfo(JSON.toJSONString(historySchoolScoreInfo));
        evaluateReportMapper.insert(evaluateReport);*/
        return null;
    }

/*    *//**
     * 设置学校组织的测试成绩
     * @return
     *//*
    private List<HisSchoolSubjectScoreInfoVO> setHisSchoolSubjectScoreInfo() {
        List<HisSchoolSubjectScoreInfoVO> list = new ArrayList<>();
        HisSchoolSubjectScoreInfoVO hisSchoolSubjectScoreInfo = new HisSchoolSubjectScoreInfoVO();
        hisSchoolSubjectScoreInfo.setSubjectName("语文");
        hisSchoolSubjectScoreInfo.setScore(120d);
        hisSchoolSubjectScoreInfo.setSchoolRank(13);
        hisSchoolSubjectScoreInfo.setSchoolNum(301);
        hisSchoolSubjectScoreInfo.setSchoolScorePercent("12.32%");
        List<StageScoreVO> stageScore = setStageScore();
        hisSchoolSubjectScoreInfo.setStageScore(stageScore);
        list.add(hisSchoolSubjectScoreInfo);
        return list;
    }

    *//**
     * 设置年级得分
     * @return
     *//*
    private List<StageScoreVO> setStageScore() {
        List<StageScoreVO> list = new ArrayList<>();
        StageScoreVO stageScore = new StageScoreVO();
        stageScore.setStageName("高一上");
        stageScore.setScore(101d);
        list.add(stageScore);
        StageScoreVO stageScore2 = new StageScoreVO();
        stageScore2.setStageName("高一下");
        stageScore2.setScore(102d);
        list.add(stageScore2);
        StageScoreVO stageScore3 = new StageScoreVO();
        stageScore3.setStageName("高二上");
        stageScore3.setScore(103d);
        list.add(stageScore3);
        StageScoreVO stageScore4 = new StageScoreVO();
        stageScore4.setStageName("高二下");
        stageScore4.setScore(104d);
        list.add(stageScore4);
        StageScoreVO stageScore5 = new StageScoreVO();
        stageScore5.setStageName("高三上");
        stageScore5.setScore(105d);
        list.add(stageScore5);
        StageScoreVO stageScore6 = new StageScoreVO();
        stageScore6.setStageName("高三下");
        stageScore6.setScore(106d);
        list.add(stageScore6);
        return list;
    }

    *//**
     * 设置历次测试成绩
     * @return
     *//*
    private List<HisSubjectScoreInfoVO> setHistoryScoreInfo() {
        List<HisSubjectScoreInfoVO> historyScoreInfo = new ArrayList<>();
        HisSubjectScoreInfoVO hisSubjectScoreInfoVO = new HisSubjectScoreInfoVO();
        hisSubjectScoreInfoVO.setSubjectName("语文");
        List<SubjectScoreInfoVO> subjectScoreInfoList = new ArrayList<>();
        SubjectScoreInfoVO subjectScoreInfo = new SubjectScoreInfoVO();
        subjectScoreInfo.setSchoolRank(12);
        subjectScoreInfo.setSchoolNum(521);
        subjectScoreInfo.setCalculateScore(110);
        subjectScoreInfo.setCalculateCollegeLevel("985高校");
        subjectScoreInfoList.add(subjectScoreInfo);
        SubjectScoreInfoVO subjectScoreInfo2 = new SubjectScoreInfoVO();
        subjectScoreInfo2.setSchoolRank(13);
        subjectScoreInfo2.setSchoolNum(523);
        subjectScoreInfo2.setCalculateScore(120);
        subjectScoreInfo2.setCalculateCollegeLevel("211高校");
        subjectScoreInfoList.add(subjectScoreInfo2);
        hisSubjectScoreInfoVO.setSubjectScoreInfo(subjectScoreInfoList);
        historyScoreInfo.add(hisSubjectScoreInfoVO);
        return historyScoreInfo;
    }

    *//**
     * 设置各学科成绩情况
     * @return
     *//*
    private List<SubjectScoreInfoVO> setEachSubjectScoreInfo() {
        List<SubjectScoreInfoVO> list = new ArrayList<>();
        SubjectScoreInfoVO subjectScoreInfoVO = new SubjectScoreInfoVO();
        subjectScoreInfoVO.setSubjectName("语文");
        subjectScoreInfoVO.setScore(99d);
        subjectScoreInfoVO.setTotalScore(150d);
        //本校
        subjectScoreInfoVO.setSchoolTop(120d);
        subjectScoreInfoVO.setSchoolAvg(101d);
        subjectScoreInfoVO.setSchoolNum(300);
        subjectScoreInfoVO.setSchoolRank(44);
        subjectScoreInfoVO.setSchoolScorePercent("30.12%");
        //全校
        subjectScoreInfoVO.setAllTop(142d);
        subjectScoreInfoVO.setAllAvg(125d);
        subjectScoreInfoVO.setAllNum(1254);
        subjectScoreInfoVO.setAllRank(552);
        subjectScoreInfoVO.setAllScorePercent("41.12%");
        list.add(subjectScoreInfoVO);
        return list;
    }

    *//**
     * 设置所有科目汇总成绩
     * @return
     *//*
    private SubjectScoreInfoVO setAllSubjectScoreInfo() {
        SubjectScoreInfoVO subjectScoreInfoVO = new SubjectScoreInfoVO();
        subjectScoreInfoVO.setSubjectName("所有学科");
        subjectScoreInfoVO.setScore(333d);
        subjectScoreInfoVO.setTotalScore(750d);
        //本校
        subjectScoreInfoVO.setSchoolTop(400d);
        subjectScoreInfoVO.setSchoolAvg(343d);
        subjectScoreInfoVO.setSchoolNum(200);
        subjectScoreInfoVO.setSchoolRank(44);
        subjectScoreInfoVO.setSchoolScorePercent("30.12%");
        //全校
        subjectScoreInfoVO.setAllTop(500d);
        subjectScoreInfoVO.setAllAvg(421d);
        subjectScoreInfoVO.setAllNum(1254);
        subjectScoreInfoVO.setAllRank(552);
        subjectScoreInfoVO.setAllScorePercent("41.12%");
        return subjectScoreInfoVO;
    }

    *//**
     * 设置三科汇总成绩
     * @return
     *//*
    private SubjectScoreInfoVO setThreeSubjectScoreInfo() {
        SubjectScoreInfoVO subjectScoreInfoVO = new SubjectScoreInfoVO();
        subjectScoreInfoVO.setSubjectName("语数英");
        subjectScoreInfoVO.setScore(99d);
        subjectScoreInfoVO.setTotalScore(150d);
        //本校
        subjectScoreInfoVO.setSchoolTop(123d);
        subjectScoreInfoVO.setSchoolAvg(101d);
        subjectScoreInfoVO.setSchoolNum(200);
        subjectScoreInfoVO.setSchoolRank(3);
        subjectScoreInfoVO.setSchoolScorePercent("30.12%");
        //全校
        subjectScoreInfoVO.setAllTop(140d);
        subjectScoreInfoVO.setAllAvg(112d);
        subjectScoreInfoVO.setAllRank(134);
        subjectScoreInfoVO.setAllNum(333);
        subjectScoreInfoVO.setAllScorePercent("45.12%");
        return subjectScoreInfoVO;
    }*/

    private Integer getUserId(){
        JWTInfo jwt = BaseContextHandle.getJWTInfo();
        if(null != jwt && StringUtil.isNotEmpty(jwt.getUserId())){
            return Integer.valueOf(jwt.getUserId());
        }else {
            throw new CoreException(AppErrorEnum.E_10018);
        }
    }
}
