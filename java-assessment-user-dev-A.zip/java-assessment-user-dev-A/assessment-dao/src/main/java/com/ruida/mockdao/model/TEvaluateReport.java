package com.ruida.mockdao.model;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;
import java.util.Date;

/**
 * @description: 升学选拔报告详情数据库实体
 * @author: kgz
 * @date: 2020/12/17
 */
@TableName("t_evaluate_report")
public class TEvaluateReport implements Serializable {
    /**
     * 试卷id
     */
    @TableId
    private Integer id;

    /**
     * 报告id
     */
    private Integer reportId;

    /**
     * 报告名称
     */
    private String reportName;

    /**
     * 用户id
     */
    private Integer userId;

    /**
     * 用户名称
     */
    private String userName;

    /**
     * 科目名称
     */
    private String subjectName;

    /**
     * 班级名称
     */
    private String className;

    /**
     * 学校名称
     */
    private String schoolName;

    /**
     * 本次测试成绩信息
     */
    private String currentScoreInfo;

    /**
     * 历次统一测试成绩信息
     */
    private String historyScoreInfo;

    /**
     * 历次学校测试成绩信息
     */
    private String historySchoolScoreInfo;

    private Integer createBy;

    private Date createTime;

    private Integer updateBy;

    private Date updateTime;

    private Integer isdelete;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getReportId() {
        return reportId;
    }

    public void setReportId(Integer reportId) {
        this.reportId = reportId;
    }

    public String getReportName() {
        return reportName;
    }

    public void setReportName(String reportName) {
        this.reportName = reportName;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getSubjectName() {
        return subjectName;
    }

    public void setSubjectName(String subjectName) {
        this.subjectName = subjectName;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public String getSchoolName() {
        return schoolName;
    }

    public void setSchoolName(String schoolName) {
        this.schoolName = schoolName;
    }

    public String getCurrentScoreInfo() {
        return currentScoreInfo;
    }

    public void setCurrentScoreInfo(String currentScoreInfo) {
        this.currentScoreInfo = currentScoreInfo;
    }

    public String getHistoryScoreInfo() {
        return historyScoreInfo;
    }

    public void setHistoryScoreInfo(String historyScoreInfo) {
        this.historyScoreInfo = historyScoreInfo;
    }

    public String getHistorySchoolScoreInfo() {
        return historySchoolScoreInfo;
    }

    public void setHistorySchoolScoreInfo(String historySchoolScoreInfo) {
        this.historySchoolScoreInfo = historySchoolScoreInfo;
    }

    public Integer getCreateBy() {
        return createBy;
    }

    public void setCreateBy(Integer createBy) {
        this.createBy = createBy;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(Integer updateBy) {
        this.updateBy = updateBy;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getIsdelete() {
        return isdelete;
    }

    public void setIsdelete(Integer isdelete) {
        this.isdelete = isdelete;
    }

    @Override
    public String toString() {
        return "TEvaluateReport{" +
                "id=" + id +
                ", reportId=" + reportId +
                ", reportName='" + reportName + '\'' +
                ", userId=" + userId +
                ", userName='" + userName + '\'' +
                ", subjectName='" + subjectName + '\'' +
                ", className='" + className + '\'' +
                ", schoolName='" + schoolName + '\'' +
                ", currentScoreInfo='" + currentScoreInfo + '\'' +
                ", historyScoreInfo='" + historyScoreInfo + '\'' +
                ", historySchoolScoreInfo='" + historySchoolScoreInfo + '\'' +
                ", createBy=" + createBy +
                ", createTime=" + createTime +
                ", updateBy=" + updateBy +
                ", updateTime=" + updateTime +
                ", isdelete=" + isdelete +
                '}';
    }
}
