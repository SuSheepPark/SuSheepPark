package com.ruida.cloud.dao;

import com.ruida.cloud.model.CoursePackageCourseRel;
import com.ruida.cloud.model.CoursePackageCourseRelExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface CoursePackageCourseRelMapper {
    long countByExample(CoursePackageCourseRelExample example);

    int deleteByExample(CoursePackageCourseRelExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(CoursePackageCourseRel record);

    int insertSelective(CoursePackageCourseRel record);

    List<CoursePackageCourseRel> selectByExample(CoursePackageCourseRelExample example);

    CoursePackageCourseRel selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") CoursePackageCourseRel record, @Param("example") CoursePackageCourseRelExample example);

    int updateByExample(@Param("record") CoursePackageCourseRel record, @Param("example") CoursePackageCourseRelExample example);

    int updateByPrimaryKeySelective(CoursePackageCourseRel record);

    int updateByPrimaryKey(CoursePackageCourseRel record);

    List<Map<String, Object>> listCoursePackageCourseRel(Integer courseId);

    List<String> listCoursePackageCourseRelIds(Integer courseId);

    void updateCoursePackageCourseRel(Map param);
}