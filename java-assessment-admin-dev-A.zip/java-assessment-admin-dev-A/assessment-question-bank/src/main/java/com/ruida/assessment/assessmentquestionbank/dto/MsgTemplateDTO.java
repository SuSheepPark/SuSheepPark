package com.ruida.assessment.assessmentquestionbank.dto;

import com.baomidou.mybatisplus.annotations.TableId;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * @description: 消息模板DTO
 * @author: kgz
 * @date: 2020/7/21
 */
@ApiModel(description = "消息模板信息")
public class MsgTemplateDTO {

    @ApiModelProperty(value = "消息模板id", name = "messageTplId")
    private Integer messageTplId;

    @ApiModelProperty(value = "标签", name = "tag")
    private String tag;

    @ApiModelProperty(value = "消息模板类型", name = "messageTplType")
    private Integer messageTplType;

    @ApiModelProperty(value = "消息模板编号", name = "messageTplNo")
    private Integer messageTplNo;

    @ApiModelProperty(value = "消息模板信息", name = "message")
    private String message;

    @ApiModelProperty(value = "是否弹出消息模板", name = "forpop")
    private Integer forpop;


    public Integer getMessageTplId() {
        return messageTplId;
    }

    public void setMessageTplId(Integer messageTplId) {
        this.messageTplId = messageTplId;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public Integer getMessageTplType() {
        return messageTplType;
    }

    public void setMessageTplType(Integer messageTplType) {
        this.messageTplType = messageTplType;
    }

    public Integer getMessageTplNo() {
        return messageTplNo;
    }

    public void setMessageTplNo(Integer messageTplNo) {
        this.messageTplNo = messageTplNo;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Integer getForpop() {
        return forpop;
    }

    public void setForpop(Integer forpop) {
        this.forpop = forpop;
    }

    @Override
    public String toString() {
        return "MsgTemplateDTO{" +
                "messageTplId=" + messageTplId +
                ", tag='" + tag + '\'' +
                ", messageTplType=" + messageTplType +
                ", messageTplNo=" + messageTplNo +
                ", message='" + message + '\'' +
                ", forpop=" + forpop +
                '}';
    }
}
