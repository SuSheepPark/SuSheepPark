package com.ruida.cloud.dao;

import com.ruida.cloud.model.TBroadcastRoom;
import com.ruida.cloud.model.TBroadcastRoomExample;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * 直播间表 Mapper 接口
 * </p>
 *
 * @author mlzhang
 * @since 2019-04-04
 */
public interface TBroadcastRoomMapper {
    long countByExample(TBroadcastRoomExample example);

    int deleteByExample(TBroadcastRoomExample example);

    int deleteByPrimaryKey(Integer broadcastRoomId);

    int insert(TBroadcastRoom record);

    int insertSelective(TBroadcastRoom record);

    List<TBroadcastRoom> selectByExample(TBroadcastRoomExample example);

    TBroadcastRoom selectByPrimaryKey(Integer broadcastRoomId);

    int updateByExampleSelective(@Param("record") TBroadcastRoom record, @Param("example") TBroadcastRoomExample example);

    int updateByExample(@Param("record") TBroadcastRoom record, @Param("example") TBroadcastRoomExample example);

    int updateByPrimaryKeySelective(TBroadcastRoom record);

    int updateByPrimaryKey(TBroadcastRoom record);

    @Select("SELECT\n" +
            "\ta.broadcast_room_id AS broadcastRoomId,\n" +
            "\ta.broadcast_room_name AS broadcastRoomName, a.status ,\n" +
            "( case a.status   when  0 then  '禁用'\n" +
            " else '启用' end ) zt\n" +
            "  \n" +
            "FROM\n" +
            "\tt_broadcast_room a\n" +
            "WHERE\n" +
            "\ta.isdelete = 0")
    List<Map<String, Object>> getTBroadcastRoom();

    @Update("update t_broadcast_room set status = #{type} ,  " +
            " update_by = #{userId} ," +
            " update_time =#{createTime} where broadcast_room_id =#{broadcastRoomId} ")
    Integer updateStatus(@Param("broadcastRoomId") Integer broadcastRoomId, @Param("userId") Integer userId, @Param("createTime") Date createTime, @Param("type") Integer type);

    @Select("SELECT\n" +
            "\ta.broadcast_room_id AS broadcastRoomId,\n" +
            "\ta.broadcast_room_name AS broadcastRoomName, a.status ,\n" +
            "( case a.status   when  0 then  '禁用'\n" +
            " else '启用' end ) zt\n" +
            "  \n" +
            "FROM\n" +
            "\tt_broadcast_room a\n" +
            "WHERE\n" +
            "\ta.isdelete = 0 and broadcast_room_id =#{broadcastRoomId}")
   Map<String, Object> getTBroadcastRoomById(@Param("broadcastRoomId") Integer id);

    @Select("SELECT\n" +
            "\ta.broadcast_room_id AS broadcastRoomId,\n" +
            "\ta.broadcast_room_name AS broadcastRoomName, a.status ,\n" +
            "( case a.status   when  0 then  '禁用'\n" +
            " else '启用' end ) zt\n" +
            "  \n" +
            "FROM\n" +
            "\tt_broadcast_room a\n" +
            "WHERE\n" +
            "\ta.isdelete = 0"+"\tAND a.`status`=1 AND a.room_type =#{type}")
    List<Map<String, Object>> getValidTBroadcastRoom(@Param("type") Byte type);

    @Select("SELECT\n" +
            "  a.weidu_room_id\n" +
            "FROM\n" +
            "  t_broadcast_room a\n" +
            "WHERE\n" +
            "  \n" +
            "    a.`status` = 1\n" +
            "    AND a.isdelete = 0\n" +
            "  \n" +
            "and a.broadcast_room_id != #{broadcastRoomId}")
    List<Integer> selectVdyooRoomIds(@Param("broadcastRoomId") Integer broadcastRoomId);
}
