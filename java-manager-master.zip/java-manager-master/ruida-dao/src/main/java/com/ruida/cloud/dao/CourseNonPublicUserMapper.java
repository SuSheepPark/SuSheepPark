package com.ruida.cloud.dao;

import com.ruida.cloud.model.CourseNonPublicUser;
import com.ruida.cloud.model.CourseNonPublicUserExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface CourseNonPublicUserMapper {
    int countByExample(CourseNonPublicUserExample example);

    int deleteByExample(CourseNonPublicUserExample example);

    int deleteByPrimaryKey(Integer nonPublicId);

    int insert(CourseNonPublicUser record);

    int insertSelective(CourseNonPublicUser record);

    List<CourseNonPublicUser> selectByExample(CourseNonPublicUserExample example);

    CourseNonPublicUser selectByPrimaryKey(Integer nonPublicId);

    int updateByExampleSelective(@Param("record") CourseNonPublicUser record, @Param("example") CourseNonPublicUserExample example);

    int updateByExample(@Param("record") CourseNonPublicUser record, @Param("example") CourseNonPublicUserExample example);

    int updateByPrimaryKeySelective(CourseNonPublicUser record);

    int updateByPrimaryKey(CourseNonPublicUser record);


    List<CourseNonPublicUser> listNonPublicUser(Integer courseId);

    //批量插入
    int insertBatch(List<CourseNonPublicUser> userList);

}