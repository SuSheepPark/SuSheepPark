package com.ruida.mockservice.service;

import com.baomidou.mybatisplus.service.IService;
import com.ruida.mockcommon.enums.MessageTplEnum;
import com.ruida.mockcommon.result.Page;
import com.ruida.mockcommon.result.PageResult;
import com.ruida.mockdao.model.UserMessage;

import java.util.Map;

public interface UserMessageService extends IService<UserMessage> {
    /**
     *
     * @param messageTplEnum
     * @param params
     * @return  生成一条消息
     */
    boolean insertMessage(MessageTplEnum messageTplEnum, Integer userId , String...params);

    boolean updateRead(Integer userMessageId);

    boolean readAllNews();

    boolean deleteMessage(Integer userMessageId);

    UserMessage getTUserMessageById(Integer userMessageId);

    PageResult<UserMessage> getMessageList(Page<UserMessage> messagePage);

    /**
     *
     * @param messageTplEnum
     * @return  生成一条新消息
     */
    boolean insertNewMessage(MessageTplEnum messageTplEnum, Integer userId, Map<String, Object> map);
}
