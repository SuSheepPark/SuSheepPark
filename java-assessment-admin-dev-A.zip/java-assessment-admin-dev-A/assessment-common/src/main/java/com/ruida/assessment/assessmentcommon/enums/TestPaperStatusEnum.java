package com.ruida.assessment.assessmentcommon.enums;

/**
 * @description: 试卷状态枚举
 * @author: kgz
 * @date: 2020/6/30
 */
public enum TestPaperStatusEnum {
    ROUGH_DRAFT(1,"草稿"),
    CHECKING(2,"待审核"),
    RELEASED(3,"已发布"),
    RELEASED_CANCEL(4,"已取消发布"),
    ;


    private Integer K;
    private String V;

    TestPaperStatusEnum(Integer k, String v) {
        K = k;
        V = v;
    }

    public Integer getK() {
        return K;
    }

    public void setK(Integer k) {
        K = k;
    }

    public String getV() {
        return V;
    }

    public void setV(String v) {
        V = v;
    }

    public static TestPaperStatusEnum getValueById(Integer K){
        for(TestPaperStatusEnum testPaperStatusEnum : TestPaperStatusEnum.values() ){
            if(testPaperStatusEnum.getK().equals(K)){
                return  testPaperStatusEnum;
            }
        }
        return null;
    }

}
