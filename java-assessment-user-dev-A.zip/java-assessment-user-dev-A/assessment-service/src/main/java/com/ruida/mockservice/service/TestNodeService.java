package com.ruida.mockservice.service;

import com.baomidou.mybatisplus.service.IService;
import com.ruida.mockdao.model.TestNode;

/**
 * Created by xumingqi on 2021/7/21 17:47
 */
public interface TestNodeService extends IService<TestNode> {
}
