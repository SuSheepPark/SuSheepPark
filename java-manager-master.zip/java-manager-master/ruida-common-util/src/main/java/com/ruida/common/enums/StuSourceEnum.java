package com.ruida.common.enums;

import java.util.LinkedHashMap;
import java.util.Map;

public enum StuSourceEnum {
    //学生来源渠道   0—pc端，1—Android端，2—IOS端，3—线下导入
    PC(0, "PC端"), ANDROID(1, "Android端"), IOS(2, "IOS端"), UNDERLINE(3, "线下导入");
    private Integer k;
    private String v;

    StuSourceEnum(Integer k, String v) {
        this.k = k;
        this.v = v;
    }

    public static Map<Integer, String> map = new LinkedHashMap<>(2);

    static {
        for (StuSourceEnum type : StuSourceEnum.values()) {
            map.put(type.getK(), type.getV());
        }
    }

    public static String getValueForK(Integer k) {
        StuSourceEnum[] ary = StuSourceEnum.values();
        for (StuSourceEnum stuSourceEnum : ary) {
            if (stuSourceEnum.k.equals(k)) {
                return stuSourceEnum.v;
            }
        }
        return "";
    }

    public Integer getK() {
        return k;
    }

    public void setK(Integer k) {
        this.k = k;
    }

    public String getV() {
        return v;
    }

    public void setV(String v) {
        this.v = v;
    }
}
