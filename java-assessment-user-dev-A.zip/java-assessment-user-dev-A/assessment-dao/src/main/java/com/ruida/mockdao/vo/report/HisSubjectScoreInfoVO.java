package com.ruida.mockdao.vo.report;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;
import java.util.List;

/**
 * @description: 历史科目得分情况VO
 * @author: kgz
 * @date: 2020/12/22
 */
@ApiModel(description = "历史科目得分情况VO")
public class HisSubjectScoreInfoVO implements Serializable {

    @ApiModelProperty(value = "科目id", name = "subjectId")
    private Integer subjectId;

    @ApiModelProperty(value = "科目名称", name = "subjectName")
    private String subjectName;

    @ApiModelProperty(value = "赋分平均值", name = "calculateScoreAvg")
    private Double calculateScoreAvg;

    @ApiModelProperty(value = "科目得分情况", name = "subjectScoreInfo")
    private List<SubjectScoreInfoVO> subjectScoreInfo;

    public Integer getSubjectId() {
        return subjectId;
    }

    public void setSubjectId(Integer subjectId) {
        this.subjectId = subjectId;
    }

    public Double getCalculateScoreAvg() {
        return calculateScoreAvg;
    }

    public void setCalculateScoreAvg(Double calculateScoreAvg) {
        this.calculateScoreAvg = calculateScoreAvg;
    }

    public String getSubjectName() {
        return subjectName;
    }

    public void setSubjectName(String subjectName) {
        this.subjectName = subjectName;
    }

    public List<SubjectScoreInfoVO> getSubjectScoreInfo() {
        return subjectScoreInfo;
    }

    public void setSubjectScoreInfo(List<SubjectScoreInfoVO> subjectScoreInfo) {
        this.subjectScoreInfo = subjectScoreInfo;
    }
}
