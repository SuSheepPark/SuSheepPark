package com.ruida.assessment.assessmentquestionbank.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * @description: 模板操作DTO
 * @author: kgz
 * @date: 2020/7/23
 */
@ApiModel(description = "消息模板操作")
public class MsgTemplateOperationDTO {

    @ApiModelProperty(value = "消息模板id", name = "messageTplId", required = true)
    private Integer messageTplId;

    @ApiModelProperty(value = "操作id", name = "operationId", required = true)
    private Integer operationId;

    public Integer getMessageTplId() {
        return messageTplId;
    }

    public void setMessageTplId(Integer messageTplId) {
        this.messageTplId = messageTplId;
    }

    public Integer getOperationId() {
        return operationId;
    }

    public void setOperationId(Integer operationId) {
        this.operationId = operationId;
    }

    @Override
    public String toString() {
        return "MsgTemplateOperationDTO{" +
                "messageTplId='" + messageTplId + '\'' +
                ", operationId=" + operationId +
                '}';
    }
}
