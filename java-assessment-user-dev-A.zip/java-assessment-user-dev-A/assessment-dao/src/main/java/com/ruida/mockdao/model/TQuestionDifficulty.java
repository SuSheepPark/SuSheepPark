package com.ruida.mockdao.model;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;

/**
 * @description: 难度等级数据库实体
 * @author: kgz
 * @date: 2020/6/9
 */
@TableName("t_question_difficulty")
@Data
@EqualsAndHashCode(callSuper = false)
public class TQuestionDifficulty  implements Serializable {

    /**
     * 题型id
     */
    @TableId
    private Integer id;

    /**
     * 难度等级名称
     */
    private String questionDifficultyName;

    /**
     * 状态（0—禁用；1—启用）
     */
    private String status;


}
