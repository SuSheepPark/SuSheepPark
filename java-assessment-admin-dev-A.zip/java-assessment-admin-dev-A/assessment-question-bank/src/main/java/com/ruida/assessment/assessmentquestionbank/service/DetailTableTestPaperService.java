package com.ruida.assessment.assessmentquestionbank.service;

import com.ruida.assessment.assessmentcommon.result.Page;
import com.ruida.assessment.assessmentcommon.result.PojoResult;
import com.ruida.assessment.assessmentquestionbank.dto.QuestionQueryDTO;
import com.ruida.assessment.assessmentquestionbank.vo.QuestionInfoVO;
import org.springframework.web.multipart.MultipartFile;

public interface DetailTableTestPaperService {
    /**
     * 导入细目表
     * @param file
     * @return
     */
    PojoResult importDeatailTable(MultipartFile file, Integer testPaperId);
    Page<QuestionInfoVO> nextQuestion(QuestionQueryDTO questionQueryDTO);

    /**
     * 换题
     * @param qrignId
     * @param nextId
     * @param testPaperId
     */
    boolean saveNextQue(String qrignId,String nextId,Integer testPaperId);
}
