package com.ruida.mockdao.vo.error;

import com.ruida.mockdao.vo.QuestionVO;
import lombok.Data;

import java.util.List;

/**
 * @description:
 * @author: chenjy
 * @create: 2020-10-19 11:29
 */
@Data
public class QuestionTypeVO {

    private Integer questionTypeId;

    private String questionTypeName;

    private List<QuestionVO> questionList;
}
