package com.ruida.assessment.assessmentquestionbank.model;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;

import java.io.Serializable;

/**
 * @description: 试题知识点关联关系数据库实体
 * @author: kgz
 * @date: 2020/6/12
 */
@TableName("t_question_knowledge_relation")
public class TQuestionKnowledgeRelation extends BaseColumn implements Serializable {
    private static final long serialVersionUID = -5661730526281579595L;

    /**
     * 试题知识点关系id
     */
    @TableId
    private Integer id;

    /**
     * 试题id
     */
    private String questionLibraryId;

    /**
     * 知识点id
     */
    private Integer knowledgeId;

    /**
     * 知识点分值
     */
    private Integer knowledgePoints;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getQuestionLibraryId() {
        return questionLibraryId;
    }

    public void setQuestionLibraryId(String questionLibraryId) {
        this.questionLibraryId = questionLibraryId;
    }

    public Integer getKnowledgeId() {
        return knowledgeId;
    }

    public void setKnowledgeId(Integer knowledgeId) {
        this.knowledgeId = knowledgeId;
    }

    public Integer getKnowledgePoints() {
        return knowledgePoints;
    }

    public void setKnowledgePoints(Integer knowledgePoints) {
        this.knowledgePoints = knowledgePoints;
    }

    @Override
    public String toString() {
        return "TQuestionKnowledgeRelation{" +
                "id=" + id +
                ", questionLibraryId=" + questionLibraryId +
                ", knowledgeId=" + knowledgeId +
                ", knowledgePoints=" + knowledgePoints +
                super.toString() +
                '}';
    }
}
