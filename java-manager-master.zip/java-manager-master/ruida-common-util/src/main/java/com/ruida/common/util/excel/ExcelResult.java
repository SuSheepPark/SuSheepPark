package com.ruida.common.util.excel;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2017/4/20.
 */
public class ExcelResult<T> {

    T successRow;

    String errorMsg;

    List<String> orginColumns = new ArrayList<String>();

    public T getSuccessRow() {
        return successRow;
    }

    public void setSuccessRow(T successRow) {
        this.successRow = successRow;
    }

    public String getErrorMsg() {
        return errorMsg;
    }

    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }

    public List<String> getOrginColumns() {
        return orginColumns;
    }

    public void setOrginColumns(List<String> orginColumns) {
        this.orginColumns = orginColumns;
    }
}
