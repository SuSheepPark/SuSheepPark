package com.ruida.mockservice.service.impl;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.ruida.mockcommon.auth.context.BaseContextHandle;
import com.ruida.mockcommon.auth.pojo.JWTInfo;
import com.ruida.mockcommon.enums.AnswerStatusEnum;
import com.ruida.mockcommon.enums.AppErrorEnum;
import com.ruida.mockcommon.exception.CoreException;
import com.ruida.mockdao.dao.ExamDetailMapper;
import com.ruida.mockdao.dao.ExamRecordMapper;
import com.ruida.mockdao.dao.TestNodeQuestionRelMapper;
import com.ruida.mockdao.dao.TestPaperProductRelMapper;
import com.ruida.mockdao.model.ExamDetail;
import com.ruida.mockdao.model.ExamRecord;
import com.ruida.mockdao.model.TestPaper;
import com.ruida.mockdao.model.TestPaperProductRel;
import com.ruida.mockdao.vo.NodeVO;
import com.ruida.mockservice.service.ExamDetailService;
import com.ruida.mockservice.service.ExamRecordService;
import com.ruida.mockservice.service.TestPaperProductRelService;
import com.ruida.mockservice.service.TestPaperService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * 考试详情表 服务实现类
 * </p>
 *
 * @author chenjy
 * @since 2020-07-15
 */
@Service
@Slf4j
public class ExamDetailServiceImpl extends ServiceImpl<ExamDetailMapper, ExamDetail> implements ExamDetailService {

    @Resource
    ExamRecordMapper examRecordMapper;
    @Resource
    ExamDetailMapper examDetailMapper;
    @Resource
    TestNodeQuestionRelMapper testNodeQuestionRelMapper;
    @Resource
    TestPaperProductRelMapper testPaperProductRelMapper;
    @Resource
    TestPaperService testPaperService;
    @Resource
    TestPaperProductRelService testPaperProductRelService;

    @Override
    public List<NodeVO> getAnswerSheet(Integer examRecordId) {
        return examDetailMapper.getAnswerSheet(examRecordId);
    }

    @Override
    public Map<String,Object> getAnalysis(Integer examRecordId, Integer productId, Integer testPaperId, String questionId) {
        JWTInfo jwt = BaseContextHandle.getJWTInfo();

        Map<String, Object> resultMap = new HashMap<>();
        Map<String, Object> param = new HashMap<>();

        param.put("questionId", questionId);
        param.put("userId", jwt.getUserId());

        ExamRecord record = null;
        if (examRecordId != null) {
            record = examRecordMapper.selectById(examRecordId);
            //判断考试记录是否为本人的考试记录
            if (!record.getCreateBy().equals(Integer.valueOf(jwt.getUserId()))) throw new CoreException(AppErrorEnum.E_60006);
            testPaperId = record.getTestPaperId();
            //判断是否购买过该商品试卷
            testPaperService.checkUserBuyPaper(record.getProductId(), testPaperId, Integer.valueOf(jwt.getUserId()));
        }else {
            //判断是否购买过该商品试卷
            testPaperService.checkUserBuyPaper(productId, testPaperId, Integer.valueOf(jwt.getUserId()));
            EntityWrapper<ExamRecord> wrapper = new EntityWrapper<>();
            wrapper.andNew().eq("product_id",productId)
                    .eq("test_paper_id",testPaperId)
                    .eq("status",0)
                    .eq("create_by",jwt.getUserId())
                    .orderBy("create_time",false);
            List<ExamRecord> records = examRecordMapper.selectList(wrapper);
            if(!CollectionUtils.isEmpty(records)){
                //参加过考试 有考试记录 默认查询最新一条
                record = records.stream().findFirst().get();
            }else {
                //record为空，未参加考试
                TestPaperProductRel testPaperProductRel =  testPaperProductRelMapper.selectByProductAndPaperId(productId,testPaperId);
                if(testPaperProductRel.getTestWay() == 2 || testPaperProductRel.getTestWay() == 3){
                    //统考类型，判断考试时间是否结束
                    LocalDateTime nowTime = LocalDateTime.now();
                    Instant instant = testPaperProductRel.getTestEndTime().toInstant();
                    ZoneId zoneId = ZoneId.systemDefault();
                    LocalDateTime testEndTime = instant.atZone(zoneId).toLocalDateTime();

                    if(nowTime.isBefore(testEndTime)){
                        throw new CoreException(AppErrorEnum.E_60003);
                    }
                }else {
                    //非统考类型没有考试记录不能查看解析
                    throw new CoreException(AppErrorEnum.E_60004);
                }
            }
        }

        TestPaper testPaper = testPaperService.selectById(testPaperId);

        param.put("testPaperId",testPaperId);

        List<NodeVO> nodeList;

        if(null != record){
            resultMap.put("examRecordId",record.getId());
            resultMap.put("duration",record.getDuration());
            resultMap.put("score",record.getScore());
            resultMap.put("testPaperScore",testPaper.getScore());
            resultMap.put("answerWay",testPaper.getAnswerWay());

            //需要人工批改的试题中还有未批改的不能查看解析
            if(StringUtils.isEmpty(questionId) && record.getTimes() == 1 && containUncorrectQuestion(record)){
                throw new CoreException(AppErrorEnum.E_60002);
            }

            param.put("examRecordId",record.getId());
            nodeList = examDetailMapper.getAnalysis(param);
        }else {
            //统考时间过了，当前用户没有参加，也能查看解析 查看的是整张试卷的正确答案解析(目前没有统考了 这种情况不会出现 保留)
            nodeList = testNodeQuestionRelMapper.analysisTestPaper(param);
        }

        nodeList.forEach(n -> n.getQuestionList().forEach(q ->testPaperService.handleQuestionVO(q)));

        resultMap.put("nodeList",nodeList);
        resultMap.put("testPaperId",testPaper.getTestPaperId());
        resultMap.put("testPaperName",testPaper.getTestPaperName());
        return resultMap;
    }

    @Override
    public boolean containUncorrectQuestion(ExamRecord record) {
        //首先判断试卷是否需要人工批阅
        /*TestPaperProductRel testPaperProductRel = testPaperProductRelService.selectOne(new EntityWrapper<TestPaperProductRel>()
                .eq("product_id",record.getProductId())
                .eq("test_paper_id",record.getTestPaperId())
                .eq("isdelete",0));*/
//        if(testPaperProductRel.getIsartificial() == 1){
            // 某张试卷第一次测试需要检查是否包含未作的试题
            EntityWrapper<ExamDetail> ew = new EntityWrapper<>();
            ew.andNew().eq("exam_record_id", record.getId());
            List<ExamDetail> detailList = examDetailMapper.selectList(ew);
            if (detailList.stream().anyMatch(x -> x.getStatus() == AnswerStatusEnum.UC.getK())) return true;
//        }
        return false;
    }
}
