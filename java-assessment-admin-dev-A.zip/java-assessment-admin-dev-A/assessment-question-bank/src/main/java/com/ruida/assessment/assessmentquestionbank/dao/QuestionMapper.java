package com.ruida.assessment.assessmentquestionbank.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.assessment.assessmentquestionbank.dto.QuestionQueryDTO;
import com.ruida.assessment.assessmentquestionbank.model.TQuestionLibrary;
import com.ruida.assessment.assessmentquestionbank.vo.QuestionInfoVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * @description: 试题dao接口
 * @author: kgz
 * @date: 2020/6/8
 */
@Mapper
public interface QuestionMapper extends BaseMapper<TQuestionLibrary> {

    /**
     * 根据id获取试题信息
     * @param id
     * @return
     */
    QuestionInfoVO getQuestionInfoById(@Param("id") String id);

    /**
     * 根据父级id获取子级试题信息
     * @param parentId
     * @return
     */
    List<QuestionInfoVO> getChildrenQuestionByParentId(@Param("parentId") String parentId);

    /**
     * 分页查询试题列表
     * @param questionQueryDTO
     * @return
     */
    List<QuestionInfoVO> getQuestionList(QuestionQueryDTO questionQueryDTO);

    /**
     * 试题列表总数
     * @param questionQueryDTO
     * @return
     */
    Integer getQuestionListCount(QuestionQueryDTO questionQueryDTO);

    /**
     * 获取试题id最大值
     * @return
     * @param date
     */
    String getMaxQuestionId(String date);

    /**
     * 获取组卷数
     * @param questionId
     * @param testPaperStatus
     * @return
     */
    Integer getPaperCount(@Param("questionId")String questionId, @Param("testPaperStatus")Integer testPaperStatus);

    /**
     * 获取组卷数
     * @param questionId
     * @param testPaperStatus
     * @return
     */
    List<String> getPaperIdList(@Param("questionId")String questionId, @Param("testPaperStatus")Integer testPaperStatus);

    /**
     * 获取组合体小题数量
     * @param questionQueryDTO
     * @return
     */
    Integer getCombineQueCount(QuestionQueryDTO questionQueryDTO);

    /**
     * 获取组合体小题列表
     * @param questionQueryDTO
     * @return
     */
    List<QuestionInfoVO> getCombineQueList(QuestionQueryDTO questionQueryDTO);
    /**
     * 细目表组题获取小题列表
     * @param questionQueryDTO
     * @return
     */
    List<QuestionInfoVO> getDetailTableQueList(QuestionQueryDTO questionQueryDTO);

    /**
     * 细目表组题试题数量
     * @param questionQueryDTO
     * @return
     */
    int getDetailTableQueCount(QuestionQueryDTO questionQueryDTO);

    /**
     * 细目表组卷组合体知识点列表筛选
     * @param questionQueryDTO
     * @return
     */
    List<Map<String,Object>> getCombineKnowledgeList(QuestionQueryDTO questionQueryDTO);

    /**
     * 查询试题的知识点
     * @param list
     * @return
     */
    List<String> queryKnowledge(List<String> list);
}
