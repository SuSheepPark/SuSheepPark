package com.ruida.mockdao.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.model.TEvaluateReport;
import com.ruida.mockdao.vo.report.UpgradeReportRecordVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @description:
 * @author: kgz
 * @date: 2020/12/24
 */
@Mapper
public interface EvaluateReportMapper extends BaseMapper<TEvaluateReport> {
    /**
     * 查询报告列表
     * @param pageIndex
     * @param pageSize
     * @param keyWords
     * @param userId
     * @return
     */
    List<UpgradeReportRecordVO> getUpgradeReportRecordList(@Param("pageIndex") int pageIndex, @Param("pageSize") int pageSize,
                                                           @Param("keyWords") String keyWords, @Param("userId") Integer userId);

    /**
     * 查询报告总数
     * @return
     * @param keyWords
     * @param userId
     */
    Integer getUpgradeReportRecordCount(@Param("keyWords") String keyWords, @Param("userId") Integer userId);
}
