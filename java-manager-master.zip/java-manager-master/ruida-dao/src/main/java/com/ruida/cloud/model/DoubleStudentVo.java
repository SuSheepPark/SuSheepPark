package com.ruida.cloud.model;

import lombok.Data;

/**
 * @author wy
 * @description: 添加课次请求测试类
 */

@Data
public class DoubleStudentVo {

    private Integer student_id;
    private String student_name;
    private String student_mobile;
    private Integer student_sex;
    private String student_sn;
    private Integer student_type;
}