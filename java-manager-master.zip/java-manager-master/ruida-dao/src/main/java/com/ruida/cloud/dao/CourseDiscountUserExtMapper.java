package com.ruida.cloud.dao;

import com.ruida.cloud.model.CourseDiscountUserExt;

import java.util.List;
import java.util.Map;

public interface CourseDiscountUserExtMapper {
    List<CourseDiscountUserExt> listDiscountUserByCourseId(Map condition);
}