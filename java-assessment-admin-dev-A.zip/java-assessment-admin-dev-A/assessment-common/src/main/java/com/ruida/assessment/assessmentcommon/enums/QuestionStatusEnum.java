package com.ruida.assessment.assessmentcommon.enums;

/**
 * @description: 试题状态，与操作对应
 * @author: kgz
 * @date: 2020/6/10
 */
public enum QuestionStatusEnum {
    ROUGH_DRAFT(1,"草稿"),
    CHECKING(2,"待审核"),
    RELEASED(3,"已发布"),
    RELEASED_CANCEL(4,"已取消发布"),
    ;


    private Integer K;
    private String V;

    QuestionStatusEnum(Integer k, String v) {
        K = k;
        V = v;
    }

    public Integer getK() {
        return K;
    }

    public void setK(Integer k) {
        K = k;
    }

    public String getV() {
        return V;
    }

    public void setV(String v) {
        V = v;
    }


    public static QuestionStatusEnum getValueById(Integer K){
        for(QuestionStatusEnum questionStatusEnum : QuestionStatusEnum.values() ){
            if(questionStatusEnum.getK().equals(K)){
                return  questionStatusEnum;
            }
        }
        return null;
    }

}
