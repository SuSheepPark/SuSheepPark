package com.ruida.mockdao.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.model.PresellTestPaper;
import org.apache.ibatis.annotations.Mapper;


@Mapper
public interface PresellTestPaperMapper extends BaseMapper<PresellTestPaper> {


}
