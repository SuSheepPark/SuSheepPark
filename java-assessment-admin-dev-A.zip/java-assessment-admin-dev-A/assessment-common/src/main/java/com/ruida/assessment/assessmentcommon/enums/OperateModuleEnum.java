package com.ruida.assessment.assessmentcommon.enums;

import java.util.ArrayList;
import java.util.List;

/**
 * @description: 操作模块，记录日志使用
 * @author: kgz
 * @date: 2020/8/11
 */
public enum OperateModuleEnum {
    QUESTION(1,"我的试题"),
    KNOWLEDGE(2,"知识点管理"),
    MATERIAL(3,"教材管理"),
    SECTION(4,"章节管理"),
    TESTPAPER(5,"我的试卷"),
    CORRECT(6,"我的批改"),
    CORRECT_ARRANGE(7,"批改设置"),
    PRODUCT(8,"商品管理"),
    RECOMMEND(9,"推荐位置"),
    BANNER(10,"banner管理"),
    SCHOOL(11,"学校管理"),
    CLASS(11,"班级管理"),
    STUDENT(12,"学员管理"),
    USER_FEEDBACK(13,"用户反馈"),
    ORDER(14,"订单中心"),
    BASIC_FIELD(15,"基础字段维护"),
    ROLE(16,"角色管理"),
    AUTH(17,"权限管理"),
    ACCOUNT(18,"后台用户账号"),
    PERSON_CONFIG(19,"个人设置"),
    MESSAGE_TEMPLATE(20,"消息模板"),
    MESSAGE_CUSTOM(21,"自定义消息"),
    HELP_CENTER(22,"帮助中心"),
    WEBSITE_CONFIG(23,"网站配置"),
    WEBSITE_LINK(24,"友情链接"),
    APP_UPDATE(25,"APP更新"),
    SENSITIVE_WORDS(26,"敏感词管理"),
    DEPARTMENT(27,"部门管理"),
    MENU(28,"菜单管理"),
    ACCOUNT_M(29,"账号管理"),
    ;


    private Integer id;
    private String module;

    OperateModuleEnum(Integer id, String module) {
        this.id = id;
        this.module = module;
    }

    /**
     * 获取操作模块列表
     * @return
     */
    public static List<String> getModules() {
        List<String> moduleList = new ArrayList<>();
        for(OperateModuleEnum operateModuleEnum : OperateModuleEnum.values() ){
            moduleList.add(operateModuleEnum.getModule());
        }
        return moduleList;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getModule() {
        return module;
    }

    public void setModule(String module) {
        this.module = module;
    }

    public static OperateModuleEnum getValueById(Integer id){
        for(OperateModuleEnum operateModuleEnum : OperateModuleEnum.values() ){
            if(operateModuleEnum.getId().equals(id)){
                return  operateModuleEnum;
            }
        }
        return null;
    }

}
