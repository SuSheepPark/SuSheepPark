package com.ruida.cloud.model;

import lombok.Data;

/**
 * @author wy
 * @description: 双师操作日志请求类
 */

@Data
public class DoubleOperateLogRequest {

    private String operateModule;
    private String syncType;
    private String operateObject;
    private String operateItem;
    private String operateStep;
    private Integer pageNo;
    private Integer pageSize;
    private Long start;
    private Integer size;
}