package com.ruida.mockdao.vo;

import lombok.Data;

import java.util.List;

/**
 * @description: 成绩查询商品VO
 * @author: chenjy
 * @create: 2020-10-09 10:08
 */
@Data
public class QueryScoreProductVO {

    private String productId;

    private String productName;

    List<QueryScorePaperVO> paperVOList;
}
