package com.ruida.common.util;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;

import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;


/**
 * 属性工具类
 */
public class PropertyMT extends PropertyPlaceholderConfigurer {

    public static final Logger logger = Logger.getLogger(PropertyMT.class);
    public static final String ROOT_NAME = "web.root"; //对应web.xml中的配置

    private static Map<String, String> propertyMap;

    @Override
    protected void processProperties(
            ConfigurableListableBeanFactory beanFactoryToProcess,
            Properties props) throws BeansException {
        final Properties systemProperties = System.getProperties();
        super.processProperties(beanFactoryToProcess, props);
        propertyMap = new HashMap<String, String>();
        for (Object key : props.keySet()) {
            String keyStr = key.toString();
            String value = props.getProperty(keyStr);
            propertyMap.put(keyStr, value);
            systemProperties.setProperty(keyStr,value);
        }
    }

    public static String getValue(String name) {
        String value = propertyMap.get(name);
        if (StringUtils.isBlank(value)) {
            String error = "属性[" + name + "]的值为空";
            logger.fatal(error);
            return "";
        } else {
            return value;
        }
    }

    public static String getRoot() {
        String cmsRoot = System.getProperty(ROOT_NAME);
        Enumeration<?> enu = System.getProperties().propertyNames();
        while (enu.hasMoreElements()) {
            Object key = enu.nextElement();
            if (key.toString().startsWith(ROOT_NAME)) {
                cmsRoot = System.getProperty(key.toString());
                break;
            }
        }
        logger.info(cmsRoot);
        return cmsRoot;
    }

    public static boolean isDev()
    {
        return "dev".equals(getValue("env"));
    }
}
