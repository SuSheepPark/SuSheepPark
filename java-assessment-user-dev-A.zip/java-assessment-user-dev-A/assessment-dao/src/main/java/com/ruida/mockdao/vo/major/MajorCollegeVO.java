package com.ruida.mockdao.vo.major;

import lombok.Data;

@Data
public class MajorCollegeVO {
    private Integer id;
    /**
     * 学校名称
     */
    private String collegeName;
    /**
     * 学校层级。1-清华北大；2-5所学校；3-一流大学；4-一流学科；5-一般本科院校；6-独立学院；7-高职院校
     */
    private Integer collegeLevel;
    /**
     * 层级名称
     */
    private String collegeLevelName;
    private String subjectCategoryName;
    private String subjectCategoryCode;
    private String majorCategoryName;
    private String majorCategoryCode;
    private String majorName;
    /**
     * 专业代码
     */
    private String majorCode;

    /**
     * 录取最高分
     */
    private Double maxScore;
    /**
     * 录取最低分
     */
    private Double minScore;
    /**
     * 学校录取最低分
     */
    private Double minAdmitScore;
    /**
     * 选考科目范围要求
     */
    private String subjectLimits;

    /**
     * 院校识别码
     */
    private String collegeCode;
    private Integer sort;


}
