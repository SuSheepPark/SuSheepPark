/**   
 * Copyright © 2019 公司名. All rights reserved.
 * 
 * @Title: CategoryServiceImpl.java 
 * @Prject: zhaowei-cms
 * @Package: com.zhaowei.cms.service 
 * @Description: TODO
 * @author: zw   
 * @date: 2019年9月17日 下午8:43:37 
 * @version: V1.0   
 */
package com.zhaowei.cms.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.zhaowei.cms.dao.CategoryMapper;
import com.zhaowei.cms.domain.Category;
import com.zhaowei.cms.service.CategoryService;

/** 
 * @ClassName: CategoryServiceImpl 
 * @Description: TODO
 * @author: zw
 * @date: 2019年9月17日 下午8:43:37  
 */
@Service
public class CategoryServiceImpl implements CategoryService {

	
	@Resource
	private CategoryMapper categoryMapper;
	
	/* (non Javadoc) 
	 * @Title: selectsByChannelId
	 * @Description: TODO
	 * @param cid
	 * @return 
	 * @see com.zhaowei.cms.service.CategoryService#selectsByChannelId(java.lang.Integer) 
	 */
	@Override
	public List<Category> selectsByChannelId(Integer cid) {
		// TODO Auto-generated method stub
		return categoryMapper.selectsByChannelId(cid);
	}

}
