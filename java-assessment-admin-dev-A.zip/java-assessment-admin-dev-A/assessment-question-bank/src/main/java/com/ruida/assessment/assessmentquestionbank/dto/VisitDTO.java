package com.ruida.assessment.assessmentquestionbank.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.Date;

/**
 * @description: 访客DTO
 * @author: kgz
 * @date: 2020/8/4
 */
@ApiModel(description = "访问信息")
public class VisitDTO {

    @ApiModelProperty(value = "访客信息", name = "visitor", required = true)
    private String visitor;

    @ApiModelProperty(value = "访问日期", name = "visitDate")
    private Date visitDate;

    public String getVisitor() {
        return visitor;
    }

    public void setVisitor(String visitor) {
        this.visitor = visitor;
    }

    public Date getVisitDate() {
        return visitDate;
    }

    public void setVisitDate(Date visitDate) {
        this.visitDate = visitDate;
    }

    @Override
    public String toString() {
        return "VisitDTO{" +
                "visitor='" + visitor + '\'' +
                "visitDate='" + visitDate + '\'' +
                '}';
    }
}
