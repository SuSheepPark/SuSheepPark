package com.ruida.mockdao.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @description: 我的考试记录
 * @author: jinhu
 * @create: 2020-07-13 13:10
 */
@Data
//@JsonInclude(value = JsonInclude.Include.NON_NULL)
public class MyExamRecordVO {

    /**
     * 试卷id
     */
    private Integer testPaperId;

    @ApiModelProperty(value = "考试记录id")
    private Integer examRecordId;

    /**
     * 试卷名称
     */
    private String testPaperName;

    @ApiModelProperty(value = "商品id")
    private Integer productId;

    @ApiModelProperty(value = "商品图片")
    private String productImg;

    @ApiModelProperty(value = "是否完成（0：交卷；1：未交卷）")
    private Integer status;

    @ApiModelProperty(value = "第几次测试 第一次的才有报告")
    private Integer times;

    @ApiModelProperty(value = "考试进度")
    private BigDecimal rate;

    @ApiModelProperty(value = "是否有报告(0：没有；1：有)")
    private Integer report;


    @ApiModelProperty(value = "已测试人数")
    private Integer initTestNum;


    @ApiModelProperty(value = "是否需要人工阅卷 0-否 1-是")
    private Integer isartificial;

    @ApiModelProperty(value = "试卷关联模板id，多个模板id用 , 拼接")
    private String paperReportIds;

    @ApiModelProperty(value = "试卷号")
    private String testPaperNo;

    @ApiModelProperty(value = "答题时长")
    private String testDuration;


    @ApiModelProperty(value = "学段id")
    private Integer periodId;

    @ApiModelProperty(value = "学段名称")
    private String periodName;

    @ApiModelProperty(value = "科目id")
    private String subjectId;

    @ApiModelProperty(value = "科目名称")
    private String subjectName;

    @ApiModelProperty(value = "教材版本id")
    private Integer versionId;

    @ApiModelProperty(value = "教材版本名称")
    private String versionName;

    @ApiModelProperty(value = "年级id")
    private Integer stageId;

    @ApiModelProperty(value = "年级名称")
    private String stageName;

    @ApiModelProperty(value = "年份")
    private String year;

    @ApiModelProperty(value = "难度")
    private Integer difficulty;

    @ApiModelProperty(value = "难度")
    private String difficultyName;

    @ApiModelProperty(value = "试卷类型")
    private Integer testPaperType;

    @ApiModelProperty(value = "试卷类型")
    private String testPaperTypeName;

    @ApiModelProperty(value = "考试类型")
    private Integer testType;

    @ApiModelProperty(value = "考试类型")
    private String testTypeName;


    @ApiModelProperty(value = "考试时间")
    @JsonFormat(pattern= "yyyy-MM-dd HH:mm",timezone="GMT+8")
    private Date createTime;


    @ApiModelProperty(value = "考试开始时间")
    @JsonFormat(pattern= "yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date testStartTime;

    @ApiModelProperty(value = "考试结束时间")
    @JsonFormat(pattern= "yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date testEndTime;

    @ApiModelProperty(value = "考试方式 0-练习 1-纸考 2-机房考 3-统考")
    private Integer testWay;


}
