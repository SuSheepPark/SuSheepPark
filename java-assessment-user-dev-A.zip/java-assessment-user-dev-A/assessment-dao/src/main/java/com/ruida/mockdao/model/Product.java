package com.ruida.mockdao.model;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableLogic;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * <p>
 * 商品表
 * </p>
 *
 * @author jinhu
 * @since 2020-07-08
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("t_product")
@ApiModel(value="Product对象", description="商品表")
public class Product implements Serializable {

    private static final long serialVersionUID = 1L;
    @ApiModelProperty(value = "商品id")
    @TableId(value = "product_id", type = IdType.AUTO)
    private Integer productId;

    @ApiModelProperty(value = "商品号")
    private String productNo;

    @ApiModelProperty(value = "商品名称")
    private String productName;

    @ApiModelProperty(value = "最低价格(多少元起)")
    private BigDecimal lowestPrice;

    @ApiModelProperty(value = "ios最低价格(多少元起)")
    private BigDecimal lowestIosPrice;

    @ApiModelProperty(value = "商品原始价格 划线价格")
    private BigDecimal productOriginPrice;

    @ApiModelProperty(value = "商品价格  安卓和PC")
    private BigDecimal productPrice;

    @ApiModelProperty(value = "商品价格  iOS")
    private BigDecimal productIosPrice;

    @ApiModelProperty(value = "是否免费(指该商品下所有试卷和报告都0元)")
    private Integer isfree;

    @ApiModelProperty(value = "初始化购买量")
    private Integer initBuyNum;

    @ApiModelProperty(value = "真实购买量（=初始化购买量+用户购买数量）")
    private Integer realBuyNum;

    @ApiModelProperty(value = "完成人数")
    private Integer completeNum;

    @ApiModelProperty(value = "商品图片")
    private String productImg;

    @ApiModelProperty(value = "商品描述 html格式")
    private String productInfoHtml;

    @ApiModelProperty(value = "测验形式(0-平时练习 1-纸考(线下联考) 2-机房统考 3-在线统考)")
    private Integer productTestWay;

    @ApiModelProperty(value = "是否隐藏 0-显示 1-隐藏")
    private Integer ishide;

    @ApiModelProperty(value = "试卷份数")
    private Integer paperNum;

//    @ApiModelProperty(value = "学段id")
//    private Integer periodId;

    @ApiModelProperty(value = "学段id列表，多个用英文逗号分隔")
    private String periodIds;

    @ApiModelProperty(value = "科目id列表，多个科目id用英文逗号拼接")
    private String subjectIds;

//    @ApiModelProperty(value = "教材版本id")
//    private Integer versionId;

    @ApiModelProperty(value = "教材版本id列表，多个用英文逗号分隔")
    private String versionIds;

//    @ApiModelProperty(value = "年级id")
//    private Integer gradeId;

//    @ApiModelProperty(value = "真实年级id")
//    private Integer gradeTrueId;

    @ApiModelProperty(value = "年级id列表，多个用英文逗号分隔")
    private String gradeIds;

    @ApiModelProperty(value = "真实年级id列表，多个用英文逗号分隔")
    private String trueGradeIds;

    @ApiModelProperty(value = "年份,多个年份用 | 拼接")
    private String years;

    @ApiModelProperty(value = "0-试卷 1-套卷 2-职业兴趣问卷 3-选科推荐报告 4-志愿填报报告")
    private Integer productType;

    @ApiModelProperty(value = "浏览量")
    private Integer browse;

    @ApiModelProperty(value = "退回原因")
    private String reason;

    @ApiModelProperty(value = "商品状态（0.已下架，1.已上架）")
    private Integer status;

    @ApiModelProperty(value = "是否置顶 0-未置顶 1-置顶")
    private Integer top;

    @ApiModelProperty(value = "置顶时间")
    private Date topTime;

    @ApiModelProperty(value = "创建人")
    private Integer createBy;

    @ApiModelProperty(value = "创建时间")
    private Date createTime;

    @ApiModelProperty(value = "更新者")
    private Integer updateBy;

    @ApiModelProperty(value = "更新时间")
    private Date updateTime;

    @ApiModelProperty(value = "删除符号 0-未删除 1-删除")
    @TableLogic
    private Integer isdelete;
}
