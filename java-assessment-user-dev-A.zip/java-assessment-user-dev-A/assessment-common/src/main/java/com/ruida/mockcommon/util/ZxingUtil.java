package com.ruida.mockcommon.util;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.font.FontRenderContext;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

/**
 * 标记码生成
 *
 * @author szl
 *
 */
public class ZxingUtil {

	/**
	 * 代理寄件标识码
	 *
	 * @param url
	 * @param width
	 * @return
	 * @throws Exception
	 */
	public static BufferedImage createQrCode( String url,  int width)
			throws Exception {
		int qrWidth = (int) (width * 0.4);
		int h = qrWidth;
		int brWidth = (int) (width * 0.6);
		int brHight = (int) (h * 0.4);
		int fontSize = (int) (width / 1000f * 30);
		Font font = new Font("宋体", Font.BOLD, fontSize);

//		String pathString = ZxingUtil.class.getResource("/font/simsun.ttc").getFile();
//		Font font = Font.createFont(Font.TRUETYPE_FONT, new File(pathString));
//		Font font = Font.createFont(Font.TRUETYPE_FONT, new File("d:/simsun.ttf"));
//		font.deriveFont(Font.BOLD, fontSize);
//		System.out.println(font.getFontName());

		int top = (int) (h / 200 * 13);

		// 生成二维码
		BufferedImage qr = encodeQrBufferedImage(url, qrWidth, h);

		return qr;
	}

	/**
	 * 上门取件条形码
	 *
	 * @param tagCode
	 * @param width
	 * @param height
	 * @return
	 * @throws Exception
	 */
	public static BufferedImage createBarCode(String tagCode, int width, int height) throws Exception {
		// 上边距
		int top = 5;
		// 条码宽度
		int newW = (int) (width * 1);
		// 条码高度，整体高度的80%，下面的20%写文字
		int newH = (int) (height * 0.8);
		int fontSize = (int) (width / 300f * 20);

//		String pathString = ZxingUtil.class.getResource("/font/simsun.ttc").getFile();
//		Font font = Font.createFont(Font.TRUETYPE_FONT, new File(pathString));
//		Font font = Font.createFont(Font.TRUETYPE_FONT, new File("d:/simsun.ttc"));
//		font.deriveFont(Font.BOLD, fontSize);
//		System.out.println(font.getFontName());

		Font font = new Font("宋体", Font.BOLD, fontSize);
		// 生成条码
		BufferedImage br = encodeBrBufferedImage(tagCode, newW, newH);
		// 根据指定大小创建条码标识
		BufferedImage bi = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
		Graphics2D graphics = (Graphics2D) bi.getGraphics();
		graphics.setBackground(Color.WHITE);
		graphics.clearRect(0, 0, width, height);
		graphics.setPaint(Color.black);
		graphics.setFont(font);
		// 加载条码
		graphics.drawImage(br, 0, top, newW, newH, null);

		String desc = "编号：" + tagCode;

		// 计算文字位置
		FontRenderContext context = graphics.getFontRenderContext();
		Rectangle2D bounds = font.getStringBounds(desc, context);
		double x = (width - bounds.getWidth()) / 2;
		double y = (height - newH - top - bounds.getHeight()) / 2;
		double ascent = -bounds.getY();
		double baseY = y + ascent + newH + top;
		// 绘制文字
		graphics.drawString(desc, (int) x, (int) baseY);

		return bi;
	}

	/**
	 *
	 * @param contents
	 * @param width
	 * @param height
	 * @return
	 */
	private static BufferedImage encodeBrBufferedImage(String contents, int width, int height) {
		// start guard + eft bars + middle guard + right bars + end guard
		int codeWidth = 3 + (7 * 6) + 5 + (7 * 6) + 3;
		codeWidth = Math.max(codeWidth, width);
		Map<EncodeHintType, Object> hints = new HashMap<EncodeHintType, Object>();
		// 指定生成条形码时使用的空白值（以像素为单位）。
		hints.put(EncodeHintType.MARGIN, 2);
		try {
			BitMatrix bitMatrix = new MultiFormatWriter().encode(contents, BarcodeFormat.CODE_128, codeWidth, height,
					hints);
			return MatrixToImageWriter.toBufferedImage(bitMatrix);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 *
	 * @param contents
	 * @param width
	 * @param height
	 * @return
	 */
	private static BufferedImage encodeQrBufferedImage(String contents, int width, int height) {
		Map<EncodeHintType, Object> hints = new HashMap<EncodeHintType, Object>();
		// 指定纠错等级 分为四个等级：L/M/Q/H, 等级越高，容错率越高，识别速度降低。
		hints.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.H);
		// 指定编码格式 编码集，通常有中文，设置为 utf-8
		hints.put(EncodeHintType.CHARACTER_SET, "UTF-8");
		try {
			BitMatrix bitMatrix = new MultiFormatWriter().encode(contents, BarcodeFormat.QR_CODE, width, height, hints);
			return MatrixToImageWriter.toBufferedImage(bitMatrix);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * 8位标识码
	 * @return
	 */
	public static String tagCode() {
		// 获得当前时间的毫秒数
		Random rd = new Random(System.currentTimeMillis());
		// 生成8位随机整数
		Integer number = rd.nextInt(90000000) + 10000000;
		return number.toString();
	}

	public static void main(String[] args) {
		try {

		/*	int width = 300;
			int height = 150;
			String bh = "weixin://wxpay/bizpayurl?pr=5eYQHKc";

			BufferedImage bi = createBarCode(bh, width, height);
			ImageIO.write(bi, "jpg", new File("d:/test_tmbs.jpg"));*/

			int width = 500;
			String url = "weixin://wxpay/bizpayurl?pr=xk1hrSe";
			BufferedImage bb = createQrCode(url,500);
			//BufferedImage bi = createQrCode(bh, url, strDls, strDesc, 500);
			ImageIO.write(bb, "jpg", new File("d:/test_bsm.jpg"));
		} catch (Exception e) {
			e.printStackTrace();
		}

		System.out.println((int) ((Math.random() * 9 + 1) * 10000000));
		System.out.println(tagCode());

	}

}
