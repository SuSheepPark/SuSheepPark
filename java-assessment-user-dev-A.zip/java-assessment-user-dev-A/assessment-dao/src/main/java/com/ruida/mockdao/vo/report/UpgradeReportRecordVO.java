package com.ruida.mockdao.vo.report;

/**
 * @description: 升学选拔报告生成记录
 * @author: kgz
 * @date: 2020/12/24
 */
public class UpgradeReportRecordVO {

    private Integer id;

    private String examName;

    private String stageName;

    private String examTimeStr;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getExamName() {
        return examName;
    }

    public void setExamName(String examName) {
        this.examName = examName;
    }

    public String getStageName() {
        return stageName;
    }

    public void setStageName(String stageName) {
        this.stageName = stageName;
    }

    public String getExamTimeStr() {
        return examTimeStr;
    }

    public void setExamTimeStr(String examTimeStr) {
        this.examTimeStr = examTimeStr;
    }
}
