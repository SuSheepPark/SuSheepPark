package com.ruida.cloud.model;

import lombok.Data;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

@Data
public class CourseLessonResult implements Serializable {
    private Map<String,Object> courseLesson;
    private List<ResourceLibrary>  libraryList;
}
