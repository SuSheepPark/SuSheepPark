package com.ruida.mockdao.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.model.Product;
import com.ruida.mockdao.dto.ProductQueryRequest;
import com.ruida.mockdao.vo.ProductNewVO;
import com.ruida.mockdao.vo.ProductVO;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 商品表 Mapper 接口
 * </p>
 *
 * @author jinhu
 * @since 2020-07-08
 */
public interface ProductMapper extends BaseMapper<Product> {


    /*
     *功能描述
     * @param 查询商品列表
     * @return
     */
    List<ProductVO> queryProductList(@Param("vo") ProductQueryRequest req);
    /*
     *功能描述
     * @param 查询商品列表(新)
     * @return
     */
    List<ProductNewVO> queryProductListNew(@Param("vo") ProductQueryRequest req);

    /*
     *功能描述
     * @param 查询推荐的商品列表
     * @return
     */
    List<ProductVO> queryRecommendProductList(@Param("vo") ProductQueryRequest req);

    /*
     *功能描述
     * @param  查询商品列表总数
     * @return
     */
    Integer queryProductCount(@Param("vo") ProductQueryRequest req);
    /*
     *功能描述
     * @param  查询商品列表总数
     * @return
     */
    Integer queryProductCountNew(@Param("vo") ProductQueryRequest req);

    /*
     *功能描述
     * @param  查询商品列表总数
     * @return
     */
    Integer queryRecommendProductCount(@Param("vo") ProductQueryRequest req);


    /*
     *功能描述
     * @param 查询用户商品列表
     * @return
     */
    List<ProductVO> queryUserProductList(@Param("vo") ProductQueryRequest req);
    /*
     *功能描述
     * @param 查询用户商品列表
     * @return
     */
    List<ProductNewVO> queryUserProductListNew(@Param("vo") ProductQueryRequest req);


    /*
     *功能描述
     * @param  查询用户商品列表总数
     * @return
     */
    Integer queryUserProductCount(@Param("vo") ProductQueryRequest req);



}
