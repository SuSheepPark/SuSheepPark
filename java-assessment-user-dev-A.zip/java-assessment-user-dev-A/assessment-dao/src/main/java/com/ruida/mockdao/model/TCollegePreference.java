package com.ruida.mockdao.model;

import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 志愿填报报告
 * </p>
 *
 * @author szl
 * @since 2021-03-02
 */
@TableName("t_college_preference")
public class TCollegePreference extends Model<TCollegePreference> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键id
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;
    /**
     * 用户id
     */
    @TableField("user_id")
    private Integer userId;
    /**
     * 报告生成时用户的学生关联信息
     */
    @TableField("stu_rid")
    private Integer stuRid;
    /**
     * 订单id
     */
    @TableField("order_no")
    private String orderNo;
    /**
     * 专业意向选择记录
     */
    @TableField("major_record_id")
    private Integer majorRecordId;
    /**
     * 高考分数
     */
    private Double score;
    /**
     * 选课科目
     */
    @TableField("subject_name")
    private String subjectName;
    /**
     * 推荐专业记录
     */
    @TableField("recommend_id")
    private Integer recommendId;
    /**
     * 报告状态（0 未生成，1已生成）
     */
    private Integer status;
    /**
     * 创建时间
     */
    @TableField("create_time")
    private Date createTime;
    /**
     * 更新时间
     */
    @TableField("update_time")
    private Date updateTime;
    /**
     * 报告首次查看时间
     */
    @TableField("first_check_time")
    private Date firstCheckTime;
    /**
     * 来源
     */
    private Integer source;
    /**
     * 逻辑删除符号
     */
    private Integer isdelete;
    /**
     * 年份
     */
    private Integer year;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Integer getMajorRecordId() {
        return majorRecordId;
    }

    public void setMajorRecordId(Integer majorRecordId) {
        this.majorRecordId = majorRecordId;
    }

    public Double getScore() {
        return score;
    }

    public void setScore(Double score) {
        this.score = score;
    }

    public String getSubjectName() {
        return subjectName;
    }

    public void setSubjectName(String subjectName) {
        this.subjectName = subjectName;
    }

    public Integer getRecommendId() {
        return recommendId;
    }

    public void setRecommendId(Integer recommendId) {
        this.recommendId = recommendId;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getIsdelete() {
        return isdelete;
    }

    public void setIsdelete(Integer isdelete) {
        this.isdelete = isdelete;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    public Date getFirstCheckTime() {
        return firstCheckTime;
    }

    public void setFirstCheckTime(Date firstCheckTime) {
        this.firstCheckTime = firstCheckTime;
    }

    public Integer getStuRid() {
        return stuRid;
    }

    public void setStuRid(Integer stuRid) {
        this.stuRid = stuRid;
    }

    public Integer getSource() {
        return source;
    }

    public void setSource(Integer source) {
        this.source = source;
    }

    @Override
    protected Serializable pkVal() {
        return this.id;
    }

    @Override
    public String toString() {
        return "TCollegePreference{" +
        ", id=" + id +
        ", userId=" + userId +
        ", orderNo=" + orderNo +
        ", majorRecordId=" + majorRecordId +
        ", score=" + score +
        ", subjectName=" + subjectName +
        ", recommendId=" + recommendId +
        ", status=" + status +
        ", createTime=" + createTime +
        ", updateTime=" + updateTime +
        ", isdelete=" + isdelete +
        "}";
    }
}
