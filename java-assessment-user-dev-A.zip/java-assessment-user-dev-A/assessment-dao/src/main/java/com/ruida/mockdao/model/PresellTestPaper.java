package com.ruida.mockdao.model;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import lombok.Data;

import java.io.Serializable;


@Data
@TableName("t_presell_test_paper")
public class PresellTestPaper extends BaseColumn implements Serializable {


    private static final long serialVersionUID = -8521771662757858384L;
    @TableId
    private Integer id;

    /**
     * 教材版本id
     */
    private Integer versionId;

    /**
     * 年级id
     */
    private Integer stageId;

    /**
     * 学科id
     */
    private Integer subjectId;

    /**
     * 年份
     */
    private Integer year;

    /*测试时长*/
    private Integer testDruation;

    private Integer productId;

    private String testPaperName;


}
