package com.ruida.assessment.assessmentquestionbank.model;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;


/**
 * @author wy
 * @description  知识点数据库实体类
 * @date 2020/6/10
 */
@Data
@ApiModel(description = "知识点数据库实体")
@TableName("t_knowledge")
public class TKnowledge extends BaseColumn implements Serializable {

    private static final long serialVersionUID = 7198845282579344103L;

    @TableId
    @ApiModelProperty(value = "知识点id", name = "knowledgeId", required = false)
    private Integer knowledgeId;

    @ApiModelProperty(value = "知识点名称", name = "knowledgeName", required = true)
    private String knowledgeName;

    @ApiModelProperty(value = "父级id", name = "pId", required = true)
    private Integer pid;

    @ApiModelProperty(value = "学段id", name = "period_id", required = true)
    private Integer periodId;

/*    @ApiModelProperty(value = "学段名称", name = "periodName", required = true)
    private String periodName;*/

    @ApiModelProperty(value = "科目id", name = "subjectId", required = true)
    private Integer subjectId;

/*    @ApiModelProperty(value = "科目名称", name = "subjectName", required = true)
    private String subjectName;*/

    @ApiModelProperty(value = "考点id", name = "examplaceId", required = true)
    private Integer examplaceId;

    @ApiModelProperty(value = "考点名称", name = "examplaceName", required = true)
    private String examplaceName;

    @ApiModelProperty(value = "排序值", name = "sort", required = true)
    private Integer sort;

    @ApiModelProperty(value = "状态 0—禁用；1—启用", name = "status", required = true)
    private Integer status;
}
