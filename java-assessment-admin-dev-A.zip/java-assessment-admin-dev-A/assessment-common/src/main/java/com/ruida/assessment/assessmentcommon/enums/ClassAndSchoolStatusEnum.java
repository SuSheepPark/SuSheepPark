package com.ruida.assessment.assessmentcommon.enums;

public enum ClassAndSchoolStatusEnum {

    STOP(0,"禁用"),
    NORMAL(1,"启用/正常"),
    CHECK(2,"待审核"),
    ;

    private Integer K;
    private String V;

    ClassAndSchoolStatusEnum(Integer k, String v) {
        K = k;
        V = v;
    }

    public Integer getK() {
        return K;
    }

    public void setK(Integer k) {
        K = k;
    }

    public String getV() {
        return V;
    }

    public void setV(String v) {
        V = v;
    }

    public static DeleteStatusEnum getValueById(Integer K){
        for(DeleteStatusEnum deleteStatusEnum : DeleteStatusEnum.values() ){
            if(deleteStatusEnum.getK().equals(K)){
                return  deleteStatusEnum;
            }
        }
        return null;
    }
}
