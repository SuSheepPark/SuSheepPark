package com.ruida.cloud.dao;

import com.ruida.cloud.model.DrainageActivityCourseRel;
import com.ruida.cloud.model.DrainageActivityCourseRelExample;
import com.ruida.cloud.model.PromotionActivityCourseRel;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface DrainageActivityCourseRelMapper {
    long countByExample(DrainageActivityCourseRelExample example);

    int deleteByExample(DrainageActivityCourseRelExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(DrainageActivityCourseRel record);

    int insertSelective(DrainageActivityCourseRel record);

    List<DrainageActivityCourseRel> selectByExample(DrainageActivityCourseRelExample example);

    DrainageActivityCourseRel selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") DrainageActivityCourseRel record, @Param("example") DrainageActivityCourseRelExample example);

    int updateByExample(@Param("record") DrainageActivityCourseRel record, @Param("example") DrainageActivityCourseRelExample example);

    int updateByPrimaryKeySelective(DrainageActivityCourseRel record);

    int updateByPrimaryKey(DrainageActivityCourseRel record);

    /**
     * 批量插入关联信息
     */
    public int insertBatch(List<DrainageActivityCourseRel> list);
}