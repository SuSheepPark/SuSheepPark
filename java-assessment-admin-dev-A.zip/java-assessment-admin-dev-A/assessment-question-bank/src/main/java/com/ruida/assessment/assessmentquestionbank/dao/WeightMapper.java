package com.ruida.assessment.assessmentquestionbank.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.assessment.assessmentquestionbank.model.Weight;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 权重设置表 Mapper 接口
 * </p>
 *
 * @author chenjy
 * @since 2020-12-16
 */
public interface WeightMapper extends BaseMapper<Weight> {

    /**
     * 根据商品获取年级
     * @param productIdList
     * @return
     */
    List<Weight> getReportWeightStageList(@Param("productIdList") List<Integer> productIdList);

    /**
     * 根据上传id获取年级
     * @param uploadId
     * @return
     */
    List<Weight> getUploadWeightStageList(@Param("uploadIdList")  List<Integer> uploadId);
}
