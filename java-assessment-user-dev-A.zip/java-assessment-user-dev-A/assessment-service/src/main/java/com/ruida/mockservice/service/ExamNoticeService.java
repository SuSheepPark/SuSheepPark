package com.ruida.mockservice.service;

import com.baomidou.mybatisplus.service.IService;
import com.ruida.mockdao.model.ExamNotice;

/**
 * <p>
 * 考试注意事项表 服务类
 * </p>
 *
 * @author chenjy
 * @since 2020-08-03
 */
public interface ExamNoticeService extends IService<ExamNotice> {

}
