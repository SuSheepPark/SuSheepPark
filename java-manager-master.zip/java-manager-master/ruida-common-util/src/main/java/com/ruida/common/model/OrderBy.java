package com.ruida.common.model;

/**
 * Created by Administrator on 2018/3/8.
 */
public class OrderBy {

    public static final String ORDER_DESC = "DESC";
    public static final String ORDER_ASC = "ASC";

    String orderColumn;
    String orderDirection = ORDER_ASC;

    // 后端使用
    String orderByClause = null;

    public OrderBy() {
    }

    public OrderBy(String orderColumn, String orderDirection) {
        this.orderColumn = orderColumn;
        this.orderDirection = orderDirection;
    }

    public OrderBy(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderColumn() {
        return orderColumn;
    }

    public void setOrderColumn(String orderColumn) {
        this.orderColumn = orderColumn;
    }

    public String getOrderDirection() {
        return orderDirection;
    }

    public void setOrderDirection(String orderDirection) {
        this.orderDirection = orderDirection;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public static OrderBy create(String s) {
        OrderBy orderBy = new OrderBy();
        orderBy.setOrderByClause(s);
        return orderBy;
    }
}
