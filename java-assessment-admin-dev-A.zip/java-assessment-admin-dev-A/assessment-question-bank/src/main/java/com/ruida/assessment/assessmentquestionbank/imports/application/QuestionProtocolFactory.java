package com.ruida.assessment.assessmentquestionbank.imports.application;

import com.ruida.assessment.assessmentquestionbank.imports.docx.DocxReader;
import com.ruida.assessment.assessmentquestionbank.imports.domain.model.ErrorMsgException;
import com.ruida.assessment.assessmentquestionbank.imports.domain.service.ChoiceQuestionProtocol;
import com.ruida.assessment.assessmentquestionbank.imports.domain.service.FillQuestionProtocol;
import com.ruida.assessment.assessmentquestionbank.imports.domain.service.MutipleChoiceQuestionProtocol;
import com.ruida.assessment.assessmentquestionbank.imports.domain.service.MutipleQuestionProtocol;
import com.ruida.assessment.assessmentquestionbank.imports.domain.service.QAQuestionProtocol;
import com.ruida.assessment.assessmentquestionbank.imports.domain.service.QuestionProtocol;
import com.ruida.assessment.assessmentquestionbank.imports.domain.service.TFQuestionProtocol;

/**
 * 根据题型得到具体的处理协议
 * @author mazhuang
 *
 */
public class QuestionProtocolFactory {

	private static QuestionProtocolFactory factory;

	public QuestionProtocol getQuestionProtocol(DocxReader reader, String name) throws ErrorMsgException {
		switch (name) {
		case "单选题":
			return new ChoiceQuestionProtocol(reader);
		case "多选题":
			return new MutipleChoiceQuestionProtocol(reader);
		case "不定项选择题":
			return new MutipleChoiceQuestionProtocol(reader);
		case "判断题":
			return new TFQuestionProtocol(reader);
		case "填空题":
			return new FillQuestionProtocol(reader);
		case "问答题":
			return new QAQuestionProtocol(reader);
		case "组合题":
			return new MutipleQuestionProtocol(reader);

		default:
			throw new ErrorMsgException(reader.getLineNum(), "错误的题目类型-" + name);
		}
	}

	public static QuestionProtocolFactory getFactory() {
		if (null == factory) {
			synchronized (QuestionProtocolFactory.class) {
				if (factory == null) {
					factory = new QuestionProtocolFactory();//

				}
			}
		}
		return factory;
	}
}
