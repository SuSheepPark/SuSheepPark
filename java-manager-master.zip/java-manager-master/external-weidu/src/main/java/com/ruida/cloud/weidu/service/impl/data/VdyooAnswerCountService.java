package com.ruida.cloud.weidu.service.impl.data;

import com.ruida.cloud.weidu.utils.PropertyUtil;
import com.ruida.cloud.weidu.utils.VdyooUtil;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * @author taosh
 * @create 2019-04-24 11:51
 */
@Service
public class VdyooAnswerCountService {
    private String vdyooPath = PropertyUtil.getProperty("vdyooTestApi");

    /**
     * 获取机构下所有课程班
     */
    public void findAllCourseClass(String courseClassId){
        String path = vdyooPath+"/api/answer/count/findAllCourseClass";

        Map<String, String> param = VdyooUtil.getSignMap();

//        String response = HttpClientUtil.postMap(path, param);
//        System.out.println(response);
    }

    /**
     * 列出课程班下的所有课表
     */
    public void findAllScheduleByCourseClassId(String courseClassId){
        String path = vdyooPath+"/api/answer/count/findAllScheduleByCourseClassId";

        Map<String, String> param = VdyooUtil.getSignMap();

        //威渡课程班ID
        param.put("courseClassId", courseClassId);

//        String response = HttpClientUtil.postMap(path, param);
//        System.out.println(response);
    }

    /**
     * 列出本节课所有答题数据
     */
    public void findExamByScheduleId(String scheduleId){
        String path = vdyooPath+"/api/answer/count/findExamByScheduleId";

        Map<String, String> param = VdyooUtil.getSignMap();

        //课表ID
        param.put("scheduleId", scheduleId);

//        String response = HttpClientUtil.postMap(path, param);
//        System.out.println(response);
    }

    /**
     * 列出本节课所有抢红包记录
     */
    public void findRedGiftByScheduleId(String scheduleId){
        String path = vdyooPath+"/api/answer/count/findRedGiftByScheduleId";

        Map<String, String> param = VdyooUtil.getSignMap();

        //课表ID
        param.put("scheduleId", scheduleId);

//        String response = HttpClientUtil.postMap(path, param);
//        System.out.println(response);
    }
}
