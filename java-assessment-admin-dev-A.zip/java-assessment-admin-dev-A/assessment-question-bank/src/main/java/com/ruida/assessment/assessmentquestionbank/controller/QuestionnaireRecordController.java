package com.ruida.assessment.assessmentquestionbank.controller;

import com.ruida.assessment.assessmentcommon.result.PageResult;
import com.ruida.assessment.assessmentquestionbank.service.QuestionnaireRecordService;
import com.ruida.assessment.assessmentquestionbank.vo.QuestionnaireRecordVO;
import com.ruida.assessment.major.web.vo.QuestionnaireRecordStudentVO;
import com.ruida.assessment.major.web.vo.SelectRecordByStudentVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.text.ParseException;

/**
 * @author xumingqi
 * @date 2021/2/23 9:33
 */
@RestController
@RequestMapping("/questionnaireRecord")
@Api(tags = "调查问卷测试记录")
public class QuestionnaireRecordController {
    @Resource
    QuestionnaireRecordService questionnaireRecordService;

    @GetMapping("/recordCountList")
    @ApiOperation(value = "调查问卷测试记录")
    public PageResult<QuestionnaireRecordVO> recordCountList() {
        PageResult<QuestionnaireRecordVO> pageResult = new PageResult<>();
        pageResult.setContent(questionnaireRecordService.getRecordCountPage());
        return pageResult;
    }

    @GetMapping("/recordDetailList")
    @ApiOperation(value = "测试记录学生信息")
    public PageResult<QuestionnaireRecordStudentVO> recordDetailList(@RequestParam Integer type,
                                                                     @RequestParam(required = false) String keyWord,
                                                                     @RequestParam(defaultValue = "1") Integer currentPage,
                                                                     @RequestParam(defaultValue = "10") Integer pageSize) {
        //type 1-科目兴趣测试 2-专业问卷调查 3-职业倾向测试
        PageResult<QuestionnaireRecordStudentVO> pageResult = new PageResult<>();
        pageResult.setContent(questionnaireRecordService.getStudentInfoPage(type, keyWord, currentPage, pageSize));
        return pageResult;
    }

    @GetMapping("/studentRecordList")
    @ApiOperation(value = "学生测试记录")
    public PageResult<SelectRecordByStudentVO> studentRecordList(@RequestParam Integer type,
                                                                 @RequestParam Integer userId,
                                                                 @RequestParam(required = false) String startTime,
                                                                 @RequestParam(required = false) String endTime,
                                                                 @RequestParam(defaultValue = "1") Integer currentPage,
                                                                 @RequestParam(defaultValue = "10") Integer pageSize) throws ParseException {
        //type 1-科目兴趣测试 2-专业问卷调查 3-职业倾向测试
        PageResult<SelectRecordByStudentVO> pageResult = new PageResult<>();
        pageResult.setContent(questionnaireRecordService.getStudentRecordPage(type, userId, startTime, endTime, currentPage, pageSize));
        return pageResult;
    }
}
