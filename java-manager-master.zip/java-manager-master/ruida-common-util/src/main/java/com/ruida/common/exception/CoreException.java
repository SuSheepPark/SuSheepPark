package com.ruida.common.exception;


import com.ruida.common.enums.AppErrorEnum;

/**
 * @author szl
 * @description: 业务核心异常定义
 * @Date 2018年12月06日
 * @verion 1.0
 */
public class CoreException extends RuntimeException {

    /**
     *
     */
    private static final long serialVersionUID = 5792816284203588336L;
    /**
     * 错误码 http层面
     */
    private int errCode;
    /**
     * 错误消息
     */
    private String message;

    /**
     * 业务错误信息
     */
    private String subErrCode;

    @Override
    public String getMessage() {
        return message;
    }

    public Integer getErrCode() {
        return errCode;
    }

    public String getSubErrCode() {
        return subErrCode;
    }

    public CoreException(int errCode, String message, Throwable cause) {
        super(message, cause);
        this.errCode = errCode;
        this.message = message;
    }

    public CoreException(int errCode, String message) {
        super(message);
        this.errCode = errCode;
        this.message = message;
    }
    public CoreException(AppErrorEnum AppErrorEnum) {
        super(AppErrorEnum.getErrorMessage());
        this.errCode = AppErrorEnum.getErrorCode();
        this.message = AppErrorEnum.getErrorMessage();
    }

    public CoreException(String message) {
        super(message);
        this.message = message;
    }
}
