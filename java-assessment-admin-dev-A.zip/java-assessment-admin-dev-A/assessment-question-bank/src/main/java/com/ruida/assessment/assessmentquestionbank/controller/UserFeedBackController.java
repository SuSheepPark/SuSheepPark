package com.ruida.assessment.assessmentquestionbank.controller;

import com.ruida.assessment.assessmentcommon.result.PageResult;
import com.ruida.assessment.assessmentcommon.result.PojoResult;
import com.ruida.assessment.assessmentquestionbank.annotaion.UserAuth;
import com.ruida.assessment.assessmentquestionbank.dto.UserFeedBackDTO;
import com.ruida.assessment.assessmentquestionbank.service.UserFeedBackService;
import com.ruida.assessment.assessmentquestionbank.vo.OrderVO;
import com.ruida.assessment.assessmentquestionbank.vo.UserFeedBackVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * @description: 用户反馈控制层
 * @author: kgz
 * @date: 2020/8/10
 */
@RequestMapping("/userFeedBack")
@RestController
@Api(value ="用户反馈相关接口")
public class UserFeedBackController {
    @Resource
    private UserFeedBackService userFeedBackService;

    @UserAuth
    @PostMapping("/getList")
    @ApiOperation(value = "分页查询用户反馈列表", notes = "分页查询用户反馈列表")
    @ApiImplicitParam(name = "userFeedBackDTO", value = "查询条件",
            required = true , dataType  = "UserFeedBackDTO",paramType = "body")
    public PageResult<UserFeedBackVO> getUserFeedBackList(@RequestBody UserFeedBackDTO userFeedBackDTO){
        PageResult<UserFeedBackVO> pageResult = new PageResult();
        pageResult.setContent(userFeedBackService.getUserFeedBackList(userFeedBackDTO));
        return pageResult;
    }

    @UserAuth
    @GetMapping("/getDetail/{id}")
    @ApiOperation(value = "获取用户反馈详情", notes = "获取用户反馈详情")
    @ApiImplicitParam(name = "id", value = "用户反馈信息id",
            required = true , dataType  = "integer",paramType = "path")
    public PojoResult getUserFeedBackDetail(@PathVariable Integer id){
        PojoResult pojoResult = new PojoResult();
        UserFeedBackVO userFeedBackVO = userFeedBackService.getUserFeedBackDetail(id);
        pojoResult.setContent(userFeedBackVO);
        return pojoResult;
    }

    @UserAuth
    @PostMapping("/reply")
    @ApiOperation(value = "回复用户反馈信息", notes = "回复用户反馈信息")
    @ApiImplicitParam(name = "userFeedBackDTO", value = "回复信息",
            required = true , dataType  = "UserFeedBackDTO",paramType = "body")
    public PojoResult<Integer> replyUserFeedBack(@RequestBody UserFeedBackDTO userFeedBackDTO){
        PojoResult<Integer> pojoResult = new PojoResult();
        pojoResult.setContent(userFeedBackService.replyUserFeedBack(userFeedBackDTO));
        return pojoResult;
    }

    @UserAuth
    @PostMapping("/delete")
    @ApiOperation(value = "删除用户反馈信息", notes = "删除用户反馈信息")
    @ApiImplicitParam(name = "userFeedBackDTO", value = "删除",
            required = true , dataType  = "UserFeedBackDTO",paramType = "body")
    public PojoResult<List<Integer>> deleteUserFeedBack(@RequestBody UserFeedBackDTO userFeedBackDTO){
        PojoResult<List<Integer>> pojoResult = new PojoResult();
        pojoResult.setContent(userFeedBackService.deleteUserFeedBack(userFeedBackDTO));
        return pojoResult;
    }

}
