package com.ruida.assessment.assessmentquestionbank.model;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;

import java.io.Serializable;
import java.util.Date;

/**
 * @description: 用户反馈信息数据库实体
 * @author: kgz
 * @date: 2020/8/10
 */
@TableName("sys_user_suggestions")
public class TUserFeedBack implements Serializable {
    private static final long serialVersionUID = -6407769736786957784L;
    /**
     * 用户意见反馈关联主键ID
     */
    @TableId
    private Integer suggestionId;

    /**
     * 用户ID
     */
    private Integer userId;

    /**
     * 联系方式
     */
    private String contactMethod;

    /**
     * 上传图片路径
     */
    private String imageUrl;

    /**
     * 是否解决（0—未回复；1—已回复）
     */
    private Integer status;

    /**
     * 意见反馈内容
     */
    private String suggestionContent;

    /**
     * 回复内容
     */
    private String replyContent;


    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新时间
     */
    private Date updateTime;

    /**
     * 更新者ID
     */
    private Integer updateBy;

    /**
     * 是否删除（0：未删除；1：删除）
     */
    private Integer isdelete;

    public Integer getSuggestionId() {
        return suggestionId;
    }

    public void setSuggestionId(Integer suggestionId) {
        this.suggestionId = suggestionId;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getContactMethod() {
        return contactMethod;
    }

    public void setContactMethod(String contactMethod) {
        this.contactMethod = contactMethod;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getSuggestionContent() {
        return suggestionContent;
    }

    public void setSuggestionContent(String suggestionContent) {
        this.suggestionContent = suggestionContent;
    }

    public String getReplyContent() {
        return replyContent;
    }

    public void setReplyContent(String replyContent) {
        this.replyContent = replyContent;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(Integer updateBy) {
        this.updateBy = updateBy;
    }

    public Integer getIsdelete() {
        return isdelete;
    }

    public void setIsdelete(Integer isdelete) {
        this.isdelete = isdelete;
    }

    @Override
    public String toString() {
        return "TUserFeedBack{" +
                "suggestionId=" + suggestionId +
                ", userId=" + userId +
                ", contactMethod='" + contactMethod + '\'' +
                ", imageUrl='" + imageUrl + '\'' +
                ", status=" + status +
                ", suggestionContent='" + suggestionContent + '\'' +
                ", replyContent='" + replyContent + '\'' +
                ", createTime=" + createTime +
                ", updateTime=" + updateTime +
                ", updateBy=" + updateBy +
                ", isdelete=" + isdelete +
                '}';
    }
}
