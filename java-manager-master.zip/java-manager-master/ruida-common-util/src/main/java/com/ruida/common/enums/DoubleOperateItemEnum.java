package com.ruida.common.enums;


import java.util.ArrayList;
import java.util.List;

/**
 * @author wy
 * @description 双师操作事项 日志使用
 * @date 2021/6/8
 */
public enum DoubleOperateItemEnum {

    UPDATE_XGJ_COURSE(1, "更新校管家课程"),
    SINGLE_ADD_LESSON(2, "单个新增课次"),
    EDIT_LESSON(3,"编辑课次"),
    DELETE_LESSON(4,"删除课次"),
    BATCH_ADD_LESSON(5,"批量新增课次"),
    UPDATE_XGJ_CLASS(6,"更新校管家班级"),
    CREATE_ASSISTANT(7,"创建助教"),
    UPDATE_ASSISTANT(8,"更新助教"),
    DELETE_ASSISTANT(9,"删除助教"),
    BIND_ASSISTANT(10,"给班级绑定助教"),
    UPDATE_XGJ_STUDENT(11,"更新校管家学生"),
    SYNC_CLASS_STU_ASS(12,"同步班级/学生/助教至百家云"),
    CREATE_LOCAL_STU(13,"本地创建学生"),
    DELETE_LOCAL_CLASS(14,"删除班级同步")
    ;

    private Integer id;
    private String item;

    DoubleOperateItemEnum(Integer id, String item) {
        this.id = id;
        this.item = item;
    }

    public static List<String> getItems() {
        List<String> itemList = new ArrayList<>();
        for (DoubleOperateItemEnum doubleOperateItemEnum : DoubleOperateItemEnum.values()){
            itemList.add(doubleOperateItemEnum.getItem());
        }
        return itemList;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getItem() {
        return item;
    }

    public void setItem(String item) {
        this.item = item;
    }}

