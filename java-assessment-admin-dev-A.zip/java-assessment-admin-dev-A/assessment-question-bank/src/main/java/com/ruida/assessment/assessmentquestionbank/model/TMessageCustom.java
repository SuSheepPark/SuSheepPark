package com.ruida.assessment.assessmentquestionbank.model;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * @description: 自定义消息数据库实体
 * @author: kgz
 * @date: 2020/7/27
 */
@TableName("t_message_custom")
public class TMessageCustom extends BaseColumn implements Serializable {

    private static final long serialVersionUID = 6392131587025516481L;
    /**
     * 自定义消息id
     */
    @TableId
    private Integer id;

    /**
     *自定义消息内容
     */
    private String content;

    /**
     *通知范围
     */
    private String noticeRange;

    /**
     *通知目标，0-学员，1-商品
     */
    private Integer purpose;

    /**
     *通知目标id，学员或商品id
     */
    private String purposeId;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getNoticeRange() {
        return noticeRange;
    }

    public void setNoticeRange(String noticeRange) {
        this.noticeRange = noticeRange;
    }

    public Integer getPurpose() {
        return purpose;
    }

    public void setPurpose(Integer purpose) {
        this.purpose = purpose;
    }

    public String getPurposeId() {
        return purposeId;
    }

    public void setPurposeId(String purposeId) {
        this.purposeId = purposeId;
    }

    @Override
    public String toString() {
        return "TMessageCustom{" +
                "id=" + id +
                ", content='" + content + '\'' +
                ", noticeRange='" + noticeRange + '\'' +
                ", purpose=" + purpose +
                ", purposeId='" + purposeId + '\'' +
                '}';
    }
}
