package com.ruida.assessment.assessmentquestionbank.dto;

import lombok.Data;

@Data
public class PreferenceFeedbackDTO extends QueryBaseDTO {
    private Integer source;//来源（0-pc 1-iOS 2-Android）
    private Integer star;//满意度
    private String searchWord;//搜索关键词
    private String startTime;//开始时间
    private String endTime;//结束时间
    private Integer hasContent;//(是否有反馈内容(0-无反馈内容 1-有)
    private Integer showAll;//展示所有
    private String telephone;//手机号


}
