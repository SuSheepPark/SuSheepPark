package com.ruida.assessment.assessmentquestionbank.dto;

import lombok.Data;

/**
 * @author wy
 * @description 树结构移动请求参数
 * @date 2020/6/10
 */
@Data
public class MoveTreeRequest {

    /*当前选中的节点id*/
    private Integer currentId;

    /*当前选中的节点排序值*/
    private Integer currentSort;

    /*移动类型 0-上移 1-下移 2-升级 */
    private Integer moveType;

    /*当前节点上一个或下一个节点id*/
    private Integer nextId;

    /*当前节点上一个或下一个节点排序值*/
    private Integer nextSort;

//    /*当前节点的父节点id*/
//    private Integer currentPid;

 /*   *//*当前节点的父节点的父节点id*//*
    private Integer ppId;*/



}
