package com.ruida.assessment.assessmentquestionbank.model;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;

import java.io.Serializable;

/**
 * @description: 网站访问量数据库实体
 * @author: kgz
 * @date: 2020/8/4
 */
@TableName("t_pv")
public class TPageView extends BaseColumn implements Serializable {
    private static final long serialVersionUID = 2004628974301672941L;
    /**
     * 主键ID
     */
    @TableId
    private Integer id;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "TPageView{" +
                "id=" + id +
                super.toString() +
                '}';
    }
}
