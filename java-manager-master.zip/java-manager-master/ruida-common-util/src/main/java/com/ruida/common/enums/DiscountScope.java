package com.ruida.common.enums;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * 0—联报优惠；1—带新优惠
 */
public enum DiscountScope {

    newuser(0,"新生"), regular(1,"老客户"), all(2,"全部");

    public static final String SOURCE_KEY = "DiscountScope";

    private int k;
    private String v;

    DiscountScope(int k, String v) {
        this.k = k;
        this.v = v;
    }

    public static Map<Integer, String> map = new LinkedHashMap<>(2);
    static
    {
        for(DiscountScope type : DiscountScope.values())
        {
            map.put(type.getK(),type.getV());
        }
    }

    public static String getSourceKey() {
        return SOURCE_KEY;
    }

    public int getK() {
        return k;
    }

    public void setK(int k) {
        this.k = k;
    }

    public String getV() {
        return v;
    }

    public void setV(String v) {
        this.v = v;
    }

    /***
     * 根据k获取v的值
     * @param k
     * @return
     */
    public static String getvByk(int k) {
        DiscountScope[] list = DiscountScope.values();
        for (DiscountScope valid : list) {
            if (valid.getK() == k ) {
                return valid.getV();
            }
        }
        return "";
    }
}
