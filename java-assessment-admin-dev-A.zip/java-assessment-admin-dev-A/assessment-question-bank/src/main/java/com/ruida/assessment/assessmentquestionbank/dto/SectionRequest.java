package com.ruida.assessment.assessmentquestionbank.dto;

import lombok.Data;

/**
 * @author wy
 * @description 新增章节请求参数
 * @date 2020/6/10
 */
@Data
public class SectionRequest {

    /*当前选中的章节id*/
    private Integer id;

    /*前选中的章节的父节点id*/
    private Integer pid;

    /*当前选中的章节的排序值*/
    private Integer sort;

    /*章节名称*/
    private String sectionName;

    /*新增类型 1-同级 2-子级 3-父级 */
    private Integer type;

    /*学段id*/
    private Integer periodId;

    /*学段名称*/
    private String periodName;

    /*科目id*/
    private Integer subjectId;

    /*科目名称*/
    private String subjectName;

    /*教材id*/
    private Integer materialId;

    /*教材版本id*/
    private Integer versionId;

    /*教材版本名称*/
    private String versionName;

    /*年级id*/
    private Integer gradeId;

    /*年级名称*/
    private String gradeName;


}
