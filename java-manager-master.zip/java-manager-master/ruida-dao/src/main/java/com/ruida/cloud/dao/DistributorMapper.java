package com.ruida.cloud.dao;

import com.ruida.cloud.model.Distributor;
import com.ruida.cloud.model.DistributorExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface DistributorMapper {
    int countByExample(DistributorExample example);

    int deleteByExample(DistributorExample example);

    int deleteByPrimaryKey(Integer distributorId);

    int insert(Distributor record);

    int insertSelective(Distributor record);

    List<Distributor> selectByExample(DistributorExample example);

    Distributor selectByPrimaryKey(Integer distributorId);

    int updateByExampleSelective(@Param("record") Distributor record, @Param("example") DistributorExample example);

    int updateByExample(@Param("record") Distributor record, @Param("example") DistributorExample example);

    int updateByPrimaryKeySelective(Distributor record);

    int updateByPrimaryKey(Distributor record);
}