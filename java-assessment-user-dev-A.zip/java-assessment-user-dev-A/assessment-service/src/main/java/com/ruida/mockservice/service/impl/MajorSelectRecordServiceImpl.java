package com.ruida.mockservice.service.impl;


import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.beust.jcommander.internal.Lists;
import com.ruida.mockcommon.auth.context.BaseContextHandle;
import com.ruida.mockcommon.auth.pojo.JWTInfo;
import com.ruida.mockdao.dao.MajorSelectDetailMapper;
import com.ruida.mockdao.dao.MajorSelectRecordMapper;
import com.ruida.mockdao.model.MajorCategory;
import com.ruida.mockdao.model.MajorSelectDetail;
import com.ruida.mockdao.model.MajorSelectRecord;
import com.ruida.mockdao.vo.StudentInfoVO;
import com.ruida.mockdao.vo.major.MajorGroupVO;
import com.ruida.mockservice.service.MajorCategoryService;
import com.ruida.mockservice.service.MajorSelectRecordService;
import com.ruida.mockservice.service.StudentService;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.*;

/**
 * <p>
 * 专业兴趣选择记录 服务实现类
 * </p>
 *
 * @author xumingqi
 * @since 2021-01-14
 */
@Service
public class MajorSelectRecordServiceImpl extends ServiceImpl<MajorSelectRecordMapper, MajorSelectRecord> implements MajorSelectRecordService {
    @Resource
    StudentService studentService;
    @Resource
    MajorCategoryService majorCategoryService;
    @Resource
    MajorSelectRecordMapper majorSelectRecordMapper;
    @Resource
    MajorSelectDetailMapper majorSelectDetailMapper;


    @Override
    @Transactional(rollbackFor = Exception.class)
    public Boolean submitLikeMajor(String majorCodes) {
        JWTInfo jwtInfo = BaseContextHandle.getJWTInfo();
        Integer userId = Integer.valueOf(jwtInfo.getUserId());
        //增加一条历史记录
        MajorSelectRecord record = new MajorSelectRecord();
        record.setUserId(userId);
        record.setCreateBy(userId);
        record.setCreateTime(new Date());
        majorSelectRecordMapper.insert(record);
        //增加专业选择详情记录
        String[] majorCodeList = majorCodes.split(",");
        for (String majorCode : majorCodeList) {
            EntityWrapper<MajorCategory> entityWrapper = new EntityWrapper<>();
            entityWrapper.eq("major_category_code", majorCode);
            entityWrapper.eq("isdelete", 0);
            MajorCategory major = majorCategoryService.selectOne(entityWrapper);
            if (major != null) {
                MajorSelectDetail selectDetail = new MajorSelectDetail();
                selectDetail.setUserId(userId);
                selectDetail.setRecordId(record.getId());
                selectDetail.setMajorCategoryCode(major.getMajorCategoryCode());
                selectDetail.setMajorCategoryName(major.getMajorCategoryName());
                selectDetail.setSubjectCategoryCode(major.getSubjectCategoryCode());
                selectDetail.setSubjectCategoryName(major.getSubjectCategoryName());
                selectDetail.setCreateBy(userId);
                record.setCreateTime(new Date());
                majorSelectDetailMapper.insert(selectDetail);
            }
        }
        return true;
    }

    @Override
    public Boolean checkHaveReport(Integer userId) {
        EntityWrapper<MajorSelectRecord> entityWrapper = new EntityWrapper<>();
        entityWrapper.eq("user_id", userId);
        entityWrapper.eq("isdelete", 0);
        List<MajorSelectRecord> list = majorSelectRecordMapper.selectList(entityWrapper);
        return CollectionUtils.isNotEmpty(list);
    }

    @Override
    public Map<String, Object> getMyMajorReport(Integer userId) {
        Map<String, Object> resultMap = new HashMap<>();
        StudentInfoVO studentInfoVO = studentService.getStudentInfoVO(userId);
        //有可能出现没姓名 没学号 没班级 没学校的新注册用户
        if (studentInfoVO == null) {
            studentInfoVO = new StudentInfoVO();
        }
        studentInfoVO.setSubjectName("综合");
        resultMap.put("studentInfo", studentInfoVO);
        resultMap.put("majorInfo", this.getMajorReportInfo(userId));
        return resultMap;
    }

    @Override
    public List<MajorGroupVO> getMajorReportInfo(Integer userId) {
        List<MajorGroupVO> resultList = Lists.newArrayList();
        EntityWrapper<MajorSelectRecord> entityWrapper = new EntityWrapper<>();
        entityWrapper.eq("user_id", userId);
        entityWrapper.eq("isdelete", 0);
        entityWrapper.orderBy("create_time", false);
        MajorSelectRecord record = this.selectOne(entityWrapper);
        if (record != null) {
            resultList = majorSelectDetailMapper.getMyMajorReport(record.getId());
        }
        return resultList;
    }

    @Override
    public List<MajorGroupVO> getMajorReportInfoByRecordId(Integer recordId) {
        return Optional.ofNullable(majorSelectDetailMapper.getMyMajorReport(recordId)).orElse(new ArrayList<>());
    }
}
