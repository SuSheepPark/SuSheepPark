/**   
 * Copyright © 2019 公司名. All rights reserved.
 * 
 * @Title: SlideServiceImpl.java 
 * @Prject: zhaowei-cms
 * @Package: com.zhaowei.cms.service.impl 
 * @Description: TODO
 * @author: zw   
 * @date: 2019年9月21日 上午11:21:13 
 * @version: V1.0   
 */
package com.zhaowei.cms.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.zhaowei.cms.dao.SlideMapper;
import com.zhaowei.cms.domain.Slide;
import com.zhaowei.cms.service.SlideService;

/** 
 * @ClassName: SlideServiceImpl 
 * @Description: TODO
 * @author: zw
 * @date: 2019年9月21日 上午11:21:13  
 */
@Service
public class SlideServiceImpl implements SlideService{

	@Resource
	private SlideMapper slideMapper;
	
	/* (non Javadoc) 
	 * @Title: selects
	 * @Description: TODO
	 * @return 
	 * @see com.zhaowei.cms.service.SlideService#selects() 
	 */
	@Override
	public List<Slide> selects() {
		// TODO Auto-generated method stub
		return slideMapper.selects();
	}

}
