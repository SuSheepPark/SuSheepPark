package com.ruida.mockservice.service;

import com.baomidou.mybatisplus.service.IService;
import com.ruida.mockdao.model.QuestionLibrary;

/**
 * <p>
 * 题库表 服务类
 * </p>
 *
 * @author chenjy
 * @since 2020-07-09
 */
public interface QuestionLibraryService extends IService<QuestionLibrary> {

}
