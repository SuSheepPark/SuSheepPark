package com.ruida.mockservice.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.ruida.mockdao.vo.jobInterest.JobInterestBuyInfoVO;
import com.ruida.mockservice.service.ISysConfigService;
import com.ruida.mockservice.service.ImageBannerService;
import com.ruida.mockservice.service.JobInterestService;
import com.ruida.mockservice.service.ProductService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * @author xumingqi
 * @date 2021/2/5 16:31
 */
@Service
public class JobInterestServiceImpl implements JobInterestService {
    @Resource
    ISysConfigService sysConfigService;
    @Resource
    ImageBannerService imageBannerService;
    @Resource
    ProductService productService;

    @Override
    public JobInterestBuyInfoVO getBuyInfoVO(Integer source) {
        JobInterestBuyInfoVO vo = new JobInterestBuyInfoVO();
        //宣传图
        //type 类型(0-科目选考封面 1-霍兰德测试封面)
        //source 平台(0-web端 1-app端)
        String imageUrl = imageBannerService.getImageBannerUrl(1, source == 0 ? 0 : 1);
        vo.setImageUrl(imageUrl);
        //文案
        String info = sysConfigService.getValueByKey("job_interest_info");
        JSONObject jsonObject = JSON.parseObject(info);
        String service = jsonObject.getString("service");
        vo.setService(service);
        //source 0—PC端 1—IOS端 2—Android端
        String instruction = source == 0 ? jsonObject.getString("webInstruction") :
                (source == 1 ? jsonObject.getString("iOSInstruction") : jsonObject.getString("AndroidInstruction"));
        List<String> instructionList = JSONArray.parseArray(instruction, String.class);
        vo.setInstruction(instructionList);
        //职业兴趣问卷不需要购买了 所以不需要productId和价格信息了
        return vo;
    }
}
