package com.ruida.assessment.assessmentquestionbank.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.assessment.assessmentquestionbank.model.TQuestionAssessmentRelation;
import com.ruida.assessment.assessmentquestionbank.model.TQuestionKnowledgeRelation;
import org.apache.ibatis.annotations.Mapper;

/**
 * @description: 试题考察要求关联关系dao层接口
 * @author: wy
 * @date: 2021/3/2
 */
@Mapper
public interface QuestionAssessmentRelationMapper extends BaseMapper<TQuestionAssessmentRelation> {
}
