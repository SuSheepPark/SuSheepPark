package com.ruida.mockdao.model;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import lombok.Data;

import java.io.Serializable;

/**
 * Created by xumingqi on 2021/7/1 13:15
 */
@Data
@TableName("t_subject")
public class Subject implements Serializable {
    private static final long serialVersionUID = 1L;
    /**
     * 科目id
     */
    @TableId
    private Integer id;

    /**
     * 科目名称
     */
    private String subjectName;

    /**
     * 状态（0—禁用；1—启用）
     */
    private String status;
}
