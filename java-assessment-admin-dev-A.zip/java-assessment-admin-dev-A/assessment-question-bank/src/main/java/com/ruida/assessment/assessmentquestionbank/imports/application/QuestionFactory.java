package com.ruida.assessment.assessmentquestionbank.imports.application;

import com.ruida.assessment.assessmentquestionbank.imports.docx.DocxReader;
import com.ruida.assessment.assessmentquestionbank.imports.domain.model.ErrorMsgException;
import com.ruida.assessment.assessmentquestionbank.imports.domain.model.Question;
import com.ruida.assessment.assessmentquestionbank.imports.domain.model.QuestionConfig;
import com.ruida.assessment.assessmentquestionbank.imports.domain.service.ErrorService;
import com.ruida.assessment.assessmentquestionbank.imports.domain.service.QuestionProtocol;

/**
 * 
 * 生成问题的工厂
 * @author mazhuang
 *
 */
public class QuestionFactory {

	private DocxReader reader;

	public QuestionFactory(DocxReader reader) {
		this.reader = reader;
	}

	public Question getQuestion() {

		QuestionProtocol.step2Question(reader);
		if (!reader.hasNext()) {
			return null;
		}
		Question question = new Question();
		question.setQuestionName(QuestionProtocol.getQuestionName(reader));
		try {
			QuestionConfig config = QuestionProtocol.getQuestionConfig(reader);
			question.setConfig(config);
			QuestionProtocolFactory questionProtocolFactory = QuestionProtocolFactory.getFactory();
			QuestionProtocol protocol = questionProtocolFactory.getQuestionProtocol(reader, config.getQuestionType());
			question.setBlock(protocol.parseBlock(config));
			return question;
		} catch (ErrorMsgException e) {
			ErrorService.addError(e.getLineNum(), question.getQuestionName(), e.getDesc());
		}

		return null;
	}
}
