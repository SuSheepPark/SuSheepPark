package com.ruida.assessment.assessmentquestionbank.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.assessment.assessmentquestionbank.dto.StudentRequest;
import com.ruida.assessment.assessmentquestionbank.dto.UserQueryRequest;
import com.ruida.assessment.assessmentquestionbank.model.TProductPresentRecord;
import com.ruida.assessment.assessmentquestionbank.vo.StudentInfoVo;
import com.ruida.assessment.assessmentquestionbank.vo.UserVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author wy
 * @description 商品赠送记录管理Mapper
 * @date 2020/8/10
 */
@Mapper
public interface ProductPresentRecordMapper extends BaseMapper<TProductPresentRecord> {

    /*
按条件查询该商品已赠送学员列表（废弃）
 */
    List<StudentInfoVo> queryProductPresentStudentList(@Param("vo") StudentRequest req);

    /*
    按条件查询该商品已赠送学员总数（废弃）
     */
    Integer queryProductPresentStudentCount(@Param("vo") StudentRequest req);

    /*
    按条件查询该商品已赠送用户列表
     */
    List<UserVo> queryProductPresentUserList(@Param("dto") UserQueryRequest req);

    /*
    按条件查询该商品已赠送用户总数
     */
    Integer queryProductPresentUserCount(@Param("dto") UserQueryRequest req);
}
