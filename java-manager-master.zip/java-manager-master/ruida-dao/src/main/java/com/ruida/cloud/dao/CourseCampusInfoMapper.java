package com.ruida.cloud.dao;

import com.ruida.cloud.daoTmp.CourseCampusInfo;

import java.util.List;
import java.util.Map;

public interface CourseCampusInfoMapper {
    List<CourseCampusInfo> listCourseCampusByCourseId(Integer courseId);

    List<Map<String ,Object>> getLimitOnlineNum(Map<String,Object> param);

    List<Map<String ,Object>> listCourseOrderNum(Map<String,Object> param);

    List<CourseCampusInfo> listCourseCampusByInfo(Map<String,Object> param);
}