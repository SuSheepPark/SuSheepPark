package com.ruida.mockdao.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.model.SmsCode;

/**
 * <p>
 * 短信验证码表 Mapper 接口
 * </p>
 *
 * @author Bhj
 * @since 2020-07-09
 */
public interface SmsCodeMapper extends BaseMapper<SmsCode> {

}
