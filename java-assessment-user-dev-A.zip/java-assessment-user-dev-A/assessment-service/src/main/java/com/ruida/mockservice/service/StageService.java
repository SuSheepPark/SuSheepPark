package com.ruida.mockservice.service;

import com.baomidou.mybatisplus.service.IService;
import com.ruida.mockdao.model.Stage;
import com.ruida.mockdao.vo.StageVO;

import java.util.List;


/**
 * <p>
 * 年级信息表 服务类
 * </p>
 *
 * @author chenjy
 * @since 2020-08-03
 */
public interface StageService extends IService<Stage> {

    List<StageVO> getStageList();

    List<Stage> getStageListByGradeId(Integer gradeId);
}
