package com.ruida.mockservice.service;

import com.baomidou.mybatisplus.service.IService;
import com.ruida.mockdao.model.TestPaperUserRel;

/**
 * <p>
 * 用户考试关联表 服务类
 * </p>
 *
 * @author jinhu
 * @since 2020-07-17
 */
public interface TestPaperUserRelService extends IService<TestPaperUserRel> {

}
