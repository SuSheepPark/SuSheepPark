package com.ruida.common.enums;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * 0—折扣优惠；1—金额优惠
 */
public enum DiscountMethod {

    discount(0,"折扣优惠"), amount(1,"金额优惠");

    public static final String SOURCE_KEY = "DiscountItemType";

    private int k;
    private String v;

    DiscountMethod(int k, String v) {
        this.k = k;
        this.v = v;
    }

    public static Map<Integer, String> map = new LinkedHashMap<>(2);
    static
    {
        for(DiscountMethod type : DiscountMethod.values())
        {
            map.put(type.getK(),type.getV());
        }
    }

    public static String getSourceKey() {
        return SOURCE_KEY;
    }

    public int getK() {
        return k;
    }

    public void setK(int k) {
        this.k = k;
    }

    public String getV() {
        return v;
    }

    public void setV(String v) {
        this.v = v;
    }

    /***
     * 根据k获取v的值
     * @param k
     * @return
     */
    public static String getvByk(int k) {
        DiscountMethod[] list = DiscountMethod.values();
        for (DiscountMethod valid : list) {
            if (valid.getK() == k ) {
                return valid.getV();
            }
        }
        return "";
    }
}
