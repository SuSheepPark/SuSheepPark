package com.ruida.mockdao.dao;


import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.model.StudyCoinRecord;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * IOS学币记录表 Mapper 接口
 * </p>
 *
 * @author Bhj
 * @since 2020-07-29
 */
public interface StudyCoinRecordMapper extends BaseMapper<StudyCoinRecord> {

    List<Map<String, Object>> listStudyCoinRecordByPage(Map<String, Object> param);

    Integer countStudyCoinRecordByPage(Map<String, Object> param);
}
