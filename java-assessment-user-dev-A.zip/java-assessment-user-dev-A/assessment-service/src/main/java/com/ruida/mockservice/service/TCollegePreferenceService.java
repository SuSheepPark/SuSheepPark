package com.ruida.mockservice.service;

import com.baomidou.mybatisplus.service.IService;
import com.ruida.mockcommon.result.Page;
import com.ruida.mockdao.model.TCollegePreference;
import com.ruida.mockdao.vo.report.CollegePreferenceReportListVO;
import com.ruida.mockservice.vo.preference.PreferenceFillInfoVO;
import com.ruida.mockservice.vo.preference.PreferenceIndexInfo;
import com.ruida.mockservice.vo.preference.PreferenceReportVO;
import com.ruida.mockservice.vo.preference.RecommendMajorVO;

import java.util.List;

/**
 * <p>
 * 志愿填报报告 服务类
 * </p>
 *
 * @author szl
 * @since 2021-03-02
 */
public interface TCollegePreferenceService extends IService<TCollegePreference> {
    /**
     * 用户是否有购买报告
     * @return
     */
    Boolean checkReportBuyStatus(Integer userId);

    TCollegePreference getReportByOrderNo(String orderNo);

    /**
     * 保存完善信息
     * @return
     */
    Integer saveFillInfo(Double score , String subjectIds,Integer userId);

    /**
     * 获取完善信息返回
     * @param userId
     * @return
     */
    PreferenceFillInfoVO getFillInfo(Integer type,Integer userId);

    /**
     * 获取首页信息
     *
     * @return
     */
    PreferenceIndexInfo getIndexInfo(Integer userId);

    PreferenceReportVO getReportInfo(TCollegePreference preference, Integer userId);

    List<RecommendMajorVO> searchRecommendMajor(Integer reportId, Integer type, String province,
                                                String collegeLevelName, String subjectCategoryName,
                                                String majorCategoryName, String majorName);

    /**
     * 创建报告
     *
     * @return
     */
    Integer saveReport(Integer userId,String orderNo,Integer type);

    Page<CollegePreferenceReportListVO> getReportList(Integer userId, Integer currentPage, Integer pageSize);

    /**
     * 生成报告的信息和上次是否一样
     * @return
     */
    Boolean isEqFillInfo(Integer userId);
    /**
     * 更新订单号到已生成的报告
     *
     * @return
     */
    Boolean updateCreatedReport(String orderNo, Integer reportId);
}
