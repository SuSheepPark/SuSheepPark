package com.ruida.mockservice.service.impl;


import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.ruida.mockcommon.enums.AppErrorEnum;
import com.ruida.mockcommon.exception.CoreException;
import com.ruida.mockcommon.util.ValidateMT;
import com.ruida.mockdao.dao.AppVersionMapper;
import com.ruida.mockdao.model.AppVersion;
import com.ruida.mockservice.service.AppVersionService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * <p>
 * APP版本信息表 服务实现类
 * </p>
 *
 * @author Bhj
 * @since 2020-07-17
 */
@Service
public class AppVersionServiceImpl extends ServiceImpl<AppVersionMapper, AppVersion> implements AppVersionService {
    @Resource
    private AppVersionMapper appVersionMapper;
    @Value("${android.download.path}")
    private String localHost;
    @Value("${project.name}")
    private String projectName;

    @Override
    public AppVersion getAppVersionInfo(Integer type) {
        EntityWrapper<AppVersion> entityWrapper = new EntityWrapper<>();
        entityWrapper.andNew().eq("type", type).eq("isdelete",0).orderBy("app_version_id", false);
        List<AppVersion> list = appVersionMapper.selectList(entityWrapper);
        if (ValidateMT.isNotNull(list)) {
            AppVersion appVersion = list.get(0);
            if (type == 1) {
                //假如是安卓 需要拼接下载地址
                appVersion.setUrl(localHost + "/" + projectName + appVersion.getUrl());
            }
            return appVersion;
        }else{
            throw new CoreException(AppErrorEnum.E_10034);
        }
    }
}
