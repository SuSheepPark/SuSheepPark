package com.ruida.assessment.assessmentcommon.enums;

/**
 * @description: 操作类型，记录日志使用
 * @author: kgz
 * @date: 2020/8/11
 */
public enum OperateTypeEnum {
    ADD(1,"新增"),
    UPDATE(2,"修改"),
    DELETE(3,"删除"),
    RELEASE(4,"发布"),
    RETURN(5,"退回"),
    RELEASE_CANCEL(5,"取消发布"),
    MOVE(6,"移动"),
    FORBID(7,"禁用"),
    ACTIVATE(8,"启用"),
    COMPLETE_CORRECT(9,"完成批改"),
    ARRANGE_CORRECT(10,"分配批改"),
    CHECK_UP(11,"上架或下架"),
    DOWN(12,"下架"),
    EDIT(13,"编辑"),
    PRESENT(14,"赠送"),
    TOP(15,"置顶"),
    FREEZE(16,"冻结"),
    RECOVER(17,"恢复"),
    CHECK(18,"审核"),
    CHANGE(19,"更换"),
    RESET_PWD(20,"重置密码"),
    REPLY(21,"回复"),
    REFUND(22,"标记退费"),
    MODIFY_PWD(23,"修改密码"),
    SEND_CUSTOM(24,"自定义发送"),
    DISPLAY(25,"显示"),
    HIDE(26,"隐藏"),
    CLOSE(27,"关闭"),
    EDIT_SAVE(28,"编辑保存"),
    STOP_START(29,"更改状态"),
    DELETE_UPDATESTATUS(30,"删除或更改状态"),
    No_TOP(31,"取消置顶"),
    MORE_OPERATION(32,"删除、退回"),
    LOGIN(33,"登录"),
    SUBMIT(34,"提交"),
    EXCEL_IMPORT(35,"批量导入学员"),
    ;


    private Integer id;
    private String operateType;

    OperateTypeEnum(Integer id, String operateType) {
        this.id = id;
        this.operateType = operateType;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getOperateType() {
        return operateType;
    }

    public void setOperateType(String operateType) {
        this.operateType = operateType;
    }

    public static OperateTypeEnum getValueById(Integer id){
        for(OperateTypeEnum operateTypeEnum : OperateTypeEnum.values() ){
            if(operateTypeEnum.getId().equals(id)){
                return  operateTypeEnum;
            }
        }
        return null;
    }

}
