package com.ruida.cloud.dao;

import com.ruida.cloud.model.SysRole;
import org.apache.ibatis.annotations.*;

import java.util.List;
import java.util.Map;

public interface SysRoleMapperExt {
    /**
     * 获取角色信息
     *
     * @param userId
     * @return
     */
    List<SysRole> getUserRoleList(Integer userId);

    /**
     * 获取用户列表
     *
     * @param param
     * @return
     */
    List<Map<String, Object>> getUserList(Map<String, Object> param);

    /**
     * @param param
     * @return 获取总数
     */
    Integer getUserCount(Map<String, Object> param);

    /**
     * 获取角色信息
     *
     * @return
     */
    List<Map<String, Object>> getRoleList();

    /**
     * 获取部门信息
     *
     * @return
     */
    List<Map<String, Object>> getDeptList(Map<String,Object> param);

    /**
     * 获取角色列表（条件查询）
     *
     * @param param
     * @return
     */
    List<SysRole> selectRoleList(Map param);

    /**
     * @param telephone
     * @return 获取用户信息根据手机号码
     */
    Map<String, Object> getUserByTelephone(@Param("telephone") String telephone);

    /**
     * @param userId
     * @return 获取用户信息根据user_id
     */
    Map<String, Object> getUserByUserId(@Param("userId") Integer userId);

    //根据用户id删除该用户的所有角色和部门
    @Delete("delete from sys_user_role  where user_id =#{userId} and department_id=#{deptId}")
    Integer deleteRoleAndDeptByUserIdAndDeptId(@Param("userId") Integer userId
            , @Param("deptId") Integer deptId);

    @Insert("INSERT INTO sys_user_role (user_id, role_id, department_id) VALUES (#{userId}, #{roleId}, #{deptId}) ")
    Integer saveRoleAndDept(Map<String, Object> param);

    List<Map<String, Object>> getRoleListByDeptId(@Param("deptId") Integer deptId);

    List<Map<String, Object>> getDeptAndRoleListByUserId(@Param("userId") Integer userId);


    List<Map<String, Object>> getDeptListByUserId(@Param("userId") Integer userId);

    List<Map<String, Object>> getRoleListByDeptIdAndUserId(@Param("userId") Integer userId, @Param("deptId") Integer deptId);

    @Update("update sys_user set isdelete = 1  where user_id = #{userId} ")
    Integer deleteUser(@Param("userId") Integer userId);

    @Delete("delete from sys_user_role  where user_id = #{userId}")
    Integer deleteUserRole(@Param("userId") Integer userId);

    @Update("update sys_user set status =#{status} where  user_id =#{userId} ")
    Integer updateStatus(@Param("userId") Integer userId, @Param("status") Integer status);

    @Select("select role_type from sys_role where role_id =#{roleId}")
    Integer getRoleTypeByRoleId(@Param("roleId") Integer roleId);

    @Select("select department_id from sys_role where role_id =#{roleId}")
    Integer getDeptIdByRoleId(@Param("roleId") String roleId);

    @Select("SELECT\n" +
            "a.department_id as departmentId,a.role_id as roleId,a.role_type as roleType\n" +
            "FROM\n" +
            "\tsys_role a\n" +
            "LEFT JOIN sys_user_role b ON a.role_id = b.role_id\n" +
            "WHERE b.user_id = #{userId} AND (a.role_type = 0 OR a.role_type =1)")
    List<SysRole> selectRoleTypeForUser(@Param("userId") Integer userId);//根据角色类型和用户查询
    /**
     * 获取角色列表数量条件查询）
     *
     * @param param
     * @return
     */

   Integer selectRoleCount(Map param);


   @Select("select role_id from sys_user_role where user_id = #{userId} ")
   List<String> selectHasRoleLists(Integer userId);
}
