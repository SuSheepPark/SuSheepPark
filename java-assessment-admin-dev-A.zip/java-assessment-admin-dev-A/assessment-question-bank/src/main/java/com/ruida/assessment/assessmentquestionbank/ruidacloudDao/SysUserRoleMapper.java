package com.ruida.assessment.assessmentquestionbank.ruidacloudDao;

import com.ruida.assessment.assessmentquestionbank.model.SysUserRole;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import jdk.internal.dynalink.linker.LinkerServices;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * 用户角色表 Mapper 接口
 * </p>
 *
 * @author szl
 * @since 2020-07-14
 */
public interface SysUserRoleMapper extends BaseMapper<SysUserRole> {
    /***
     * 获取用户的角色信息
     * @param userId
     * @return
     */
    @Select("SELECT\n" +
            "\ta.role_id as roleId,\n" +
            "\tb.role_name as roleName,\n" +
            "\tb.role_type as roleType,\n" +
            "\tb.role_code as roleCode\n" +
            "FROM\n" +
            "\tsys_user_role a\n" +
            "LEFT JOIN sys_role b ON a.role_id = b.role_id\n" +
            "WHERE\n" +
            "\ta.user_id = #{userId}")
    List<Map<String,Object>> getUserRoles(@Param("userId") Integer userId);
}
