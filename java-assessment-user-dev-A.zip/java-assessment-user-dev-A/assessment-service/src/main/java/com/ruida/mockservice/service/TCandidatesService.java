package com.ruida.mockservice.service;

import com.baomidou.mybatisplus.service.IService;
import com.ruida.mockdao.model.TCandidates;

import java.util.List;

/**
 * <p>
 * 实施对象表 服务类
 * </p>
 *
 * @author szl
 * @since 2021-07-22
 */
public interface TCandidatesService extends IService<TCandidates> {
    /**
     * 添加实施对象场次记录
     *
     * @param productId
     * @param testPaperId
     * @return
     */
    Boolean addCandidatesRecord(Integer productId, Integer testPaperId, Integer userId);

    /**
     * 根据场次id查询实施对象
     * @param sceneId
     * @return
     */
    List<TCandidates> selectAllStuBySceneId(String sceneId);
}
