package com.ruida.cloud.weidu.enums;

/**
 * @param
 * @description 错误代码
 * @return
 */
public enum ResultStatusCode {
    OK(0, "操作成功"),
    SIGN_ERROR(120, "签名错误"),
    TIME_OUT(130, "访问超时"),
    BAD_REQUEST(400, "参数解析失败"),
    INVALID_TOKEN(401, "无效的授权码"),
    INVALID_CLIENTID(402, "无效的密钥"),
    METHOD_NOT_ALLOWED(405, "不支持当前请求方法"),
    SYSTEM_ERR(500, "服务器运行异常"),
    NOT_EXIST_USER_OR_ERROR_PWD(10000, "该用户不存在或密码错误"),
    LOGINED_IN(10001, "该用户已登录"),
    NOT_EXIST_BUSINESS(10002, "该商家不存在"),
    SHIRO_ERROR(10003, "登录异常"),
    UNAUTHO_ERROR(10004, "您没有该权限"),
    BIND_PHONE(10010, "请绑定手机号"),
    UPLOAD_ERROR(20000, "上传文件异常"),
    INVALID_CAPTCHA(30005, "无效的验证码"),
    USER_FROZEN(40000, "该用户已被冻结"),
    PERFECT_GOOD_INFORMATION(50000, "请完善课程信息后再发布"),
    TEACHER_INFO_FAIL(50001, "获取教师信息失败"),
    DEAL_FAIL(50002, "操作失败"),
    UPLOAD_EMPTY_FILE(50003, "上传文件为空"),
    UPLOAD_FAIL(50004, "上传失败"),
    UPLOAD_OVERSIZE(50005, "上传文件过大"),
    UPLOAD_SUCCESS(50006, "上传成功"),
    DELETE_LESSON_PUBLISH(60001, "课程已上线，不可删除"),
    FORBIDDEN_SUCCESS(700001,"禁用成功"),
    FORBIDDEN_FAIL(70002,"禁用失败"),
    USING_SUCCESS(700003,"启用成功"),
    USING_FAIL(70004,"启用失败"),
    RELEASE_SUCCESS(70005, "发布成功"),
    RELEASE_FAIL(70006, "发布失败");

    private int code;
    private String msg;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    private ResultStatusCode(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }
}
