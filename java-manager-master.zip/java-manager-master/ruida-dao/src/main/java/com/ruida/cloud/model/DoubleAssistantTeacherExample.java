package com.ruida.cloud.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class DoubleAssistantTeacherExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public DoubleAssistantTeacherExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andAssistantTeacherIdIsNull() {
            addCriterion("assistant_teacher_id is null");
            return (Criteria) this;
        }

        public Criteria andAssistantTeacherIdIsNotNull() {
            addCriterion("assistant_teacher_id is not null");
            return (Criteria) this;
        }

        public Criteria andAssistantTeacherIdEqualTo(Integer value) {
            addCriterion("assistant_teacher_id =", value, "assistantTeacherId");
            return (Criteria) this;
        }

        public Criteria andAssistantTeacherIdNotEqualTo(Integer value) {
            addCriterion("assistant_teacher_id <>", value, "assistantTeacherId");
            return (Criteria) this;
        }

        public Criteria andAssistantTeacherIdGreaterThan(Integer value) {
            addCriterion("assistant_teacher_id >", value, "assistantTeacherId");
            return (Criteria) this;
        }

        public Criteria andAssistantTeacherIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("assistant_teacher_id >=", value, "assistantTeacherId");
            return (Criteria) this;
        }

        public Criteria andAssistantTeacherIdLessThan(Integer value) {
            addCriterion("assistant_teacher_id <", value, "assistantTeacherId");
            return (Criteria) this;
        }

        public Criteria andAssistantTeacherIdLessThanOrEqualTo(Integer value) {
            addCriterion("assistant_teacher_id <=", value, "assistantTeacherId");
            return (Criteria) this;
        }

        public Criteria andAssistantTeacherIdIn(List<Integer> values) {
            addCriterion("assistant_teacher_id in", values, "assistantTeacherId");
            return (Criteria) this;
        }

        public Criteria andAssistantTeacherIdNotIn(List<Integer> values) {
            addCriterion("assistant_teacher_id not in", values, "assistantTeacherId");
            return (Criteria) this;
        }

        public Criteria andAssistantTeacherIdBetween(Integer value1, Integer value2) {
            addCriterion("assistant_teacher_id between", value1, value2, "assistantTeacherId");
            return (Criteria) this;
        }

        public Criteria andAssistantTeacherIdNotBetween(Integer value1, Integer value2) {
            addCriterion("assistant_teacher_id not between", value1, value2, "assistantTeacherId");
            return (Criteria) this;
        }

        public Criteria andAssistantTeacherIdBjyIsNull() {
            addCriterion("assistant_teacher_id_bjy is null");
            return (Criteria) this;
        }

        public Criteria andAssistantTeacherIdBjyIsNotNull() {
            addCriterion("assistant_teacher_id_bjy is not null");
            return (Criteria) this;
        }

        public Criteria andAssistantTeacherIdBjyEqualTo(String value) {
            addCriterion("assistant_teacher_id_bjy =", value, "assistantTeacherIdBjy");
            return (Criteria) this;
        }

        public Criteria andAssistantTeacherIdBjyNotEqualTo(String value) {
            addCriterion("assistant_teacher_id_bjy <>", value, "assistantTeacherIdBjy");
            return (Criteria) this;
        }

        public Criteria andAssistantTeacherIdBjyGreaterThan(String value) {
            addCriterion("assistant_teacher_id_bjy >", value, "assistantTeacherIdBjy");
            return (Criteria) this;
        }

        public Criteria andAssistantTeacherIdBjyGreaterThanOrEqualTo(String value) {
            addCriterion("assistant_teacher_id_bjy >=", value, "assistantTeacherIdBjy");
            return (Criteria) this;
        }

        public Criteria andAssistantTeacherIdBjyLessThan(String value) {
            addCriterion("assistant_teacher_id_bjy <", value, "assistantTeacherIdBjy");
            return (Criteria) this;
        }

        public Criteria andAssistantTeacherIdBjyLessThanOrEqualTo(String value) {
            addCriterion("assistant_teacher_id_bjy <=", value, "assistantTeacherIdBjy");
            return (Criteria) this;
        }

        public Criteria andAssistantTeacherIdBjyLike(String value) {
            addCriterion("assistant_teacher_id_bjy like", value, "assistantTeacherIdBjy");
            return (Criteria) this;
        }

        public Criteria andAssistantTeacherIdBjyNotLike(String value) {
            addCriterion("assistant_teacher_id_bjy not like", value, "assistantTeacherIdBjy");
            return (Criteria) this;
        }

        public Criteria andAssistantTeacherIdBjyIn(List<String> values) {
            addCriterion("assistant_teacher_id_bjy in", values, "assistantTeacherIdBjy");
            return (Criteria) this;
        }

        public Criteria andAssistantTeacherIdBjyNotIn(List<String> values) {
            addCriterion("assistant_teacher_id_bjy not in", values, "assistantTeacherIdBjy");
            return (Criteria) this;
        }

        public Criteria andAssistantTeacherIdBjyBetween(String value1, String value2) {
            addCriterion("assistant_teacher_id_bjy between", value1, value2, "assistantTeacherIdBjy");
            return (Criteria) this;
        }

        public Criteria andAssistantTeacherIdBjyNotBetween(String value1, String value2) {
            addCriterion("assistant_teacher_id_bjy not between", value1, value2, "assistantTeacherIdBjy");
            return (Criteria) this;
        }

        public Criteria andAssistantTeacherNameIsNull() {
            addCriterion("assistant_teacher_name is null");
            return (Criteria) this;
        }

        public Criteria andAssistantTeacherNameIsNotNull() {
            addCriterion("assistant_teacher_name is not null");
            return (Criteria) this;
        }

        public Criteria andAssistantTeacherNameEqualTo(String value) {
            addCriterion("assistant_teacher_name =", value, "assistantTeacherName");
            return (Criteria) this;
        }

        public Criteria andAssistantTeacherNameNotEqualTo(String value) {
            addCriterion("assistant_teacher_name <>", value, "assistantTeacherName");
            return (Criteria) this;
        }

        public Criteria andAssistantTeacherNameGreaterThan(String value) {
            addCriterion("assistant_teacher_name >", value, "assistantTeacherName");
            return (Criteria) this;
        }

        public Criteria andAssistantTeacherNameGreaterThanOrEqualTo(String value) {
            addCriterion("assistant_teacher_name >=", value, "assistantTeacherName");
            return (Criteria) this;
        }

        public Criteria andAssistantTeacherNameLessThan(String value) {
            addCriterion("assistant_teacher_name <", value, "assistantTeacherName");
            return (Criteria) this;
        }

        public Criteria andAssistantTeacherNameLessThanOrEqualTo(String value) {
            addCriterion("assistant_teacher_name <=", value, "assistantTeacherName");
            return (Criteria) this;
        }

        public Criteria andAssistantTeacherNameLike(String value) {
            addCriterion("assistant_teacher_name like", value, "assistantTeacherName");
            return (Criteria) this;
        }

        public Criteria andAssistantTeacherNameNotLike(String value) {
            addCriterion("assistant_teacher_name not like", value, "assistantTeacherName");
            return (Criteria) this;
        }

        public Criteria andAssistantTeacherNameIn(List<String> values) {
            addCriterion("assistant_teacher_name in", values, "assistantTeacherName");
            return (Criteria) this;
        }

        public Criteria andAssistantTeacherNameNotIn(List<String> values) {
            addCriterion("assistant_teacher_name not in", values, "assistantTeacherName");
            return (Criteria) this;
        }

        public Criteria andAssistantTeacherNameBetween(String value1, String value2) {
            addCriterion("assistant_teacher_name between", value1, value2, "assistantTeacherName");
            return (Criteria) this;
        }

        public Criteria andAssistantTeacherNameNotBetween(String value1, String value2) {
            addCriterion("assistant_teacher_name not between", value1, value2, "assistantTeacherName");
            return (Criteria) this;
        }

        public Criteria andTelephoneIsNull() {
            addCriterion("telephone is null");
            return (Criteria) this;
        }

        public Criteria andTelephoneIsNotNull() {
            addCriterion("telephone is not null");
            return (Criteria) this;
        }

        public Criteria andTelephoneEqualTo(String value) {
            addCriterion("telephone =", value, "telephone");
            return (Criteria) this;
        }

        public Criteria andTelephoneNotEqualTo(String value) {
            addCriterion("telephone <>", value, "telephone");
            return (Criteria) this;
        }

        public Criteria andTelephoneGreaterThan(String value) {
            addCriterion("telephone >", value, "telephone");
            return (Criteria) this;
        }

        public Criteria andTelephoneGreaterThanOrEqualTo(String value) {
            addCriterion("telephone >=", value, "telephone");
            return (Criteria) this;
        }

        public Criteria andTelephoneLessThan(String value) {
            addCriterion("telephone <", value, "telephone");
            return (Criteria) this;
        }

        public Criteria andTelephoneLessThanOrEqualTo(String value) {
            addCriterion("telephone <=", value, "telephone");
            return (Criteria) this;
        }

        public Criteria andTelephoneLike(String value) {
            addCriterion("telephone like", value, "telephone");
            return (Criteria) this;
        }

        public Criteria andTelephoneNotLike(String value) {
            addCriterion("telephone not like", value, "telephone");
            return (Criteria) this;
        }

        public Criteria andTelephoneIn(List<String> values) {
            addCriterion("telephone in", values, "telephone");
            return (Criteria) this;
        }

        public Criteria andTelephoneNotIn(List<String> values) {
            addCriterion("telephone not in", values, "telephone");
            return (Criteria) this;
        }

        public Criteria andTelephoneBetween(String value1, String value2) {
            addCriterion("telephone between", value1, value2, "telephone");
            return (Criteria) this;
        }

        public Criteria andTelephoneNotBetween(String value1, String value2) {
            addCriterion("telephone not between", value1, value2, "telephone");
            return (Criteria) this;
        }

        public Criteria andStatusIsNull() {
            addCriterion("status is null");
            return (Criteria) this;
        }

        public Criteria andStatusIsNotNull() {
            addCriterion("status is not null");
            return (Criteria) this;
        }

        public Criteria andStatusEqualTo(Byte value) {
            addCriterion("status =", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotEqualTo(Byte value) {
            addCriterion("status <>", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusGreaterThan(Byte value) {
            addCriterion("status >", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusGreaterThanOrEqualTo(Byte value) {
            addCriterion("status >=", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusLessThan(Byte value) {
            addCriterion("status <", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusLessThanOrEqualTo(Byte value) {
            addCriterion("status <=", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusIn(List<Byte> values) {
            addCriterion("status in", values, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotIn(List<Byte> values) {
            addCriterion("status not in", values, "status");
            return (Criteria) this;
        }

        public Criteria andStatusBetween(Byte value1, Byte value2) {
            addCriterion("status between", value1, value2, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotBetween(Byte value1, Byte value2) {
            addCriterion("status not between", value1, value2, "status");
            return (Criteria) this;
        }

        public Criteria andCreateByIsNull() {
            addCriterion("create_by is null");
            return (Criteria) this;
        }

        public Criteria andCreateByIsNotNull() {
            addCriterion("create_by is not null");
            return (Criteria) this;
        }

        public Criteria andCreateByEqualTo(Integer value) {
            addCriterion("create_by =", value, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByNotEqualTo(Integer value) {
            addCriterion("create_by <>", value, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByGreaterThan(Integer value) {
            addCriterion("create_by >", value, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByGreaterThanOrEqualTo(Integer value) {
            addCriterion("create_by >=", value, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByLessThan(Integer value) {
            addCriterion("create_by <", value, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByLessThanOrEqualTo(Integer value) {
            addCriterion("create_by <=", value, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByIn(List<Integer> values) {
            addCriterion("create_by in", values, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByNotIn(List<Integer> values) {
            addCriterion("create_by not in", values, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByBetween(Integer value1, Integer value2) {
            addCriterion("create_by between", value1, value2, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByNotBetween(Integer value1, Integer value2) {
            addCriterion("create_by not between", value1, value2, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNull() {
            addCriterion("create_time is null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNotNull() {
            addCriterion("create_time is not null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeEqualTo(Date value) {
            addCriterion("create_time =", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotEqualTo(Date value) {
            addCriterion("create_time <>", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThan(Date value) {
            addCriterion("create_time >", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("create_time >=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThan(Date value) {
            addCriterion("create_time <", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThanOrEqualTo(Date value) {
            addCriterion("create_time <=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIn(List<Date> values) {
            addCriterion("create_time in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotIn(List<Date> values) {
            addCriterion("create_time not in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeBetween(Date value1, Date value2) {
            addCriterion("create_time between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotBetween(Date value1, Date value2) {
            addCriterion("create_time not between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andUpdateByIsNull() {
            addCriterion("update_by is null");
            return (Criteria) this;
        }

        public Criteria andUpdateByIsNotNull() {
            addCriterion("update_by is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateByEqualTo(Integer value) {
            addCriterion("update_by =", value, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByNotEqualTo(Integer value) {
            addCriterion("update_by <>", value, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByGreaterThan(Integer value) {
            addCriterion("update_by >", value, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByGreaterThanOrEqualTo(Integer value) {
            addCriterion("update_by >=", value, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByLessThan(Integer value) {
            addCriterion("update_by <", value, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByLessThanOrEqualTo(Integer value) {
            addCriterion("update_by <=", value, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByIn(List<Integer> values) {
            addCriterion("update_by in", values, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByNotIn(List<Integer> values) {
            addCriterion("update_by not in", values, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByBetween(Integer value1, Integer value2) {
            addCriterion("update_by between", value1, value2, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByNotBetween(Integer value1, Integer value2) {
            addCriterion("update_by not between", value1, value2, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNull() {
            addCriterion("update_time is null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNotNull() {
            addCriterion("update_time is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeEqualTo(Date value) {
            addCriterion("update_time =", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotEqualTo(Date value) {
            addCriterion("update_time <>", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThan(Date value) {
            addCriterion("update_time >", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("update_time >=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThan(Date value) {
            addCriterion("update_time <", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThanOrEqualTo(Date value) {
            addCriterion("update_time <=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIn(List<Date> values) {
            addCriterion("update_time in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotIn(List<Date> values) {
            addCriterion("update_time not in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeBetween(Date value1, Date value2) {
            addCriterion("update_time between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotBetween(Date value1, Date value2) {
            addCriterion("update_time not between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andIsdeleteIsNull() {
            addCriterion("isdelete is null");
            return (Criteria) this;
        }

        public Criteria andIsdeleteIsNotNull() {
            addCriterion("isdelete is not null");
            return (Criteria) this;
        }

        public Criteria andIsdeleteEqualTo(Byte value) {
            addCriterion("isdelete =", value, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteNotEqualTo(Byte value) {
            addCriterion("isdelete <>", value, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteGreaterThan(Byte value) {
            addCriterion("isdelete >", value, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteGreaterThanOrEqualTo(Byte value) {
            addCriterion("isdelete >=", value, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteLessThan(Byte value) {
            addCriterion("isdelete <", value, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteLessThanOrEqualTo(Byte value) {
            addCriterion("isdelete <=", value, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteIn(List<Byte> values) {
            addCriterion("isdelete in", values, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteNotIn(List<Byte> values) {
            addCriterion("isdelete not in", values, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteBetween(Byte value1, Byte value2) {
            addCriterion("isdelete between", value1, value2, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteNotBetween(Byte value1, Byte value2) {
            addCriterion("isdelete not between", value1, value2, "isdelete");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}