package com.ruida.cloud.dao;

import com.ruida.cloud.model.TCourseQuestionItem;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

public interface TCourseQuestionItemMapper {
    /**
     * @param QuestionId
     * @return 查询所有的问题
     */
    @Select("select course_question_item_id AS courseQuestionItemId,\n" +
            " course_question_id AS courseQuestionId,\n" +
            " tag,\n" +
            " content \n" +
            "  from t_course_question_item where course_question_id = #{QuestionId} and isdelete = 0 ")
    List<TCourseQuestionItem> getQuestionItemList(Integer QuestionId);

    /**
     * 批量删除（逻辑删除）
     *
     * @param questionIds
     * @return
     */
    @Update("update t_course_question_item set isdelete = 1 where  course_question_id in (#{questionIds})")
    Integer deleteQuestion(@Param("questionIds") String questionIds);

    /**
     * @param questionId
     * @return 删除指定的记录
     */
    @Update("update t_course_question_item set isdelete = 1 where  course_question_id =#{questionId})")
    Integer deleteQuestionItemById(@Param("questionId") Integer questionId);

    /**
     * 新增子选项
     *
     * @param tCourseQuestionItem
     */
    void insertQuestionItem(TCourseQuestionItem tCourseQuestionItem);
}
