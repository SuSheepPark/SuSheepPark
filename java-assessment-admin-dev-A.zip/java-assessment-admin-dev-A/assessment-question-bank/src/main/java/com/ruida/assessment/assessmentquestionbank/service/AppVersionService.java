package com.ruida.assessment.assessmentquestionbank.service;

import com.baomidou.mybatisplus.service.IService;
import com.ruida.assessment.assessmentquestionbank.dto.AppVersionDetailDTO;
import com.ruida.assessment.assessmentquestionbank.model.TAppVersion;
import com.ruida.assessment.assessmentquestionbank.vo.AppVersionDetailVO;

/**
 * @description: APP更新业务层接口
 * @author: kgz
 * @date: 2020/8/17
 */
public interface AppVersionService extends IService<TAppVersion> {
    /**
     * 获取APP版本更新信息
     * @return
     * @param type
     */
    AppVersionDetailVO getAppVersionDetail(Integer type);

    /**
     * 保存APP版本更新信息
     * @param appVersionDTO
     */
    void saveAppVersion(AppVersionDetailDTO appVersionDTO);
}
