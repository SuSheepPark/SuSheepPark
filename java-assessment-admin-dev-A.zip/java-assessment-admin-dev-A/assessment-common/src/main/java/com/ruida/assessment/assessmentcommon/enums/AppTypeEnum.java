package com.ruida.assessment.assessmentcommon.enums;

/**
 * @description: APP类型
 * @author: kgz
 * @date: 2020/8/17
 */
public enum AppTypeEnum {
    ANDROID(1,"Android"),
    IOS(2,"IOS"),
    ;

    private Integer K;
    private String V;

    AppTypeEnum(Integer k, String v) {
        K = k;
        V = v;
    }

    public Integer getK() {
        return K;
    }

    public void setK(Integer k) {
        K = k;
    }

    public String getV() {
        return V;
    }

    public void setV(String v) {
        V = v;
    }


    public static AppTypeEnum getValueById(Integer K){
        for(AppTypeEnum appTypeEnum : AppTypeEnum.values() ){
            if(appTypeEnum.getK().equals(K)){
                return  appTypeEnum;
            }
        }
        return null;
    }

}
