package com.ruida.common.enums;

/**
 * 展示互动接口错误码
 */
public enum GseenErrorEnum {


    // 展示互动返回错误code信息
    E_100(-1, "500", "失败"),
    E_101(101, "503", "参数错误"),
    E_102(102, "500", "参数转换错误"),
    E_200(200, "400", "认证失败"),
    E_201(201, "500", "口令过期"),
    E_300(300, "500", "系统错误"),
    E_500(500, "500", "业务错误"),
    E_501(501, "500", "业务错误 – 数据不存在"),
    E_502(502, "500", "业务错误 – 重复数据"),
    E_600(600, "500", "接口被禁用，请联系管理员");

    String httpStatus = "";
    int errorCode = -1;
    String errorMessage = "";

    public String getHttpStatus() {
        return httpStatus;
    }

    public int getErrorCode() {
        return errorCode;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    GseenErrorEnum(int errorCode, String httpStatus, String errorMessage) {
        this.httpStatus = httpStatus;
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
    }

}
