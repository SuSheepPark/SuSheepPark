package com.ruida.cloud.weidu.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.ruida.cloud.dao.WeiduCourseRelMapper;
import com.ruida.cloud.model.WeiduCourseRel;
import com.ruida.cloud.weidu.config.WeiduConfig;
import com.ruida.cloud.weidu.exception.VdyooException;
import com.ruida.cloud.weidu.service.BaseVdyooService;
import com.ruida.cloud.weidu.vo.VdyooEntity;
import com.ruida.common.context.BaseContextHandle;
import com.ruida.common.util.ValidateMT;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * 课程关联表：
 * 睿达课程id     pid
 * 威渡课程id     id
 *
 * @author taosh
 * @create 2019-04-23 16:11
 */
@Service
@Slf4j
public class VdyooCourseService extends BaseVdyooService {
    @Resource
    private WeiduCourseRelMapper weiduCourseRelMapper;

    /**
     * 添加课程
     * , propagation= Propagation.NESTED
     */
    @Transactional(rollbackFor = Exception.class,propagation=Propagation.NESTED)
    public String addCourse(Map<String, Object> params) {
        //处理业务逻辑
        VdyooEntity vdyooEntity = vdyooFactory.post(params, WeiduConfig.addCourse);
        boolean flag = false;
        String id = null;

        if (vdyooEntity.getSuccess()) {
            try {
                //插入关联表
                WeiduCourseRel entity = new WeiduCourseRel();
                entity.setCourseId((Integer) params.get("pid"));
                JSONObject object =(JSONObject) JSON.toJSON(vdyooEntity.getPayload());
                entity.setWeiduCourseId(object.getString("id"));
                entity.setCreateBy(BaseContextHandle.getUserId());
                entity.setCreateTime(new Date());
                entity.setIsdelete((byte) 0);
                entity.setUpdateBy(BaseContextHandle.getUserId());
                entity.setUpdateTime(new Date());
                id = object.getString("id");
                flag = weiduCourseRelMapper.insert(entity) > 0;
                if( !flag ){
                    throw new VdyooException("500", "威渡课程关联失败，请联系管理员或稍后再试");
                }else{
                    return id;
                }
            } catch (Exception e) {
                //失败了回滚到以前（调用维度删除接口）
                if (ValidateMT.isNotNull(id)) {
                    Map<String, Object> map = new HashMap<>(1);
                    map.put("id", id);
                    this.deleteCourseById(map);
                }
                throw new VdyooException("500", "威渡课程关联失败，请联系管理员或稍后再试");
            }
        }else{
            throw new VdyooException("500", vdyooEntity.getMessage());
        }
    }

    /**
     * 根据id删除课程
     */
    public boolean deleteCourseById(Map<String, Object> params) {
        return vdyooFactory.post(params, WeiduConfig.deleteCourseById).getSuccess();
    }

    /**
     * 编辑课程 根据课程Id
     */
    public boolean editCourseById(Map<String, Object> params) {
        //处理业务逻辑
        VdyooEntity vdyooEntity = vdyooFactory.post(params, WeiduConfig.editCourseById);

        if (vdyooEntity.getSuccess()) {
            return vdyooEntity.getSuccess();
        }else {
            throw new VdyooException("500", vdyooEntity.getMessage());
        }
    }

    /**
     * 通过威渡课程Id 来查询课程信息
     */

    public void findCourseById(Map<String, Object> params) {
        vdyooFactory.post(params, WeiduConfig.findCourseById);
    }

    /**
     * 查询全部的课程
     */
    public void findCourseClassByTenant() {
        VdyooEntity vdyooEntity = vdyooFactory.post(WeiduConfig.findCourseClassByTenant);

        if (vdyooEntity.getSuccess()) {
            System.out.println(vdyooEntity.getPayload());
        }else {
            throw new VdyooException("500", vdyooEntity.getMessage());
        }
    }
}
