package com.ruida.cloud.dao;

import com.ruida.cloud.model.Tschool;
import com.ruida.cloud.model.TschoolExample;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface TschoolMapper {
    int countByExample(TschoolExample example);

    int deleteByExample(TschoolExample example);

    int deleteByPrimaryKey(Integer schoolId);

    int insert(Tschool record);

    int insertSelective(Tschool record);

    List<Tschool> selectByExample(TschoolExample example);

    Tschool selectByPrimaryKey(Integer schoolId);

    int updateByExampleSelective(@Param("record") Tschool record, @Param("example") TschoolExample example);

    int updateByExample(@Param("record") Tschool record, @Param("example") TschoolExample example);

    int updateByPrimaryKeySelective(Tschool record);

    int updateByPrimaryKey(Tschool record);


    @Select("select school_id AS schoolId from t_school where isdelete = 0 and school_name = #{schoolName} ")
    List<Integer> getSchoolIdBySchoolName(@Param("schoolName") String schoolName);
}