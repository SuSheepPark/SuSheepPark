package com.ruida.cloud.weidu.service.impl;

import com.ruida.cloud.weidu.config.WeiduConfig;
import com.ruida.cloud.weidu.service.BaseVdyooService;
import com.ruida.cloud.weidu.utils.PropertyUtil;
import com.ruida.cloud.weidu.utils.VdyooUtil;
import com.ruida.cloud.weidu.vo.VdyooEntity;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * @author taosh
 * @create 2019-04-24 9:33
 */
@Service
public class VdyooStartExamService extends BaseVdyooService {
    private String vdyooPath = PropertyUtil.getProperty("vdyooTestApi");

    /**
     * 互动发起
     */
    public VdyooEntity startExam(Map<String, Object> param) {
        //    String path = vdyooPath+"/api/answer/event/startExam";

//        //主讲老师ID
//        param.put("teacherId", "");
//        //计划ID
//        param.put("scheduleId", "");
//        //题型 枚举类型： choice(“选择题”),choosewrong(“选错题”)
//        param.put("examType", "123");
//        //答案 选择题： A,B,C,D  ------      选错题 0,1
//        param.put("answer", "");

//        String response = HttpClientUtil.postMap(path, param);
//        System.out.println(response);
        return this.vdyooFactory.post(param, WeiduConfig.startExam);
    }

    /**
     * 结束互动
     */
    public final static String endExam = "/api/answer/event/endExam";

    public VdyooEntity endExam(Map<String, Object> param) {

//        //主讲老师ID
//        param.put("teacherId", "");
//        //计划ID
//        param.put("scheduleId", "");

//        String response = HttpClientUtil.postMap(path, param);
//        System.out.println(response);
        return this.vdyooFactory.post(param, WeiduConfig.endExam);
    }

    /**
     * 红包操作
     */
    public final static String operateReadGift = "/api/answer/event/operateReadGift";

    public VdyooEntity operateReadGift(Map<String, Object> param) {
//        String path = vdyooPath+"/api/answer/event/operateReadGift";
//
//        Map<String, String> param = VdyooUtil.getSignMap();

        //操作类型 枚举类型： ready(“准备” ,”1”),start(“开始”,”2”),over(“结束”,”3”),close(“关闭”,”4”);
//        param.put("operateType", "");
//        //红包token: 第一次调用准备动作时不是必填项，之后的开始，结束，关闭时必填选项，调用时准备动作会返回一个红包token,用于后续动作使用
//        param.put("redGiftToken", "");
//        //主讲老师ID
//        param.put("teacherId", "");
//        //红包数量
//        param.put("giftNum", "");
//        //分数
//        param.put("scoreNum", "");
//        //计划ID
//        param.put("scheduleId", "");

//        String response = HttpClientUtil.postMap(path, param);
//        System.out.println(response);
        return this.vdyooFactory.post(param, WeiduConfig.operateReadGift);
    }

    /**
     * 获取学生列表（包含学生状态是否绑定）
     */
    public final static String findRoomScheduleStudents = "/api/answer/event/findRoomScheduleStudents";

    public VdyooEntity findRoomScheduleStudents(Map<String, Object> param) {
        //   String path = vdyooPath+"/api/answer/event/findRoomScheduleStudents";

//        //教室（直播间）ID
//        param.put("roomId", "");
//        //计划ID
//        param.put("scheduleId", "");

//        String response = HttpClientUtil.postMap(path, param);
//        System.out.println(response);

        return this.vdyooFactory.post(param, WeiduConfig.findRoomScheduleStudents);
    }

    /**
     * 选择学生退出（解除绑定）
     */
    public final static String logoutStudents = "/api/answer/event/logoutStudents";

    public VdyooEntity logoutStudents(Map<String, Object> param) {
        //   String path = vdyooPath + "/api/answer/event/logoutStudents";

        // Map<String, String> param = VdyooUtil.getSignMap();

        //学生ID数组
//        param.put("studentIds", "");
//        //教室（直播间）ID
//        param.put("roomId", "");
//        //计划ID
//        param.put("scheduleId", "");

//        String response = HttpClientUtil.postMap(path, param);
//        System.out.println(response);
        return this.vdyooFactory.post(param, WeiduConfig.logoutStudents);
    }

    /**
     * 学生签到
     */
    public final static String signInByMarker = "/api/answer/event/signInByMarker";

    public VdyooEntity signInByMarker(Map<String, Object> param) {
     //   String path = vdyooPath + "/api/answer/event/signInByMarker";

//        Map<String, String> param = VdyooUtil.getSignMap();
//
//        //学生ID数组
//        param.put("studentIds", "");
//        //教室（直播间）ID
//        param.put("roomId", "");
//        //计划ID
//        param.put("scheduleId", "");

//        String response = HttpClientUtil.postMap(path, param);
//        System.out.println(response);
        return this.vdyooFactory.post(param, WeiduConfig.signInByMarker);
    }

    /**
     * 学生的缺勤
     */
    public final static String signOutByMarker = "/api/answer/event/signOutByMarker";
    public VdyooEntity signOutByMarker(Map<String, Object> param) {
//        String path = vdyooPath + "/api/answer/event/signOutByMarker";
//
//        Map<String, String> param = VdyooUtil.getSignMap();
//
//        //学生ID数组
//        param.put("studentIds", "");
//        //教室（直播间）ID
//        param.put("roomId", "");
//        //计划ID
//        param.put("scheduleId", "");

//        String response = HttpClientUtil.postMap(path, param);
//        System.out.println(response);
        return this.vdyooFactory.post(param,WeiduConfig.signOutByMarker);
    }

    /**
     * 助教激活课表,学生自动签到
     */
    public final static String selectRoomScheduleAutoSingIn = "/api/answer/event/selectRoomScheduleAutoSingIn";

    public VdyooEntity selectRoomScheduleAutoSingIn(Map<String, Object> param) {
//        String path = vdyooPath + "/api/answer/event/selectRoomScheduleAutoSingIn";
//
//        Map<String, String> param = VdyooUtil.getSignMap();
//
//        //助教老师的ID
//        param.put("teacherId", "");
//        //教室（直播间）ID
//        param.put("roomId", "");
//        //计划ID
//        param.put("scheduleId", "");

//        String response = HttpClientUtil.postMap(path, param);
//        System.out.println(response);
        return this.vdyooFactory.post(param,WeiduConfig.selectRoomScheduleAutoSingIn);
    }

}
