package com.ruida.mockservice.service.impl;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.ruida.mockcommon.auth.context.BaseContextHandle;
import com.ruida.mockcommon.enums.SubjectEnum;
import com.ruida.mockdao.dao.ExamRecordMapper;
import com.ruida.mockdao.dao.InputScoreMapper;
import com.ruida.mockdao.dao.SysUserMapper;
import com.ruida.mockdao.dto.ExamRecordDTO;
import com.ruida.mockdao.model.InputScore;
import com.ruida.mockdao.vo.report.InputScoreVO;
import com.ruida.mockservice.service.InputScoreService;
import com.ruida.mockservice.service.ReportService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

/**
 * <p>
 * 科目选考-手动输入成绩表 服务实现类
 * </p>
 *
 * @author chenjy
 * @since 2021-01-18
 */
@Service
public class InputScoreServiceImpl extends ServiceImpl<InputScoreMapper, InputScore> implements InputScoreService {

    @Resource
    SysUserMapper sysUserMapper;
    @Resource
    private ExamRecordMapper examRecordMapper;
    @Resource
    private ReportService reportService;

    @Override
    public List<InputScoreVO> getPastScore(Integer userId) {
        List<InputScoreVO> result = new ArrayList<>();

        List<ExamRecordDTO> examRecordDTOList = examRecordMapper.queryNineOneExam(userId);

        //手动输入的成绩
        List<InputScore> inputScoreList = this.selectList(new EntityWrapper<InputScore>().eq("user_id", userId).eq("is_delete", 0));

        if(!CollectionUtils.isEmpty(inputScoreList)){
            inputScoreList.forEach(e->{
                ExamRecordDTO dto = new ExamRecordDTO();
                dto.setSubjectId(e.getSubjectId());
                dto.setScore(e.getScore().doubleValue());
                dto.setCreateTime(e.getCreateTime());
                dto.setSource(0);
                examRecordDTOList.add(dto);
            });
        }

        // 按照科目分组
        Map<Integer, List<ExamRecordDTO>> groupMap = examRecordDTOList.stream().collect(Collectors.groupingBy(ExamRecordDTO::getSubjectId));

        Arrays.stream(SubjectEnum.values()).forEach(e->{
            InputScoreVO vo = new InputScoreVO();
            vo.setSubjectId(e.getCode());
            for(Map.Entry<Integer,List<ExamRecordDTO>> entry:groupMap.entrySet()){
                if(entry.getKey() == e.getCode()){
                    // 对原始成绩进行赋分处理
                    List<ExamRecordDTO> subjectExamRecords = entry.getValue();

                    //如果既有考试成绩又有输入成绩，则不使用输入成绩
                    if(subjectExamRecords.size() > 1 && subjectExamRecords.stream().anyMatch(y->y.getSource() == 0)){
                        subjectExamRecords = subjectExamRecords.stream().filter(x -> x.getSource() == 1).collect(Collectors.toList());
                    }

                    //TODO 插叙速度较慢，待优化
//                    reportService.assignPoint(subjectExamRecords);

                    Double avg = subjectExamRecords.stream().collect(Collectors.averagingDouble(ExamRecordDTO::getScore));
                    vo.setScore(new BigDecimal(String.valueOf(avg)).setScale(1,4));
                }
            }
            result.add(vo);
        });
        return result;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean saveInputScore(List<InputScore> list) {
        int userId = Integer.parseInt(BaseContextHandle.getUserID());

        list = list.stream().map(e -> {
            InputScore old = this.selectOne(new EntityWrapper<InputScore>().eq("user_id", userId).eq("subject_id", e.getSubjectId()).eq("is_delete", 0));
            if(old != null){
                e.setIsDelete(1);
                this.deleteById(old.getId());
            }
            e.setIsDelete(0);
            e.setUserId(userId);
            e.setCreateTime(new Date());
            return e;
        }).collect(Collectors.toList());

        return this.insertBatch(list);
    }
}
