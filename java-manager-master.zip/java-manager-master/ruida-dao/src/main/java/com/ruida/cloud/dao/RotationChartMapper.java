package com.ruida.cloud.dao;

import com.ruida.cloud.model.RotationChart;
import com.ruida.cloud.model.RotationChartExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface RotationChartMapper {
    int countByExample(RotationChartExample example);

    int deleteByExample(RotationChartExample example);

    int deleteByPrimaryKey(Integer rotationChartId);

    int insert(RotationChart record);

    int insertSelective(RotationChart record);

    List<RotationChart> selectByExample(RotationChartExample example);

    RotationChart selectByPrimaryKey(Integer rotationChartId);

    int updateByExampleSelective(@Param("record") RotationChart record, @Param("example") RotationChartExample example);

    int updateByExample(@Param("record") RotationChart record, @Param("example") RotationChartExample example);

    int updateByPrimaryKeySelective(RotationChart record);

    int updateByPrimaryKey(RotationChart record);
}