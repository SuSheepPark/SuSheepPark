package com.ruida.mockservice.service;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * <p>
 * 阿里支付 服务类
 * </p>
 *
 * @author Bhj
 * @since 2020-07-17
 */
public interface AlipayService {
    void doPost(HttpServletRequest payForm, HttpServletResponse response) throws IOException, ServletException;

    String orderAlipay(HttpServletRequest payForm, HttpServletResponse response);
}
