package com.ruida.assessment.assessmentquestionbank.model;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;

/**
 * @description: 保密等级数据库实体
 * @author: kgz
 * @date: 2020/6/10
 */
@TableName("t_security_level")
public class TSecurityLevel extends BaseColumn implements Serializable {

    private static final long serialVersionUID = 71530498869219814L;

    /**
     * 保密等级id
     */
    @TableId
    private Integer id;

    /**
     * 保密等级名称
     */
    private String securityLevelName;

    /**
     * 状态（0—禁用；1—启用）
     */
    private String status;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getSecurityLevelName() {
        return securityLevelName;
    }

    public void setSecurityLevelName(String securityLevelName) {
        this.securityLevelName = securityLevelName;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "SecurityLevel{" +
                "id=" + id +
                ", securityLevelName='" + securityLevelName + '\'' +
                ", status='" + status + '\'' +
                super.toString() +
                '}';
    }
}
