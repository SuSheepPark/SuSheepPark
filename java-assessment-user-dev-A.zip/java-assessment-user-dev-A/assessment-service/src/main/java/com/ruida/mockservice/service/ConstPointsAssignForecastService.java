package com.ruida.mockservice.service;

import com.baomidou.mybatisplus.service.IService;
import com.ruida.mockdao.model.ConstPointsAssignForecast;

import java.util.List;

/**
 * <p>
 * 赋分预估常模表 服务类
 * </p>
 *
 * @author chenjy
 * @since 2021-03-11
 */
public interface ConstPointsAssignForecastService extends IService<ConstPointsAssignForecast> {

	/**
	 * 将原始分数转换为赋分
	 * 
	 * @param standard    参考标准
	 * @param originScore 原始成绩
	 * @param subjectId   科目
	 * @return
	 */
	Double convertScore(List<Double> standard, Double originScore, Integer subjectId, Integer constRangeId);

}
