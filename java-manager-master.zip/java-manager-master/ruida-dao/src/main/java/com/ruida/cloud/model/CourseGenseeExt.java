package com.ruida.cloud.model;

import lombok.Data;

/**
 * @author admin
 * @description: ${TODO}
 * @Date 2019/5/28
 * @verion 1.0
 */
@Data
public class CourseGenseeExt extends CourseGensee{
    /**
     * 课次名字
     */
    private String courseLessonName;
    /**
     * 课次id
     */
    private Integer courseLessonId;
    /**
     * 课程名字
     */
    private String courseName;
    /**
     * 课程id
     */
    private Integer courseId;
    /**
     * 推流地址
     */
    private String address;
    /**
     * 开始时间
     */
    private String startTime;
    /**
     * 结束时间
     */
    private  String endTime;

}
