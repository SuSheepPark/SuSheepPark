package com.ruida.common.vo;

import java.io.Serializable;

/**
 * @description:
 * @author szl
 * @Date 2018年12月10日
 * @verion 1.0
 */
public class ExtBaseResult implements Serializable {

	private static final long serialVersionUID = 7220877209535559537L;

	private static final String SUCCESS_CODE = "0";

	private Boolean success;

	/** 错误码 */
	private String statusCode;

	/** 错误信息 */
	private String errorMsg;
	/** 附加信息 */
	private String msg;

	public ExtBaseResult() {
		setStatusCode(SUCCESS_CODE);
		this.success = true;
	}

	@SuppressWarnings("unchecked")
	public <R extends ExtBaseResult> R setErrorMessage(String code, String message) {
		setStatusCode(code);
		setErrorMsg(message);
		this.success = false;
		return (R) this;
	}

	public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}



	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}



}
