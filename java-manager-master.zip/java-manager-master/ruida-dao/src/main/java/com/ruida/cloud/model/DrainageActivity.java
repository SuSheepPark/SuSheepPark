package com.ruida.cloud.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ruida.common.SystemConstant;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;

public class DrainageActivity implements Serializable {
    private Integer drainageActivityId;

    private String drainageActivityName;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone= SystemConstant.TIME_ZONE)
    private Date startTime;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone= SystemConstant.TIME_ZONE)
    private Date endTime;

    private Byte status;

    private Integer courseId;

    private Byte relateAllCourse;

    private Byte relateAllDistributor;

    private Integer createBy;

    private Date createTime;

    private Integer updateBy;

    private Date updateTime;

    private Byte isdelete;

    private static final long serialVersionUID = 1L;

    public Integer getDrainageActivityId() {
        return drainageActivityId;
    }

    public void setDrainageActivityId(Integer drainageActivityId) {
        this.drainageActivityId = drainageActivityId;
    }

    public String getDrainageActivityName() {
        return drainageActivityName;
    }

    public void setDrainageActivityName(String drainageActivityName) {
        this.drainageActivityName = drainageActivityName == null ? null : drainageActivityName.trim();
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public Byte getStatus() {
        return status;
    }

    public void setStatus(Byte status) {
        this.status = status;
    }

    public Integer getCourseId() {
        return courseId;
    }

    public void setCourseId(Integer courseId) {
        this.courseId = courseId;
    }

    public Byte getRelateAllCourse() {
        return relateAllCourse;
    }

    public void setRelateAllCourse(Byte relateAllCourse) {
        this.relateAllCourse = relateAllCourse;
    }

    public Byte getRelateAllDistributor() {
        return relateAllDistributor;
    }

    public void setRelateAllDistributor(Byte relateAllDistributor) {
        this.relateAllDistributor = relateAllDistributor;
    }

    public Integer getCreateBy() {
        return createBy;
    }

    public void setCreateBy(Integer createBy) {
        this.createBy = createBy;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(Integer updateBy) {
        this.updateBy = updateBy;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Byte getIsdelete() {
        return isdelete;
    }

    public void setIsdelete(Byte isdelete) {
        this.isdelete = isdelete;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", drainageActivityId=").append(drainageActivityId);
        sb.append(", drainageActivityName=").append(drainageActivityName);
        sb.append(", startTime=").append(startTime);
        sb.append(", endTime=").append(endTime);
        sb.append(", status=").append(status);
        sb.append(", courseId=").append(courseId);
        sb.append(", relateAllCourse=").append(relateAllCourse);
        sb.append(", relateAllDistributor=").append(relateAllDistributor);
        sb.append(", createBy=").append(createBy);
        sb.append(", createTime=").append(createTime);
        sb.append(", updateBy=").append(updateBy);
        sb.append(", updateTime=").append(updateTime);
        sb.append(", isdelete=").append(isdelete);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}