package com.ruida.cloud.dao;

import com.ruida.cloud.model.OrderStudyCoinRel;
import com.ruida.cloud.model.OrderStudyCoinRelExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface OrderStudyCoinRelMapper {
    int countByExample(OrderStudyCoinRelExample example);

    int deleteByExample(OrderStudyCoinRelExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(OrderStudyCoinRel record);

    int insertSelective(OrderStudyCoinRel record);

    List<OrderStudyCoinRel> selectByExample(OrderStudyCoinRelExample example);

    OrderStudyCoinRel selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") OrderStudyCoinRel record, @Param("example") OrderStudyCoinRelExample example);

    int updateByExample(@Param("record") OrderStudyCoinRel record, @Param("example") OrderStudyCoinRelExample example);

    int updateByPrimaryKeySelective(OrderStudyCoinRel record);

    int updateByPrimaryKey(OrderStudyCoinRel record);
}