package com.ruida.cloud.dao;

import com.ruida.cloud.model.DiscountActivity;
import com.ruida.cloud.model.DiscountActivityExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface DiscountActivityMapper {
    long countByExample(DiscountActivityExample example);

    int deleteByExample(DiscountActivityExample example);

    int deleteByPrimaryKey(Integer discountActivityId);

    int insert(DiscountActivity record);

    int insertSelective(DiscountActivity record);

    List<DiscountActivity> selectByExample(DiscountActivityExample example);

    DiscountActivity selectByPrimaryKey(Integer discountActivityId);

    int updateByExampleSelective(@Param("record") DiscountActivity record, @Param("example") DiscountActivityExample example);

    int updateByExample(@Param("record") DiscountActivity record, @Param("example") DiscountActivityExample example);

    int updateByPrimaryKeySelective(DiscountActivity record);

    int updateByPrimaryKey(DiscountActivity record);
}