package com.zhaowei.cms.dao;

import java.util.List;

import com.zhaowei.cms.domain.Category;
/**
 * 
 * @ClassName: CategoryMapper 
 * @Description: 分类
 * @author: zw
 * @date: 2019年9月17日 下午8:30:00
 */
public interface CategoryMapper {
	/**
	 * 
	 * @Title: selectsByChannel 
	 * @Description:根据栏目查询旗下所有分类
	 * @param cid
	 * @return
	 * @return: List<Category>
	 */
	List<Category> selectsByChannelId(Integer cid);
	
    int deleteByPrimaryKey(Integer id);

    int insert(Category record);

    int insertSelective(Category record);

    Category selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(Category record);

    int updateByPrimaryKey(Category record);
}