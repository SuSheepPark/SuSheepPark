package com.ruida.mockdao.vo;

import lombok.Data;

/**
 * 高考成绩一分一段每年的最高最低分
 */
@Data
public class MaxAndMinScoreVO {
    private Double minScore;
    private Double maxScore;
    private Integer year;

}
