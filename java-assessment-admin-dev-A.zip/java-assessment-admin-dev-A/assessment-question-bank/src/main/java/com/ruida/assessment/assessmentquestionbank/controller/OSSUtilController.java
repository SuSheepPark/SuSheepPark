package com.ruida.assessment.assessmentquestionbank.controller;

import com.ruida.assessment.assessmentcommon.result.PojoResult;
import com.ruida.assessment.assessmentcommon.util.AliYunOSSUtil;
import com.ruida.assessment.assessmentquestionbank.service.AliyunOSSService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @author xumingqi
 * @date 2021/2/7 9:22
 */
@RestController
@RequestMapping("/ossUtil")
@Api(tags = "上传图片到阿里云oss")
public class OSSUtilController {
    @Resource
    AliyunOSSService aliyunOSSService;
    @GetMapping("/uploadFile")
    @ApiOperation(value = "上传文件并获取url")
    public PojoResult<String> uploadFile(@RequestParam MultipartFile file) throws IOException {
        PojoResult<String> result = new PojoResult<>();
        String fileName = file.getOriginalFilename();
        SimpleDateFormat df = new SimpleDateFormat("yyyyMMddHHmmss");
        fileName = "ruidaceping/" + df.format(new Date()) + fileName;
        InputStream inputStream = file.getInputStream();
        String url = aliyunOSSService.uploadFile(inputStream, fileName);
        result.setContent(url);
        return result;
    }

    @GetMapping("/uploadPic")
    @ApiOperation(value = "上传图片")
    public PojoResult<String> uploadPic(@RequestParam MultipartFile file) throws IOException {
        PojoResult<String> result = new PojoResult<>();
        String fileName = file.getOriginalFilename();
        SimpleDateFormat df = new SimpleDateFormat("yyyyMMddHHmmss");
        fileName = "ruidaceping/" + df.format(new Date()) + fileName;
        InputStream inputStream = file.getInputStream();
        String url = aliyunOSSService.uploadPic(inputStream, fileName);
        result.setContent(url);
        return result;
    }
}
