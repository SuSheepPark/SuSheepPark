package com.ruida.mockdao.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.model.ProductUserRel;

/**
 * <p>
 * 用户商品关联表 Mapper 接口
 * </p>
 *
 * @author jinhu
 * @since 2020-07-14
 */
public interface ProductUserRelMapper extends BaseMapper<ProductUserRel> {

}
