package com.ruida.mockdao.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.model.Stage;
import com.ruida.mockdao.vo.StageVO;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 年级信息表 Mapper 接口
 * </p>
 *
 * @author chenjy
 * @since 2020-08-03
 */
public interface StageMapper extends BaseMapper<Stage> {

    List<StageVO> getStageList();

}
