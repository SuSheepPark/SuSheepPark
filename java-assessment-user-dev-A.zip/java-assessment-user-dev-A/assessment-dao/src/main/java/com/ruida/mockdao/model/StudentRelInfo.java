package com.ruida.mockdao.model;

import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;
import lombok.Data;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 学生关联信息表（学校、学段、年级、班级）
 * </p>
 *
 * @author Bhj
 * @since 2020-07-10
 */
@Data
@Accessors(chain = true)
@TableName("t_student_rel_info")
public class StudentRelInfo extends Model<StudentRelInfo> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键ID
     */
    @TableId(value = "rid", type = IdType.AUTO)
    private Integer rid;
    /**
     * 学生ID
     */
    @TableField("student_id")
    private Integer studentId;
    /**
     * 学校ID
     */
    @TableField("school_id")
    private Integer schoolId;
    /**
     * 学段ID
     */
    @TableField("period_id")
    private Integer periodId;
    /**
     * 年级ID
     */
    @TableField("grade_id")
    private Integer gradeId;
    /**
     * 班级ID
     */
    @TableField("class_id")
    private Integer classId;
    /**
     * 创建者ID
     */
    @TableField("create_by")
    private Integer createBy;
    /**
     * 创建日期
     */
    @TableField("create_time")
    private Date createTime;
    /**
     * 更新者ID
     */
    @TableField("update_by")
    private Integer updateBy;
    /**
     * 更新日期
     */
    @TableField("update_time")
    private Date updateTime;

    private Integer status;
    @Override
    protected Serializable pkVal() {
        return this.rid;
    }

}
