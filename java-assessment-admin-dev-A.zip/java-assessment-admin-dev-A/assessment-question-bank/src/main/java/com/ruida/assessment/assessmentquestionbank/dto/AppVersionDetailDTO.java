package com.ruida.assessment.assessmentquestionbank.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * @description: APP版本详情信息DTO
 * @author: kgz
 * @date: 2020/8/17
 */
@ApiModel(description = "APP版本详情信息")
public class AppVersionDetailDTO {

    @ApiModelProperty(value = "主键ID", name = "appVersionId")
    private Integer appVersionId;

    @ApiModelProperty(value = "类型（1—安卓；2—IOS）", name = "type")
    private Integer type;

    @ApiModelProperty(value = "大版本号", name = "versionCode")
    private String versionCode;

    @ApiModelProperty(value = "详细版本号", name = "version")
    private String version;

    @ApiModelProperty(value = "下载路径", name = "url")
    private String url;

    @ApiModelProperty(value = "下载路径配置方式(0-本地上传地址;1-第三方商店地址)", name = "pathConfigMethod")
    private Integer pathConfigMethod;

    @ApiModelProperty(value = "文件名称", name = "fileName")
    private String fileName;

    @ApiModelProperty(value = "是否强制更新（0：不强制；1：强制）", name = "isupdate")
    private Integer isupdate;

    @ApiModelProperty(value = "更新描述", name = "remark")
    private String remark;

    public Integer getAppVersionId() {
        return appVersionId;
    }

    public void setAppVersionId(Integer appVersionId) {
        this.appVersionId = appVersionId;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public String getVersionCode() {
        return versionCode;
    }

    public void setVersionCode(String versionCode) {
        this.versionCode = versionCode;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Integer getPathConfigMethod() {
        return pathConfigMethod;
    }

    public void setPathConfigMethod(Integer pathConfigMethod) {
        this.pathConfigMethod = pathConfigMethod;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public Integer getIsupdate() {
        return isupdate;
    }

    public void setIsupdate(Integer isupdate) {
        this.isupdate = isupdate;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }
}
