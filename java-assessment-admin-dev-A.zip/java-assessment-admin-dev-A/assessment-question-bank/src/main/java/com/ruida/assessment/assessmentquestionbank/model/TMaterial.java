package com.ruida.assessment.assessmentquestionbank.model;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @author wy
 * @description 教材数据库实体类
 * @date 2020/6/12
 */
@Data
@ApiModel(description = "教材数据库实体")
@TableName("t_material")
public class TMaterial extends BaseColumn implements Serializable {
    private static final long serialVersionUID = -3668784540077702517L;


    @TableId
    @ApiModelProperty(value = "教材id", name = "versionId", required = false)
    private Integer materialId;

    @ApiModelProperty(value = "教材版本id", name = "versionId", required = false)
    private Integer versionId;
/*
    @ApiModelProperty(value = "教材版本名", name = "versionName", required = true)
    private String versionName;*/


    @ApiModelProperty(value = "学段id", name = "period_id", required = true)
    private Integer periodId;

/*    @ApiModelProperty(value = "学段名称", name = "periodName", required = true)
    private String periodName;*/

    @ApiModelProperty(value = "科目id", name = "subjectId", required = true)
    private Integer subjectId;

/*    @ApiModelProperty(value = "科目名称", name = "subjectName", required = true)
    private String subjectName;*/

    @ApiModelProperty(value = "年级id", name = "gradeId", required = true)
    private Integer gradeId;

/*    @ApiModelProperty(value = "年级名称", name = "gradeName", required = true)
    private String gradeName;*/

    @ApiModelProperty(value = "状态 0—禁用；1—启用", name = "status", required = true)
    private Integer status;
}
