package com.ruida.mockdao.model;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 试卷的导入成绩、计算报告等任务的执行状态
 * </p>
 *
 * @author 
 * @since 2021-05-12
 */
@TableName("t_test_paper_product_task")
public class TTestPaperProductTask implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId
    private Integer taskId;
    private Integer testPaperId;
    private Integer productId;
    /**
     * 成绩导入的执行状态。0-未开始；1-任务下发中；2-执行中；3-执行完成
     */
    private Integer importStatus;
    /**
     * 成绩导入的最近一次执行完成时间
     */
    private Date importTime;
    /**
     * 个人报告的计算状态。0-未开始；1-任务下发中；2-执行中；3-执行完成
     */
    private Integer reportStatus;
    /**
     * 个人报告的计算完成时间
     */
    private Date reportTime;
    /**
     * 班级学校报告的计算状态
     */
    private Integer scReportStatus;
    /**
     * 班级学校报告的计算完成时间
     */
    private Date scReportTime;


    public Integer getTaskId() {
        return taskId;
    }

    public void setTaskId(Integer taskId) {
        this.taskId = taskId;
    }

    public Integer getTestPaperId() {
        return testPaperId;
    }

    public void setTestPaperId(Integer testPaperId) {
        this.testPaperId = testPaperId;
    }

    public Integer getProductId() {
        return productId;
    }

    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    public Integer getImportStatus() {
        return importStatus;
    }

    public void setImportStatus(Integer importStatus) {
        this.importStatus = importStatus;
    }

    public Date getImportTime() {
        return importTime;
    }

    public void setImportTime(Date importTime) {
        this.importTime = importTime;
    }

    public Integer getReportStatus() {
        return reportStatus;
    }

    public void setReportStatus(Integer reportStatus) {
        this.reportStatus = reportStatus;
    }

    public Date getReportTime() {
        return reportTime;
    }

    public void setReportTime(Date reportTime) {
        this.reportTime = reportTime;
    }

    public Integer getScReportStatus() {
        return scReportStatus;
    }

    public void setScReportStatus(Integer scReportStatus) {
        this.scReportStatus = scReportStatus;
    }

    public Date getScReportTime() {
        return scReportTime;
    }

    public void setScReportTime(Date scReportTime) {
        this.scReportTime = scReportTime;
    }

    @Override
    public String toString() {
        return "TTestPaperProductTask{" +
        ", taskId=" + taskId +
        ", testPaperId=" + testPaperId +
        ", productId=" + productId +
        ", importStatus=" + importStatus +
        ", importTime=" + importTime +
        ", reportStatus=" + reportStatus +
        ", reportTime=" + reportTime +
        ", scReportStatus=" + scReportStatus +
        ", scReportTime=" + scReportTime +
        "}";
    }
}
