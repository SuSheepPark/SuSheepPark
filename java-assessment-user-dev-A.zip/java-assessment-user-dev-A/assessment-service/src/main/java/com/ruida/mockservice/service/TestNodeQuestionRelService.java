package com.ruida.mockservice.service;

import com.baomidou.mybatisplus.service.IService;
import com.ruida.mockdao.model.TestNodeQuestionRel;

/**
 * <p>
 * 小节试题关联表 服务类
 * </p>
 *
 * @author chenjy
 * @since 2020-07-15
 */
public interface TestNodeQuestionRelService extends IService<TestNodeQuestionRel> {

}
