package com.ruida.cloud.weidu.service.impl.data;

import com.ruida.cloud.weidu.utils.PropertyUtil;
import com.ruida.cloud.weidu.utils.VdyooUtil;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * @author taosh
 * @create 2019-04-24 11:44
 */
@Service
public class VdyooCourseClassCountService {
    private String vdyooPath = PropertyUtil.getProperty("vdyooTestApi");

    /**
     * 获取学生全部答题数据通过学生的ID来查询学生的答题情况
     */
    public void findCourseClassCountByCourseClassId(String courseClassId){
        String path = vdyooPath+"/api/business/courseclasscount/findCourseClassCountByCourseClassId";

        Map<String, String> param = VdyooUtil.getSignMap();

        //威渡课程班ID
        param.put("courseClassId", courseClassId);

//        String response = HttpClientUtil.postMap(path, param);
//        System.out.println(response);
    }

    /**
     * 获取学生全部答题数据通过学生的ID来查询学生的答题情况
     */
    public void findCourseClassCountByCourseClassIdByExamType(String courseClassId, String examType){
        String path = vdyooPath+"/api/business/courseclasscount/findCourseClassCountByCourseClassIdByExamType";

        Map<String, String> param = VdyooUtil.getSignMap();

        //威渡课程班ID
        param.put("courseClassId", courseClassId);
        //题型, 选择题：”choice”,多选题:”mutichoice”,填空题:”completion”,选错题:”choosewrong”,带分数填空题:”fraction”
        param.put("examType", examType);

//        String response = HttpClientUtil.postMap(path, param);
//        System.out.println(response);
    }

    /**
     * 通过课程班，试题类型 ,课表，查出该课程的试题类型答题情况
     */
    public void findCourseClassCountByCourseClassIdAndExamTypeAndSchedule(String courseClassId, String examType, String scheduleId){
        String path = vdyooPath+"/api/business/courseclasscount/findCourseClassCountByCourseClassIdAndExamTypeAndSchedule";

        Map<String, String> param = VdyooUtil.getSignMap();

        //威渡课程班ID
        param.put("courseClassId", courseClassId);
        //题型, 选择题：”choice”,多选题:”mutichoice”,填空题:”completion”,选错题:”choosewrong”,带分数填空题:”fraction”
        param.put("examType", examType);
        //课表Id
        param.put("scheduleId", scheduleId);

//        String response = HttpClientUtil.postMap(path, param);
//        System.out.println(response);
    }

    /**
     * 通过课程班，试题类型 ,课表，查出该课程的试题类型答题情况
     */
    public void findCourseClassCountBySchedule(String courseClassId, String scheduleId){
        String path = vdyooPath+"/api/business/courseclasscount/findCourseClassCountBySchedule";

        Map<String, String> param = VdyooUtil.getSignMap();

        //威渡课程班ID
        param.put("courseClassId", courseClassId);
        //课表Id
        param.put("scheduleId", scheduleId);

//        String response = HttpClientUtil.postMap(path, param);
//        System.out.println(response);
    }
}
