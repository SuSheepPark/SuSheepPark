package com.ruida.mockservice.service;

import com.ruida.mockdao.model.ExamRecord;

import java.math.BigDecimal;

/**
 * Created by xumingqi on 2021/8/2 11:09
 */
public interface ProductAsyncService {

    /**
     * 保存答题进度
     */
    void saveAnswerRate(ExamRecord examRecord);

    /**
     * 提交试卷时调用，记录做题进度
     *
     * @param userId         必填
     * @param productId      必填
     * @param testPaperId    必填
     * @param rate           必填  本次练习进度
     * @param completeStatus 必填 本次练习交卷状态 0 交卷/ 1 未交卷
     */
    void handlePaperRelAfterExam(int userId, int productId, int testPaperId, BigDecimal rate, int completeStatus);
}
