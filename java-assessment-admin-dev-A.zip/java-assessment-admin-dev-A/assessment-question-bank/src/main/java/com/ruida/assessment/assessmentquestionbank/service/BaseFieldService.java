package com.ruida.assessment.assessmentquestionbank.service;

import com.ruida.assessment.assessmentcommon.result.PageData;
import com.ruida.assessment.assessmentquestionbank.dto.BaseFieldDTO;
import com.ruida.assessment.assessmentquestionbank.vo.BaseFieldVO;

import java.util.List;

public interface BaseFieldService {

    /**
     * 基础字段维护 查询
     * @param baseFieldDTO
     * @throws Exception
     */
    PageData queryBaseField(BaseFieldDTO baseFieldDTO) throws Exception;

    /**
     * 基础字段维护 增加
     * @param baseFieldDTO
     * @return
     * @throws Exception
     */
    boolean insertBaseField(BaseFieldDTO baseFieldDTO) throws Exception;

    /**
     * 基础字段维护 修改
     * @param baseFieldDTO
     * @return
     * @throws Exception
     */
    boolean updateBaseField(BaseFieldDTO baseFieldDTO) throws Exception;

    /*
     *功能描述 编辑时查询基础字段信息
     * @param
     * @return
     */
    BaseFieldVO queryBaseFieldInfo(BaseFieldDTO baseFieldDTO)throws Exception;

    /**
     * 基础字段维护 删除
     * @param baseFieldDTO
     * @return
     */
//    boolean deleteBaseField(BaseFieldDTO baseFieldDTO) throws Exception;
}
