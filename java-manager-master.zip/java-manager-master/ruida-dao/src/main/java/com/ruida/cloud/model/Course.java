package com.ruida.cloud.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ruida.common.SystemConstant;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

public class Course implements Serializable {
    private Integer courseId;

    private String courseName;

    private Byte teachingMethod;

    private String coverPath;

    private String semesterId;

    private Integer periodId;

    private Integer stageId;

    private Integer courseTypeId;

    private Integer classTypeId;

    private Integer courseVideoId;

    private Byte ispublic;

    private Byte ischarge;

    private Byte sale;

    private Byte istryvideo;

    @JsonFormat(pattern = "yyyy-MM-dd",timezone= SystemConstant.TIME_ZONE)
    private Date startDate;

    @JsonFormat(pattern = "yyyy-MM-dd",timezone= SystemConstant.TIME_ZONE)
    private Date endDate;

    private String startTime;

    private String endTime;

    private Integer intervalDays;

    private Byte validTime;

    private Integer teacherId;

    private Integer broadcastRoomId;

    private Byte iscompose;

    private Byte isprepublish;

    private Byte ispublish;

    private Byte ishot;

    private Integer courseMaximum;

    private Integer createBy;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm",timezone= SystemConstant.TIME_ZONE)
    private Date createTime;

    private Integer updateBy;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm",timezone= SystemConstant.TIME_ZONE)
    private Date updateTime;

    private Integer publishBy;

    private Date publishTime;

    private Byte isdelete;

    private String summary;

    private String summaryHtml;

    private Byte istest;

    private Byte isshow;

    private static final long serialVersionUID = 1L;

    //临时字段
    private String periodName;
    private String stageName;
    private String subjectName;
    private Integer[] subjectIds;
    private BigDecimal coursePrice;
    private String courseTypeName;
    private String validTimeName;
    private String assistantTeachers;
    private String lecturerTeachers;
    private String classTypeName;
    private Integer lessonCount;
    private String semesters;
    private String broadcastRoomName;
    private String classTeacherIds;
    private List<Map<String, Object>> coursePackageCourseRelList;
    private Integer canEdit;
    private List<Campus> campusList;

    private Byte segmentId;

    private Integer classLength;

    /**
     * 直播课类型 (0—大班课；1—分组课)
     */
    private Integer liveType;

    private Integer maxUsers;

    /**
     * 课程分组数量
     */
    private Integer groupNum;

    /**
     * 台下学生数量限制，最大支持300，（直播小班课）
     */
    private Integer maxBackupUsers;

    /**
     * 台下学生是否自动上台； 0：不是，1：是（直播小班课，目前默认否）
     */
    private Integer autoOnStage;

    /**
     * 播放人数
     */
    private Integer watchNum;


    public Integer getWatchNum() {
        return watchNum;
    }

    public void setWatchNum(Integer watchNum) {
        this.watchNum = watchNum;
    }

    public Integer getMaxBackupUsers() {
        return maxBackupUsers;
    }

    public void setMaxBackupUsers(Integer maxBackupUsers) {
        this.maxBackupUsers = maxBackupUsers;
    }

    public Integer getAutoOnStage() {
        return autoOnStage;
    }

    public void setAutoOnStage(Integer autoOnStage) {
        this.autoOnStage = autoOnStage;
    }

    public Integer getMaxUsers() {
        return maxUsers;
    }

    public void setMaxUsers(Integer maxUsers) {
        this.maxUsers = maxUsers;
    }

    public Integer getLiveType() {
        return liveType;
    }

    public void setLiveType(Integer liveType) {
        this.liveType = liveType;
    }

    public Integer getGroupNum() {
        return groupNum;
    }

    public void setGroupNum(Integer groupNum) {
        this.groupNum = groupNum;
    }

    public List<Campus> getCampusList() {
        return campusList;
    }

    public void setCampusList(List<Campus> campusList) {
        this.campusList = campusList;
    }

    public Byte getSegmentId() {
        return segmentId;
    }

    public void setSegmentId(Byte segmentId) {
        this.segmentId = segmentId;
    }

    public Integer getClassLength() {
        return classLength;
    }

    public void setClassLength(Integer classLength) {
        this.classLength = classLength;
    }

    public Integer getCanEdit() {
        return canEdit;
    }

    public void setCanEdit(Integer canEdit) {
        this.canEdit = canEdit;
    }

    public List<Map<String, Object>> getCoursePackageCourseRelList() {
        return coursePackageCourseRelList;
    }

    public void setCoursePackageCourseRelList(List<Map<String, Object>> coursePackageCourseRelList) {
        this.coursePackageCourseRelList = coursePackageCourseRelList;
    }

    public Byte getIscompose() {
        return iscompose;
    }

    public void setIscompose(Byte iscompose) {
        this.iscompose = iscompose;
    }

    public String getClassTeacherIds() {
        return classTeacherIds;
    }

    public void setClassTeacherIds(String classTeacherIds) {
        this.classTeacherIds = classTeacherIds;
    }

    public Byte getIsshow() {
        return isshow;
    }

    public void setIsshow(Byte isshow) {
        this.isshow = isshow;
    }

    public Byte getIstest() {
        return istest;
    }

    public void setIstest(Byte istest) {
        this.istest = istest;
    }

    public Integer getBroadcastRoomId() {
        return broadcastRoomId;
    }

    public void setBroadcastRoomId(Integer broadcastRoomId) {
        this.broadcastRoomId = broadcastRoomId;
    }

    public String getBroadcastRoomName() {
        return broadcastRoomName;
    }

    public void setBroadcastRoomName(String broadcastRoomName) {
        this.broadcastRoomName = broadcastRoomName;
    }

    public String getSummaryHtml() {
        return summaryHtml;
    }

    public void setSummaryHtml(String summaryHtml) {
        this.summaryHtml = summaryHtml;
    }

    public String getSubjectName() {
        return subjectName;
    }

    public void setSubjectName(String subjectName) {
        this.subjectName = subjectName;
    }

    public String getSemesters() {
        return semesters;
    }

    public void setSemesters(String semesters) {
        this.semesters = semesters;
    }

    public Integer getCourseVideoId() {
        return courseVideoId;
    }

    public void setCourseVideoId(Integer courseVideoId) {
        this.courseVideoId = courseVideoId;
    }

    public Integer getLessonCount() {
        return lessonCount;
    }

    public void setLessonCount(Integer lessonCount) {
        this.lessonCount = lessonCount;
    }

    public Byte getIsprepublish() {
        return isprepublish;
    }

    public void setIsprepublish(Byte isprepublish) {
        this.isprepublish = isprepublish;
    }

    public String getSemesterId() {
        return semesterId;
    }

    public void setSemesterId(String semesterId) {
        this.semesterId = semesterId;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public Integer getIntervalDays() {
        return intervalDays;
    }

    public void setIntervalDays(Integer intervalDays) {
        this.intervalDays = intervalDays;
    }

    public Integer getTeacherId() {
        return teacherId;
    }

    public void setTeacherId(Integer teacherId) {
        this.teacherId = teacherId;
    }

    public Integer getCourseMaximum() {
        return courseMaximum;
    }

    public void setCourseMaximum(Integer courseMaximum) {
        this.courseMaximum = courseMaximum;
    }

    public BigDecimal getCoursePrice() {
        return coursePrice;
    }

    public void setCoursePrice(BigDecimal coursePrice) {
        this.coursePrice = coursePrice;
    }

    public String getClassTypeName() {
        return classTypeName;
    }

    public void setClassTypeName(String classTypeName) {
        this.classTypeName = classTypeName;
    }

    public Integer getClassTypeId() {
        return classTypeId;
    }

    public void setClassTypeId(Integer classTypeId) {
        this.classTypeId = classTypeId;
    }

    public String getPeriodName() {
        return periodName;
    }

    public void setPeriodName(String periodName) {
        this.periodName = periodName;
    }

    public String getStageName() {
        return stageName;
    }

    public void setStageName(String stageName) {
        this.stageName = stageName;
    }

    public Integer[] getSubjectIds() {
        return subjectIds;
    }

    public void setSubjectIds(Integer[] subjectIds) {
        this.subjectIds = subjectIds;
    }

    public String getCourseTypeName() {
        return courseTypeName;
    }

    public void setCourseTypeName(String courseTypeName) {
        this.courseTypeName = courseTypeName;
    }

    public String getValidTimeName() {
        return validTimeName;
    }

    public void setValidTimeName(String validTimeName) {
        this.validTimeName = validTimeName;
    }

    public String getAssistantTeachers() {
        return assistantTeachers;
    }

    public void setAssistantTeachers(String assistantTeachers) {
        this.assistantTeachers = assistantTeachers;
    }

    public String getLecturerTeachers() {
        return lecturerTeachers;
    }

    public void setLecturerTeachers(String lecturerTeachers) {
        this.lecturerTeachers = lecturerTeachers;
    }

    public Integer getCourseId() {
        return courseId;
    }

    public void setCourseId(Integer courseId) {
        this.courseId = courseId;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName == null ? null : courseName.trim();
    }

    public Byte getTeachingMethod() {
        return teachingMethod;
    }

    public void setTeachingMethod(Byte teachingMethod) {
        this.teachingMethod = teachingMethod;
    }

    public String getCoverPath() {
        return coverPath;
    }

    public void setCoverPath(String coverPath) {
        this.coverPath = coverPath == null ? null : coverPath.trim();
    }

    public Integer getPeriodId() {
        return periodId;
    }

    public void setPeriodId(Integer periodId) {
        this.periodId = periodId;
    }

    public Integer getStageId() {
        return stageId;
    }

    public void setStageId(Integer stageId) {
        this.stageId = stageId;
    }

    public Integer getCourseTypeId() {
        return courseTypeId;
    }

    public void setCourseTypeId(Integer courseTypeId) {
        this.courseTypeId = courseTypeId;
    }

    public Byte getIspublic() {
        return ispublic;
    }

    public void setIspublic(Byte ispublic) {
        this.ispublic = ispublic;
    }

    public Byte getIscharge() {
        return ischarge;
    }

    public void setIscharge(Byte ischarge) {
        this.ischarge = ischarge;
    }

    public Byte getSale() {
        return sale;
    }

    public void setSale(Byte sale) {
        this.sale = sale;
    }

    public Byte getIstryvideo() {
        return istryvideo;
    }

    public void setIstryvideo(Byte istryvideo) {
        this.istryvideo = istryvideo;
    }

    public Byte getValidTime() {
        return validTime;
    }

    public void setValidTime(Byte validTime) {
        this.validTime = validTime;
    }

    public Byte getIspublish() {
        return ispublish;
    }

    public void setIspublish(Byte ispublish) {
        this.ispublish = ispublish;
    }

    public Byte getIshot() {
        return ishot;
    }

    public void setIshot(Byte ishot) {
        this.ishot = ishot;
    }

    public Integer getCreateBy() {
        return createBy;
    }

    public void setCreateBy(Integer createBy) {
        this.createBy = createBy;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(Integer updateBy) {
        this.updateBy = updateBy;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getPublishBy() {
        return publishBy;
    }

    public void setPublishBy(Integer publishBy) {
        this.publishBy = publishBy;
    }

    public Date getPublishTime() {
        return publishTime;
    }

    public void setPublishTime(Date publishTime) {
        this.publishTime = publishTime;
    }

    public Byte getIsdelete() {
        return isdelete;
    }

    public void setIsdelete(Byte isdelete) {
        this.isdelete = isdelete;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary == null ? null : summary.trim();
    }

    @Override
    public String toString() {
        return "Course{" +
                "courseId=" + courseId +
                ", courseName='" + courseName + '\'' +
                ", teachingMethod=" + teachingMethod +
                ", coverPath='" + coverPath + '\'' +
                ", semesterId='" + semesterId + '\'' +
                ", periodId=" + periodId +
                ", stageId=" + stageId +
                ", courseTypeId=" + courseTypeId +
                ", classTypeId=" + classTypeId +
                ", courseVideoId=" + courseVideoId +
                ", ispublic=" + ispublic +
                ", ischarge=" + ischarge +
                ", sale=" + sale +
                ", istryvideo=" + istryvideo +
                ", startDate=" + startDate +
                ", endDate=" + endDate +
                ", startTime='" + startTime + '\'' +
                ", endTime='" + endTime + '\'' +
                ", intervalDays=" + intervalDays +
                ", validTime=" + validTime +
                ", teacherId=" + teacherId +
                ", broadcastRoomId=" + broadcastRoomId +
                ", iscompose=" + iscompose +
                ", isprepublish=" + isprepublish +
                ", ispublish=" + ispublish +
                ", ishot=" + ishot +
                ", courseMaximum=" + courseMaximum +
                ", createBy=" + createBy +
                ", createTime=" + createTime +
                ", updateBy=" + updateBy +
                ", updateTime=" + updateTime +
                ", publishBy=" + publishBy +
                ", publishTime=" + publishTime +
                ", isdelete=" + isdelete +
                ", summary='" + summary + '\'' +
                ", summaryHtml='" + summaryHtml + '\'' +
                ", istest=" + istest +
                ", isshow=" + isshow +
                ", periodName='" + periodName + '\'' +
                ", stageName='" + stageName + '\'' +
                ", subjectName='" + subjectName + '\'' +
                ", subjectIds=" + Arrays.toString(subjectIds) +
                ", coursePrice=" + coursePrice +
                ", courseTypeName='" + courseTypeName + '\'' +
                ", validTimeName='" + validTimeName + '\'' +
                ", assistantTeachers='" + assistantTeachers + '\'' +
                ", lecturerTeachers='" + lecturerTeachers + '\'' +
                ", classTypeName='" + classTypeName + '\'' +
                ", lessonCount=" + lessonCount +
                ", semesters='" + semesters + '\'' +
                ", broadcastRoomName='" + broadcastRoomName + '\'' +
                ", classTeacherIds='" + classTeacherIds + '\'' +
                ", coursePackageCourseRelList=" + coursePackageCourseRelList +
                ", canEdit=" + canEdit +
                ", campusList=" + campusList +
                ", segmentId=" + segmentId +
                ", classLength=" + classLength +
                ", liveType=" + liveType +
                ", maxUsers=" + maxUsers +
                ", groupNum=" + groupNum +
                ", maxBackupUsers=" + maxBackupUsers +
                ", autoOnStage=" + autoOnStage +
                '}';
    }
}