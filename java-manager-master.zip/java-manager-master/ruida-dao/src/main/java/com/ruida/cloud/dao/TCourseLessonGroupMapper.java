package com.ruida.cloud.dao;

import com.ruida.cloud.model.TCourseLessonGroup;
import com.ruida.cloud.model.TCourseLessonGroupExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface TCourseLessonGroupMapper {
    int countByExample(TCourseLessonGroupExample example);

    int deleteByExample(TCourseLessonGroupExample example);

    int deleteByPrimaryKey(Integer courseLessonGroupId);

    int insert(TCourseLessonGroup record);

    int insertSelective(TCourseLessonGroup record);

    List<TCourseLessonGroup> selectByExample(TCourseLessonGroupExample example);

    TCourseLessonGroup selectByPrimaryKey(Integer courseLessonGroupId);

    int updateByExampleSelective(@Param("record") TCourseLessonGroup record, @Param("example") TCourseLessonGroupExample example);

    int updateByExample(@Param("record") TCourseLessonGroup record, @Param("example") TCourseLessonGroupExample example);

    int updateByPrimaryKeySelective(TCourseLessonGroup record);

    int updateByPrimaryKey(TCourseLessonGroup record);
}