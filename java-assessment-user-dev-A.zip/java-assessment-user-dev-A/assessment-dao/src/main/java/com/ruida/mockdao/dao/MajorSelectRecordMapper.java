package com.ruida.mockdao.dao;


import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.model.MajorSelectRecord;

/**
 * <p>
 * 专业兴趣选择记录 Mapper 接口
 * </p>
 *
 * @author xumingqi
 * @since 2021-01-14
 */
public interface MajorSelectRecordMapper extends BaseMapper<MajorSelectRecord> {

}
