package com.ruida.cloud.model;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;

/**
 * @author admin
 * @description: ${TODO}
 * @Date 2020/4/16
 * @verion 1.0
 */
@Data
public class DrainageActivityVO implements Serializable {
    private Integer drainageActivityId;
    private String drainageActivityName;
    private Date startTime;
    private Date endTime;
    private String courseNames;
    private String distributorName;
    private String distributorIds;

    /**
     * 总流量
     */
    private Long totalUv;

    /**
     * 时间开始结束区间
     */
    private String intervalStr;

    /**
     * 活动状态
     */
    private String drainageStatus;

    /**
     * 活动状态值
     */
    private Integer drainageStatusVul;

    /**
     * 0禁用 1启用
     */
    private Integer status;
    private Integer relateAllCourse;
    private Integer relateAllDistributor;

}
