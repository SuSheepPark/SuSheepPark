package com.ruida.assessment.assessmentquestionbank.imports.application;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.xwpf.usermodel.IBodyElement;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.apache.poi.xwpf.usermodel.XWPFTable;
import org.apache.poi.xwpf.usermodel.XWPFTableCell;
import org.apache.poi.xwpf.usermodel.XWPFTableRow;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTRPr;

import com.ruida.assessment.assessmentquestionbank.imports.docx.DocxService;
import com.ruida.assessment.assessmentquestionbank.imports.domain.service.HTMLProtocol;

/**
 * 将word对象转换为富文本的html对象，保留样式
 * 
 * @author mazhuang
 *
 */
public class Docx2HTMLProcessingFactory {

	public static String element2HTML(IBodyElement element, String prefix) {
		switch (element.getElementType()) {
		case PARAGRAPH:
			List<XWPFRun> runs = ((XWPFParagraph) element).getRuns();
			StringBuffer sb = new StringBuffer("<div>");
			boolean flag = false;
			String flagString = prefix, lineString = DocxService.getLineText(element);
			if (lineString.startsWith(prefix)) {
				flag = true;
			}
			for (XWPFRun run : runs) {
				if (flag) {
					String text = DocxService.getText(run);
					if (!StringUtils.isEmpty(text) && flagString.startsWith(text)) {
						flagString = flagString.substring(text.length());
						if (StringUtils.isEmpty(text)) {
							flag = false;
						}
						continue;
					}
				}
				String textHTML = run2HTML(run, flagString);
				if (!StringUtils.isEmpty(textHTML)) {
					sb.append(textHTML);
				}
			}
			return sb.append("</div>").toString();
		case TABLE:
			XWPFTable table = (XWPFTable) element;
			return table2HTML(table);
		default:
			return null;
		}
	}

	public static String run2HTML(XWPFRun run, String prefix) {
		String result = null;
		String contentString = DocxService.getText(run);
		if (!StringUtils.isEmpty(contentString)) {
			if (!StringUtils.isEmpty(prefix)) {
				if (contentString.startsWith(prefix)) {
					contentString = contentString.substring(prefix.length());
				} else if (prefix.contains(contentString)) {
					return contentString;
				}
			}
			if (StringUtils.isEmpty(contentString)) {
				return null;
			}
			String fontFamily = null, color = null;
			Integer fontSize = null;
			boolean isB = false, isI = false, isStrike = false, isU = false;

			CTRPr pr = run.getCTR().isSetRPr() ? run.getCTR().getRPr() : null;
			if (pr != null) {
				fontFamily = run.getFontFamily();
				fontSize = run.getFontSize();
				color = run.getColor();
				isB = pr.getB() != null;
				isI = pr.getI() != null;
				isU = pr.getU() != null;
				isStrike = pr.getStrike() != null;
			}
			String textHTML = HTMLProtocol.parseText(contentString, fontFamily, fontSize, color, isB, isI, isU,
					isStrike);
			result = textHTML;
		} else {
			String imgBase64 = DocxService.getPic(run);
			if (!StringUtils.isEmpty(imgBase64)) {
				result = HTMLProtocol.parseImg(imgBase64);
			} else {
				imgBase64 = DocxService.getMath(run);
				if (!StringUtils.isEmpty(imgBase64)) {
					result = HTMLProtocol.parseImg(imgBase64);
				}
			}
		}
		return result;
	}

	public static String table2HTML(XWPFTable table) {
		StringBuffer sbTable=new StringBuffer();
		for (int i = 0; i < table.getNumberOfRows(); i++) {
			XWPFTableRow row = table.getRow(i);
			List<XWPFTableCell> cells = row.getTableCells();
			StringBuffer sbRow=new StringBuffer();
			for (XWPFTableCell cell : cells) {
				List<XWPFParagraph> paragraphs = cell.getParagraphs();

				StringBuffer sbCell = new StringBuffer();
				for (XWPFParagraph paragraph : paragraphs) {
					List<XWPFRun> runs = paragraph.getRuns();
					StringBuffer sb = new StringBuffer();
					for (XWPFRun run : runs) {
						String textHTML = run2HTML(run, null);
						if (!StringUtils.isEmpty(textHTML)) {
							sb.append(textHTML);
						}
					}
					if (sb.length() > 0) {
						sbCell.append(sb).append("</br>");
					}
				}
				sbRow.append(HTMLProtocol.parseTableCell(sbCell.toString()));
			}
			sbTable.append(HTMLProtocol.parseTableRow(sbRow.toString()));
		}
		return HTMLProtocol.parseTable(sbTable.toString(),table.getWidth());
	}
}
