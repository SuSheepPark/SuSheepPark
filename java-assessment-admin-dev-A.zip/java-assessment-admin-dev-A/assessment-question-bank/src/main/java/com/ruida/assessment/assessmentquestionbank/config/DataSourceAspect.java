package com.ruida.assessment.assessmentquestionbank.config;

import com.ruida.assessment.assessmentcommon.enums.DBTypeEnum;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

/**
 * @author taosh
 * @create 2019-12-10 14:29
 */
@Component
@Order(value = -100)
@Slf4j
@Aspect
public class DataSourceAspect {
    @Pointcut("execution(* com.ruida.assessment.assessmentquestionbank.dao..*.*(..))")
    private void db1Aspect() {
    }

   /* @Pointcut("execution(* com.ruida.assessment.assessmentquestionbank.ruidacloudDao..*.*(..))")
    private void db2Aspect() {
    }*/

    @Before("db1Aspect()")
    public void db1() {
//        log.info("切换到db1 数据源...");
        DataSourceContextHolder.setDbType(DBTypeEnum.ceping);
    }

    /*@Before("db2Aspect()")
    public void db2() {
        log.info("切换到db2 数据源...");
        DataSourceContextHolder.setDbType(DBTypeEnum.ruidaCloud);
    }*/
}
