package com.ruida.mockdao.model;

import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 大学专业类表（不是专业表）
 * </p>
 *
 * @author xumingqi
 * @since 2021-01-14
 */
@TableName("t_major_category")
public class MajorCategory extends Model<MajorCategory> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "major_category_id", type = IdType.AUTO)
    private Integer majorCategoryId;
    /**
     * 专业类代码
     */
    @TableField("major_category_code")
    private String majorCategoryCode;
    @TableField("major_category_name")
    private String majorCategoryName;
    /**
     * 学科门类代码
     */
    @TableField("subject_category_code")
    private String subjectCategoryCode;
    @TableField("subject_category_name")
    private String subjectCategoryName;
    /**
     * 创建者ID
     */
    @TableField("create_by")
    private Integer createBy;
    /**
     * 创建时间
     */
    @TableField("create_time")
    private Date createTime;
    /**
     * 更新者ID
     */
    @TableField("update_by")
    private Integer updateBy;
    /**
     * 更新时间
     */
    @TableField("update_time")
    private Date updateTime;
    /**
     * 是否删除（0：未删除；1：删除）
     */
    private Integer isdelete;


    public Integer getMajorCategoryId() {
        return majorCategoryId;
    }

    public void setMajorCategoryId(Integer majorCategoryId) {
        this.majorCategoryId = majorCategoryId;
    }

    public String getMajorCategoryCode() {
        return majorCategoryCode;
    }

    public void setMajorCategoryCode(String majorCategoryCode) {
        this.majorCategoryCode = majorCategoryCode;
    }

    public String getMajorCategoryName() {
        return majorCategoryName;
    }

    public void setMajorCategoryName(String majorCategoryName) {
        this.majorCategoryName = majorCategoryName;
    }

    public String getSubjectCategoryCode() {
        return subjectCategoryCode;
    }

    public void setSubjectCategoryCode(String subjectCategoryCode) {
        this.subjectCategoryCode = subjectCategoryCode;
    }

    public String getSubjectCategoryName() {
        return subjectCategoryName;
    }

    public void setSubjectCategoryName(String subjectCategoryName) {
        this.subjectCategoryName = subjectCategoryName;
    }

    public Integer getCreateBy() {
        return createBy;
    }

    public void setCreateBy(Integer createBy) {
        this.createBy = createBy;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(Integer updateBy) {
        this.updateBy = updateBy;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getIsdelete() {
        return isdelete;
    }

    public void setIsdelete(Integer isdelete) {
        this.isdelete = isdelete;
    }

    @Override
    protected Serializable pkVal() {
        return this.majorCategoryId;
    }

    @Override
    public String toString() {
        return "MajorCategory{" +
                ", majorCategoryId=" + majorCategoryId +
                ", majorCategoryCode=" + majorCategoryCode +
                ", majorCategoryName=" + majorCategoryName +
                ", subjectCategoryCode=" + subjectCategoryCode +
                ", subjectCategoryName=" + subjectCategoryName +
                ", createBy=" + createBy +
                ", createTime=" + createTime +
                ", updateBy=" + updateBy +
                ", updateTime=" + updateTime +
                ", isdelete=" + isdelete +
                "}";
    }
}
