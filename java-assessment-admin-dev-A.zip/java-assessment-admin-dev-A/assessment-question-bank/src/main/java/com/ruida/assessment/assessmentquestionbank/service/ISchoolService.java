package com.ruida.assessment.assessmentquestionbank.service;

import com.baomidou.mybatisplus.service.IService;
import com.ruida.assessment.assessmentcommon.result.BaseResult;
import com.ruida.assessment.assessmentcommon.result.PageData;
import com.ruida.assessment.assessmentcommon.result.PojoResult;
import com.ruida.assessment.assessmentquestionbank.dto.BatchOperationRequest;
import com.ruida.assessment.assessmentquestionbank.dto.SchoolRequest;
import com.ruida.assessment.assessmentquestionbank.model.TClass;
import com.ruida.assessment.assessmentquestionbank.model.TGrade;
import com.ruida.assessment.assessmentquestionbank.model.TSchool;
import com.ruida.assessment.assessmentquestionbank.vo.*;

import java.util.List;
import java.util.Map;

/**
 * @author wy
 * @description
 * @date 2020/6/12  学校管理服务接口
 */

public interface ISchoolService extends IService<TSchool> {

    /*
        查询学校列表 （分页）
     */
    PageData<SchoolVo> querySchoolList(SchoolRequest request);

    /*
        查询学校列表总数
     */
    Integer querySchoolCount(SchoolRequest request);

    /*
        禁用、启用、删除学校
     */
    BaseResult updateOrDeleteSchool(BatchOperationRequest request);

    /*
        新增、修改学校信息
     */
    PojoResult saveSchool(SchoolRequest request);

    /*
        编辑时查询学校信息
     */
    SchoolVo querySchoolInfo(Integer schoolId);

    /*
        下拉框获取学校列表
    */
    List<TSchool> querySchoolListInfo(Integer periodId,Integer district);

    /*
        下拉框获取学校年级列表
    */
    List<TGrade> queryGradeBySchoolId(Integer schoolId);

    /*
        下拉框获取年级班级列表
    */
    List<ClassVo> queryClassByGradeId(Integer gradeId, Integer schoolId);

    /*
        根据学校id和班级id查询学校和班级代码
     */
    Map<String, String> getSchoolOrClassCode(Integer schoolId, Integer classId);

    /**
     * 查询学校班级待办信息
     * @param request
     * @return
     */
    List<SchoolClassTaskVO> getTask(SchoolRequest request);

    BaseResult insertClass(Integer schoolId, String periodId);
}
