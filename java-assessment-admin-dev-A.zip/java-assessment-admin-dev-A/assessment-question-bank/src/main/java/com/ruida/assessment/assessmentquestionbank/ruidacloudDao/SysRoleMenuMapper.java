package com.ruida.assessment.assessmentquestionbank.ruidacloudDao;

import com.ruida.assessment.assessmentquestionbank.model.SysRoleMenu;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

/**
 * <p>
 * 角色菜单关系表 Mapper 接口
 * </p>
 *
 * @author szl
 * @since 2020-07-14
 */
public interface SysRoleMenuMapper extends BaseMapper<SysRoleMenu> {

    @Select("select count(id) from sys_role_menu where role_id =#{roleId} and menu_id =#{menuId}")
    int selectCountBymenuIdAndRoleId(@Param("roleId") Integer roleId , @Param("menuId") Integer menuId);

    @Delete("delete from sys_role_menu where role_id =#{roleId}  ")
    int deleteByByRoleId(@Param("roleId") Integer roleId );
}
