package com.ruida.mockdao.vo;
import com.ruida.mockdao.vo.product.PaperReportVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

@Data
@ApiModel(value = "Product对象", description = "商品")
//@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProductNewVO implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "商品id")
    private Integer productId;

    @ApiModelProperty(value = "商品号")
    private String productNo;

    @ApiModelProperty(value = "商品名称")
    private String productName;


    @ApiModelProperty(value = "商品最低价格 安卓和PC")
    private BigDecimal lowestPrice;

    @ApiModelProperty(value = "商品最低价格 IOS")
    private BigDecimal lowestIosPrice;
    @ApiModelProperty(value = "商品最高价格IOS")
    private BigDecimal iosTotalPrice;
    @ApiModelProperty(value = "商品最高价格")
    private BigDecimal totalPrice;

    @ApiModelProperty(value = "购买量")
    private Integer buyNum;

    @ApiModelProperty(value = "商品图片")
    private String productImg;

    @ApiModelProperty(value = "科目名称，多个科目名称用 | 拼接")
    private String subjectName;


    @ApiModelProperty(value = "年级名称 多个名称用 | 拼接")
    private String gradeName;

    @ApiModelProperty(value = "年份,多个年份用 多个名称用 | 拼接")
    private String years;

    @ApiModelProperty(value = "商品状态（0.已下架，1.已上架，2.草稿，3.待审核）")
    private Integer status;

    @ApiModelProperty(value = "是否置顶  0未置顶  1置顶")
    private Integer top = 0;
    @ApiModelProperty(value = "价格是否加起  0未置顶  1置顶")
    private Integer eq = 0;
    @ApiModelProperty(value = "价格是否加起  0未置顶  1置顶")
    private Integer iOSEq = 0;
    @ApiModelProperty(value = "价格描述")
    private String priceDesp;
    @ApiModelProperty(value = "ios价格描述")
    private String iosPriceDesp;
    @ApiModelProperty(value = "试卷份数")
    private Integer count;
    @ApiModelProperty(value = "是否购收藏  0未收藏  1收藏")
    private Integer isCollect;
    @ApiModelProperty(value = "是否购买  0未购买  1购买")
    private Integer isBuy = 0;
    @ApiModelProperty(value = "教材版本名称")
    private String versionName;
    @ApiModelProperty(value = "完成人数")
    private Integer completeNum;

    @ApiModelProperty(value = "完成度")
    private BigDecimal completeRate;
    @ApiModelProperty(value = "商品描述 html格式")
    private String productInfoHtml;
    @ApiModelProperty(value = "试卷列表")
    private List<PaperReportVO> testPapers;

    @ApiModelProperty(value = "联系电话")
    private String telephone;
    @ApiModelProperty(value = "已购买的试卷数量")
    private Integer purchasedTestPaperNum;

    @ApiModelProperty(value = "已完成的试卷数量")
    private Integer completeTestPaperNum;


}
