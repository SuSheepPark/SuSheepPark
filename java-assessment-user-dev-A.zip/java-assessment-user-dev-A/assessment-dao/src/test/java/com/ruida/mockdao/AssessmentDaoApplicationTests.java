package com.ruida.mockdao;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AssessmentDaoApplicationTests {

    @Test
    void contextLoads() {
    }

}
