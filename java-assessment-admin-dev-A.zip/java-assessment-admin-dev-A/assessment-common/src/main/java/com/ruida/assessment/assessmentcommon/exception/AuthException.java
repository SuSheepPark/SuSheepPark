package com.ruida.assessment.assessmentcommon.exception;


import com.ruida.assessment.assessmentcommon.enums.AppErrorEnum;

public class AuthException extends RuntimeException {
    /**  */
    private static final long serialVersionUID = 5792816284203588336L;
    /**
     * 错误码 业务层面
     */
    private String errCode;
    /**
     * 错误消息
     */
    private String message;

    /**
     * 业务错误信息
     */
    private String subErrCode;

    @Override
    public String getMessage() {
        return message;
    }

    public String getErrCode() {
        return errCode;
    }

    public String getSubErrCode() {
        return subErrCode;
    }

    public AuthException(String errCode, String message, Throwable cause) {
        super(message, cause);
        this.errCode = errCode;
        this.message = message;
    }

    public AuthException(String errCode, String message) {
        super(message);
        this.errCode = errCode;
        this.message = message;
    }

    public AuthException(AppErrorEnum aisCommonError) {
        this(aisCommonError.getHttpStatus(), aisCommonError.getErrorMessage());
        this.subErrCode = aisCommonError.getErrorCode();
    }

    public AuthException(AppErrorEnum aisCommonError, String errMsg) {
        this(aisCommonError.getHttpStatus(), aisCommonError.getErrorMessage() + " " + errMsg);
        this.subErrCode = aisCommonError.getErrorCode();
    }

    public AuthException(String errMsg, AppErrorEnum aisCommonError) {
        this(aisCommonError.getHttpStatus(), errMsg + " " + aisCommonError.getErrorMessage());
        this.subErrCode = aisCommonError.getErrorCode();
    }
}
