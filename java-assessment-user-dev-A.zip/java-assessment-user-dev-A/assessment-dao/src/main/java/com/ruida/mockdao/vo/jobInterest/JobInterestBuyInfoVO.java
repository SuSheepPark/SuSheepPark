package com.ruida.mockdao.vo.jobInterest;

import lombok.Data;

import java.util.List;

/**
 * @author xumingqi
 * @date 2021/2/5 16:35
 */
@Data
public class JobInterestBuyInfoVO {
    String imageUrl;
    String service;
    List<String> instruction;
    String price;
    String originPrice;
    String iosPrice;
    String productId;
}
