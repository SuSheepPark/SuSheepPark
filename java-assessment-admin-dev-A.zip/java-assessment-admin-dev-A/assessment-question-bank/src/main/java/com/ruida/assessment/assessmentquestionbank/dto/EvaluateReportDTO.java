package com.ruida.assessment.assessmentquestionbank.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * @description: 升学选拔报告
 * @author: kgz
 * @date: 2020/12/17
 */
@ApiModel(description = "升学选拔报告")
public class EvaluateReportDTO {

    @ApiModelProperty(value = "试题类型id", name = "questionTypeId", required = true)
    private Integer reportId;

    @ApiModelProperty(value = "父级id", name = "parentId", required = true)
    private String reportName;

    public Integer getReportId() {
        return reportId;
    }

    public void setReportId(Integer reportId) {
        this.reportId = reportId;
    }

    public String getReportName() {
        return reportName;
    }

    public void setReportName(String reportName) {
        this.reportName = reportName;
    }
}
