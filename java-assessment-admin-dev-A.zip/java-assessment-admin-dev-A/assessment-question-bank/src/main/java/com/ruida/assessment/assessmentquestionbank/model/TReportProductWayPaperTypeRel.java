package com.ruida.assessment.assessmentquestionbank.model;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import io.swagger.annotations.ApiModel;
import lombok.Data;

import java.io.Serializable;


@Data
@TableName("t_report_productway_papertype_rel")
@ApiModel(description = "报告类型和试卷性质和商品测验形式关联表")
public class TReportProductWayPaperTypeRel extends BaseColumn implements Serializable {

    private static final long serialVersionUID = 1L;

    //主键id
    @TableId
    private Integer id;

    //是否需要关联常模，0不需要，1需要
    private Integer needConst;

    //试卷性质(1-练习卷 2-高中联考卷1分1赋 3-高中联考卷3分1赋 4-高中联考卷必考科目 5-初中联考卷)
    private Integer paperUseType;

    //商品测验形式(0-平时练习 1-纸考(线下联考) 2-机房统考 3-在线统考)
    private Integer productTestWay;

    //班级学校报告类型，关联t_schoolclass_report_template表id
    private Integer reportTypeElseId;

    //个人报告类型，关联t_report_template表id
    private Integer reportTypeStudentId;


}
