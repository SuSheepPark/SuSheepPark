package com.ruida.mockcommon.util;

import org.apache.commons.lang3.StringUtils;
import sun.misc.BASE64Encoder;

import javax.imageio.ImageIO;
import javax.imageio.ImageReadParam;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;
import java.awt.*;
import java.awt.geom.AffineTransform;
import java.awt.image.AffineTransformOp;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.Iterator;


/**
 * 图片处理工具类   其他功能待扩展
 * @author szl
 *
 */
public class ImageHelper {

	/**
	 * 图片缩放
	 *
	 * @param input
	 * @param suffix
	 * @param w
	 * @param h
	 * @return
	 * @throws Exception
	 */
	public static byte[] zoomImage(InputStream input, String suffix, int w, int h) throws Exception {
		// 参数判断
		if (input == null) {
			throw new RuntimeException("input is null");
		}
		if (StringUtils.isBlank(suffix)) {
			throw new RuntimeException("suffix is empty");
		}
		double wr = 0, hr = 0;
		BufferedImage bufImg = ImageIO.read(input);
		Image itemp = bufImg.getScaledInstance(w, h, Image.SCALE_SMOOTH);
		// 计算放大率
		wr = w * 1.0 / bufImg.getWidth();
		hr = h * 1.0 / bufImg.getHeight();
		AffineTransformOp ato = new AffineTransformOp(AffineTransform.getScaleInstance(wr, hr), null);
		// 放大处理
		itemp = ato.filter(bufImg, null);
		// 返回字节流
		ByteArrayOutputStream output = new ByteArrayOutputStream();
		ImageIO.write((BufferedImage) itemp, suffix, output);
		return output.toByteArray();
	}

	/**
	 * 图片裁剪通用接口
	 *
	 * @param input
	 * @param suffix
	 * @param x
	 * @param y
	 * @param w
	 * @param h
	 * @return
	 * @throws Exception
	 */
	public static byte[] cutImage(InputStream input, String suffix, int x, int y, int w, int h) throws Exception {
		// 参数判断
		if (input == null) {
			throw new RuntimeException("input is null");
		}
		if (StringUtils.isBlank(suffix)) {
			throw new RuntimeException("suffix is empty");
		}
		// 获取 ImageReader对象
		Iterator<ImageReader> iterator = ImageIO.getImageReadersByFormatName(suffix);
		ImageReader reader = (ImageReader) iterator.next();

		// 实始输入流
		ImageInputStream iis = ImageIO.createImageInputStream(input);
		reader.setInput(iis, true);

		// 初始ImageReadParam 参数
		ImageReadParam param = reader.getDefaultReadParam();
		Rectangle rect = new Rectangle(x, y, w, h);
		param.setSourceRegion(rect);
		BufferedImage bi = reader.read(0, param);

		// 生成字节流
		ByteArrayOutputStream ouput = new ByteArrayOutputStream();
		ImageIO.write(bi, suffix, ouput);
		return ouput.toByteArray();
	}

	/**
	 * 图片裁剪通用接口
	 *
	 * @param images
	 * @param outPut
	 * @param suffix
	 * @param x
	 * @param y
	 * @param w
	 * @param h
	 * @throws IOException
	 */
	public static void generateImage(byte[] images, OutputStream outPut, String suffix, int x, int y, int w, int h)
			throws IOException {
		// 参数判断
		if (images == null || images.length == 0) {
			throw new RuntimeException("images is null");
		}
		if (outPut == null) {
			throw new RuntimeException("outPut is null");
		}
		if (StringUtils.isBlank(suffix)) {
			throw new RuntimeException("suffix is empty");
		}
		// 获取 ImageReader对象
		Iterator<ImageReader> iterator = ImageIO.getImageReadersByFormatName(suffix);
		ImageReader reader = (ImageReader) iterator.next();

		// 初始化输入流
		ByteArrayInputStream input = new ByteArrayInputStream(images);
		ImageInputStream iis = ImageIO.createImageInputStream(input);
		reader.setInput(iis, true);

		// 初始化参数
		ImageReadParam param = reader.getDefaultReadParam();
		Rectangle rect = new Rectangle(x, y, w, h);
		param.setSourceRegion(rect);
		BufferedImage bi = reader.read(0, param);

		ImageIO.write(bi, suffix, outPut);
	}

	/**
	 * 图片裁剪通用接口
	 *
	 * @param images
	 * @param suffix
	 * @param x
	 * @param y
	 * @param w
	 * @param h
	 * @throws IOException
	 */
	public static void generateImage(String dest, byte[] images, String suffix, int x, int y, int w, int h)
			throws IOException {
		Iterator<ImageReader> iterator = ImageIO.getImageReadersByFormatName(suffix);
		ImageReader reader = (ImageReader) iterator.next();

		ByteArrayInputStream input = new ByteArrayInputStream(images);
		ImageInputStream iis = ImageIO.createImageInputStream(input);
		reader.setInput(iis, true);

		ImageReadParam param = reader.getDefaultReadParam();
		Rectangle rect = new Rectangle(x, y, w, h);
		param.setSourceRegion(rect);
		BufferedImage bi = reader.read(0, param);

		ImageIO.write(bi, suffix, new File(dest));
	}

	public static void main(String args[]) throws Exception {
		String imageType = "jpg";
		int x = 150;
		int y = 50;
		int w = 750;
		int h = 560;
		String src = "E:\\ui\\Koala.jpg";

		byte[] imageBytes = ImageHelper.cutImage(new FileInputStream(src), imageType, x, y, w, h);
		System.out.println(imageBytes.length);

		// 根据bytes生成图片
		String destPath = "E:\\ui\\KoalaNew.png";
		ImageHelper.generateImage(destPath, imageBytes, imageType, x, y, w, h);
	}

	/**
	 * 图片base64编码
	 * @param bufferedImage
	 * @return
	 */
	public static String imageToBase64(BufferedImage bufferedImage) throws IOException {
		ByteArrayOutputStream outputStream = null;
		outputStream = new ByteArrayOutputStream();
		ImageIO.write(bufferedImage, "jpg", outputStream);
		BASE64Encoder encoder = new BASE64Encoder();
		return encoder.encode(outputStream.toByteArray()).replace("\r\n","");// 返回Base64编码过的字节数组字符串
	}
}
