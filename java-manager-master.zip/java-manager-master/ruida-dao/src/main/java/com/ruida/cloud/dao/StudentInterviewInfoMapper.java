package com.ruida.cloud.dao;

import com.ruida.cloud.model.StudentInterviewInfo;
import com.ruida.cloud.model.StudentInterviewInfoExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface StudentInterviewInfoMapper {
    long countByExample(StudentInterviewInfoExample example);

    int deleteByExample(StudentInterviewInfoExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(StudentInterviewInfo record);

    int insertSelective(StudentInterviewInfo record);

    List<StudentInterviewInfo> selectByExample(StudentInterviewInfoExample example);

    StudentInterviewInfo selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") StudentInterviewInfo record, @Param("example") StudentInterviewInfoExample example);

    int updateByExample(@Param("record") StudentInterviewInfo record, @Param("example") StudentInterviewInfoExample example);

    int updateByPrimaryKeySelective(StudentInterviewInfo record);

    int updateByPrimaryKey(StudentInterviewInfo record);

    List<Map<String, Object>> listInterviewByStuId(Map condition);
}