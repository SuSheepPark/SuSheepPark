package com.ruida.mockdao.model;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableLogic;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;
import lombok.Data;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.util.Date;

/**
 * <p>
 * 商品-试卷关联表
 * </p>
 *
 * @author chenjy
 * @since 2020-07-17
 */
@TableName("t_test_paper_product_rel")
@Data
@Accessors(chain = true)
public class TestPaperProductRel  {

    private static final long serialVersionUID = 1L;

    /**
     * id
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;
    /**
     * 试卷id
     */
    @TableField("test_paper_id")
    private Integer testPaperId;
    /**
     * 商品id
     */
    @TableField("product_id")
    private Integer productId;
    /**
     * 初始化测试人数
     */
    @TableField("init_test_num")
    private Integer initTestNum;
    /**
     * 可测试次数
     */
    @TableField("allow_test_num")
    private Integer allowTestNum;
    /**
     * 试卷关联模板id，多个模板id用 , 拼接
     */
    @TableField("paper_report_ids")
    private String paperReportIds;
    /**
     * 是否需要人工阅卷 0-否 1-是
     */
    private Integer isartificial;
    /**
     * 更新时间
     */
    @TableField("update_time")
    private Date updateTime;
    /**
     * 更新人
     */
    @TableField("update_by")
    private Integer updateBy;
    /**
     * 创建时间
     */
    @TableField("create_time")
    private Date createTime;
    /**
     * 创建人
     */
    @TableField("create_by")
    private Integer createBy;
    /**
     * 是否删除
     */
    @TableLogic
    private Integer isdelete;

    /**
     * 考试开始时间
     */
    @TableField("test_start_time")
    private Date testStartTime;

    /**
     * 考试结束时间
     */
    @TableField("test_end_time")
    private Date testEndTime;

    /**
     * 考试方式
     */
    @TableField("test_way")
    private Integer testWay;

    @TableField("ispresell")
    private Integer ispresell;

    /**
     * 商品试卷对应的常模id
     */
    @TableField("const_range_id")
    private Integer constRangeId;

    /**
     * 试卷价格
     */
    @TableField("paper_price")
    private BigDecimal paperPrice;

    /**
     * 试卷ios价格
     */
    @TableField("paper_ios_price")
    private BigDecimal paperIosPrice;

    /**
     * 报告价格
     */
    @TableField("report_price")
    private BigDecimal reportPrice;

    /**
     * 报告ios价格
     */
    @TableField("report_ios_price")
    private BigDecimal reportIosPrice;

    /**
     * 阅卷方式(1-自动批阅 2-后台批阅 3-自主批阅) 多个用英文逗号分隔
     */
    @TableField("correct_way")
    private String correctWay;
}
