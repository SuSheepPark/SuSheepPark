package com.ruida.assessment.assessmentquestionbank.model;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;

/**
 * @author wy
 * @description 商品关联预售占位试卷表
 * @date 2020/10/19
 */
@Data
@TableName("t_presell_test_paper")
public class TPresellTestPaper extends BaseColumn implements Serializable {


    private static final long serialVersionUID = -8521771662757858384L;
    @TableId
    private Integer id;

    /**
     * 教材版本id
     */
    private Integer versionId;

    /**
     * 年级id
     */
    private Integer stageId;

    /**
     * 学科id
     */
    private Integer subjectId;

    /**
     * 年份
     */
    private Integer year;

    /*测试时长*/
    private Integer testDruation;

    private Integer productId;

    private String testPaperName;


}
