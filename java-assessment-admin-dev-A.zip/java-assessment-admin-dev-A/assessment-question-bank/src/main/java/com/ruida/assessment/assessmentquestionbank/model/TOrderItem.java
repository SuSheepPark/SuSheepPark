package com.ruida.assessment.assessmentquestionbank.model;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import io.swagger.annotations.ApiModel;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;


/**
 * @author wy
 * @description  订单-商品关联实体类
 * @date 2020/8/3
 */
@Data
@ApiModel(description = "订单商品关联实体类")
@TableName("t_order_item")
public class TOrderItem extends BaseColumn implements Serializable {


    private static final long serialVersionUID = -607065716505755194L;
    /**
     * 主键id
     */
    @TableId
    private Integer orderItemId;

    private Integer orderId;

    private Integer productId;

    /**
     * 报告id(t_test_paper_product_rel表的主键，非计算好的报告的id)
     */
    private Integer reportId;

    /**
     * 商品名称
     */
    private String productName;

    /**
     * 商品图片
     */
    private String productImage;

    /**
     * 试卷id
     */
    private Integer testPaperId;

    /**
     * 是否预售试卷 0-正常试卷 1-预售试卷
     */
    private Integer ispresell;

    /**
     * 试卷名称
     */
    private String testPaperName;

    /**
     * 试卷价格
     */
    private BigDecimal testPaperPrice;

    /**
     * 试卷ios价格
     */
    private BigDecimal testPaperIosPrice;

    /**
     * 报告价格
     */
    private BigDecimal reportPrice;

    /**
     * 报告ios价格
     */
    private BigDecimal reportIosPrice;

    /**
     * 是否购买试卷
     */
    private Integer buyPaper;

    /**
     * 是否购买报告 0-否 1-是
     */
    private Integer buyReport;


}
