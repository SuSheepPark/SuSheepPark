package com.ruida.mockdao.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.model.StatAssessmentTargetUserRel;
import com.ruida.mockdao.vo.TargetStatVO;
import org.apache.ibatis.annotations.Param;
import java.util.List;

/**
 * <p>
 * 考察要求用户统计表 Mapper 接口
 * </p>
 *
 * @author chenjy
 * @since 2021-03-04
 */
public interface StatAssessmentTargetUserRelMapper extends BaseMapper<StatAssessmentTargetUserRel> {

    /**
     * 个人考察要求掌握情况
     * @param recordId
     * @return
     */
    List<TargetStatVO> queryUserTargetStat(Integer recordId);

    /**
     * 班级考察要求掌握情况
     * @param userId
     * @param productId
     * @param testPaperId
     * @return
     */
    List<TargetStatVO> queryClassTargetStat(@Param("userId") Integer userId, @Param("productId") Integer productId, @Param("testPaperId") Integer testPaperId);

    /**
     * 学校考察要求掌握情况
     * @param userId
     * @param productId
     * @param testPaperId
     * @return
     */
    List<TargetStatVO> querySchoolTargetStat(@Param("userId") Integer userId, @Param("productId") Integer productId, @Param("testPaperId") Integer testPaperId);

    /**
     * 查询9+1学校考察要求掌握情况
     * @param productId
     * @param testPaperId
     * @return
     */
    List<TargetStatVO> queryNineOneSchoolTargetStat(@Param("productId") Integer productId, @Param("testPaperId") Integer testPaperId);

    /**
     * 联考学校掌握率
     * @param productId
     * @param testPaperId
     * @return
     */
    List<TargetStatVO> queryUnionTargetStat(@Param("productId") Integer productId, @Param("testPaperId") Integer testPaperId);
}
