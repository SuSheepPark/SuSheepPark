package com.ruida.assessment.assessmentquestionbank.model;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import lombok.Data;

import java.io.Serializable;

/**
 * @author wy
 * @description  考试类型-学段关联实体类
 * @date 2020/9/14
 */
@Data
@TableName("t_test_type_period_rel")
public class TTestTypePeriodRel implements Serializable {


    private static final long serialVersionUID = 6994263433242141376L;
    @TableId
    private Integer id;

    private Integer testTypeId;
    private Integer periodId;
}
