package com.ruida.mockdao.vo;

import lombok.Data;

import java.util.List;

/**
 * Created by xumingqi on 2021/7/21 16:48
 */
@Data
public class SelfCheckPaperVO {
    /**
     * 试卷id
     */
    private Integer testPaperId;

    /**
     * 试卷名称
     */
    private String testPaperName;

    /**
     * 小节集合
     */
    private List<SelfCheckNodeVO> nodeList;
}
