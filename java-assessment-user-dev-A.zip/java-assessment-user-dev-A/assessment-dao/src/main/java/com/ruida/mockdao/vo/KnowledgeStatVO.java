package com.ruida.mockdao.vo;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.util.List;


@Data
@ApiModel(value="知识点统计")
@EqualsAndHashCode(exclude={"rankSchool", "rankClass","knowledgeName","userId","examRecordId","fullScore",
        "realScore","rateScore","rateScorePercent","fullScoreClass","realScoreClass","rateScoreSchoolAvg",
        "rateScoreNineOneSchoolAvg","rankNineOneSchool","ratePercentSchool","ratePercentNineOneSchool"})
public class KnowledgeStatVO implements Serializable {

    @ApiModelProperty(value = "知识点id")
    private Integer knowledgeId;

    @ApiModelProperty(value = "知识点父id")
    private Integer pid;

    @ApiModelProperty(value = "知识点名称")
    private String knowledgeName;

    @ApiModelProperty(value = "用户id")
    private Integer userId;

    @ApiModelProperty(value = "考试id")
    private Integer examRecordId;

    @ApiModelProperty(value = "满分")
    private Double fullScore;

    @ApiModelProperty(value = "得分")
    private Double realScore;

    @ApiModelProperty(value = "本人掌握率")
    private Double rateScore;

    @ApiModelProperty(value = "本人掌握率百分比")
    private String rateScorePercent;

    @ApiModelProperty(value = "班级满分")
    private Double fullScoreClass;

    @ApiModelProperty(value = "班级得分")
    private Double realScoreClass;

    @ApiModelProperty(value = "班级掌握率")
    private Double rateScoreClass;

    @ApiModelProperty(value = "学校满分")
    private Double fullScoreSchool;

    @ApiModelProperty(value = "学校得分")
    private Double realScoreSchool;

    @ApiModelProperty(value = "学校掌握率")
    private Double rateScoreSchool;

    @ApiModelProperty(value = "本校平均掌握率")
    private String rateScoreSchoolAvg;

    @ApiModelProperty(value = "9+1学校平均掌握率")
    private String rateScoreNineOneSchoolAvg;

    @ApiModelProperty(value = "联考学校满分")
    private Double fullScoreUnion;

    @ApiModelProperty(value = "联考学校得分")
    private Double realScoreUnion;

    @ApiModelProperty(value = "联考学校掌握率")
    private Double rateScoreUnion;

    @ApiModelProperty(value = "班级排名")
    private Integer rankClass;

    @ApiModelProperty(value = "学校排名")
    private Integer rankSchool;

    @ApiModelProperty(value = "9+1学校排名")
    private Integer rankNineOneSchool;

    @ApiModelProperty(value = "联考学校排名")
    private Integer rankUnion;

    @ApiModelProperty(value = "掌握率在本校的百分比")
    private String ratePercentSchool;

    @ApiModelProperty(value = "掌握率在9+1学校的百分比")
    private String ratePercentNineOneSchool;

    @ApiModelProperty(value = "树形结构时此知识点的行高")
    private Integer rowNum;

    @ApiModelProperty(value = "树形结构")
    private List<KnowledgeStatVO> children;
}
