package com.ruida.assessment.assessmentquestionbank.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.assessment.assessmentquestionbank.model.TMaterialVersionPeriodSubjectRel;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author wy
 * @description 教材版本-学段-科目关联Mapper
 * @date 2020/9/14
 */
@Mapper
public interface MaterialVersionPeriodSubjectRelMapper extends BaseMapper<TMaterialVersionPeriodSubjectRel> {


}
