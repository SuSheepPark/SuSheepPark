package com.ruida.assessment.assessmentcommon.enums;

public enum ClassCheckEnum {

    NO(0,"没有待审核的班级"),
    YES(1,"有待审核的班级"),
    ;

    private Integer K;
    private String V;

    ClassCheckEnum(Integer k, String v) {
        K = k;
        V = v;
    }

    public Integer getK() {
        return K;
    }

    public void setK(Integer k) {
        K = k;
    }

    public String getV() {
        return V;
    }

    public void setV(String v) {
        V = v;
    }

    public static DeleteStatusEnum getValueById(Integer K){
        for(DeleteStatusEnum deleteStatusEnum : DeleteStatusEnum.values() ){
            if(deleteStatusEnum.getK().equals(K)){
                return  deleteStatusEnum;
            }
        }
        return null;
    }
}
