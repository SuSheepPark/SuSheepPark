package com.ruida.assessment.assessmentquestionbank.controller;

import com.ruida.assessment.assessmentcommon.result.ListResult;
import com.ruida.assessment.assessmentquestionbank.service.StageService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * @description: 年级控制层
 * @author: kgz
 * @date: 2020/6/29
 */
@RequestMapping("/stage")
@RestController
@Api(value ="年级接口")
public class StageController {
    @Resource
    private StageService stageService;

    @GetMapping(value = {"/getList/{type}", "/getList"})
    @ApiOperation(value = "获取年级下拉框列表", notes = "获取年级下拉框列表")
    public ListResult getList(@PathVariable(required = false) Integer type){
        ListResult listResult = new ListResult();
        listResult.setContent(stageService.getStageList(type));
        return listResult;
    }
    @GetMapping(value = {"/getListByPeriod", "/getListByPeriod"})
    @ApiOperation(value = "根据学段获取年级下拉框列表", notes = "根据学段获取年级下拉框列表")
    public ListResult getListByPeriod(Integer periodId, Integer type){
        ListResult listResult = new ListResult();
        listResult.setContent(stageService.getStageListByPeriod(periodId,type));
        return listResult;
    }
}
