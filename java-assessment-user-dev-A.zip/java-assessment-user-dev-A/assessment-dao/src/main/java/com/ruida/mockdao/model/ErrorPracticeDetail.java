package com.ruida.mockdao.model;

import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 错题练习记录明细表
 * </p>
 *
 * @author chenjy
 * @since 2020-10-20
 */
@TableName("t_error_practice_detail")
public class ErrorPracticeDetail extends Model<ErrorPracticeDetail> {

    private static final long serialVersionUID = 1L;

    /**
     * 错题练习记录明细id
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;
    /**
     * 记录id
     */
    @TableField("record_id")
    private Integer recordId;
    /**
     * 试题id
     */
    @TableField("question_id")
    private String questionId;
    /**
     * 父级试题id
     */
    private String pid;
    /**
     * 试题类型id
     */
    @TableField("question_type_id")
    private Integer questionTypeId;
    /**
     * 科目id
     */
    @TableField("subject_id")
    private Integer subjectId;
    /**
     * 图片id，多个用逗号隔开
     */
    @TableField("image_id")
    private String imageId;
    /**
     * 用户答案
     */
    private String answer;
    /**
     * 音频试题播放次数
     */
    @TableField("audio_play_count")
    private Integer audioPlayCount;
    /**
     * 状态（1-答对；2-答错；3-半对半错；4-未批）
     */
    private Integer status;
    /**
     * 创建人
     */
    @TableField("create_by")
    private Integer createBy;
    /**
     * 创建时间
     */
    @TableField("create_time")
    private Date createTime;
    /**
     * 修改人
     */
    @TableField("update_by")
    private Integer updateBy;
    /**
     * 修改时间
     */
    @TableField("update_time")
    private Date updateTime;
    /**
     * 删除标志
     */
    private Integer isdelete;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getRecordId() {
        return recordId;
    }

    public void setRecordId(Integer recordId) {
        this.recordId = recordId;
    }

    public String getQuestionId() {
        return questionId;
    }

    public void setQuestionId(String questionId) {
        this.questionId = questionId;
    }

    public String getPid() {
        return pid;
    }

    public void setPid(String pid) {
        this.pid = pid;
    }

    public Integer getQuestionTypeId() {
        return questionTypeId;
    }

    public void setQuestionTypeId(Integer questionTypeId) {
        this.questionTypeId = questionTypeId;
    }

    public Integer getSubjectId() {
        return subjectId;
    }

    public void setSubjectId(Integer subjectId) {
        this.subjectId = subjectId;
    }

    public String getImageId() {
        return imageId;
    }

    public void setImageId(String imageId) {
        this.imageId = imageId;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public Integer getAudioPlayCount() {
        return audioPlayCount;
    }

    public void setAudioPlayCount(Integer audioPlayCount) {
        this.audioPlayCount = audioPlayCount;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getCreateBy() {
        return createBy;
    }

    public void setCreateBy(Integer createBy) {
        this.createBy = createBy;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(Integer updateBy) {
        this.updateBy = updateBy;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getIsdelete() {
        return isdelete;
    }

    public void setIsdelete(Integer isdelete) {
        this.isdelete = isdelete;
    }

    @Override
    protected Serializable pkVal() {
        return this.id;
    }

    @Override
    public String toString() {
        return "ErrorPracticeDetail{" +
        ", id=" + id +
        ", recordId=" + recordId +
        ", questionId=" + questionId +
        ", pid=" + pid +
        ", questionTypeId=" + questionTypeId +
        ", subjectId=" + subjectId +
        ", imageId=" + imageId +
        ", answer=" + answer +
        ", audioPlayCount=" + audioPlayCount +
        ", status=" + status +
        ", createBy=" + createBy +
        ", createTime=" + createTime +
        ", updateBy=" + updateBy +
        ", updateTime=" + updateTime +
        ", isdelete=" + isdelete +
        "}";
    }
}
