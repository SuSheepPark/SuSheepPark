package com.ruida.assessment.assessmentcommon.enums;

/**
 * @description: 消息模板操作类型枚举
 * @author: kgz
 * @date: 2020/7/23
 */
public enum MsgTemplateOperationEnum {
    ACTIVE(1,"启用"),
    FORBIDDEN(2,"禁用"),
    DELETE(3,"删除"),
    ;


    private Integer K;
    private String V;

    MsgTemplateOperationEnum(Integer k, String v) {
        K = k;
        V = v;
    }

    public Integer getK() {
        return K;
    }

    public void setK(Integer k) {
        K = k;
    }

    public String getV() {
        return V;
    }

    public void setV(String v) {
        V = v;
    }


    public static MsgTemplateOperationEnum getValueById(Integer K){
        for(MsgTemplateOperationEnum msgTemplateOperationEnum : MsgTemplateOperationEnum.values() ){
            if(msgTemplateOperationEnum.getK().equals(K)){
                return  msgTemplateOperationEnum;
            }
        }
        return null;
    }
}
