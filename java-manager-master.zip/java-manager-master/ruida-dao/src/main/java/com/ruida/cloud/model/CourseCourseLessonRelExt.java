package com.ruida.cloud.model;

import java.io.Serializable;

public class CourseCourseLessonRelExt implements Serializable {
    private Integer id;

    private Integer courseId;

    private Integer courseLessonId;

    private Integer broadcastRoomId;

    private static final long serialVersionUID = 1L;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getCourseId() {
        return courseId;
    }

    public void setCourseId(Integer courseId) {
        this.courseId = courseId;
    }

    public Integer getCourseLessonId() {
        return courseLessonId;
    }

    public void setCourseLessonId(Integer courseLessonId) {
        this.courseLessonId = courseLessonId;
    }



    public Integer getBroadcastRoomId() {
        return broadcastRoomId;
    }

    public void setBroadcastRoomId(Integer broadcastRoomId) {
        this.broadcastRoomId = broadcastRoomId;
    }

    @Override
    public String toString() {
        return "CourseCourseLessonRelExt{" +
                "id=" + id +
                ", courseId=" + courseId +
                ", courseLessonId=" + courseLessonId +
                ", broadcastRoomId=" + broadcastRoomId +
                '}';
    }
}