package com.ruida.assessment.assessmentquestionbank.service;

import java.util.List;
import java.util.Map;

import com.ruida.assessment.assessmentquestionbank.dto.ReportDTO;
import com.ruida.assessment.assessmentquestionbank.vo.ClassReportVO;
import com.ruida.assessment.assessmentquestionbank.vo.QuestionScoreVO;

/**
 * @description: 班级测试报告 业务层接口
 * @author: 
 * @date: 
 */
public interface MiddleSchoolClassReportService {

    /**
     * 查询本校班级考试得分整体情况
     * @param reportDTO
     * @return
     */
    List<ClassReportVO> getClassScoreInfo(ReportDTO reportDTO);

	List<QuestionScoreVO> getQuestionScoreInfo(ReportDTO reportDTO, Map<String, Object> cache);

	void setQuestionAvgScore(ReportDTO reportDTO, List<QuestionScoreVO> list, Map<String, Object> cache);

}
