package com.ruida.mockcommon.enums;

import lombok.Getter;

/**
 * @description 选科方案报告类型
 * @author chenjy
 * @since 2021/2/25 9:47
 */
@Getter
public enum SchemaReportTypeEnum {
    /**
     * 推荐类型
     */
    RECOMMEND(1,"推荐"),

    /**
     * 自选类型
     */
    CUSTOM(2,"自选");

    private final int id;

    private final String name;

    SchemaReportTypeEnum(int id, String name) {
        this.id = id;
        this.name = name;
    }
}
