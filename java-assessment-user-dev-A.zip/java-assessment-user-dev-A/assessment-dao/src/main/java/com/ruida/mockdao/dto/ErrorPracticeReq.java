package com.ruida.mockdao.dto;

import lombok.Data;

/**
 * @description:
 * @author: chenjy
 * @create: 2020-10-16 10:06
 */
@Data
public class ErrorPracticeReq {

    private Integer type;

    private Integer periodId;

    private Integer subjectTypeId;

    private String amount;

    private String knowledgeIds;
}
