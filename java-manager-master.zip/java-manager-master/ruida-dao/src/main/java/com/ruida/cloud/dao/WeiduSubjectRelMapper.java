package com.ruida.cloud.dao;

import com.ruida.cloud.model.WeiduSubjectRel;
import com.ruida.cloud.model.WeiduSubjectRelExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface WeiduSubjectRelMapper {
    long countByExample(WeiduSubjectRelExample example);

    int deleteByExample(WeiduSubjectRelExample example);

    int deleteByPrimaryKey(Integer rid);

    int insert(WeiduSubjectRel record);

    int insertSelective(WeiduSubjectRel record);

    List<WeiduSubjectRel> selectByExample(WeiduSubjectRelExample example);

    WeiduSubjectRel selectByPrimaryKey(Integer rid);

    int updateByExampleSelective(@Param("record") WeiduSubjectRel record, @Param("example") WeiduSubjectRelExample example);

    int updateByExample(@Param("record") WeiduSubjectRel record, @Param("example") WeiduSubjectRelExample example);

    int updateByPrimaryKeySelective(WeiduSubjectRel record);

    int updateByPrimaryKey(WeiduSubjectRel record);
}