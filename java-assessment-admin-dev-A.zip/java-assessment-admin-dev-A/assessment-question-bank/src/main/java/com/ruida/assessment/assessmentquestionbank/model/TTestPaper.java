package com.ruida.assessment.assessmentquestionbank.model;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;

import java.io.Serializable;

/**
 * @description: 试卷数据库实体
 * @author: kgz
 * @date: 2020/6/29
 */
@TableName("t_test_paper")
public class TTestPaper extends BaseColumn implements Serializable {
    private static final long serialVersionUID = -7490646944691517013L;
    /**
     * 试卷id
     */
    @TableId
    private Integer testPaperId;

    /**
     * 试卷名称
     */
    private String testPaperName;

    /**
     * 试卷分数
     */
    private Double score;

    /**
     * 学段id
     */
    private Integer periodId;


    /**
     * 年级id
     */
    private Integer stageId;

    /**
     * 科目id
     */
    private Integer subjectId;

    /**
     * 教材版本id
     */
    private Integer materialVersionId;

    /**
     * 年份
     */
    private Integer year;

    /**
     * 省份id
     */
    private Integer provinceId;

    /**
     * 考试类型
     */
    private Integer testTypeId;

    /**
     * 试卷类型
     */
    private Integer testPaperTypeId;

    /**
     * 试卷难度
     */
    private Integer difficultyId;

    /**
     * 测试时常
     * 单位分钟
     */
    private Integer testDruation;

    /**
     * 试卷号
     * 自动生成
     */
    private String testPaperNo;

    /**
     * 试卷状态（1.草稿2.待审核3.已发布4.已取消发布）
     */
    private Integer status;
    /**
     * 试题用途id
     */
    private Integer questionPurposeId;
    /**
     * 退回原因
     */
    private String rejectReason;

    private Integer dataImportType;

    /**
     * 试卷性质(1-练习卷 2-高中联考卷1分1赋 3-高中联考卷3分1赋 4-高中联考卷必考科目 5-初中联考卷)"
     */
    private Integer paperUseType;
    /**
     * 试卷上传阿里云oss的路径
     */
    private  String testPaperPath;
    /**
     * 试卷文件原始名称
     */
    private  String originalFileName;

    /**
     * 答题方式(1-在线答题 2-纸面答题)
     */
    private Integer answerWay;

    public Integer getTestPaperId() {
        return testPaperId;
    }

    public void setTestPaperId(Integer testPaperId) {
        this.testPaperId = testPaperId;
    }

    public String getTestPaperName() {
        return testPaperName;
    }

    public void setTestPaperName(String testPaperName) {
        this.testPaperName = testPaperName;
    }

    public Integer getStageId() {
        return stageId;
    }

    public void setStageId(Integer stageId) {
        this.stageId = stageId;
    }

    public Integer getSubjectId() {
        return subjectId;
    }

    public void setSubjectId(Integer subjectId) {
        this.subjectId = subjectId;
    }

    public Integer getMaterialVersionId() {
        return materialVersionId;
    }

    public void setMaterialVersionId(Integer materialVersionId) {
        this.materialVersionId = materialVersionId;
    }

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    public Integer getProvinceId() {
        return provinceId;
    }

    public void setProvinceId(Integer provinceId) {
        this.provinceId = provinceId;
    }

    public Integer getTestTypeId() {
        return testTypeId;
    }

    public void setTestTypeId(Integer testTypeId) {
        this.testTypeId = testTypeId;
    }

    public Integer getTestPaperTypeId() {
        return testPaperTypeId;
    }

    public void setTestPaperTypeId(Integer testPaperTypeId) {
        this.testPaperTypeId = testPaperTypeId;
    }

    public Integer getDifficultyId() {
        return difficultyId;
    }

    public void setDifficultyId(Integer difficultyId) {
        this.difficultyId = difficultyId;
    }

    public Integer getTestDruation() {
        return testDruation;
    }

    public void setTestDruation(Integer testDruation) {
        this.testDruation = testDruation;
    }

    public String getTestPaperNo() {
        return testPaperNo;
    }

    public void setTestPaperNo(String testPaperNo) {
        this.testPaperNo = testPaperNo;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getRejectReason() {
        return rejectReason;
    }

    public void setRejectReason(String rejectReason) {
        this.rejectReason = rejectReason;
    }

    public Integer getPeriodId() {
        return periodId;
    }

    public void setPeriodId(Integer periodId) {
        this.periodId = periodId;
    }

    public Double getScore() {
        return score;
    }

    public void setScore(Double score) {
        this.score = score;
    }

    public Integer getQuestionPurposeId() {
        return questionPurposeId;
    }

    public void setQuestionPurposeId(Integer questionPurposeId) {
        this.questionPurposeId = questionPurposeId;
    }

    public Integer getDataImportType() {
        return dataImportType;
    }

    public void setDataImportType(Integer dataImportType) {
        this.dataImportType = dataImportType;
    }

    public Integer getPaperUseType() {
        return paperUseType;
    }

    public void setPaperUseType(Integer paperUseType) {
        this.paperUseType = paperUseType;
    }

    public Integer getAnswerWay() {
        return answerWay;
    }

    public void setAnswerWay(Integer answerWay) {
        this.answerWay = answerWay;
    }

    public String getTestPaperPath() {
        return testPaperPath;
    }

    public void setTestPaperPath(String testPaperPath) {
        this.testPaperPath = testPaperPath;
    }

    public String getOriginalFileName() {
        return originalFileName;
    }

    public void setOriginalFileName(String originalFileName) {
        this.originalFileName = originalFileName;
    }

    @Override
    public String toString() {
        return "TTestPaper{" +
                "testPaperId=" + testPaperId +
                ", testPaperName='" + testPaperName + '\'' +
                ", score=" + score +
                ", periodId=" + periodId +
                ", stageId=" + stageId +
                ", subjectId=" + subjectId +
                ", materialVersionId=" + materialVersionId +
                ", year=" + year +
                ", provinceId=" + provinceId +
                ", testTypeId=" + testTypeId +
                ", testPaperTypeId=" + testPaperTypeId +
                ", difficultyId=" + difficultyId +
                ", testDruation=" + testDruation +
                ", testPaperNo='" + testPaperNo + '\'' +
                ", status=" + status +
                ", questionPurposeId=" + questionPurposeId +
                ", rejectReason='" + rejectReason + '\'' +
                ", dataImportType=" + dataImportType +
                ", paperUseType=" + paperUseType +
                ", answerWay=" + answerWay +
                '}';
    }
}
