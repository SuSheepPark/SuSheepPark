package com.ruida.cloud.model;

import java.io.Serializable;

public class CourseCampusRel implements Serializable {
    private Integer courseCampusId;

    private Integer courseId;

    private Integer campusId;

    private Integer campusOnlineStuNum;

    private static final long serialVersionUID = 1L;

    public Integer getCourseCampusId() {
        return courseCampusId;
    }

    public void setCourseCampusId(Integer courseCampusId) {
        this.courseCampusId = courseCampusId;
    }

    public Integer getCourseId() {
        return courseId;
    }

    public void setCourseId(Integer courseId) {
        this.courseId = courseId;
    }

    public Integer getCampusId() {
        return campusId;
    }

    public void setCampusId(Integer campusId) {
        this.campusId = campusId;
    }

    public Integer getCampusOnlineStuNum() {
        return campusOnlineStuNum;
    }

    public void setCampusOnlineStuNum(Integer campusOnlineStuNum) {
        this.campusOnlineStuNum = campusOnlineStuNum;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", courseCampusId=").append(courseCampusId);
        sb.append(", courseId=").append(courseId);
        sb.append(", campusId=").append(campusId);
        sb.append(", campusOnlineStuNum=").append(campusOnlineStuNum);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}