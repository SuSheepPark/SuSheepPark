package com.ruida.assessment.assessmentquestionbank.dto;

import com.ruida.assessment.assessmentquestionbank.model.TUserPeriodSubject;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class UserRoleDeadTimeDTO implements Serializable {
    private String deadline;
    private String roleId;
    private List<TUserPeriodSubject> userPeriodSubjects;
}
