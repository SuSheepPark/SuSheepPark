package com.ruida.mockdao.model;

import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * <p>
 * IOS学币记录表
 * </p>
 *
 * @author Bhj
 * @since 2020-07-29
 */
@TableName("t_study_coin_record")
public class StudyCoinRecord extends Model<StudyCoinRecord> {

    private static final long serialVersionUID = 1L;

    /**
     * 学币主键ID
     */
    @TableId(value = "study_coin_record_id", type = IdType.AUTO)
    private Integer studyCoinRecordId;
    /**
     * 用户ID
     */
    @TableField("user_id")
    private Integer userId;
    /**
     * 操作类型（0—加币；1—减币）
     */
    @TableField("operation_type")
    private Integer operationType;
    /**
     * 操作关联的订单ID
     */
    @TableField("order_id")
    private Integer orderId;
    /**
     * 学币数量
     */
    @TableField("study_coin_num")
    private BigDecimal studyCoinNum;
    /**
     * 备注
     */
    private String remark;
    /**
     * 是否是沙盒环境（0-否；1-是）
     */
    @TableField("is_sandbox")
    private Integer isSandbox;
    /**
     * 创建者ID
     */
    @TableField("create_by")
    private Integer createBy;
    /**
     * 创建时间
     */
    @TableField("create_time")
    private Date createTime;
    /**
     * 更新者ID
     */
    @TableField("update_by")
    private Integer updateBy;
    /**
     * 更新时间
     */
    @TableField("update_time")
    private Date updateTime;
    /**
     * 是否删除（0：未删除；1：删除）
     */
    private Integer isdelete;


    public Integer getStudyCoinRecordId() {
        return studyCoinRecordId;
    }

    public void setStudyCoinRecordId(Integer studyCoinRecordId) {
        this.studyCoinRecordId = studyCoinRecordId;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Integer getOperationType() {
        return operationType;
    }

    public void setOperationType(Integer operationType) {
        this.operationType = operationType;
    }

    public Integer getOrderId() {
        return orderId;
    }

    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    public BigDecimal getStudyCoinNum() {
        return studyCoinNum;
    }

    public void setStudyCoinNum(BigDecimal studyCoinNum) {
        this.studyCoinNum = studyCoinNum;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public Integer getCreateBy() {
        return createBy;
    }

    public void setCreateBy(Integer createBy) {
        this.createBy = createBy;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(Integer updateBy) {
        this.updateBy = updateBy;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getIsdelete() {
        return isdelete;
    }

    public void setIsdelete(Integer isdelete) {
        this.isdelete = isdelete;
    }

    public Integer getIsSandbox() { return isSandbox; }

    public void setIsSandbox(Integer isSandbox) { this.isSandbox = isSandbox; }

    @Override
    protected Serializable pkVal() {
        return this.studyCoinRecordId;
    }

    @Override
    public String toString() {
        return "StudyCoinRecord{" +
        ", studyCoinRecordId=" + studyCoinRecordId +
        ", userId=" + userId +
        ", operationType=" + operationType +
        ", orderId=" + orderId +
        ", studyCoinNum=" + studyCoinNum +
        ", remark=" + remark +
        ", isSandbox=" + isSandbox +
        ", createBy=" + createBy +
        ", createTime=" + createTime +
        ", updateBy=" + updateBy +
        ", updateTime=" + updateTime +
        ", isdelete=" + isdelete +
        "}";
    }
}
