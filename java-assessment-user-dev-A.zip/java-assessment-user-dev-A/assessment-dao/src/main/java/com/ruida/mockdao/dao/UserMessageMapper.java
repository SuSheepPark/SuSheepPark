package com.ruida.mockdao.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.model.UserMessage;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Update;

/**
 * <p>
 * 用户消息表 Mapper 接口
 * </p>
 *
 * @author Bhj
 * @since 2020-07-09
 */
public interface UserMessageMapper extends BaseMapper<UserMessage> {
      @Update(" update  t_user_message  set  isread = 1  where isread = 0 and user_id = #{userId} ")
      Integer readAllNews(@Param("userId") String userId);
}
