package com.ruida.common.enums;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * @author Bhj
 * @description: ${TODO}
 * @Date 2020/6/4
 * @verion 1.0
 */
public enum CouponSendTipsEnum {
    //优惠券发放时提醒类型
    SENDSUCCESS(0,"优惠券发放成功"), NOCOUPON(1,"优惠券数量不足"), HAVECOUPON(2,"有用户重复领取优惠券");
    private Integer k;
    private String v;

    CouponSendTipsEnum(Integer k, String v) {
        this.k = k;
        this.v = v;
    }

    public static Map<Integer, String> map = new LinkedHashMap<>(2);

    static {
        for (CouponSendTipsEnum type : CouponSendTipsEnum.values()) {
            map.put(type.getK(), type.getV());
        }
    }

    /***
     * 获取角色类型
     * @return
     */
    public static String getValueForK(Integer k) {
        CouponSendTipsEnum[] ary = CouponSendTipsEnum.values();
        for (CouponSendTipsEnum couponSendTipsEnum : ary) {
            if (couponSendTipsEnum.k == k) {
                return couponSendTipsEnum.v;
            }
        }
        return "";
    }

    public Integer getK() {
        return k;
    }

    public void setK(Integer k) {
        this.k = k;
    }

    public String getV() {
        return v;
    }

    public void setV(String v) {
        this.v = v;
    }
}
