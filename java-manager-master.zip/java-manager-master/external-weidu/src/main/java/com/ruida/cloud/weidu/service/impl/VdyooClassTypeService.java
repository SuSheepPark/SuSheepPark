package com.ruida.cloud.weidu.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.ruida.cloud.dao.WeiduClassTypeRelMapper;
import com.ruida.cloud.model.WeiduClassTypeRel;
import com.ruida.cloud.weidu.config.WeiduConfig;
import com.ruida.cloud.weidu.service.BaseVdyooService;
import com.ruida.cloud.weidu.utils.PropertyUtil;
import com.ruida.cloud.weidu.vo.VdyooEntity;
import com.ruida.common.context.BaseContextHandle;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author taosh
 * @create 2019-04-23 16:44
 */
@Service
public class VdyooClassTypeService extends BaseVdyooService {
    private String vdyooPath = PropertyUtil.getProperty("vdyooTestApi");

    @Resource
    private WeiduClassTypeRelMapper weiduClassTypeRelMapper;

    /**
     * 创建班型（奥数班 火箭班）
     */
    public boolean addTenantClassType(Map<String, Object> param) {
        VdyooEntity vdyooEntity = this.vdyooFactory.post(param, WeiduConfig.addTenantClassType);
        boolean flag = false;
        if (vdyooEntity.getSuccess()) {
            WeiduClassTypeRel classTypeRel = new WeiduClassTypeRel();
            classTypeRel.setClassTypeId((Integer) param.get("pid"));
            JSONObject object = (JSONObject) JSON.toJSON(vdyooEntity.getPayload());
            classTypeRel.setWeiduClassTypeId(object.getInteger("id"));
            classTypeRel.setCreateBy(BaseContextHandle.getUserId());
            classTypeRel.setUpdateBy(BaseContextHandle.getUserId());
            classTypeRel.setIsdelete((byte) 0);
            classTypeRel.setCreateTime(new Date());
            classTypeRel.setUpdateTime(new Date());
            flag = weiduClassTypeRelMapper.insert(classTypeRel) > 0;
        }
        return flag;
    }

    /**
     * 编辑班型
     */
    public boolean editTenantClassTypeById(Map<String, Object> param) {

        return this.vdyooFactory.post(param, WeiduConfig.editTenantClassTypeById).getSuccess();
    }

    /**
     * 查看班型的信息
     */

    public boolean findClassTypeById(String id) {
        Map<String, Object> param = new HashMap<>(2);
        //威渡id
        param.put("id", id);
        return this.vdyooFactory.post(param, WeiduConfig.findClassTypeById).getSuccess();
    }

    /**
     * 查看班型的信息
     */
    public VdyooEntity findClassTypeByTenant() {
        return this.vdyooFactory.post(WeiduConfig.findClassTypeByTenant);
    }
}
