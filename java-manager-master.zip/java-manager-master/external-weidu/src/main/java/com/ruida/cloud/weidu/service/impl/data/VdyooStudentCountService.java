package com.ruida.cloud.weidu.service.impl.data;

import com.ruida.cloud.weidu.config.WeiduConfig;
import com.ruida.cloud.weidu.service.BaseVdyooService;
import com.ruida.cloud.weidu.utils.PropertyUtil;
import com.ruida.cloud.weidu.utils.VdyooUtil;
import com.ruida.cloud.weidu.vo.VdyooEntity;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

/**
 * @author taosh
 * @create 2019-04-24 10:05
 */
@Service
public class VdyooStudentCountService extends BaseVdyooService {
    private String vdyooPath = PropertyUtil.getProperty("vdyooTestApi");

    /**
     * 获取学生全部答题数据通过学生的ID来查询学生的答题情况
     */
    public final static String findStudentCountById="/api/business/studentcount/findStudentCountById";
    public VdyooEntity findStudentCountById(Integer studentId){
        String path = vdyooPath+"/api/business/studentcount/findStudentCountById";

        Map<String, Object> param = new HashMap<>(1);

        //学生ID
        param.put("studentId", studentId);

//        String response = HttpClientUtil.postMap(path, param);
//        System.out.println(response);
        return this.vdyooFactory.post(param, WeiduConfig.findStudentCountById);
    }

    /**
     * 通过学生和试题类型 查出该学生的试题类型的答题情况
     */
    public final static String findStudentCountByIdByExamType="/api/business/studentcount/findStudentCountByIdByExamType";
    public VdyooEntity findStudentCountByIdByExamType(Map<String, Object> param){
        String path = vdyooPath+"/api/business/studentcount/findStudentCountByIdByExamType";

//        Map<String, String> param = VdyooUtil.getSignMap();

//        //学生ID
//        param.put("studentId", studentId);
//        //题型, 选择题：”choice”,多选题:”mutichoice”,填空题:”completion”,选错题:”choosewrong”,带分数填空题:”fraction”
//        param.put("examType", examType);

//        String response = HttpClientUtil.postMap(path, param);
//        System.out.println(response);
        return this.vdyooFactory.post(param, WeiduConfig.findStudentCountByIdByExamType);
    }

    /**
     * 通过学生 课表 查出学生在教学计划答题情况
     */
    public final static String findStudentCountByIdBySchedule="/api/business/studentcount/findStudentCountByIdBySchedule";
    public VdyooEntity findStudentCountByIdBySchedule(Map<String, Object> param){
//        String path = vdyooPath+"/api/business/studentcount/findStudentCountByIdBySchedule";
//
//        Map<String, String> param = VdyooUtil.getSignMap();
//
//        //学生ID
//        param.put("studentId", studentId);
//        //课表Id
//        param.put("scheduleId", scheduleId);

//        String response = HttpClientUtil.postMap(path, param);
//        System.out.println(response);
        return this.vdyooFactory.post(param, WeiduConfig.findStudentCountByIdBySchedule);
    }


//    /**
//     * 通过学生 课表 试题类型 查出学生在课表中的试题类型答题情况
//     */
//    public final static String findStudentCountByIdByExamType="/api/business/studentcount/findStudentCountByIdByExamType";
//    public void findStudentCountByIdByExamType(String studentId, String scheduleId, String examType){
//        String path = vdyooPath+"/api/business/studentcount/findStudentCountByIdByExamType";
//
//        Map<String, String> param = VdyooUtil.getSignMap();
//
//        //学生ID
//        param.put("studentId", studentId);
//        //课表Id
//        param.put("scheduleId", scheduleId);
//        //题型, 选择题：”choice”,多选题:”mutichoice”,填空题:”completion”,选错题:”choosewrong”,带分数填空题:”fraction”
//        param.put("examType", examType);
//
////        String response = HttpClientUtil.postMap(path, param);
////        System.out.println(response);
//    }
}
