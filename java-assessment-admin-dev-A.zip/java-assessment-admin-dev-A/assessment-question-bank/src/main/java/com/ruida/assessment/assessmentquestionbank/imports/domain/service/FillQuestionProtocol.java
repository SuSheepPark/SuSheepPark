package com.ruida.assessment.assessmentquestionbank.imports.domain.service;

import org.apache.commons.lang3.StringUtils;

import com.ruida.assessment.assessmentquestionbank.imports.docx.DocxReader;
import com.ruida.assessment.assessmentquestionbank.imports.domain.model.ErrorMsgException;
import com.ruida.assessment.assessmentquestionbank.imports.domain.model.QuestionAnswer;
import com.ruida.assessment.assessmentquestionbank.imports.domain.model.QuestionBaseConfig;
import com.ruida.assessment.assessmentquestionbank.imports.domain.model.QuestionBlock;
import com.ruida.assessment.assessmentquestionbank.imports.domain.model.QuestionContent;
import com.ruida.assessment.assessmentquestionbank.imports.domain.model.QuestionExplain;
import com.ruida.assessment.assessmentquestionbank.imports.domain.model.QuestionKnowledge;
import com.ruida.assessment.assessmentquestionbank.imports.domain.model.QuestionRemark;

public class FillQuestionProtocol extends QuestionProtocol {

	public FillQuestionProtocol(DocxReader reader) {
		super(reader);
	}

	@Override
	public Boolean checkIdentification() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected QuestionContent getContent() {
		QuestionContent content = new QuestionContent();
		content.setContent(getContentString());
		return content;
	}

	@Override
	protected String formatAnswerItem(String lineString) {
		return lineString;
	}

	@Override
	public QuestionBlock parseBlock(QuestionBaseConfig config) throws ErrorMsgException {
		reader.stepTo(CONTENT_START, QUESTION_START);
		QuestionBlock block = new QuestionBlock();

		QuestionContent content = getContent();
		block.setContent(content);

		QuestionAnswer answer = getAnswer(Protocol2ModelService.HUMANCORRECT.equals(config.getAutoCorrection()));
		if (answer.getAnswerItems() == null) {
			throw new ErrorMsgException(reader.getLineNum(), "未能读取到题目的答案，请检查格式");
		}
		if (StringUtils.isEmpty(answer.getAnswerType())) {
			if (answer.getAnswerItems().size() == 1) {
				answer.setAnswerType("完全一致");
			} else {
				throw new ErrorMsgException(reader.getLineNum(), "填空题需要指定答案设置，如‘仅顺序不一致’");
			}
		}
		block.setAnswer(answer);

		QuestionExplain explain = getExplain();
		block.setExplain(explain);
		QuestionRemark remark = getRemark();
		block.setRemark(remark);
		QuestionKnowledge knowledge = getKnowledge();
		block.setKnowledge(knowledge);
		return block;
	}
}
