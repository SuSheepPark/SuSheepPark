package com.ruida.assessment.assessmentquestionbank.imports.domain.model;

public class QuestionBaseConfig {

	private String questionType;
	private String uploadPhoto;
	private String autoCorrection;
	
	public String getUploadPhoto() {
		return uploadPhoto;
	}
	public void setUploadPhoto(String uploadPhoto) {
		this.uploadPhoto = uploadPhoto;
	}
	public String getAutoCorrection() {
		return autoCorrection;
	}
	public void setAutoCorrection(String autoCorrection) {
		this.autoCorrection = autoCorrection;
	}
	public String getQuestionType() {
		return questionType;
	}
	public void setQuestionType(String questionType) {
		this.questionType = questionType;
	}
}
