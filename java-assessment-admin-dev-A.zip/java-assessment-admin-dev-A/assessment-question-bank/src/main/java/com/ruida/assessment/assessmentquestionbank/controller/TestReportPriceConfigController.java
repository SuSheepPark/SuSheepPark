package com.ruida.assessment.assessmentquestionbank.controller;

import com.ruida.assessment.assessmentcommon.result.PojoResult;
import com.ruida.assessment.assessmentquestionbank.annotaion.UserAuth;
import com.ruida.assessment.assessmentquestionbank.dto.TestReportPriceConfigDTO;
import com.ruida.assessment.assessmentquestionbank.service.TestReportPriceConfigService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * @description: 测试、报告价格设置控制层
 * @author: kgz
 * @date: 2021/1/13
 */
@RequestMapping("/testReportPriceConfig")
@RestController
@Api(value ="试卷相关接口")
public class TestReportPriceConfigController {
    @Resource
    TestReportPriceConfigService testReportPriceConfigService;

    @UserAuth
    @GetMapping("/getDetail")
    @ApiOperation(value = "获取详情", notes = "获取详情")
    public PojoResult getDetail(){
        PojoResult pageResult = new PojoResult();
        pageResult.setContent(testReportPriceConfigService.getDetail());
        return pageResult;
    }

    @UserAuth
    @PostMapping("/save")
    @ApiOperation(value = "保存", notes = "保存")
    @ApiImplicitParam(name = "list", value = "保存信息",
            required = true , dataType  = "list",paramType = "body")
    public PojoResult save(@RequestBody List<TestReportPriceConfigDTO> list){
        return testReportPriceConfigService.save(list);
    }
}
