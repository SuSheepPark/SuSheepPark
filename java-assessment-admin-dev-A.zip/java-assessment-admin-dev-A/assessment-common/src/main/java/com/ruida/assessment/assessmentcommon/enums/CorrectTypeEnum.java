package com.ruida.assessment.assessmentcommon.enums;

/**
 * @description: 批改类型
 *
 * @author: kgz
 * @date: 2020/7/3
 */
public enum CorrectTypeEnum {
    MANUAL(0,"人工批改"),
    AUTOMATION(1,"自动批改"),
    ;

    private Integer K;
    private String V;

    CorrectTypeEnum(Integer k, String v) {
        K = k;
        V = v;
    }

    public Integer getK() {
        return K;
    }

    public void setK(Integer k) {
        K = k;
    }

    public String getV() {
        return V;
    }

    public void setV(String v) {
        V = v;
    }


    public static CorrectTypeEnum getValueById(Integer K){
        for(CorrectTypeEnum correctTypeEnum : CorrectTypeEnum.values() ){
            if(correctTypeEnum.getK().equals(K)){
                return  correctTypeEnum;
            }
        }
        return null;
    }

}
