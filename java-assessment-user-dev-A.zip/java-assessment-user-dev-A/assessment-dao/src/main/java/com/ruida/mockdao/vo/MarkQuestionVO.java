package com.ruida.mockdao.vo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.ruida.mockdao.pojo.Choice;
import lombok.Data;
import java.util.List;

/**
 * @description: 标记试题列表返回VO
 * @author: chenjy
 * @create: 2020-07-10 10:26
 */
@Data
@JsonIgnoreProperties({"stem"})
public class MarkQuestionVO {

    /**
     * 标记试题id
     */
    private Integer id;

    /**
     * 试卷id
     */
    private Integer testPaperId;

    /**
     * 试题id
     */
    private String questionId;

    /**
     * 题干
     */
    private String questionTitle;

    /**
     * 题型id
     */
    private Integer questionTypeId;

    /**
     * 试题名称
     */
    private String questionTypeName;

    /**
     * 分值
     */
    private Double score;

    /**
     * 选项 string类型
     */
    private String stem;

    /**
     * 选项 集合类型
     */
    private List<Choice> option;

    /**
     * 子题
     */
    private List<MarkQuestionVO> child;

}
