package com.ruida.mockdao.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.model.TInformationColumn;

/**
 * <p>
 * 首页资讯栏目表 Mapper 接口
 * </p>
 *
 * @author wy
 * @since 2021-08-16
 */
public interface TInformationColumnMapper extends BaseMapper<TInformationColumn> {

}
