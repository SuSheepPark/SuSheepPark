package com.ruida.cloud.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ruida.common.SystemConstant;
import com.ruida.common.util.excel.ExcelAnnotation;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@Data
public class CourseExt implements Serializable {
    private Integer courseId;

    @ExcelAnnotation(title = "课程名称")
    private String courseName;

    //授课方式
    private Byte teachingMethod;
    //学段
    private Integer periodId;
    //年级
    private Integer stageId;
    //学科
    private String subjectIds;
    //课程类型
    private Integer courseTypeId;
    //班级类型
    private Integer classTypeId;
    //辅课老师
    private String assistantTeacherId;
    //是否发布
    private Byte ispublish;

    private Byte isdelete;

    //表单提交的其他补充信息
    //封面路径
    private String coverPath;
    //是否公开
    private Byte ispublic;

    private String token;

    //教学班级
    private List<TeachingClassExt> teachingClassList;
    //权限学生信息（班级+辅课老师）
    private List<NonPublicInfo> nonPublicInfoList;
    //权限学生数据
    private List<CourseNonPublicUser> nonPublicUserList;
    //是否推荐
    private Byte ishot;
    //是否收费
    public Byte ischarge;
    //可否试看
    private Byte istryvideo;
    //课程有效期
    private Byte validTime;
    //课程介绍
    private String summary;

    private String summaryHtml;

    private Byte isshow;

    private Byte istest;

    //优惠额度
    private Byte sale;
    //优惠学生数据
    private List<CourseDiscountUser> discountUserList;

    //权限用户 班级添加(班级id)
    private Integer[] nonPublicClassIds;
    //权限用户 单独添加
    private Integer[] nonPublicUserIds;
    //折扣班级用户id
    private Integer[] discountClassUserIds;
    //折扣个人用户id
    private Integer[] discountSingleUserIds;
    //学科价格设置
    private List<CoursePrice> coursePriceList;

    //课包价格设置
    private CoursePrice packageCoursePrice;

    //学段
    @ExcelAnnotation(title = "学段")
    private String periodName;
    @ExcelAnnotation(title = "年级")
    private String stageName;
    @ExcelAnnotation(title = "学科")
    private String subjectName;
    //课程类型
    @ExcelAnnotation(title = "课程类型")
    private String courseTypeName;
    //课次数
    @ExcelAnnotation(title = "课次数")
    private Integer lessonCount;
    //主讲老师
    @ExcelAnnotation(title = "主讲老师")
    private String lecturerTeachers;
    //辅课老师
    @ExcelAnnotation(title = "辅课老师")
    private String assistantTeachers;
    @ExcelAnnotation(title = "校区")
    private String schoolName;
    //开课次间
    @ExcelAnnotation(title = "起止时间")
    private String startEndTime;
    //授课方式
    @ExcelAnnotation(title = "授课方式")
    private String teacherMenthodName;

    private BigDecimal price;

    @ExcelAnnotation(title = "双师/在线课程价格")
    private String coursePrice;

    //是否已备课
    private Byte isprepare;

    //新增字段
    //开始日期
    @JsonFormat(pattern = "yyyy-MM-dd",timezone= SystemConstant.TIME_ZONE)
    private Date startDate;
    //结束日期
    @JsonFormat(pattern = "yyyy-MM-dd",timezone= SystemConstant.TIME_ZONE)
    private Date endDate;
    private String endDateStr;
    private String startDateStr;

    //开始时间
    private String startTime;
    //结束时间
    private String endTime;
    //学期
    private String semesterId;
    //开课间隔天数
    private Integer intervalDays;
    //主讲老师id
    private Integer teacherId;
    //课程最大购买数量
    private Integer courseMaximum;
    //是否发布
    private Byte isprepublish;

    private Integer courseVideoId;

    //新增班主任ids
    private String classTeacherIds;

    //直播间id
    private Integer broadcastRoomId;

    //未排班
    private Integer freeNum;
    //已排班
    private Integer surplusNum;
    //课程校区关联表id
    private Integer courseBroadcastroomId;
    //教学班级表id
    private Integer teachingClassId;

    @ExcelAnnotation(title = "排班信息")
    private String scheduleNum;

    //班主任课程显示学生人数
    private String onlineStudents;

    /**
     * 是否为组合课
     */
    private Byte iscompose;

    /**
     * 子课程id
     */
    private String childCourseIds;

    private Byte segmentId;

    private Integer classLength;

    /**
     * 直播课类型 (0—大班课；1—分组课)
     */
    private Integer liveType;

    /**
     * 最大上台人数（百家云小班课）
     */
    private Integer maxUsers;

    /**
     * 课程分组数量
     */
    private Integer groupNum;

    /**
     * 台下学生数量限制，最大支持300，（直播小班课）
     */
    private Integer maxBackupUsers;

    /**
     * 台下学生是否自动上台； 0：不是，1：是（直播小班课，目前默认否）
     */
    private Integer autoOnStage;

    /* 更新时间 */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone= SystemConstant.TIME_ZONE)
    private Date updateTime;

    /**
     * 播放次数
     */
    private Integer watchNum;
}
