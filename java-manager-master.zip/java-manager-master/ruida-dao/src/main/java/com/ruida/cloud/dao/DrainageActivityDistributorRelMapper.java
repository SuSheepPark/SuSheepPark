package com.ruida.cloud.dao;

import com.ruida.cloud.model.DrainageActivityDistributorRel;
import com.ruida.cloud.model.DrainageActivityDistributorRelExample;
import com.ruida.cloud.model.PromotionActivityDistributorRel;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface DrainageActivityDistributorRelMapper {
    long countByExample(DrainageActivityDistributorRelExample example);

    int deleteByExample(DrainageActivityDistributorRelExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(DrainageActivityDistributorRel record);

    int insertSelective(DrainageActivityDistributorRel record);

    List<DrainageActivityDistributorRel> selectByExample(DrainageActivityDistributorRelExample example);

    DrainageActivityDistributorRel selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") DrainageActivityDistributorRel record, @Param("example") DrainageActivityDistributorRelExample example);

    int updateByExample(@Param("record") DrainageActivityDistributorRel record, @Param("example") DrainageActivityDistributorRelExample example);

    int updateByPrimaryKeySelective(DrainageActivityDistributorRel record);

    int updateByPrimaryKey(DrainageActivityDistributorRel record);

    /**
     * 批量插入数据
     */
    public int insertBatch(List<DrainageActivityDistributorRel> list);
}