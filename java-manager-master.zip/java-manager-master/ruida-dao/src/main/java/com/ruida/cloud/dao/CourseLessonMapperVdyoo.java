package com.ruida.cloud.dao;


import com.ruida.cloud.model.CourseLessonVdyoo;

import java.util.List;

public interface CourseLessonMapperVdyoo {
    List<CourseLessonVdyoo> listCourseLessonVdyoo(int courseId);
}