package com.ruida.cloud.model;

import com.ruida.common.util.excel.ExcelAnnotation;
import lombok.Data;

/**
 * @author admin
 * @description: ${TODO}
 * @Date 2019/7/19
 * @verion 1.0
 */
@Data
public class KnowledgeAddPOJO {
    @ExcelAnnotation(title = "父级知识点")
    private String pid;
    @ExcelAnnotation(title = "新增知识点")
    private String sub;
    @ExcelAnnotation(title = "上传结果")
    private String result;
    @ExcelAnnotation(title = "上传失败原因")
    private String reson;
}
