package com.ruida.mockdao.vo;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;


@Data
@ApiModel(value="目标分值统计")
public class TargetStatVO implements Serializable {

    @ApiModelProperty(value = "目标id")
    private Integer targetId;

    @ApiModelProperty(value = "目标名称")
    private String targetName;


    @ApiModelProperty(value = "满分")
    private Double fullScore;

    @ApiModelProperty(value = "得分")
    private Double realScore;

    @ApiModelProperty(value = "掌握率")
    private Double rateScore;

    @ApiModelProperty(value = "掌握率百分比")
    private String ratePercent;

}
