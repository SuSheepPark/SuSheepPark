package com.ruida.mockdao.vo;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * 首页商品列表
 */

@Data
@ApiModel(value = "首页商品列表")
//@JsonInclude(JsonInclude.Include.NON_NULL)
public class HomeProductVO {

    @ApiModelProperty(value = "热门商品")
    private List<ProductVO> hotProduct;


    @ApiModelProperty(value = "最新商品")
    private List<ProductVO> newProduct;
}
