package com.ruida.assessment.assessmentquestionbank.controller;

import com.ruida.assessment.assessmentcommon.result.ListResult;
import com.ruida.assessment.assessmentquestionbank.annotaion.UserAuth;
import com.ruida.assessment.assessmentquestionbank.service.PeriodService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * @description: 学段控制层
 * @author: kgz
 * @date: 2020/6/18
 */
@RequestMapping("/period")
@RestController
@Api(value ="学段相关接口")
public class PeriodController {

    @Resource
    private PeriodService periodService;

    @UserAuth
    @GetMapping(value = {"/getList/{all}", "/getList"})
    @ApiOperation(value = "根据学段下拉框列表", notes = "根据学段下拉框列表")
    public ListResult getList(@PathVariable(required = false) Integer all){
        ListResult listResult = new ListResult();
        listResult.setContent(periodService.getPeriodList(all));
        return listResult;
    }
}
