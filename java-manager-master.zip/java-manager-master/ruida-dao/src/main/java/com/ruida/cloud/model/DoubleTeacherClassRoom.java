package com.ruida.cloud.model;

import com.sun.javafx.binding.StringFormatter;
import lombok.Data;


@Data
public class DoubleTeacherClassRoom {

    /**
     * 双师教室（设备）id
     */
    private Integer device_id;

    /*
    设备唯一标志
     */
    private String device_unique;

    /*
    校区id
     */
    private Integer zone_id;

    /**
     * 身份（教室类型） 0:学生（听课教室） 1:老师（授课教室）
     */
    private Integer user_role;

    /*
    教室名称
     */
    private String class_name;

}