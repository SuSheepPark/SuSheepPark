package com.ruida.mockdao.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.model.TCandidates;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * 实施对象表 Mapper 接口
 * </p>
 *
 * @author szl
 * @since 2021-07-22
 */
public interface TCandidatesMapper extends BaseMapper<TCandidates> {
    /**
     * 获取场次
     * @param productId
     * @param testPaperId
     * @return
     */
    @Select("SELECT\n" +
            "\ta.scene_id,a.plan_id\n" +
            "FROM\n" +
            "\tt_scene a\n" +
            "LEFT JOIN t_implement_plan b ON a.plan_id = b.plan_id\n" +
            "LEFT  JOIN t_test_paper_product_rel c ON a.test_paper_id = c.test_paper_id  AND b.product_id = c.product_id\n" +
            "WHERE\n" +
            "\ta.test_paper_id = #{testPaperId} and\n" +
            " c.product_id = #{productId} and b.product_id = #{productId}\n" +
            "AND c.isdelete = 0\n" +
            "AND c.ispresell = 0\n" +
            "AND a.isdelete = 0\n" +
            "AND b.isdelete = 0")
    Map<String,String> getSceneByProductAndTestPaper(@Param("productId") Integer productId, @Param("testPaperId")Integer testPaperId);

    /**
     * 查询该用户在该实施计划已经绑定过的数据
     * @param planId
     * @param stuId
     * @return
     */
    List<TCandidates> isBondedStuNo(@Param("planId") String planId,@Param("stuId") Integer stuId);

}
