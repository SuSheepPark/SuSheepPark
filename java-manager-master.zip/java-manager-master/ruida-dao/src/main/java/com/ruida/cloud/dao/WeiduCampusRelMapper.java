package com.ruida.cloud.dao;

import com.ruida.cloud.model.WeiduCampusRel;
import com.ruida.cloud.model.WeiduCampusRelExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface WeiduCampusRelMapper {
    long countByExample(WeiduCampusRelExample example);

    int deleteByExample(WeiduCampusRelExample example);

    int deleteByPrimaryKey(Integer rid);

    int insert(WeiduCampusRel record);

    int insertSelective(WeiduCampusRel record);

    List<WeiduCampusRel> selectByExample(WeiduCampusRelExample example);

    WeiduCampusRel selectByPrimaryKey(Integer rid);

    int updateByExampleSelective(@Param("record") WeiduCampusRel record, @Param("example") WeiduCampusRelExample example);

    int updateByExample(@Param("record") WeiduCampusRel record, @Param("example") WeiduCampusRelExample example);

    int updateByPrimaryKeySelective(WeiduCampusRel record);

    int updateByPrimaryKey(WeiduCampusRel record);
}