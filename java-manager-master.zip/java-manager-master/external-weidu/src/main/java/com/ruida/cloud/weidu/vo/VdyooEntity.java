package com.ruida.cloud.weidu.vo;

import com.alibaba.fastjson.JSON;
import lombok.Data;

@Data
public class VdyooEntity {
    Boolean success;
    String  message;
    String  error;
    Object payload;
}
