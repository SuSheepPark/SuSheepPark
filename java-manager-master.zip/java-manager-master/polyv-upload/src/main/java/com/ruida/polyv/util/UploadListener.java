package com.ruida.polyv.util;

public interface UploadListener {
	public void fail(Exception ex);
	public void success(String body);
}
