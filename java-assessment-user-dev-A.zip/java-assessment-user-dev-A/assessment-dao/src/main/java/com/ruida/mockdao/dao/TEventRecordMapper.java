package com.ruida.mockdao.dao;

import com.ruida.mockdao.model.TEventRecord;
import com.baomidou.mybatisplus.mapper.BaseMapper;

/**
 * <p>
 * 事件点击记录 Mapper 接口
 * </p>
 *
 * @author szl
 * @since 2021-05-27
 */
public interface TEventRecordMapper extends BaseMapper<TEventRecord> {

}
