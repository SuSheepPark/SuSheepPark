package com.ruida.mockdao.model;

import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;

import java.io.Serializable;

/**
 * <p>
 * 班级与年级与学校关联表（班级、年级、学校）
 * </p>
 *
 * @author Bhj
 * @since 2020-07-21
 */
@TableName("t_class_grade_school_rel")
public class ClassGradeSchoolRel extends Model<ClassGradeSchoolRel> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键ID
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;
    /**
     * 班级ID
     */
    @TableField("class_id")
    private Integer classId;
    /**
     * 年级ID
     */
    @TableField("grade_id")
    private Integer gradeId;
    /**
     * 学校ID
     */
    @TableField("school_id")
    private Integer schoolId;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getClassId() {
        return classId;
    }

    public void setClassId(Integer classId) {
        this.classId = classId;
    }

    public Integer getGradeId() {
        return gradeId;
    }

    public void setGradeId(Integer gradeId) {
        this.gradeId = gradeId;
    }

    public Integer getSchoolId() {
        return schoolId;
    }

    public void setSchoolId(Integer schoolId) {
        this.schoolId = schoolId;
    }

    @Override
    protected Serializable pkVal() {
        return this.id;
    }

    @Override
    public String toString() {
        return "ClassStageSchoolRel{" +
        ", id=" + id +
        ", classId=" + classId +
        ", gradeId=" + gradeId +
        ", schoolId=" + schoolId +
        "}";
    }
}
