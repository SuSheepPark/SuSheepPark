package com.ruida.mockdao.model;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;

import java.io.Serializable;

/**
 * @description: 年级
 * @author: kgz
 * @date: 2020/6/29
 */
@TableName("t_stage")
public class TStage implements Serializable {
    private static final long serialVersionUID = 4013943955676254258L;

    /**
     * 年级id
     */
    @TableId
    private Integer id;

    /**
     * 年级名称
     */
    private String stageName;

    /**
     * 状态（0—禁用；1—启用）
     */
    private Integer status;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getStageName() {
        return stageName;
    }

    public void setStageName(String stageName) {
        this.stageName = stageName;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "TStage{" +
                "id=" + id +
                ", stageName='" + stageName + '\'' +
                ", status=" + status +
                super.toString() +
                '}';
    }
}
