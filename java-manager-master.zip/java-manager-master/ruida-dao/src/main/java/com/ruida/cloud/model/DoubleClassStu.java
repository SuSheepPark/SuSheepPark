package com.ruida.cloud.model;

import com.ruida.common.util.excel.ExcelAnnotation;
import lombok.Data;
/*
双师班级学生
 */
@Data
public class DoubleClassStu {
    @ExcelAnnotation(title = "校区")
    private String campusName;
    @ExcelAnnotation(title = "班级")
    private String className;
    @ExcelAnnotation(title = "学生数量")
    private String studentNum;
    @ExcelAnnotation(title = "学生姓名")
    private String studentName;
    @ExcelAnnotation(title = "学号")
    private String studentNo;


}
