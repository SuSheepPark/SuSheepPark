package com.ruida.mockdao.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.model.ConstPointsAssignForecast;

/**
 * <p>
 * 赋分预估常模表 Mapper 接口
 * </p>
 *
 * @author chenjy
 * @since 2021-03-11
 */
public interface ConstPointsAssignForecastMapper extends BaseMapper<ConstPointsAssignForecast> {

}
