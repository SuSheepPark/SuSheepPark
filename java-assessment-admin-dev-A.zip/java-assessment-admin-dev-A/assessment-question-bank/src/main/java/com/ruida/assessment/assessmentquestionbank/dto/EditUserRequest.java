package com.ruida.assessment.assessmentquestionbank.dto;

import lombok.Data;
import java.io.Serializable;
import java.util.List;

@Data
public class EditUserRequest implements Serializable {
   private Integer userId;
   private String realName;
   private String telephone;
   private Boolean  isAdd;
   private String secuId;
   private List<UserRoleDeadTimeDTO> userRoleRelationList;
}
