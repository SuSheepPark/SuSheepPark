package com.ruida.mockservice.service;


import com.baomidou.mybatisplus.service.IService;
import com.ruida.mockdao.model.AppVersion;

/**
 * <p>
 * APP版本信息表 服务类
 * </p>
 *
 * @author Bhj
 * @since 2020-07-17
 */
public interface AppVersionService extends IService<AppVersion> {

    AppVersion getAppVersionInfo(Integer type);
}
