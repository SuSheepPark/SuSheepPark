package com.ruida.mockdao.dao;


import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.model.OptionalSubjectReport;

/**
 * @description:
 * @author: kgz
 * @date: 2021/2/24
 */
public interface OptionalSubjectReportMapper extends BaseMapper<OptionalSubjectReport> {
}
