package com.ruida.mockservice.service;

/**
 * Created by xumingqi on 2021/7/1 17:29
 */
public interface PayService {
    boolean checkOrderBeforePay(String orderNo);
}
