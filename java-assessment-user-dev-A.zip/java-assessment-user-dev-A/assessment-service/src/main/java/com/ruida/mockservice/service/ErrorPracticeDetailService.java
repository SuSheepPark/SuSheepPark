package com.ruida.mockservice.service;

import com.baomidou.mybatisplus.service.IService;
import com.ruida.mockdao.model.ErrorPracticeDetail;
import com.ruida.mockdao.vo.error.QuestionTypeVO;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * 错题练习记录明细表 服务类
 * </p>
 *
 * @author chenjy
 * @since 2020-10-20
 */
public interface ErrorPracticeDetailService extends IService<ErrorPracticeDetail> {

    Map<String,Object> analysis(Integer recordId);

    List<QuestionTypeVO> getAnswerSheet(Integer recordId);
}
