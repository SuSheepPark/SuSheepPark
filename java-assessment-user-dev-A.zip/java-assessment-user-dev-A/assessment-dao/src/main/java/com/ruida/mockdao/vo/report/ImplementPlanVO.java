package com.ruida.mockdao.vo.report;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;

/**
 * @description: 实施计划VO
 * @author: kgz
 * @date: 2021/9/6
 */
@ApiModel(description = "实施计划信息")
public class ImplementPlanVO implements Serializable {

    @ApiModelProperty(value = "实施计划id", name = "planId")
    private String planId;

    @ApiModelProperty(value = "实施计划名称", name = "planName")
    private String planName;

    public String getPlanId() {
        return planId;
    }

    public void setPlanId(String planId) {
        this.planId = planId;
    }

    public String getPlanName() {
        return planName;
    }

    public void setPlanName(String planName) {
        this.planName = planName;
    }

    @Override
    public String toString() {
        return "ImplementPlanVO{" +
                "planId='" + planId + '\'' +
                ", planName='" + planName + '\'' +
                '}';
    }
}
