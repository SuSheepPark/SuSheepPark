package com.ruida.mockdao.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ruida.mockdao.model.ExamNotice;
import lombok.Data;

import java.util.Date;
import java.util.List;

/**
 * @description: 试卷测试记录
 * @author: wy
 * @create: 2021-07-23
 */
@Data
public class MyTestPaperExamRecordVO {

    /**
     * 商品id
     */
    private Integer productId;
    /**
     * 试卷id
     */
    private Integer testPaperId;
    /**
     * 测试记录id
     */
    private Integer examRecordId;

    /*
    第几次
     */
    private String recordName;
    /**
     * 提交时间/阅卷完成时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date submitTime;

}

