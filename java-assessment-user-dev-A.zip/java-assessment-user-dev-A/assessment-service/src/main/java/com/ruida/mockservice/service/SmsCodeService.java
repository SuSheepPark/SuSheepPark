package com.ruida.mockservice.service;

import com.baomidou.mybatisplus.service.IService;
import com.ruida.mockdao.model.SmsCode;

/**
 * <p>
 * 短信验证码表 服务类
 * </p>
 *
 * @author Bhj
 * @since 2020-07-09
 */
public interface SmsCodeService extends IService<SmsCode> {
     Boolean insertSmsCode(SmsCode tSmsCode);

     String getLastSmsCodeByTel(String telephone);
}
