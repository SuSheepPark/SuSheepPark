/**   
 * Copyright © 2019 公司名. All rights reserved.
 * 
 * @Title: cmsEception.java 
 * @Prject: zhaowei-cms
 * @Package: com.zhaowei.cms.util 
 * @Description: TODO
 * @author: zw   
 * @date: 2019年9月19日 下午3:24:48 
 * @version: V1.0   
 */
package com.zhaowei.cms.util;

/** 
 * @ClassName: cmsEception 
 * @Description: cms的自定义异常
 * @author: zw
 * @date: 2019年9月19日 下午3:24:48  
 */
public class CMSEception extends RuntimeException{

	/**
	 * @fieldName: serialVersionUID
	 * @fieldType: long
	 * @Description: TODO
	 */
	private static final long serialVersionUID = 1L;

	
	public CMSEception() {}
	
	public CMSEception(String message) {
		super(message);
	}
	
	
}
