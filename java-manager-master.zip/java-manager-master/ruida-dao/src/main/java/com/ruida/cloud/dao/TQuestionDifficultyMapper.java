package com.ruida.cloud.dao;

import com.ruida.cloud.model.TQuestionDifficulty;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * 题目难度等级表 Mapper 接口
 * </p>
 *
 * @author mlzhang
 * @since 2019-12-16
 */
public interface TQuestionDifficultyMapper {
    @Select("SELECT\n" +
            "\tquestion_type_id AS questionTypeId,\n" +
            "\tquestion_type_name AS questionTypeName\n" +
            "FROM\n" +
            "\tt_question_type where isdelete=0")
    List<Map<String, Object>> getQuestionTypeList();

    @Select("SELECT\n" +
            "\tdifficulty_id AS difficultyId,\n" +
            "difficulty_level ASdifficultyLevel\n" +
            "FROM\n" +
            "\tt_question_difficulty\n" +
            "where isdelete= 0 and `status` = 1 ")
    List<Map<String, Object>> getDifficultyList();

    @Select("SELECT\n" +
            "\tquestion_type_actual_id AS questionTypeActualId,\n" +
            "\tquestion_type_actual_name AS questionTypeActualName\n" +
            "FROM\n" +
            "\tt_question_type_actual\n" +
            "WHERE\n" +
            "\tisdelete = 0\n" +
            "AND question_type_actual_id != 5")
    List<Map<String, Object>> selectQuestionType();

}
