package com.ruida.assessment.assessmentquestionbank.model;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;

import java.io.Serializable;

/**
 * @description: 升学选拔报告详情数据库实体
 * @author: kgz
 * @date: 2020/12/17
 */
@TableName("t_evaluate_report")
public class TEvaluateReport extends BaseColumn implements Serializable {
    /**
     * 试卷id
     */
    @TableId
    private Integer id;

    /**
     * 报告id
     */
    private Integer reportId;

    /**
     * 报告名称
     */
    private String reportName;

    /**
     * 用户id
     */
    private Integer userId;

    /**
     * 用户名称
     */
    private String userName;

    /**
     * 身份证号码
     */
    private String idCard;

    /**
     * 学号
     */
    private String stuNo;

    /**
     * 科目名称
     */
    private String subjectName;

    /**
     * 班级名称
     */
    private String className;

    /**
     * 学校名称
     */
    private String schoolName;

    /**
     * 本次测试成绩信息
     */
    private String currentScoreInfo;

    /**
     * 历次统一测试成绩信息
     */
    private String historyScoreInfo;

    /**
     * 历次学校测试成绩信息
     */
    private String historySchoolScoreInfo;

    public String getIdCard() {
        return idCard;
    }

    public void setIdCard(String idCard) {
        this.idCard = idCard;
    }

    public String getStuNo() {
        return stuNo;
    }

    public void setStuNo(String stuNo) {
        this.stuNo = stuNo;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getReportId() {
        return reportId;
    }

    public void setReportId(Integer reportId) {
        this.reportId = reportId;
    }

    public String getReportName() {
        return reportName;
    }

    public void setReportName(String reportName) {
        this.reportName = reportName;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getSubjectName() {
        return subjectName;
    }

    public void setSubjectName(String subjectName) {
        this.subjectName = subjectName;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public String getSchoolName() {
        return schoolName;
    }

    public void setSchoolName(String schoolName) {
        this.schoolName = schoolName;
    }

    public String getCurrentScoreInfo() {
        return currentScoreInfo;
    }

    public void setCurrentScoreInfo(String currentScoreInfo) {
        this.currentScoreInfo = currentScoreInfo;
    }

    public String getHistoryScoreInfo() {
        return historyScoreInfo;
    }

    public void setHistoryScoreInfo(String historyScoreInfo) {
        this.historyScoreInfo = historyScoreInfo;
    }

    public String getHistorySchoolScoreInfo() {
        return historySchoolScoreInfo;
    }

    public void setHistorySchoolScoreInfo(String historySchoolScoreInfo) {
        this.historySchoolScoreInfo = historySchoolScoreInfo;
    }

    @Override
    public String toString() {
        return "TEvaluateReport{" +
                "id=" + id +
                ", reportId=" + reportId +
                ", reportName='" + reportName + '\'' +
                ", userId=" + userId +
                ", userName='" + userName + '\'' +
                ", subjectName='" + subjectName + '\'' +
                ", className='" + className + '\'' +
                ", schoolName='" + schoolName + '\'' +
                ", currentScoreInfo='" + currentScoreInfo + '\'' +
                ", historyScoreInfo='" + historyScoreInfo + '\'' +
                ", historySchoolScoreInfo='" + historySchoolScoreInfo + '\'' +
                '}';
    }
}
