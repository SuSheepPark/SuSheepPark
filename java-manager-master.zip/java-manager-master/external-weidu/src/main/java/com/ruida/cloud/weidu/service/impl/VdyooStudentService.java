package com.ruida.cloud.weidu.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.ruida.cloud.dao.WeiduStudentRelMapper;
import com.ruida.cloud.model.WeiduStudentRel;
import com.ruida.cloud.weidu.config.WeiduConfig;
import com.ruida.cloud.weidu.exception.VdyooException;
import com.ruida.cloud.weidu.service.BaseVdyooService;
import com.ruida.cloud.weidu.utils.PropertyUtil;
import com.ruida.cloud.weidu.utils.VdyooUtil;
import com.ruida.cloud.weidu.vo.VdyooEntity;
import com.ruida.common.context.BaseContextHandle;
import com.ruida.common.util.HttpClientUtil;
import com.ruida.common.util.ValidateMT;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.*;

/**
 * 关联表：
 * 睿达stuid    pid
 * 威渡id       id
 * 睿达班级id    pClassId
 * 威渡班级id    classId
 *
 * @author taosh
 * @create 2019-04-23 17:07
 */
@Service
@Slf4j
public class VdyooStudentService extends BaseVdyooService {
    private String vdyooPath = PropertyUtil.getProperty("vdyooTestApi");
    @Resource
    private WeiduStudentRelMapper weiduStudentRelMapper;

    /**
     * 创建学生
     */
    @Transactional(rollbackFor = Exception.class)
    public Integer addStudent(Map<String, Object> param) {
        VdyooEntity vdyooEntity = this.vdyooFactory.post(param, WeiduConfig.addStudent);
        boolean flag = false;
        Integer id = null;
        if (vdyooEntity.getSuccess()) {
            try {
                WeiduStudentRel weiduStudentRel = new WeiduStudentRel();
                JSONObject object = (JSONObject)JSON.toJSON(vdyooEntity.getPayload());
                weiduStudentRel.setWeiduStudentId(object.getString("id"));
                weiduStudentRel.setIsdelete((byte) 0);
                weiduStudentRel.setStudentId((Integer) param.get("pid"));
                weiduStudentRel.setCreateTime(new Date());
                id = object.getInteger("id");

                flag = weiduStudentRelMapper.insert(weiduStudentRel) > 0;

                if( flag ){
                    return id;
                }else {
                    this.deleteStudentById(id);
                    throw new VdyooException("500", "学生关联威渡信息操作失败");
                }
            } catch (Exception e) {
                if (ValidateMT.isNotNull(id)) {
                    this.deleteStudentById(id);
                }
                log.error("威渡异常:"+JSONObject.toJSONString(e));
                throw new VdyooException("500", "操作失败");
            }
        }

        return 0;
    }

    /**
     * 创建班级学生
     */
    public void addClassStudent() {
        String path = vdyooPath + "/api/business/student/addClassStudent";

        Map<String, String> param = VdyooUtil.getSignMap();

        //学生ID
        param.put("pid", "123");
        //所属层级   todo 暂无
        param.put("departmentId", "");
        //登录账号
        param.put("userName", "123");
        //登录密码
        param.put("passWord", "");
        //姓名
        param.put("name", "123");
        //所属教学班级
        param.put("classId", "123");
        //电话    非必填
        param.put("mobile", "");
        //邮箱    非必填
        param.put("email", "123");

//        String response = HttpClientUtil.postMap(path, param);
//        System.out.println(response);
    }

    /**
     * 批量创建学生
     */
    public boolean addBatchStudent(Map<String, Object> params) {
        VdyooEntity vdyooEntity = this.vdyooFactory.post(params, WeiduConfig.addBatchStudent);
        boolean flag = false;
        List<Integer> errorIds = new ArrayList<>();
        if (vdyooEntity.getSuccess()) {
            try {
                JSONArray jsonArray =(JSONArray) JSON.toJSON(vdyooEntity.getPayload());
                List<WeiduStudentRel> list = new ArrayList<>();
                for (Object object : jsonArray) {
                    JSONObject jsonObject = (JSONObject) object;
                    WeiduStudentRel weiduStudentRel = new WeiduStudentRel();
                    weiduStudentRel.setWeiduStudentId(jsonObject.getString("id"));
                    weiduStudentRel.setIsdelete((byte) 0);
                    weiduStudentRel.setCreateBy(BaseContextHandle.getUserId());
                    weiduStudentRel.setStudentId(jsonObject.getInteger("pid"));
                    weiduStudentRel.setCreateTime(new Date());
                    weiduStudentRel.setUpdateBy(BaseContextHandle.getUserId());
                    weiduStudentRel.setUpdateTime(new Date());
                    list.add(weiduStudentRel);
                    errorIds.add(jsonObject.getInteger("id"));
                }
                flag = weiduStudentRelMapper.insertList(list) > 0;
            } catch (Exception e) {
                log.error("威渡异常:"+JSONObject.toJSONString(e));
                //操作失败后要进行回滚到 维度方
                if (ValidateMT.isNotNull(errorIds) && errorIds.size() > 0) {
                    for (Integer id : errorIds) {
                        this.deleteStudentById(id);
                    }
                }
                throw new VdyooException("500", "操作失败");
            }
        }
        return flag;
    }


    /**
     * 删除学生(根据威渡id)
     */
    public boolean deleteStudentById(Integer id) {
        Map<String, Object> param = new HashMap<>();
        param.put("id", id);
        return this.vdyooFactory.post(param, WeiduConfig.deleteStudentById).getSuccess();
    }

    /**
     * 删除学生(根据学生本地id)
     */
    public final static String deleteStudentByPid = "/api/business/student/deleteStudentByPid";

    public boolean deleteStudentByPid(Integer pid) {
        Map<String, Object> param = new HashMap<>();
        //本地学生ID
        param.put("pid", pid);
        return this.vdyooFactory.post(param, WeiduConfig.deleteStudentByPid).getSuccess();
    }

    /**
     * 编辑学生信息(根据威渡id)
     */
    public final static String editStudentById = "/api/business/student/editStudentById";

    public boolean editStudentById(Map<String, Object> param) {
        return this.vdyooFactory.post(param, WeiduConfig.deleteStudentByPid).getSuccess();
    }

    /**
     * 编辑学生信息(根据学生本地id)
     */
    public boolean editStudentByPid(Map<String, Object> param) {
        return this.vdyooFactory.post(param, WeiduConfig.editStudentByPid).getSuccess();
    }

    /**
     * 根据ID查询学生
     */
    public final static String findStudentByid = "/api/business/student/findStudentByid";

    public VdyooEntity findStudentByid(Integer id) {
        Map<String, Object> param = new HashMap<>();
        return this.vdyooFactory.post(param, WeiduConfig.findStudentByid);
    }

    /**
     * 根据ID查询学生(根据学生本地pid)
     */
    public final static String findStudentByPid = "/api/business/student/findStudentByPid";

    public VdyooEntity findStudentByPid(Integer id) {
        Map<String, Object> param = new HashMap<>();
        return this.vdyooFactory.post(param, WeiduConfig.findStudentByPid);
    }


    /**
     * 查询公司下所有学生
     */
    public final static String findStudentByTenant = "/api/business/student/findStudentByTenant";

    public VdyooEntity findStudentByTenant() {
        return this.vdyooFactory.post(WeiduConfig.findStudentByTenant);
    }

    /****************************管理班级成员（学生）********************************/
    /**
     * 添加班级成员（将学生与班级关联，游客->学生）
     */
    public final static String addClassMember = "/api/business/classmember/addClassMember";

    public VdyooEntity addClassMember(Map<String, Object> param) {
        return this.vdyooFactory.post(param, WeiduConfig.addClassMember);
    }

    /**
     * 批量添加班级成员（将学生与班级关联，游客->学生）
     */
    public VdyooEntity addClassMembers(Map<String, Object> param) {
        return this.vdyooFactory.post(param, WeiduConfig.addClassMembers);
    }

    /**
     * 删除班级成员（将学生移除班级，学生->游客）
     */
    public VdyooEntity deleteClassMemberById(Map<String, Object> param) {
        /***"/api/business/classmember/deleteClassMember"   两个接口功能一样**/
        return this.vdyooFactory.post(param, WeiduConfig.deleteClassMember);
    }

    /**
     * 学生更换班级
     */
    public void editClassMember(String oldClassId, String classId, String studentId) {
        String path = vdyooPath + "/api/business/classmember/editClassMember";

        Map<String, String> param = VdyooUtil.getSignMap();
        //原教学班的ID
        param.put("oldClassId", oldClassId);
        //新教学班的ID
        param.put("classId", classId);
        //学生的ID
        param.put("studentId", studentId);

//        String response = HttpClientUtil.postMap(path, param);
//        System.out.println(response);
    }

    /**
     * 通过学生的ID来查询该学生所在哪几个班级
     */
    public void findClassMemberByStudent(String studentId) {
        /***"/api/business/classmember/deleteClassMember"   两个接口功能一样**/
        String path = vdyooPath + "/api/business/classmember/findClassMemberByStudent";

        Map<String, String> param = VdyooUtil.getSignMap();
        //学生的ID
        param.put("studentId", studentId);

//        String response = HttpClientUtil.postMap(path, param);
//        System.out.println(response);
    }

    /**
     * 通过学生的ID来查询该学生所在哪几个班级
     */
    public void findClassMemberByClass(String classId) {
        /***"/api/business/classmember/deleteClassMember"   两个接口功能一样**/
        String path = vdyooPath + "/api/business/classmember/findClassMemberByClass";

        Map<String, String> param = VdyooUtil.getSignMap();
        //学生的ID
        param.put("classId", classId);

//        String response = HttpClientUtil.postMap(path, param);
//        System.out.println(response);
    }


}
