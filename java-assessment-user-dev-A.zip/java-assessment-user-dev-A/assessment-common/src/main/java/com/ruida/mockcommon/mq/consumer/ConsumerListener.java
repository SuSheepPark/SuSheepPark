package com.ruida.mockcommon.mq.consumer;


import com.aliyun.openservices.ons.api.*;
import com.aliyun.openservices.shade.com.alibaba.rocketmq.common.protocol.heartbeat.MessageModel;
import com.google.common.collect.Lists;
import com.ruida.mockcommon.mq.producer.MQUtil;
import com.ruida.mockcommon.mq.producer.RMQConfig;
import lombok.extern.slf4j.Slf4j;
import org.reflections.Reflections;
import org.reflections.scanners.TypeAnnotationsScanner;
import org.reflections.util.ClasspathHelper;
import org.reflections.util.ConfigurationBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import javax.annotation.Resource;
import java.util.Properties;
import java.util.Set;


/**
 * Created by jinhu on 2020/8/3.
 * 消费者初始化
 */
@Component
@Slf4j
public class ConsumerListener implements ApplicationListener<ApplicationReadyEvent> {

	@Value("${spring.profiles.active}")
	private String profiles;

	@Resource
	private ApplicationContext context;



	@Override
	public void onApplicationEvent(ApplicationReadyEvent applicationReadyEvent) {

		Reflections reflections = new Reflections(new ConfigurationBuilder()
				.setUrls(ClasspathHelper.forPackage("com.ruida")).setScanners(new TypeAnnotationsScanner()));

		Set<Class<?>> classes = reflections.getTypesAnnotatedWith(MQConsumer.class, true);
		for (Class<?> cla : classes) {
			MQConsumer mqConsumer = cla.getDeclaredAnnotation(MQConsumer.class);

			final String realConsumerId = MQUtil.getRealId(mqConsumer.consumer());
			final String topic = mqConsumer.topic();
			final String realTopic = topic;//MQUtil.getRealId(topic);
			final String tags = mqConsumer.tags() + "-" + profiles;
			final MessageModel messageModel = mqConsumer.messageModel();


			if (!(Lists.newArrayList(cla.getInterfaces()).contains(MQConsumeService.class))) {
				throw new IllegalArgumentException(cla.getName() + "must be implements MQConsumeService interface");
			}

			Consumer consumer = initConsumer(realConsumerId, messageModel, topic, tags);

			MQConsumeService mqConsumeServiceImpl = (MQConsumeService) context
					.getBean(StringUtils.uncapitalize(cla.getSimpleName()));

			log.info("subscribe consumer consumerId:{} topic:{} tags:{}", realConsumerId, realTopic, tags);


			consumer.subscribe(topic,tags, new MessageListener(){

				@Override
				public Action consume(Message message, ConsumeContext consumeContext) {

					try {
						if (message.getReconsumeTimes() >= 16) {
							log.warn("Reconsume:{} message:{}", message,
									message.getBody() == null ? "" : new String(message.getBody(), "UTF-8"));
						} else {
							log.info("{} message:{}", message,
									message.getBody() == null ? "" : new String(message.getBody(), "UTF-8"));
						}
						boolean ret = mqConsumeServiceImpl.consume(message);
						if (ret) {
							return Action.CommitMessage;
						} else {
							return Action.ReconsumeLater;
						}
					} catch (Exception e) {
						log.error("error message:{}", message, e);
						return Action.ReconsumeLater;
					}
				}
			});

			try {
				consumer.start();
			} catch (Exception e) {
				log.error("consumer start:", e);
				throw new IllegalArgumentException(cla.getName() + " fail to start");
			}
		}
	}

	@Resource
	RMQConfig rmqConfig;

	/**
	 * 非线程安全
	 * @param consumerId
	 * @param messageModel
	 * @param topic
	 * @param tags
	 * @return
	 */
	private Consumer initConsumer(
			final String consumerId, final MessageModel messageModel, final String topic,
			final String tags)  {

		Properties properties = rmqConfig.getProperties();
		properties.put(PropertyKeyConst.GROUP_ID,consumerId);
		properties.put(PropertyKeyConst.MessageModel, messageModel);

		Consumer consumer = ONSFactory.createConsumer(properties);

		return consumer;


	}
}
