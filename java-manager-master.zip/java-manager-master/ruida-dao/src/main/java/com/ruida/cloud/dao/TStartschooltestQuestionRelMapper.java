package com.ruida.cloud.dao;

import com.ruida.cloud.model.TStartschooltestQuestionRel;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.apache.poi.hssf.record.BOFRecord;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * 入学诊断、题目关联表 Mapper 接口
 * </p>
 *
 * @author mlzhang
 * @since 2019-12-16
 */
public interface TStartschooltestQuestionRelMapper {
    @Update("update   t_startschooltest_question_rel set isdelete = 1 where question_library_id = #{questionId}")
    Integer deleteTestQuestionRelByQuestionId(@Param("questionId") Integer questionId);

    Integer insert(TStartschooltestQuestionRel tStartschooltestQuestionRel);

    Integer updateById(TStartschooltestQuestionRel tStartschooltestQuestionRel);

    TStartschooltestQuestionRel selectById(@Param("id") Integer id);

    @Select("select count(*) from  t_startschooltest_question_rel where isdelete =0 " +
            "and start_school_test_id =#{testId} ")
    Integer selectCountByTestId(@Param("testId") Integer testId);

    @Select("select count(*) from  t_startschooltest_question_rel where isdelete =0 " +
            "and start_school_test_id =#{testId} and question_library_id = #{questionId} ")
    Integer selectCountByTestIdAndQuestionId(@Param("testId") Integer testId, @Param("questionId") Integer questionId);


    List<Map<String, Object>> selectTestStudentListById(Map<String, Object> param);

    @Select("select count(*)  from  t_course_purchase where purchaser_id =#{userId} ")
    Integer getCourseBuyNumberByUserId(@Param("userId") Integer userId);


    List<Map<String,Object>> selectListByTestId(@Param("testId") Integer testId);

    Integer updateByPrimaryKeySelective(TStartschooltestQuestionRel questionRel);

    List<Map<String,Object>> listTestQuestionRel(Integer startSchoolTestId);
}
