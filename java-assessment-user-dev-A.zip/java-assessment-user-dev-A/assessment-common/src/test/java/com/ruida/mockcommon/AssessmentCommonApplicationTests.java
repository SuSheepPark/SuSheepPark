package com.ruida.mockcommon;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AssessmentCommonApplicationTests {

    @Test
    void contextLoads() {
    }

}
