package com.ruida.common.util.excel.processor.impl;

import com.ruida.common.SystemConstant;
import com.ruida.common.util.excel.processor.TypeProcessor;
import org.apache.commons.lang3.StringUtils;

import java.text.ParseException;
import java.text.SimpleDateFormat;

/**
 * Created by Administrator on 2017/4/18.
 */
public class DateProcessorImpl implements TypeProcessor {

    SimpleDateFormat sf;

    public DateProcessorImpl(String dateFormat) {
        if(dateFormat == null){
            dateFormat = SystemConstant.DATE_FORMAT;
        }
        sf = new SimpleDateFormat(dateFormat);
    }

    @Override
    public Object fromString(String preValue) throws ParseException {
        if(StringUtils.isBlank(preValue)){
            return null;
        }
        if(preValue.endsWith(".0")){
            preValue = preValue.replace(".0", "");
        }
        try{
            return sf.parse(preValue);
        }catch (Exception ex){
            throw new ParseException(preValue + "无法转换为日期类型", 0);
        }
    }

    @Override
    public String toString(Object value) throws ParseException {
        if(value == null){
            return "";
        }

        return sf.format(value);
    }

}
