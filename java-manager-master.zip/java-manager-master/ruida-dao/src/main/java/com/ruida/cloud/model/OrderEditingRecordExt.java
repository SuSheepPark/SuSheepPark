package com.ruida.cloud.model;

import lombok.Data;

/**
 * @description: 订单操作记录扩展类
 * @author: chenjy
 * @create: 2020-06-03 11:20
 */
@Data
public class OrderEditingRecordExt extends OrderEditingRecord{
    /**
     * 操作人姓名
     */
    private String operator;

    /**
     * 操作类型
     */
    private String editTypeName;

    /**
     * 修改前授课方式
     */
    private String teachingMethodOldName;

    /**
     * 修改后授课方式
     */
    private String teachingMethodNewName;
}
