package com.ruida.mockdao.model;

import java.util.Date;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.enums.IdType;

import io.swagger.annotations.ApiModelProperty;

/**
 * <p>
 * 科目兴趣调查的答卷
 * </p>
 *
 * @author
 * @since 2021-01-11
 */
public class TSubjectInterestExamRecord {

	@TableId(value = "record_id", type = IdType.AUTO)
	private Integer recordId;
	/**
	 * 完整的提交的答案
	 */
	private String answer;
	/**
	 * 必选科目
	 */
	private String mustChoose;
	/**
	 * 必不选科目
	 */
	private String notChoose;
	/**
	 * 分析报告
	 */
	private String report;
	/**
	 * 状态
	 */
	private Integer status;
	@ApiModelProperty(value = "创建者id", name = "createBy", required = true)
	private Integer createBy;

	@ApiModelProperty(value = "创建时间", name = "createTime", required = true)
	private Date createTime;

	@ApiModelProperty(value = "更新者id", name = "updateBy", required = false)
	private Integer updateBy;

	@ApiModelProperty(value = "更新时间", name = "updateTime", required = false)
	private Date updateTime;

	@ApiModelProperty(value = "是否删除（0-未删除；1-删除）", name = "isdelete", required = false)
	private Integer isdelete;

	public Integer getRecordId() {
		return recordId;
	}

	public void setRecordId(Integer recordId) {
		this.recordId = recordId;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(Object answer) {
		if (answer instanceof String) {
			this.answer = answer.toString();
		} else {
			this.answer = JSON.toJSONString(answer);
		}
	}

	public String getMustChoose() {
		return mustChoose;
	}

	public void setMustChoose(String mustChoose) {
		this.mustChoose = mustChoose;
	}

	public String getNotChoose() {
		return notChoose;
	}

	public void setNotChoose(String notChoose) {
		this.notChoose = notChoose;
	}

	public String getReport() {
		return report;
	}

	public void setReport(String report) {
		this.report = report;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Integer getIsdelete() {
		return isdelete;
	}

	public void setIsdelete(Integer isdelete) {
		this.isdelete = isdelete;
	}

	@Override
	public String toString() {
		return "TSubjectInterestExamRecord{" + ", recordId=" + recordId + ", answer=" + answer + ", mustChoose="
				+ mustChoose + ", notChoose=" + notChoose + ", report=" + report + ", status=" + status + ", isdelete="
				+ isdelete + "}";
	}

	public Integer getCreateBy() {
		return createBy;
	}

	public void setCreateBy(Integer createBy) {
		this.createBy = createBy;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Integer getUpdateBy() {
		return updateBy;
	}

	public void setUpdateBy(Integer updateBy) {
		this.updateBy = updateBy;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
}
