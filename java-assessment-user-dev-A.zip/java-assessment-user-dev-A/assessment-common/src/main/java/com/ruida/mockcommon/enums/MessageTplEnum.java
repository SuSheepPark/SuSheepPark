package com.ruida.mockcommon.enums;

public enum MessageTplEnum {

    BEGIN_CLASS(0, 0, "开课提醒"),
    REGISTER_SUCCESS(0, 1, "账号注册完成后系统通知"),
    BUY_SUCCESS(0, 2, "购买成功提醒"),
    PAYMENT(0, 3, "付款提醒"),
    CONFIRM(0, 7, "确认提醒");
    /**
     * 消息模板类型(0—系统出发消息<需同时发送手机号码；1—主动推动消息>）
     **/
    private Integer messageTplType;
    /**
     * 消息模板编号（0—开课提醒；1—账号注册完成后系统通知；2—购买成功提醒；3—付款提醒；4-确认提醒）
     **/
    private Integer messageTplNo;
    /**
     * 状态描述
     **/
    private String desc;
    MessageTplEnum(Integer messageTplType, Integer messageTplNo, String desc) {
        this.messageTplType = messageTplType;
        this.messageTplNo = messageTplNo;
        this.desc = desc;
    }

    public Integer getMessageTplType() {
        return messageTplType;
    }

    public void setMessageTplType(Integer messageTplType) {
        this.messageTplType = messageTplType;
    }

    public Integer getMessageTplNo() {
        return messageTplNo;
    }

    public void setMessageTplNo(Integer messageTplNo) {
        this.messageTplNo = messageTplNo;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
