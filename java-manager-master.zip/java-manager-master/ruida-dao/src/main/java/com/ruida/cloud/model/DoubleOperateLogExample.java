package com.ruida.cloud.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class DoubleOperateLogExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public DoubleOperateLogExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andIdIsNull() {
            addCriterion("id is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("id is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(Integer value) {
            addCriterion("id =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(Integer value) {
            addCriterion("id <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(Integer value) {
            addCriterion("id >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("id >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(Integer value) {
            addCriterion("id <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(Integer value) {
            addCriterion("id <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<Integer> values) {
            addCriterion("id in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<Integer> values) {
            addCriterion("id not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(Integer value1, Integer value2) {
            addCriterion("id between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(Integer value1, Integer value2) {
            addCriterion("id not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andOperateModuleIsNull() {
            addCriterion("operate_module is null");
            return (Criteria) this;
        }

        public Criteria andOperateModuleIsNotNull() {
            addCriterion("operate_module is not null");
            return (Criteria) this;
        }

        public Criteria andOperateModuleEqualTo(String value) {
            addCriterion("operate_module =", value, "operateModule");
            return (Criteria) this;
        }

        public Criteria andOperateModuleNotEqualTo(String value) {
            addCriterion("operate_module <>", value, "operateModule");
            return (Criteria) this;
        }

        public Criteria andOperateModuleGreaterThan(String value) {
            addCriterion("operate_module >", value, "operateModule");
            return (Criteria) this;
        }

        public Criteria andOperateModuleGreaterThanOrEqualTo(String value) {
            addCriterion("operate_module >=", value, "operateModule");
            return (Criteria) this;
        }

        public Criteria andOperateModuleLessThan(String value) {
            addCriterion("operate_module <", value, "operateModule");
            return (Criteria) this;
        }

        public Criteria andOperateModuleLessThanOrEqualTo(String value) {
            addCriterion("operate_module <=", value, "operateModule");
            return (Criteria) this;
        }

        public Criteria andOperateModuleLike(String value) {
            addCriterion("operate_module like", value, "operateModule");
            return (Criteria) this;
        }

        public Criteria andOperateModuleNotLike(String value) {
            addCriterion("operate_module not like", value, "operateModule");
            return (Criteria) this;
        }

        public Criteria andOperateModuleIn(List<String> values) {
            addCriterion("operate_module in", values, "operateModule");
            return (Criteria) this;
        }

        public Criteria andOperateModuleNotIn(List<String> values) {
            addCriterion("operate_module not in", values, "operateModule");
            return (Criteria) this;
        }

        public Criteria andOperateModuleBetween(String value1, String value2) {
            addCriterion("operate_module between", value1, value2, "operateModule");
            return (Criteria) this;
        }

        public Criteria andOperateModuleNotBetween(String value1, String value2) {
            addCriterion("operate_module not between", value1, value2, "operateModule");
            return (Criteria) this;
        }

        public Criteria andSyncTypeIsNull() {
            addCriterion("sync_type is null");
            return (Criteria) this;
        }

        public Criteria andSyncTypeIsNotNull() {
            addCriterion("sync_type is not null");
            return (Criteria) this;
        }

        public Criteria andSyncTypeEqualTo(String value) {
            addCriterion("sync_type =", value, "syncType");
            return (Criteria) this;
        }

        public Criteria andSyncTypeNotEqualTo(String value) {
            addCriterion("sync_type <>", value, "syncType");
            return (Criteria) this;
        }

        public Criteria andSyncTypeGreaterThan(String value) {
            addCriterion("sync_type >", value, "syncType");
            return (Criteria) this;
        }

        public Criteria andSyncTypeGreaterThanOrEqualTo(String value) {
            addCriterion("sync_type >=", value, "syncType");
            return (Criteria) this;
        }

        public Criteria andSyncTypeLessThan(String value) {
            addCriterion("sync_type <", value, "syncType");
            return (Criteria) this;
        }

        public Criteria andSyncTypeLessThanOrEqualTo(String value) {
            addCriterion("sync_type <=", value, "syncType");
            return (Criteria) this;
        }

        public Criteria andSyncTypeLike(String value) {
            addCriterion("sync_type like", value, "syncType");
            return (Criteria) this;
        }

        public Criteria andSyncTypeNotLike(String value) {
            addCriterion("sync_type not like", value, "syncType");
            return (Criteria) this;
        }

        public Criteria andSyncTypeIn(List<String> values) {
            addCriterion("sync_type in", values, "syncType");
            return (Criteria) this;
        }

        public Criteria andSyncTypeNotIn(List<String> values) {
            addCriterion("sync_type not in", values, "syncType");
            return (Criteria) this;
        }

        public Criteria andSyncTypeBetween(String value1, String value2) {
            addCriterion("sync_type between", value1, value2, "syncType");
            return (Criteria) this;
        }

        public Criteria andSyncTypeNotBetween(String value1, String value2) {
            addCriterion("sync_type not between", value1, value2, "syncType");
            return (Criteria) this;
        }

        public Criteria andOperateObjectIsNull() {
            addCriterion("operate_object is null");
            return (Criteria) this;
        }

        public Criteria andOperateObjectIsNotNull() {
            addCriterion("operate_object is not null");
            return (Criteria) this;
        }

        public Criteria andOperateObjectEqualTo(String value) {
            addCriterion("operate_object =", value, "operateObject");
            return (Criteria) this;
        }

        public Criteria andOperateObjectNotEqualTo(String value) {
            addCriterion("operate_object <>", value, "operateObject");
            return (Criteria) this;
        }

        public Criteria andOperateObjectGreaterThan(String value) {
            addCriterion("operate_object >", value, "operateObject");
            return (Criteria) this;
        }

        public Criteria andOperateObjectGreaterThanOrEqualTo(String value) {
            addCriterion("operate_object >=", value, "operateObject");
            return (Criteria) this;
        }

        public Criteria andOperateObjectLessThan(String value) {
            addCriterion("operate_object <", value, "operateObject");
            return (Criteria) this;
        }

        public Criteria andOperateObjectLessThanOrEqualTo(String value) {
            addCriterion("operate_object <=", value, "operateObject");
            return (Criteria) this;
        }

        public Criteria andOperateObjectLike(String value) {
            addCriterion("operate_object like", value, "operateObject");
            return (Criteria) this;
        }

        public Criteria andOperateObjectNotLike(String value) {
            addCriterion("operate_object not like", value, "operateObject");
            return (Criteria) this;
        }

        public Criteria andOperateObjectIn(List<String> values) {
            addCriterion("operate_object in", values, "operateObject");
            return (Criteria) this;
        }

        public Criteria andOperateObjectNotIn(List<String> values) {
            addCriterion("operate_object not in", values, "operateObject");
            return (Criteria) this;
        }

        public Criteria andOperateObjectBetween(String value1, String value2) {
            addCriterion("operate_object between", value1, value2, "operateObject");
            return (Criteria) this;
        }

        public Criteria andOperateObjectNotBetween(String value1, String value2) {
            addCriterion("operate_object not between", value1, value2, "operateObject");
            return (Criteria) this;
        }

        public Criteria andOperateItemIsNull() {
            addCriterion("operate_item is null");
            return (Criteria) this;
        }

        public Criteria andOperateItemIsNotNull() {
            addCriterion("operate_item is not null");
            return (Criteria) this;
        }

        public Criteria andOperateItemEqualTo(String value) {
            addCriterion("operate_item =", value, "operateItem");
            return (Criteria) this;
        }

        public Criteria andOperateItemNotEqualTo(String value) {
            addCriterion("operate_item <>", value, "operateItem");
            return (Criteria) this;
        }

        public Criteria andOperateItemGreaterThan(String value) {
            addCriterion("operate_item >", value, "operateItem");
            return (Criteria) this;
        }

        public Criteria andOperateItemGreaterThanOrEqualTo(String value) {
            addCriterion("operate_item >=", value, "operateItem");
            return (Criteria) this;
        }

        public Criteria andOperateItemLessThan(String value) {
            addCriterion("operate_item <", value, "operateItem");
            return (Criteria) this;
        }

        public Criteria andOperateItemLessThanOrEqualTo(String value) {
            addCriterion("operate_item <=", value, "operateItem");
            return (Criteria) this;
        }

        public Criteria andOperateItemLike(String value) {
            addCriterion("operate_item like", value, "operateItem");
            return (Criteria) this;
        }

        public Criteria andOperateItemNotLike(String value) {
            addCriterion("operate_item not like", value, "operateItem");
            return (Criteria) this;
        }

        public Criteria andOperateItemIn(List<String> values) {
            addCriterion("operate_item in", values, "operateItem");
            return (Criteria) this;
        }

        public Criteria andOperateItemNotIn(List<String> values) {
            addCriterion("operate_item not in", values, "operateItem");
            return (Criteria) this;
        }

        public Criteria andOperateItemBetween(String value1, String value2) {
            addCriterion("operate_item between", value1, value2, "operateItem");
            return (Criteria) this;
        }

        public Criteria andOperateItemNotBetween(String value1, String value2) {
            addCriterion("operate_item not between", value1, value2, "operateItem");
            return (Criteria) this;
        }

        public Criteria andOperateStepIsNull() {
            addCriterion("operate_step is null");
            return (Criteria) this;
        }

        public Criteria andOperateStepIsNotNull() {
            addCriterion("operate_step is not null");
            return (Criteria) this;
        }

        public Criteria andOperateStepEqualTo(String value) {
            addCriterion("operate_step =", value, "operateStep");
            return (Criteria) this;
        }

        public Criteria andOperateStepNotEqualTo(String value) {
            addCriterion("operate_step <>", value, "operateStep");
            return (Criteria) this;
        }

        public Criteria andOperateStepGreaterThan(String value) {
            addCriterion("operate_step >", value, "operateStep");
            return (Criteria) this;
        }

        public Criteria andOperateStepGreaterThanOrEqualTo(String value) {
            addCriterion("operate_step >=", value, "operateStep");
            return (Criteria) this;
        }

        public Criteria andOperateStepLessThan(String value) {
            addCriterion("operate_step <", value, "operateStep");
            return (Criteria) this;
        }

        public Criteria andOperateStepLessThanOrEqualTo(String value) {
            addCriterion("operate_step <=", value, "operateStep");
            return (Criteria) this;
        }

        public Criteria andOperateStepLike(String value) {
            addCriterion("operate_step like", value, "operateStep");
            return (Criteria) this;
        }

        public Criteria andOperateStepNotLike(String value) {
            addCriterion("operate_step not like", value, "operateStep");
            return (Criteria) this;
        }

        public Criteria andOperateStepIn(List<String> values) {
            addCriterion("operate_step in", values, "operateStep");
            return (Criteria) this;
        }

        public Criteria andOperateStepNotIn(List<String> values) {
            addCriterion("operate_step not in", values, "operateStep");
            return (Criteria) this;
        }

        public Criteria andOperateStepBetween(String value1, String value2) {
            addCriterion("operate_step between", value1, value2, "operateStep");
            return (Criteria) this;
        }

        public Criteria andOperateStepNotBetween(String value1, String value2) {
            addCriterion("operate_step not between", value1, value2, "operateStep");
            return (Criteria) this;
        }

        public Criteria andOperateResultIsNull() {
            addCriterion("operate_result is null");
            return (Criteria) this;
        }

        public Criteria andOperateResultIsNotNull() {
            addCriterion("operate_result is not null");
            return (Criteria) this;
        }

        public Criteria andOperateResultEqualTo(String value) {
            addCriterion("operate_result =", value, "operateResult");
            return (Criteria) this;
        }

        public Criteria andOperateResultNotEqualTo(String value) {
            addCriterion("operate_result <>", value, "operateResult");
            return (Criteria) this;
        }

        public Criteria andOperateResultGreaterThan(String value) {
            addCriterion("operate_result >", value, "operateResult");
            return (Criteria) this;
        }

        public Criteria andOperateResultGreaterThanOrEqualTo(String value) {
            addCriterion("operate_result >=", value, "operateResult");
            return (Criteria) this;
        }

        public Criteria andOperateResultLessThan(String value) {
            addCriterion("operate_result <", value, "operateResult");
            return (Criteria) this;
        }

        public Criteria andOperateResultLessThanOrEqualTo(String value) {
            addCriterion("operate_result <=", value, "operateResult");
            return (Criteria) this;
        }

        public Criteria andOperateResultLike(String value) {
            addCriterion("operate_result like", value, "operateResult");
            return (Criteria) this;
        }

        public Criteria andOperateResultNotLike(String value) {
            addCriterion("operate_result not like", value, "operateResult");
            return (Criteria) this;
        }

        public Criteria andOperateResultIn(List<String> values) {
            addCriterion("operate_result in", values, "operateResult");
            return (Criteria) this;
        }

        public Criteria andOperateResultNotIn(List<String> values) {
            addCriterion("operate_result not in", values, "operateResult");
            return (Criteria) this;
        }

        public Criteria andOperateResultBetween(String value1, String value2) {
            addCriterion("operate_result between", value1, value2, "operateResult");
            return (Criteria) this;
        }

        public Criteria andOperateResultNotBetween(String value1, String value2) {
            addCriterion("operate_result not between", value1, value2, "operateResult");
            return (Criteria) this;
        }

        public Criteria andOperateUserIdIsNull() {
            addCriterion("operate_user_id is null");
            return (Criteria) this;
        }

        public Criteria andOperateUserIdIsNotNull() {
            addCriterion("operate_user_id is not null");
            return (Criteria) this;
        }

        public Criteria andOperateUserIdEqualTo(Integer value) {
            addCriterion("operate_user_id =", value, "operateUserId");
            return (Criteria) this;
        }

        public Criteria andOperateUserIdNotEqualTo(Integer value) {
            addCriterion("operate_user_id <>", value, "operateUserId");
            return (Criteria) this;
        }

        public Criteria andOperateUserIdGreaterThan(Integer value) {
            addCriterion("operate_user_id >", value, "operateUserId");
            return (Criteria) this;
        }

        public Criteria andOperateUserIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("operate_user_id >=", value, "operateUserId");
            return (Criteria) this;
        }

        public Criteria andOperateUserIdLessThan(Integer value) {
            addCriterion("operate_user_id <", value, "operateUserId");
            return (Criteria) this;
        }

        public Criteria andOperateUserIdLessThanOrEqualTo(Integer value) {
            addCriterion("operate_user_id <=", value, "operateUserId");
            return (Criteria) this;
        }

        public Criteria andOperateUserIdIn(List<Integer> values) {
            addCriterion("operate_user_id in", values, "operateUserId");
            return (Criteria) this;
        }

        public Criteria andOperateUserIdNotIn(List<Integer> values) {
            addCriterion("operate_user_id not in", values, "operateUserId");
            return (Criteria) this;
        }

        public Criteria andOperateUserIdBetween(Integer value1, Integer value2) {
            addCriterion("operate_user_id between", value1, value2, "operateUserId");
            return (Criteria) this;
        }

        public Criteria andOperateUserIdNotBetween(Integer value1, Integer value2) {
            addCriterion("operate_user_id not between", value1, value2, "operateUserId");
            return (Criteria) this;
        }

        public Criteria andOperateUserNameIsNull() {
            addCriterion("operate_user_name is null");
            return (Criteria) this;
        }

        public Criteria andOperateUserNameIsNotNull() {
            addCriterion("operate_user_name is not null");
            return (Criteria) this;
        }

        public Criteria andOperateUserNameEqualTo(String value) {
            addCriterion("operate_user_name =", value, "operateUserName");
            return (Criteria) this;
        }

        public Criteria andOperateUserNameNotEqualTo(String value) {
            addCriterion("operate_user_name <>", value, "operateUserName");
            return (Criteria) this;
        }

        public Criteria andOperateUserNameGreaterThan(String value) {
            addCriterion("operate_user_name >", value, "operateUserName");
            return (Criteria) this;
        }

        public Criteria andOperateUserNameGreaterThanOrEqualTo(String value) {
            addCriterion("operate_user_name >=", value, "operateUserName");
            return (Criteria) this;
        }

        public Criteria andOperateUserNameLessThan(String value) {
            addCriterion("operate_user_name <", value, "operateUserName");
            return (Criteria) this;
        }

        public Criteria andOperateUserNameLessThanOrEqualTo(String value) {
            addCriterion("operate_user_name <=", value, "operateUserName");
            return (Criteria) this;
        }

        public Criteria andOperateUserNameLike(String value) {
            addCriterion("operate_user_name like", value, "operateUserName");
            return (Criteria) this;
        }

        public Criteria andOperateUserNameNotLike(String value) {
            addCriterion("operate_user_name not like", value, "operateUserName");
            return (Criteria) this;
        }

        public Criteria andOperateUserNameIn(List<String> values) {
            addCriterion("operate_user_name in", values, "operateUserName");
            return (Criteria) this;
        }

        public Criteria andOperateUserNameNotIn(List<String> values) {
            addCriterion("operate_user_name not in", values, "operateUserName");
            return (Criteria) this;
        }

        public Criteria andOperateUserNameBetween(String value1, String value2) {
            addCriterion("operate_user_name between", value1, value2, "operateUserName");
            return (Criteria) this;
        }

        public Criteria andOperateUserNameNotBetween(String value1, String value2) {
            addCriterion("operate_user_name not between", value1, value2, "operateUserName");
            return (Criteria) this;
        }

        public Criteria andOperateRealNameIsNull() {
            addCriterion("operate_real_name is null");
            return (Criteria) this;
        }

        public Criteria andOperateRealNameIsNotNull() {
            addCriterion("operate_real_name is not null");
            return (Criteria) this;
        }

        public Criteria andOperateRealNameEqualTo(String value) {
            addCriterion("operate_real_name =", value, "operateRealName");
            return (Criteria) this;
        }

        public Criteria andOperateRealNameNotEqualTo(String value) {
            addCriterion("operate_real_name <>", value, "operateRealName");
            return (Criteria) this;
        }

        public Criteria andOperateRealNameGreaterThan(String value) {
            addCriterion("operate_real_name >", value, "operateRealName");
            return (Criteria) this;
        }

        public Criteria andOperateRealNameGreaterThanOrEqualTo(String value) {
            addCriterion("operate_real_name >=", value, "operateRealName");
            return (Criteria) this;
        }

        public Criteria andOperateRealNameLessThan(String value) {
            addCriterion("operate_real_name <", value, "operateRealName");
            return (Criteria) this;
        }

        public Criteria andOperateRealNameLessThanOrEqualTo(String value) {
            addCriterion("operate_real_name <=", value, "operateRealName");
            return (Criteria) this;
        }

        public Criteria andOperateRealNameLike(String value) {
            addCriterion("operate_real_name like", value, "operateRealName");
            return (Criteria) this;
        }

        public Criteria andOperateRealNameNotLike(String value) {
            addCriterion("operate_real_name not like", value, "operateRealName");
            return (Criteria) this;
        }

        public Criteria andOperateRealNameIn(List<String> values) {
            addCriterion("operate_real_name in", values, "operateRealName");
            return (Criteria) this;
        }

        public Criteria andOperateRealNameNotIn(List<String> values) {
            addCriterion("operate_real_name not in", values, "operateRealName");
            return (Criteria) this;
        }

        public Criteria andOperateRealNameBetween(String value1, String value2) {
            addCriterion("operate_real_name between", value1, value2, "operateRealName");
            return (Criteria) this;
        }

        public Criteria andOperateRealNameNotBetween(String value1, String value2) {
            addCriterion("operate_real_name not between", value1, value2, "operateRealName");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNull() {
            addCriterion("create_time is null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNotNull() {
            addCriterion("create_time is not null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeEqualTo(Date value) {
            addCriterion("create_time =", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotEqualTo(Date value) {
            addCriterion("create_time <>", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThan(Date value) {
            addCriterion("create_time >", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("create_time >=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThan(Date value) {
            addCriterion("create_time <", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThanOrEqualTo(Date value) {
            addCriterion("create_time <=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIn(List<Date> values) {
            addCriterion("create_time in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotIn(List<Date> values) {
            addCriterion("create_time not in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeBetween(Date value1, Date value2) {
            addCriterion("create_time between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotBetween(Date value1, Date value2) {
            addCriterion("create_time not between", value1, value2, "createTime");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}