package com.ruida.cloud.dao;

import com.ruida.cloud.model.XiaogjCourseLessonRel;
import com.ruida.cloud.model.XiaogjCourseLessonRelExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface XiaogjCourseLessonRelMapper {
    int countByExample(XiaogjCourseLessonRelExample example);

    int deleteByExample(XiaogjCourseLessonRelExample example);

    int deleteByPrimaryKey(Integer rid);

    int insert(XiaogjCourseLessonRel record);

    int insertSelective(XiaogjCourseLessonRel record);

    List<XiaogjCourseLessonRel> selectByExample(XiaogjCourseLessonRelExample example);

    XiaogjCourseLessonRel selectByPrimaryKey(Integer rid);

    int updateByExampleSelective(@Param("record") XiaogjCourseLessonRel record, @Param("example") XiaogjCourseLessonRelExample example);

    int updateByExample(@Param("record") XiaogjCourseLessonRel record, @Param("example") XiaogjCourseLessonRelExample example);

    int updateByPrimaryKeySelective(XiaogjCourseLessonRel record);

    int updateByPrimaryKey(XiaogjCourseLessonRel record);
}