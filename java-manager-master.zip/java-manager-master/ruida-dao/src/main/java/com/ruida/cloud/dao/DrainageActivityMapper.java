package com.ruida.cloud.dao;

import com.ruida.cloud.model.DrainageActivity;
import com.ruida.cloud.model.DrainageActivityExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface DrainageActivityMapper {
    long countByExample(DrainageActivityExample example);

    int deleteByExample(DrainageActivityExample example);

    int deleteByPrimaryKey(Integer drainageActivityId);

    int insert(DrainageActivity record);

    int insertSelective(DrainageActivity record);

    List<DrainageActivity> selectByExample(DrainageActivityExample example);

    DrainageActivity selectByPrimaryKey(Integer drainageActivityId);

    int updateByExampleSelective(@Param("record") DrainageActivity record, @Param("example") DrainageActivityExample example);

    int updateByExample(@Param("record") DrainageActivity record, @Param("example") DrainageActivityExample example);

    int updateByPrimaryKeySelective(DrainageActivity record);

    int updateByPrimaryKey(DrainageActivity record);
}