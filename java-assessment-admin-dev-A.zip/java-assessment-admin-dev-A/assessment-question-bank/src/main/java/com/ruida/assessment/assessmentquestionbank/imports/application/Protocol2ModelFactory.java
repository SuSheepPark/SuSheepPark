package com.ruida.assessment.assessmentquestionbank.imports.application;

import java.util.List;
import java.util.stream.Collectors;

import javax.inject.Inject;
import javax.inject.Named;

import com.ruida.assessment.assessmentquestionbank.imports.domain.model.Question;
import com.ruida.assessment.assessmentquestionbank.imports.domain.service.Protocol2ModelService;
import com.ruida.assessment.assessmentquestionbank.vo.QuestionInfoVO;

/**
 * 将协议对象转换为业务数据对象
 * @author mazhuang
 *
 */
@Named
public class Protocol2ModelFactory {

	@Inject
	Protocol2ModelService protocol2ModelService;

	public List<QuestionInfoVO> parse2QuestionLibraries(List<Question> protocolQuestions) {
		return protocolQuestions.stream().map(x -> protocol2ModelService.parseQuestionLibrary(x)).filter(x -> x != null)
				.collect(Collectors.toList());
	}
}
