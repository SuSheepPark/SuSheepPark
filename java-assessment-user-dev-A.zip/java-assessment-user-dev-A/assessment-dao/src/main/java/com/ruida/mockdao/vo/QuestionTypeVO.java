package com.ruida.mockdao.vo;

import lombok.Data;

/**
 * @description: 题型VO
 * @author: chenjy
 * @create: 2020-08-03 14:09
 */
@Data
public class QuestionTypeVO {

    /**
     * 题型名称
     */
    private String questionTypeName;

    /**
     * 数量
     */
    private Integer amount;

    /**
     * 总分
     */
    private Double totalScore;
}
