package com.ruida.mockcommon.util;

import org.apache.commons.lang3.StringUtils;

/**
 * Created by xumingqi on 2021/7/13 8:46
 */
public class SensitiveUtil {
    /**
     * 手机号脱敏筛选正则
     */
    public static final String PHONE_REGEX = "(\\d{3})\\d{4}(\\d{4})";

    /**
     * 手机号脱敏替换正则
     */
    public static final String PHONE_REPLACE_REGEX = "$1****$2";

    /**
     * 身份证号脱敏筛选正则
     */
    public static final String ID_CARD_REGEX = "(\\w{6})\\w*(\\w{4})";

    /**
     * 手机号脱敏处理
     */
    public static String desensitizePhone(String phone) {
        return StringUtils.isEmpty(phone) ? "" : phone.replaceAll(PHONE_REGEX, PHONE_REPLACE_REGEX);
    }

    public static String desensitizeIdCard(String idCard) {
        if (!StringUtils.isEmpty(idCard)) {
            if (idCard.length() == 15) {
                idCard = idCard.replaceAll(ID_CARD_REGEX, "$1*****$2");
            }
            if (idCard.length() == 18) {
                idCard = idCard.replaceAll(ID_CARD_REGEX, "$1********$2");
            }
        }
        return idCard;
    }
}
