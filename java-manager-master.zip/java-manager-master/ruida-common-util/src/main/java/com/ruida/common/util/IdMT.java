package com.ruida.common.util;

import org.apache.commons.lang3.RandomStringUtils;

public class IdMT {

	public static String yearPrefix(String prefix,int length) {
		return prefix + DateMT.getYear() + RandomStringUtils.randomNumeric(length);
	}
}
