package com.ruida.mockdao.dao;

import com.ruida.mockdao.dto.ReportDTO;
import com.ruida.mockdao.model.StudentRelInfo;
import com.ruida.mockdao.model.TTestPaperProductTask;
import com.ruida.mockdao.vo.KnowledgeVO;
import com.ruida.mockdao.vo.TargetStatVO;
import com.ruida.mockdao.vo.report.*;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface ReportMapper {

    /**
     * 报告基础信息
     * @param reportDTO
     * @return
     */
    ReportVO selectReportBasicInfo(@Param("req") ReportDTO reportDTO);

    /**
     * 联考排名
     * @param reportDTO
     * @return
     */
    List<ReportRank> getUnionRank(@Param("req") ReportDTO reportDTO);

    /**
     * 9+1排名
     * @param reportDTO
     * @return
     */
    List<ReportRank> getNineOneSchoolRank(@Param("req") ReportDTO reportDTO);

    /**
     * 学校排名
     * @param reportDTO
     * @return
     */
    List<ReportRank> getSchoolRank(@Param("req") ReportDTO reportDTO);

    /**
     * 班级排名
     * @param reportDTO
     * @return
     */
    List<ReportRank> getClassRank(@Param("req") ReportDTO reportDTO);

    /**
     * 查询得分信息
     * @param reportDTO
     * @return
     */
    ReportVO getReportScoreInfo(@Param("req") ReportDTO reportDTO);

    /**
     * 查询9+1学校得分信息
     * @param reportDTO
     * @return
     */
    ReportVO getNineOneSchoolScoreInfo(@Param("req") ReportDTO reportDTO);

    /**
     * 查询报告试题信息
     * @param reportDTO
     * @return
     */
    List<ReportQuestionKnowledgeVO> selectReportQuestionInfo(@Param("req") ReportDTO reportDTO);

    /**
     * 查询报告的题型情况
     * @param reportDTO
     * @return
     */
    List<ReportQuestionTypeVO> selectReportQuestionTypeList(@Param("req") ReportDTO reportDTO);

    /**
     * 获取历次测试得分情况
     * @param reportDTO
     * @return
     */
    List<ReportVO> getHistoryReport(@Param("req") ReportDTO reportDTO);

    /**
     * 根据考试id和父级知识点获取知识点列表
     * @param pid
     * @param examRecordIdList
     * @return
     */
    List<KnowledgeVO> getReportKnowledgeByPid(@Param("pidList") List<Integer> pid, @Param("examRecordIdList") List<Integer> examRecordIdList);

    /**
     * 根据考试id获取考核目标列表
     * @param examRecordIdList
     * @return
     */
    List<TargetStatVO> getReportTarget(@Param("examRecordIdList") List<Integer> examRecordIdList);

    /**
     * 根据用户id查询9+1学校学生数量
     * @param reportDTO
     * @return
     */
    int getNineOneSchoolStudent(@Param("req") ReportDTO reportDTO);

    /**
     * 查询试卷的9+1商品id
     * @param reportDTO
     * @return
     */
    Integer getNineOneProductId(@Param("req") ReportDTO reportDTO);

    /**
     * 获取商品试卷的报告计算任务
     * @param reportDTO
     * @return
     */
    TTestPaperProductTask getTestPaperProductTask(@Param("req") ReportDTO reportDTO);

    /**
     * 查询测试次数
     * @param reportDTO
     * @return
     */
    List<TestCountVO> getTestCount(@Param("req") ReportDTO reportDTO);

    /**
     * 分页查询已经生成报告的实施计划列表
     * @param reportDTO
     * @return
     */
    List<ImplementPlanVO> getReportFinishedImplementPlanList(@Param("req") ReportDTO reportDTO);

    /**
     * 查询已经生成报告的实施计划总数
     * @param reportDTO
     * @return
     */
    Integer getReportFinishedImplementPlanCount(@Param("req") ReportDTO reportDTO);

    /**
     * 根据实施计划、准考证号查询场次科目列表
     * @param planId
     * @param stuId
     * @return
     */
    List<SceneVO> getSceneSubjectList(@Param("planId") String planId, @Param("stuId") Integer stuId);
    
    /**
     * 根据场次获取统考、联考参与考试的所有学校
     * @param sceneId
     * @return
     */
    List<StudentRelInfo> selectExamRecordSchool(String sceneId);
}
