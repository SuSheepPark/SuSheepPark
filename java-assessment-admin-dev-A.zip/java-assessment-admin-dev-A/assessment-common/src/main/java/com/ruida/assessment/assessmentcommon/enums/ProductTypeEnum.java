package com.ruida.assessment.assessmentcommon.enums;

/**
 * @description: 商品类型枚举
 * @author: kgz
 * @date: 2020/8/7
 */
public enum ProductTypeEnum {
    SINGLE_PAPER(0, "试卷"),
    WISH_FILLING_REPORT(4, "志愿填报报告");

    private Integer K;
    private String V;

    ProductTypeEnum(Integer k, String v) {
        K = k;
        V = v;
    }

    public Integer getK() {
        return K;
    }

    public void setK(Integer k) {
        K = k;
    }

    public String getV() {
        return V;
    }

    public void setV(String v) {
        V = v;
    }

    public static ProductTypeEnum getValueById(Integer K){
        if(K != null){
            for(ProductTypeEnum productTypeEnum : ProductTypeEnum.values() ){
                if(productTypeEnum.getK().equals(K)){
                    return  productTypeEnum;
                }
            }
        }
        return null;
    }

}
