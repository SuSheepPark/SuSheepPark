package com.ruida.mockcommon.entity;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @description: node节点
 * @author: chenjy
 * @create: 2020-08-12 16:05
 */
@Data
public class TreeNode implements Serializable {

    private int id;

    private int pid;

    private String name;

    private List<TreeNode> children;
}
