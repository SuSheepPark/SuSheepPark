/**   
 * Copyright © 2019 公司名. All rights reserved.
 * 
 * @Title: ChannelService.java 
 * @Prject: zhaowei-cms
 * @Package: com.zhaowei.cms.service 
 * @Description: TODO
 * @author: zw   
 * @date: 2019年9月17日 下午8:39:58 
 * @version: V1.0   
 */
package com.zhaowei.cms.service;

import java.util.List;

import com.zhaowei.cms.domain.Channel;


public interface ChannelService {

	/**
	 * @Title: selects 
	 * @Description:查询所有的栏目
	 * @return
	 * @return: List<Channel>
	 */
	List<Channel> selects();
	
}
