package com.ruida.assessment.assessmentcommon.enums;

/**
 * @description:
 * @author: kgz
 * @date: 2020/7/30
 */
public enum MessagePurposeEnum {
    STUDENT(0,"学员"),
    PRODUCT(1,"商品"),

    ;


    private Integer K;
    private String V;

    MessagePurposeEnum(Integer k, String v) {
        K = k;
        V = v;
    }

    public Integer getK() {
        return K;
    }

    public void setK(Integer k) {
        K = k;
    }

    public String getV() {
        return V;
    }

    public void setV(String v) {
        V = v;
    }


    public static MessagePurposeEnum getValueById(Integer K){
        for(MessagePurposeEnum messagePurposeEnum : MessagePurposeEnum.values() ){
            if(messagePurposeEnum.getK().equals(K)){
                return  messagePurposeEnum;
            }
        }
        return null;
    }

}
