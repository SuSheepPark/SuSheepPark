package com.ruida.assessment.assessmentcommon.enums;

/**
 * @description: 预售枚举类
 * @author: wy
 * @date: 2021/7/2
 */
public enum PresellEnum {
    NOT_PRESELL(0,"非预售"),
    PRESELL(1,"预售"),
    ;

    private Integer K;
    private String V;

    PresellEnum(Integer k, String v) {
        K = k;
        V = v;
    }

    public Integer getK() {
        return K;
    }

    public void setK(Integer k) {
        K = k;
    }

    public String getV() {
        return V;
    }

    public void setV(String v) {
        V = v;
    }

    public static PresellEnum getValueById(Integer K){
        if(K != null){
            for(PresellEnum deleteStatusEnum : PresellEnum.values() ){
                if(deleteStatusEnum.getK().equals(K)){
                    return  deleteStatusEnum;
                }
            }
        }
        return null;
    }

}
