package com.ruida.assessment.assessmentquestionbank.controller;

import com.google.common.collect.Lists;
import com.ruida.assessment.assessmentcommon.auth.context.BaseContextHandle;
import com.ruida.assessment.assessmentcommon.auth.pojo.JWTInfo;
import com.ruida.assessment.assessmentcommon.enums.OperateModuleEnum;
import com.ruida.assessment.assessmentcommon.enums.OperateTypeEnum;
import com.ruida.assessment.assessmentcommon.enums.SourceChannelEnum;
import com.ruida.assessment.assessmentcommon.exception.CoreException;
import com.ruida.assessment.assessmentcommon.result.*;
import com.ruida.assessment.assessmentcommon.util.RegexUtils;
import com.ruida.assessment.assessmentcommon.util.ValidateMT;
import com.ruida.assessment.assessmentcommon.util.excel.ExportExcelUtils;
import com.ruida.assessment.assessmentquestionbank.SystemConstant;
import com.ruida.assessment.assessmentquestionbank.annotaion.OperateLog;
import com.ruida.assessment.assessmentquestionbank.annotaion.UserAuth;
import com.ruida.assessment.assessmentquestionbank.dto.BatchOperationRequest;
import com.ruida.assessment.assessmentquestionbank.dto.EditUserRequest;
import com.ruida.assessment.assessmentquestionbank.dto.UserBoundStudentRequest;
import com.ruida.assessment.assessmentquestionbank.dto.UserQueryRequest;
import com.ruida.assessment.assessmentquestionbank.model.TUserPeriodSubject;
import com.ruida.assessment.assessmentquestionbank.ruidacloudDao.SysUserMapper;
import com.ruida.assessment.assessmentquestionbank.service.SysCryptoService;
import com.ruida.assessment.assessmentquestionbank.service.SysUserService;
import com.ruida.assessment.assessmentquestionbank.service.UserPeriodSubjectService;
import com.ruida.assessment.assessmentquestionbank.service.ruidaCloud.SysMenuService;
import com.ruida.assessment.assessmentquestionbank.service.ruidaCloud.UserService;
import com.ruida.assessment.assessmentquestionbank.service.ruidaCloud.UserServiceImpl;
import com.ruida.assessment.assessmentquestionbank.vo.OrderListVO;
import com.ruida.assessment.assessmentquestionbank.vo.UserInfoVo;
import com.ruida.assessment.assessmentquestionbank.vo.UserVo;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.lang.StringUtils;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.inject.Inject;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/user")
public class UserController {
    @Resource
    SysUserService sysUserService;
    @Resource
    UserPeriodSubjectService userPeriodSubjectService;
    @Resource
    private SysMenuService sysMenuService;
    @Resource
    private UserService userService;
    @Inject
    private SysCryptoService cryptoService;
    @Resource
    private SysUserMapper sysUserMapper;
    @Resource
    private UserServiceImpl userServiceImpl;

    /**
     * @param username
     * @param password
     * @param source
     * @return 用户登录
     */
    @PostMapping("login")
    @OperateLog(module = OperateModuleEnum.ACCOUNT_M, operateType = OperateTypeEnum.LOGIN)
    public MapResult<String, Object> login(@RequestParam("username") String username,
                                           @RequestParam("password") String password,
                                           @RequestParam("source") String source,
                                           @RequestParam("isExistenceLogin")  boolean isExistenceLogin,
                                           @RequestParam(required = false,value = "deviceNo")String deviceNo) throws Exception {

        if (StringUtils.isBlank(username)) {
            throw new CoreException("500", "请输入用户名");
        }
        if (StringUtils.isBlank(password)) {
            throw new CoreException("500", "请输入密码");
        }
//        if(StringUtils.equals(source,"2") || StringUtils.equals(source,"3")){
//             if(StringUtils.isBlank(deviceNo)){
//                 throw new CoreException("500", "设备号不能为空");
//             }
//        }
        //去掉username中的空格后登录
        return sysUserService.login(username.replace(" ", ""), password, source,isExistenceLogin,deviceNo);
    }

    //@RequiresRoles("")
    @RequestMapping("getUserList")
    @ResponseBody
    @UserAuth
    public PageResult getUserList(Integer pageNum, String userName,Integer roleId, Integer departmentId,String searchWord) {
        PageResult pageResult = new PageResult();
        pageNum = pageNum == null ? 1 : pageNum;
        Page page = new Page();
        page.setCurrentPage(pageNum);
        page.setPageSize(SystemConstant.DEFAULT_PAGE_SIZE);
        Map param = new HashMap();
        param.put("roleId",roleId);
        param.put("departmentId",departmentId);
        param.put("searchWord",searchWord);
        param.put("userName",userName);
        //如果验证为手机号则加密后去匹配数据库
        if(StringUtils.isNotEmpty(searchWord)){
            if(RegexUtils.isMobile(searchWord)){
                param.put("telephone",cryptoService.AESEncode(searchWord));
            }
        }
        PageData pageData = userService.getUserList(page, param);
        page.setResult(pageData.getRows());
        page.setTotalCount(Integer.parseInt(String.valueOf(pageData.getTotal()))  );
        pageResult.setContent(page);
        return pageResult;
    }

    /**
     * 获取所有的角色
     *
     * @return
     */
    @RequestMapping("getRoleList")
    @ResponseBody
    @UserAuth
    public ListResult getRoleList() {
        ListResult result = new ListResult();
        List<Map<String, Object>> list = userService.getRoleList();
        result.setContent(list);
        return result;
    }

    /**l
     * 获取所有的角色
     *
     * @return
     */
    @RequestMapping("getRoleListByDetpId")
    @ResponseBody
    @UserAuth
    public ListResult getRoleListByDetpId(Integer deptId) {
        ListResult result = new ListResult();
        List<Map<String, Object>> list = userService.getRoleListByDeptId(deptId);
        result.setContent(list);
        return result;
    }


    /**
     * 获取所有 部门
     *
     * @return
     */

    @RequestMapping("getDeptList")
    @ResponseBody
    @UserAuth
    public ListResult getDeptList() {
        ListResult listResult = new ListResult();
        List<Map<String, Object>> list = userService.getDeptList();
        listResult.setContent(list);

        return listResult;
    }

    /**
     * 添加用户
     *
     * @return
     */
    @RequestMapping("add")
    @ResponseBody
    @UserAuth
    @OperateLog(module = OperateModuleEnum.ACCOUNT_M, operateType = OperateTypeEnum.ADD)
    public PojoResult add(@RequestBody EditUserRequest request) {
        PojoResult pojoResult = new PojoResult();

        if (userService.add(request.getRealName(), request.getTelephone(),request.getUserRoleRelationList() ,request.getSecuId())!=null) {
            pojoResult.setContent("用户添加成功，初始密码为123456");
            return pojoResult;
        } else {
            throw new CoreException("500", "保存失败");
        }
    }
    /**
     * 编辑用户
     *
     * @return
     */
    @RequestMapping("editUser")
    @ResponseBody
    @UserAuth
    @OperateLog(module = OperateModuleEnum.ACCOUNT_M, operateType = OperateTypeEnum.EDIT)
    public PojoResult editUser(@RequestBody EditUserRequest request) {
        PojoResult pojoResult = new PojoResult();
        if (userService.editUser(request.getUserId(), request.getRealName(), request.getTelephone(), request.getUserRoleRelationList(),
                request.getIsAdd(),request.getSecuId())) {
            pojoResult.setContent("操作成功");
            return  pojoResult;
        } else {
            throw new CoreException("500", "保存失败");
        }
    }
    @RequestMapping("deleteUser")
    @ResponseBody
    @UserAuth
    @OperateLog(module = OperateModuleEnum.ACCOUNT_M, operateType = OperateTypeEnum.DELETE)
    public PojoResult deleteUser(@RequestParam(value = "userId") Integer userId) {
        PojoResult pojoResult = new PojoResult();
        if (userService.deleteUser(userId)) {
            pojoResult.setContent("删除成功");
            return  pojoResult;
        } else {

            throw new CoreException("500", "删除失败");
        }
    }

    @RequestMapping("deleteUserByAdminDeptId")
    @ResponseBody
    @UserAuth
    public PojoResult deleteUserByAdminDeptId(@RequestParam(value = "userId") Integer userId) {
        PojoResult pojoResult = new PojoResult();
        if (userService.deleteUserByAdminDeptId(userId)) {
            pojoResult.setContent("删除成功");
            return pojoResult;
        } else {
            throw new CoreException("500", "删除失败");
        }
    }

    @RequestMapping("updateStatus")
    @ResponseBody
    @UserAuth
    @OperateLog(module = OperateModuleEnum.ACCOUNT_M, operateType = OperateTypeEnum.STOP_START)
    public PojoResult updateStatus(@RequestParam(value = "userId") Integer userId, Integer status) {
        PojoResult pojoResult = new PojoResult();
        if (userService.updateStatus(userId, status)) {
            String test = "";
            if(status == 0 ){
                test = "启用成功";
            }else{
                test = "禁用成功";
            }
            pojoResult.setContent(test);
            return pojoResult;
        } else {
            throw new CoreException("500", "操作失败");
        }
    }

    @RequestMapping("getDeptRoleTree")
    @ResponseBody
    @UserAuth
    public ListResult getDeptRoleTree() {
        ListResult listResult = new ListResult();
        JWTInfo userInfo = BaseContextHandle.getJWTInfo();
        List<Map<String, Object>> list = new ArrayList<>();
        if(userService.isAdmin(Integer.valueOf(userInfo.getUserId()))){
            List<Map<String, Object>> deptList = userService.getDeptList();
            for (Map<String, Object> dept : deptList) {
                Map<String, Object> map = new HashMap<>();
                List<Map<String, Object>> roles =
                        userService.getRoleListByDeptId((Integer) dept.get("departmentId"));
                map.put("key", dept.get("departmentId"));
                map.put("value", dept.get("departmentId"));
                map.put("title", dept.get("departmentName"));
                List<Map<String, Object>> children = Lists.newArrayList();
                for (Map<String, Object> param : roles) {
                    Map<String, Object> result = new HashMap<>();
                    result.put("key", dept.get("departmentId")+"-"+param.get("roleId"));
                    result.put("value", dept.get("departmentId")+"-"+param.get("roleId"));
                    result.put("title", param.get("roleName"));
                   /* if(param.get("roleType").equals(Integer.valueOf(0)) ){
                        continue;
                    }*/ //放开超级管理员角色返回
                    children.add(result);
                }
                map.put("children", children);
                list.add(map);
            }
        }else{

            Map<String, Object> map = new HashMap<>();
            List<Map<String, Object>> roles =
                    userService.getRoleListByDeptId(Integer.valueOf(userInfo.getDeptId()) );
            map.put("key", userInfo.getDeptId());
            map.put("value", userInfo.getDeptId());
            map.put("title", "");
            List<Map<String, Object>> children = Lists.newArrayList();
            for (Map<String, Object> param : roles) {
                Map<String, Object> result = new HashMap<>();
                result.put("key", userInfo.getDeptId()+"-"+param.get("roleId"));
                result.put("value", userInfo.getDeptId()+"-"+param.get("roleId"));
                result.put("title", param.get("roleName"));
                if(param.get("roleType").equals(Integer.valueOf(0))){
                    continue;
                }
                children.add(result);
            }
            map.put("children", children);
            list.add(map);
        }
        listResult.setContent(list);
        return listResult;
    }

    @RequestMapping("getUserInfoByUserId")
    @ResponseBody
    @UserAuth
    public MapResult getUserInfoByUserId(Integer userId) {
        MapResult result = new MapResult();
        result.setContent(userService.getUserInfoByUserId(userId));
        return result;
    }
    /**
     * 菜单列表
     * @return
     */
    @RequestMapping(value={"/menuList", ""})
    @ResponseBody
    @UserAuth
    public MapResult menuList() {
        MapResult mapResult = new MapResult();
        Map<String,Object> menuListWithoutBtn = sysMenuService.getUserMenuListAndButtonPermission();
        mapResult.setContent(menuListWithoutBtn);
        return mapResult;
    }

    @RequestMapping("getUserPeriodSubjectByUserId")
    @ResponseBody
    @UserAuth
    public ListResult getUserPeriodSubjectByUserId() {
        ListResult result = new ListResult();
        result.setContent(userPeriodSubjectService.getList());
        return result;
    }
    @RequestMapping("addUserPeriodSubject")
    @ResponseBody
    @UserAuth
    public PojoResult<Boolean> addUserPeriodSubject(@RequestBody List<TUserPeriodSubject> list) {
        PojoResult result = new PojoResult();
        result.setContent(userService.addUserPeriodSubject(list));
        return result;
    }

    /**
     * 获取老师列表
     * @return
     */
    @RequestMapping("getTeacherList")
    public ListResult getTeacherList(){
        ListResult result = new ListResult();
     List<Map<String,Object>> resultList =  userService.getTeacherUserList();
     result.setContent(resultList);
     return result;
    }

    /**
     * 用户信息获取
     * @return
     */
    @RequestMapping("userDetailInfo")
    @UserAuth
    public MapResult userDetailInfo(){
        MapResult result = new MapResult();
       Map<String,Object> resultMap =  userService.userDetailInfo();
        result.setContent(resultMap);
        return result;
    }
    /**
     * @param oldPwd
     * @param newPwd
     * @return 修改密码
     */
    @PostMapping("updatePassword")
    @UserAuth
    @ApiOperation(value = "修改密码", notes = "修改密码")
    @ApiImplicitParams(
            {
                    @ApiImplicitParam(name = "oldPwd" ,value = "老密码",dataType = "String",required = true,paramType = "form"),
                    @ApiImplicitParam(name = "newPwd" ,value = "新密码",dataType = "String",required = true,paramType = "form")
            }
    )
    @OperateLog(module = OperateModuleEnum.ACCOUNT_M, operateType = OperateTypeEnum.MODIFY_PWD)
    public BaseResult updatePassword(@RequestParam("oldPwd") String oldPwd,
                                     @RequestParam("newPwd") String newPwd) throws Exception {
        if (userService.revisePassword(oldPwd, newPwd)) {
            BaseResult baseResult = new BaseResult();
            baseResult.setMsg("修改密码成功");
            return baseResult;
        } else {
            throw new CoreException("500", "修改密码失败");
        }
    }

    /**
     * @return 重置密码
     */
    @PostMapping("resetPassword")
    @UserAuth
    @ApiOperation(value = "重置密码", notes = "重置密码")
    @ApiImplicitParams(
            {
                    @ApiImplicitParam(name = "userId" ,value = "用户id",dataType = "Integer",required = true,paramType = "form")

            }
    )
    @OperateLog(module = OperateModuleEnum.ACCOUNT_M, operateType = OperateTypeEnum.RESET_PWD)
    public BaseResult resetPassword(@RequestParam("userId") Integer userId
                                    ) {
        if (userService.resetPassword(userId)) {
            BaseResult baseResult = new BaseResult();
            baseResult.setMsg("重置密码成功，密码重置为123456！");
            return baseResult;
        } else {
            throw new CoreException("500", "重置密码失败");
        }
    }

    /**
     *   用户管理列表条件查询
     * @param request
     * @return
     */
    @UserAuth
    @PostMapping("query/userList")
    public PojoResult queryUserList(@RequestBody UserQueryRequest request){
        PageData<UserVo> userVos = userService.queryUserList(request);
        PojoResult<PageData> result = new PojoResult<>();
        result.setContent(userVos);
        return result;
    }

    /**
     * 导出用户列表
     * @param request
     * @param response
     * @return
     */
    @UserAuth
    @RequestMapping(value = "excel/exportUserList")
    public void exportUserList(@RequestBody UserQueryRequest request, HttpServletResponse response) {
        //如果验证为手机号则加密后去匹配数据库
        if (RegexUtils.isTelephone(request.getSearchWord())) {
            request.setTelephone(cryptoService.AESEncode(request.getSearchWord()));
        }
        //得到所有要导出的数据
        List<UserVo> userList = sysUserMapper.queryUserList(request);
        for (UserVo userVo : userList) {
            //处理手机号
            userVo.setTelephone(userServiceImpl.processData(userVo));
            userVo.setIsboundStuStr(userVo.getBoundStuNum() == 0 ? "否" : "是");
            userVo.setIsboundWeChatStr(userVo.getIsboundWeChat().equals(0) ? "否" : "是");
            userVo.setSourceName(SourceChannelEnum.getNameByCode(userVo.getSource()));
            userVo.setStatusStr(ValidateMT.isNotNull(userVo.getStatus()) && userVo.getStatus().equals(0) ? "禁用" : "启用");

        }
        //定义导出的excel名字
        String excelName = "用户列表";
        //导出相关信息
        new ExportExcelUtils().export(excelName, userList, UserVo.class, response);
    }

    /*
     * 功能描述   批量禁用、启用用户
     * @param
     * @return
     */
    @UserAuth
    @PostMapping("update/batchUpdateStatus")
    public BaseResult batchUpdateStatus(@RequestBody BatchOperationRequest request){
        return userService.batchUpdateStatus(request);
    }

    /*
     * 功能描述   查询用户订单购买记录列表(无分页)
     * @param
     * @return
     */
    @UserAuth
    @GetMapping("query/userOrderList")
    public PojoResult queryuUserOrderList(@RequestParam Integer userId){
        List<OrderListVO> orderList = userService.queryUserOrderList(userId);
        PojoResult result = new PojoResult<>();
        result.setContent(orderList);
        return result;
    }

    /*
     * 功能描述   查询用户信息
     * @param
     * @return
     */
    @UserAuth
    @GetMapping("query/userInfo")
    public PojoResult queryUserInfo(@RequestParam Integer userId) {
        UserInfoVo userInfoVo = userService.queryUserInfo(userId);
        PojoResult<UserInfoVo> result = new PojoResult<>();
        result.setContent(userInfoVo);
        return result;
    }

    /*
     * 功能描述 用户绑定考生
     * @param
     * @return
     */
    @UserAuth
    @PostMapping("bound/boundStudent")
    public BaseResult boundStudent(@RequestBody UserBoundStudentRequest request){
        return userService.userBoundStudent(request);
    }

    /*
     * 功能描述 用户解绑考生
     * @param
     * @return
     */
    @UserAuth
    @PutMapping("unbound/{userId}/{stuId}")
    public BaseResult unboundStudent(@PathVariable Integer userId,@PathVariable Integer stuId){
        return userService.userUnboundStudent(userId,stuId);
    }
}
