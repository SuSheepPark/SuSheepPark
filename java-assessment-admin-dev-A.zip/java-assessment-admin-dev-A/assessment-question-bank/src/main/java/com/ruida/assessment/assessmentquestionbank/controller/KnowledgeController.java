package com.ruida.assessment.assessmentquestionbank.controller;

import com.alibaba.fastjson.JSON;
import com.ruida.assessment.assessmentcommon.enums.ResultStatusCode;
import com.ruida.assessment.assessmentcommon.result.BaseResult;
import com.ruida.assessment.assessmentcommon.result.ListResult;
import com.ruida.assessment.assessmentcommon.result.PojoResult;
import com.ruida.assessment.assessmentquestionbank.annotaion.UserAuth;
import com.ruida.assessment.assessmentquestionbank.dao.KnowledgeMapper;
import com.ruida.assessment.assessmentquestionbank.dto.BatchOperationRequest;
import com.ruida.assessment.assessmentquestionbank.dto.KnowledgeRequest;
import com.ruida.assessment.assessmentquestionbank.dto.MoveTreeRequest;
import com.ruida.assessment.assessmentquestionbank.model.TKnowledge;
import com.ruida.assessment.assessmentquestionbank.service.IKnowledgeService;
import com.ruida.assessment.assessmentquestionbank.vo.KnowledgeTreeVo;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

/**
 * @author wy
 * @description 知识点管理业务层
 * @date 2020/6/10
 */
@RequestMapping("/knowledge")
@RestController
public class KnowledgeController {

    @Resource
    private IKnowledgeService knowledgeService;
    @Resource
    private KnowledgeMapper knowledgeMapper;
    @Resource
    protected RedisTemplate redisTemplate;

    /*
     *功能描述   知识点新增
     * @param
     * @return
     */
    @UserAuth
    @PostMapping("add/addKnowledge")
    public PojoResult addKnowledge(@RequestBody KnowledgeRequest knowledgeRequest){

         PojoResult result = knowledgeService.addKnowledge(knowledgeRequest);
         //更新redis中的树形结构
         knowledgeService.updateKnowledgeRedisData(knowledgeRequest);
         return result;
        /*BaseResult result = new BaseResult();
        result.setMsg("操作成功");
        Integer flag = knowledgeService.addKnowledge(knowledgeRequest);
        if (flag > 0)
            return result;
        if(flag == -1)
            return result.setErrorMessage(ResultStatusCode.SAME_NAME.getCode(),"同级不可同名");
        return result.setErrorMessage(ResultStatusCode.DEAL_FAIL.getCode(),"操作失败");*/
    }

    /*
     *功能描述   查询知识点树形结构
     * @param
     * @return
     */
    @UserAuth
    @PostMapping("query/knowledgeTree")
    public ListResult queryKnowledgeTree(@RequestBody KnowledgeRequest knowledgeRequest){
        List<KnowledgeTreeVo> list = knowledgeService.queryKnowledgeTreeList(knowledgeRequest);
        ListResult<KnowledgeTreeVo> result = new ListResult<>();
        result.setContent(list);
        result.setMsg("成功");
        return result;
    }

    /*
     *功能描述    知识点编辑
     * @param
     * @return
     */
    @UserAuth
    @PostMapping("update/updateKnowledge")
    public BaseResult updateKnowledge(@RequestBody KnowledgeRequest knowledgeRequest){

        BaseResult result = knowledgeService.updateKnowledge(knowledgeRequest);
        return result;
    }


    /*
     *功能描述    批量禁用、启用
     * @param
     * @return
     */
    @UserAuth
    @PostMapping("stop/batchStopKnowledge")
    public BaseResult batchStopKnowledge(@RequestBody BatchOperationRequest batchOperationRequest){
        BaseResult result = new BaseResult();
        result.setMsg("操作成功");
        Boolean flag = knowledgeService.batchStopKnowledge(batchOperationRequest);
        if (flag)
            return result;
        return result.setErrorMessage(ResultStatusCode.DEAL_FAIL.getCode(),"操作失败");
    }

    /*
     *功能描述    单个删除知识点
     * @param
     * @return
     */
    @UserAuth
    @PostMapping("delete/deleteKnowledge")
    public BaseResult deleteKnowledgeById(@RequestBody KnowledgeRequest knowledgeRequest){
        return knowledgeService.deleteKnowledgeById(knowledgeRequest);
    }

    /*
     *功能描述    结构树移动  上移、下移、升级
     * @param
     * @return
     */
    @UserAuth
    @PostMapping("exchange/moveKnowledgeTree")
    public PojoResult moveKnowledgeTree(@RequestBody MoveTreeRequest moveTreeRequest){
        PojoResult result = knowledgeService.moveKnowledgeTree(moveTreeRequest);
        //更新redis中的树形结构
        KnowledgeRequest knowledgeRequest = new KnowledgeRequest();
        TKnowledge knowledge = knowledgeMapper.selectById(moveTreeRequest.getCurrentId());
        knowledgeRequest.setPeriodId(knowledge.getPeriodId());
        knowledgeRequest.setSubjectId(knowledge.getSubjectId());
        knowledgeService.updateKnowledgeRedisData(knowledgeRequest);
        return  result;
    }

    /*
     * 功能描述   批量删除知识点     (一期只实现父节点单选批量删除单个父节点及其所有子集)
     * @param
     * @return
     */
    @UserAuth
    @PostMapping("delete/batchDeleteKnowledge")
    public ListResult batchDeleteKnowledge(@RequestBody KnowledgeRequest request){

        ListResult result = knowledgeService.batchDeleteKnowledge(request);
        List<KnowledgeTreeVo> all = knowledgeMapper.selectTreeColumnList(request);
//            List<KnowledgeTreeVo> allTree = makeTree(all,0,new LinkedList<>());
        redisTemplate.opsForValue().set("knowledge_tree_"+request.getPeriodId()+"_"+request.getSubjectId(), JSON.toJSONString(all));
        return result;
    }
}
