package com.ruida.assessment.assessmentquestionbank.aop;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.ruida.assessment.assessmentcommon.auth.context.BaseContextHandle;
import com.ruida.assessment.assessmentcommon.auth.pojo.JWTInfo;
import com.ruida.assessment.assessmentcommon.auth.utils.JwtTokenUtil;
import com.ruida.assessment.assessmentcommon.enums.AppErrorEnum;
import com.ruida.assessment.assessmentcommon.enums.UserAuthCEnum;
import com.ruida.assessment.assessmentcommon.exception.AuthException;
import com.ruida.assessment.assessmentcommon.exception.CoreException;
import com.ruida.assessment.assessmentcommon.result.BaseResult;
import com.ruida.assessment.assessmentcommon.util.ValidateMT;
import com.ruida.assessment.assessmentquestionbank.SystemConstant;
import com.ruida.assessment.assessmentquestionbank.annotaion.UserAuth;
import com.ruida.assessment.assessmentquestionbank.ruidacloudDao.SysUserMapper;
import org.apache.commons.lang.StringUtils;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.*;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.lang.reflect.Method;
import java.util.Map;

/**
 * @author szl
 * @description: 日志異常統一處理切麵
 * @Date 2018年12月05日
 * @verion 1.0
 */
@Aspect
@Component
public class WebLogAspect {

	private final static Logger LOGGER = LoggerFactory.getLogger(WebLogAspect.class);
	private final static String AUTH_HEADER = "Authorization";
	/**
	 * 处理方法请求的时间
	 */
	ThreadLocal<Long> startTime = new ThreadLocal<Long>();

	@Resource
	RedisTemplate redisTemplate;
	@Resource
	SysUserMapper sysUserMapper;
	/**
	 * strng类型
	 */
	final static String STR_TYPE = "java.lang.String";
	final static String Object = "java.lang.Object";
	final static String ResponseEntity = "org.springframework.http.ResponseEntity";

	/**
	 * controller层切点
	 */
	@Pointcut("execution(public * com.ruida.assessment..*.controller..*.*(..))")
	public void log() {

	}



	@Around("log()")
	public Object around(ProceedingJoinPoint pjp) throws Exception , Throwable{

		// 获取连接点方法运行时的入参列表
		Object result = null;

		// 调用方法名处理
		Signature sign = pjp.getSignature();

		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		MethodSignature msig = null;
		if (!(sign instanceof MethodSignature)) {
			throw new IllegalArgumentException("该注解只能用于方法");
		}
		msig = (MethodSignature) sign;
		Object target = pjp.getTarget();

		ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
		HttpServletRequest request = attributes.getRequest();
		// 匹配类上注解
		UserAuth userAnnotation = target.getClass().getAnnotation(UserAuth.class);
		if (userAnnotation != null) {
			// 获取注解里的值
			if (userAnnotation.type() == UserAuthCEnum.PASS) {
				try {
					return pjp.proceed();
				} catch (Exception e) {
					throw e;
				} catch (Throwable throwable){
					throw throwable;
				}
			}
		}

		// 匹配方法上注解
		Method targetMethod = msig.getMethod();// 获取接口方法
		Method realMethod = target.getClass().getDeclaredMethod(msig.getName(), targetMethod.getParameterTypes());// 获取具体实现方法
		UserAuth userAccess = realMethod.getAnnotation(UserAuth.class);
		if (userAccess != null) {
			// 获取注解里的值
			if (userAccess.type() == UserAuthCEnum.PASS) {
				try {
					passAuthToken(request);
					return pjp.proceed();
				} catch (Exception e) {
					throw e;
				}
				catch (Throwable throwable){
					throw throwable;
				}finally {

				}
			}
		}

		try {

			result = pjp.proceed();


		}  catch (Exception ex) {
			throw ex;

		}
		catch (Throwable throwable){
			throw throwable;
		}finally {

		}
		return result;

	}



	protected void passAuthToken(HttpServletRequest request) {
		String requestHeader = request.getHeader(AUTH_HEADER);
		String authToken;
		if (requestHeader != null && requestHeader.startsWith("Bearer ")) {
			authToken = requestHeader.substring(7);
			// 验证token是否过期,包含了验证jwt是否正确
			boolean JWTDateFalg = true;

			if (JWTDateFalg) {
				boolean flag = JwtTokenUtil.isTokenExpired(authToken);
				if (flag) {
					throw new AuthException(AppErrorEnum.E_10028);
				}
			}
			JWTInfo info = null;
			// 解析当前的token 中是否带有 jwtinfo
			boolean JWTInfoNotHas = false;
			if (JWTDateFalg) {
				// 获取token 中隐藏的个人信息
				try {
					info = JwtTokenUtil.getInfoFromToken(authToken);
				} catch (Exception e) {
					e.printStackTrace();
				}
				// token 中没有解析到 JWTInfo
				if (org.apache.commons.lang.StringUtils.isBlank(info.getUserId())) {
					if (JWTDateFalg) {
						throw new AuthException(AppErrorEnum.E_10028);
					}
				}
				JWTInfoNotHas = true;
			}
			if (JWTInfoNotHas) {
				// 有可能非法操作 ，导致用户异常
				// 获取缓存中的token 进行认证
				String tokenKey = String.format(SystemConstant.TOKEN_KEY, info.getUserId());
				// RedisTemplate redisTemplate = SpringUtil.getBean(RedisTemplate.class);
				boolean tokenFlag = false;
				if (redisTemplate.hasKey(tokenKey)) {
					String redisToken = (String) redisTemplate.opsForValue().get(tokenKey);
					if (StringUtils.equals(redisToken, authToken)) {
						tokenFlag = true;
					} else {
						throw new AuthException(AppErrorEnum.E_10028);
					}
//                    tokenFlag = true;
				} else {
					// 缓存中没有 说明不合法的token
					throw new AuthException(AppErrorEnum.E_10028);
				}
				if (tokenFlag) {
					Map<String, Object> UserInfoMap = sysUserMapper.selectUserInfo(info.getUserId());
					// log.debug("user info is {}", UserInfoMap.toString());
					info.setPassword((String) UserInfoMap.get("userPassword"));

					BaseContextHandle.setUserID(info.getUserId());
					BaseContextHandle.setUsername(info.getUsername());
					BaseContextHandle.setJWTInfo(info);
					BaseContextHandle.set("userInfo", UserInfoMap);
				}
			}
		} else {
			// header没有带Bearer字段
			throw new AuthException(AppErrorEnum.E_10028);
		}
		BaseContextHandle.setRemoteHost(request.getScheme() + "://" + request.getServerName());

	}
}
