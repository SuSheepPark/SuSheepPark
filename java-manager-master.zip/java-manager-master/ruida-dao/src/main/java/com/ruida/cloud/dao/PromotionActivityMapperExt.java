package com.ruida.cloud.dao;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;
import java.util.Map;

public interface PromotionActivityMapperExt {

    @Update("update t_promotion_activity set status=#{status} where promotion_activity_id=#{id}")
    Integer updateStatus(@Param("status") Integer status,@Param("id") Integer id);


    String listPromotionCourseIds(Integer activityId);

    String listPromotionDistributorIds(@Param("activityId") Integer activityId);

    List<Map<String, Object>> listSecondaryDistributorIds(@Param("activityId") Integer activityId);

    /**
     * 推广活动和分销商相关信息显示
     */
    List showPromotionActivity();

}
