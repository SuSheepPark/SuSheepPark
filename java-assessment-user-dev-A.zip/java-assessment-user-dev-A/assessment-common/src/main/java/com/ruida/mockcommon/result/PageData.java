package com.ruida.mockcommon.result;

import lombok.Data;

import java.util.List;

@Data
public class PageData<T> {
    long total;
    List<T> rows;
    int pageSize;//每页数量
    int currentPage;//当前页
    long totalPage;//总页数



}
