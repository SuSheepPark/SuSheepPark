package com.ruida.assessment.assessmentquestionbank.controller;

import com.ruida.assessment.assessmentcommon.enums.SourceChannelEnum;
import com.ruida.assessment.assessmentcommon.result.BaseResult;
import com.ruida.assessment.assessmentcommon.result.ListResult;
import com.ruida.assessment.assessmentcommon.result.PageData;
import com.ruida.assessment.assessmentcommon.result.PojoResult;
import com.ruida.assessment.assessmentcommon.util.excel.ExportExcelUtils;
import com.ruida.assessment.assessmentquestionbank.annotaion.UserAuth;
import com.ruida.assessment.assessmentquestionbank.dao.StudentMapper;
import com.ruida.assessment.assessmentquestionbank.dto.NewExchangeClassDTO;
import com.ruida.assessment.assessmentquestionbank.dto.StudentQueryRequest;
import com.ruida.assessment.assessmentquestionbank.service.IStudentService;
import com.ruida.assessment.assessmentquestionbank.service.SysCryptoService;
import com.ruida.assessment.assessmentquestionbank.service.impl.StudentServiceImpl;
import com.ruida.assessment.assessmentquestionbank.vo.OrderListVO;
import com.ruida.assessment.assessmentquestionbank.vo.StudentVo;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.inject.Inject;
import javax.servlet.http.HttpServletResponse;
import java.text.ParseException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author wy
 * @description 考生管理业务类
 * @date 2020/7/31
 */
@RequestMapping("/student")
@RestController
public class StudentController {
    @Resource
    private IStudentService studentService;
    @Resource
    private StudentMapper studentMapper;


    /**
     *   考生列表条件查询 (不包含用户虚拟考生：stu_type = 0为虚拟考生)
     * @param request
     * @return
     */
    @UserAuth
    @PostMapping("query/studentList")
    public PojoResult queryStudentList(@RequestBody StudentQueryRequest request){
        PageData<StudentVo> studentInfoList = studentService.queryStudentDataList(request);
        PojoResult<PageData> studentResult = new PojoResult<>();
        studentResult.setContent(studentInfoList);
        return studentResult;
    }

    /**
     * 导出考生列表 (不包含用户虚拟考生：stu_type = 0为虚拟考生)
     * @param request
     * @param response
     * @return
     * @throws ParseException
     */
    @UserAuth
    @PostMapping(value = "excel/exportStudentList")
    public void exportStudentList(@RequestBody StudentQueryRequest request, HttpServletResponse response) {
        //获取所有满足查询条件的数据
        List<StudentVo> studentVos = studentMapper.queryStudentDataList(request);
        studentVos.parallelStream().forEach(studentVo -> {
            studentVo.setIsboundStr(studentVo.getIsbound().equals(0)?"否":"是");
        });
        //定义导出的excel名字
        String excelName = "考生列表";
        //导出相关信息
        new ExportExcelUtils().export(excelName, studentVos, StudentVo.class, response);
    }

    /*
     *功能描述  更换班级(新方案)
     * @param
     * @return
     */
    @UserAuth
    @PostMapping("/newExchangeClass")
    public BaseResult newExchangeClass(@RequestBody  NewExchangeClassDTO exchangeClassDTO){
        BaseResult result =   studentService.newExchangeClass( exchangeClassDTO);
        return result;
    }

    /*
     *功能描述 删除考生
     * @param
     * @return
     */
    @UserAuth
    @DeleteMapping("delete/{stuId}")
    public BaseResult deleteStuendtByStuId(@PathVariable Integer stuId){
        return studentService.deleteStuendtByStuId(stuId);
    }

    /*
     *功能描述 注册来源下拉列表
     * @param
     * @return
     */
    @UserAuth
    @GetMapping("sourceChannelList")
    public BaseResult querySourceChannel(){
        ListResult<Map<String,Object>> result = new ListResult<>();
        List<Map<String, Object>> sourceChannelList = Arrays.stream(SourceChannelEnum.values()).map(e -> {
            Map<String, Object> map = new HashMap(4);
            map.put("code", e.getCode());
            map.put("name", e.getName());
            return map;
        }).collect(Collectors.toList());

        result.setContent(sourceChannelList);
        result.setTotalCount(sourceChannelList.size());
        return result;
    }

}
