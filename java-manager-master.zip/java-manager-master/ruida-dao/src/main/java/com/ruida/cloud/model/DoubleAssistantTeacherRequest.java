package com.ruida.cloud.model;

import lombok.Data;

/**
 * @author wy
 * @description: 添加助教请求类
 */

@Data
public class DoubleAssistantTeacherRequest {

    private Integer teacher_id;//助教id  我们自己生成的助教id  非百家云的id
    private String teacher_name;//主讲老师姓名
    private String teacher_mobile;//
    private Integer pageNo;
    private Integer pageSize;
    private Long start;
    private Integer size;
}