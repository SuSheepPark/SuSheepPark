package com.ruida.assessment.assessmentcommon.enums;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @description: 阅卷方式
 * @author: szl
 * @date: 2021/6/30
 */
public enum CorrectWayEnum {
    AUTO(1,"自动批阅"),
    AUTONOMIC(2,"自主批阅"),
    SINGLE_TO_SINGLE(3,"老师单题单批"),
    SINGLE_TO_MULTI(4,"老师单题多批"),
    TOTAL(5,"老师整题批阅");


    private Integer K;
    private String V;

    CorrectWayEnum(Integer k, String v) {
        K = k;
        V = v;
    }

    public static List<Map<String, Object>> getList() {
        List<Map<String, Object>> list = new ArrayList<>();
        for(CorrectWayEnum correctWayEnum : CorrectWayEnum.values() ){
            Map<String, Object> map = new HashMap<>();
            map.put("id", correctWayEnum.getK());
            map.put("name", correctWayEnum.getV());
            list.add(map);
        }
        return list;
    }

    public Integer getK() {
        return K;
    }

    public void setK(Integer k) {
        K = k;
    }

    public String getV() {
        return V;
    }

    public void setV(String v) {
        V = v;
    }


    public static CorrectWayEnum getValueById(Integer K){
        for(CorrectWayEnum correctWayEnum : CorrectWayEnum.values() ){
            if(correctWayEnum.getK().equals(K)){
                return  correctWayEnum;
            }
        }
        return null;
    }

}
