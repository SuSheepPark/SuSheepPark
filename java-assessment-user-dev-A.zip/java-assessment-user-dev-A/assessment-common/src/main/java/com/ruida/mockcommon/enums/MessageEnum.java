package com.ruida.mockcommon.enums;

public enum MessageEnum {

    FIND_PWD("1", "find", "找回密码"),
    REGISRER_USER("2", "register", "用户注册"),
    BIND_MOBILE("3", "bind", "账户绑定"),
    BIND_MOBILE_FIRST("4", "update_bind_first", "账户更改手机号码第一步"),
    BIND_MOBILE_SECOND("5", "update_bind_second", "账户更改手机号码第二步"),
    LOGIN_MOBILE("6", "login_tel", "手机登录"),
    PARENT_MODE("7", "parent_mode", "家长模式验证码"),
    CONFIRM_IDENTITY("8", "confirm_identify", "确认身份"),
    LOGIN_MOBILE_WX("9", "login_tel_wx", "微信登录验证码");

    MessageEnum(String typeCode, String type, String typeDesc) {
        this.typeCode = typeCode;
        this.type = type;
        this.typeDesc = typeDesc;
    }

    private String typeCode;
    private String type;
    private String typeDesc;


    public static String getMsgtypeBycode(String typeCode) {
        MessageEnum messageEnum[] = MessageEnum.values();

        for (MessageEnum msg : messageEnum) {
            if (msg.getTypeCode().equals(typeCode)) {
                return msg.getType();
            }
        }
        return null;
    }


    public String getTypeCode() {
        return typeCode;
    }

    public void setTypeCode(String typeCode) {
        this.typeCode = typeCode;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getTypeDesc() {
        return typeDesc;
    }

    public void setTypeDesc(String typeDesc) {
        this.typeDesc = typeDesc;
    }
}
