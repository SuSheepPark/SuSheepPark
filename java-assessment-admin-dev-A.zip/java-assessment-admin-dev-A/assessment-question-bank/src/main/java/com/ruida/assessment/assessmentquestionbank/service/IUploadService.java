package com.ruida.assessment.assessmentquestionbank.service;

import com.ruida.assessment.assessmentcommon.result.MapResult;
import com.ruida.assessment.assessmentquestionbank.dto.UploadCombinerDTO;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;

/**
 * @author wy
 * @description
 * @date 2020/9/1  文件上传服务层
 */

public interface IUploadService {


    MapResult singleFileUpload(MultipartFile file, String type) throws Exception;

    MapResult uploadProductPic(MultipartFile file) throws Exception;

    /***
     * 上传试卷pdf
     * @param file
     * @return
     * @throws Exception
     */
    MapResult uploadTestPaperPDF(MultipartFile file, Integer testPaperId) throws Exception;

    /**
     * 阿里云统一文件上传接口
     * @param uploadCombinerDTO
     * @return
     */
     MapResult<String, Object> uploadCombiner(UploadCombinerDTO uploadCombinerDTO);

    }
