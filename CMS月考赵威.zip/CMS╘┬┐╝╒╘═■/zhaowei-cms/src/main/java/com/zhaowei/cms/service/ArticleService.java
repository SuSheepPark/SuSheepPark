/**   
 * Copyright © 2019 公司名. All rights reserved.
 * 
 * @Title: ArticleService.java 
 * @Prject: zhaowei-cms
 * @Package: com.zhaowei.cms.service 
 * @Description: TODO
 * @author: zw   
 * @date: 2019年9月10日 下午8:45:58 
 * @version: V1.0   
 */
package com.zhaowei.cms.service;

import java.util.List;

import org.springframework.web.bind.annotation.RequestParam;

import com.github.pagehelper.PageInfo;
import com.zhaowei.cms.domain.Article;
import com.zhaowei.cms.domain.Comment;

/**
 * @ClassName: ArticleService
 * @Description: TODO
 * @author: zw
 * @date: 2019年9月10日 下午8:45:58
 */
public interface ArticleService {
	
	/**
	 * 
	 * @Title: selectPre 
	 * @Description: s上一篇
	 * @param article
	 * @return
	 * @return: Article
	 */
	Article selectPre(Article article);
	/**
	 * @Title: selectNext 
	 * @Description:下一篇
	 * @param id
	 * @return
	 * @return: Article
	 */
	Article selectNext(Article article);
	
	
	
	PageInfo<Article> selects(Article article,Integer page,Integer pageSize);

	int insertSelective(Article record);

	Article selectByPrimaryKey(Integer id);

	int updateByPrimaryKeySelective(Article article);
	/** 
	 * @Title: selectsByComments 
	 * @Description: TODO
	 * @param article2
	 * @param i
	 * @param j
	 * @return
	 * @return: PageInfo<Article>
	 */
	PageInfo<Article> selectsByComments(Article article2, Integer page,Integer pageSize);
	/** 
	 * @Title: selectsByclick 
	 * @Description: TODO
	 * @param article2
	 * @param i
	 * @param j
	 * @return
	 * @return: PageInfo<Article>
	 */
	PageInfo<Article> selectsByclick(Article article2, Integer page,Integer pageSize);
	/** 
	 * @Title: updateOnlyComments 
	 * @Description: TODO
	 * @param comments
	 * @param id 
	 * @return: void
	 */
	//boolean updateOnlyComments(@RequestParam(defaultValue = "")Integer comments,@RequestParam(defaultValue = "")Integer id);

}
