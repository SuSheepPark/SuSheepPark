package com.ruida.mockdao.model;

import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 学校专业录取信息
 * </p>
 *
 * @author szl
 * @since 2021-02-23
 */
@TableName("t_major_college")
public class TMajorCollege extends Model<TMajorCollege> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;
    /**
     * 学校名称
     */
    @TableField("college_name")
    private String collegeName;

    /**
     * 省份
     */
    private String province;

    /**
     * 学校层级。1-清华北大；2-5所学校；3-一流大学；4-一流学科；5-一般本科院校；6-独立学院；7-高职院校
     */
    @TableField("college_level")
    private Integer collegeLevel;
    /**
     * 层级名称
     */
    @TableField("college_level_name")
    private String collegeLevelName;
    @TableField("subject_category_name")
    private String subjectCategoryName;
    @TableField("subject_category_code")
    private String subjectCategoryCode;
    @TableField("major_category_name")
    private String majorCategoryName;
    @TableField("major_category_code")
    private String majorCategoryCode;
    @TableField("major_name")
    private String majorName;
    /**
     * 专业代码
     */
    @TableField("major_code")
    private String majorCode;
    /**
     * 计划数
     */
    @TableField("plan_num")
    private Integer planNum;
    /**
     * 录取最高分
     */
    @TableField("max_score")
    private Double maxScore;
    /**
     * 录取最低分
     */
    @TableField("min_score")
    private Double minScore;
    /**
     * 录取最低分去年排名
     */
    @TableField("admit_rank")
    private Integer admitRank;
    /**
     * 选考科目范围要求
     */
    @TableField("subject_limits")
    private String subjectLimits;
    /**
     * 创建者ID
     */
    @TableField("create_by")
    private Integer createBy;
    /**
     * 创建时间
     */
    @TableField("create_time")
    private Date createTime;
    /**
     * 更新者ID
     */
    @TableField("update_by")
    private Integer updateBy;
    /**
     * 更新时间
     */
    @TableField("update_time")
    private Date updateTime;
    /**
     * 是否删除（0：未删除；1：删除）
     */
    private Integer isdelete;
    /**
     * 院校识别码
     */
    @TableField("college_code")
    private String collegeCode;
    /**
     * 识别码
     */
    private String code;
    /**
     * 识别码
     */
    @TableField(exist = false)
    private Double admitScore;
    /**
     * 年份
     */
    private Integer year;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCollegeName() {
        return collegeName;
    }

    public void setCollegeName(String collegeName) {
        this.collegeName = collegeName;
    }

    public Integer getCollegeLevel() {
        return collegeLevel;
    }

    public void setCollegeLevel(Integer collegeLevel) {
        this.collegeLevel = collegeLevel;
    }

    public String getCollegeLevelName() {
        return collegeLevelName;
    }

    public void setCollegeLevelName(String collegeLevelName) {
        this.collegeLevelName = collegeLevelName;
    }

    public String getSubjectCategoryName() {
        return subjectCategoryName;
    }

    public void setSubjectCategoryName(String subjectCategoryName) {
        this.subjectCategoryName = subjectCategoryName;
    }

    public String getSubjectCategoryCode() {
        return subjectCategoryCode;
    }

    public void setSubjectCategoryCode(String subjectCategoryCode) {
        this.subjectCategoryCode = subjectCategoryCode;
    }

    public String getMajorCategoryName() {
        return majorCategoryName;
    }

    public void setMajorCategoryName(String majorCategoryName) {
        this.majorCategoryName = majorCategoryName;
    }

    public String getMajorCategoryCode() {
        return majorCategoryCode;
    }

    public void setMajorCategoryCode(String majorCategoryCode) {
        this.majorCategoryCode = majorCategoryCode;
    }

    public String getMajorName() {
        return majorName;
    }

    public void setMajorName(String majorName) {
        this.majorName = majorName;
    }

    public String getMajorCode() {
        return majorCode;
    }

    public void setMajorCode(String majorCode) {
        this.majorCode = majorCode;
    }

    public Integer getPlanNum() {
        return planNum;
    }

    public void setPlanNum(Integer planNum) {
        this.planNum = planNum;
    }

    public Double getMaxScore() {
        return maxScore;
    }

    public void setMaxScore(Double maxScore) {
        this.maxScore = maxScore;
    }

    public Double getMinScore() {
        return minScore;
    }

    public void setMinScore(Double minScore) {
        this.minScore = minScore;
    }

    public String getSubjectLimits() {
        return subjectLimits;
    }

    public void setSubjectLimits(String subjectLimits) {
        this.subjectLimits = subjectLimits;
    }

    public Integer getCreateBy() {
        return createBy;
    }

    public void setCreateBy(Integer createBy) {
        this.createBy = createBy;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(Integer updateBy) {
        this.updateBy = updateBy;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getIsdelete() {
        return isdelete;
    }

    public void setIsdelete(Integer isdelete) {
        this.isdelete = isdelete;
    }

    public String getCollegeCode() {
        return collegeCode;
    }

    public void setCollegeCode(String collegeCode) {
        this.collegeCode = collegeCode;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    public Integer getAdmitRank() {
        return admitRank;
    }

    public void setAdmitRank(Integer admitRank) {
        this.admitRank = admitRank;
    }

    @Override
    protected Serializable pkVal() {
        return this.id;
    }

    public Double getAdmitScore() {
        return admitScore;
    }

    public void setAdmitScore(Double admitScore) {
        this.admitScore = admitScore;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    @Override
    public String toString() {
        return "TMajorCollege{" +
                ", id=" + id +
                ", collegeName=" + collegeName +
                ", collegeLevel=" + collegeLevel +
                ", collegeLevelName=" + collegeLevelName +
                ", subjectCategoryName=" + subjectCategoryName +
                ", subjectCategoryCode=" + subjectCategoryCode +
        ", majorCategoryName=" + majorCategoryName +
        ", majorCategoryCode=" + majorCategoryCode +
        ", majorName=" + majorName +
        ", majorCode=" + majorCode +
        ", planNum=" + planNum +
        ", maxScore=" + maxScore +
        ", minScore=" + minScore +
        ", subjectLimits=" + subjectLimits +
        ", createBy=" + createBy +
        ", createTime=" + createTime +
        ", updateBy=" + updateBy +
        ", updateTime=" + updateTime +
        ", isdelete=" + isdelete +
        ", collegeCode=" + collegeCode +
        ", code=" + code +
        "}";
    }
}
