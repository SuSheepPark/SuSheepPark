package com.ruida.assessment.assessmentquestionbank.service;

import com.baomidou.mybatisplus.service.IService;
import com.ruida.assessment.assessmentcommon.result.BaseResult;
import com.ruida.assessment.assessmentcommon.result.ListResult;
import com.ruida.assessment.assessmentcommon.result.PojoResult;
import com.ruida.assessment.assessmentquestionbank.dto.BatchOperationRequest;
import com.ruida.assessment.assessmentquestionbank.dto.KnowledgeRequest;
import com.ruida.assessment.assessmentquestionbank.dto.MoveTreeRequest;
import com.ruida.assessment.assessmentquestionbank.dto.SectionRequest;
import com.ruida.assessment.assessmentquestionbank.model.TKnowledge;
import com.ruida.assessment.assessmentquestionbank.model.TSection;
import com.ruida.assessment.assessmentquestionbank.vo.KnowledgeTreeVo;
import com.ruida.assessment.assessmentquestionbank.vo.SectionTreeVo;

import java.util.List;

/**
 * @author wy
 * @description 知识点服务接口
 * @date 2020/6/10
 */
public interface ISectionService extends IService<TSection> {


    ListResult<SectionTreeVo> querySectionTreeList(SectionRequest request);

    PojoResult addSection(SectionRequest sectionRequest);

    BaseResult updateSection(SectionRequest sectionRequest);

    Boolean batchStopSection(BatchOperationRequest batchOperationRequest);

    BaseResult deleteSectionById(SectionRequest sectionRequest);

    ListResult queryknowledgeBySection(SectionRequest request);

    BaseResult addSectionKnowledge(BatchOperationRequest batchOperationRequest);

    BaseResult deleteKnowledgeByRelationId(BatchOperationRequest request);

    Boolean moveSectionTree(MoveTreeRequest moveTreeRequest);

    ListResult batchDeleteSection(SectionRequest request);

    /*
     *功能描述 
     * @param kid    知识点id
     * @param allKnowledgeTreeVoList  根据学段和科目查询出的当前学段科目下的知识点列表集合
     * @return 
     */
    String selectAllKnowledgeName(Integer kid,List<KnowledgeTreeVo> allKnowledgeTreeVoList);
}
