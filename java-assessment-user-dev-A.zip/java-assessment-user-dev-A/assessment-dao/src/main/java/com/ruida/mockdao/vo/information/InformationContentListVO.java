package com.ruida.mockdao.vo.information;

import java.util.Date;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.enums.IdType;
import com.fasterxml.jackson.annotation.JsonFormat;

public class InformationContentListVO {
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;
    /**
     * 所属栏目id
     */
    private Integer columnId;
    /**
     * 标题
     */
    private String title;
    /**
     * 副标题
     */
    @TableField("second_title")
    private String secondTitle;
    /**
     * web端封面图url
     */
    @TableField("web_img_url")
    private String webImgUrl;
    /**
     * 小程序封面图url
     */
    @TableField("applet_img_url")
    private String appletImgUrl;

    /**
     * 上架时间
     */
    @TableField("up_time")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date upTime;

    private Integer year;
    private Integer month;
    private Integer dayOfMonth;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getColumnId() {
		return columnId;
	}
	public void setColumnId(Integer columnId) {
		this.columnId = columnId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getSecondTitle() {
		return secondTitle;
	}
	public void setSecondTitle(String secondTitle) {
		this.secondTitle = secondTitle;
	}
	public String getWebImgUrl() {
		return webImgUrl;
	}
	public void setWebImgUrl(String webImgUrl) {
		this.webImgUrl = webImgUrl;
	}
	public String getAppletImgUrl() {
		return appletImgUrl;
	}
	public void setAppletImgUrl(String appletImgUrl) {
		this.appletImgUrl = appletImgUrl;
	}
	public Date getUpTime() {
		return upTime;
	}
	public void setUpTime(Date upTime) {
		this.upTime = upTime;
	}
	public Integer getYear() {
		return year;
	}
	public void setYear(Integer year) {
		this.year = year;
	}
	public Integer getMonth() {
		return month;
	}
	public void setMonth(Integer month) {
		this.month = month;
	}
	public Integer getDayOfMonth() {
		return dayOfMonth;
	}
	public void setDayOfMonth(Integer dayOfMonth) {
		this.dayOfMonth = dayOfMonth;
	}
}
