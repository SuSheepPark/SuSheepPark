package com.ruida.mockdao.model;

import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 选科方案-专业推荐记录表
 * </p>
 *
 * @author szl
 * @since 2021-02-25
 */
@TableName("t_major_recommend")
public class TMajorRecommend extends Model<TMajorRecommend> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;
    /**
     * 用户id
     */
    @TableField("user_id")
    private Integer userId;
    /**
     * 用户选科方案报告id
     */
    @TableField("report_id")
    private Integer reportId;
    /**
     * 逻辑删除
     */
    private Integer isdelete;
    /**
     * 专业名字
     */
    @TableField("major_name")
    private String majorName;
    /**
     * 专业类
     */
    @TableField("major_category_name")
    private String majorCategoryName;
    /**
     * 学科类名字
     */
    @TableField("subject_category_name")
    private String subjectCategoryName;
    /**
     * 识别码
     */
    private String code;
    /**
     * 学校名字
     */
    @TableField("college_name")
    private String collegeName;

    /**
     * 学校层级名称
     */
    @TableField("college_level_name")
    private String collegeLevelName;

    /**
     * 计划招录人数
     */
    @TableField("plan_num")
    private Integer planNum;

    /**
     * 省份
     */
    private String province;
    /**
     * 去年录取分数
     */
    @TableField("admit_score")
    private Double admitScore;
    /**
     * 创建时间
     */
    @TableField("create_time")
    private Date createTime;
    /**
     * 更新时间
     */
    @TableField("update_time")
    private Date updateTime;
    /**
     * 排序序号
     */
    private Integer sort;
    /**
     * 报告类型 0 选科方案 1志愿填报
     */
    private Integer type;
    /**
     * 志愿填报推荐专业星级
     */
    private Integer star;
    /**
     * 学校层级。1-清华北大；2-5所学校；3-一流大学；4-一流学科；5-一般本科院校；6-独立学院；7-高职院校
     */
    @TableField("college_level")
    private Integer collegeLevel;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Integer getReportId() {
        return reportId;
    }

    public void setReportId(Integer reportId) {
        this.reportId = reportId;
    }

    public Integer getIsdelete() {
        return isdelete;
    }

    public void setIsdelete(Integer isdelete) {
        this.isdelete = isdelete;
    }

    public String getMajorName() {
        return majorName;
    }

    public void setMajorName(String majorName) {
        this.majorName = majorName;
    }

    public String getMajorCategoryName() {
        return majorCategoryName;
    }

    public void setMajorCategoryName(String majorCategoryName) {
        this.majorCategoryName = majorCategoryName;
    }

    public String getSubjectCategoryName() {
        return subjectCategoryName;
    }

    public void setSubjectCategoryName(String subjectCategoryName) {
        this.subjectCategoryName = subjectCategoryName;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getCollegeName() {
        return collegeName;
    }

    public void setCollegeName(String collegeName) {
        this.collegeName = collegeName;
    }

    public Double getAdmitScore() {
        return admitScore;
    }

    public void setAdmitScore(Double admitScore) {
        this.admitScore = admitScore;
    }

    @Override
    protected Serializable pkVal() {
        return this.id;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getSort() {
        return sort;
    }

    public void setSort(Integer sort) {
        this.sort = sort;
    }

    public Integer getCollegeLevel() {
        return collegeLevel;
    }

    public void setCollegeLevel(Integer collegeLevel) {
        this.collegeLevel = collegeLevel;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public Integer getStar() {
        return star;
    }

    public void setStar(Integer star) {
        this.star = star;
    }

    public String getCollegeLevelName() {
        return collegeLevelName;
    }

    public void setCollegeLevelName(String collegeLevelName) {
        this.collegeLevelName = collegeLevelName;
    }

    public Integer getPlanNum() {
        return planNum;
    }

    public void setPlanNum(Integer planNum) {
        this.planNum = planNum;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    @Override
    public String toString() {
        return "TMajorRecommend{" +
                "id=" + id +
                ", userId=" + userId +
                ", reportId=" + reportId +
                ", isdelete=" + isdelete +
                ", majorName='" + majorName + '\'' +
                ", majorCategoryName='" + majorCategoryName + '\'' +
                ", subjectCategoryName='" + subjectCategoryName + '\'' +
                ", code='" + code + '\'' +
                ", collegeName='" + collegeName + '\'' +
                ", admitScore=" + admitScore +
                ", createTime=" + createTime +
                ", updateTime=" + updateTime +
                '}';
    }
}
