package com.ruida.common.enums;

public interface RoleType {
     Integer administrator = 0;
     Integer admin = 1 ;
}
