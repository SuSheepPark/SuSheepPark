package com.ruida.assessment.assessmentquestionbank.imports.domain.model;

public class QuestionContentItem {

	private String itemContent;
	private Integer number;

	public String getItemContent() {
		return itemContent;
	}

	public void setItemContent(String itemContent) {
		this.itemContent = itemContent;
	}

	public Integer getNumber() {
		return number;
	}

	public void setNumber(Integer number) {
		this.number = number;
	}
}
