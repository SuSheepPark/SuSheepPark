package com.ruida.assessment.assessmentquestionbank.controller;

import com.ruida.assessment.assessmentcommon.result.PageResult;
import com.ruida.assessment.assessmentcommon.result.PojoResult;
import com.ruida.assessment.assessmentquestionbank.annotaion.UserAuth;
import com.ruida.assessment.assessmentquestionbank.dto.QueryBaseDTO;
import com.ruida.assessment.assessmentquestionbank.dto.UserMessageDTO;
import com.ruida.assessment.assessmentquestionbank.service.MessageManagementService;
import com.ruida.assessment.assessmentquestionbank.vo.MessageCustomVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

/**
 * @description: 消息管理业务层
 * @author: kgz
 * @date: 2020/7/24
 */
@RequestMapping("/messageManagement")
@RestController
@Api(value ="消息管理相关接口")
public class MessageManagementController {

    @Resource
    private MessageManagementService messageManagementService;

    @UserAuth
    @PostMapping("/getList")
    @ApiOperation(value = "分页查询自定义消息列表", notes = "分页查询自定义消息列表")
    @ApiImplicitParam(name = "queryBaseDTO", value = "列表查询条件",
            required = true , dataType  = "QueryBaseDTO",paramType = "body")
    public PageResult<MessageCustomVO> getList(@RequestBody QueryBaseDTO queryBaseDTO){
        PageResult<MessageCustomVO> pageResult = new PageResult();
        pageResult.setContent(messageManagementService.getMessageCustomList(queryBaseDTO));
        return pageResult;
    }

    @UserAuth
    @GetMapping("/getDetail/{id}")
    @ApiImplicitParam(name = "id", value = "自定义消息id",
            required = true , dataType  = "integer",paramType = "path")
    public PojoResult getDetail(@PathVariable Integer id){
        PojoResult pojoResult = new PojoResult();
        MessageCustomVO messageCustomVO = messageManagementService.getMessageCustomDetail(id);
        pojoResult.setContent(messageCustomVO);
        return pojoResult;
    }

    @UserAuth
    @PostMapping("/sendMessage")
    @ApiImplicitParam(name = "userMessageDTO", value = "自定义消息体",
            required = true , dataType  = "UserMessageDTO",paramType = "body")
    public PojoResult sendMessage(@RequestBody UserMessageDTO userMessageDTO){
        PojoResult pojoResult = new PojoResult();
        messageManagementService.sendMessage(userMessageDTO);
        pojoResult.setContent(userMessageDTO);
        return pojoResult;
    }

    @UserAuth
    @GetMapping("/delete/{id}")
    @ApiImplicitParam(name = "id", value = "自定义消息id",
            required = true , dataType  = "integer",paramType = "path")
    public PojoResult delete(@PathVariable Integer id){
        PojoResult pojoResult = new PojoResult();
        messageManagementService.deleteMessageCustom(id);
        pojoResult.setContent(id);
        return pojoResult;
    }

}
