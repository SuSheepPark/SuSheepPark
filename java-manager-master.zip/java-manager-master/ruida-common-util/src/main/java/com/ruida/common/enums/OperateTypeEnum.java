package com.ruida.common.enums;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * 操作类型
 */
public enum OperateTypeEnum {

    MODIFY((byte)0,"修改"),
    DELETE((byte)1,"删除");

    private Byte k;
    private String v;

    OperateTypeEnum(Byte k, String v) {
        this.k = k;
        this.v = v;
    }

    public static Map<Byte,String> map = new LinkedHashMap<>();

    static {
        for (OperateTypeEnum operateType : OperateTypeEnum.values()){
            map.put(operateType.getK(),operateType.getV());
        }
    }

    public static String getValueByKey(int k) {
        OperateTypeEnum[] list = OperateTypeEnum.values();
        for (OperateTypeEnum item : list) {
            if (item.getK() == k ) {
                return item.getV();
            }
        }
        return "";
    }

    public Byte getK() {
        return k;
    }

    public void setK(Byte k) {
        this.k = k;
    }

    public String getV() {
        return v;
    }

    public void setV(String v) {
        this.v = v;
    }
}
