package com.ruida.mockdao.dao;


import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.model.SysUserStudyCoin;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * IOS用户学币表 Mapper 接口
 * </p>
 *
 * @author Bhj
 * @since 2020-07-29
 */
public interface SysUserStudyCoinMapper extends BaseMapper<SysUserStudyCoin> {

    BigDecimal getStudyCoinNumByUserId(Integer userId);

    List<Map<String, Object>> listStudyCoinPrice();
}
