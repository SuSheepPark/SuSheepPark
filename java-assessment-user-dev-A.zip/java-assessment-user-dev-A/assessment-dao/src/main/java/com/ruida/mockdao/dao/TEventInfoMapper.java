package com.ruida.mockdao.dao;

import com.ruida.mockdao.model.TEventInfo;
import com.baomidou.mybatisplus.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author szl
 * @since 2021-05-27
 */
public interface TEventInfoMapper extends BaseMapper<TEventInfo> {

}
