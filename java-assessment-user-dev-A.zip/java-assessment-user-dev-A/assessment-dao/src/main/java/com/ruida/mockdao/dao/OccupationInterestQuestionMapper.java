package com.ruida.mockdao.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.model.OccupationInterestQuestion;

/**
 * <p>
 * 霍兰德职业兴趣调查试题 Mapper 接口
 * </p>
 *
 * @author 
 * @since 2021-02-05
 */
public interface OccupationInterestQuestionMapper extends BaseMapper<OccupationInterestQuestion> {

}
