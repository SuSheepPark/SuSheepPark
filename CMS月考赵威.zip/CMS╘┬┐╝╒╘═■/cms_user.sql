/*
Navicat MySQL Data Transfer

Source Server         : my
Source Server Version : 50557
Source Host           : 127.0.0.1:3306
Source Database       : 1705e_cms

Target Server Type    : MYSQL
Target Server Version : 50557
File Encoding         : 65001

Date: 2019-09-25 11:40:12
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `cms_user`
-- ----------------------------
DROP TABLE IF EXISTS `cms_user`;
CREATE TABLE `cms_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `nickname` varchar(20) DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `gender` int(11) DEFAULT NULL,
  `locked` int(11) DEFAULT NULL COMMENT '0:正常,1:禁用',
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  `role` varchar(1) DEFAULT '0' COMMENT '0:普通用户,1:管理员',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=140 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cms_user
-- ----------------------------
INSERT INTO `cms_user` VALUES ('126', '是老于', '456', '鱼老师', '2019-09-04', '67', '0', '2019-09-18 10:35:25', '2019-09-06 10:35:29', '0');
INSERT INTO `cms_user` VALUES ('127', 'qwe', '123456', '新华', '2019-09-04', '34', '0', '2019-09-13 08:54:14', '2019-09-20 08:54:18', '0');
INSERT INTO `cms_user` VALUES ('128', '疯灵', '154047', 'Firosh', '2019-09-10', '74', '0', '2019-09-26 19:10:52', '2019-09-13 19:10:56', '1');
INSERT INTO `cms_user` VALUES ('129', '安溥', '8524', '焦安溥', '2019-09-19', '41', '0', '2019-09-05 19:11:44', '2019-09-20 19:11:47', '0');
INSERT INTO `cms_user` VALUES ('130', 'asd', '23456', '生代采', '2019-09-12', '44', '0', '2019-09-07 08:54:54', '2019-09-29 08:54:58', '0');
INSERT INTO `cms_user` VALUES ('131', 'sdfg', '456', '地方sd', '2019-09-27', '65', '0', '2019-08-29 08:57:07', '2019-09-13 08:57:24', '0');
INSERT INTO `cms_user` VALUES ('132', 'asdf', '56234', 'yh', '2019-09-27', '7', '0', '2019-09-28 11:57:09', '2019-09-20 08:57:26', '0');
INSERT INTO `cms_user` VALUES ('133', 'sdf', '23', 'jhf', '2019-09-28', '6', '0', '2019-09-14 08:57:13', '2019-09-27 08:57:28', '0');
INSERT INTO `cms_user` VALUES ('134', 'sdc', '23456', 'sdfs', '2019-09-20', '45', '1', '2019-09-20 08:57:19', '2019-09-13 08:57:30', '0');
INSERT INTO `cms_user` VALUES ('135', 'nhn', '234564', null, '2019-09-20', '23', '1', '2019-09-28 08:57:17', '2019-09-28 08:57:35', '0');
INSERT INTO `cms_user` VALUES ('136', 'jm', '456', null, '2019-09-13', '2', '1', '2019-09-13 08:57:22', '2019-09-06 08:57:32', '0');
INSERT INTO `cms_user` VALUES ('137', 'piao', '0f6a7f7251423110e272d92fe5731dec', 'piao', '1999-06-30', '1', '0', '2019-09-19 19:38:10', '2019-09-19 19:38:10', '0');
INSERT INTO `cms_user` VALUES ('138', 'wen', '0f6a7f7251423110e272d92fe5731dec', 'wen', '2019-09-04', '1', '0', '2019-09-20 00:06:02', '2019-09-20 00:06:02', '1');
INSERT INTO `cms_user` VALUES ('139', 'zhao', '978fb8452caf6c7c4a6afecad4e9f7a9', 'zhao', null, '0', '0', '2019-09-24 18:59:26', '2019-09-24 18:59:26', '0');
