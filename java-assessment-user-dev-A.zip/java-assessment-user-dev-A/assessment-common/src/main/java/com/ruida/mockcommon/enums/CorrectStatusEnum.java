package com.ruida.mockcommon.enums;

public enum CorrectStatusEnum {
    CORRECTED(0,"已批阅"),
    UN_CORRECTED(1,"未批阅"),
    NAN(2,"不需要批阅");

    private int k;

    private String v;

    CorrectStatusEnum(int k, String v) {
        this.k = k;
        this.v = v;
    }

    public int getK() {
        return k;
    }

    public void setK(int k) {
        this.k = k;
    }

    public String getV() {
        return v;
    }

    public void setV(String v) {
        this.v = v;
    }
}
