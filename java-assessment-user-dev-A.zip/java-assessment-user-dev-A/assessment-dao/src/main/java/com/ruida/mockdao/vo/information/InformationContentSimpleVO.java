package com.ruida.mockdao.vo.information;

import java.util.Date;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.enums.IdType;
import com.fasterxml.jackson.annotation.JsonFormat;

public class InformationContentSimpleVO {
	@TableId(value = "id", type = IdType.AUTO)
    private Integer id;
    /**
     * 标题
     */
    private String title;

    /**
     * web端封面图url
     */
    @TableField("web_img_url")
    private String webImgUrl;

    /**
     * 上架时间
     */
    @TableField("up_time")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date upTime;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getWebImgUrl() {
		return webImgUrl;
	}

	public void setWebImgUrl(String webImgUrl) {
		this.webImgUrl = webImgUrl;
	}

	public Date getUpTime() {
		return upTime;
	}

	public void setUpTime(Date upTime) {
		this.upTime = upTime;
	}
}
