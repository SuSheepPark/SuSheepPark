package com.ruida.mockdao.pojo;

/**
 * @description: 报告基础信息
 * @author: chenjy
 * @create: 2021-01-18 09:51
 */
public class ReportBasicInfo {

    private String userName;

    private String className;

    private String schoolName;

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public String getSchoolName() {
        return schoolName;
    }

    public void setSchoolName(String schoolName) {
        this.schoolName = schoolName;
    }
}
