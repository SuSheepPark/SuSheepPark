package com.ruida.cloud.model;

import java.io.Serializable;

public class CourseBroadcastroomRel implements Serializable {
    private Integer courseBroadcastroomId;

    private Integer courseId;

    private Integer campusId;

    private Integer broadcastRoomId;

    private Integer broadcastRoomOnlineStuNum;

    private static final long serialVersionUID = 1L;

    public Integer getCourseBroadcastroomId() {
        return courseBroadcastroomId;
    }

    public void setCourseBroadcastroomId(Integer courseBroadcastroomId) {
        this.courseBroadcastroomId = courseBroadcastroomId;
    }

    public Integer getCourseId() {
        return courseId;
    }

    public void setCourseId(Integer courseId) {
        this.courseId = courseId;
    }

    public Integer getCampusId() {
        return campusId;
    }

    public void setCampusId(Integer campusId) {
        this.campusId = campusId;
    }

    public Integer getBroadcastRoomId() {
        return broadcastRoomId;
    }

    public void setBroadcastRoomId(Integer broadcastRoomId) {
        this.broadcastRoomId = broadcastRoomId;
    }

    public Integer getBroadcastRoomOnlineStuNum() {
        return broadcastRoomOnlineStuNum;
    }

    public void setBroadcastRoomOnlineStuNum(Integer broadcastRoomOnlineStuNum) {
        this.broadcastRoomOnlineStuNum = broadcastRoomOnlineStuNum;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", courseBroadcastroomId=").append(courseBroadcastroomId);
        sb.append(", courseId=").append(courseId);
        sb.append(", campusId=").append(campusId);
        sb.append(", broadcastRoomId=").append(broadcastRoomId);
        sb.append(", broadcastRoomOnlineStuNum=").append(broadcastRoomOnlineStuNum);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}