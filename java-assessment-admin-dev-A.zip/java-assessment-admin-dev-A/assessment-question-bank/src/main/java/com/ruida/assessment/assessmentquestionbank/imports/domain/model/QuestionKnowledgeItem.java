package com.ruida.assessment.assessmentquestionbank.imports.domain.model;

public class QuestionKnowledgeItem {

	private String knowledgeString;
	private String weight;
	public String getKnowledgeString() {
		return knowledgeString;
	}
	public void setKnowledgeString(String knowledgeString) {
		this.knowledgeString = knowledgeString;
	}
	public String getWeight() {
		return weight;
	}
	public void setWeight(String weight) {
		this.weight = weight;
	}
}
