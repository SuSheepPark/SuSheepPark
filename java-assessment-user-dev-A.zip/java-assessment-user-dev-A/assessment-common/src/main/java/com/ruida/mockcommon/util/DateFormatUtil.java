package com.ruida.mockcommon.util;

import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;

/**
 * @author xumingqi
 * @date 2021/2/25 13:50
 */
public class DateFormatUtil {
    public static String getDateFormat(Date date) {
        Instant nowInstant = new Date().toInstant();
        Instant updateTimeInstant = date.toInstant();
        Duration duration = Duration.between(updateTimeInstant, nowInstant);
        long days = duration.toDays();
        if (days < 1) {
            long minutes = duration.toMinutes();
            if (minutes < 5) {
                return "刚刚";
            } else {
                long hours = duration.toHours();
                if (hours < 1) {
                    return minutes + "分钟前";
                } else {
                    return hours + "小时前";
                }
            }
        } else if (days < 7) {
            return days + "天前";
        } else {
            LocalDateTime updateDateTime = LocalDateTime.ofInstant(updateTimeInstant, ZoneId.systemDefault());
            if (days < 365) {
                return DateTimeFormatter.ofPattern("MM-dd hh:mm").format(updateDateTime);
            } else {
                return DateTimeFormatter.ofPattern("yyyy-MM-dd hh:mm").format(updateDateTime);
            }
        }
    }
}
