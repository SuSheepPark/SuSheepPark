package com.ruida.cloud.dao;

import com.ruida.cloud.model.ClassType;
import com.ruida.cloud.model.ClassTypeExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface ClassTypeMapper {
    long countByExample(ClassTypeExample example);

    int deleteByExample(ClassTypeExample example);

    int deleteByPrimaryKey(Integer classTypeId);

    int insert(ClassType record);

    int insertSelective(ClassType record);

    List<ClassType> selectByExample(ClassTypeExample example);

    ClassType selectByPrimaryKey(Integer classTypeId);

    int updateByExampleSelective(@Param("record") ClassType record, @Param("example") ClassTypeExample example);

    int updateByExample(@Param("record") ClassType record, @Param("example") ClassTypeExample example);

    int updateByPrimaryKeySelective(ClassType record);

    int updateByPrimaryKey(ClassType record);

    //根据学段id列出班级类型
    List<ClassType> listClassTypeByPeriodId(Integer periodId);
}