package com.ruida.mockcommon.redis;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.support.atomic.RedisAtomicLong;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.concurrent.TimeUnit;

/**
 * redis操作封装
 *
 * @author szl
 */
@Component
public class RedisManager {

    private static final String LOCK_SUCCESS = "OK";
    private static final Long RELEASE_SUCCESS = 1L;

    /**
     * 所有操作的key都加统一的前缀，防止不同项目相互影响
     */
    private static final  String keyPrefix = "assessment";
    /**
     * 订单模块前缀
     */
    public static final  String ORDER_MODULE = "order_module";
    /**
     * 阿里云oss模块前缀
     */
    public static final  String OSS_MODULE = "oss_module";
    /**
     * 考试模块前缀
     */
    public static final  String EXAM_MODULE = "exam_module";

    @Autowired
    private StringRedisTemplate stringRedisTemplate;
    @Autowired
    RedisTemplate redisTemplate;


    /**
     * 普通缓存获取
     *
     * @param key 键
     * @return 值
     */
    public String get(String key,String module) {
        key = this.keyWrapper(key,module);
        return key == null ? null : stringRedisTemplate.opsForValue().get(key);
    }

    /**
     * 普通缓存放入
     *
     * @param key   键
     * @param value 值
     * @return true成功 false失败
     */
    public boolean set(String key, String value,String module) {
        try {
            key = this.keyWrapper(key,module);
            stringRedisTemplate.opsForValue().set(key, value);
            return true;
        } catch (Exception e) {

            return false;
        }

    }

    /**
     * 普通缓存放入,key不存在才会设置
     *
     * @param key   键
     * @param value 值
     * @return true成功 false失败
     */
    public boolean setIfAbsent(String key, String value,String module) {
        try {
            key = this.keyWrapper(key, module);
            return stringRedisTemplate.opsForValue().setIfAbsent(key, value);
        } catch (Exception e) {

            return false;
        }

    }

    /**
     * 普通缓存放入并设置时间
     *
     * @param key   键
     * @param value 值
     * @param time  时间(秒) time要大于0 如果time小于等于0 将设置无限期
     * @return true成功 false 失败
     */
    public boolean set(String key, String value,String module, long time) {
        try {
            key = this.keyWrapper(key,module);
            if (time > 0) {
                stringRedisTemplate.opsForValue().set(key, value, time, TimeUnit.SECONDS);
            } else {
                set(key, value,module);
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * 判断key是否存在
     *
     * @param key 键
     * @return true 存在 false不存在
     */
    public boolean hasKey(String key,String module) {
        try {
            key = this.keyWrapper(key,module);
            return stringRedisTemplate.hasKey(key);
        } catch (Exception e) {

            return false;
        }
    }

    /**
     * 删除缓存
     *
     * @param keys 可以传一个值 或多个
     */
    public  void del(String module,String... keys) {
        if (keys != null && keys.length > 0) {
            for (int i = 0; i < keys.length; i++) {
                keys[i] = this.keyWrapper(keys[i],module);
            }
            if (keys.length == 1) {
                stringRedisTemplate.delete(keys[0]);
            } else {
                stringRedisTemplate.delete(CollectionUtils.arrayToList(keys));
            }
        }
    }
    /**
     * 指定缓存失效时间
     *
     * @param key  键
     * @param time 时间(秒)
     * @return
     */
    public boolean expire(String key,String module, long time) {
        try {
            key = this.keyWrapper(key,module);
            if (time > 0) {
                stringRedisTemplate.expire(key, time, TimeUnit.SECONDS);
            }
            return true;
        } catch (Exception e) {

            return false;
        }
    }

    /**
     * 根据key 获取过期时间
     *
     * @param key 键 不能为null
     * @return 时间(秒) 返回0代表为永久有效
     */
    public long getExpire(String key,String module) {
        key = this.keyWrapper(key,module);
        return stringRedisTemplate.getExpire(key, TimeUnit.SECONDS);
    }

    /**
     * 递减
     *
     * @param key   键
     * @param delta 要增加的数值
     * @return 增加后的值
     */
    public long incrBy(String key, Long delta,String module) {
        if (delta < 0) {
            throw new RuntimeException("递增因子必须大于0");
        }
        key = this.keyWrapper(key,module);
        return stringRedisTemplate.opsForValue().increment(key, delta);
    }

    /**
     * 递减
     *
     * @param key   键
     * @param delta 要减少的数值
     * @return 减少后的值
     */
    public long decrBy(String key, Long delta,String module) {
        if (delta < 0) {
            throw new RuntimeException("递减因子必须大于0");
        }
        key = this.keyWrapper(key,module);
        return stringRedisTemplate.opsForValue().increment(key, -delta);
    }

    /**
     * 将key的前缀附加上
     *
     * @param rawKey 未经修改的key
     * @return 修改过的key
     */
    private String keyWrapper(String rawKey,String module) {
        if (StringUtils.isNotBlank(this.keyPrefix)) {
            return String.format("%s:%s:%s",this.keyPrefix,module,rawKey);
        } else {
            return rawKey;
        }
    }

    /**
     *
     * @param key 未包装的key
     * @param module 模块
     * @param liveTime 生存时间
     * @return
     */
    public Long incr(String key,String module ,long liveTime) {
        key = this.keyWrapper(key,module);
        RedisAtomicLong entityIdCounter = new RedisAtomicLong(key, redisTemplate.getConnectionFactory());
        Long increment = entityIdCounter.getAndIncrement();

        if ((null == increment || increment.longValue() == 0) && liveTime > 0) {//初始设置过期时间
            entityIdCounter.expire(liveTime, TimeUnit.HOURS);
        }
        return increment;

    }
}
