package com.ruida.cloud.model;

import lombok.Data;

import java.util.Date;

@Data
public class DoubleStudent {
    /**
     * 学生ID
     */
    private Integer studentId;

    /**
     * 校管家学生ID
     */
    private String studentIdXgj;

    /**
     * 学生姓名
     */
    private String studentName;

    /**
     * 学号
     */
    private String studentNo;

    /**
     * 联系方式
     */
    private String telephone;

    /**
     * 学生性别（0：未知；1：男；2：女）
     */
    private Byte sex;

    /**
     * 状态
     */
    private Byte status;

    /**
     * 创建者ID（关联user_id）
     */
    private Integer createBy;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新者ID（关联user_id）
     */
    private Integer updateBy;

    /**
     * 更新时间
     */
    private Date updateTime;

    /**
     * 是否删除（0：未删除；1：删除）
     */
    private Byte isdelete;

}