package com.ruida.assessment.assessmentquestionbank.model;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.ruida.assessment.assessmentquestionbank.vo.ClassVo;
import lombok.Data;

import java.io.Serializable;
import java.util.LinkedList;
import java.util.List;

/**
 * @author wy
 * @description 年级Vo
 * @date 2020/7/28
 */
@Data
@TableName("t_grade")
public class TGrade extends BaseColumn implements Serializable {


    private static final long serialVersionUID = 1136862057852605773L;
    /**
     * 年级ID
     */
    @TableId
    private Integer gradeId;
    /**
     * 年级名称
     */
    private String gradeName;
    /**
     * 学段id
     */
    private Integer periodId;
    /**
     * 状态（0—禁用；1—启用）
     */
    private Integer status;

}
