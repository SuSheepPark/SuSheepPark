package com.ruida.assessment.assessmentquestionbank.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.assessment.assessmentcommon.result.Page;
import com.ruida.assessment.assessmentquestionbank.model.TTestType;
import com.ruida.assessment.assessmentquestionbank.vo.BaseFieldVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

/**
 * @description:
 * @author: kgz
 * @date: 2020/7/6
 */
@Mapper
public interface TestTypeMapper extends BaseMapper<TTestType> {

    /**
     * 分页查询列表
     * @param page
     * @return
     */
    List<BaseFieldVO> queryList(@Param("page") Page page,@Param("pName") String pName);

    /**
     * 列表数据条数
     * @return
     */
    Integer countQueryList(@Param("pName") String pName);
    @Select("SELECT\n" +
        "\tb.`name` ,\n" +
        "b.id,\n" +
        "b.`status`\n" +
        "FROM\n" +
        "\tt_test_type_period_rel a\n" +
        "LEFT JOIN t_test_type b ON a.test_type_id = b.id\n" +
        "WHERE\n" +
        "\ta.period_id = #{periodId}")
    List<Map<String,Object>> getListById(@Param("periodId") Integer periodId);


}
