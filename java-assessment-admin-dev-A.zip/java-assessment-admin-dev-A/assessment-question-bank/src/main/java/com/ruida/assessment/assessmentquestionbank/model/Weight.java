package com.ruida.assessment.assessmentquestionbank.model;

import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;
import com.fasterxml.jackson.annotation.JsonIgnore;
import org.hibernate.validator.constraints.Range;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 权重设置表
 * </p>
 *
 * @author chenjy
 * @since 2020-12-16
 */
@TableName("t_weight")
public class Weight extends Model<Weight> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键ID
     */
    @JsonIgnore
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;
    /**
     * 报告ID
     */
    @TableField("report_id")
    private Integer reportId;
    /**
     * 学段ID
     */
    @TableField("period_id")
    private Integer periodId;
    /**
     * 学段名称
     */
    @TableField("period_name")
    private String periodName;
    /**
     * 年级ID
     */
    @TableField("stage_id")
    private Integer stageId;
    /**
     * 年级名称
     */
    @TableField("stage_name")
    private String stageName;
    /**
     * 权重值(10表示10%)
     */
    @Range(min = 0,max = 100,message = "权重取值范围不合法")
    private Integer weight;
    /**
     * 是否为默认值(1：是，0：否)
     */
    @JsonIgnore
    private Integer isdefault;
    /**
     * 创建人
     */
    @JsonIgnore
    @TableField("create_by")
    private Integer createBy;
    /**
     * 创建时间
     */
    @JsonIgnore
    @TableField("create_time")
    private Date createTime;
    /**
     * 是否删除(1：是，0：否)
     */
    @JsonIgnore
    private Integer isdelete;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getPeriodId() {
        return periodId;
    }

    public void setPeriodId(Integer periodId) {
        this.periodId = periodId;
    }

    public String getPeriodName() {
        return periodName;
    }

    public void setPeriodName(String periodName) {
        this.periodName = periodName;
    }

    public Integer getStageId() {
        return stageId;
    }

    public void setStageId(Integer stageId) {
        this.stageId = stageId;
    }

    public String getStageName() {
        return stageName;
    }

    public void setStageName(String stageName) {
        this.stageName = stageName;
    }

    public Integer getWeight() {
        return weight;
    }

    public void setWeight(Integer weight) {
        this.weight = weight;
    }

    public Integer getIsdefault() {
        return isdefault;
    }

    public void setIsdefault(Integer isdefault) {
        this.isdefault = isdefault;
    }

    public Integer getCreateBy() {
        return createBy;
    }

    public void setCreateBy(Integer createBy) {
        this.createBy = createBy;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getIsdelete() {
        return isdelete;
    }

    public void setIsdelete(Integer isdelete) {
        this.isdelete = isdelete;
    }

    public Integer getReportId() {
        return reportId;
    }

    public void setReportId(Integer reportId) {
        this.reportId = reportId;
    }

    @Override
    protected Serializable pkVal() {
        return this.id;
    }

    @Override
    public String toString() {
        return "Weight{" +
        ", id=" + id +
        ", reportId=" + reportId +
        ", periodId=" + periodId +
        ", periodName=" + periodName +
        ", stageId=" + stageId +
        ", stageName=" + stageName +
        ", weight=" + weight +
        ", isdefault=" + isdefault +
        ", createBy=" + createBy +
        ", createTime=" + createTime +
        ", isdelete=" + isdelete +
        "}";
    }
}
