package com.ruida.mockservice.service;

import com.baomidou.mybatisplus.service.IService;
import com.ruida.mockdao.model.OccupationInterestQuestion;

/**
 * <p>
 * 霍兰德职业兴趣调查试题 服务类
 * </p>
 *
 * @author 
 * @since 2021-02-05
 */
public interface OccupationInterestQuestionService extends IService<OccupationInterestQuestion> {

}
