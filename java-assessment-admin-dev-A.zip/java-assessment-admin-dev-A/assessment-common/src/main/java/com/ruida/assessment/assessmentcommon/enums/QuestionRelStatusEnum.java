package com.ruida.assessment.assessmentcommon.enums;

/**
 * @description: 商品状态枚举类
 * @author: kgz
 * @date: 2020/6/9
 */
public enum QuestionRelStatusEnum {
    REL(0,"引用"),
    REJ(1,"退回"),
    ;

    private Integer K;
    private String V;

    QuestionRelStatusEnum(Integer k, String v) {
        K = k;
        V = v;
    }

    public Integer getK() {
        return K;
    }

    public void setK(Integer k) {
        K = k;
    }

    public String getV() {
        return V;
    }

    public void setV(String v) {
        V = v;
    }

    public static QuestionRelStatusEnum getValueById(Integer K){
        if(K != null){
            for(QuestionRelStatusEnum relStatusEnum : QuestionRelStatusEnum.values() ){
                if(relStatusEnum.getK().equals(K)){
                    return  relStatusEnum;
                }
            }
        }
        return null;
    }

}
