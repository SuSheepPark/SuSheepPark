package com.ruida.cloud.dao;

import com.ruida.cloud.model.TStudyCoinRecord;
import com.ruida.cloud.model.TStudyCoinRecordExample;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

public interface TStudyCoinRecordMapperExt {
    int countByExample(TStudyCoinRecordExample example);

    int deleteByExample(TStudyCoinRecordExample example);

    int deleteByPrimaryKey(Integer studyCoinRecordId);

    int insert(TStudyCoinRecord record);

    int insertSelective(TStudyCoinRecord record);

    TStudyCoinRecord selectByPrimaryKey(Integer studyCoinRecordId);

    int updateByExampleSelective(@Param("record") TStudyCoinRecord record, @Param("example") TStudyCoinRecordExample example);

    int updateByExample(@Param("record") TStudyCoinRecord record, @Param("example") TStudyCoinRecordExample example);

    int updateByPrimaryKeySelective(TStudyCoinRecord record);

    int updateByPrimaryKey(TStudyCoinRecord record);

    /**
     * 学习币记录的查询
     * @param param
     * @return
     */
    List selectByExample(Map param);

}