package com.ruida.assessment.assessmentquestionbank.model;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @author wy
 * @description 章节-知识点关联表
 * @date 2020/6/13
 */
@Data
@ApiModel(description = "章节-知识点关联实体")
@TableName("t_section_knowledge")
public class TSectionKnowledge extends BaseColumn implements Serializable {
    private static final long serialVersionUID = -7753171464918803015L;

    @TableId
    @ApiModelProperty(value = "id", name = "id", required = false)
    private Integer id;

    @ApiModelProperty(value = "知识点id", name = "knowledgeId", required = true)
    private Integer knowledgeId;

    @ApiModelProperty(value = "章节id", name = "sectionId", required = true)
    private Integer sectionId;

 /*   @ApiModelProperty(value = "知识点全称 代数-集合-集合的含义", name = "knowledgeAllname", required = true)
    private String knowledgeAllname;
*/
}
