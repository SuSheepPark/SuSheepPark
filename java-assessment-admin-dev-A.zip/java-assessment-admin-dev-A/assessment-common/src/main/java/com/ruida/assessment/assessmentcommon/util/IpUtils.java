package com.ruida.assessment.assessmentcommon.util;

import org.apache.commons.lang3.StringUtils;
import org.springframework.util.CollectionUtils;

import javax.servlet.http.HttpServletRequest;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
/**
 * 服务器IP地址工具类
 * @author szl
 */
public class IpUtils {
	
    /**
     * 获取服务器IP地址，支持多网卡多IP
     * @return
     * @throws SocketException
     */
    public static List<String> getLocalIPs() throws SocketException {
        InetAddress ip = null;
        List<String> ipList = new ArrayList<String>();
        Enumeration<NetworkInterface> netInterfaces = (Enumeration<NetworkInterface>) NetworkInterface
                .getNetworkInterfaces();
        while (netInterfaces.hasMoreElements()) {
            NetworkInterface ni = (NetworkInterface) netInterfaces.nextElement();
            Enumeration<InetAddress> ips = ni.getInetAddresses();
            while (ips.hasMoreElements()) {
                ip = (InetAddress) ips.nextElement();
                if (!ip.isLoopbackAddress()
                        && ip.getHostAddress().matches("(\\d{1,3}\\.){3}\\d{1,3}")) {
                    ipList.add(ip.getHostAddress());
                }
            }
        }

        return ipList;
    }

    /**
     * 指定的IP地址是否包含，local（当前服务器）IP地址
     * @param ipRange ip 范围，ip地址之间用,分隔
     * @return
     * @throws SocketException
     */
    public static boolean isIncludeLocalIP(String ipRange) throws SocketException {
        List<String> localIps = getLocalIPs();

        if (CollectionUtils.isEmpty(localIps) || StringUtils.isEmpty(ipRange)) {
            return false;
        } else {
            for (String ip : localIps) {
                if (ipRange.indexOf(ip) != -1) {
                    return true;
                }
            }
        }
        return false;
    }
    public static String getIpAddress(HttpServletRequest request) {
        String ip = request.getHeader("x-forwarded-for");
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("Proxy-Client-IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("WL-Proxy-Client-IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getRemoteAddr();
        }
        if (ip.contains(",")) {
            return ip.split(",")[0];
        } else {
            return ip;
        }
    }

}