package com.ruida.assessment.assessmentcommon.enums;

public enum DBTypeEnum {
    ceping("ceping"), ruidaCloud("ruidacloud");
    private String value;

    DBTypeEnum(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
