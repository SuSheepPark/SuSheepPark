package com.ruida.assessment.assessmentquestionbank.service;

import com.ruida.assessment.assessmentcommon.result.Page;
import com.ruida.assessment.assessmentquestionbank.dto.QueryBaseDTO;
import com.ruida.assessment.assessmentquestionbank.dto.UserMessageDTO;
import com.ruida.assessment.assessmentquestionbank.vo.MessageCustomVO;
import com.ruida.assessment.assessmentquestionbank.vo.UserMessageVO;

/**
 * @description:
 * @author: kgz
 * @date: 2020/7/24
 */
public interface MessageManagementService {
    /**
     * 分页查询消息列表
     * @param queryBaseDTO
     * @return
     */
    Page<MessageCustomVO> getMessageCustomList(QueryBaseDTO queryBaseDTO);

    /**
     * 获取消息详情
     * @param id
     * @return
     */
    MessageCustomVO getMessageCustomDetail(Integer id);

    /**
     * 发送消息
     * @param userMessage
     */
    void sendMessage(UserMessageDTO userMessage);

    /**
     * 删除自定义消息
     * @param id
     */
    void deleteMessageCustom(Integer id);
}
