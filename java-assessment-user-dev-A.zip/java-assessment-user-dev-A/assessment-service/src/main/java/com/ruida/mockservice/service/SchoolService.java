package com.ruida.mockservice.service;


import com.baomidou.mybatisplus.service.IService;
import com.ruida.mockdao.model.School;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * 学校信息表 服务类
 * </p>
 *
 * @author Bhj
 * @since 2020-07-13
 */
public interface SchoolService extends IService<School> {

    List<Map<String, Object>> listSchool(Integer province, Integer city, Integer district, String searchName);

    List<Map<String, Object>> listStage(Integer schoolId);

    List<Map<String, Object>> listClass(Integer schoolId, Integer stageId);

    Boolean addNewSchool(String schoolName);

    Boolean addNewClass(String className, Integer schoolId, Integer stageId);

    List<Map<String, Object>> listGrade(Integer schoolId);
}
