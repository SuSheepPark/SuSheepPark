package com.ruida.assessment.assessmentquestionbank.controller;

import com.ruida.assessment.assessmentcommon.result.PojoResult;
import com.ruida.assessment.assessmentquestionbank.dto.VisitDTO;
import com.ruida.assessment.assessmentquestionbank.service.VisitService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * @description: 网站访问信息控制层
 * @author: kgz
 * @date: 2020/8/4
 */
@RequestMapping("/visit")
@RestController
@Api(value ="用户消息相关接口")
public class VisitController {

    @Resource
    private VisitService visitService;

    @PostMapping("/pv/add")
    @ApiOperation(value = "增加网站访问量", notes = "增加网站访问量")
    public PojoResult addPageView(){
        PojoResult pojoResult = new PojoResult();
        visitService.addPageView();
        return pojoResult;
    }

    @PostMapping("/uv/save")
    @ApiOperation(value = "保存网站访客记录", notes = "保存网站访客记录")
    public PojoResult saveUniqueVisitor(@RequestBody VisitDTO visitDTO){
        PojoResult pojoResult = new PojoResult();
        visitService.saveUniqueVisitor(visitDTO);
        return pojoResult;
    }
}
