package com.ruida.mockdao.vo.major;

import lombok.Data;

import java.util.List;

/**
 * @author xumingqi
 * @date 2021/1/14 13:08
 */
@Data
public class MajorGroupVO {
    String subjectCategoryCode;
    String subjectCategoryName;
    List<MajorVO> majorVOList;
}
