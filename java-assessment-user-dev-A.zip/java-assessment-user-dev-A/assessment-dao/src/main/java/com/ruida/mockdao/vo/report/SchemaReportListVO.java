package com.ruida.mockdao.vo.report;

import com.ruida.mockdao.model.SchemaReport;
import lombok.Data;

import java.util.List;

/**
 * @author xumingqi
 * @date 2021/3/3 11:35
 */
@Data
public class SchemaReportListVO extends SchemaReport {
    List<String> subjectList;
}
