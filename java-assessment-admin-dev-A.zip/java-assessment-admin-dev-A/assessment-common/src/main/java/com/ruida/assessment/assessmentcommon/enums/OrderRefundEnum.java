package com.ruida.assessment.assessmentcommon.enums;

/**
 * @description: 是否已退费枚举
 * @author: kgz
 * @date: 2020/8/3
 */
public enum OrderRefundEnum {
    REFUND_FALSE(0,"否"),
    REFUND_TRUE(1,"是"),
    ;

    private Integer K;
    private String V;

    OrderRefundEnum(Integer k, String v) {
        K = k;
        V = v;
    }

    public Integer getK() {
        return K;
    }

    public void setK(Integer k) {
        K = k;
    }

    public String getV() {
        return V;
    }

    public void setV(String v) {
        V = v;
    }

    public static OrderRefundEnum getValueById(Integer K){
        if(K != null){
            for(OrderRefundEnum orderRefundEnum : OrderRefundEnum.values() ){
                if(orderRefundEnum.getK().equals(K)){
                    return  orderRefundEnum;
                }
            }
        }
        return null;
    }
}
