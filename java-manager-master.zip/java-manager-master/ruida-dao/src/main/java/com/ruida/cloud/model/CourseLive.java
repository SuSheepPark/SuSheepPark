package com.ruida.cloud.model;

import com.ruida.common.util.excel.ExcelAnnotation;

import java.io.Serializable;

/**
 * @author admin
 * @description: ${TODO}
 * @Date 2020/3/13
 * @verion 1.0
 */
public class CourseLive implements Serializable {

    private static final long serialVersionUID = 6144293127441855959L;
    /**
     * 课程链接
     */
    @ExcelAnnotation(title = "课程ID")
    private Integer courseId;
    /**课程名字*/
    @ExcelAnnotation(title = "课程名字")
    private String courseName;
    /**课程开课时间*/
    @ExcelAnnotation(title = "开课时间")
    private String startDates;
    /**课程H5购买链接*/
    @ExcelAnnotation(title = "课程H5购买链接")
    private String H5Link;

    public Integer getCourseId() {
        return courseId;
    }

    public void setCourseId(Integer courseId) {
        this.courseId = courseId;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public String getStartDates() {
        return startDates;
    }

    public void setStartDates(String startDates) {
        this.startDates = startDates;
    }

    public String getH5Link() {
        return H5Link;
    }

    public void setH5Link(String h5Link) {
        H5Link = h5Link;
    }
}
