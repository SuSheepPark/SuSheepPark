package com.ruida.cloud.weidu.service.impl;

import com.ruida.cloud.weidu.config.WeiduConfig;
import com.ruida.cloud.weidu.dao.VdyooFactory;
import com.ruida.cloud.weidu.utils.PropertyUtil;
import com.ruida.cloud.weidu.utils.VdyooUtil;
import com.ruida.cloud.weidu.vo.Result;
import com.ruida.cloud.weidu.vo.VdyooEntity;
import com.sun.org.apache.xpath.internal.operations.Bool;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.Map;

/**
 * @author taosh
 * @create 2019-04-23 15:10
 */
@Service
public class VdyooClassRoomService {
    @Resource
    private VdyooFactory vdyooFactory;

    /**
     * 查询公司下所有教室
     */
    public VdyooEntity findRoomByTenant(){
        Map<String, Object> param = new HashMap<>();
        VdyooEntity entity = vdyooFactory.post(param, WeiduConfig.findRoomByTenant);
        return entity;
    }

    /**
     * 根据教室ID查询教室信息
     * @param id
     */
    public VdyooEntity getRoomById(String id){
        Map<String, Object> param = new HashMap<>(1);
        //威渡id
        param.put("id", id);
        VdyooEntity entity = vdyooFactory.post(param, WeiduConfig.getRoomById);
        return entity;
    }

    /**
     * 编辑教室地址
     */
    public Boolean updateRoomById(String id, String address){
        Map<String, Object> param = new HashMap<>(2);
        //威渡id
        param.put("id", id);
        //地址
        param.put("address", address);
        return  vdyooFactory.post(param, WeiduConfig.updateRoomById).getSuccess();
    }
}
