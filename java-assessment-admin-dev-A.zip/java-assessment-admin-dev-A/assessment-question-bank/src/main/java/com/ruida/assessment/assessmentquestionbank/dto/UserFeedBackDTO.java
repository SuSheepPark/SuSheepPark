package com.ruida.assessment.assessmentquestionbank.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @description: 用户反馈DTO
 * @author: kgz
 * @date: 2020/8/10
 */
@ApiModel(description = "用户反馈查询条件")
public class UserFeedBackDTO extends QueryBaseDTO {

    @ApiModelProperty(value = "用户意见反馈关联主键ID", name = "suggestionId")
    private Integer suggestionId;

    @ApiModelProperty(value = "用户意见反馈关联主键ID", name = "id")
    private String id;

    @ApiModelProperty(value = "关键字，反馈内容、学员账号", name = "keyWords")
    private String keyWords;

    @ApiModelProperty(value = "反馈状态", name = "status")
    private Integer status;

    @ApiModelProperty(value = "回复内容", name = "replyContent")
    private String replyContent;

    @ApiModelProperty(value = "开始时间", name = "startTime")
    private String startTime;

    @ApiModelProperty(value = "结束时间", name = "endTime")
    private String endTime;

    public String getKeyWords() {
        return keyWords;
    }

    public void setKeyWords(String keyWords) {
        this.keyWords = keyWords;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public Integer getSuggestionId() {
        return suggestionId;
    }

    public void setSuggestionId(Integer suggestionId) {
        this.suggestionId = suggestionId;
    }

    public String getReplyContent() {
        return replyContent;
    }

    public void setReplyContent(String replyContent) {
        this.replyContent = replyContent;
    }

    public List<Integer> getIdList() {
        if(StringUtils.isNotEmpty(this.id)){
            List<Integer> idList = Arrays.asList(this.id.split(",")).stream().map(x -> Integer.valueOf(x)).collect(Collectors.toList());
            return idList;
        }
        return new ArrayList<>();
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
