package com.ruida.assessment.assessmentquestionbank.model;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;

/**
 * @description: 科目数据库实体
 * @author: kgz
 * @date: 2020/6/18
 */
@TableName("t_subject")
public class TSubject extends BaseColumn implements Serializable {
    private static final long serialVersionUID = 8618842431927564362L;

    /**
     * 学段id
     */
    @TableId
    private Integer id;

    /**
     * 科目名称
     */
    private String subjectName;

    /**
     * 状态（0—禁用；1—启用）
     */
    private String status;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getSubjectName() {
        return subjectName;
    }

    public void setSubjectName(String subjectName) {
        this.subjectName = subjectName;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
