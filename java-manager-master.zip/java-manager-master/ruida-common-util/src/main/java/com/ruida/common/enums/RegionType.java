package com.ruida.common.enums;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * 0—小于；1—小于等于；2—等于；3—大于；4—大于等于
 */
public enum RegionType {
    less_than(0,"小于"), less_equal(1,"小于等于"),  equal(2,"等于"),  big_than(3,"大于"),  big_equal(4,"大于等于");

    public static final String SOURCE_KEY = "RegionType";

    private int k;
    private String v;

    RegionType(int k, String v) {
        this.k = k;
        this.v = v;
    }

    public static Map<Integer, String> map = new LinkedHashMap<>(2);
    static
    {
        for(RegionType type : RegionType.values())
        {
            map.put(type.getK(),type.getV());
        }
    }

    public static String getSourceKey() {
        return SOURCE_KEY;
    }

    public int getK() {
        return k;
    }

    public void setK(int k) {
        this.k = k;
    }

    public String getV() {
        return v;
    }

    public void setV(String v) {
        this.v = v;
    }

    /***
     * 根据k获取v的值
     * @param k
     * @return
     */
    public static String getvByk(int k) {
        RegionType[] list = RegionType.values();
        for (RegionType valid : list) {
            if (valid.getK() == k ) {
                return valid.getV();
            }
        }
        return "";
    }
}
