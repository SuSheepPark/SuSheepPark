package com.ruida.mockdao.model;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableLogic;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;
import lombok.Data;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 知识点用户统计表
 * </p>
 *
 * @author jinhu
 * @since 2020-08-11
 */
@Data
@Accessors(chain = true)
@TableName("stat_knowledge_user_rel")
public class StatKnowledgeUserRel implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 自增主键
     */
    @TableId(value = "rel_id", type = IdType.AUTO)
    private Integer relId;
    /**
     * 用户id
     */
    @TableField("user_id")
    private Integer userId;
    /**
     * 学生id
     */
    @TableField("stu_id")
    private Integer stuId;
    /**
     * 考试id
     */
    @TableField("exam_record_id")
    private Integer examRecordId;
    /**
     * 知识点id
     */
    @TableField("knowledge_id")
    private Integer knowledgeId;
    /**
     * 知识点名称
     */
    @TableField("knowledge_name")
    private String knowledgeName;
    /**
     * 满分
     */
    @TableField("full_score")
    private Double fullScore;
    /**
     * 实际得分
     */
    @TableField("real_score")
    private Double realScore;
    /**
     * 创建人
     */
    @TableField("create_by")
    private Integer createBy;
    /**
     * 创建时间
     */
    @TableField("create_time")
    private Date createTime;
    /**
     * 更新者
     */
    @TableField("update_by")
    private Integer updateBy;
    /**
     * 更新时间
     */
    @TableField("update_time")
    private Date updateTime;
    /**
     * 删除符号 0-未删除 1-删除
     */
    @TableLogic
    private Integer isdelete;


}
