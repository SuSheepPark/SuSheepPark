package com.ruida.mockcommon.auth.pojo;

import java.io.Serializable;

import com.ruida.mockcommon.enums.AuthCheckType;

/**
 * JWTInfo  带的用户信息
 * @author mlzhang
 */
public class JWTInfo implements Serializable {
    private String username;
    private String userId;
    private String source;
    //学生id
    private String stuId;
    //用户密码
    private String password;
    private Integer roleId;
    private Integer roleType ;
    private String roleName ;
    private Integer personId;
    private String realName;
    private AuthCheckType authCheckType;

    public String getRealName() {
        return realName;
    }

    public void setRealName(String realName) {
        this.realName = realName;
    }

    public Integer getPersonId() {
        return personId;
    }

    public void setPersonId(Integer personId) {
        this.personId = personId;
    }

    public JWTInfo(){}

    public JWTInfo(String username, String userId, String source) {
        this.username = username;
        this.userId = userId;
        this.source = source;
    }


    public JWTInfo(String stuId, String source) {
        this.stuId = stuId;
        this.source = source;
    }
    
    public Integer getRoleId() {
        return roleId;
    }

    public void setRoleId(Integer roleId) {
        this.roleId = roleId;
    }

    public Integer getRoleType() {
        return roleType;
    }

    public void setRoleType(Integer roleType) {
        this.roleType = roleType;
    }

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getStuId() {
        return stuId;
    }

    public void setStuId(String stuId) {
        this.stuId = stuId;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }


    @Override
    public String toString() {
        return "JWTInfo{" +
                "username='" + username + '\'' +
                ", userId='" + userId + '\'' +
                ", source='" + source + '\'' +
                '}';
    }

	public AuthCheckType getAuthCheckType() {
		return authCheckType;
	}

	public void setAuthCheckType(AuthCheckType authCheckType) {
		this.authCheckType = authCheckType;
	}


}
