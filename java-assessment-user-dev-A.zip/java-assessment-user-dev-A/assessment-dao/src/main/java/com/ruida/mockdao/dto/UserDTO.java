package com.ruida.mockdao.dto;

import lombok.Data;

/**
 * @description: 用户信息DTO
 * @author: chenjy
 * @create: 2021-01-20 15:57
 */
@Data
public class UserDTO {

    private Integer userId;

    private String userName;

    private String realName;

    private String headImg;

    private String telephone;

    private String className;

    private String schoolName;

    private String roleName;
}
