package com.ruida.cloud.daoTmp;

import lombok.Data;


@Data
public class BaijiayunParams {

    //上传地址
    private String upload_url;
    //视频Id
    private String video_id;
    //视频时长，单位：秒
    private String duration;
    //文件大小，单位：字节
    private String size;
    //视频宽
    private String width;
    //视频播放地址（该地址有效期是通过expires_in参数控制，默认为12小时）
    private String url;
    //视频高
    private String height;
}
