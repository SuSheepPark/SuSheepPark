package com.ruida.assessment.assessmentquestionbank.ruidacloudDao;

import com.ruida.assessment.assessmentquestionbank.model.TDepartment;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.assessment.assessmentquestionbank.model.ext.TDepartmentExt;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * <p>
 * 部门表 Mapper 接口
 * </p>
 *
 * @author szl
 * @since 2020-07-14
 */
public interface TDepartmentMapper extends BaseMapper<TDepartment> {
    /**
     * 分页查询部门
     *
     * @param pageNo
     * @param pageSize
     * @return
     */
    @Select("SELECT\n" +
            "\ta.department_id AS departmentId,\n" +
            "\ta.department_name AS departmentName,\n" +
            "\ta.`status`,\n" +
            "\ta.create_time AS createTime,\n" +
            "\ta.update_time AS updateTime,\n" +
            "\tGROUP_CONCAT(DISTINCT c.telephone)  as telephone,\n" +
            " GROUP_CONCAT(DISTINCT c.real_name)\t AS realName\n" +
            "FROM\n" +
            "\tt_department a\n" +
            " LEFT JOIN sys_user_role b ON a.department_id = b.department_id \n" +
            " LEFT JOIN sys_role d ON b.role_id = d.role_id  AND d.role_type = 1\n" +
            " LEFT JOIN sys_user c ON b.user_id = c.user_id AND  d.role_id IS NOT NULL\n" +
            "WHERE\n" +
            "\ta.isdelete = 0 \n" +
            "GROUP BY\n" +
            "\ta.department_id\n" +
            "ORDER BY\n" +
            "\ta.create_time DESC\n" +
            "LIMIT  #{pageNo},#{pageSize} ")
    List<TDepartment> selectDepartmentByPage(@Param("pageNo") Integer pageNo, @Param("pageSize") Integer pageSize);

    @Select("SELECT\n" +
            "\ta.department_id AS departmentId,a.department_name AS departmentName\n" +
            "FROM\n" +
            "\tt_department a\n" +
            "LEFT JOIN sys_role b ON b.department_id = a.department_id\n" +
            "LEFT JOIN sys_user_role c ON c.role_id = b.role_id\n" +
            "WHERE c.user_id = #{userId}")
    List<TDepartmentExt> getDepartMentByUserId(@Param("userId") Integer userId);//查询用户的部门信息
    @Select("SELECT\n" +
            "\ta.department_id AS departmentId,\n" +
            "\ta.department_name AS departmentName,\n" +
            "\ta.`status`,\n" +
            "\ta.create_time AS createTime,\n" +
            "\ta.update_time AS updateTime,\n" +
            "\tc.telephone,\n" +
            "\tc.real_name realName\n" +
            "FROM\n" +
            "\tt_department a\n" +
            "LEFT JOIN sys_user_role b ON a.department_id = b.department_id\n" +
            "LEFT JOIN sys_role d ON d.role_type = 1\n" +
            "OR d.role_type = 0\n" +
            "LEFT JOIN sys_user c ON b.user_id = c.user_id\n" +
            "WHERE\n" +
            "\ta.isdelete = 0\n" +
            "AND a.department_id = #{departmentId}\n" +
            "GROUP BY\n" +
            "\ta.department_id")
    TDepartment getDepartmentById(@Param("departmentId") Integer departmentId);
}
