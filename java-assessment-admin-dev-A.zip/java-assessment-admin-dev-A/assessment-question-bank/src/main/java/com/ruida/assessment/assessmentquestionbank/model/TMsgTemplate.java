package com.ruida.assessment.assessmentquestionbank.model;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;

import java.io.Serializable;

/**
 * @description: 消息模板数据库实体
 * @author: kgz
 * @date: 2020/7/20
 */
@TableName("t_message_tpl")
public class TMsgTemplate extends BaseColumn implements Serializable {
    private static final long serialVersionUID = 6070742306075776971L;
    /**
     * 消息模板id
     */
    @TableId
    private Integer messageTplId;

    /**
     * 标签，消息模板名称
     */
    private String tag;

    /**
     * 消息模板类型
     * 0—系统出发消息<需同时发送手机号码；1—主动推动消息>
     */
    private Integer messageTplType;

    /**
     * 消息模板编号
     * 0—开课提醒；1—账号注册完成后系统通知；2—购买成功提醒；3—付款提醒；4—课程变动提醒；5-备课资料更新提醒
     */
    private Integer messageTplNo;

    /**
     * 消息模板信息
     */
    private String message;

    /**
     * 是否弹出消息模板
     * 0—不弹出；1—弹出
     */
    private Integer forpop;

    /**
     * 状态（0—禁用；1—启用）
     */
    private Integer status;

    public Integer getMessageTplId() {
        return messageTplId;
    }

    public void setMessageTplId(Integer messageTplId) {
        this.messageTplId = messageTplId;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public Integer getMessageTplType() {
        return messageTplType;
    }

    public void setMessageTplType(Integer messageTplType) {
        this.messageTplType = messageTplType;
    }

    public Integer getMessageTplNo() {
        return messageTplNo;
    }

    public void setMessageTplNo(Integer messageTplNo) {
        this.messageTplNo = messageTplNo;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Integer getForpop() {
        return forpop;
    }

    public void setForpop(Integer forpop) {
        this.forpop = forpop;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "TMsgTemplate{" +
                "messageTplId=" + messageTplId +
                ", tag='" + tag + '\'' +
                ", messageTplType=" + messageTplType +
                ", messageTplNo=" + messageTplNo +
                ", message='" + message + '\'' +
                ", forpop=" + forpop +
                ", status=" + status +
                '}';
    }
}
