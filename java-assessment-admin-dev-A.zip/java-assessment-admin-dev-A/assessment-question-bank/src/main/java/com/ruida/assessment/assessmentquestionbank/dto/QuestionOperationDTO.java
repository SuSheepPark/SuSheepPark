package com.ruida.assessment.assessmentquestionbank.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * @description: 试题操作DTO
 * @author: kgz
 * @date: 2020/6/8
 */
@ApiModel(description = "试题操作信息")
public class QuestionOperationDTO {

    @ApiModelProperty(value = "试题id，逗号分隔", name = "questionId", required = true)
    private String questionId;

    @ApiModelProperty(value = "操作id", name = "operationId", required = true)
    private Integer operationId;

    @ApiModelProperty(value = "拒绝原因", name = "rejectReason", required = true)
    private String rejectReason;

    @ApiModelProperty(value = "评价", name = "evaluation", required = true)
    private String evaluation;

    public String getQuestionId() {
        return questionId;
    }

    public void setQuestionId(String questionId) {
        this.questionId = questionId;
    }

    /**
     * 转换并获取试题id集合
     * @return
     */
    public List<String> getQuestionIdList() {
        return Arrays.asList(questionId.split(","));
    }

    public Integer getOperationId() {
        return operationId;
    }

    public void setOperationId(Integer operationId) {
        this.operationId = operationId;
    }

    public String getRejectReason() {
        return rejectReason;
    }

    public void setRejectReason(String rejectReason) {
        this.rejectReason = rejectReason;
    }

    public String getEvaluation() {
        return evaluation;
    }

    public void setEvaluation(String evaluation) {
        this.evaluation = evaluation;
    }

    @Override
    public String toString() {
        return "QuestionOperationDTO{" +
                "questionId='" + questionId + '\'' +
                ", operationId=" + operationId +
                ", rejectReason='" + rejectReason + '\'' +
                ", evaluation='" + evaluation + '\'' +
                '}';
    }
}
