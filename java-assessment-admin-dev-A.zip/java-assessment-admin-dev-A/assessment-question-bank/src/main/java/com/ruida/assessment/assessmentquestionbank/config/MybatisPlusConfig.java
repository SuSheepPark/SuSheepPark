package com.ruida.assessment.assessmentquestionbank.config;

import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.druid.spring.boot.autoconfigure.DruidDataSourceBuilder;
import com.baomidou.mybatisplus.MybatisConfiguration;
import com.baomidou.mybatisplus.plugins.PaginationInterceptor;
import com.baomidou.mybatisplus.spring.boot.starter.MybatisPlusProperties;
import com.ruida.assessment.assessmentcommon.enums.DBTypeEnum;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.AutoConfigureAfter;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.sql.DataSource;
import java.util.HashMap;
import java.util.Map;

/**
 * @author  mlzhang
 */
@Configuration
@EnableTransactionManagement
@MapperScan(basePackages = {"com.ruida.assessment.assessmentquestionbank.dao","com.ruida.assessment.assessmentquestionbank.ruidacluodDao"})
@EnableConfigurationProperties(MybatisPlusProperties.class)
@AutoConfigureAfter(DataSourceAutoConfiguration.class)
public class MybatisPlusConfig {
    /**
     * druid配置
     */
    @Bean(name = "ceping")
    @ConfigurationProperties(prefix = "spring.datasource.ceping")
    public DataSource db1() {
        return DruidDataSourceBuilder.create().build();
    }

   /* @Bean(name = "ruidacloud")
    @ConfigurationProperties(prefix = "spring.datasource.ruidacloud")
    public DataSource db2() {
        return DruidDataSourceBuilder.create().build();
    }*/
    /**
     * 单数据源连接池配置
     */
  /*  @Bean(name = "dataSource")
    public DruidDataSource dataSource(DruidProperties druidProperties) {
        DruidDataSource dataSource = new DruidDataSource();
        druidProperties.config(dataSource);
        return dataSource;
    }*/
    /**
     * 动态数据源配置
     *
     * @return
     */
    @Bean
    @Primary
    public DataSource multipleDataSource(@Qualifier("ceping") DataSource db1) {
        DynamicDataSource dynamicDataSource = new DynamicDataSource();
        Map<Object, Object> targetDataSources = new HashMap<>(2);
        targetDataSources.put(DBTypeEnum.ceping.getValue(), db1);
//        targetDataSources.put(DBTypeEnum.ruidaCloud.getValue(), db2);
        dynamicDataSource.setTargetDataSources(targetDataSources);
        // 程序默认数据源，这个要根据程序调用数据源频次，经常把常调用的数据源作为默认
        dynamicDataSource.setDefaultTargetDataSource(db1);
        return dynamicDataSource;
    }
    /**
     * mybatis-plus分页插件
     */
    @Bean
    public PaginationInterceptor paginationInterceptor() {
        return new PaginationInterceptor();
    }
/*    @Bean(name = "sqlSessionFactory")
    public SqlSessionFactory sqlSessionFactory() throws Exception {
        MybatisSqlSessionFactoryBean sqlSessionFactoryBean = new MybatisSqlSessionFactoryBean();
        sqlSessionFactoryBean.setDataSource(multipleDataSource(db1(), db2()));
        sqlSessionFactoryBean.getObject().getConfiguration().setMapUnderscoreToCamelCase(true);
        MybatisConfiguration mybatisConfiguration = new MybatisConfiguration();
        mybatisConfiguration.setCallSettersOnNulls(true);
        sqlSessionFactoryBean.setConfiguration(mybatisConfiguration);
        ResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
        sqlSessionFactoryBean
                .setMapperLocations(resolver.getResources("classpath*:/mapper/*Mapper.xml"));
        return sqlSessionFactoryBean.getObject();
    }*/
//
//
//    @Bean
//    public DataSourceTransactionManager dataSourceTransactionManager(@Qualifier("dataSource") DruidDataSource dataSource){
//        return  new DataSourceTransactionManager(dataSource);
//    }

}
