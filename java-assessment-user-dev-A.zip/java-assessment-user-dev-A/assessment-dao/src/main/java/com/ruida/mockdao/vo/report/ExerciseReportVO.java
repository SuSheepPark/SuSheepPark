package com.ruida.mockdao.vo.report;

import com.ruida.mockdao.vo.KnowledgeStatVO;
import lombok.Data;

import java.util.List;

/**
 * @author chenjy
 * @date 2021/3/9
 */
@Data
public class ExerciseReportVO {

    /**
     * 报告id
     */
    private Integer reportId;

    /**
     * 是否购买
     */
    private Boolean needBuy;

    /**
     * 报告价格
     */
    private Double reportPrice;

    /**
     * 考试记录id
     */
    private Integer examRecordId;

    /**
     * 报告基础信息
     */
    private ReportBaseInfo reportBaseInfo;

    /**
     * 联考分数、排名等信息
     */
    private ScoreRank unionScoreRank;

    /**
     * 预测信息
     */
    private ConstCalculate constCalculate;

    /**
     * 知识点信息
     */
    private KnowledgeRow lowKnowledgeRow;

    /**
     * 题型维度
     */
    private TestPaperQuestionInfoVO reportQuestionTypeList;

    /**
     * 知识点维度
     */
    private ReportStatKnowledgeVO2 reportKnowledge;

    /**
     * 考察目标维度
     */
    private ReportTargetStatVO2 reportTarget;

    @Data
    public static class ReportBaseInfo{

        private String reportName;

        private String studentName;

        private String className;

        private String schoolName;

        private String subjectName;

        private Double score;

        private Double totalScore;
    }

    @Data
    public static class ScoreRank{
        private Integer rank;

        private Integer count;

        private Double top;

        private Double avg;
        
        private Double percent;
        
        private String desc;
    }
    
    @Data
    public static class ConstCalculate{
        private Integer score;
        
        private String collegeLevel;
        
        private List<ConstCollegeForecastRow> constCollegeForecastTable;
    }
    
    @Data
    public static class ConstCollegeForecastRow{
        private String collegeLevel;
        
        private Integer highScore;
        
        private Integer lowScore;
    }
    
    @Data
    public static class KnowledgeRow{
        /**
         * 0-正常推荐，1-没有薄弱知识点，2-没有挂载知识点
         */
        private Integer status;
        
        private List<KnowledgeBlock> knowledgeList;
        
        @Data
        public static class KnowledgeBlock{
            private String knowledgeName;
            
            private Double percent;
        }
    }
    
    @Data
    public static class TestPaperQuestionInfoVO{
        private Integer nodeSize;
        private Integer questionSize;
        private Integer rightQuestionSize;
        private List<TestPaperNodeVO> nodeVos;
    }
    
    @Data
    public static class ReportStatKnowledgeVO2{
        private KnowledgeRow lowKnowledge;
        private KnowledgeRow highKnowledge;
        private List<KnowledgeStatVO> knowledgeTree;
    }
    
    @Data
    public static class ReportTargetStatVO2{
    	/**
    	 * 0-薄弱和较好都有，正常显示；1-只有较好没有薄弱；2-只有薄弱没有较好；3没有考察要求
    	 */
    	private Integer status;
    	private List<String> lowList;
    	private List<String> highList;
    	private ReportTargetStatVO reportTarget;
    }
}

