package com.ruida.cloud.dao;

import com.ruida.cloud.daoTmp.CourseOrderExt;

import java.util.Map;

public interface CourseOrderExtMapper {
    CourseOrderExt getCourseExt(Map<String, Object> param);
    CourseOrderExt  getCourseExtByOnline(Map<String, Object> param);
}