package com.ruida.mockdao.vo.report;

import lombok.Data;

import java.io.Serializable;

/**
 * @description: 报告题型VO
 * @author: chenjy
 * @create: 2020-08-05 16:28
 */
@Data
public class ReportQuestionTypeVO implements Serializable {

    /**题型名称*/
    private String questionTypeName;

    /**得分*/
    private Double score;

    /**班级平均分*/
    private Double classAvgScore;

    /**学校平均分*/
    private Double schoolAvgScore;

    /**联考学校平均分*/
    private Double unionAvgScore;

    /**总分*/
    private Double totalScore;
}
