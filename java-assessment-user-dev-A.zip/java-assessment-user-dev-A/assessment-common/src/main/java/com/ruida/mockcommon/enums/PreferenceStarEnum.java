package com.ruida.mockcommon.enums;

public enum PreferenceStarEnum {
    ONE_STAR(1,"可保底"),
    TWO_STAR(2,"可冲击"),
    THREE_STAR(3,"较稳妥");
    private  Integer key;
    private String val;
    PreferenceStarEnum(Integer key,String val){
        this.key = key;
        this.val = val;
    }
   public static String getValByKey(Integer key){
        PreferenceStarEnum[] list = PreferenceStarEnum.values();
        for (PreferenceStarEnum s : list) {
        if (s.key.equals(key)){
            return s.val;
        }
        }
        return null;
    }


}
