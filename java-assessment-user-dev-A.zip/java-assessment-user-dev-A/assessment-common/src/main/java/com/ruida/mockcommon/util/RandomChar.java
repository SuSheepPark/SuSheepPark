package com.ruida.mockcommon.util;

import java.util.Random;

public class RandomChar {
    public static String getRandomChar( int num) throws Exception {
        StringBuffer sb=new StringBuffer();
        Random random = new Random();
        for (int i = 0; i < num; i++) {
            sb.append((char) (97 + random.nextInt(26)));
        }
        return sb.toString();
    }

    public static void main(String[] args) throws Exception {
        System.out.println(getRandomChar(2));
    }
}
