package com.ruida.assessment.assessmentquestionbank.model;

import com.baomidou.mybatisplus.enums.IdType;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.enums.IdType;
import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableName;
import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author szl
 * @since 2020-07-23
 */
@TableName("t_user_period_subject")
public class TUserPeriodSubject extends Model<TUserPeriodSubject> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;
    @TableField("user_id")
    private Integer userId;
    @TableField("role_id")
    private Integer roleId;
    /**
     * 学段id
     */
    @TableField("period_id")
    private Integer periodId;
    /**
     * 学科id
     */
    @TableField("subject_id")
    private Integer subjectId;
    /**
     * 逻辑删除符（0-未删除 1-已删除）
     */
    private Integer isdelete;
    /**
     * 学段名字
     */
    @TableField(exist = false)
    private String periodName;
    /**
     * 学科名字
     */
    @TableField(exist = false)
    private String subjectName;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Integer getPeriodId() {
        return periodId;
    }

    public void setPeriodId(Integer periodId) {
        this.periodId = periodId;
    }

    public Integer getSubjectId() {
        return subjectId;
    }

    public void setSubjectId(Integer subjectId) {
        this.subjectId = subjectId;
    }

    public Integer getIsdelete() {
        return isdelete;
    }

    public void setIsdelete(Integer isdelete) {
        this.isdelete = isdelete;
    }

    @Override
    protected Serializable pkVal() {
        return this.id;
    }

    public String getPeriodName() {
        return periodName;
    }

    public void setPeriodName(String periodName) {
        this.periodName = periodName;
    }

    public String getSubjectName() {
        return subjectName;
    }

    public void setSubjectName(String subjectName) {
        this.subjectName = subjectName;
    }

    public Integer getRoleId() {
        return roleId;
    }

    public void setRoleId(Integer roleId) {
        this.roleId = roleId;
    }
    @Override
    public String toString() {
        return "TUserPeriodSubject{" +
        ", id=" + id +
        ", userId=" + userId +
        ", periodId=" + periodId +
        ", subjectId=" + subjectId +
        ", isdelete=" + isdelete +
        "}";
    }
}
