package com.ruida.assessment.assessmentquestionbank.dto;

import com.ruida.assessment.assessmentquestionbank.model.Weight;
import lombok.Data;

import java.util.List;

/**
 * @author xumingqi
 * @date 2020/12/15 16:22
 */
@Data
public class UpgradeReportRecordDTO {
    /**
     * 主键ID
     */
    private Integer id;

    /**
     * 统考名称
     */
    private String examName;

    /**
     * 年级段名称
     */
    private String stageName;
    /**
     * 年级段id
     */
    private String stageId;

    /**
     * 统考时间，是一个字符串，格式如2020.5
     */
    private String examTimeStr;

    /**
     * 本次考试成绩上传记录id(对应表的t_upload_exam_record的主键)
     */
    private Integer currentExamUploadId;

    /**
     * 本次成绩记录商品id(对应t_product主键)
     */
    private Integer currentExamProductId;

    /**
     * 历次成绩导入记录id(用英文逗号分隔，对应表t_upload_exam_record的主键)
     */
    private String historyExamUploadIds;

    /**
     * 历次成绩商品id(用英文逗号分隔，对应表t_product的主键)
     */
    private String historyExamProductIds;

    /**
     * 本次成绩上传类型（0 代表线下；1 代表线上已有并且关联商品）
     */
    private Integer uploadType;

    /**
     * 是否引用平台历史数据（0 不引用；1 引用）
     */
    private Integer isplatRel;

    /**
     * 报告权重
     */
    private List<Weight> weightList;
}
