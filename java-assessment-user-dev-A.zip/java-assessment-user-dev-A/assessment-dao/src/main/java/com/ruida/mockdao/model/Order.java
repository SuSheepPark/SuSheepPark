package com.ruida.mockdao.model;

import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;
import com.fasterxml.jackson.annotation.JsonFormat;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * <p>
 * 订单信息表
 * </p>
 *
 * @author Bhj
 * @since 2020-07-20
 */
@TableName("t_order")
public class Order extends Model<Order> {

    private static final long serialVersionUID = 1L;

    /**
     * 订单主键ID
     */
    @TableId(value = "order_id", type = IdType.AUTO)
    private Integer orderId;
    /**
     * 订单编号
     */
    @TableField("order_no")
    private String orderNo;

    @TableField("product_id")
    private Integer productId;
    /**
     * 订单交易号
     */
    @TableField("order_trans_no")
    private String orderTransNo;

    /**
     * 报告记录id(职业兴趣测试报告)
     */
    @TableField("record_id")
    private Integer recordId;

    /**
     * 是否购买报告(0-未购买; 1-已购买)
     */
    @TableField("is_purchase_report")
    private Integer isPurchaseReport;
    /**
     * 订单类型（0-试卷 8-志愿填报）
     */
    @TableField("order_type")
    private Integer orderType;
    /**
     * 订单名称
     */
    @TableField("order_name")
    private String orderName;
    /**
     * 订单金额
     */
    @TableField("order_amount")
    private BigDecimal orderAmount;
    /**
     * 折扣金额
     */
    @TableField("sale_amount")
    private BigDecimal saleAmount;
    /**
     * 实付金额
     */
    @TableField("pay_amount")
    private BigDecimal payAmount;
    /**
     * 购买人ID（关联sys_user表的user_id）
     */
    @TableField("purchaser_id")
    private Integer purchaserId;
    /**
     * 购买人姓名
     */
    @TableField("purchaser_name")
    private String purchaserName;
    /**
     * 购买人联系电话
     */
    private String telephone;
    /**
     * 支付方式（0—微信支付；1—支付宝；2—QQ钱包；3—网银支付；4—线下支付；5—免费）
     */
    @TableField("payment_type")
    private Integer paymentType;
    /**
     * 付款账号
     */
    @TableField("payment_account")
    private String paymentAccount;
    /**
     * 订单状态（0—待支付；1—已支付；2—已关闭; 3-待确认；4-退款中；5-已退款）
     */
    private Integer status;
    /**
     * 订单来源（0—PC端；1—IOS端；2—Android端；3—H5；4—线下交易；5—测试订单 ）
     */
    private Integer source;
    /**
     * 订单创建时间
     */
    @TableField("create_time")
    @JsonFormat(pattern= "yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date createTime;
    /**
     * 订单更新时间
     */
    @TableField("update_time")
    @JsonFormat(pattern= "yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date updateTime;
    /**
     * 订单付款时间
     */
    @TableField("payment_time")
    @JsonFormat(pattern= "yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date paymentTime;
    /**
     * 交易关闭时间
     */
    @TableField("close_time")
    @JsonFormat(pattern= "yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date closeTime;
    /**
     * 是否删除（0：未删除；1：删除）
     */
    private Integer isdelete;


    public Integer getOrderId() {
        return orderId;
    }

    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    public Integer getProductId() {
        return productId;
    }

    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public String getOrderTransNo() {
        return orderTransNo;
    }

    public void setOrderTransNo(String orderTransNo) {
        this.orderTransNo = orderTransNo;
    }

    public Integer getRecordId() {
        return recordId;
    }

    public void setRecordId(Integer recordId) {
        this.recordId = recordId;
    }

    public Integer getIsPurchaseReport() {
        return isPurchaseReport;
    }

    public void setIsPurchaseReport(Integer isPurchaseReport) {
        this.isPurchaseReport = isPurchaseReport;
    }

    public Integer getOrderType() {
        return orderType;
    }

    public void setOrderType(Integer orderType) {
        this.orderType = orderType;
    }

    public String getOrderName() {
        return orderName;
    }

    public void setOrderName(String orderName) {
        this.orderName = orderName;
    }

    public BigDecimal getOrderAmount() {
        return orderAmount;
    }

    public void setOrderAmount(BigDecimal orderAmount) {
        this.orderAmount = orderAmount;
    }

    public BigDecimal getSaleAmount() {
        return saleAmount;
    }

    public void setSaleAmount(BigDecimal saleAmount) {
        this.saleAmount = saleAmount;
    }

    public BigDecimal getPayAmount() {
        return payAmount;
    }

    public void setPayAmount(BigDecimal payAmount) {
        this.payAmount = payAmount;
    }

    public Integer getPurchaserId() {
        return purchaserId;
    }

    public void setPurchaserId(Integer purchaserId) {
        this.purchaserId = purchaserId;
    }

    public String getPurchaserName() {
        return purchaserName;
    }

    public void setPurchaserName(String purchaserName) {
        this.purchaserName = purchaserName;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public Integer getPaymentType() {
        return paymentType;
    }

    public void setPaymentType(Integer paymentType) {
        this.paymentType = paymentType;
    }

    public String getPaymentAccount() {
        return paymentAccount;
    }

    public void setPaymentAccount(String paymentAccount) {
        this.paymentAccount = paymentAccount;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getSource() {
        return source;
    }

    public void setSource(Integer source) {
        this.source = source;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Date getPaymentTime() {
        return paymentTime;
    }

    public void setPaymentTime(Date paymentTime) {
        this.paymentTime = paymentTime;
    }

    public Date getCloseTime() {
        return closeTime;
    }

    public void setCloseTime(Date closeTime) {
        this.closeTime = closeTime;
    }

    public Integer getIsdelete() {
        return isdelete;
    }

    public void setIsdelete(Integer isdelete) {
        this.isdelete = isdelete;
    }

    @Override
    protected Serializable pkVal() {
        return this.orderId;
    }

    @Override
    public String toString() {
        return "Order{" +
                "orderId=" + orderId +
                ", orderNo='" + orderNo + '\'' +
                ", productId=" + productId +
                ", orderTransNo='" + orderTransNo + '\'' +
                ", recordId=" + recordId +
                ", isPurchaseReport=" + isPurchaseReport +
                ", orderType=" + orderType +
                ", orderName='" + orderName + '\'' +
                ", orderAmount=" + orderAmount +
                ", saleAmount=" + saleAmount +
                ", payAmount=" + payAmount +
                ", purchaserId=" + purchaserId +
                ", purchaserName='" + purchaserName + '\'' +
                ", telephone='" + telephone + '\'' +
                ", paymentType=" + paymentType +
                ", paymentAccount='" + paymentAccount + '\'' +
                ", status=" + status +
                ", source=" + source +
                ", createTime=" + createTime +
                ", updateTime=" + updateTime +
                ", paymentTime=" + paymentTime +
                ", closeTime=" + closeTime +
                ", isdelete=" + isdelete +
                '}';
    }
}
