package com.ruida.mockservice.service;

import com.baomidou.mybatisplus.service.IService;
import com.ruida.mockdao.model.RecommendAppFrontpage;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author jinhu
 * @since 2020-08-07
 */
public interface RecommendAppFrontpageService extends IService<RecommendAppFrontpage> {

}
