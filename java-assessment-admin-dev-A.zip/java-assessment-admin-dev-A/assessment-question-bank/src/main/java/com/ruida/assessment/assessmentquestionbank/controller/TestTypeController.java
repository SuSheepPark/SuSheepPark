package com.ruida.assessment.assessmentquestionbank.controller;

import com.ruida.assessment.assessmentcommon.result.ListResult;
import com.ruida.assessment.assessmentquestionbank.service.TestTypeService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * @description:
 * @author: kgz
 * @date: 2020/7/6
 */
@RequestMapping("/testType")
@RestController
@Api(value ="考试类型接口")
public class TestTypeController {
    @Resource
    private TestTypeService testTypeService;

    @GetMapping("/getList")
    @ApiOperation(value = "获取考试类型下拉框列表", notes = "获取考试类型下拉框列表")
    public ListResult getList(){
        ListResult listResult = new ListResult();
        listResult.setContent(testTypeService.getList());
        return listResult;
    }

    @GetMapping("/getListByPeriod")
    @ApiOperation(value = "根据学段获取考试类型下拉框列表", notes = "获取考试类型下拉框列表")
    public ListResult getListByPeriod(Integer periodId){
        ListResult listResult = new ListResult();
        listResult.setContent(testTypeService.getListById(periodId));
        return listResult;
    }
}
