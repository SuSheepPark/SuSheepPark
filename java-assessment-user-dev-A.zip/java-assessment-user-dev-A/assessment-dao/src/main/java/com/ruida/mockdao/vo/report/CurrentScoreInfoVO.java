package com.ruida.mockdao.vo.report;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.List;

/**
 * @description: 本次测试成绩VO
 * @author: kgz
 * @date: 2020/12/18
 */
@ApiModel(description = "本次测试成绩VO")
public class CurrentScoreInfoVO {

    @ApiModelProperty(value = "语数英三科成绩", name = "threeSubjectScoreInfo")
    private SubjectScoreInfoVO threeSubjectScoreInfo;

    @ApiModelProperty(value = "所有学科成绩", name = "allSubjectScoreInfo")
    private SubjectScoreInfoVO allSubjectScoreInfo;

    @ApiModelProperty(value = "各学科成绩", name = "eachSubjectScoreInfo")
    private List<SubjectScoreInfoVO> eachSubjectScoreInfo;

    public SubjectScoreInfoVO getThreeSubjectScoreInfo() {
        return threeSubjectScoreInfo;
    }

    public void setThreeSubjectScoreInfo(SubjectScoreInfoVO threeSubjectScoreInfo) {
        this.threeSubjectScoreInfo = threeSubjectScoreInfo;
    }

    public SubjectScoreInfoVO getAllSubjectScoreInfo() {
        return allSubjectScoreInfo;
    }

    public void setAllSubjectScoreInfo(SubjectScoreInfoVO allSubjectScoreInfo) {
        this.allSubjectScoreInfo = allSubjectScoreInfo;
    }

    public List<SubjectScoreInfoVO> getEachSubjectScoreInfo() {
        return eachSubjectScoreInfo;
    }

    public void setEachSubjectScoreInfo(List<SubjectScoreInfoVO> eachSubjectScoreInfo) {
        this.eachSubjectScoreInfo = eachSubjectScoreInfo;
    }
}
