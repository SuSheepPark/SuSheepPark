package com.ruida.mockdao.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.model.ErrorPracticeRecord;
import com.ruida.mockdao.vo.error.PracticeRecordVO;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * 错题练习记录表 Mapper 接口
 * </p>
 *
 * @author chenjy
 * @since 2020-10-19
 */
public interface ErrorPracticeRecordMapper extends BaseMapper<ErrorPracticeRecord> {

    Integer queryPeriodId(@Param("stageId") Integer stageId);

    List<PracticeRecordVO> queryPracticeRecord(Map map);

    Integer queryRecordCount(Map map);
}
