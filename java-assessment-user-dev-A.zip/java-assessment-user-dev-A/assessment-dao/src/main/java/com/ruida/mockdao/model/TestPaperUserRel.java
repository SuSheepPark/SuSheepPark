package com.ruida.mockdao.model;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableLogic;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;
import lombok.Data;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * <p>
 * 用户考试关联表
 * </p>
 *
 * @author jinhu
 * @since 2020-07-17
 */
@Data
@Accessors(chain = true)
@TableName("t_test_paper_user_rel")
public class TestPaperUserRel implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 自增主键
     */
    @TableId(value = "rel_id", type = IdType.AUTO)
    private Integer relId;
    /**
     * 用户id
     */
    @TableField("user_id")
    private Integer userId;

    /**
     * 考生id
     */
    @TableField("stu_id")
    private Integer stuId;
    /**
     * 试卷id
     */
    @TableField("test_paper_id")
    private Integer testPaperId;

    /**
     * 商品id
     */
    @TableField("product_id")
    private Integer productId;

    /**
     * 是否购买了报告
     */
    @TableField("buy_report")
    private Integer buyReport;

    /**
     * 完成次数
     */
    @TableField("complete_num")
    private Integer completeNum;

    /**
     * 最近练习的完成状态 0-交卷 1-未交卷
     */
    @TableField("complete_status")
    private Integer completeStatus;
    /**
     * 完成比例
     */
    private BigDecimal rate;
    /**
     * 创建人
     */
    @TableField("create_by")
    private Integer createBy;
    /**
     * 创建时间
     */
    @TableField("create_time")
    private Date createTime;
    /**
     * 更新者
     */
    @TableField("update_by")
    private Integer updateBy;
    /**
     * 更新时间
     */
    @TableField("update_time")
    private Date updateTime;
    /**
     * 删除符号 0-未删除 1-删除
     */
    @TableLogic
    private Integer isdelete;


}
