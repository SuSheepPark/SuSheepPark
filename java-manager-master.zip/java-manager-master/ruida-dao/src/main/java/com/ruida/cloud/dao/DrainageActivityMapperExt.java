package com.ruida.cloud.dao;

import com.ruida.cloud.model.DrainageActivityVO;
import com.ruida.cloud.model.PromotionActSta;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Update;

import java.util.List;
import java.util.Map;

/**
 * @author taosh
 * @create 2020-04-29 14:55
 */
public interface DrainageActivityMapperExt {

    @Update("update t_drainage_activity set status=#{status} where drainage_activity_id=#{id}")
    Integer updateStatus(@Param("status") Integer status, @Param("id") Integer id);

    String listDrainageCourseIds(Integer activityId);

    String listDrainageDistributorIds(Integer activityId);

    List<Map<String, Object>>  listSecondaryDistributorIds(Integer activityId);

    /**
     * 查询推广活动分销商信息
     * @param id
     * @return
     */
    List<Map<String,Object>> selectDistributorByCondition(@Param("id") int id);

    List<Map<String,Object>> selectAllDistributor();

    /**
     * 查询推广活动关联课程信息
     * @param id 活动id
     * @return
     */
    List<Map<String,Object>> selectDrainageCourseRel(int id);

    /**
     * 营销活动列表
     * @return
     */
    List<DrainageActivityVO> listDrainageActivityByPage(Map param);

    /**
     * 营销互动列表总数
     * @param paramMap
     * @return
     */
    Integer countDrainageActivityByPage(Map paramMap);

    /**
     * 根据活动id获取人数
     */

}
