package com.ruida.mockservice.service.impl;

import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.ruida.mockcommon.exception.CoreException;
import com.ruida.mockdao.dao.ErrorPracticeDetailMapper;
import com.ruida.mockdao.dao.ErrorPracticeRecordMapper;
import com.ruida.mockdao.model.ErrorPracticeDetail;
import com.ruida.mockdao.model.ErrorPracticeRecord;
import com.ruida.mockdao.vo.error.QuestionTypeVO;
import com.ruida.mockservice.service.ErrorPracticeDetailService;
import com.ruida.mockservice.service.TestPaperService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * 错题练习记录明细表 服务实现类
 * </p>
 *
 * @author chenjy
 * @since 2020-10-20
 */
@Service
public class ErrorPracticeDetailServiceImpl extends ServiceImpl<ErrorPracticeDetailMapper, ErrorPracticeDetail> implements ErrorPracticeDetailService {

    @Resource
    private ErrorPracticeDetailMapper errorPracticeDetailMapper;
    @Resource
    private TestPaperService testPaperService;
    @Resource
    private ErrorPracticeRecordMapper errorPracticeRecordMapper;

    @Override
    public Map<String,Object> analysis(Integer recordId) {
        Map<String,Object> map = new HashMap<>();
        ErrorPracticeRecord record = errorPracticeRecordMapper.selectById(recordId);
        if(record == null){
            throw new CoreException("500","练习记录id有误");
        }
        List<QuestionTypeVO> questionTypeList = errorPracticeDetailMapper.analysis(recordId);
        questionTypeList.forEach(x->x.getQuestionList().forEach(y->testPaperService.handleQuestionVO(y)));
        map.put("questionTypeList",questionTypeList);
        map.put("duration",record.getDuration());
        return map;
    }

    @Override
    public List<QuestionTypeVO> getAnswerSheet(Integer recordId) {
        return errorPracticeDetailMapper.getAnswerSheet(recordId);
    }
}
