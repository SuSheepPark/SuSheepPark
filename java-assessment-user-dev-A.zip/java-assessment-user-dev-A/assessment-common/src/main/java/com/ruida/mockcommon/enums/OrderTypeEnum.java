package com.ruida.mockcommon.enums;


import java.util.*;

public enum OrderTypeEnum {
    TEST_PAPER(0, "试卷"),
    WISH_FILLING_REPORT(8, "志愿填报");

    private Integer k;
    private String v;

    OrderTypeEnum(Integer k, String v) {
        this.k = k;
        this.v = v;
    }


    public static Map<Integer, String> map = new LinkedHashMap<>(8);

    static {
        for (OrderTypeEnum type : OrderTypeEnum.values()) {
            map.put(type.getK(), type.getV());
        }
    }

    public Integer getK() {
        return k;
    }

    public void setK(Integer k) {
        this.k = k;
    }

    public String getV() {
        return v;
    }

    public void setV(String v) {
        this.v = v;
    }

    public static OrderTypeEnum getValueById(Integer K){
        //旧的报告类型
        List<Integer> oldType = Arrays.asList(1,2,3,4,5,6,7);
        for(OrderTypeEnum orderTypeEnum : OrderTypeEnum.values() ){
            if(orderTypeEnum.getK().equals(K)){
                return  orderTypeEnum;
            }else if(oldType.contains(K)){
                return OrderTypeEnum.TEST_PAPER;
            }
        }
        return null;
    }
}
