package com.ruida.mockcommon.result;

import com.ruida.mockcommon.enums.AppErrorEnum;

import java.io.Serializable;


public class BaseResult implements Serializable {

	private static final long serialVersionUID = 7220877209535559537L;

	private static final String SUCCESS_CODE = "0";

//	private static final String SUCCESS_MSG = "success";

	private Boolean success;

	/** 错误码 */
	private String statusCode;

	/** 子错误码(业务错误码) */
//	private String subErrCode;

	/** 错误信息 */
	private String errorMsg;

	/** 附加信息 */
	private String msg;

	/**供开发人员排错使用*/
	private Object devMsg;

//	private String errorLevel;

	/** 扩展错误信息 */
//	private Map<String, String> errorExtInfo;//错误栈暂不考虑输出

	public BaseResult() {
		setStatusCode(SUCCESS_CODE);
		//setErrorMsg(SUCCESS_MSG);
//		setSubErrCode(SUCCESS_CODE);
		this.success = true;
	}

	public BaseResult(AppErrorEnum errorEnum){
		this.success = false;
		this.errorMsg = errorEnum.getErrorMessage();
		this.statusCode = errorEnum.getErrorCode();
	}

	@SuppressWarnings("unchecked")
	public <R extends BaseResult> R setErrorMessage(String code, String message) {
		setStatusCode(code);
		setErrorMsg(message);
		this.success = false;
		return (R) this;
	}

	public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}

	/*
	 * public Map<String, String> getErrorExtInfo() { return errorExtInfo; }
	 *
	 * public void setErrorExtInfo(Map<String, String> errorExtInfo) {
	 * this.errorExtInfo = errorExtInfo; }
	 */



	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public Object getDevMsg() {
		return devMsg;
	}

	public void setDevMsg(Object devMsg) {
		this.devMsg = devMsg;
	}

	/*
	 * public String getErrorLevel() { return errorLevel; }
	 *
	 * public void setErrorLevel(String errorLevel) { this.errorLevel = errorLevel;
	 * }
	 *
	 * public String getSubErrCode() { return subErrCode; }
	 *
	 * public void setSubErrCode(String subErrCode) { this.subErrCode = subErrCode;
	 * }
	 */

	@Override
	public String toString() {
		return "BaseResult{" +
				"success=" + success +
				", statusCode='" + statusCode + '\'' +
				", errorMsg='" + errorMsg + '\'' +
				", msg='" + msg + '\'' +
				'}';
	}
}
