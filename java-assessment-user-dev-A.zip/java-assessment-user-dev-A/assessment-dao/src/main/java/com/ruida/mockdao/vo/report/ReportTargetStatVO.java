package com.ruida.mockdao.vo.report;


import com.ruida.mockdao.vo.TargetStatVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.List;


@Data
@ApiModel(value="目标分值统计")
public class ReportTargetStatVO implements Serializable {

    @ApiModelProperty(value = "用户")
    private List<TargetStatVO> userTargetStat;

    @ApiModelProperty(value = "班级")
    private List<TargetStatVO> classTargetStat;

    @ApiModelProperty(value = "学校")
    private List<TargetStatVO> schoolTargetStat;

    @ApiModelProperty(value = "9+1学校")
    private List<TargetStatVO> nineOneSchoolTargetStat;

    @ApiModelProperty(value = "联考学校")
    private List<TargetStatVO> unionTargetStat;
}
