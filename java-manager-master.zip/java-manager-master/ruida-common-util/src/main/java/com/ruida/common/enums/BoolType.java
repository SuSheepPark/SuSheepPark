package com.ruida.common.enums;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Created by gongbin on 2018/3/1.
 */
public enum BoolType {

    yes("1","是"),no("0","否");

    public static final String SOURCE_KEY = "Bool";
    private String k;
    private String v;

    BoolType(String k, String v) {
        this.k = k;
        this.v = v;
    }

    public static Map<String,String> map = new LinkedHashMap<>(2);
    static
    {
        for(BoolType type : BoolType.values())
        {
            map.put(type.getK(),type.getV());
        }
    }

    public String getK() {
        return k;
    }

    public void setK(String k) {
        this.k = k;
    }

    public String getV() {
        return v;
    }

    public void setV(String v) {
        this.v = v;
    }
}
