package com.ruida.assessment.assessmentcommon.enums;

/**
 * 升学选拔报告生成记录状态
 *
 * @author xumingqi
 * @date 2020/12/15 15:25
 */
public enum UpgradeReportRecordStatusEnum {
    NOT_FINISH(0, "未完成"),
    FINISH(1, "已完成");

    private Integer K;
    private String V;

    UpgradeReportRecordStatusEnum(Integer k, String v) {
        K = k;
        V = v;
    }

    public Integer getK() {
        return K;
    }

    public void setK(Integer k) {
        K = k;
    }

    public String getV() {
        return V;
    }

    public void setV(String v) {
        V = v;
    }
}
