package com.ruida.assessment.assessmentcommon.result;

import java.util.List;

/**
 * @description:
 * @author szl
 * @Date 2018年12月10日
 * @verion 1.0
 */
public class ListResult<T> extends BaseResult {

	private static final long serialVersionUID = -1629682760241859545L;

	private List<T> content;

	private Integer totalCount;

	public ListResult() {
	}

	public ListResult(List<T> content) {
		this.content = content;
		if (content != null) {
			this.totalCount = content.size();
		}
	}

	public Integer getTotalCount() {
		return this.totalCount;
	}

	public void setTotalCount(Integer totalCount) {
		this.totalCount = totalCount;
	}

	public List<T> getContent() {
		return this.content;
	}

	public void setContent(List<T> content) {
		this.content = content;
	}
}