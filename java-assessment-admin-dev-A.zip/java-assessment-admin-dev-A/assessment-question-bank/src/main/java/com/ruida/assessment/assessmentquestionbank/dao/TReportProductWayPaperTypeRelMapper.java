package com.ruida.assessment.assessmentquestionbank.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.assessment.assessmentquestionbank.model.TReportProductWayPaperTypeRel;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface TReportProductWayPaperTypeRelMapper  extends BaseMapper<TReportProductWayPaperTypeRel> {
}
