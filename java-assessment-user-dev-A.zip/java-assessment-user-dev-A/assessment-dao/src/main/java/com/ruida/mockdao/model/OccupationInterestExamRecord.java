package com.ruida.mockdao.model;

import java.io.Serializable;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.Period;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;

/**
 * <p>
 * 霍兰德职业兴趣答题卡以及报告
 * </p>
 *
 * @author
 * @since 2021-02-05
 */
@TableName("t_occupation_interest_exam_record")
public class OccupationInterestExamRecord implements Serializable {

	private static final long serialVersionUID = 1L;

	@TableId(value = "record_id", type = IdType.AUTO)
	private Integer recordId;
	private Boolean checkBuyQuestion;
	private String answer;
	private Boolean checkBuyReport;
	private String report;
	/**
	 * 状态
	 */
	private Integer status;
	/**
	 * 创建人
	 */
	private Integer createBy;
	/**
	 * 创建时间
	 */
	private Date createTime;
	/**
	 * 修改人
	 */
	private Integer updateBy;
	/**
	 * 修改时间
	 */
	private Date updateTime;
	/**
	 * 删除标志（0：未删除；1：已删除）
	 */
	private Integer isdelete;
	
	private String group;

	public Integer getRecordId() {
		return recordId;
	}

	public void setRecordId(Integer recordId) {
		this.recordId = recordId;
	}

	public String getReport() {
		return report;
	}

	public void setReport(String report) {
		this.report = report;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Integer getCreateBy() {
		return createBy;
	}

	public void setCreateBy(Integer createBy) {
		this.createBy = createBy;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Integer getUpdateBy() {
		return updateBy;
	}

	public void setUpdateBy(Integer updateBy) {
		this.updateBy = updateBy;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public Integer getIsdelete() {
		return isdelete;
	}

	public void setIsdelete(Integer isdelete) {
		this.isdelete = isdelete;
	}

	@Override
	public String toString() {
		return "TOccupationInterestExamRecord{" + ", recordId=" + recordId + ", checkBuyQuestion=" + checkBuyQuestion
				+ ", answer=" + answer + ", checkBuyReport=" + checkBuyReport + ", report=" + report + ", status="
				+ status + ", createBy=" + createBy + ", createTime=" + createTime + ", updateBy=" + updateBy
				+ ", updateTime=" + updateTime + ", isdelete=" + isdelete + "}";
	}

	public Boolean getCheckBuyQuestion() {
		return checkBuyQuestion;
	}

	public void setCheckBuyQuestion(Boolean checkBuyQuestion) {
		this.checkBuyQuestion = checkBuyQuestion;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(Object answer) {
		if (answer instanceof String) {
			this.answer = answer.toString();
		} else {
			this.answer = JSON.toJSONString(answer);
		}
	}

	public Boolean getCheckBuyReport() {
		return checkBuyReport;
	}

	public void setCheckBuyReport(Boolean checkBuyReport) {
		this.checkBuyReport = checkBuyReport;
	}

	public String getCreateTimeFormat() {
		Instant nowInstant = new Date().toInstant();
		Instant updateTimeInstant = updateTime.toInstant();
		Duration duration = Duration.between(updateTimeInstant, nowInstant);
		long days = duration.toDays();
		if (days < 1) {
			long minutes = duration.toMinutes();
			if (minutes < 5) {
				return "刚刚";
			} else {
				long hours = duration.toHours();
				if (hours < 1) {
					return minutes + "分钟前";
				} else {
					return hours + "小时前";
				}
			}
		} else if (days < 7) {
			return days + "天前";
		} else {
			LocalDateTime updateDateTime = LocalDateTime.ofInstant(updateTimeInstant, ZoneId.systemDefault());
			if (days < 365) {
				return DateTimeFormatter.ofPattern("MM-dd hh:mm").format(updateDateTime);
			} else {
				return DateTimeFormatter.ofPattern("yyyy-MM-dd hh:mm").format(updateDateTime);
			}
		}

	}

	public String getGroup() {
		return group;
	}

	public void setGroup(String group) {
		this.group = group;
	}
	
	public String getReportName() {
		return "职业兴趣测试报告";
	}
}
