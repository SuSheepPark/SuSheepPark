package com.ruida.assessment.assessmentquestionbank.service;

import java.util.List;

import com.baomidou.mybatisplus.service.IService;
import com.ruida.assessment.assessmentquestionbank.model.TMaterialVersion;

/**
 * @description:
 * @author: kgz
 * @date: 2020/6/29
 */
public interface MaterialVersionService extends QuestionBaseService,IService<TMaterialVersion> {
    /**
     * 根据学科学段获取教材版本
     * @param periodId
     * @param subjectId
     * @return
     */
   List getListByPeriodSubjectId(Integer periodId, Integer subjectId);
}
