
package com.ruida.assessment.assessmentcommon.filter;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @description: 跨域过滤器
 * @author: kgz
 * @date: 2020/6/29
 */
@Component
@WebFilter(filterName="CorssFilter",urlPatterns="/*")
public class CorssFilter implements Filter {

    /**
     * 是否开启支持跨域访问
     */
    @Value("${crossOrigin}")
    private String crossOrigin;

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        if(Boolean.valueOf(crossOrigin)){
            //配置全局跨域
            HttpServletRequest re= (HttpServletRequest) servletRequest;
            HttpServletResponse res= (HttpServletResponse) servletResponse;
            //允许的域
            res.setHeader("Access-Control-Allow-Origin", "*");
            //允许浏览器携带cookie
            res.setHeader("Access-Control-Allow-Credentials","true");
            //response.setHeader("Access-Control-Allow-Headers", "token");
            res.setHeader("Access-Control-Allow-Methods", "*");
            res.setHeader("Access-Control-Allow-Headers", "*");
            res.setHeader("Access-Control-Expose-Headers", "*");
            String method = re.getMethod();
            if("OPTIONS".equals(method)){
                res.setStatus(HttpServletResponse.SC_OK);
            }else{
                filterChain.doFilter(re,res);
            }
        }
    }
}


