package com.ruida.assessment.assessmentcommon.auth;

public interface JwtConstants {
    String AUTH_HEADER = "Authorization";
    String SECRET = "defaultSecret";
    Long EXPIRATION = 604800L;
    String AUTH_PATH = "/student/login";

    String AUTH_RELEASE_PATH [] ={ "/auth/student/getUserRecommendStage","/course/listHotCourse"
            ,"/course/listCourse","/course/getCourseInfo"};
    String DEFAULT_TOKEN = "default";

}
