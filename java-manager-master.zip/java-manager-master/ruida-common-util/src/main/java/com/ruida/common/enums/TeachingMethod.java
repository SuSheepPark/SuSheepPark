package com.ruida.common.enums;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Created by tc on 2019/11/11
 */
public enum TeachingMethod {

    BOTHLINE(0,"双师直播"),RECORD(1,"录播"),UNDERLINE(2,"线下双师"),ONLINE(3,"线上直播"),PUREUNDERLINE(4,"纯线下课");

    public static final String SOURCE_KEY = "TeachingMethod";
    private int k;
    private String v;

    TeachingMethod(int k, String v) {
        this.k = k;
        this.v = v;
    }

    public static Map<Integer,String> map = new LinkedHashMap<>(2);
    static
    {
        for(TeachingMethod type : TeachingMethod.values())
        {
            map.put(type.getK(),type.getV());
        }
    }

    public int getK() {
        return k;
    }

    public void setK(int k) {
        this.k = k;
    }

    public String getV() {
        return v;
    }

    public void setV(String v) {
        this.v = v;
    }

    /***
     * 根据k获取v的值
     * @param k
     * @return
     */
    public static String getvByk(int k) {
        TeachingMethod[] list = TeachingMethod.values();
        for (TeachingMethod valid : list) {
            if (valid.getK() == k ) {
                return valid.getV();
            }
        }
        return "";
    }
}
