package com.ruida.assessment.assessmentquestionbank.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
@ApiModel(description = "试卷试题引用")
@Data
public class TestPaperQuestionRelDTO implements Serializable {
    @ApiModelProperty(value = "试卷id", name = "testPaperId", required = true)
    private Integer testPaperId;
    @ApiModelProperty(value = "试题id", name = "questionId",required = true)
    private String questionId;
    @ApiModelProperty(value = "退回原因", name = "rejectReson",required = true)
    private String rejectReson;

}
