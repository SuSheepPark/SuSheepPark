package com.ruida.assessment.assessmentquestionbank.controller;

import com.ruida.assessment.assessmentcommon.result.PojoResult;
import com.ruida.assessment.assessmentquestionbank.annotaion.UserAuth;
import com.ruida.assessment.assessmentquestionbank.dto.OrderQueryDTO;
import com.ruida.assessment.assessmentquestionbank.dto.ReportDTO;
import com.ruida.assessment.assessmentquestionbank.service.ReportStudentService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

/**
 * @description: 学生个人报告计算控制层（测试用）
 * @author: kgz
 * @date: 2021/5/17
 */
@RequestMapping("/reportStudent/")
@RestController
@Api(value ="用户消息相关接口")
public class ReportStudentController {
    @Resource
    private ReportStudentService reportStudentService;

    @UserAuth
    @PostMapping("taskStart")
    @ApiOperation(value = "学生个人报告计算任务启动", notes = "学生个人报告计算任务启动")
    @ApiImplicitParam(name = "reportDTO", value = "查询条件",
            required = true , dataType  = "ReportDTO",paramType = "body")
    public PojoResult taskStart(@RequestBody ReportDTO reportDTO, HttpServletRequest request){
        PojoResult pojoResult = new PojoResult();
        pojoResult.setContent(reportStudentService.reportStudentTask(reportDTO.getProductId(), reportDTO.getTestPaperId(), request));
        return pojoResult;
    }

    @UserAuth
    @PostMapping("sendMessage")
    @ApiOperation(value = "发送学生个人报告启动计算消息", notes = "发送学生个人报告启动计算消息")
    @ApiImplicitParam(name = "reportDTO", value = "查询条件",
            required = true , dataType  = "ReportDTO",paramType = "body")
    public PojoResult sendMessage(@RequestBody ReportDTO reportDTO, HttpServletRequest request){
        PojoResult pojoResult = new PojoResult();
        pojoResult.setContent(reportStudentService.sendReportTaskMessage(reportDTO.getProductId(), reportDTO.getTestPaperId(), request));
        return pojoResult;
    }

    @UserAuth
    @PostMapping("putUserToRedis")
    @ApiOperation(value = "将参加考试的学生id存入redis", notes = "将参加考试的学生id存入redis")
    @ApiImplicitParam(name = "reportDTO", value = "查询条件",
            required = true , dataType  = "ReportDTO",paramType = "body")
    public PojoResult putUserToRedis(@RequestBody ReportDTO reportDTO){
        PojoResult pojoResult = new PojoResult();
        pojoResult.setContent(reportStudentService.putStudentUserIdListToRedis(reportDTO.getProductId(), reportDTO.getTestPaperId()));
        return pojoResult;
    }
}
