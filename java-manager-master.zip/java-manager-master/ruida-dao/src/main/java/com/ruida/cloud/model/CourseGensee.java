package com.ruida.cloud.model;

import java.io.Serializable;
import java.util.Date;

public class CourseGensee implements Serializable {
    private Integer courseGenseeId;

    private String roomId;

    private String number;

    private String assistanttoken;

    private String studenttoken;

    private String teachertoken;

    private String studentclienttoken;

    private Date startdate;

    private Byte webjoin;

    private Byte clientjoin;

    private Date invaliddate;

    private String teacherjoinurl;

    private String studentjoinurl;

    private Byte scene;

    private String code;

    private String message;

    private static final long serialVersionUID = 1L;

    public Integer getCourseGenseeId() {
        return courseGenseeId;
    }

    public void setCourseGenseeId(Integer courseGenseeId) {
        this.courseGenseeId = courseGenseeId;
    }

    public String getRoomId() {
        return roomId;
    }

    public void setRoomId(String roomId) {
        this.roomId = roomId == null ? null : roomId.trim();
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number == null ? null : number.trim();
    }

    public String getAssistanttoken() {
        return assistanttoken;
    }

    public void setAssistanttoken(String assistanttoken) {
        this.assistanttoken = assistanttoken == null ? null : assistanttoken.trim();
    }

    public String getStudenttoken() {
        return studenttoken;
    }

    public void setStudenttoken(String studenttoken) {
        this.studenttoken = studenttoken == null ? null : studenttoken.trim();
    }

    public String getTeachertoken() {
        return teachertoken;
    }

    public void setTeachertoken(String teachertoken) {
        this.teachertoken = teachertoken == null ? null : teachertoken.trim();
    }

    public String getStudentclienttoken() {
        return studentclienttoken;
    }

    public void setStudentclienttoken(String studentclienttoken) {
        this.studentclienttoken = studentclienttoken == null ? null : studentclienttoken.trim();
    }

    public Date getStartdate() {
        return startdate;
    }

    public void setStartdate(Date startdate) {
        this.startdate = startdate;
    }

    public Byte getWebjoin() {
        return webjoin;
    }

    public void setWebjoin(Byte webjoin) {
        this.webjoin = webjoin;
    }

    public Byte getClientjoin() {
        return clientjoin;
    }

    public void setClientjoin(Byte clientjoin) {
        this.clientjoin = clientjoin;
    }

    public Date getInvaliddate() {
        return invaliddate;
    }

    public void setInvaliddate(Date invaliddate) {
        this.invaliddate = invaliddate;
    }

    public String getTeacherjoinurl() {
        return teacherjoinurl;
    }

    public void setTeacherjoinurl(String teacherjoinurl) {
        this.teacherjoinurl = teacherjoinurl == null ? null : teacherjoinurl.trim();
    }

    public String getStudentjoinurl() {
        return studentjoinurl;
    }

    public void setStudentjoinurl(String studentjoinurl) {
        this.studentjoinurl = studentjoinurl == null ? null : studentjoinurl.trim();
    }

    public Byte getScene() {
        return scene;
    }

    public void setScene(Byte scene) {
        this.scene = scene;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code == null ? null : code.trim();
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message == null ? null : message.trim();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", courseGenseeId=").append(courseGenseeId);
        sb.append(", roomId=").append(roomId);
        sb.append(", number=").append(number);
        sb.append(", assistanttoken=").append(assistanttoken);
        sb.append(", studenttoken=").append(studenttoken);
        sb.append(", teachertoken=").append(teachertoken);
        sb.append(", studentclienttoken=").append(studentclienttoken);
        sb.append(", startdate=").append(startdate);
        sb.append(", webjoin=").append(webjoin);
        sb.append(", clientjoin=").append(clientjoin);
        sb.append(", invaliddate=").append(invaliddate);
        sb.append(", teacherjoinurl=").append(teacherjoinurl);
        sb.append(", studentjoinurl=").append(studentjoinurl);
        sb.append(", scene=").append(scene);
        sb.append(", code=").append(code);
        sb.append(", message=").append(message);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}