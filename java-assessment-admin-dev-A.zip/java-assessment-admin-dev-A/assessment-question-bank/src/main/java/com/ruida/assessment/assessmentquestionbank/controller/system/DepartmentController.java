package com.ruida.assessment.assessmentquestionbank.controller.system;

import com.ruida.assessment.assessmentcommon.enums.OperateModuleEnum;
import com.ruida.assessment.assessmentcommon.enums.OperateTypeEnum;
import com.ruida.assessment.assessmentcommon.result.BoolAlertResult;
import com.ruida.assessment.assessmentcommon.result.MapResult;
import com.ruida.assessment.assessmentcommon.result.PojoResult;
import com.ruida.assessment.assessmentcommon.util.RegexUtils;
import com.ruida.assessment.assessmentcommon.util.ValidateMT;
import com.ruida.assessment.assessmentquestionbank.annotaion.OperateLog;
import com.ruida.assessment.assessmentquestionbank.annotaion.UserAuth;
import com.ruida.assessment.assessmentquestionbank.imports.util.StringUtil;
import com.ruida.assessment.assessmentquestionbank.model.TDepartment;
import com.ruida.assessment.assessmentquestionbank.service.SysCryptoService;
import com.ruida.assessment.assessmentquestionbank.service.ruidaCloud.DepartmentService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author admin
 * @description: ${TODO}
 * @Date 2019/6/2
 * @verion 1.0
 */
@RestController
@RequestMapping("/sys")
public class DepartmentController {
    @Resource
    DepartmentService departmentService;
    @Resource
    private SysCryptoService sysCryptoService;

    /**
     * 分页获取部门列表
     *
     * @param pageNo
     * @param pageSize
     * @return
     */
    @RequestMapping("/getDepartmentList")
    @UserAuth
    public MapResult selectDepartmentByPage(Integer pageNo, Integer pageSize) {
        MapResult result = new MapResult();
        Map<String, Object> resultMap = new HashMap<>();

        if (ValidateMT.isNull(pageNo)){
            pageNo = 1;
        }
        if (ValidateMT.isNull(pageSize)){
            pageSize = 10;
        }
        resultMap.put("pageNo", pageNo);
        resultMap.put("pageSize", pageSize);

        List<TDepartment> list = new ArrayList<>();//返回数组
        TDepartment passDep = departmentService.isPass();//是否是管理员
        if (ValidateMT.isNull(passDep)){
            list = departmentService.selectDepartmentByPage( (pageNo - 1) * pageSize, pageSize);
            Integer total = departmentService.countDepartment();
            resultMap.put("total", total);
        }else {
            list.add(passDep);
            resultMap.put("total", 1);
        }
        //手机号解密
        list.forEach(e ->{
            String telephone = e.getTelephone();
            if(!StringUtil.isEmpty(telephone)){
                telephone = (telephone.length() == 32) ? sysCryptoService.AESDncode(telephone) : telephone;
                e.setTelephone(telephone);
            }
        });
        resultMap.put("list", list);

         result.setContent(resultMap);
        return result;
    }

    /**
     * 添加部门
     *
     * @param department
     * @return
     */
    @RequestMapping("/addDepartment")
    @UserAuth
    @OperateLog(module = OperateModuleEnum.DEPARTMENT, operateType = OperateTypeEnum.ADD)
    public PojoResult addDepartment(TDepartment department) {
        PojoResult pojoResult = new PojoResult();
        department = departmentService.addAndEditDepartment(department);
        pojoResult.setContent(department);
        return pojoResult;
    }

    /**
     * 编辑部门
     *
     * @param department
     * @return
     */
    @RequestMapping("/editDepartment")
    @UserAuth
    @OperateLog(module = OperateModuleEnum.DEPARTMENT, operateType = OperateTypeEnum.EDIT)
    public PojoResult editDepartment(TDepartment department) {
        PojoResult pojoResult = new PojoResult();
        department = departmentService.addAndEditDepartment(department);
        pojoResult.setContent(department);
        return pojoResult;
    }

    /**
     * 删除部门
     *
     * @param departmentId
     * @return
     */
    @RequestMapping("deleteDpt")
    @UserAuth
    @OperateLog(module = OperateModuleEnum.DEPARTMENT, operateType = OperateTypeEnum.DELETE)
    public PojoResult deleteDepartment(Integer departmentId) {
        PojoResult pojoResult = new PojoResult();
        BoolAlertResult boolAlertResult = departmentService.deleteDepartment(departmentId);
        pojoResult.setContent(boolAlertResult.getMsg());
        return pojoResult;
    }

    /**
     * 禁用启用部门
     *
     * @param departmentId
     * @return
     */
    @RequestMapping("fobidAndStartDpt")
    @UserAuth
    @OperateLog(module = OperateModuleEnum.DEPARTMENT, operateType = OperateTypeEnum.STOP_START)
    public PojoResult forbidAndStartDepartment(Integer departmentId) {
        PojoResult pojoResult = new PojoResult();

        BoolAlertResult boolAlertResult = departmentService.fobidAndStartDepartment(departmentId);
        pojoResult.setContent(boolAlertResult.getMsg());
        return pojoResult;
    }
}
