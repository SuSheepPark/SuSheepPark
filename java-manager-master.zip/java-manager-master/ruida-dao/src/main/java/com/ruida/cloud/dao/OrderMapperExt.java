package com.ruida.cloud.dao;

import com.ruida.cloud.model.CourseNonPublicUser;
import com.ruida.cloud.model.Order;
import com.ruida.cloud.model.OrderExt;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

/**
 * @author admin
 * @description: ${TODO}
 * @Date 2019/1/21
 * @verion 1.0
 */
public interface OrderMapperExt extends OrderMapper{
    Map countByExampleSearch(Map condtion);
    List<OrderExt> selectByExampleSearch(Map condtion);
    OrderExt selectById(Map condtion);
    Double sumAmount(Map condtion);
    Integer orderCount(Map condtion);
    Map orderCountAndAmount(Map condtion);

    /**
     * 根据课程查询订单信息列表
     *
     * @param condtion
     * @return
     */
    List<OrderExt> selectOrderForCourse(Map condtion);

    @Select("SELECT\n" +
            "\n" +
            "\tCONCAT(\n" +
            "\t\tDATE_FORMAT(b.start_date, '%Y-%m-%d'),\n" +
            "\t\t' ',\n" +
            "\t\tb.start_time\n" +
            "\t) time\n" +
            "FROM\n" +
            "\tt_course_course_lesson_rel a\n" +
            "LEFT JOIN t_course_lesson b ON a.course_lesson_id = b.course_lesson_id\n" +
            "AND b.isdelete = 0\n" +
            "WHERE\n" +
            "\ta.course_id = #{courseId} \n" +
            "AND CONCAT(\n" +
            "\tCONCAT(\n" +
            "\t\tDATE_FORMAT(b.start_date, '%Y-%m-%d'),\n" +
            "\t\t' ',\n" +
            "\t\tb.start_time\n" +
            "\t)\n" +
            ") > DATE_FORMAT(NOW(), '%Y-%m-%d %H:%i')\n" +
            "GROUP BY\n" +
            "\tb.course_lesson_id\n" +
            "LIMIT 1;")
    String getStartTime(@Param("courseId") Integer courseId);

    //批量插入
    int insertOrderBatch(List<Order> list);

    int countOrderByCourseId(Integer courseId);

    /**
     * 查询推广活动订单详情
     * @param condition
     * @return
     */
    List<OrderExt> selectMarketOrderDetail(Map condition);

    int countMarketOrderDetail(Map condition);

    List<Map<String, Object>> selectByExampleForExcel(Map map);

    List<Map<String, Object>> selectFinanceOrderForPage(Map map);

    int countFinanceOrderForPage(Map map);

    List<Map<String, Object>> sumFinanceOrderList(Map map);

    /**
     * 查询某个订单之后的订单
     * @param param
     * @return
     */
    List findOderByOderId(Map<String, Object> param);

    List<Map<String, Object>> selectOrderByOrderId(Integer orderId);

    List<Map<String, Object>> listOrderByShopCartNo(String shopCartNo);

    int countRefundOrderByShopCartNo(Map condition);

    List<Map<String, Object>> countSecondryPreferencePrice(String shopCartNo);
}
