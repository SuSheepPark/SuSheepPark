package com.ruida.mockservice.service;

import com.baomidou.mybatisplus.service.IService;
import com.ruida.mockdao.model.ErrorPractice;

/**
 * <p>
 * 错题练习表 服务类
 * </p>
 *
 * @author chenjy
 * @since 2020-10-16
 */
public interface ErrorPracticeService extends IService<ErrorPractice> {

}
