package com.ruida.mockdao.pojo;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

/**
 * @description: 选择题实体类
 * @author: chenjy
 * @create: 2020-07-10 17:45
 */
@Data
@JsonInclude(value = JsonInclude.Include.NON_NULL)
public class Choice {

    private String key;

    private String val;

    private Integer status;
}
