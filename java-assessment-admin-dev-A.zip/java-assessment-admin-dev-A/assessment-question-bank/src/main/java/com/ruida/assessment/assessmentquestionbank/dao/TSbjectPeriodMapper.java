package com.ruida.assessment.assessmentquestionbank.dao;

import com.ruida.assessment.assessmentquestionbank.model.TUserPeriodSubject;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface TSbjectPeriodMapper {
    @Select("SELECT\n" +
            "b.period_name as periodName,\n" +
            "c.subject_name as subjectName,\n" +
            "a.period_id as periodId,\n" +
            "a.subject_id as subjectId\n" +
            "FROM\n" +
            "\tt_user_period_subject a\n" +
            "LEFT JOIN t_period b ON a.period_id = b.id\n" +
            "LEFT JOIN t_subject c ON a.subject_id = c.id\n" +
            "WHERE\n" +
            "\ta.isdelete = 0\n" +
            "AND a.user_id = #{userId}")
    List<TUserPeriodSubject>  getList(@Param("userId") Integer userId);

    /**
     * 获取所有学段学科
     * @return
     */
    @Select("\n" +
            " SELECT\n" +
            "        b.period_name as periodName,\n" +
            "        c.subject_name as subjectName,\n" +
            "        a.period_id as periodId,\n" +
            "        a.subject_id as subjectId\n" +
            "    FROM\n" +
            "        t_period_subject_relation a\n" +
            "            LEFT JOIN t_period b ON a.period_id = b.id\n" +
            "            LEFT JOIN t_subject c ON a.subject_id = c.id\n" +
            "    WHERE\n" +
            "        a.isdelete = 0")
    List<TUserPeriodSubject> getAllList();
}
