package com.ruida.assessment.assessmentquestionbank.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.assessment.assessmentquestionbank.model.TQuestionStatus;
import org.apache.ibatis.annotations.Mapper;

/**
 * @description:
 * @author: kgz
 * @date: 2020/6/30
 */
@Mapper
public interface QuestionStatusMapper extends BaseMapper<TQuestionStatus> {
}
