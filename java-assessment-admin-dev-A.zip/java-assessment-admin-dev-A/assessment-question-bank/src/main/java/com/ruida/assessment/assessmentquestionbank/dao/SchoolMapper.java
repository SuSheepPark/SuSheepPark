package com.ruida.assessment.assessmentquestionbank.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.assessment.assessmentquestionbank.dto.SchoolRequest;
import com.ruida.assessment.assessmentquestionbank.model.TSchool;
import com.ruida.assessment.assessmentquestionbank.vo.SchoolGradeClassInfo;
import com.ruida.assessment.assessmentquestionbank.vo.SchoolVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author wy
 * @description 学校管理Mapper
 * @date 2020/6/12
 */
@Mapper
public interface SchoolMapper extends BaseMapper<TSchool> {

    /*
        按条件查询学校列表（分页）
     */
    List<SchoolVo> querySchoolList(@Param("vo") SchoolRequest req);

    Integer querySchoolCount(@Param("vo") SchoolRequest req);

    /*
        查询所有 学校-年级-班级 列表
     */
    List<SchoolGradeClassInfo> queryAllSchoolGradeClassList();
}
