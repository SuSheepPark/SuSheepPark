package com.ruida.cloud.model;

import lombok.Data;

import java.util.List;
import java.util.Map;

/**
 * @author taosh
 * @create 2020-04-15 10:07
 */
@Data
public class PromotionActivityExt extends PromotionActivity {
    private Integer promotionActivityId;

    private String activityCourseIds;

    private String activityDistributorIds;

    /**
     * 一级分销商id
     */
    private String superDistributorIds;
    /**
     * 二级分销商id
     */
    private List<Map<String, Object>> secondaryDistributorIds;

    private List<PromotionActivityCommission> commissionList;

    /**
     * 活动和佣金关联关系(分组)
     */
    private Map<Integer,List<CommissionExt>> commissionMapList;

    /**
     * 活动和分销商关联关系
     */
    private List<Map<String,Object>> promotionActivityDistributorRelList;

    /**
     * 活动和课程关联关系
     */
    private List<Map<String,Object>> promotionActivityCourseRelList;
}
