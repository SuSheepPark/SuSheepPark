package com.ruida.common.enums;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Created by  on 2018/3/1.
 */
public enum CourseSegment {

    WAITING(1,"一期"), PAID(2,"二期"), CLOSED(3,"三期"),TBC(4,"四期"), ;

    public static final String SOURCE_KEY = "Bool";
    private Integer k;
    private String v;

    CourseSegment(Integer k, String v) {
        this.k = k;
        this.v = v;
    }

    public static Map<Integer,String> map = new LinkedHashMap<>(2);
    static
    {
        for(CourseSegment type : CourseSegment.values())
        {
            map.put(type.getK(),type.getV());
        }
    }

    public Integer getK() {
        return k;
    }

    public void setK(Integer k) {
        this.k = k;
    }

    public String getV() {
        return v;
    }

    public void setV(String v) {
        this.v = v;
    }

    /***
     * 根据k获取v的值
     * @param k
     * @return
     */
    public static String getvByk(int k) {
        CourseSegment[] list = CourseSegment.values();
        for (CourseSegment valid : list) {
            if (valid.getK() == k ) {
                return valid.getV();
            }
        }
        return "";
    }
}
