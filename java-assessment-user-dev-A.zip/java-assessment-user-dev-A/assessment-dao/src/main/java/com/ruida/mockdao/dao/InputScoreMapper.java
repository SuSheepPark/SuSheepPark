package com.ruida.mockdao.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.model.InputScore;

/**
 * <p>
 * 科目选考-手动输入成绩表 Mapper 接口
 * </p>
 *
 * @author chenjy
 * @since 2021-01-18
 */
public interface InputScoreMapper extends BaseMapper<InputScore> {

}
