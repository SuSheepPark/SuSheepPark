package com.ruida.mockservice.service;

import com.baomidou.mybatisplus.service.IService;
import com.ruida.mockdao.model.TInformationColumn;

/**
 * <p>
 * 首页资讯栏目表 服务类
 * </p>
 *
 * @author wy
 * @since 2021-08-16
 */
public interface TInformationColumnService extends IService<TInformationColumn> {

}
