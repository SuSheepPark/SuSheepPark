package com.ruida.assessment.assessmentquestionbank.model;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;

import java.io.Serializable;

/**
 * @description: 区域数据库实体
 * @author: kgz
 * @date: 2020/7/7
 */
@TableName("t_areainfo")
public class TArea implements Serializable {
    private static final long serialVersionUID = -3726841199012866716L;

    /**
     * 区域id
     */
    @TableId
    private Integer id;

    /**
     * 区域名称
     */
    private String name;

    /**
     * 层级标识： 1—省份， 2—市， 3—区县
     */
    private String areaLevel;

    /**
     * 父节点id
     */
    private String parentId;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAreaLevel() {
        return areaLevel;
    }

    public void setAreaLevel(String areaLevel) {
        this.areaLevel = areaLevel;
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }
}
