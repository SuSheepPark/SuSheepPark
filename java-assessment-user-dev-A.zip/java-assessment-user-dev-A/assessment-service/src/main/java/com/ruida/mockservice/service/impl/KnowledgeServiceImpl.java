package com.ruida.mockservice.service.impl;

import com.ruida.mockcommon.auth.context.BaseContextHandle;
import com.ruida.mockcommon.auth.pojo.JWTInfo;
import com.ruida.mockcommon.enums.AppErrorEnum;
import com.ruida.mockcommon.exception.CoreException;
import com.ruida.mockdao.dao.KnowledgeMapper;
import com.ruida.mockdao.vo.KnowledgeVO;
import com.ruida.mockservice.service.KnowledgeService;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

/**
 * @description: 知识点服务实现类
 * @author: chenjy
 * @create: 2020-07-24 09:19
 */
@Service
public class KnowledgeServiceImpl implements KnowledgeService {

    @Resource
    KnowledgeMapper knowledgeMapper;

    @Override
    public List<KnowledgeVO> queryBizKnowledge(Integer type) {
        List<KnowledgeVO> list = new ArrayList<>();
        JWTInfo jwt = BaseContextHandle.getJWTInfo();
        if(jwt == null){
            throw new CoreException(AppErrorEnum.E_10018);
        }
        String tableName = null;
        switch (type) {
            case 1:
                tableName = "t_error_book";
                break;
            case 2:
                tableName = "t_question_mark";
            default:
                break;
        }
        if(tableName != null){
            list = knowledgeMapper.queryBizKnowledge(tableName,Integer.valueOf(jwt.getUserId()));
        }
        return list;
    }
}
