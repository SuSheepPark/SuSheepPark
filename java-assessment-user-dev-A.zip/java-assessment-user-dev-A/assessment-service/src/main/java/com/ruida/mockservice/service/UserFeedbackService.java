package com.ruida.mockservice.service;

import com.baomidou.mybatisplus.service.IService;
import com.ruida.mockdao.model.UserFeedback;

/**
 * Created by xumingqi on 2021/5/26 9:02
 */
public interface UserFeedbackService extends IService<UserFeedback> {
    Boolean addUserFeedback(Integer reportId, Integer userId, Integer star, String content, Integer source);
}
