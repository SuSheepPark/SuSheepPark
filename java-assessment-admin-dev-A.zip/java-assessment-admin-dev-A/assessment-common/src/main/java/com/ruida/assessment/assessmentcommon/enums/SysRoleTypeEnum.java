package com.ruida.assessment.assessmentcommon.enums;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * @author admin
 * @description: ${TODO}
 * @Date 2019/6/3
 * @verion 1.0
 */
public enum SysRoleTypeEnum {
    // 角色类型：(0—超级管理员；1—部门管理员；2—教师；3—学生；4—游客；5-其他）
    ADMIN(0, "超级管理员"), NORMAL_ADMIN(1, "部门管理员"), TEACHER(2, "教师"),
    STUDENT(3, "学生"), VISITOR(4, "游客"), OTHER(5, "其他");
    private Integer k;
    private String v;

    SysRoleTypeEnum(Integer k, String v) {
        this.k = k;
        this.v = v;
    }

    public static Map<Integer, String> map = new LinkedHashMap<>(2);

    static {
        for (SysRoleTypeEnum type : SysRoleTypeEnum.values()) {
            map.put(type.getK(), type.getV());
        }
    }

    /***
     * 获取角色类型
     * @return
     */
    public static String getValueForK(Integer k) {
        SysRoleTypeEnum[] ary = SysRoleTypeEnum.values();
        for (SysRoleTypeEnum sysRoleTypeEnum : ary) {
            if (sysRoleTypeEnum.k == k) {
                return sysRoleTypeEnum.v;
            }
        }
        return "";
    }

    public Integer getK() {
        return k;
    }

    public void setK(Integer k) {
        this.k = k;
    }

    public String getV() {
        return v;
    }

    public void setV(String v) {
        this.v = v;
    }
}
