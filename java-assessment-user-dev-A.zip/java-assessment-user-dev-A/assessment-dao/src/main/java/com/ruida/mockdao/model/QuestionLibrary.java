package com.ruida.mockdao.model;

import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 题库表
 * </p>
 *
 * @author chenjy
 * @since 2020-07-09
 */
@TableName("t_question_library")
public class QuestionLibrary extends Model<QuestionLibrary> {

    private static final long serialVersionUID = 1L;

    /**
     * 试题主键id
     */
    @TableId(value = "id", type = IdType.AUTO)
    private String id;
    /**
     * 学段id
     */
    @TableField("period_id")
    private Integer periodId;
    /**
     * 科目id
     */
    @TableField("subject_id")
    private Integer subjectId;
    /**
     * 父级id
     */
    @TableField("parent_id")
    private String parentId;
    /**
     * 题型id
     */
    @TableField("question_type_id")
    private Integer questionTypeId;
    /**
     * 难度id
     */
    @TableField("difficulty_id")
    private Integer difficultyId;
    /**
     * 保密等级（0—公开；1—暂时保密；2—保密；3—严格保密；4—机密）
     */
    @TableField("security_level_id")
    private Integer securityLevelId;
    /**
     * 考核目标id
     */
    @TableField("assessment_target_id")
    private Integer assessmentTargetId;
    /**
     * 试题来源id
     */
    @TableField("question_source_id")
    private Integer questionSourceId;
    /**
     * 试题用途id
     */
    @TableField("question_purpose_id")
    private Integer questionPurposeId;
    /**
     * 预计时长，分钟
     */
    @TableField("estimate_duration")
    private Integer estimateDuration;
    /**
     * 试题内容
     */
    @TableField("question_title")
    private String questionTitle;
    /**
     * 试题音频地址
     */
    @TableField("question_audio_url")
    private String questionAudioUrl;
    /**
     * 试题音频名称
     */
    @TableField("question_audio_name")
    private String questionAudioName;
    /**
     * 试题音频时长
     */
    @TableField("question_audio_duration")
    private String questionAudioDuration;
    /**
     * 试题音频来源
     */
    @TableField("question_audio_source")
    private Integer questionAudioSource;
    /**
     * 可播放次数
     */
    @TableField("play_count")
    private Integer playCount;
    /**
     * 题目设置
     */
    @TableField("question_title_setting")
    private String questionTitleSetting;
    /**
     * 题目序号（组合题使用）
     */
    @TableField("question_sort")
    private Integer questionSort;
    /**
     * 批改类型（0—主观题；1—客观题）
     */
    @TableField("correct_type")
    private Integer correctType;
    /**
     * 选项
     */
    private String stem;
    /**
     * 答案
     */
    private String answer;
    /**
     * 是否支持拍照上传答案（0—不支持；1—支持）
     */
    @TableField("answer_photograph_id")
    private Integer answerPhotographId;
    /**
     * 试题分析
     */
    private String analysis;
    /**
     * 备注
     */
    private String note;
    /**
     * 退回原因
     */
    @TableField("reject_reason")
    private String rejectReason;
    /**
     * 评价
     */
    private String evaluation;
    /**
     * 试题状态（0-草稿；1-待审核；2-已发布；3-取消发布）
     */
    @TableField("question_status")
    private Integer questionStatus;
    /**
     * 创建者id
     */
    @TableField("create_by")
    private Integer createBy;
    /**
     * 创建时间
     */
    @TableField("create_time")
    private Date createTime;
    /**
     * 更新者id
     */
    @TableField("update_by")
    private Integer updateBy;
    /**
     * 更新时间
     */
    @TableField("update_time")
    private Date updateTime;
    /**
     * 是否删除（0：未删除；1：删除）
     */
    private Integer isdelete;


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getPeriodId() {
        return periodId;
    }

    public void setPeriodId(Integer periodId) {
        this.periodId = periodId;
    }

    public Integer getSubjectId() {
        return subjectId;
    }

    public void setSubjectId(Integer subjectId) {
        this.subjectId = subjectId;
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public Integer getQuestionTypeId() {
        return questionTypeId;
    }

    public void setQuestionTypeId(Integer questionTypeId) {
        this.questionTypeId = questionTypeId;
    }

    public Integer getDifficultyId() {
        return difficultyId;
    }

    public void setDifficultyId(Integer difficultyId) {
        this.difficultyId = difficultyId;
    }

    public Integer getSecurityLevelId() {
        return securityLevelId;
    }

    public void setSecurityLevelId(Integer securityLevelId) {
        this.securityLevelId = securityLevelId;
    }

    public Integer getAssessmentTargetId() {
        return assessmentTargetId;
    }

    public void setAssessmentTargetId(Integer assessmentTargetId) {
        this.assessmentTargetId = assessmentTargetId;
    }

    public Integer getQuestionSourceId() {
        return questionSourceId;
    }

    public void setQuestionSourceId(Integer questionSourceId) {
        this.questionSourceId = questionSourceId;
    }

    public Integer getQuestionPurposeId() {
        return questionPurposeId;
    }

    public void setQuestionPurposeId(Integer questionPurposeId) {
        this.questionPurposeId = questionPurposeId;
    }

    public Integer getEstimateDuration() {
        return estimateDuration;
    }

    public void setEstimateDuration(Integer estimateDuration) {
        this.estimateDuration = estimateDuration;
    }

    public String getQuestionTitle() {
        return questionTitle;
    }

    public void setQuestionTitle(String questionTitle) {
        this.questionTitle = questionTitle;
    }

    public String getQuestionAudioUrl() {
        return questionAudioUrl;
    }

    public void setQuestionAudioUrl(String questionAudioUrl) {
        this.questionAudioUrl = questionAudioUrl;
    }

    public String getQuestionAudioName() {
        return questionAudioName;
    }

    public void setQuestionAudioName(String questionAudioName) {
        this.questionAudioName = questionAudioName;
    }

    public String getQuestionAudioDuration() {
        return questionAudioDuration;
    }

    public void setQuestionAudioDuration(String questionAudioDuration) {
        this.questionAudioDuration = questionAudioDuration;
    }

    public Integer getQuestionAudioSource() {
        return questionAudioSource;
    }

    public void setQuestionAudioSource(Integer questionAudioSource) {
        this.questionAudioSource = questionAudioSource;
    }

    public Integer getPlayCount() {
        return playCount;
    }

    public void setPlayCount(Integer playCount) {
        this.playCount = playCount;
    }

    public String getQuestionTitleSetting() {
        return questionTitleSetting;
    }

    public void setQuestionTitleSetting(String questionTitleSetting) {
        this.questionTitleSetting = questionTitleSetting;
    }

    public Integer getQuestionSort() {
        return questionSort;
    }

    public void setQuestionSort(Integer questionSort) {
        this.questionSort = questionSort;
    }

    public Integer getCorrectType() {
        return correctType;
    }

    public void setCorrectType(Integer correctType) {
        this.correctType = correctType;
    }

    public String getStem() {
        return stem;
    }

    public void setStem(String stem) {
        this.stem = stem;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public Integer getAnswerPhotographId() {
        return answerPhotographId;
    }

    public void setAnswerPhotographId(Integer answerPhotographId) {
        this.answerPhotographId = answerPhotographId;
    }

    public String getAnalysis() {
        return analysis;
    }

    public void setAnalysis(String analysis) {
        this.analysis = analysis;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public String getRejectReason() {
        return rejectReason;
    }

    public void setRejectReason(String rejectReason) {
        this.rejectReason = rejectReason;
    }

    public String getEvaluation() {
        return evaluation;
    }

    public void setEvaluation(String evaluation) {
        this.evaluation = evaluation;
    }

    public Integer getQuestionStatus() {
        return questionStatus;
    }

    public void setQuestionStatus(Integer questionStatus) {
        this.questionStatus = questionStatus;
    }

    public Integer getCreateBy() {
        return createBy;
    }

    public void setCreateBy(Integer createBy) {
        this.createBy = createBy;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(Integer updateBy) {
        this.updateBy = updateBy;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getIsdelete() {
        return isdelete;
    }

    public void setIsdelete(Integer isdelete) {
        this.isdelete = isdelete;
    }

    @Override
    protected Serializable pkVal() {
        return this.id;
    }

    @Override
    public String toString() {
        return "QuestionLibrary{" +
        ", id=" + id +
        ", periodId=" + periodId +
        ", subjectId=" + subjectId +
        ", parentId=" + parentId +
        ", questionTypeId=" + questionTypeId +
        ", difficultyId=" + difficultyId +
        ", securityLevelId=" + securityLevelId +
        ", assessmentTargetId=" + assessmentTargetId +
        ", questionSourceId=" + questionSourceId +
        ", questionPurposeId=" + questionPurposeId +
        ", estimateDuration=" + estimateDuration +
        ", questionTitle=" + questionTitle +
        ", questionAudioUrl=" + questionAudioUrl +
        ", questionAudioName=" + questionAudioName +
        ", questionAudioDuration=" + questionAudioDuration +
        ", questionAudioSource=" + questionAudioSource +
        ", playCount=" + playCount +
        ", questionTitleSetting=" + questionTitleSetting +
        ", questionSort=" + questionSort +
        ", correctType=" + correctType +
        ", stem=" + stem +
        ", answer=" + answer +
        ", answerPhotographId=" + answerPhotographId +
        ", analysis=" + analysis +
        ", note=" + note +
        ", rejectReason=" + rejectReason +
        ", evaluation=" + evaluation +
        ", questionStatus=" + questionStatus +
        ", createBy=" + createBy +
        ", createTime=" + createTime +
        ", updateBy=" + updateBy +
        ", updateTime=" + updateTime +
        ", isdelete=" + isdelete +
        "}";
    }
}
