package com.ruida.mockcommon.util;

import java.math.BigDecimal;

/**
 * 计算价格
 * @author szl
 *
 */
public class CalculatingPrice {

	private static final BigDecimal HUNDRED=new BigDecimal(100);
	/**
	 * 乘100
	 *
	 * @param price
	 * @return
	 */
	public static BigDecimal multiply100(BigDecimal price) {
		return price.multiply(HUNDRED);
	}

	/**
	 * 除100
	 *
	 * @param price
	 * @return
	 */
	public static BigDecimal divide100(BigDecimal price) {
		return price.divide(HUNDRED);
	}

}
