package com.ruida.cloud.dao;

import com.ruida.cloud.model.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

public interface DoubleCourseMapper {
    int countByExample(DoubleCourseExample example);

    int deleteByExample(DoubleCourseExample example);

    int deleteByPrimaryKey(Integer courseId);

    int insert(DoubleCourse record);

    int insertSelective(DoubleCourse record);

    List<DoubleCourse> selectByExample(DoubleCourseExample example);

    DoubleCourse selectByPrimaryKey(Integer courseId);

    int updateByExampleSelective(@Param("record") DoubleCourse record, @Param("example") DoubleCourseExample example);

    int updateByExample(@Param("record") DoubleCourse record, @Param("example") DoubleCourseExample example);

    int updateByPrimaryKeySelective(DoubleCourse record);

    int updateByPrimaryKey(DoubleCourse record);

    /**
     * 双师课列表（分页）
     * @param param
     * @return
     */
    List<DoubleCourseExt> getDoubleTeacherList(Map param);

    /**
     * 列表总数
     * @param param
     * @return
     */
    Integer getDoubleTeacherListNum(Map param);

    /**
     * 获取年级
     * @return
     */
    List getDoubleTeacherStage();

    /**
     * 双师课列表（不分页）
     * @param param
     * @return
     */
    List<DoubleCourseExt> getDoubleTeacherListNotPage(Map param);

    /**
     * 获取科目
     * @return
     */
    List getDoubleTeacherSubject();

    /**
     *  排课列表
     * @param param
     * @return
     */
    List<DoubleCourseExt> getDoubleCourseLessonList(Map param);

    /**
     * 排课列表数量
     * @param param
     * @return
     */
    Integer getDoubleCourseLessonListNum(Map param);

    /**
     * 排课列表（无分页）
     * @param param
     * @return
     */
    List<DoubleCourseExt> getDoubleCourseLessonListNotPage(Map param);


    @Select("SELECT room_id FROM t_double_course_lesson WHERE isdelete = 0 and course_id = #{courseId}")
    List<String> getDoubleCourseRoomIds(@Param("courseId") Integer courseId);

    @Update("UPDATE t_double_course a set a.listen_zone_ids = #{listenZoneIds} WHERE a.course_id = #{courseId} ")
    Integer updateDoubleCourseListenZoneIds(@Param("listenZoneIds") String listenZoneIds,@Param("courseId") Integer courseId);
}