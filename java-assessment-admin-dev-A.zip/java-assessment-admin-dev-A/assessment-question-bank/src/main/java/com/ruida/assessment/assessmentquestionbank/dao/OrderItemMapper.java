package com.ruida.assessment.assessmentquestionbank.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.assessment.assessmentquestionbank.model.TOrderItem;
import org.apache.ibatis.annotations.Param;
import org.mapstruct.Mapper;

import java.util.Collection;
import java.util.List;

/**
 * @author wy
 * @description 订单商品mapper
 * @date 2020/8/3
 */
@Mapper
public interface OrderItemMapper extends BaseMapper<TOrderItem> {

    List<TOrderItem> queryOwnPaperItmes(@Param("productId") Integer productId, @Param("presellId") Integer presellId,@Param("ispresell") Integer ispresell);

    List<TOrderItem> queryUserOwnPaperItmes(@Param("userId") Integer userId,@Param("productId") Integer productId,@Param("ispresell") Integer ispresell);

    List<TOrderItem> queryUserOwnReportItems(@Param("userId") Integer userId, @Param("productId")Integer productId);
}
