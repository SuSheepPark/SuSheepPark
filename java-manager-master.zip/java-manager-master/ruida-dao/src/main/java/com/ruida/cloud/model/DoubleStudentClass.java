package com.ruida.cloud.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ruida.common.SystemConstant;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 * 双师听课教室
 */
@Data
public class DoubleStudentClass {
    /**
     * id
     */
    private Integer id;

    /**
     * 课程id
     */
    private String courseId;

    /**
     * 听课教室id
     */
    private String studentClassId;

    /**
     * 听课教室名称
     */
    private String studentClassName;

    /**
     * 是否删除
     */
    private int isdelete;

    /**
     * 创建时间
     */
    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern= "yyyy-MM-dd HH:mm:ss",timezone=SystemConstant.TIME_ZONE)
    private Date createTime;

    /**
     * 更新时间
     */
    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern= "yyyy-MM-dd HH:mm:ss",timezone= SystemConstant.TIME_ZONE)
    private Date updateTime;

    /**
     * 创建者ID（关联user_id）
     */
    private Integer createBy;

    /**
     * 更新者ID（关联user_id）
     */
    private Integer updateBy;

}