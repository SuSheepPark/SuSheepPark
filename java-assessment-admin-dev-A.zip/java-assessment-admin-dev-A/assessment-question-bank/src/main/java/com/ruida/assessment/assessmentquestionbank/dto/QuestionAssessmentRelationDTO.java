package com.ruida.assessment.assessmentquestionbank.dto;

import lombok.Data;

/**
 * @description: 试题与考察要求关联关系dto
 * @author: wy
 * @date: 2021/3/2
 */
@Data
public class QuestionAssessmentRelationDTO {
    /**
     * 系id
     */
    private Integer id;

    /**
     * 试题id
     */
    private String questionLibraryId;

    /**
     * 考察要求id
     */
    private Integer assessmentId;

    /**
     * 权重值
     */
    private Double assessmentPoints;


}
