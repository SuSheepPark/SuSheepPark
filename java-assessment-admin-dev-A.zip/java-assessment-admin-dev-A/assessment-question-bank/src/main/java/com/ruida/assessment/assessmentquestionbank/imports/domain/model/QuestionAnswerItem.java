package com.ruida.assessment.assessmentquestionbank.imports.domain.model;

public class QuestionAnswerItem {
	private String answer;

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}
	
}
