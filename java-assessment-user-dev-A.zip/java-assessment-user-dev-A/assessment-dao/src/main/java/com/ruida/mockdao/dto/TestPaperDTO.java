package com.ruida.mockdao.dto;

import lombok.Data;

import java.util.List;

/**
 * @description: 试卷DTO
 * @author: chenjy
 * @create: 2020-07-14 16:59
 */
@Data
public class TestPaperDTO {

    /**
     * 场次Id
     */
    private String sceneId;

    /*
    考试记录id
     */
    private Integer examRecordId;

    /**
     * 状态 （0：交卷；1：未交卷）
     */
    private Integer status;

    /**
     * 考试时间 （单位：秒）
     */
    private Integer duration;

    /**
     * 小节信息
     */
    private List<NodeDTO> nodeList;
}
