package com.ruida.assessment.assessmentquestionbank.dto;

/**
 * @description: 试题与知识点关联关系dto
 * @author: kgz
 * @date: 2020/6/16
 */
public class QuestionKnowledgeRelationDTO {
    /**
     * 试题知识点关系id
     */
    private Integer id;

    /**
     * 试题id
     */
    private String questionLibraryId;

    /**
     * 知识点id
     */
    private Integer knowledgeId;

    /**
     * 知识点分值
     */
    private Double knowledgePoints;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getQuestionLibraryId() {
        return questionLibraryId;
    }

    public void setQuestionLibraryId(String questionLibraryId) {
        this.questionLibraryId = questionLibraryId;
    }

    public Integer getKnowledgeId() {
        return knowledgeId;
    }

    public void setKnowledgeId(Integer knowledgeId) {
        this.knowledgeId = knowledgeId;
    }

    public Double getKnowledgePoints() {
        return knowledgePoints;
    }

    public void setKnowledgePoints(Double knowledgePoints) {
        this.knowledgePoints = knowledgePoints;
    }

    @Override
    public String toString() {
        return "QuestionKnowledgeRelationDTO{" +
                "id=" + id +
                ", questionLibraryId=" + questionLibraryId +
                ", knowledgeId=" + knowledgeId +
                ", knowledgePoints=" + knowledgePoints +
                '}';
    }
}
