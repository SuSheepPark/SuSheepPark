package com.ruida.assessment.assessmentquestionbank.dto;

import lombok.Data;

/**
 * @author wy
 * @description 班级请求类
 * @date 2020/7/24
 */
@Data
public class ClassRequest {

    private Integer classId;

    private String className;

    private Integer schoolId;

    private Integer gradeId;

    private Integer status;

}
