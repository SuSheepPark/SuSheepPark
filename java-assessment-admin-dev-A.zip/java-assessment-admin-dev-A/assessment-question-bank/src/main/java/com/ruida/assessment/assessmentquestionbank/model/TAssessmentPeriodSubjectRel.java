package com.ruida.assessment.assessmentquestionbank.model;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import lombok.Data;

import java.io.Serializable;

/**
 * @author wy
 * @description  考察要求-学段-科目关联实体类
 * @date 2020/9/14
 */
@Data
@TableName("t_assessment_period_subject_rel")
public class TAssessmentPeriodSubjectRel implements Serializable {


    private static final long serialVersionUID = 1753161771395723850L;

    @TableId
    private Integer id;

    private Integer assessmentId;
    private Integer periodId;
    private Integer subjectId;
}
