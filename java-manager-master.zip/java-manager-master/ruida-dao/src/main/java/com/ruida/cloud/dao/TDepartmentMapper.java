package com.ruida.cloud.dao;

import com.ruida.cloud.model.TDepartment;
import com.ruida.cloud.model.TDepartmentExample;

import java.util.List;

import com.ruida.cloud.model.TDepartmentExt;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

public interface TDepartmentMapper {
    int countByExample(TDepartmentExample example);

    int deleteByExample(TDepartmentExample example);

    int deleteByPrimaryKey(Integer departmentId);

    int insert(TDepartment record);

    int insertSelective(TDepartment record);

    List<TDepartment> selectByExample(TDepartmentExample example);

    TDepartment selectByPrimaryKey(Integer departmentId);

    int updateByExampleSelective(@Param("record") TDepartment record, @Param("example") TDepartmentExample example);

    int updateByExample(@Param("record") TDepartment record, @Param("example") TDepartmentExample example);

    int updateByPrimaryKeySelective(TDepartment record);

    int updateByPrimaryKey(TDepartment record);

    /**
     * 分页查询部门
     *
     * @param pageNo
     * @param pageSize
     * @return
     */
    @Select("SELECT\n" +
            "\ta.department_id AS departmentId,\n" +
            "\ta.department_name AS departmentName,\n" +
            "\ta.`status`,\n" +
            "\ta.create_time AS createTime,\n" +
            "\ta.update_time AS updateTime,\n" +
            "  c.telephone,\n" +
            "  c.real_name AS  realName\n" +
            "FROM\n" +
            "\tt_department a\n" +
            " LEFT JOIN sys_user_role b ON a.department_id = b.department_id \n" +
            " LEFT JOIN sys_role d ON b.role_id = d.role_id  AND d.role_type = 1\n" +
            " LEFT JOIN sys_user c ON b.user_id = c.user_id AND  d.role_id IS NOT NULL\n" +
            "WHERE\n" +
            "\ta.isdelete = 0 \n" +
            "GROUP BY\n" +
            "\ta.department_id\n" +
            "ORDER BY\n" +
            "\ta.create_time DESC\n" +
            "LIMIT  #{pageNo},#{pageSize} ")
    List<TDepartment> selectDepartmentByPage(@Param("pageNo") Integer pageNo, @Param("pageSize") Integer pageSize);

    @Select("SELECT\n" +
            "\ta.department_id AS departmentId,a.department_name AS departmentName\n" +
            "FROM\n" +
            "\tt_department a\n" +
            "LEFT JOIN sys_role b ON b.department_id = a.department_id\n" +
            "LEFT JOIN sys_user_role c ON c.role_id = b.role_id\n" +
            "WHERE c.user_id = #{userId}")
    List<TDepartmentExt> getDepartMentByUserId(@Param("userId") Integer userId);//查询用户的部门信息
    @Select("SELECT\n" +
            "\ta.department_id AS departmentId,\n" +
            "\ta.department_name AS departmentName,\n" +
            "\ta.`status`,\n" +
            "\ta.create_time AS createTime,\n" +
            "\ta.update_time AS updateTime,\n" +
            "\tc.telephone,\n" +
            "\tc.real_name realName\n" +
            "FROM\n" +
            "\tt_department a\n" +
            "LEFT JOIN sys_user_role b ON a.department_id = b.department_id\n" +
            "LEFT JOIN sys_role d ON d.role_type = 1\n" +
            "OR d.role_type = 0\n" +
            "LEFT JOIN sys_user c ON b.user_id = c.user_id\n" +
            "WHERE\n" +
            "\ta.isdelete = 0\n" +
            "AND a.department_id = #{departmentId}\n" +
            "GROUP BY\n" +
            "\ta.department_id")
    TDepartment getDepartmentById(@Param("departmentId") Integer departmentId);
}