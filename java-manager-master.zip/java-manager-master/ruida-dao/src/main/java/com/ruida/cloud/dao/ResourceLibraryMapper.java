package com.ruida.cloud.dao;

import com.ruida.cloud.model.ResourceLibrary;
import com.ruida.cloud.model.ResourceLibraryExample;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Update;

import java.util.Date;
import java.util.List;
import java.util.Map;

public interface ResourceLibraryMapper {
    int countByExample(ResourceLibraryExample example);

    int deleteByExample(ResourceLibraryExample example);

    int deleteByPrimaryKey(Integer resourceLibraryId);

    int insert(ResourceLibrary record);

    int insertSelective(ResourceLibrary record);

    List<ResourceLibrary> selectByExample(ResourceLibraryExample example);

    ResourceLibrary selectByPrimaryKey(Integer resourceLibraryId);

    int updateByExampleSelective(@Param("record") ResourceLibrary record, @Param("example") ResourceLibraryExample example);

    int updateByExample(@Param("record") ResourceLibrary record, @Param("example") ResourceLibraryExample example);

    int updateByPrimaryKeySelective(ResourceLibrary record);

    int updateByPrimaryKey(ResourceLibrary record);

    List<Map<String ,Object>> getResourceLibraryByLessonId(@Param("courseLessonId") Integer courseLessonId);
    @Update("update  t_resource_library set  isdelete = 1 ,update_by=#{userId} ,update_time=#{time}   where resource_library_id=#{id} ")
    Integer deleteLibraryByid(@Param("id") Integer id, @Param("userId") Integer userId, @Param("time") Date time);
}