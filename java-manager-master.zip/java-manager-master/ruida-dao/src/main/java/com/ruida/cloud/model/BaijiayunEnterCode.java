package com.ruida.cloud.model;

import lombok.Data;

@Data
public class BaijiayunEnterCode {

    //学生参加码
    private String studentEnterCode;

    //学生进入房间地址
    private String studentEnterUrl;

    //老师参加码
    private String teacherEnterCode;

    //老师进入房间地址
    private String teacherEnterUrl;

    //助教参加码
    private String assistantEnterCode;

    //助教进入房间地址
    private String assistantEnterUrl;

}
