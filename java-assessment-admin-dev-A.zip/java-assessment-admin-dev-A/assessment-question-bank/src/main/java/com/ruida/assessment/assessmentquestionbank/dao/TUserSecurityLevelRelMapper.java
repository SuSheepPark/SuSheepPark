package com.ruida.assessment.assessmentquestionbank.dao;

import com.ruida.assessment.assessmentquestionbank.model.TUserSecurityLevelRel;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * <p>
 * 用户保密等级关联表 Mapper 接口
 * </p>
 *
 * @author szl
 * @since 2020-07-29
 */
public interface TUserSecurityLevelRelMapper extends BaseMapper<TUserSecurityLevelRel> {
       @Select("SELECT a.security_level FROM t_user_security_level_rel a WHERE a.user_id = #{userId}")
       List<Integer> getSecuIdListByUser(@Param("userId") Integer userId);
}
