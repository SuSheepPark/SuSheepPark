package com.ruida.mockcommon.enums;

import com.google.common.collect.Lists;

import java.util.Collection;
import java.util.List;

/**
 * 科目
 */
public enum SubjectEnum {
    CHINESE(1,"语文"),
    MATH(2,"数学"),
    ENGLISH(3,"英语"),
//    SCIENCE(4,"科学"),
    PHYSICS(5,"物理"),
    CHEMISTRY(6,"化学"),
    BIOLOGY(7,"生物"),
    POLITICS(8,"政治"),
    HISTORY(9,"历史"),
    GEOGRAPHY(10,"地理"),
    TECHNOLOGY(11,"技术");

    private int code;

    private String name;

    SubjectEnum(int code, String name) {
        this.code = code;
        this.name = name;
    }

    public int getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    public static String getNameByCode(int code){
        for(SubjectEnum item:SubjectEnum.values()){
            if(item.getCode() == code){
                return item.getName();
            }
        }
        return null;
    }

    public static String convert(Collection<Integer> collection){
        if (collection == null || collection.isEmpty()){
            return null;
        }

        int max = collection.size() - 1;

        StringBuilder sb = new StringBuilder();
        sb.append("「");

        int i = 0;
        for(Integer code : collection){
            sb.append(getNameByCode(code));
            if(i == max){
                return sb.append("」").toString();
            }
            sb.append("、");
            i++;

        }
        return null;
    }

    /**
     * 必修科目
     * @return
     */
    public static List<SubjectEnum> getRequiredSubject(){
        return  Lists.newArrayList(
                SubjectEnum.CHINESE,
                SubjectEnum.MATH,
                SubjectEnum.ENGLISH);
    }

    /**
     * 选考科目
     * @return
     */
    public static List<SubjectEnum> getOptionalSubject(){
        return Lists.newArrayList(
                SubjectEnum.PHYSICS,
                SubjectEnum.CHEMISTRY,
                SubjectEnum.BIOLOGY,
                SubjectEnum.POLITICS,
                SubjectEnum.HISTORY,
                SubjectEnum.GEOGRAPHY,
                SubjectEnum.TECHNOLOGY);
    }

}
