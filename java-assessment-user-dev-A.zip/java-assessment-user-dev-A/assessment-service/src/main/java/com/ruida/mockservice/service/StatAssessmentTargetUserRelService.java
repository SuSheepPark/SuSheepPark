package com.ruida.mockservice.service;

import com.baomidou.mybatisplus.service.IService;
import com.ruida.mockdao.model.StatAssessmentTargetUserRel;

/**
 * <p>
 * 考察要求用户统计表 服务类
 * </p>
 *
 * @author chenjy
 * @since 2021-03-04
 */
public interface StatAssessmentTargetUserRelService extends IService<StatAssessmentTargetUserRel> {

}
