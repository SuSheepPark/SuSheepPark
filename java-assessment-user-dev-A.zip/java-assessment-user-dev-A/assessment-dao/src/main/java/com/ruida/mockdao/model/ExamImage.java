package com.ruida.mockdao.model;

import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;
import com.fasterxml.jackson.annotation.JsonIgnore;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 
 * </p>
 *
 * @author chenjy
 * @since 2020-07-14
 */
@TableName("t_exam_image")
public class ExamImage extends Model<ExamImage> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键ID
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;
    /**
     * 试题ID
     */
    @JsonIgnore
    @TableField("question_id")
    private String questionId;
    /**
     * 图片路径
     */
    @TableField("image_path")
    private String imagePath;
    /**
     * 创建人
     */
    @JsonIgnore
    @TableField("create_by")
    private Integer createBy;
    /**
     * 创建时间
     */
    @JsonIgnore
    @TableField("create_time")
    private Date createTime;
    /**
     * 修改人
     */
    @JsonIgnore
    @TableField("update_by")
    private Integer updateBy;
    /**
     * 修改时间
     */
    @JsonIgnore
    @TableField("update_time")
    private Date updateTime;
    /**
     * 删除标志（0：未删除；1：已删除）
     */
    @JsonIgnore
    private Integer isdelete;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getQuestionId() {
        return questionId;
    }

    public void setQuestionId(String questionId) {
        this.questionId = questionId;
    }

    public String getImagePath() {
        return imagePath;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }

    public Integer getCreateBy() {
        return createBy;
    }

    public void setCreateBy(Integer createBy) {
        this.createBy = createBy;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(Integer updateBy) {
        this.updateBy = updateBy;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getIsdelete() {
        return isdelete;
    }

    public void setIsdelete(Integer isdelete) {
        this.isdelete = isdelete;
    }

    @Override
    protected Serializable pkVal() {
        return this.id;
    }

    @Override
    public String toString() {
        return "ExamImage{" +
        ", id=" + id +
        ", questionId=" + questionId +
        ", imagePath=" + imagePath +
        ", createBy=" + createBy +
        ", createTime=" + createTime +
        ", updateBy=" + updateBy +
        ", updateTime=" + updateTime +
        ", isdelete=" + isdelete +
        "}";
    }
}
