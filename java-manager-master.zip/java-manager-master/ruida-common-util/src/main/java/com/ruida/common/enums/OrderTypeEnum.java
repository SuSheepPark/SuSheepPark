package com.ruida.common.enums;

public enum OrderTypeEnum {
    COURSE_ORDER(0, "课程订单"),
    BOOK_ORDER(1, "图书订单"),
    COMPOSE_ORDER(2, "组合课订单");

    private int code;
    private String name;

    OrderTypeEnum(int code, String name) {
        this.code = code;
        this.name = name;
    }

    public static OrderTypeEnum getEnum(int code) {
        for (OrderTypeEnum item : OrderTypeEnum.values()) {
            if (item.code == code) {
                return item;
            }
        }
        return null;
    }

    /**
     * 根据code获取name
     *
     * @param code
     * @return
     */
    public static String getName(int code) {
        OrderTypeEnum item = getEnum(code);
        return item != null ? item.name : null;
    }


    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


}
