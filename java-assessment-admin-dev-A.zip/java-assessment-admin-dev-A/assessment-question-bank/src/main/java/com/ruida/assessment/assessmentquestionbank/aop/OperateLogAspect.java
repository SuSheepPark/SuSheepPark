package com.ruida.assessment.assessmentquestionbank.aop;

import com.alibaba.fastjson.JSON;
import com.ruida.assessment.assessmentcommon.auth.context.BaseContextHandle;
import com.ruida.assessment.assessmentcommon.auth.pojo.JWTInfo;
import com.ruida.assessment.assessmentcommon.util.IpUtils;
import com.ruida.assessment.assessmentquestionbank.annotaion.OperateLog;
import com.ruida.assessment.assessmentquestionbank.model.TOperateLog;
import com.ruida.assessment.assessmentquestionbank.service.OperateLogService;
import com.ruida.assessment.assessmentquestionbank.service.ruidaCloud.UserService;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Date;
import java.util.Map;
import java.util.Optional;

/**
 * @description: 操作日志统一处理切面
 * @author: kgz
 * @date: 2020/8/12
 */
@Slf4j
@Aspect
@Component
public class OperateLogAspect {

    @Resource
    private OperateLogService operateLogService;

    @Resource
    private UserService userService;

    /**
     * 设置操作日志切入点 记录操作日志 在注解的位置切入代码
     */
     @Pointcut("@annotation(com.ruida.assessment.assessmentquestionbank.annotaion.OperateLog)")
     public void pointCut() {
    }

    /**
     * 记录操作日志
     */
    @After("pointCut()")
     public void saveOperLog(JoinPoint joinPoint) {
        // 获取RequestAttributes
        RequestAttributes requestAttributes = RequestContextHolder.getRequestAttributes();
        // 从获取RequestAttributes中获取HttpServletRequest的信息
        HttpServletRequest request = (HttpServletRequest) requestAttributes.resolveReference(RequestAttributes.REFERENCE_REQUEST);
        try {

            // 从切面织入点处通过反射机制获取织入点处的方法
            MethodSignature signature = (MethodSignature) joinPoint.getSignature();
            // 获取切入点所在的方法
            Method method = signature.getMethod();
            // 获取操作
            OperateLog operateLog = method.getAnnotation(OperateLog.class);
            if (operateLog != null) {
                TOperateLog tOperateLog = new TOperateLog();
                tOperateLog.setOperateModule(operateLog.module().getModule());
                tOperateLog.setModuleId(operateLog.module().getId());
                tOperateLog.setOperateType(operateLog.operateType().getOperateType());
                tOperateLog.setOperateDesc(operateLog.operateType().getOperateType());
                tOperateLog.setOperateUri(request.getRequestURI());
                tOperateLog.setOperateIp(IpUtils.getIpAddress(request));
                tOperateLog.setOperateUserId(getUserInfo().getUserId() == null ? null : Integer.valueOf(getUserInfo().getUserId()));
                tOperateLog.setOperateUserName(getUserInfo().getUsername());
                tOperateLog.setOperateRealName(getUserRealName(getUserInfo().getUserId()));
                tOperateLog.setCreateTime(new Date());
                operateLogService.insert(tOperateLog);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
     }

    /**
     * 获取当前用户信息
     * @return
     */
    private JWTInfo getUserInfo(){
        JWTInfo userInfo = BaseContextHandle.getJWTInfo();
        return Optional.ofNullable(userInfo).orElse(new JWTInfo());
    }

    /**
     * 获取操作者的姓名
     * @return
     */
    private String getUserRealName(String userId) {
        try {
            if(userId != null){
                Map<String, Object> user = userService.getUserInfoByUserId(Integer.valueOf(userId));
                if(user != null && user.size() > 0){
                    return String.valueOf(user.get("realName"));
                }
            }
        }catch (Exception e){
        }
        return null;
    }
}
