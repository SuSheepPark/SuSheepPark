package com.ruida.mockdao.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.model.Student;
import com.ruida.mockdao.model.StudentRelInfo;
import com.ruida.mockdao.vo.StudentInfoVO;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * 学生信息表（包括学生和游客） Mapper 接口
 * </p>
 *
 * @author Bhj
 * @since 2020-07-09
 */
public interface StudentMapper extends BaseMapper<Student> {

    /**
     *  插入学生信息
     * @param student
     */
    void insertStudent(Student student);

    /**
     * 根据用户 user_id 获取 详细的信息
     *
     * @param userId
     * @return
     */
    Map<String, Object> getStudentInfo(int userId);
    
    /**根据准考证号获取学生班级学校等信息
     * @param stuId
     * @return
     */
    StudentInfoVO getStudentRelInfoByStudentNo(String stuId);
    
    StudentInfoVO getStudentInfoVO(Integer userId);

    Student getStudent(String userId);

    StudentRelInfo getStudentRelInfo(Integer stuId);

    StudentRelInfo getStudentRelInfoByUserId(Integer userID);

    Integer getPeriodIdByGrade(Integer stageId);

    /**
     * 查询用户的准考证号列表
     * @param userId
     * @return
     */
    List<StudentInfoVO> getStuNoList(Integer userId);

    /**
     * 是否未绑定准考证号
     * @return
     */
    List<Student> isBondedStuNo(String userId);

    /**
     * web端获取用户详情
     * @return
     */
    List<StudentInfoVO> getStudentByUserId(String userId);
}
