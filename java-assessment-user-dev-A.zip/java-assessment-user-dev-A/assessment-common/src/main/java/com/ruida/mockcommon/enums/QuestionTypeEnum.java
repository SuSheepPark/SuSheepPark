package com.ruida.mockcommon.enums;

/**
 * 题型枚举
 */
public enum QuestionTypeEnum {
    SCT(1,"单选题"),
    MCT(2,"多选题"),
    ICT(3,"不定项选择题"),
    JDT(4,"判断题"),
    CT(5,"填空题"),
    SAT(6,"简答题"),
    CQT(7,"组合题");


    private Integer K;
    private String V;

    QuestionTypeEnum(Integer k, String v) {
        K = k;
        V = v;
    }

    public Integer getK() {
        return K;
    }

    public void setK(Integer k) {
        K = k;
    }

    public String getV() {
        return V;
    }

    public void setV(String v) {
        V = v;
    }


    public static String getValueById(Integer K) {
        for (QuestionTypeEnum questionEnum : QuestionTypeEnum.values()) {
            if (questionEnum.getK().equals(K)) {
                return questionEnum.getV();
            }
        }
        return null;
    }

    public static boolean isObjectiveQuestion(Integer typeId) {
        return SCT.getK().equals(typeId) || MCT.getK().equals(typeId) || ICT.getK().equals(typeId) || JDT.getK().equals(typeId);
    }

}
