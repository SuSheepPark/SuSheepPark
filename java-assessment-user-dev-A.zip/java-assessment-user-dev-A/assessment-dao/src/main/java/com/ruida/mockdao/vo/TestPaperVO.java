package com.ruida.mockdao.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import java.util.Date;
import java.util.List;

/**
 * @description: 试卷VO
 * @author: chenjy
 * @create: 2020-07-13 13:10
 */
@Data
@JsonInclude(value = JsonInclude.Include.NON_NULL)
public class TestPaperVO {

    /**
     * 试卷id
     */
    private Integer testPaperId;

    /**
     * 试卷名称
     */
    private String testPaperName;

    /**
     * 考试方式（0-练习 1-纸考 2-机房考 3-统考）
     */
    private Integer testWay;

    /**
     * 考试开始时间(统考类型的试卷才有值)
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",locale = "zh",timezone = "GMT+8")
    private Date testStartTime;

    /**
     * 考试结束时间(统考类型的试卷才有值)
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",locale = "zh",timezone = "GMT+8")
    private Date testEndTime;

    /**
     * 考试时长
     */
    private Integer testDuration;

    /**
     * 考试使用的时间啊
     */
    private Integer usedTime;

    /**
     * 服务器时间
     */
    private String now;

    /**
     * 小节集合
     */
    private List<NodeVO> nodeList;

    private Integer examRecordId;

    //在线统考

    /**
     * 场次名称
     */
    private String sceneName;

    /**
     * 考生名称
     */
    private String stuName;

    /**
     * 考号
     */
    private String stuNo;
}
