package com.ruida.mockdao.model;

import java.io.Serializable;
import java.util.Date;

import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;
import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * <p>
 * 首页资讯栏目表
 * </p>
 *
 * @author wy
 * @since 2021-08-16
 */
@TableName("t_information_column")
public class TInformationColumn extends Model<TInformationColumn> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;
    /**
     * 栏目名称
     */
    private String name;
    /**
     * 描述
     */
    @JsonIgnore
    private String desc;
    /**
     * 栏目类型id
     */
    @JsonIgnore
    private Integer informationId;
    /**
     * 状态 0-显示 1-隐藏
     */
    @JsonIgnore
    private Integer status;
    /**
     * 排序
     */
    private Integer sort;
    @TableField("create_by")
    @JsonIgnore
    private Integer createBy;
    @TableField("create_time")
    @JsonIgnore
    private Date createTime;
    @TableField("update_by")
    @JsonIgnore
    private Integer updateBy;
    @TableField("update_time")
    @JsonIgnore
    private Date updateTime;
    @JsonIgnore
    private Integer isdelete;


    public Integer getId() {
        return id;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public Integer getInformationId() {
        return informationId;
    }

    public void setInformationId(Integer informationId) {
        this.informationId = informationId;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getSort() {
        return sort;
    }

    public void setSort(Integer sort) {
        this.sort = sort;
    }

    public Integer getCreateBy() {
        return createBy;
    }

    public void setCreateBy(Integer createBy) {
        this.createBy = createBy;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(Integer updateBy) {
        this.updateBy = updateBy;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getIsdelete() {
        return isdelete;
    }

    public void setIsdelete(Integer isdelete) {
        this.isdelete = isdelete;
    }

    @Override
    protected Serializable pkVal() {
        return this.id;
    }

    @Override
    public String toString() {
        return "TInformationColumn{" +
        ", id=" + id +
        ", name=" + name +
        ", status=" + status +
        ", sort=" + sort +
        ", createBy=" + createBy +
        ", createTime=" + createTime +
        ", updateBy=" + updateBy +
        ", updateTime=" + updateTime +
        ", isdelete=" + isdelete +
        "}";
    }
}
