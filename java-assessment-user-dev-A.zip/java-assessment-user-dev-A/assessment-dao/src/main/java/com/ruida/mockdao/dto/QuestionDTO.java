package com.ruida.mockdao.dto;

import com.ruida.mockdao.pojo.Choice;
import lombok.Data;

import java.util.List;

/**
 * @description: 试题DTO
 * @author: chenjy
 * @create: 2020-07-14 17:04
 */
@Data
public class QuestionDTO {

    /**
     * 试题id
     */
    private String questionId;

    /**
     * 拍照上传的图片id
     */
    private String imageId;

    /**
     * 用户答案
     */
    private List<Choice> userAnswer;

    /**
     * 子题信息
     */
    private List<QuestionDTO> child;

    /**
     * 音频已经播放的次数
     */
    private Integer audioPlayCount;

    /**
     * 自主阅卷评分
     */
    private String selfCheckScore;

}
