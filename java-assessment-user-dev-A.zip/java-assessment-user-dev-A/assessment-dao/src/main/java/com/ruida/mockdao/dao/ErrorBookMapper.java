package com.ruida.mockdao.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.dto.PersonCenterDTO;
import com.ruida.mockdao.model.ErrorBook;
import com.ruida.mockdao.vo.QuestionVO;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * 错题表 Mapper 接口
 * </p>
 *
 * @author chenjy
 * @since 2020-07-16
 */
public interface ErrorBookMapper extends BaseMapper<ErrorBook> {

    List<QuestionVO> selectErrorQuestionList(@Param("req") PersonCenterDTO req);

    Integer countErrorQuestion(@Param("req") PersonCenterDTO req);

    Map getErrorQuestionInfo(@Param("userId") Integer userId);

    Integer deleteErrorQuestion(@Param("list") List<String> idList,@Param("userId") Integer userId);

    List<Map<String,Object>> queryErrorQuestionGroupSubject(@Param("userId") Integer userId,@Param("periodId") Integer periodId);

    Integer countErrorNum(@Param("userId") Integer userId);

    List<Integer> queryKnowledge(@Param("userId") String userId,@Param("subjectId") Integer subjectId);
}
