package com.ruida.assessment.assessmentquestionbank.model;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import io.swagger.annotations.ApiModel;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @author wy
 * @description 学员数据库实体类
 * @date 2020/7/31
 */
@Data
@ApiModel(description = "商品赠送记录实体类")
@TableName("t_product_present_record")
public class TProductPresentRecord extends BaseColumn implements Serializable {


    private static final long serialVersionUID = -3055051666168867106L;
    /**
     * 主键ID
     */
    @TableId
    private Integer id;

    /*
    用户id
     */
    private Integer userId;

    /*
    学生id
     */
    private Integer stuId;


    private Integer productId;

    /*
    是否已赠送报告 0-否 1-是
     */
    private Integer isPresentReport;

    /*
    赠送时间
     */
    private Date presentTime;


}
