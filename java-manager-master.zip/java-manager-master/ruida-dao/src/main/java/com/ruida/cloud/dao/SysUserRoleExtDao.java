package com.ruida.cloud.dao;

import com.ruida.cloud.model.SchoolStageClassRel;
import com.ruida.cloud.model.StudentRelInfo;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * @author admin
 * @description: ${TODO}
 * @Date 2019/9/26
 * @verion 1.0
 */
public interface SysUserRoleExtDao {
    /**
     * 根据用户id获取组织架构
     * @param userId
     * @return
     */
    @Select("SELECT\n" +
            "\ta.class_id AS classId,\n" +
            "\ta.period_id AS periodId,\n" +
            "\ta.rid,\n" +
            "\ta.`status`,\n" +
            "\ta.student_id AS studentId,\n" +
            "\ta.stage_id AS stageId,\n" +
            "\ta.school_id AS schoolId\n" +
            "FROM\n" +
            "\tt_student_rel_info a\n" +
            "LEFT JOIN t_student b ON a.student_id = b.stu_id\n" +
            "WHERE\n" +
            "\tb.user_id = #{userId}\n" +
            "AND b.isdelete = 0\n" +
            "AND a. STATUS = 1")
    StudentRelInfo getOrgByUserId(@Param("userId") Integer userId);
}
