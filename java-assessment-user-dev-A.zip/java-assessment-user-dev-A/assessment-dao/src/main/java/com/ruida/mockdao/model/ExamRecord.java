package com.ruida.mockdao.model;

import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * <p>
 * 考试记录表
 * </p>
 *
 * @author chenjy
 * @since 2020-08-04
 */
@TableName("t_exam_record")
public class ExamRecord extends Model<ExamRecord> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键ID
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;
    /**
     * 测试名称
     */
    @TableField("exam_name")
    private String examName;
    /**
     * 商品id
     */
    @TableField("product_id")
    private Integer productId;
    /**
     * 试卷ID
     */
    @TableField("test_paper_id")
    private Integer testPaperId;

    /**
     * 考生id
     */
    @TableField("stu_id")
    private Integer stuId;
    /**
     * 场次id
     */
    @TableField("scene_id")
    private String sceneId;
    /**
     * 是否完成（0：交卷；1：未交卷）
     */
    private Integer status;
    /**
     * 考试时间（单位：秒）
     */
    private Integer duration;
    /**
     * 试卷得分
     */
    private Double score;
    /**
     * 第几次测试
     */
    private Integer times;
    /**
     * 考试进度
     */
    private BigDecimal rate;
    /**
     * 批改状态（0-已批改；1-未批改；2-不需要批改）
     */
    @TableField("correct_status")
    private Integer correctStatus;
    /**
     * 是否有报告
     */
    private Integer report;
    /**
     * 考试方式 0-练习 1-纸考 2-机房考 3-统考
     */
    @TableField("test_way")
    private Integer testWay;
    /**
     * 成绩来源；null或者1是系统内答题，2是系统内批量导入
     */
    @TableField("data_source")
    private Integer dataSource;
    /**
     * 交卷时间/自主批阅完成时间
     */
    @TableField("submit_time")
    private Date submitTime;
    /**
     * 创建人
     */
    @TableField("create_by")
    private Integer createBy;
    /**
     * 创建时间
     */
    @TableField("create_time")
    private Date createTime;
    /**
     * 修改人
     */
    @TableField("update_by")
    private Integer updateBy;
    /**
     * 修改时间
     */
    @TableField("update_time")
    private Date updateTime;
    /**
     * 删除标志（0：未删除；1：已删除）
     */
    private Integer isdelete;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getExamName() {
        return examName;
    }

    public void setExamName(String examName) {
        this.examName = examName;
    }

    public Integer getProductId() {
        return productId;
    }

    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    public Integer getTestPaperId() {
        return testPaperId;
    }

    public void setTestPaperId(Integer testPaperId) {
        this.testPaperId = testPaperId;
    }

    public Integer getStuId() {
        return stuId;
    }

    public void setStuId(Integer stuId) {
        this.stuId = stuId;
    }

    public String getSceneId() {
        return sceneId;
    }

    public void setSceneId(String sceneId) {
        this.sceneId = sceneId;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getDuration() {
        return duration;
    }

    public void setDuration(Integer duration) {
        this.duration = duration;
    }

    public Double getScore() {
        return score;
    }

    public void setScore(Double score) {
        this.score = score;
    }

    public Integer getTimes() {
        return times;
    }

    public void setTimes(Integer times) {
        this.times = times;
    }

    public Date getSubmitTime() {
        return submitTime;
    }

    public void setSubmitTime(Date submitTime) {
        this.submitTime = submitTime;
    }

    public BigDecimal getRate() {
        return rate;
    }

    public void setRate(BigDecimal rate) {
        this.rate = rate;
    }

    public Integer getCorrectStatus() {
        return correctStatus;
    }

    public void setCorrectStatus(Integer correctStatus) {
        this.correctStatus = correctStatus;
    }

    public Integer getReport() {
        return report;
    }

    public void setReport(Integer report) {
        this.report = report;
    }

    public Integer getTestWay() {
        return testWay;
    }

    public void setTestWay(Integer testWay) {
        this.testWay = testWay;
    }

    public Integer getDataSource() {
        return dataSource;
    }

    public void setDataSource(Integer dataSource) {
        this.dataSource = dataSource;
    }

    public Integer getCreateBy() {
        return createBy;
    }

    public void setCreateBy(Integer createBy) {
        this.createBy = createBy;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(Integer updateBy) {
        this.updateBy = updateBy;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getIsdelete() {
        return isdelete;
    }

    public void setIsdelete(Integer isdelete) {
        this.isdelete = isdelete;
    }

    @Override
    protected Serializable pkVal() {
        return this.id;
    }

    @Override
    public String toString() {
        return "ExamRecord{" +
                "id=" + id +
                ", examName='" + examName + '\'' +
                ", productId=" + productId +
                ", testPaperId=" + testPaperId +
                ", stuId=" + stuId +
                ", sceneId='" + sceneId + '\'' +
                ", status=" + status +
                ", duration=" + duration +
                ", score=" + score +
                ", times=" + times +
                ", rate=" + rate +
                ", correctStatus=" + correctStatus +
                ", report=" + report +
                ", testWay=" + testWay +
                ", dataSource=" + dataSource +
                ", submitTime=" + submitTime +
                ", createBy=" + createBy +
                ", createTime=" + createTime +
                ", updateBy=" + updateBy +
                ", updateTime=" + updateTime +
                ", isdelete=" + isdelete +
                '}';
    }
}
