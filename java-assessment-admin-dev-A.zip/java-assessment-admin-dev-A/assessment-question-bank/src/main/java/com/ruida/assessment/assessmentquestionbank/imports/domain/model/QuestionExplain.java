package com.ruida.assessment.assessmentquestionbank.imports.domain.model;

public class QuestionExplain {

	private String explain;

	public String getExplain() {
		return explain;
	}

	public void setExplain(String explain) {
		this.explain = explain;
	}
	
}
