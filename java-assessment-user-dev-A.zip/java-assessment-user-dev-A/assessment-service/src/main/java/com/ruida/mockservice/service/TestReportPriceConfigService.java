package com.ruida.mockservice.service;


import com.baomidou.mybatisplus.service.IService;
import com.ruida.mockdao.model.TTestReportPriceConfig;

/**
 * @author xumingqi
 * @date 2021/2/5 16:31
 */
public interface TestReportPriceConfigService extends IService<TTestReportPriceConfig> {
    /**
     * 根据type获取配置价格
     *
     * @param type 0-霍兰德测试价格设置 1-霍兰德测试报告价格设置 2-科目选考推荐科目组合报告价格设置 3-志愿填报报告价格设置
     * @return
     */
    TTestReportPriceConfig getConfigByType(Integer type);
}
