package com.ruida.assessment.assessmentquestionbank.model;

import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * <p>
 * IOS用户学币表
 * </p>
 *
 * @author Bhj
 * @since 2020-07-29
 */
@Data
@TableName("sys_user_study_coin")
public class TSysUserStudyCoin extends BaseColumn implements Serializable {


    private static final long serialVersionUID = 1578182189542604301L;
    /**
     * IOS用户学币主键ID
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;
    /**
     * 用户ID
     */
    private Integer userId;
    /**
     * 学币数量
     */
    private BigDecimal studyCoinNums;

}
