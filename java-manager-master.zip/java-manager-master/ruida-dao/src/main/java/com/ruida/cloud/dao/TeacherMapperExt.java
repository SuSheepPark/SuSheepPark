package com.ruida.cloud.dao;

import com.ruida.cloud.model.TeacherExt;
import net.sf.ehcache.search.aggregator.Count;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

public interface TeacherMapperExt {
    List<TeacherExt> listMasterTeachersByCourseId(Integer courseId);

    int countTeacherByExample(Map condition);

    List<TeacherExt> selectTeacherByExample(Map condition);

    List<TeacherExt> listTeacherByExample(Map condition);

    List<TeacherExt> listTeacherAllInfoById(Integer teacherId);

    List<TeacherExt> listTeacherInfoByName(Map condition);

    List<TeacherExt> getAssistantTeacherByCampus(Map param);

    @Select("SELECT\n" +
            "\tt.teacher_id AS teacherId,\n" +
            "\tt.pen_name as penName\n" +
            "FROM\n" +
            "\tt_teacher t\n" +
            "\tLEFT JOIN t_teacher_rel_info i ON i.teacher_id = t.teacher_id\n" +
            "\tleft join sys_user u on u.user_id = t.user_id\n" +
            "where FIND_IN_SET(#{periodId}, i.period_id)\n" +
            "and FIND_IN_SET(#{subjectId}, i.subject_id)\n" +
            "AND t.teacher_type = 0\n" +
            "AND t.isdelete = 0 and i.status = 1 and u.status = 1")
    List<Map<String,Object>> getPenNameList(Map condition);

    @Select("SELECT\n" +
            "\ta.teacher_id AS teacherId,\n" +
            "\ta.user_id AS userId,\n" +
            "\tb.user_name AS userName\n" +
            "FROM\n" +
            "\tt_teacher a\n" +
            "LEFT JOIN sys_user b ON a.user_id = b.user_id \n" +
            "WHERE\n" +
            "\ta.teacher_id = #{teacherId}\n" +
            "AND b.isdelete = 0\n" +
            "AND a.isdelete = 0\n" +
            "AND b.`status` = 1")
    List<Map<String,Object>> getUserNameList(Map condition);
    @Select("SELECT\n" +
           "count(0)\n" +
            "FROM\n" +
            "\tt_teacher a\n" +
            "LEFT JOIN sys_user b ON a.user_id = b.user_id \n" +
            "WHERE\n" +
            " b.user_name  = #{userName}\n" +
            "AND b.isdelete = 0\n" +
            "AND a.isdelete = 0\n" +
            "AND b.`status` = 1")
    Integer getCountByTeacher(Map condition);
}