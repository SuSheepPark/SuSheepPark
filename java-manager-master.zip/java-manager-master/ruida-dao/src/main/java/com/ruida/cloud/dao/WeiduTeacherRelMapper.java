package com.ruida.cloud.dao;

import com.ruida.cloud.model.WeiduTeacherRel;
import com.ruida.cloud.model.WeiduTeacherRelExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface WeiduTeacherRelMapper {
    long countByExample(WeiduTeacherRelExample example);

    int deleteByExample(WeiduTeacherRelExample example);

    int deleteByPrimaryKey(Integer rid);

    int insert(WeiduTeacherRel record);

    int insertSelective(WeiduTeacherRel record);

    List<WeiduTeacherRel> selectByExample(WeiduTeacherRelExample example);

    WeiduTeacherRel selectByPrimaryKey(Integer rid);

    int updateByExampleSelective(@Param("record") WeiduTeacherRel record, @Param("example") WeiduTeacherRelExample example);

    int updateByExample(@Param("record") WeiduTeacherRel record, @Param("example") WeiduTeacherRelExample example);

    int updateByPrimaryKeySelective(WeiduTeacherRel record);

    int updateByPrimaryKey(WeiduTeacherRel record);
}