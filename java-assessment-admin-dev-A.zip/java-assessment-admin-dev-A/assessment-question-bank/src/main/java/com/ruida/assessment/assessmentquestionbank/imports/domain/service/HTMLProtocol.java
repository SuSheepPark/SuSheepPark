package com.ruida.assessment.assessmentquestionbank.imports.domain.service;

import org.apache.commons.lang3.StringUtils;

import com.ruida.assessment.assessmentcommon.auth.context.BaseContextHandle;

public class HTMLProtocol {

	public static String parseText(String text, String fontFamily, Integer fontSize, String color, boolean isB,
			boolean isI, boolean isU, boolean isStrike) {
		StringBuffer sb = new StringBuffer();
		sb.append("<span style='");
		if (!StringUtils.isEmpty(fontFamily)) {
			sb.append("font-family:").append(fontFamily).append(";");
		}
		if (fontSize != null && fontSize != -1) {
			sb.append("font-size:").append(fontSize * 20 / 15).append("px;");
		}
		if (!StringUtils.isEmpty(color)) {
			sb.append("color:#").append(color).append(";");
		}
		if (isB) {
			sb.append("font-weight:bold;");
		}
		if (isI) {
			sb.append("font-style:italic;");
		}
		if (isU) {
			sb.append("text-decoration: underline;");
		}
		if (isStrike) {
			sb.append("text-decoration: line-through;");
		}
		sb.append("'>").append(text).append("</span>");
		return sb.toString();
	}

	public static String parseImg(String base64) {
		StringBuffer sb = new StringBuffer();
		String host = BaseContextHandle.getRemoteHost();
		sb.append("<img src='").append(host).append(base64).append("' style='vertical-align: middle'/>");
		return sb.toString();
	}

	public static String parseTable(String body, Integer width) {
		StringBuffer sb = new StringBuffer();
		sb.append("<table border='1' style='width:" + width + "px'>").append(body).append("</table>");
		return sb.toString();
	}

	public static String parseTableRow(String body) {
		StringBuffer sb = new StringBuffer();
		sb.append("<tr>").append(body).append("</tr>");
		return sb.toString();
	}

	public static String parseTableCell(String test) {
		StringBuffer sb = new StringBuffer();
		sb.append("<td>").append(test).append("</td>");
		return sb.toString();
	}
}
