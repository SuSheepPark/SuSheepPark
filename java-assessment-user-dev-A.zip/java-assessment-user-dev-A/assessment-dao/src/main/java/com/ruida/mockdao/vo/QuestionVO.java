package com.ruida.mockdao.vo;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.ruida.mockdao.model.ExamImage;
import com.ruida.mockdao.pojo.Choice;
import lombok.Data;

import java.util.List;

/**
 * @description: 试题VO
 * @author: chenjy
 * @create: 2020-07-13 11:52
 */
@Data
@JsonIgnoreProperties(value = {"stem", "answer", "examAnswer", "tempAnswer", "paperId"})
public class QuestionVO {

    /**
     * 试题id
     */
    private String questionId;

    /**
     * 题号
     */
    private String questionNo;

    /**
     * 考试记录id
     */
    @JsonInclude(value = JsonInclude.Include.NON_NULL)
    private Integer examRecordId;

    /**
     * 试卷id
     */
    @JsonInclude(value = JsonInclude.Include.NON_NULL)
    private Integer testPaperId;

    /**
     * 题干
     */
    private String questionTitle;

    /**
     * 题型id
     */
    private Integer questionTypeId;

    /**
     * 试题音频地址
     */
    private String questionAudioUrl;

    /**
     * 音频总的可播放次数
     */
    private Integer playCount;

    /**
     * 音频已经播放次数
     */
    private Integer audioPlayCount;

    /**
     * 题型名称
     */
    private String questionTypeName;

    /**
     * 是否标记
     */
    private Integer mark;

    /**
     * 试题在小节中的排序
     */
    private Integer sort;

    /**
     * 参考答案
     */
    private List<Choice> stdAnswer;

    /**
     * 用户答案
     */
    private List<Choice> userAnswer;

    /**
     * 题目序号（组合题使用）
     */
    private Integer questionSort;

    /**
     * 分析
     */
    @JsonInclude(value = JsonInclude.Include.NON_NULL)
    private String analysis;

    /**
     * 选项 string类型
     */
    private String stem;

    /**
     * 答案
     */
    private String answer;

    /**
     * 答案（中间过程使用）
     */
    private String tempAnswer;

    /**
     * 用户提交的答案
     */
    private String examAnswer;

    /**
     * 答案数量
     */
    private Integer answerNum;

    /**
     * 选项 集合类型
     */
    private List<Choice> option;

    /**
     * 难度
     */
    @JsonInclude(value = JsonInclude.Include.NON_NULL)
    private String difficulty;

    /**
     * 是否支持拍照上传
     */
    @JsonInclude(value = JsonInclude.Include.NON_NULL)
    private Integer photograph;

    /**
     * 试题分数
     */
    private Double score;

    /**
     * 得分
     */
    private Double point;

    /**
     * 试题预计时长
     */
    @JsonInclude(value = JsonInclude.Include.NON_NULL)
    private Double estimateDuration;

    /**
     * 试题状态
     */
    @JsonInclude(value = JsonInclude.Include.NON_NULL)
    private Integer status;

    @JsonIgnore
    private String imageId;

    private List<ExamImage> imageList;

    /**
     * 试题和知识点关联关系
     */
    @JsonInclude(value = JsonInclude.Include.NON_NULL)
    private List<QuestionKnowledgeRelVO> questionKnowledgeRelList;

    /**
     * 子题
     */
    private List<QuestionVO> child;
}
