package com.ruida.mockdao.dto;

import com.ruida.mockdao.model.ExamRecord;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * @description: 考试记录DTO
 * @author: chenjy
 * @create: 2021-01-19 11:04
 */
@Getter
@Setter
@ToString(callSuper = true)
public class ExamRecordDTO extends ExamRecord implements Comparable<ExamRecordDTO>{

    private Integer subjectId;

    /**
     * 数据来源（1-考试成绩，0-手动输入）
     */
    private Integer source;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ExamRecordDTO that = (ExamRecordDTO) o;

        return super.getId() != null ? super.getId().equals(that.getId()) : that.getId() == null;
    }

    @Override
    public int hashCode() {
        return super.getId() != null ? super.getId().hashCode() : 0;
    }

    @Override
    public int compareTo(ExamRecordDTO o) {
        return o.getCreateTime().compareTo(this.getCreateTime());
    }
}
