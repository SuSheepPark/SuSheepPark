package com.ruida.mockdao.vo;

import lombok.Data;

import java.util.List;

/**
 * Created by xumingqi on 2021/7/21 16:59
 */
@Data
public class SelfCheckNodeVO {

    /**
     * 小节id
     */
    private Integer nodeId;

    /**
     * 小节名称
     */
    private String nodeTitle;

    /**
     * 小节在试卷中顺序
     */
    private Integer nodeSort;

    /**
     * 小节分数
     */
    private Double nodeScore;

    /**
     * 试题集合
     */
    private List<SelfCheckQuestionVO> questionList;
}
