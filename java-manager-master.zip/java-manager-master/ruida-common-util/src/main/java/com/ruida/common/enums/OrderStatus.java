package com.ruida.common.enums;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Created by  on 2018/3/1.
 */
public enum OrderStatus {

    WAITING(0,"待支付"), PAID(1,"已支付"), CLOSED(2,"已关闭"),TBC(3,"待确认"), REFUNDING(4,"退款中"), REFUNDED(5,"已退款");

    public static final String SOURCE_KEY = "Bool";
    private Integer k;
    private String v;

    OrderStatus(Integer k, String v) {
        this.k = k;
        this.v = v;
    }

    public static Map<Integer,String> map = new LinkedHashMap<>(2);
    static
    {
        for(OrderStatus type : OrderStatus.values())
        {
            map.put(type.getK(),type.getV());
        }
    }

    public Integer getK() {
        return k;
    }

    public void setK(Integer k) {
        this.k = k;
    }

    public String getV() {
        return v;
    }

    public void setV(String v) {
        this.v = v;
    }

    /***
     * 根据k获取v的值
     * @param k
     * @return
     */
    public static String getvByk(int k) {
        OrderStatus[] list = OrderStatus.values();
        for (OrderStatus valid : list) {
            if (valid.getK() == k ) {
                return valid.getV();
            }
        }
        return "";
    }
}
