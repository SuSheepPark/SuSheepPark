package com.ruida.assessment.assessmentcommon.enums;

import java.util.Arrays;
import java.util.List;

/**
 * @description: 试卷性质
 * @author: kgz
 * @date: 2021/6/30
 */
public enum PaperUseTypeEnum {
    PRACTICE(1,"练习卷"),
    UNION(0,"联考卷"),
    UNION_ONE_ONE(2,"高中联考卷1分1赋"),
    UNION_THREE_ONE(3,"高中联考卷3分1赋"),
    UNION_REQUIRED_SUBJECT(4,"高中联考卷必考科目"),
    UNION_JUNIOR_SCHOOL(5,"初中联考卷"),
    ;


    private Integer K;
    private String V;

    PaperUseTypeEnum(Integer k, String v) {
        K = k;
        V = v;
    }

    /**
     * 联考报告子类型
     * @return
     */
    public static List<Integer> getUnionList() {
        return Arrays.asList(UNION_ONE_ONE.getK(),
                UNION_THREE_ONE.getK(),
                UNION_REQUIRED_SUBJECT.getK(),
                UNION_JUNIOR_SCHOOL.getK());
    }

    public Integer getK() {
        return K;
    }

    public void setK(Integer k) {
        K = k;
    }

    public String getV() {
        return V;
    }

    public void setV(String v) {
        V = v;
    }

    public static PaperUseTypeEnum getValueById(Integer K){
        for(PaperUseTypeEnum paperUseTypeEnum : PaperUseTypeEnum.values() ){
            if(paperUseTypeEnum.getK().equals(K)){
                return  paperUseTypeEnum;
            }
        }
        return null;
    }
}
