package com.ruida.cloud.dao;

import com.ruida.cloud.model.WeiduSemesterRel;
import com.ruida.cloud.model.WeiduSemesterRelExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface WeiduSemesterRelMapper {
    long countByExample(WeiduSemesterRelExample example);

    int deleteByExample(WeiduSemesterRelExample example);

    int deleteByPrimaryKey(Integer rid);

    int insert(WeiduSemesterRel record);

    int insertSelective(WeiduSemesterRel record);

    List<WeiduSemesterRel> selectByExample(WeiduSemesterRelExample example);

    WeiduSemesterRel selectByPrimaryKey(Integer rid);

    int updateByExampleSelective(@Param("record") WeiduSemesterRel record, @Param("example") WeiduSemesterRelExample example);

    int updateByExample(@Param("record") WeiduSemesterRel record, @Param("example") WeiduSemesterRelExample example);

    int updateByPrimaryKeySelective(WeiduSemesterRel record);

    int updateByPrimaryKey(WeiduSemesterRel record);
}