package com.ruida.assessment.assessmentquestionbank.aop;

import com.alibaba.fastjson.JSONObject;
import com.google.gson.JsonObject;
import com.ruida.assessment.assessmentcommon.exception.AuthException;
import com.ruida.assessment.assessmentcommon.exception.CoreException;
import com.ruida.assessment.assessmentcommon.result.BaseResult;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import javax.servlet.http.HttpServletRequest;

/**
 * @author mlzhang
 * 异常处理
 */
@ControllerAdvice
@Order(-1)
@Slf4j
public class GlobalExceptionHandler {

    /**
     * 参数校验
     * @param e
     * @return
     */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseBody
    @ResponseStatus(HttpStatus.BAD_GATEWAY)
    public BaseResult handleMethodArgumentNotValidException(MethodArgumentNotValidException e){
        BaseResult result = new BaseResult();
        BindingResult bindingResult = e.getBindingResult();

        StringBuffer sb = new StringBuffer("Invalid Request:\n");

        for(FieldError fieldError : bindingResult.getFieldErrors()){
            sb.append(fieldError.getDefaultMessage());
            sb.append("\n");
        }

        result.setCode(500);
        result.setMsg(sb.toString());
        return result;
    }

    /**
     * 拦截业务异常
     */
    @ExceptionHandler(CoreException.class)
    @ResponseStatus(HttpStatus.OK)
    @ResponseBody
    public BaseResult bussiness(CoreException e) {
        BaseResult result = new BaseResult();
        result.setSuccess(false);
        result.setCode(Integer.parseInt(e.getErrCode()));
        result.setMsg(e.getMessage());
        result.setDevMsg("");
        return result;
    }

    @ExceptionHandler(AuthException.class)
    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    @ResponseBody
    public BaseResult authBussiness(AuthException e) {
        BaseResult result = new BaseResult();
        result.setSuccess(false);
        result.setMsg(e.getMessage());
        result.setDevMsg(e);
        result.setCode(401);
        return result;
    }


    @ExceptionHandler(Exception.class)
    @ResponseStatus(HttpStatus.OK)
    @ResponseBody
    public BaseResult authBussiness(Exception e) {
        BaseResult result = new BaseResult();
        result.setSuccess(false);
        result.setMsg("操作失败");
        result.setCode(500);

        result.setDevMsg(e);
        log.error("ex:{}",e);
        return result;
    }


}
