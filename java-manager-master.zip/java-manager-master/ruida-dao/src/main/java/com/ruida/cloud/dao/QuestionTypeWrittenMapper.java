package com.ruida.cloud.dao;

import com.ruida.cloud.model.QuestionTypeWritten;
import com.ruida.cloud.model.QuestionTypeWrittenExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface QuestionTypeWrittenMapper {
    long countByExample(QuestionTypeWrittenExample example);

    int deleteByExample(QuestionTypeWrittenExample example);

    int deleteByPrimaryKey(Integer questionTypeWrittenId);

    int insert(QuestionTypeWritten record);

    int insertSelective(QuestionTypeWritten record);

    List<QuestionTypeWritten> selectByExample(QuestionTypeWrittenExample example);

    QuestionTypeWritten selectByPrimaryKey(Integer questionTypeWrittenId);

    int updateByExampleSelective(@Param("record") QuestionTypeWritten record, @Param("example") QuestionTypeWrittenExample example);

    int updateByExample(@Param("record") QuestionTypeWritten record, @Param("example") QuestionTypeWrittenExample example);

    int updateByPrimaryKeySelective(QuestionTypeWritten record);

    int updateByPrimaryKey(QuestionTypeWritten record);
}