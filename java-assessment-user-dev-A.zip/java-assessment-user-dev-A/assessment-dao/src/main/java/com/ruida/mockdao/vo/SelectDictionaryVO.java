package com.ruida.mockdao.vo;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.ruida.mockdao.model.*;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;
import java.util.Map;

/**
 * 首页商品列表
 */

@Data
@ApiModel(value="筛选条件列表")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SelectDictionaryVO {

//    @ApiModelProperty(value = "学段年级")
//    private List<TPeriod> period;
//
//    private String periodName = "学段年级";

    @ApiModelProperty(value = "考试类型")
    private List<TTestType> testType;

    private String testTypeName = "考试类型";

    @ApiModelProperty(value = "科目")
    private List<TSubject> subject;

    private String subjectName = "科目";

    @ApiModelProperty(value = "试卷类型")
    private List<TTestPaperType> testPaperType;

    private String testPaperTypeName = "试卷类型";

    @ApiModelProperty(value = "学段年级")
    private List<TStage> stage;

    private String stageName = "学段年级";

    @ApiModelProperty(value = "难度")
    private List<TQuestionDifficulty> questionDifficulty;

    private String questionDifficultyName = "难度";

    @ApiModelProperty(value = "教材版本")
    private List<TMaterialVersion> materialVersion;

    private String materialVersionName = "教材版本";


    @ApiModelProperty(value = "年份")
    private List<String> year;

    private String yearName = "年份";

    @ApiModelProperty(value = "考试方式")
    private List<ProductTestWayVO> productTestWay;

    private String productTestWayName = "考试方式";

    @ApiModelProperty(value = "年级信息")
    private List<TGrade> grade;

    @ApiModelProperty(value = "学段")
    private List<TPeriod> period;
}
