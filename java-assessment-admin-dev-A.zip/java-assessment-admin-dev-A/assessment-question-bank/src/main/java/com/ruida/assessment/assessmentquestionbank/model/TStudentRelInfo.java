package com.ruida.assessment.assessmentquestionbank.model;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import io.swagger.annotations.ApiModel;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @author wy
 * @description 学生关联信息数据库实体类
 * @date 2020/7/27
 */
@Data
@ApiModel(description = "学生关联信息")
@TableName("t_student_rel_info")
public class TStudentRelInfo  implements Serializable {


    private static final long serialVersionUID = -3384338590718808729L;

    @TableId
    private Integer rid;

    private Integer studentId;

    private Integer schoolId;

    private Integer periodId;

    private Integer gradeId;

    private Integer classId;

    private Integer createBy;

    private Date createTime;

    private Integer updateBy;

    private Date updateTime;
    private Date startTime;
    private Date endTime;
    private Integer status;

}
