package com.ruida.mockdao.dao;


import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.model.AppVersion;

/**
 * <p>
 * APP版本信息表 Mapper 接口
 * </p>
 *
 * @author Bhj
 * @since 2020-07-17
 */
public interface AppVersionMapper extends BaseMapper<AppVersion> {

}
