package com.ruida.mockcommon.enums;

/**
 * 登录权限隔离分类。用于区分不同的接口访问权限和不同的当前用户获取逻辑
 * @author mazhuang
 *
 */
public enum AuthCheckType {
	USER, // 用户登录
	STUDENT// 考生登录
}
