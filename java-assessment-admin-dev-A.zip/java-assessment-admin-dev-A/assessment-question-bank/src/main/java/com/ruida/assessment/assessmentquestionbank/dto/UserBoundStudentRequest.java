package com.ruida.assessment.assessmentquestionbank.dto;

import com.ruida.assessment.assessmentquestionbank.model.TSectionKnowledge;
import lombok.Data;

import java.util.List;

/**
 * @author wy
 * @description 用户绑定考生请求类
 * @date 2020/6/12
 */
@Data
public class UserBoundStudentRequest {

   private Integer userId;
   private String stuNo;
   private String stuName;

}
