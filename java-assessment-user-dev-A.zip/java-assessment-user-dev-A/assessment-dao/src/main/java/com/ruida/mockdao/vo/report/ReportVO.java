package com.ruida.mockdao.vo.report;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @description: 测评报告VO
 * @author: chenjy
 * @create: 2020-08-05 16:14
 */
@Data
public class ReportVO implements Serializable {

    /*是否需要购买报告(0:不需要；1：需要)*/
    private Integer needBuy;

    /*报告模板id*/
    private String reportId;

    /*报告名称*/
    private String reportName;

    /*考试id*/
    private Integer examRecordId;

    /*考试名称*/
    private String examName;

    /*商品id*/
    private Integer productId;

    /*学生姓名*/
    private String userName;

    /*科目id*/
    private Integer subjectId;

    /*试卷id*/
    private Integer testPaperId;

    /*科目*/
    private String subjectName;

    /*班级*/
    private String className;

    /*学校id*/
    private String schoolId;

    /*学校*/
    private String schoolName;

    /*得分*/
    private Double score;

    /*得分进步幅度*/
    private Double improvedScore;

    /*总分*/
    private Double totalScore;

    /*班级平均分*/
    private Double classAvg;

    /*班级最高分*/
    private Double classTop;

    /*班级排名*/
    private Integer classRank;

    /*班级人数*/
    private Integer classNum;

    /*学校平均分*/
    private Double schoolAvg;

    /*学校最高分*/
    private Double schoolTop;

    /*学校排名*/
    private Integer schoolRank;

    /*学校人数*/
    private Integer schoolNum;

    /*得分在学校的百分位*/
    private String scorePercentSchool;

    /*联考平均分*/
    private Double unionAvg;

    /*联考最高分*/
    private Double unionTop;

    /*联考排名*/
    private Integer unionRank;

    /*联考人数*/
    private Integer unionNum;

    /*得分在联考的百分位*/
    private String scorePercentUnion;

    /*9+1学校平均分*/
    private Double nineOneSchoolAvg;

    /*9+1学校最高分*/
    private Double nineOneSchoolTop;

    /*9+1学校排名*/
    private Integer nineOneSchoolRank;

    /*9+1学校人数*/
    private Integer nineOneSchoolNum;

    /*得分在9+1学校的百分位*/
    private String scorePercentNineOneSchool;

    /**
     * 预期可能达到的选考赋分或高考分数
     */
    private Integer calculateScore;

    /**
     * 成绩预期可能达到的高校层次
     */
    private String calculateCollegeLevel;

    /*试题知识点维度*/
    private List<ReportQuestionKnowledgeVO> reportQuestionKnowledgeList;

    /*题型维度*/
    private List<ReportQuestionTypeVO> reportQuestionTypeList;

    /*知识点维度*/
    private ReportStatKnowledgeVO reportKnowledge;

    /*考察目表维度*/
    private ReportTargetStatVO reportTarget;
}
