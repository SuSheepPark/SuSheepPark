package com.ruida.assessment.assessmentquestionbank.controller;

import com.ruida.assessment.assessmentcommon.result.ListResult;
import com.ruida.assessment.assessmentquestionbank.service.QuestionSourceService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * @description: 试题来源控制层
 * @author: kgz
 * @date: 2020/6/10
 */
@RequestMapping("/questionSource")
@RestController
@Api(value ="试题来源相关接口")
public class QuestionSourceController {

    @Resource
    private QuestionSourceService questionSourceService;

    @GetMapping("/getList")
    @ApiOperation(value = "获取考核目标下拉框列表", notes = "获取考核目标下拉框列表")
    public ListResult getList(){
        ListResult listResult = new ListResult();
        listResult.setContent(questionSourceService.getList());
        return listResult;
    }
}
