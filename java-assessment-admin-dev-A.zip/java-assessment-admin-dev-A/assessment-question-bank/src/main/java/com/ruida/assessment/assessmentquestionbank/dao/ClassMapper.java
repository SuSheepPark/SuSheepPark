package com.ruida.assessment.assessmentquestionbank.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.assessment.assessmentquestionbank.model.TClass;
import com.ruida.assessment.assessmentquestionbank.model.TClassGradeSchoolRel;
import com.ruida.assessment.assessmentquestionbank.vo.ClassVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * @author wy
 * @description 班级管理Mapper
 * @date 2020/6/12
 */
@Mapper
public interface ClassMapper extends BaseMapper<TClass> {

    /*
          查询学校下是否有待审核的班级
       */
    List<TClass> checkClassList(@Param("schoolId") Integer schoolId,@Param("status") Integer status);

    /*
    *   根据学校id和年级id精确查找班级
    * */
    List<ClassVo> queryClassListBySchoolIdAndGradeId(@Param("schoolId") Integer schoolId, @Param("gradeId") Integer gradeId);

    /*
     *   根据学校id和年级id精确查找班级(带班级人数)
     * */
    List<ClassVo> queryClassInfoBySchoolIdAndGradeId(@Param("schoolId") Integer schoolId, @Param("gradeId") Integer gradeId);

    /**
     * 根据班级名字查询学校年级中班级id
     * @param schoolId
     * @param gradeId
     * @param classId
     * @return
     */
    @Select("SELECT a.class_id FROM t_class_grade_school_rel a LEFT JOIN t_class b ON a.class_id = b.class_id\n" +
            "WHERE a.school_id = #{schoolId} AND a.grade_id = #{gradeId} AND b.class_name =  (SELECT class_name FROM t_class WHERE class_id = #{classId}) ")
    Integer getClassIdByClassName(@Param("schoolId") Integer schoolId,@Param("gradeId") Integer gradeId,@Param("classId") Integer classId);
}
