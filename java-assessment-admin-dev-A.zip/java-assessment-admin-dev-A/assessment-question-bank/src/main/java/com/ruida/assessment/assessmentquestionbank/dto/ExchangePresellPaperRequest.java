package com.ruida.assessment.assessmentquestionbank.dto;

import com.ruida.assessment.assessmentquestionbank.model.TPresellTestPaper;
import com.ruida.assessment.assessmentquestionbank.model.TTestPaperProductRel;
import com.ruida.assessment.assessmentquestionbank.vo.ExchangePresellPaperVo;
import lombok.Data;

import java.math.BigDecimal;
import java.util.LinkedList;
import java.util.List;

/**
 * @author wy
 * @description  替换预售试卷请求类
 * @date 2020/6/24
 */
@Data
public class ExchangePresellPaperRequest {

    private Integer productId;
    private List<ExchangePresellPaperVo> exchangePresellPaperLists;

}
