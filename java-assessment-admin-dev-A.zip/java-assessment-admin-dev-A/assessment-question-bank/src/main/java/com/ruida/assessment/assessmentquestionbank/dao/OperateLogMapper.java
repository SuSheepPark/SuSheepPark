package com.ruida.assessment.assessmentquestionbank.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.assessment.assessmentquestionbank.dto.OperateLogDTO;
import com.ruida.assessment.assessmentquestionbank.model.TOperateLog;
import com.ruida.assessment.assessmentquestionbank.vo.OperateLogVO;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * @description: 操作日志数据库层接口
 * @author: kgz
 * @date: 2020/8/12
 */
@Mapper
public interface OperateLogMapper extends BaseMapper<TOperateLog> {
    /**
     * 分页查询操作日志列表
     * @param operateLogDTO
     * @return
     */
    List<OperateLogVO> getOperateLogList(OperateLogDTO operateLogDTO);

    /**
     * 查询操作日志总数
     * @param operateLogDTO
     * @return
     */
    Integer getOperateLogCount(OperateLogDTO operateLogDTO);
}
