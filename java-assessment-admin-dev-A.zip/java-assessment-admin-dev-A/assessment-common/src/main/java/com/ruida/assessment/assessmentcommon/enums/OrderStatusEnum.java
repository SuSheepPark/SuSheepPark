package com.ruida.assessment.assessmentcommon.enums;

/**
 * @description: 订单支付状态
 * @author: kgz
 * @date: 2020/8/3
 */
public enum OrderStatusEnum {
    PAYING(0,"待支付"),
    PAYED(1,"已支付"),
    CANCEL(2,"已取消"),
    ;

    private Integer K;
    private String V;

    OrderStatusEnum(Integer k, String v) {
        K = k;
        V = v;
    }

    public Integer getK() {
        return K;
    }

    public void setK(Integer k) {
        K = k;
    }

    public String getV() {
        return V;
    }

    public void setV(String v) {
        V = v;
    }

    public static OrderStatusEnum getValueById(Integer K){
        if(K != null){
            for(OrderStatusEnum orderStatusEnum : OrderStatusEnum.values() ){
                if(orderStatusEnum.getK().equals(K)){
                    return  orderStatusEnum;
                }
            }
        }
        return null;
    }
}
