package com.ruida.mockservice.service;

import com.baomidou.mybatisplus.service.IService;
import com.ruida.mockdao.model.SysConfig;

/**
 * Created by xumingqi on 2021/5/11 11:40
 */
public interface ISysConfigService extends IService<SysConfig> {
    String getValueByKey(String key);

    Boolean updateValueByKey(String key, String value, Integer userId);
}
