package com.ruida.mockdao.dto;

import com.ruida.mockcommon.enums.ReportTypeEnum;
import com.ruida.mockcommon.result.Page;
import lombok.Data;

/**
 * @description: 测评报告DTO
 * @author: chenjy
 * @create: 2020-08-05 16:38
 */
@Data
public class ReportDTO {

    private ReportTypeEnum reportTypeEnum;

    /*用户id*/
    private Integer userId;

    /*商品id*/
    private Integer productId;

    /*9+1商品id*/
    private Integer nineOneProductId;

    /*考试方式，0-练习 1-纸考 2-机房考 3-统考 4-指定情况的9+1统考常模基准数据*/
    private Integer testWay;

    /*试卷id*/
    private Integer testPaperId;

    /*科目id*/
    private Integer subjectId;

    /*报告模板id*/
    private String reportId;

    /*报告id*/
    private Integer id;

    /*科目id*/
    private Boolean isNineOneStudent;

    /*商品试卷对应的常模id*/
    private Integer constRangeId;

    /*考试记录id*/
    private Integer examRecordId;

    /*考生id*/
    private Integer stuId;

    /*分页对象*/
    private Page page = new Page();
}
