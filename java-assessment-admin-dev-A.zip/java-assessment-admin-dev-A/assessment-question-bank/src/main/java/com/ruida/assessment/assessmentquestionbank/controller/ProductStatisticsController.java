package com.ruida.assessment.assessmentquestionbank.controller;

import com.ruida.assessment.assessmentcommon.result.PojoResult;
import com.ruida.assessment.assessmentquestionbank.annotaion.UserAuth;
import com.ruida.assessment.assessmentquestionbank.dto.BasicDataDTO;
import com.ruida.assessment.assessmentquestionbank.service.ProductStatisticsService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * @description: 商品数据统计
 * @author: kgz
 * @date: 2020/8/7
 */
@RequestMapping("/productStatistics")
@RestController
@Api(value ="用户数据统计相关接口")
public class ProductStatisticsController {

    @Resource
    private ProductStatisticsService productStatisticsService;

    @UserAuth
    @PostMapping("/basicData")
    @ApiOperation(value = "基础数据", notes = "基础数据")
    public PojoResult getProductBasicData(){
        PojoResult pojoResult = new PojoResult();
        pojoResult.setContent(productStatisticsService.getProductBasicData());
        return pojoResult;
    }

    @UserAuth
    @PostMapping("/rank")
    @ApiOperation(value = "支付榜TOP5之付费商品", notes = "支付榜TOP5之付费商品")
    @ApiImplicitParam(name = "basicDataDTO", value = "查询条件",
            required = true , dataType  = "BasicDataDTO",paramType = "body")
    public PojoResult getRankData(@RequestBody BasicDataDTO basicDataDTO){
        PojoResult pojoResult = new PojoResult();
        pojoResult.setContent(productStatisticsService.getRankData(basicDataDTO));
        return pojoResult;
    }

}
