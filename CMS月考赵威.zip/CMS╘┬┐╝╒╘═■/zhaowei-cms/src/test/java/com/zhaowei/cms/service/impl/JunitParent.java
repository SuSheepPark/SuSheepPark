/**   
 * Copyright © 2019 公司名. All rights reserved.
 * 
 * @Title: JunitParent.java 
 * @Prject: zhaowei-cms
 * @Package: com.zhaowei.cms.service.impl 
 * @Description: TODO
 * @author: zw   
 * @date: 2019年9月11日 上午10:41:26 
 * @version: V1.0   
 */
package com.zhaowei.cms.service.impl;

import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/** 
 * @ClassName: JunitParent 
 * @Description: TODO
 * @author: zw
 * @date: 2019年9月11日 上午10:41:26  
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:spring-beans.xml")
public class JunitParent {

}
