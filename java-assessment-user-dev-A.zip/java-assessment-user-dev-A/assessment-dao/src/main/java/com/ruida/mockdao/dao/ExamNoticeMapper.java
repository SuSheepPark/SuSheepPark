package com.ruida.mockdao.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.model.ExamNotice;
import com.ruida.mockdao.vo.TestPaperStructureVO;
import org.apache.ibatis.annotations.Param;

/**
 * <p>
 * 考试注意事项表 Mapper 接口
 * </p>
 *
 * @author chenjy
 * @since 2020-08-03
 */
public interface ExamNoticeMapper extends BaseMapper<ExamNotice> {

    /**
     * 获取测评前页信息
     * @param type
     * @param channel
     * @return
     */
    TestPaperStructureVO queryHomePage(@Param("type") Integer type,@Param("channel") Integer channel);
}
