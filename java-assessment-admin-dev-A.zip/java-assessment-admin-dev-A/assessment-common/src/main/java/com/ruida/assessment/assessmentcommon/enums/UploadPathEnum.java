package com.ruida.assessment.assessmentcommon.enums;


import com.ruida.assessment.assessmentcommon.exception.CoreException;

/**
 * @author szl
 * @description: 文件上传路径类型
 * @Date 2019/1/15
 * @verion 1.0
 */
public enum UploadPathEnum {

    COVER_PIC(0,"/product/coverPic"),//封面图片
    COVER_RICH(1,"/product/richText"),//富文本
    COURSE_WARE(2,"/COURSE_WARE"),//资源库
    ROTATION_CHART(3,"/banner"),//门户轮播
    NEW_INFO(4,"/NEW_INFO"),//门户首页富文本咨询富文本
    SCHOOL_LOGO(5,"/SCHOOL_LOGO"),//学校logo
    STU_EXCEL(6,"/STU_EXCEL"),//导入学生excl文件上传路径
    COURSE_INTRO(7,"/COURSE_INTRO"),//课程介绍哦啊
    COURSE_STORE(8,"/COURSE_STORE"),//课程收藏
    COURSE_CAMPUS(9,"/COURSE_CAMPUS"),//学生排版导入
    KNOWLEDGE(10,"/KNOWLEDGE"),//知识点上传
    ANDROID_APK(11,"/android"),//安卓apk
    QUESTION_AUDIO(12,"/question/audio"),//试题音频文件
    DETAIL_TABLE(13,"/DETAIL_TABLE"),
    SCENE_FILE(14,"/SCENE_FILE");//细目表;//细目表

    private final int code;
    private String address;

    private UploadPathEnum(int code,String address) {
        this.code = code;
        this.address=address;
    }


    public static UploadPathEnum forInt(int code) throws Exception {
        for (UploadPathEnum type : values()) {
            if (type.code == code) {
                return type;
            }
        }
        throw new CoreException(AppErrorEnum.E_10006);
    }


    public int getCode() {
        return code;
    }


	public String getAddress() {
		return address;
	}
}
