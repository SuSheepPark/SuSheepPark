package com.ruida.assessment.assessmentquestionbank.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.assessment.assessmentcommon.result.Page;
import com.ruida.assessment.assessmentquestionbank.model.TSubject;
import com.ruida.assessment.assessmentquestionbank.vo.BaseFieldVO;
import com.ruida.assessment.assessmentquestionbank.vo.SubjectVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * @description: 科目dao层接口
 * @author: kgz
 * @date: 2020/6/18
 */
@Mapper
public interface SubjectMapper extends BaseMapper<TSubject> {
    /**
     * 根据id列表获取科目名称(根据id的顺序排序)
     *
     * @param idList id列表
     * @return 科目名称列表
     */
    List<SubjectVO> getSubjectsByIdList(@Param("idList") List<String> idList);

    /**
     * 查询科目下拉框列表
     *
     * @param periodId
     * @return
     */
    List getSubjectList(@Param("periodId") Integer periodId, @Param("userId") Integer userId);

    /**
     * 获取科目下拉框所有选项列表
     *
     * @param periodId
     * @return
     */
    List getAllSubjectList(@Param("periodId") Integer periodId);

    /**
     * 分页查询列表
     *
     * @param page
     * @return
     */
    List<BaseFieldVO> queryList(@Param("page") Page page);

    /**
     * 列表数据条数
     *
     * @return
     */
    Integer countQuerList();

    /**
     * 根据科目查学段
     * @param subjectId
     * @return
     */
    BaseFieldVO getPeriodBySubject(@Param("subjectId")Integer subjectId);
    /**
     * 获取科目总分
     * @param periodId
     * @param subjectId
     * @return
     */
    @Select("SELECT a.sum_score FROM t_subject_sum_score a WHERE a.subject_id = #{subjectId} AND a.period_id = #{periodId}")
    Integer getSubjectScore(@Param("periodId") Integer periodId,@Param("subjectId") Integer subjectId);
}
