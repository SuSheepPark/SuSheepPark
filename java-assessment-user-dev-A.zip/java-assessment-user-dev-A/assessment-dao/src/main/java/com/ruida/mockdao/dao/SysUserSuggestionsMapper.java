package com.ruida.mockdao.dao;


import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.model.SysUserSuggestions;

/**
 * <p>
 * 用户意见反馈关联表 Mapper 接口
 * </p>
 *
 * @author Bhj
 * @since 2020-07-15
 */
public interface SysUserSuggestionsMapper extends BaseMapper<SysUserSuggestions> {

}
