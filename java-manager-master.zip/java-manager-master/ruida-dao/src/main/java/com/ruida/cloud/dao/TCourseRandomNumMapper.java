package com.ruida.cloud.dao;

import com.ruida.cloud.model.TCourseRandomNum;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Update;

public interface TCourseRandomNumMapper {
    @Insert("insert into  t_course_random_num (course_id,purchase_num,max_limit_num,isdelete)" +
            " values(#{courseId},#{purchaseNum},#{maxLimitNum},#{isdelete})")
    Integer insert(TCourseRandomNum courseRandomNum);
    @Update("update t_course_random_num set isdelete = 1 where random_num_id = #{id} ")
    Integer delete(Integer id);
}
