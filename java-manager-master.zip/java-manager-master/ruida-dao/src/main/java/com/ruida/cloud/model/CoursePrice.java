package com.ruida.cloud.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ruida.common.SystemConstant;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class CoursePrice implements Serializable {
    private Integer coursePriceId;

    private Integer courseId;

    private Integer subjectId;

    private Byte lessonNum;

    private BigDecimal underLinePrice;

    private BigDecimal underLineSalePrice;

    private BigDecimal onlinePrice;

    private BigDecimal onlineSalePrice;

    private Integer createBy;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm",timezone= SystemConstant.TIME_ZONE)
    private Date createTime;

    private Integer updateBy;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm",timezone= SystemConstant.TIME_ZONE)
    private Date updateTime;

    private Byte isdelete;

    //学科名
    private String subjectName;
    //价格  课包使用
    private BigDecimal price;
    //优惠价   课包使用
    private BigDecimal salePrice;

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public BigDecimal getSalePrice() {
        return salePrice;
    }

    public void setSalePrice(BigDecimal salePrice) {
        this.salePrice = salePrice;
    }

    public String getSubjectName() {
        return subjectName;
    }

    public void setSubjectName(String subjectName) {
        this.subjectName = subjectName;
    }

    private static final long serialVersionUID = 1L;

    public Integer getCoursePriceId() {
        return coursePriceId;
    }

    public void setCoursePriceId(Integer coursePriceId) {
        this.coursePriceId = coursePriceId;
    }

    public Integer getCourseId() {
        return courseId;
    }

    public void setCourseId(Integer courseId) {
        this.courseId = courseId;
    }

    public Integer getSubjectId() {
        return subjectId;
    }

    public void setSubjectId(Integer subjectId) {
        this.subjectId = subjectId;
    }

    public Byte getLessonNum() {
        return lessonNum;
    }

    public void setLessonNum(Byte lessonNum) {
        this.lessonNum = lessonNum;
    }

    public BigDecimal getUnderLinePrice() {
        return underLinePrice;
    }

    public void setUnderLinePrice(BigDecimal underLinePrice) {
        this.underLinePrice = underLinePrice;
    }

    public BigDecimal getUnderLineSalePrice() {
        return underLineSalePrice;
    }

    public void setUnderLineSalePrice(BigDecimal underLineSalePrice) {
        this.underLineSalePrice = underLineSalePrice;
    }

    public BigDecimal getOnlinePrice() {
        return onlinePrice;
    }

    public void setOnlinePrice(BigDecimal onlinePrice) {
        this.onlinePrice = onlinePrice;
    }

    public BigDecimal getOnlineSalePrice() {
        return onlineSalePrice;
    }

    public void setOnlineSalePrice(BigDecimal onlineSalePrice) {
        this.onlineSalePrice = onlineSalePrice;
    }

    public Integer getCreateBy() {
        return createBy;
    }

    public void setCreateBy(Integer createBy) {
        this.createBy = createBy;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(Integer updateBy) {
        this.updateBy = updateBy;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Byte getIsdelete() {
        return isdelete;
    }

    public void setIsdelete(Byte isdelete) {
        this.isdelete = isdelete;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", coursePriceId=").append(coursePriceId);
        sb.append(", courseId=").append(courseId);
        sb.append(", subjectId=").append(subjectId);
        sb.append(", lessonNum=").append(lessonNum);
        sb.append(", underLinePrice=").append(underLinePrice);
        sb.append(", underLineSalePrice=").append(underLineSalePrice);
        sb.append(", onlinePrice=").append(onlinePrice);
        sb.append(", onlineSalePrice=").append(onlineSalePrice);
        sb.append(", createBy=").append(createBy);
        sb.append(", createTime=").append(createTime);
        sb.append(", updateBy=").append(updateBy);
        sb.append(", updateTime=").append(updateTime);
        sb.append(", isdelete=").append(isdelete);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}