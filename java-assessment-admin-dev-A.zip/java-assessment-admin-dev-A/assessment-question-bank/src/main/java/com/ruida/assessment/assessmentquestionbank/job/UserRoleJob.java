package com.ruida.assessment.assessmentquestionbank.job;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.toolkit.CollectionUtils;
import com.ruida.assessment.assessmentquestionbank.model.SysUserRole;
import com.ruida.assessment.assessmentquestionbank.ruidacloudDao.SysUserRoleMapper;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

@Component
public class UserRoleJob {
    @Resource
    SysUserRoleMapper sysUserRoleMapper;
    /**
     * 每1小时执行一次删除过期的用户角色关联
     */
    @Scheduled(cron = "0 0 * * * ?")
    public void synFreshCookies(){
        EntityWrapper<SysUserRole> entityWrapper = new EntityWrapper<>();
        entityWrapper.le("deadline",new Date());
        List<SysUserRole> list = sysUserRoleMapper.selectList(entityWrapper);
        if (CollectionUtils.isNotEmpty(list)){
            list.forEach(a->{
                System.out.println("___删除id_"+a.getId());
                sysUserRoleMapper.deleteById(a.getId());
            });
        }
    }
}
