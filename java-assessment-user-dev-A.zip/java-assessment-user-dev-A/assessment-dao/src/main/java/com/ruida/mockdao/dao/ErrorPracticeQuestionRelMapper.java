package com.ruida.mockdao.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.model.ErrorPracticeQuestionRel;
import com.ruida.mockdao.vo.QuestionVO;
import com.ruida.mockdao.vo.error.QuestionTypeVO;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 错题练习和试题关联表 Mapper 接口
 * </p>
 *
 * @author chenjy
 * @since 2020-10-16
 */
public interface ErrorPracticeQuestionRelMapper extends BaseMapper<ErrorPracticeQuestionRel> {

    List<QuestionTypeVO> queryErrorPracticeDetail(Integer practiceId);

    List<QuestionVO> querySubQuestionInfo(@Param("parentId") String parentId);
}
