package com.ruida.cloud.dao;

import com.ruida.cloud.model.QuestionTypeWrittenExt;

import java.util.List;
import java.util.Map;

/**
 * @author taosh
 * @create 2019-06-19 13:26
 */
public interface QuestionTypeWrittenMapperExt {
    int countWrittenQuestionByExample(Map condition);

    List<QuestionTypeWrittenExt> selectWrittenQuestionByExample(Map condition);

    List<QuestionTypeWrittenExt> selectWrittenQuestionByInfo(Map condition);
}
