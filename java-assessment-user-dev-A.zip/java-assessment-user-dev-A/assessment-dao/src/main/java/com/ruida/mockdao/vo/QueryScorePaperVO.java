package com.ruida.mockdao.vo;

import lombok.Data;

/**
 * @description: 成绩查询试卷VO
 * @author: chenjy
 * @create: 2020-10-09 10:09
 */
@Data
public class QueryScorePaperVO {

    private String testPaperId;

    private String testPaperName;

    private String subjectName;
}
