package com.ruida.mockdao.model;

import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.FieldStrategy;
import com.baomidou.mybatisplus.enums.IdType;
import lombok.Data;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 学生信息表（包括学生和游客）
 * </p>
 *
 * @author Bhj
 * @since 2020-07-09
 */
@Data
@Accessors(chain = true)
@TableName("t_student")
public class Student extends Model<Student> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键ID
     */
    @TableId(value = "stu_id", type = IdType.AUTO)
    private Integer stuId;
    /**
     * 用户表ID（和用户表进行关联）
     */
    @TableField("user_id")
    private Integer userId;
    /**
     * 学生学号
     */
    @TableField("stu_no")
    private String stuNo;
    /**
     * 学生姓名
     */
    @TableField(value = "stu_name" ,strategy= FieldStrategy.IGNORED)
    private String stuName;
    /**
     *考生类型 0-默认用户生成的考生 1-导入的考生
     */
    @TableField(value = "stu_type")
    private Integer stuType;

    /**
     * 学生账号
     */
    @TableField("stu_account")
    private String stuAccount;
    /**
     * 学生年龄
     */
    private Integer age;
    /**
     * 学生性别
     */
    @TableField(strategy= FieldStrategy.IGNORED)
    private Integer sex;
    /**
     * 身份证号
     */
    @TableField("id_card")
    private String idCard;
    /**
     * 联系电话
     */
    private String telephone;
    /**
     * 渠道来源（保留字段）
     */
    @TableField("source_channel")
    private Integer sourceChannel;
    /**
     * 创建者ID
     */
    @TableField("create_by")
    private Integer createBy;
    /**
     * 创建时间
     */
    @TableField("create_time")
    private Date createTime;
    /**
     * 更新者ID
     */
    @TableField("update_by")
    private Integer updateBy;
    /**
     * 更新时间
     */
    @TableField("update_time")
    private Date updateTime;
    /**
     * 是否删除（0：未删除；1：删除）
     */
    private Integer isdelete;

    @Override
    protected Serializable pkVal() {
        return this.stuId;
    }
}
