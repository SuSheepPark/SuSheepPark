package com.ruida.assessment.assessmentquestionbank.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.assessment.assessmentcommon.result.Page;
import com.ruida.assessment.assessmentquestionbank.model.TQuestionSource;
import com.ruida.assessment.assessmentquestionbank.vo.BaseFieldVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @description: 试题来源dao层接口
 * @author: kgz
 * @date: 2020/6/10
 */
@Mapper
public interface QuestionSourceMapper extends BaseMapper<TQuestionSource> {

    /**
     * 分页查询列表
     * @param page
     * @return
     */
    List<BaseFieldVO> queryList(@Param("page") Page page,@Param("pName") String pName);

    /**
     * 列表数据条数
     * @return
     */
    Integer countQueryList(@Param("pName") String pName);

}
