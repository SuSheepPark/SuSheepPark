package com.ruida.cloud.dao;

import com.ruida.cloud.model.TStudentGroup;
import com.ruida.cloud.model.TStudentGroupExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface TStudentGroupMapper {
    int countByExample(TStudentGroupExample example);

    int deleteByExample(TStudentGroupExample example);

    int deleteByPrimaryKey(Integer studentGroupId);

    int insert(TStudentGroup record);

    int insertSelective(TStudentGroup record);

    List<TStudentGroup> selectByExample(TStudentGroupExample example);

    TStudentGroup selectByPrimaryKey(Integer studentGroupId);

    int updateByExampleSelective(@Param("record") TStudentGroup record, @Param("example") TStudentGroupExample example);

    int updateByExample(@Param("record") TStudentGroup record, @Param("example") TStudentGroupExample example);

    int updateByPrimaryKeySelective(TStudentGroup record);

    int updateByPrimaryKey(TStudentGroup record);
}