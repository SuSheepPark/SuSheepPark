package com.ruida.assessment.assessmentcommon.enums;

import lombok.Getter;

/**
 * Created by xumingqi on 2021/8/16 10:34
 */
@Getter
public enum RotationChartSourceEnum {
    WEB(0, "web端"),
    APP(1, "APP端"),
    MINI(2, "小程序端");

    private final Integer k;
    private final String v;

    RotationChartSourceEnum(Integer k, String v) {
        this.k = k;
        this.v = v;
    }

    public static String getValueById(Integer K) {
        for (RotationChartSourceEnum sourceEnum : RotationChartSourceEnum.values()) {
            if (sourceEnum.getK().equals(K)) {
                return sourceEnum.getV();
            }
        }
        return null;
    }
}
