package com.ruida.mockdao.vo;

import lombok.Data;

import java.util.Date;

@Data
public class SceneInfoVO {
    private String sceneName;
    private Date startTime;
    private Date endTime;
    private String subjectName;
    private String sceneId;
    private Integer status;
    private Integer allowLate;
    private Integer examRecordId;
    private Boolean hasSubmit;
    private String time;
    private Integer duration;
}
