package com.ruida.assessment.assessmentcommon.enums;

/**
 * @description: 下拉框类型
 * @author: kgz
 * @date: 2020/7/3
 */
public enum SelectOptionTypeEnum {
    QUESTION_TYPE("questionType","题型"),
    QUESTION_SOURCE("questionSource","试题来源"),
    QUESTION_ASSESSMENT_TARGET("questionAssessmentTarget","考核目标"),
    QUESTION_ASSESSMENT_TARGET_REL("questionAssessmentTargetRel","联动考核目标"),
    QUESTION_DIFFICULTY("questionDifficulty","难度等级"),
    QUESTION_PURPOSE("questionPurpose","试题用途"),
    SECURITY_LEVEL("securityLevel","安全等级"),
    TEST_PAPER_TYPE("testPaperType","试卷类型"),
    TEST_TYPE("testType","考试类型"),
    AREA("area","区域"),
    PERIOD("period","学段"),
    ;


    private String K;
    private String V;

    SelectOptionTypeEnum(String k, String v) {
        K = k;
        V = v;
    }

    public String getK() {
        return K;
    }

    public void setK(String k) {
        K = k;
    }

    public String getV() {
        return V;
    }

    public void setV(String v) {
        V = v;
    }


    public static SelectOptionTypeEnum getValueById(Integer K){
        for(SelectOptionTypeEnum selectOptionTypeEnum : SelectOptionTypeEnum.values() ){
            if(selectOptionTypeEnum.getK().equals(K)){
                return  selectOptionTypeEnum;
            }
        }
        return null;
    }

}
