package com.ruida.cloud.model;

import lombok.Data;

import java.util.Date;

/**
 * 双师课次
 */
@Data
public class DoubleCourseLesson {
    /**
     * 课次id
     */
    private Integer courseLessonId;

    /**
     * 对接百家云room_id
     */
    private String roomId;

    /**
     * 课程id
     */
    private String courseId;

    /**
     * 课次名称
     */
    private String courseLessonName;

    /**
     * 状态 
     */
    private Byte status;

    /**
     * 排序（用于上移、下移功能）
     */
    private Integer orderNum;

    /**
     * 课次开始日期
     */
    private Date startDate;

    /**
     * 课次结束日期
     */
    private Date endDate;

    /**
     * 课次开始时间
     */
    private String startTime;

    /**
     * 课次结束时间
     */
    private String endTime;

    /**
     * 是否删除
     */
    private int isdelete;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新时间
     */
    private Date updateTime;

    /**
     * 创建者ID（关联user_id）
     */
    private Integer createBy;

    /**
     * 更新者ID（关联user_id）
     */
    private Integer updateBy;

    /**
     * 学生参加码
     */
    private String studentEnterCode;

    /**
     * 老师参加码
     */
    private String teacherEnterCode;

    /**
     * 监课参加码
     */
    private String assistantEnterCode;

    private String statusName;

}