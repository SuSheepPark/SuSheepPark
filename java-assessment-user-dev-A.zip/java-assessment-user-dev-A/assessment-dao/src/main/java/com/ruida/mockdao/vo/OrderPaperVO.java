package com.ruida.mockdao.vo;

import lombok.Data;

@Data
public class OrderPaperVO {

    /**
     * 试卷ID
     */
    private Integer testPaperId;
    /**
     *试卷名称
     */
    private String testPaperName;
    /**
     * 年级
     */
    private String stageName;
    /**
     * 科目
     */
    private String subjectName;
    /**
     * 年份
     */
    private String year;
    /**
     * 版本
     */
    private String versionName;
}
