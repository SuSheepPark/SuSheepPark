package com.ruida.mockdao.dao;


import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.model.StudentRelInfo;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

/**
 * <p>
 * 学生关联信息表（学校、学段、年级、班级） Mapper 接口
 * </p>
 *
 * @author Bhj
 * @since 2020-07-09
 */
public interface StudentRelInfoMapper extends BaseMapper<StudentRelInfo> {
    /**
     * 获取有效用户id
     * @param userId
     * @return
     */
    @Select("SELECT\n" +
            "\tb.rid\n" +
            "FROM\n" +
            "\tt_student a\n" +
            "LEFT JOIN t_student_rel_info b ON a.stu_id = b.student_id\n" +
            "WHERE\n" +
            "\ta.user_id = #{userId} AND b.status = 1 and a.isdelete = 0 ")
    Integer getValidStuRidByUserid(@Param("userId") Integer userId);
}
