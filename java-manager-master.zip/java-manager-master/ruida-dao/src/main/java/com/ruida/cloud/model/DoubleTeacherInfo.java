package com.ruida.cloud.model;

import lombok.Data;

import java.util.Date;

@Data
public class DoubleTeacherInfo {

    /**
     * 第三方老师id
     */
    private Integer teacher_id;

    /*
    bjy 老师 id
     */
    private Integer id;

    private  String teacher_mobile;

    private String teacher_name;

    /*
    老师角色 1:老师 2：助教
     */
    private Integer role;

    private Integer status;

    private Date create_time;

    private Date update_time;

}