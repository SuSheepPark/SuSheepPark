package com.ruida.mockdao.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.model.TestPaperUserRel;
import org.apache.ibatis.annotations.Param;

/**
 * <p>
 * 用户考试关联表 Mapper 接口
 * </p>
 *
 * @author jinhu
 * @since 2020-07-17
 */
public interface TestPaperUserRelMapper extends BaseMapper<TestPaperUserRel> {

    TestPaperUserRel selectByPaperAndUserId(@Param("productId") Integer productId,
                                            @Param("testPaperId") Integer testPaperId,
                                            @Param("userId") String userId);

    Integer countUserTestPaperNum(Integer userId);
}
