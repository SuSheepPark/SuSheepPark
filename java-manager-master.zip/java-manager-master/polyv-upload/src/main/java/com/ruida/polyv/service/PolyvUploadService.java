package com.ruida.polyv.service;

import com.microsoft.schemas.office.visio.x2012.main.VisioDocumentDocument1;
import com.ruida.common.enums.AppErrorEnum;
import com.ruida.common.exception.CoreException;
import com.ruida.common.polyvparam.PolyvParam;
import com.ruida.common.vo.Result;
import com.ruida.polyv.sdk.PolyvSDKClient;
import com.ruida.polyv.sdk.Video;
import com.ruida.polyv.util.Progress;
import com.ruida.polyv.util.UploadListener;
import lombok.Data;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

/**
 * @author taosh
 * @create 2019-05-15 8:35
 */
@Service
public class PolyvUploadService {


    /**
     * 上传视频
     */
    public Result polyvUpload( String filePath, String title){
        Video video = null;
        String errorMsg;
        Map<String, Object> result = new HashMap<>(3);

        long start = System.currentTimeMillis();
        Runnable runnable = new UploadCallable(filePath, title);
        runnable.run();

        while(true){
            PolyvSDKClient client = PolyvSDKClient.getInstance();
            int percent = client.getPercent();

            System.out.println("percent:=========="+percent+"%");
            //result.put("vid", video.getVid());
            //result.put("image", video.getFirstImage());
            //result.put("video", video);
            //result.put("percent", percent);

            if(percent==100){
                video = ((UploadCallable) runnable).video;
                long end = System.currentTimeMillis();
                System.out.println("上传时间："+(end-start));
                break;
            }else {
                try {
                    Thread.sleep(1000);
                    break;
                } catch (Exception e) {
                    errorMsg = e.getMessage();
                    result.put("errorMsg", errorMsg);
                    throw new CoreException(AppErrorEnum.E_70001.getErrorCode(),AppErrorEnum.E_70001.getErrorMessage()+e.getMessage());
                }
            }
        }

        return new Result(0, "上传成功", video);
    }

    @Data
    class UploadCallable implements Runnable {
        Video video;
        String filePath;
        String title;

        public UploadCallable(String filePath, String title) {
            this.filePath = filePath;
            this.title = title;
        }

        @Override
        public void run() {
            Video v;
            try {
                PolyvSDKClient client = PolyvSDKClient.getInstance();
                v = client.upload( filePath, title, "tag", "desc", 0);

                video = v;
            } catch (Exception e) {
                throw new CoreException(AppErrorEnum.E_70001.getErrorCode(),AppErrorEnum.E_70001.getErrorMessage()+e.getMessage());
            }
        }
    }

    /**
     * 断点续传
     */
    public Result resumableUpload(String filePath, String title){
        PolyvSDKClient client = PolyvSDKClient.getInstance();

        String vid = "";
        try {
            vid = client.resumableUpload(filePath, title, "", "", 1,new Progress(){
                @Override
                public void run(long offset, long max) {
                    int percent = (int)(offset*100/max);
                    System.out.println(percent);
                }
            },new UploadListener() {
                @Override
                public void success(String body) {
                    System.out.println("上传成功："+body);
                }

                @Override
                public void fail(Exception ex) {
                    throw new CoreException(AppErrorEnum.E_70002.getErrorCode(),AppErrorEnum.E_70002.getErrorMessage()+ex.getLocalizedMessage());
                }
            });
        } catch (Exception e) {
            throw new CoreException(AppErrorEnum.E_70002.getErrorCode(),AppErrorEnum.E_70002.getErrorMessage()+e.getMessage());
        }

        return new Result(0, "续传成功", true);
    }


    /**
     * 根据vid获取对象
     */
    public Video getVideoByVid(String vid) {
        try {
            Video v = PolyvSDKClient.getInstance().getVideo(vid);
            return v;
        } catch (Exception e) {
            throw new CoreException(AppErrorEnum.E_70004.getErrorCode(),AppErrorEnum.E_70004.getErrorMessage()+e.getMessage());
        }
    }

    /**
     * 根据vid删除video
     */
    public boolean deleteVideo(String vid) {
        try {
            boolean result = PolyvSDKClient.getInstance().deleteVideo(vid);

            return result;
        } catch (Exception e) {
            throw new CoreException(AppErrorEnum.E_70003.getErrorCode(),AppErrorEnum.E_70003.getErrorMessage()+e.getMessage());
        }
    }
}
