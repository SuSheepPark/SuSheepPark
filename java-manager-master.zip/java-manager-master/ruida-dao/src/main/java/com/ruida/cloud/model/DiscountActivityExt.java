package com.ruida.cloud.model;

import lombok.Data;

import java.util.List;

/**
 * @author taosh
 * @create 2020-04-11 15:49
 */
@Data
public class DiscountActivityExt extends DiscountActivity {
    private Integer discountActivityId;

    /**
     * 优惠类型
     */
    private String discountTypeName;
    /**
     * 优惠方式
     */
    private String dicountMethod;


    /**
     * 适用范围
     */
    private String applicationScopeStr;

    /**
     * 课程ids
     */
    private String discountCourseIds;

    /**
     * 适用地区
     */
    private String discountZone;

    /**
     * 优惠时段
     */
    private String discountTime;

    /**
     * 优惠范围
     */
    private String discountScope;

    /**
     * 优惠力度
     */
    private String discountStrength;

    /**
     * 状态
     */
    private Byte status;

    /**
     * 折扣
     */
    private Integer discountNum;

    /**
     * 范围类型1（0—小于；1—小于等于；2—等于；3—大于；4—大于等于）
     */
    private Byte rangeTypeOne;

    /**
     *  1, 2, 3, 4
     */
    private Integer rangeNumOne;

    /**
     * 范围类型1（0—小于；1—小于等于；2—等于；3—大于；4—大于等于）
     */
    private Byte rangeTypeTwo;

    /**
     * 1, 2, 3, 4
     */
    private Integer rangeNumTwo;

    private String rangeTypeStr;

    /**
     * 优惠活动详情
     */
    private List<DiscountActivityItem> activityItemList;
}
