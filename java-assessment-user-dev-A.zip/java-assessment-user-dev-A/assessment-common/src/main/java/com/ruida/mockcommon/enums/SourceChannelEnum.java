package com.ruida.mockcommon.enums;

import java.util.Objects;

/**
 * @author chenjy
 * @date 2021/3/26
 */
public enum SourceChannelEnum {

    WEB(1,"web注册"),
    IOS(2,"Android注册"),
    ANDROID(3,"iOS注册"),
    IMPORT(4,"后台导入"),
    APPLET(5,"小程序");

    private final int code;

    private final String name;

    SourceChannelEnum(int code, String name) {
        this.code = code;
        this.name = name;
    }

    public int getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    public static String getNameByCode(Integer code){
        for (SourceChannelEnum item : SourceChannelEnum.values()){
            if(Objects.equals(code,item.getCode())){
                return item.getName();
            }
        }
        return "--";
    }
}
