package com.ruida.assessment.assessmentquestionbank.controller;

import com.ruida.assessment.assessmentcommon.result.ListResult;
import com.ruida.assessment.assessmentquestionbank.service.QuestionSourceService;
import com.ruida.assessment.assessmentquestionbank.service.QuestionStatusService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * @description: 试题状态控制层
 * @author: kgz
 * @date: 2020/6/30
 */
@RequestMapping("/questionStatus")
@RestController
@Api(value ="试题状态接口")
public class QuestionStatusController {

    @Resource
    private QuestionStatusService questionStatusService;

    @GetMapping("/getList")
    @ApiOperation(value = "获取考核目标下拉框列表", notes = "获取考核目标下拉框列表")
    public ListResult getList(){
        ListResult listResult = new ListResult();
        listResult.setContent(questionStatusService.getList());
        return listResult;
    }
}
