package com.ruida.mockcommon.auth;

public interface JwtConstants {
    String AUTH_HEADER = "Authorization";
    String SECRET = "defaultSecret";
    Long EXPIRATION = 604800L;
    String AUTH_PATH = "/student/login";

    String AUTH_RELEASE_PATH [] ={"/product/**","/msg/sendMobileCode" };
    String DEFAULT_TOKEN = "default";

    //创建token，小程序的source是5
    String MINI_PROGRAM_SOURCE = "5";

}
