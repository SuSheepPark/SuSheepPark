package com.ruida.mockcommon.constant;

import java.io.Serializable;
import java.util.regex.Pattern;

/**
 * 魔数处理 >> 待完善
 * @author szl
 */
public class Constants implements Serializable{

	private static final long serialVersionUID = 8978683067893231133L;

	public static final String       SLASH                   	= "/";
    public static final String       END_OF_STAGE              	= "EOF";
    public static final String       UNDERSCORE                 = "_";
    public static final String       DASH                       = "-";
    public static final String       EQUALMARK                	= "=";
    public static final String       ANDMARK                  	= "&";
    public static final String       SEMICOLON                 	= ";";
    public static final String       STAR                       = "*";
    public static final String       QUESTIONMARK              	= "?";
    public static final String       DOT                      	= ".";
    public static final String       AT                        	= "@";
    public static final String       POUND                     	= "#";
    public static final String       VERTICALLINE              	= "|";
    public static final String       PARALLEL                  	= "|";
    public static final String       ESCAPE_CHAR                = "\\";
    public static final String       REGEX_MATCH_PREFIX         = "^";
    public static final String       COMMA                      = ",";
    public static final String       APP_TYPE_ANDROID           = "Android";
    public static final String       APP_TYPE_IOS              	= "iOS";
    public static final String       SYSTEM_WINDOWS             = "WINDOWS";
    public static final String       SYSTEM_LINUX               = "LINUX";
    public static final String       NULL_STR                   = "NULL";

    public static final String       PRO_OS_NAME                = "os.name";

    public static final String       UTF8                       = "UTF-8";
    public static final String       ISO8859_1                  = "iso8859-1";
    public static final String       MSIE                  		= "MSIE";
    public static final String       MOZILLA                  	= "Mozilla";


    public static final String       TASK_ENV_DEV               = "dev";
    public static final String       TASK_ENV_PRERUN            = "prerun";
    public static final String       TASK_ENV_RUN               = "run";

    public static final Integer      ZERO						= 0;
    public static final Integer      ONE						= 1;
    public static final Integer      TWO						= 2;
    public static final Integer      THREE						= 3;
    public static final Integer      FOUR						= 4;
    public static final Integer      FIVE						= 5;
    public static final Integer      SIX						= 6;
    public static final Integer      SEVEN						= 7;
    public static final Integer      ZERO_INT			    	= 0;
    public static final Integer      ONE_INT			   	 	= 1;
    public static final Integer      DOWN_ONE_INT				= -1;

    public static final String       PERCENT                    ="%";
	public static final Pattern      SLASH_PATTEN               = Pattern.compile(SLASH);
	public static final Pattern      COMMA_PATTERN              = Pattern.compile(COMMA);

	public static final String       DOWNLOAD_PROTOCAL          = "application/x-download";
	public static final String       FILE_SUFFIX_ZIP            = "zip";

	public static final String 		 MONDAY 					= "星期一";
	public static final String 	     TUESDAY					= "星期二";
	public static final String       WEDNESDAY					= "星期三";
	public static final String       THURSDAY					= "星期四";
	public static final String       FRIDAY						= "星期五";
	public static final String       SATURDAY					= "星期六";
	public static final String       SUNDAY 					= "星期日";
	public static final String       TODAY 					    = "0";
	public static final String       TOMORROW 					= "1";

	public static final Integer 	 BAR_WIDTH                  = 300;
	public static final Integer 	 BAR_HEIGHT                 = 150;
	public static final Integer 	 QR_WIDTH                   = 500;

	//系统异常代码
	public static final String       SYSTEM_EXCEPTION_CODE      ="500";

	//第一次下单，再次下单
    public static final String FIRST = "first";
    public static final String SECOND = "second";
}
