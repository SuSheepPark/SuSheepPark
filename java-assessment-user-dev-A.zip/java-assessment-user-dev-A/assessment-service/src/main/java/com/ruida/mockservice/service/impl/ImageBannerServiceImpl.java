package com.ruida.mockservice.service.impl;


import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.ruida.mockdao.dao.ImageBannerMapper;
import com.ruida.mockdao.model.ImageBanner;
import com.ruida.mockservice.service.ImageBannerService;
import org.springframework.stereotype.Service;

/**
 * <p>
 * banner图 服务实现类
 * </p>
 *
 * @author xumingqi
 * @since 2021-01-07
 */
@Service
public class ImageBannerServiceImpl extends ServiceImpl<ImageBannerMapper, ImageBanner> implements ImageBannerService {

    @Override
    public String getImageBannerUrl(Integer type, Integer source) {
        EntityWrapper<ImageBanner> entityWrapper = new EntityWrapper<>();
        entityWrapper.eq("type", type);
        entityWrapper.eq("source", source);
        ImageBanner imageBanner = this.selectOne(entityWrapper);
        return imageBanner == null ? "" : imageBanner.getImagePath();
    }
}
