package com.ruida.cloud.dao;

import com.ruida.cloud.model.BaijiayunIntegral;
import com.ruida.cloud.model.BaijiayunIntegralExample;
import java.util.List;
import java.util.Map;

import com.ruida.cloud.vo.BaijiayunIntegralVO;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

public interface BaijiayunIntegralMapper {
    int countByExample(BaijiayunIntegralExample example);

    int deleteByExample(BaijiayunIntegralExample example);

    int deleteByPrimaryKey(Long id);

    int insert(BaijiayunIntegral record);

    int insertSelective(BaijiayunIntegral record);

    List<BaijiayunIntegral> selectByExample(BaijiayunIntegralExample example);

    BaijiayunIntegral selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") BaijiayunIntegral record, @Param("example") BaijiayunIntegralExample example);

    int updateByExample(@Param("record") BaijiayunIntegral record, @Param("example") BaijiayunIntegralExample example);

    int updateByPrimaryKeySelective(BaijiayunIntegral record);

    int updateByPrimaryKey(BaijiayunIntegral record);

    List<BaijiayunIntegralVO> selectInteralList(Map param);
    Integer selectInteralCount(Map param);
    @Select("SELECT a.zone_id ,a.zone_name FROM t_baijiayun_class a WHERE a.device_unique = #{deviceUnique}")
    Map<String,Object> getZoneIdByDecice(@Param("deviceUnique") String deviceUnique);

}