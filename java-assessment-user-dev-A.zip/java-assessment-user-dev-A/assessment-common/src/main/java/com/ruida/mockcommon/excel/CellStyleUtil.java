package com.ruida.mockcommon.excel;

import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;

/**
 * 单元格样式工具类
 * @author szl
 *
 */
public class CellStyleUtil {

	/**
	 * 设置border
	 * @param cellStyle
	 * @return
	 */
    public static CellStyle setBorder(CellStyle cellStyle){
        if(cellStyle == null){
            return null;
        }
        cellStyle.setBorderTop(CellStyle.BORDER_THIN);
        cellStyle.setTopBorderColor(IndexedColors.BLACK.getIndex());
        cellStyle.setBorderLeft(CellStyle.BORDER_THIN);
        cellStyle.setLeftBorderColor(IndexedColors.BLACK.getIndex());
        cellStyle.setBorderRight(CellStyle.BORDER_THIN);
        cellStyle.setRightBorderColor(IndexedColors.BLACK.getIndex());
        cellStyle.setBorderBottom(CellStyle.BORDER_THIN);
        cellStyle.setBottomBorderColor(IndexedColors.BLACK.getIndex());

        return cellStyle;
    }

    /**
     *
     * @param cellStyle
     * @param color
     * @return
     */
    public static CellStyle setForeGroundColor(CellStyle cellStyle,short color){
        if(cellStyle == null){
            return null;
        }
        cellStyle.setFillForegroundColor(color);
        cellStyle.setFillPattern(CellStyle.SOLID_FOREGROUND);
        return cellStyle;
    }

    /**
     * 设置字体
     * @param cellStyle
     * @param font
     * @return
     */
    public static CellStyle setFont(CellStyle cellStyle,Font font){
        if(cellStyle == null || font == null){
            return cellStyle;
        }
        font.setBoldweight(Font.BOLDWEIGHT_BOLD);
        font.setColor(IndexedColors.BLACK.getIndex());
        font.setFontName("宋体");
        font.setFontHeightInPoints((short)11);
        cellStyle.setFont(font);
        return cellStyle;
    }

    /**
     * 设置对齐
     * @param cellStyle
     * @param align
     * @param vertical
     * @return
     */
    public static CellStyle setAlign(CellStyle cellStyle,short align,short vertical){
        if(cellStyle == null){
            return null;
        }
        cellStyle.setAlignment(align);
        cellStyle.setVerticalAlignment(vertical);
        return cellStyle;
    }


}
