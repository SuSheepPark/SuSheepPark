package com.ruida.mockdao.vo.report;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;

/**
 * @description:
 * @author: kgz
 * @date: 2021/9/6
 */
@ApiModel(description = "场次信息")
public class SceneVO implements Serializable {

    @ApiModelProperty(value = "实施计划id", name = "planId")
    private String sceneId;

    @ApiModelProperty(value = "实施计划名称", name = "planName")
    private String subjectName;

    public String getSceneId() {
        return sceneId;
    }

    public void setSceneId(String sceneId) {
        this.sceneId = sceneId;
    }

    public String getSubjectName() {
        return subjectName;
    }

    public void setSubjectName(String subjectName) {
        this.subjectName = subjectName;
    }

    @Override
    public String toString() {
        return "SceneVO{" +
                "sceneId='" + sceneId + '\'' +
                ", subjectName='" + subjectName + '\'' +
                '}';
    }
}
