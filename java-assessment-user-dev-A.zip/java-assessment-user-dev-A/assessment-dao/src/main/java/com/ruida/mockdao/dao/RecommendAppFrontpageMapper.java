package com.ruida.mockdao.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.dto.ProductQueryRequest;
import com.ruida.mockdao.model.RecommendAppFrontpage;
import com.ruida.mockdao.vo.ProductNewVO;
import com.ruida.mockdao.vo.ProductVO;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author jinhu
 * @since 2020-08-07
 */
public interface RecommendAppFrontpageMapper extends BaseMapper<RecommendAppFrontpage> {


    /**
     * 查询推荐商品列表
     * @param req
     * @return
     */
	@Deprecated
    List<ProductVO> queryRecommendProductList(@Param("vo") ProductQueryRequest req);
    /**
     * 查询推荐商品列表
     * @param req
     * @return
     */
    @Deprecated
    List<ProductNewVO> queryRecommendProductListNew(@Param("vo") ProductQueryRequest req);
    /**
     * 查询推荐商品列表.因版本更新,上面两个接口以及使用的数据表作废，推荐表变成t_recommend_excellent_test_paper
     * @param req
     * @return
     */
    List<ProductNewVO> queryRecommendProductList3();

}
