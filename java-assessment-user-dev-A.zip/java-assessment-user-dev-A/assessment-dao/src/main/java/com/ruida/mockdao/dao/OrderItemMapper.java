package com.ruida.mockdao.dao;


import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.model.OrderItem;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 订单详情表 Mapper 接口
 * </p>
 *
 * @author Bhj
 * @since 2020-07-23
 */
public interface OrderItemMapper extends BaseMapper<OrderItem> {
    List<OrderItem> getUserPayedOrderItemList(@Param("userId") Integer userId, @Param("productId") Integer productId);
}
