package com.ruida.cloud.dao;

import com.ruida.cloud.model.WeiduStageRel;
import com.ruida.cloud.model.WeiduStageRelExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface WeiduStageRelMapper {
    long countByExample(WeiduStageRelExample example);

    int deleteByExample(WeiduStageRelExample example);

    int deleteByPrimaryKey(Integer rid);

    int insert(WeiduStageRel record);

    int insertSelective(WeiduStageRel record);

    List<WeiduStageRel> selectByExample(WeiduStageRelExample example);

    WeiduStageRel selectByPrimaryKey(Integer rid);

    int updateByExampleSelective(@Param("record") WeiduStageRel record, @Param("example") WeiduStageRelExample example);

    int updateByExample(@Param("record") WeiduStageRel record, @Param("example") WeiduStageRelExample example);

    int updateByPrimaryKeySelective(WeiduStageRel record);

    int updateByPrimaryKey(WeiduStageRel record);
}