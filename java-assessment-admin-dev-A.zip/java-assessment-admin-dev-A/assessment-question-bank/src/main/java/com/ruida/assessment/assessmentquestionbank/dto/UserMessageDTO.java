package com.ruida.assessment.assessmentquestionbank.dto;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.List;
import java.util.Map;

/**
 * @description: 消息DTO
 * @author: kgz
 * @date: 2020/7/27
 */
@ApiModel(description = "消息")
public class UserMessageDTO {

    @ApiModelProperty(value = "用户消息id", name = "userMessageId")
    private List<Integer> userMessageId;

    @ApiModelProperty(value = "消息模板编号", name = "messageTplId")
    private Integer messageTplNo;

    @ApiModelProperty(value = "消息模板变量", name = "messageParams")
    private String messageParams;

    @ApiModelProperty(value = "学员id集合", name = "studentId")
    private List<Integer> studentIds;

    @ApiModelProperty(value = "消息内容", name = "messageParams")
    private String content;

    @ApiModelProperty(value = "通知范围", name = "range")
    private String noticeRange;

    @ApiModelProperty(value = "消息目的，学员或商品", name = "purpose")
    private Integer purpose;

    @ApiModelProperty(value = "通知目标id，学员或商品id", name = "purposeId")
    private String purposeId;

    @ApiModelProperty(value = "商品id集合", name = "productId")
    private List<Integer> productIds;

    public String getMessageParams() {
        return messageParams;
    }

    public void setMessageParams(String messageParams) {
        this.messageParams = messageParams;
    }

    public List<Integer> getStudentIds() {
        return studentIds;
    }

    public void setStudentIds(List<Integer> studentIds) {
        this.studentIds = studentIds;
    }

    public List<Integer> getProductIds() {
        return productIds;
    }

    public void setProductIds(List<Integer> productIds) {
        this.productIds = productIds;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getNoticeRange() {
        return noticeRange;
    }

    public void setNoticeRange(String noticeRange) {
        this.noticeRange = noticeRange;
    }

    public Integer getPurpose() {
        return purpose;
    }

    public void setPurpose(Integer purpose) {
        this.purpose = purpose;
    }

    public Integer getMessageTplNo() {
        return messageTplNo;
    }

    public void setMessageTplNo(Integer messageTplNo) {
        this.messageTplNo = messageTplNo;
    }

    public List<Integer> getUserMessageId() {
        return userMessageId;
    }

    public void setUserMessageId(List<Integer> userMessageId) {
        this.userMessageId = userMessageId;
    }

    public String getPurposeId() {
        return purposeId;
    }

    public void setPurposeId(String purposeId) {
        this.purposeId = purposeId;
    }

    @Override
    public String toString() {
        return "UserMessageDTO{" +
                "userMessageId=" + userMessageId +
                ", messageTplNo=" + messageTplNo +
                ", messageParams='" + messageParams + '\'' +
                ", studentIds=" + studentIds +
                ", content='" + content + '\'' +
                ", noticeRange='" + noticeRange + '\'' +
                ", purpose=" + purpose +
                ", purposeId='" + purposeId + '\'' +
                ", productIds=" + productIds +
                '}';
    }
}
