package com.ruida.assessment.assessmentquestionbank.controller;

import com.ruida.assessment.assessmentcommon.result.ListResult;
import com.ruida.assessment.assessmentquestionbank.service.QuestionDifficultyService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

/**
 * @description: 难度等级控制类
 * @author: kgz
 * @date: 2020/6/9
 */
@RequestMapping("/questionDifficulty")
@RestController
@Api(value ="难度等级相关接口")
public class QuestionDifficultyController {

    @Resource
    private QuestionDifficultyService questionDifficultyService;

    @GetMapping("/getList")
    @ApiOperation(value = "获取难度等级下拉框列表", notes = "获取难度等级下拉框列表")
    public ListResult getList(){
        ListResult listResult = new ListResult();
        listResult.setContent(questionDifficultyService.getList());
        return listResult;
    }
}
