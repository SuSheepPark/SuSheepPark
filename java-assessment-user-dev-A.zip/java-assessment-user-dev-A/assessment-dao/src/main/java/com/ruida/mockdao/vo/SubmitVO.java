package com.ruida.mockdao.vo;

import lombok.Data;

/**
 * @description: 提交试卷VO
 * @author: chenjy
 * @create: 2020-07-17 11:57
 */
@Data
public class SubmitVO {

    /**
     * 状态(0：正常，1：含有未批的试题)
     */
    private Integer status;

    /**
     * 试卷id
     */
    private Integer testPaperId;

    /**
     * 商品id
     */
    private Integer productId;

    /**
     * 是否有报告(0：没有；1：有)
     */
    private Integer report;

    /**
     * 得分
     */
    private Double point;

    /**
     * 试卷满分
     */
    private Double fullScore;

    /**
     * 考试记录id
     */
    private Integer examRecordId;

    /**
     * 剩余考试次数
     */
    private Integer surplusExamTime;

    /**
     * 考试次数
     */
    private Integer times;

}
