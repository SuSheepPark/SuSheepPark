package com.ruida.assessment.assessmentquestionbank.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.assessment.assessmentquestionbank.model.TPeriodSubjectRelation;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface TPeriodSubjectRelationMapper extends BaseMapper<TPeriodSubjectRelation> {

    List<TPeriodSubjectRelation> selectListBySubjectId(Integer subjectId);

}
