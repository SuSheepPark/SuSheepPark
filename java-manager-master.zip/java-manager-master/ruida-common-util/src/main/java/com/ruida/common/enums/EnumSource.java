package com.ruida.common.enums;

import java.util.HashMap;
import java.util.Map;

public class EnumSource
{
	public static final String PREFIX = "Enum_";

	private static Map<String,Map<String,String>> map = new HashMap<String, Map<String,String>>();

	static
	{
		init();
	}

	public static void init()
	{
		map.put(PREFIX + BoolType.SOURCE_KEY, BoolType.map);
		map.put(PREFIX + BoolStatusType.SOURCE_KEY, BoolStatusType.map);
		map.put(PREFIX + MenuType.SOURCE_KEY, MenuType.map);
		map.put(PREFIX + OperateType.SOURCE_KEY, OperateType.map);
		map.put(PREFIX + orderType.SOURCE_KEY, orderType.map);
		map.put(PREFIX + CourseValidTimeEnum.SOURCE_KEY, CourseValidTimeEnum.map);
	}

	public static void register(String key, Map<String,String> enumMap)
	{
		map.put(PREFIX + key, enumMap);
	}


	public static Map<String,String> getMap(String key)
	{
		return map.get(key);
	}

	public static String parse(String dicCode,String dicKey)
	{
		Map<String,String> tmp = map.get(dicCode);
		if( tmp == null)
		{
			return "";
		}

		if(tmp.get(dicKey) == null)
		{
			return "";
		}
		return tmp.get(dicKey);
	}
}
