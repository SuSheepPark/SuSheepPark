package com.ruida.cloud.model;

import com.ruida.common.util.ValidateMT;

/**
 * @author admin
 * @description: ${TODO}
 * @Date 2019/1/24
 * @verion 1.0
 */
public class CourseVideoExt extends  CourseVideo {
    /**创建者*/
    private String createByName;
    /**课程名字*/
    private String courseName;
    /**课次名字*/
    private String lessonName;
    /**课程发布状态*/
    private Byte ispublish;
    /**课次id*/
    private Integer courseLessonId;
    /**文件大小单位M*/
    private  String resouceSize;

    public String getResouceSize() {
        if (ValidateMT.isNotNull(getSourceFilesize())){
         Integer tem =   getSourceFilesize();
      return String.format("%.4f",tem/(float)1024/(float)1024/(float)1024);
        }else {
            return "0.0000";
        }

    }

    public void setResouceSize(String resouceSize) {
        this.resouceSize = resouceSize;
    }

    @Override
    public Integer getCourseLessonId() {
        return courseLessonId;
    }

    @Override
    public void setCourseLessonId(Integer courseLessonId) {
        this.courseLessonId = courseLessonId;
    }

    public Byte getIspublish() {
        return ispublish;
    }

    public void setIspublish(Byte ispublish) {
        this.ispublish = ispublish;
    }

    public String getCreateByName() {
        return createByName;
    }

    public void setCreateByName(String createByName) {
        this.createByName = createByName;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public String getLessonName() {
        return lessonName;
    }

    public void setLessonName(String lessonName) {
        this.lessonName = lessonName;
    }
}
