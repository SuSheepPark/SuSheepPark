package com.ruida.assessment.assessmentquestionbank.dao;

import com.ruida.assessment.assessmentquestionbank.model.TUserPeriodSubject;
import com.baomidou.mybatisplus.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author szl
 * @since 2020-07-23
 */
public interface TUserPeriodSubjectMapper extends BaseMapper<TUserPeriodSubject> {

}
