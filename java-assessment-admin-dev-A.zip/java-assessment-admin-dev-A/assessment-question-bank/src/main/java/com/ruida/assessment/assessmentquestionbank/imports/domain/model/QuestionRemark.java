package com.ruida.assessment.assessmentquestionbank.imports.domain.model;

public class QuestionRemark {

	private String remark;

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}
}
