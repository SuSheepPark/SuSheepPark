package com.ruida.cloud.dao;

import com.ruida.cloud.model.DoubleCourseExt;
import com.ruida.cloud.model.DoubleCourseLesson;
import com.ruida.cloud.model.DoubleCourseLessonExample;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

public interface DoubleCourseLessonMapper {
    int countByExample(DoubleCourseLessonExample example);

    int deleteByExample(DoubleCourseLessonExample example);

    int deleteByPrimaryKey(Integer courseLessonId);

    int insert(DoubleCourseLesson record);

    int insertSelective(DoubleCourseLesson record);

    List<DoubleCourseLesson> selectByExample(DoubleCourseLessonExample example);

    DoubleCourseLesson selectByPrimaryKey(Integer courseLessonId);

    int updateByExampleSelective(@Param("record") DoubleCourseLesson record, @Param("example") DoubleCourseLessonExample example);

    int updateByExample(@Param("record") DoubleCourseLesson record, @Param("example") DoubleCourseLessonExample example);

    int updateByPrimaryKeySelective(DoubleCourseLesson record);

    int updateByPrimaryKey(DoubleCourseLesson record);

    List<DoubleCourseLesson> selectByCourseId(Map param);

    Integer selectNumByCourseId(String courseId);

    List<DoubleCourseLesson> getcourseLessonAfter(@Param("orderNum") Integer orderNum,@Param("courseId") String courseId);

    List<DoubleCourseLesson> selectCourseLessonOrderByOrderNum(@Param("courseId") String courseId);

    List<DoubleCourseLesson> listByCourseId(Integer courseId);
}