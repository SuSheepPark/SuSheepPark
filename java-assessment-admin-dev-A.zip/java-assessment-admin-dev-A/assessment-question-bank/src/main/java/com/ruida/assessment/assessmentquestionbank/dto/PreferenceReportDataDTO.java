package com.ruida.assessment.assessmentquestionbank.dto;

import lombok.Data;

/**
 * 志愿填报报告统计DTO
 */
@Data
public class PreferenceReportDataDTO extends QueryBaseDTO {
    private Integer source;//来源（0-pc 1-iOS 2-Android）
    private Integer payed;//支付状态（0-未支付 1-已支付）
    private String searchWord;//搜索关键词
    private String startTime;//第一次查看报告时间开始
    private String endTime;//第一次查看报告时间结束
    private Integer showAll;//展示所有
    private String telephone;//手机号

}
