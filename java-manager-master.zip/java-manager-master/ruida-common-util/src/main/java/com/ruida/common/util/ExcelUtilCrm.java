/**
 * Author: John
 */

package com.ruida.common.util;

import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.*;

import java.util.Iterator;

/**
 *
 * @author ivan.zhou
 *
 */
public class ExcelUtilCrm {
  public static final short EXCEL_FORMAT_CODE_OF_TEXT = 49; // Is excel cell text type
  public static final short EXCEL_FORMAT_CODE_OF_GENERAL = 0; // Is excel cell general type
  public static final short EXCEL_FORMAT_CODE_OF_DATE = 14; // Is excel cell date type
  // excel styles
  public static final short FGColor_Null = 9;
  public static final short FGColor_Green = 42;
  public static final short FGColor_Yellow = 13;
  public static final short FGColor_LightYellow = 43;
  public static final short FGColor_Red = 10;
  public static final short BGColor = 64;
  public static final short FPattern = 1;
  public static final short BorderBottom = 1;
  public static final short BorderTop = 1;
  public static final short BorderLeft = 1;
  public static final short BorderRight = 1;
  public static final short LeftBorderColor = 64;
  public static final short RightBorderColor = 64;
  public static final short TopBorderColor = 64;
  public static final short BottomBorderColor = 64;
  public static final short Alignment = 1;
  public static final short Vertical = 2;

  public static final int MAX_ROW_ID_IN_SHEET = 65535;
  public static final short MAX_COLUMN_ID_IN_SHEET = 255;

  public static final short COMMON_DEFAULT_ROW_HEIGHT = 350;
  public static final short COMMON_DEFAULT_COLUMN_WIDTH = 25;
  public static final short COMMON_MAX_COLUMN_WIDTH = 25600;

  /**
   * Set cell style
   */
  public static void setCellStyle(XSSFCell cell, XSSFCellStyle style) {
    cell.setCellStyle(style);
  }

  /**
   * Get a cell by row object and column id , if exist return else create a new cell
   */
  public static XSSFCell getCell(XSSFRow row, short i) {
    if (row == null || i < 0 || i > MAX_COLUMN_ID_IN_SHEET) {
      return null;
    }

    XSSFCell cell = row.getCell((int) i);
    if (cell == null) {
      cell = row.createCell((int) i);
    }

    return cell;
  }

  public static Cell getCell(Row row, short i) {
    if (row == null || i < 0 || i > MAX_COLUMN_ID_IN_SHEET) {
      return null;
    }

    Cell cell = row.getCell((int) i);
    if (cell == null) {
      cell = row.createCell((int) i);
    }

    return cell;
  }

  /**
   * Get a cell by sheet object, row id and column id, if exist return else create a new cell
   */
  public static XSSFCell getCell(XSSFSheet sheet, int rowId, short columnId) {
    if (sheet == null || rowId < 0 || columnId < 0) {
      return null;
    }

    XSSFRow row = sheet.getRow(rowId);
    if (row == null) {
      row = sheet.createRow(rowId);
    }

    XSSFCell cell = row.getCell((int) columnId);
    if (cell == null) {
      cell = row.createCell((int) columnId);
    }

    return cell;
  }

  /**
   * Get a row by sheet object and row id, if exist return else create a new row
   */
  public static XSSFRow getRow(XSSFSheet sheet, int rowId) {
    if (sheet == null || rowId < 0 || rowId > MAX_ROW_ID_IN_SHEET) {
      return null;
    }

    XSSFRow row = sheet.getRow(rowId);
    if (row == null) {
      row = sheet.createRow(rowId);
    }

    return row;
  }

  public static Row getRow(Sheet sheet, int rowId) {
    if (sheet == null || rowId < 0 || rowId > MAX_ROW_ID_IN_SHEET) {
      return null;
    }

    Row row = sheet.getRow(rowId);
    if (row == null) {
      row = sheet.createRow(rowId);
    }

    return row;
  }

  /**
   * Get a sheet by workbook object and sheet id, if exist return else create a new sheet
   */
  public static XSSFSheet getSheet(XSSFWorkbook workbook, int sheetId) {
    if (workbook == null || sheetId < 0) {
      return null;
    }

    XSSFSheet sheet = workbook.getSheetAt(sheetId);
    if (sheet == null) {
      sheet = workbook.createSheet("sheet" + sheetId);
    }

    return sheet;
  }

  /**
   * Copy row
   */
  public static void copyRow(XSSFWorkbook wb, XSSFRow fromRow, XSSFRow toRow, boolean copyValueFlag) {
    for (Iterator<Cell> cellIt = fromRow.cellIterator(); cellIt.hasNext();) {
      XSSFCell tmpCell = (XSSFCell) cellIt.next();
      XSSFCell newCell = toRow.createCell(tmpCell.getColumnIndex());
      copyCell(wb, tmpCell, newCell, copyValueFlag);
    }
  }

  /**
   * Copy cell
   */
  public static void copyCell(XSSFWorkbook wb, XSSFCell srcCell, XSSFCell distCell, boolean copyValueFlag) {
    distCell.setCellStyle(srcCell.getCellStyle());
    if (srcCell.getCellComment() != null) {
      distCell.setCellComment(srcCell.getCellComment());
    }
    int srcCellType = srcCell.getCellType();
    distCell.setCellType(srcCellType);
    if (copyValueFlag) {
      if (srcCellType == XSSFCell.CELL_TYPE_NUMERIC) {
        if (HSSFDateUtil.isCellDateFormatted(srcCell)) {
          distCell.setCellValue(srcCell.getDateCellValue());
        } else {
          distCell.setCellValue(srcCell.getNumericCellValue());
        }
      } else if (srcCellType == XSSFCell.CELL_TYPE_STRING) {
        distCell.setCellValue(srcCell.getRichStringCellValue());
      } else if (srcCellType == XSSFCell.CELL_TYPE_BLANK) {
        // nothing21
      } else if (srcCellType == XSSFCell.CELL_TYPE_BOOLEAN) {
        distCell.setCellValue(srcCell.getBooleanCellValue());
      } else if (srcCellType == XSSFCell.CELL_TYPE_ERROR) {
        distCell.setCellErrorValue(srcCell.getErrorCellValue());
      } else if (srcCellType == XSSFCell.CELL_TYPE_FORMULA) {
        distCell.setCellFormula(srcCell.getCellFormula());
      } else { // nothing29
      }
    }
  }
}
