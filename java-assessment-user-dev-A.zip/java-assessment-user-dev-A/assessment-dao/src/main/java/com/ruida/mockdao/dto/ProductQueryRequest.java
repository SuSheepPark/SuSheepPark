package com.ruida.mockdao.dto;

import com.ruida.mockcommon.result.Page;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

/**
 * @author wy
 * @description 查询商品请求类
 * @date 2020/6/24
 */
@Data
public class ProductQueryRequest {


    private static final String PRODUCT_NO_REGEX = "^P(\\d{12})$";

    /**
     * 用户id
     */
    private String userId;

    /*
       商品id
     */
    private Integer productId;

    /*
       排除商品id
     */
    private Integer productIdExclude;

    /*
      排除商品ids
    */
    private List<Integer> productIdsExclude;

    private String productName;
    private String productNo;
    /**
     * 商品类型 (0-试卷 1-套卷 2-职业兴趣问卷)
     */
    private List<Integer> productTypeList;
    /*
     模糊查询字段  商品号或商品名称
     */
    private String searchWord;

    /*
   商品类型  是否是套卷 0-试卷 1-套卷
     */
    private Integer iscompose;

    /*
        商品状态 0-已下架 1-已上架
     */
    private Integer status;

    /*
    价格区间 起
     */
    private BigDecimal priceStart;

    /*
    价格区间 止
     */
    private BigDecimal priceEnd;

    /*
    学段id
     */
    private Integer periodId;
    /*
  学段ids
   */
    private String periodIds;

    /*
    科目id
     */
    private Integer subjectId;
    private String subjectName;

    /*
    教材版本id
     */
    private Integer versionId;
    /*
   教材版本ids
    */
    private String versionIds;

    /*
    年级id
     */
    private Integer gradeId;
    /*
    年级ids
   */
    private String gradeIds;


    /**
     * 学段年级
     */
    private Integer stageId;

    private List<Integer> stageIdList;

    /*
    年份
     */
    private String year;

    /*
   考试类型
    */
    private Integer testType;

    /*
    试卷类型
     */
    private Integer testPaperType;

    @ApiModelProperty(value = "商品考试方式 0-练习 3-统考")
    private String productTestWay;

    @ApiModelProperty(value = "商品考试方式")
    private String[] productTestWayArray;

    @ApiModelProperty(value = "商品状态")
    private Integer[] productStatusArray;

    @ApiModelProperty(value = "是否隐藏 0-显示 1-隐藏")
    private Integer ishide = 0;

    /*
    难度
     */
    private Integer difficulty;

    /*
        排序字段  默认创建时间排序倒序     */
    private String  orderStr = "product_no";

    /*
        排序方式 0-降序 1-升序 默认创建时间排序倒序
     */
    private Integer orderType = 0;

    private Page page;

    /*分页*/
    private Integer start;
    private Integer size;


    private Integer isdelete = 0;


    private void setSearchWord(String searchWord){
        //正则匹配 查询的是商品号还是商品名称
        if(searchWord.matches(PRODUCT_NO_REGEX)){
            this.setProductNo(searchWord);
        }else{
            this.setProductName(searchWord);
        }
        this.searchWord = searchWord;
    }
}
