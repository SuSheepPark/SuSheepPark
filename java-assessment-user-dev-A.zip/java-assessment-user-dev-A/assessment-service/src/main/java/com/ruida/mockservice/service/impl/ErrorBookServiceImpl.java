package com.ruida.mockservice.service.impl;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.ruida.mockcommon.auth.context.BaseContextHandle;
import com.ruida.mockcommon.auth.pojo.JWTInfo;
import com.ruida.mockcommon.entity.TreeNode;
import com.ruida.mockcommon.enums.AppErrorEnum;
import com.ruida.mockcommon.enums.QuestionTypeEnum;
import com.ruida.mockcommon.exception.CoreException;
import com.ruida.mockcommon.result.Page;
import com.ruida.mockcommon.util.TreeHelper;
import com.ruida.mockdao.dao.ErrorBookMapper;
import com.ruida.mockdao.dao.ExamDetailMapper;
import com.ruida.mockdao.dao.KnowledgeMapper;
import com.ruida.mockdao.dao.QuestionLibraryMapper;
import com.ruida.mockdao.dto.ErrorBookDTO;
import com.ruida.mockdao.dto.PersonCenterDTO;
import com.ruida.mockdao.model.ErrorBook;
import com.ruida.mockdao.model.Knowledge;
import com.ruida.mockdao.vo.QuestionVO;
import com.ruida.mockservice.service.ErrorBookService;
import com.ruida.mockservice.service.TestPaperService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.text.DecimalFormat;
import java.util.*;

/**
 * <p>
 * 错题表 服务实现类
 * </p>
 *
 * @author chenjy
 * @since 2020-07-16
 */
@Service
@Slf4j
public class ErrorBookServiceImpl extends ServiceImpl<ErrorBookMapper, ErrorBook> implements ErrorBookService {

    @Resource
    ErrorBookMapper errorBookMapper;
    @Resource
    QuestionLibraryMapper questionLibraryMapper;
    @Resource
    ExamDetailMapper examDetailMapper;
    @Resource
    KnowledgeMapper knowledgeMapper;
    @Resource
    TestPaperService testPaperService;

    @Override
    public boolean addErrorBook(ErrorBookDTO errorBookDTO) {

        // 检查错题本中是否存在当前试题，如果存在则更新，否则插入
        EntityWrapper<ErrorBook> wrapper = new EntityWrapper<>();
        wrapper.andNew().eq("question_id", errorBookDTO.getQuestionId())
                .eq("create_by", errorBookDTO.getCreateBy())
                .eq("isdelete", 0);
        List<ErrorBook> list = errorBookMapper.selectList(wrapper);

        ErrorBook errorBook;

        if (!CollectionUtils.isEmpty(list)) {
            errorBook = list.get(0);
            errorBook.setExamRecordId(errorBookDTO.getExamRecordId());
            errorBook.setTestPaperId(errorBookDTO.getTestPaperId());
            errorBook.setUpdateBy(errorBookDTO.getCreateBy());
            errorBook.setUpdateTime(new Date());
            return errorBookMapper.updateById(errorBook) > 0;
        } else {
            errorBook = new ErrorBook();
            errorBook.setExamRecordId(errorBookDTO.getExamRecordId());
            errorBook.setTestPaperId(errorBookDTO.getTestPaperId());
            errorBook.setQuestionId(errorBookDTO.getQuestionId());
            errorBook.setQuestionTypeId(errorBookDTO.getQuestionTypeId());
            errorBook.setPeriodId(errorBookDTO.getPeriodId());
            errorBook.setSubjectId(errorBookDTO.getSubjectId());
            errorBook.setCreateBy(errorBookDTO.getCreateBy());
            errorBook.setCreateTime(new Date());
            return errorBookMapper.insert(errorBook) > 0;
        }
    }

    @Override
    public boolean removeQuestionFromErrorBook(String questionId, Integer userId) {
        EntityWrapper<ErrorBook> wrapper = new EntityWrapper<>();
        wrapper.andNew().eq("question_id", questionId).eq("create_by", userId);
        return errorBookMapper.delete(wrapper) > 0;
    }

    @Override
    public Map<String, Object> queryErrorQuestionGroupSubject(Integer periodId) {
        Map<String, Object> map = new HashMap<>();
        JWTInfo jwt = BaseContextHandle.getJWTInfo();
        if (jwt == null) {
            throw new CoreException(AppErrorEnum.E_10018);
        }
        map.put("subjectList", errorBookMapper.queryErrorQuestionGroupSubject(Integer.valueOf(jwt.getUserId()), periodId));
        map.putAll(getQuestionStatsInfo(Integer.valueOf(jwt.getUserId())));
        return map;
    }

    @Override
    public Page<QuestionVO> queryErrorBookList(Page page, PersonCenterDTO req) {
        JWTInfo jwt = BaseContextHandle.getJWTInfo();
        if (jwt == null) {
            throw new CoreException(AppErrorEnum.E_10018);
        }
        req.setUserId(Integer.valueOf(jwt.getUserId()));
        req.setPageStart(page.getOffset());
        req.setPageSize(page.getPageSize());

        List<QuestionVO> list = errorBookMapper.selectErrorQuestionList(req);

        list.stream().filter(x -> x.getQuestionTypeId().equals(QuestionTypeEnum.CQT.getK()))
                .forEach(y -> y.setChild(questionLibraryMapper.selectChildQuestion(null, y.getQuestionId(), null)));

        list.forEach(x -> testPaperService.handleQuestionVO(x));

        page.setResult(list);
        page.setCurrentPage(page.getCurrentPage());
        page.setNowTime(new Date());
        page.setPageSize(page.getPageSize());
        page.setTotalCount(errorBookMapper.countErrorQuestion(req));
        return page;
    }

    @Override
    public Map<String, Object> getQuestionStatsInfo(Integer userId) {
        Map<String, Object> map = new HashMap<>();
        int totalNum = examDetailMapper.countTotalNum(userId);
        int errorNum = errorBookMapper.countErrorNum(userId);

        // 设置保留位数
        DecimalFormat df = new DecimalFormat("0.00");

        String errorRatio;
        String correctRatio;

        if (totalNum == 0) {
            errorRatio = "0";
            correctRatio = "0";
        } else {
            errorRatio = df.format((float) errorNum / totalNum);
            correctRatio = df.format((float) (totalNum - errorNum) / totalNum);
        }

        map.put("totalNum", totalNum);
        map.put("errorNum", errorNum);
        map.put("errorRatio", errorRatio);
        map.put("correctRatio", correctRatio);
        return map;
    }

    @Override
    public boolean deleteErrorQuestion(String questionIds) {
        JWTInfo jwt = BaseContextHandle.getJWTInfo();
        if (jwt == null) {
            throw new CoreException(AppErrorEnum.E_10018);
        }
        return errorBookMapper.deleteErrorQuestion(Arrays.asList(questionIds.split(",")), Integer.valueOf(jwt.getUserId())) > 0;
    }

    @Override
    public List<TreeNode> makeKnowledgeTree(Integer subjectId) {
        String userId = BaseContextHandle.getUserID();
        List<Integer> lastKnowledgeList = errorBookMapper.queryKnowledge(userId, subjectId);

        Set<TreeNode> knowledgeList = new HashSet<>();
        lastKnowledgeList.forEach(knowledgeId -> {
            Knowledge k = knowledgeMapper.selectById(knowledgeId);
            TreeNode c = new TreeNode();
            c.setId(k.getKnowledgeId());
            c.setName(k.getKnowledgeName());
            c.setPid(k.getPid());
            knowledgeList.add(c);

            while (c.getPid() != 0) {
                Knowledge parent = knowledgeMapper.selectById(c.getPid());
                TreeNode p = new TreeNode();
                p.setId(parent.getKnowledgeId());
                p.setPid(parent.getPid());
                p.setName(parent.getKnowledgeName());
                knowledgeList.add(p);
                c = p;
            }
        });


        List<TreeNode> knowledgeTree = (List<TreeNode>) TreeHelper.buildTree(new ArrayList<>(knowledgeList));
        knowledgeTree.forEach(x -> {
            if (x.getChildren() != null) {
                x.getChildren().forEach(y -> y.setChildren(new ArrayList<>()));
            }
        });

        return knowledgeTree;
    }
}
