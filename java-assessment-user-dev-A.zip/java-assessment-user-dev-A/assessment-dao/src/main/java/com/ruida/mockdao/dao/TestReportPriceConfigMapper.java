package com.ruida.mockdao.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.model.TTestReportPriceConfig;

/**
 * @author xumingqi
 * @date 2021/2/5 16:31
 */
public interface TestReportPriceConfigMapper extends BaseMapper<TTestReportPriceConfig> {
}
