package com.ruida.common.enums;

public enum ButtonType {
    SURE(0, "确认"),
    SENDBACK(1, "退回"),
    BACKOUT(2, "撤销"),
    ;
    private Integer val;
    private String name;

    ButtonType(Integer val, String name) {
        this.val = val;
        this.name = name;
    }

    public Integer getVal() {
        return val;
    }

    public String getName() {
        return name;
    }

    public static String getNameByType(Integer val) {
        for (ButtonType buttonType : ButtonType.values()) {
            if (val.equals(buttonType.getVal())) {
                return buttonType.getName();
            }
        }
        return null;
    }
}
