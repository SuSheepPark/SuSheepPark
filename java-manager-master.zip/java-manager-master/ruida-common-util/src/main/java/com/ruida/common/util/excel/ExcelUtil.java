package com.ruida.common.util.excel;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.hssf.usermodel.*;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.util.List;
import java.util.Map;

/**
 * @author taosh
 * @create 2019-10-21 9:42
 */
public class ExcelUtil {
//    /**
//     * 导出Excel
//     * @param sheetName sheet名称
//     * @param title 标题
//     * @param exportDataList 内容
//     * @param wb HSSFWorkbook对象
//     * @return
//     */
//    public static HSSFWorkbook getHSSFWorkbook(
//            String sheetName, String []title, List<Map<String, Object>> exportDataList, HSSFWorkbook wb){

//        // 第一步，创建一个HSSFWorkbook，对应一个Excel文件
//        if(wb == null){
//            wb = new HSSFWorkbook();
//        }
//
//        // 第二步，在workbook中添加一个sheet,对应Excel文件中的sheet
//        HSSFSheet sheet = wb.createSheet(sheetName);
//
//        // 第三步，在sheet中添加表头第0行,注意老版本poi对Excel的行数列数有限制
//        HSSFRow row = sheet.createRow(0);
//
//        // 第四步，创建单元格，并设置值表头 设置表头居中
//        HSSFCellStyle style = wb.createCellStyle();
//        // 创建一个居中格式
//        style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
//
//        //声明列对象
//        HSSFCell cell = null;
//
//        //创建标题
//        for(int i=0;i<title.length;i++){
//            cell = row.createCell(i);
//            cell.setCellValue(title[i]);
//            cell.setCellStyle(style);
//        }
//
//        //创建内容
//        for(int i=0;i<exportDataList.size();i++){
//            row = sheet.createRow(i + 1);
//            for(int j=0;j<exportDataList.get(i).size();j++){
//                //将内容按顺序赋给对应的列对象
//                row.createCell(j).setCellValue(exportDataList.get(i).get(j+"")+"");
//            }
//        }
//        return wb;
//    }

    public static HSSFWorkbook generateListContent(List<Map<String, Object>> mapList, String[] titles, String sheetName) {
        return generateListContent(mapList, sheetName, titles, null);
    }

    public static HSSFWorkbook generateListContent(List<Map<String, Object>> mapList, String sheetName, String[] titles, HSSFWorkbook hssfWorkbook) {

        if (hssfWorkbook == null) {
            hssfWorkbook = new HSSFWorkbook();
        }
        if (mapList == null) {
            return hssfWorkbook;
        }

        /**
         * 创建一个sheet
         */
        HSSFSheet sheet = hssfWorkbook.createSheet(sheetName);
        sheet.setColumnWidth(0, 20 * 256);
        sheet.setDefaultColumnWidth(20);
        sheet.setDefaultRowHeightInPoints(20);
        /**
         * 创建单元格，并设置值表头 设置表头居中
         */
        HSSFCellStyle style = hssfWorkbook.createCellStyle();
        /**
         * 创建一个居中格式
         */
        style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
        HSSFFont font = hssfWorkbook.createFont();
        //font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
        style.setFont(font);

        /**
         * row样式1
         */
        HSSFCellStyle style1 = hssfWorkbook.createCellStyle();
        HSSFFont font1 = hssfWorkbook.createFont();
        font1.setBoldweight(HSSFFont.BOLDWEIGHT_NORMAL);
        /**
         * row样式2
         */
        HSSFCellStyle style2 = hssfWorkbook.createCellStyle();
        style2.setAlignment(HSSFCellStyle.ALIGN_CENTER);
        HSSFFont font2 = hssfWorkbook.createFont();
        font2.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
        style2.setFont(font2);

        HSSFRow row = sheet.createRow(0);
        HSSFCell cell;
        int cellIndex;
        int rowIndex = 1;

        //创建标题
        for(int i = 0; i < titles.length; i++){
            cell = row.createCell(i);
            cell.setCellValue(titles[i]);
            cell.setCellStyle(style);
            cell.setCellStyle(style2);
        }

        for (Map<String, Object> mapRow : mapList) {
            row = sheet.createRow(rowIndex);
            cellIndex = 0;

            for (Map.Entry<String, Object> entry : mapRow.entrySet()) {
                if (cellIndex >= titles.length){
                    break;
                }
                cell = row.createCell(cellIndex);
                cell.setCellValue(entry.getValue() + "");
                cell.setCellStyle(style1);
                cellIndex++;
            }
            rowIndex++;
        }

        return hssfWorkbook;
    }

    public static void write(HSSFWorkbook hssfWorkbook, String name, HttpServletResponse response) throws IOException {
        write(hssfWorkbook, name, null, response);
    }

    /**
     * 输出流
     *
     * @param hssfWorkbook
     * @param name
     * @param suffix       后缀
     * @param response
     * @throws IOException
     */
    public static void write(HSSFWorkbook hssfWorkbook, String name, String suffix, HttpServletResponse response) throws IOException {

        if (suffix == null) {
            suffix = "xls";
        }

        OutputStream os = null;
        //将excel的数据写入文件
        response.setContentType("octets/stream");
        String excelName = name;//文件名字
        //转码防止乱码
        try {
            response.addHeader("Content-Disposition", "attachment;filename=" + new String(excelName.getBytes("UTF-8"), "UTF-8") + "." + suffix);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }

        try {
            os = response.getOutputStream();
            hssfWorkbook.write(os);
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("生成表格出错");
        } finally {
            if (os != null) {
                os.flush();
                os.close();
            }
        }

    }

}
