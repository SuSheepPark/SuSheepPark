package com.ruida.mockdao.dto;

import lombok.Data;

@Data
public class TestPaperQueryRequest {


    /**
     * 用户id
     */
    private String userId;

    /*
       商品id
     */
    private Integer productId;

    private Integer status;

    /*
        排序字段  默认创建时间排序倒序     */
    private String  orderStr = "test_paper_no";

    /*
        排序方式 0-降序 1-升序 默认创建时间排序倒序
     */
    private Integer orderType = 0;


    private Integer isdelete = 0;


}
