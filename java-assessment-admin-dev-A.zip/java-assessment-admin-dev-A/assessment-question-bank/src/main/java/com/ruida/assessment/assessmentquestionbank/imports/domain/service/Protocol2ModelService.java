package com.ruida.assessment.assessmentquestionbank.imports.domain.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import javax.inject.Inject;
import javax.inject.Named;

import org.apache.commons.lang3.StringUtils;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.ruida.assessment.assessmentcommon.enums.QuestionEnum;
import com.ruida.assessment.assessmentcommon.enums.QuestionStatusEnum;
import com.ruida.assessment.assessmentquestionbank.imports.domain.model.ErrorMsgException;
import com.ruida.assessment.assessmentquestionbank.imports.domain.model.Question;
import com.ruida.assessment.assessmentquestionbank.imports.domain.model.QuestionAnswerItem;
import com.ruida.assessment.assessmentquestionbank.imports.domain.model.QuestionBlock;
import com.ruida.assessment.assessmentquestionbank.imports.domain.model.QuestionBaseConfig;
import com.ruida.assessment.assessmentquestionbank.imports.domain.model.QuestionConfig;
import com.ruida.assessment.assessmentquestionbank.imports.domain.model.QuestionContent;
import com.ruida.assessment.assessmentquestionbank.imports.domain.model.QuestionContentItem;
import com.ruida.assessment.assessmentquestionbank.imports.domain.model.QuestionKnowledgeItem;
import com.ruida.assessment.assessmentquestionbank.model.TKnowledge;
import com.ruida.assessment.assessmentquestionbank.model.TQuestionAssessmentTarget;
import com.ruida.assessment.assessmentquestionbank.model.TQuestionDifficulty;
import com.ruida.assessment.assessmentquestionbank.model.TQuestionPurpose;
import com.ruida.assessment.assessmentquestionbank.model.TQuestionSource;
import com.ruida.assessment.assessmentquestionbank.model.TQuestionType;
import com.ruida.assessment.assessmentquestionbank.model.TSecurityLevel;
import com.ruida.assessment.assessmentquestionbank.service.IKnowledgeService;
import com.ruida.assessment.assessmentquestionbank.service.QuestionAssessmentTargetService;
import com.ruida.assessment.assessmentquestionbank.service.QuestionDifficultyService;
import com.ruida.assessment.assessmentquestionbank.service.QuestionPurposeService;
import com.ruida.assessment.assessmentquestionbank.service.QuestionSourceService;
import com.ruida.assessment.assessmentquestionbank.service.QuestionTypeService;
import com.ruida.assessment.assessmentquestionbank.service.SecurityLevelService;
import com.ruida.assessment.assessmentquestionbank.vo.QuestionInfoVO;
import com.ruida.assessment.assessmentquestionbank.vo.QuestionKnowledgeRelationVO;

@Named
public class Protocol2ModelService {

	public static final String AUTOCORRECT="自动批改";
	public static final String HUMANCORRECT="人工批改";
	@Inject
	QuestionTypeService questionTypeService;
	@Inject
	QuestionDifficultyService questionDifficultyService;
	@Inject
	SecurityLevelService securityLevelService;
	@Inject
	QuestionAssessmentTargetService questionAssessmentTargetService;
	@Inject
	QuestionSourceService questionSourceService;
	@Inject
	QuestionPurposeService questionPurposeService;
	@Inject
	IKnowledgeService knowledgeService;

	public QuestionInfoVO parseQuestionLibrary(Question protocolQuestion) {
		QuestionInfoVO questionLibrary = new QuestionInfoVO();
		QuestionConfig config = protocolQuestion.getConfig();
		try {
			questionLibrary.setQuestionTypeId(parseQuestionType(config.getQuestionType()));
			questionLibrary.setQuestionTypeName(config.getQuestionType());
			questionLibrary.setDifficultyId(parseDiffculty(config.getDifficulty()));
			questionLibrary.setDifficultyName(config.getDifficulty());
			questionLibrary.setSecurityLevelId(parseSecurityLevel(config.getPublicLevel()));
			questionLibrary.setSecurityLevelName(config.getPublicLevel());
			questionLibrary.setAssessmentTargetId(parseQuestionAssessmentTarget(config.getScore()));
			questionLibrary.setAssessmentTargetName(config.getScore());
			questionLibrary.setQuestionSourceId(parseQuestionSource(config.getSource()));
			questionLibrary.setQuestionSourceName(config.getSource());
			questionLibrary.setQuestionPurposeId(parseQuestionPurpose(config.getUse()));
			questionLibrary.setQuestionPurposeName(config.getUse());
			questionLibrary.setEstimateDuration(parseEstimateDuration(config.getLength()));
			questionLibrary.setAnswerPhotographId(parseAnswerPhotographId(config.getUploadPhoto()));
			questionLibrary.setCorrectType(parseCorrectType(config.getAutoCorrection()));
		} catch (ErrorMsgException e) {
			ErrorService.addError(null, protocolQuestion.getQuestionName(), e.getDesc());
			return null;
		}
		QuestionBlock block = protocolQuestion.getBlock();
		QuestionContent content = block.getContent();
		questionLibrary.setQuestionTitle(content.getContent());
		if (QuestionEnum.CQT.getV().equals(config.getQuestionType())) {
			List<QuestionBlock> blocks = content.getBlocks();
			List<QuestionInfoVO> children = new ArrayList<QuestionInfoVO>();
			for (QuestionBlock block2 : blocks) {
				QuestionInfoVO questionLibrary2 = new QuestionInfoVO();
				QuestionBaseConfig config2 = block2.getBlockConfig();

				try {
					questionLibrary2.setQuestionTypeId(parseQuestionType(config2.getQuestionType()));
					questionLibrary2.setQuestionTypeName(config2.getQuestionType());
					questionLibrary2.setAnswerPhotographId(parseAnswerPhotographId(config2.getUploadPhoto()));
					questionLibrary2.setCorrectType(parseCorrectType(config2.getAutoCorrection()));
				} catch (ErrorMsgException e) {
					ErrorService.addError(null, protocolQuestion.getQuestionName(),
							"组合题的子题目的错误的题目类型：" + config2.getQuestionType());
					return null;
				}

				QuestionContent content2 = block2.getContent();
				questionLibrary2.setQuestionTitle(content2.getContent());
				questionLibrary2.setQuestionSort(block2.getNumber());

				questionLibrary2
						.setStem(parseContentItem2stem(content2.getItems(), block2.getAnswer().getAnswerItems()));
				try {
					questionLibrary2.setQuestionTitleSetting(parseAnswerConfig(block2.getAnswer().getAnswerType()));
				} catch (ErrorMsgException e1) {
					ErrorService.addError(null, protocolQuestion.getQuestionName(), e1.getDesc());
					return null;
				}
				questionLibrary2.setAnswer(parseAnswerItem2Answer(block2.getAnswer().getAnswerItems()));
				questionLibrary2.setAnalysis(block2.getExplain().getExplain());
				if (block2.getRemark() != null) {
//					questionLibrary2.setNote(block2.getRemark().getRemark());
					questionLibrary2.setRemark(block2.getRemark().getRemark());
				}

				if (block2.getKnowledge() != null) {
					List<QuestionKnowledgeItem> knowledgeItems = block2.getKnowledge().getItems();
					if (knowledgeItems != null) {
						try {
							questionLibrary2.setQuestionKnowledgeRelation(parseKnowledge(knowledgeItems));
						} catch (ErrorMsgException e) {
							ErrorService.addError(null, protocolQuestion.getQuestionName(), e.getDesc());
							return null;
						}
					}
				}
				questionLibrary2.setQuestionStatus(QuestionStatusEnum.ROUGH_DRAFT.getK());
				children.add(questionLibrary2);
			}
			questionLibrary.setChildren(children);
		} else {
			questionLibrary.setStem(parseContentItem2stem(content.getItems(), block.getAnswer().getAnswerItems()));
			try {
				questionLibrary.setQuestionTitleSetting(parseAnswerConfig(block.getAnswer().getAnswerType()));
			} catch (ErrorMsgException e1) {
				ErrorService.addError(null, protocolQuestion.getQuestionName(), e1.getDesc());
				return null;
			}
			questionLibrary.setAnswer(parseAnswerItem2Answer(block.getAnswer().getAnswerItems()));
			questionLibrary.setAnalysis(block.getExplain().getExplain());
//			questionLibrary.setNote(block.getRemark().getRemark());
			questionLibrary.setRemark(block.getRemark().getRemark());

			if (block.getKnowledge() != null) {
				List<QuestionKnowledgeItem> knowledgeItems = block.getKnowledge().getItems();
				if (knowledgeItems != null) {
					try {
						questionLibrary.setQuestionKnowledgeRelation(parseKnowledge(knowledgeItems));
					} catch (ErrorMsgException e) {
						ErrorService.addError(null, protocolQuestion.getQuestionName(), e.getDesc());
						return null;
					}
				}
			}
		}

		questionLibrary.setQuestionStatus(QuestionStatusEnum.ROUGH_DRAFT.getK());
		return questionLibrary;
	}

	private Integer parseAnswerConfig(String answerType) throws ErrorMsgException {
		if (StringUtils.isEmpty(answerType)) {
			return null;
		}
		switch (answerType) {
		case "完全一致":
			return 1;
		case "仅顺序不一致":
			return 2;
		case "仅供参考":
			return 3;
		default:
			throw new ErrorMsgException(null, "错误的题目配置项类型：" + answerType);
		}
	}

	private Integer parseQuestionType(String questionTypeString) throws ErrorMsgException {
		TQuestionType questionType = questionTypeService.selectQuestionTypeByName(questionTypeString);
		if (questionType == null) {
			throw new ErrorMsgException(null, "错误的题目类型：" + questionTypeString);
		}
		return questionType.getId();
	}

	private Integer parseDiffculty(String name) throws ErrorMsgException {
		TQuestionDifficulty difficulty = questionDifficultyService.selectQuestionDifficultyByName(name);
		if (difficulty == null) {
			throw new ErrorMsgException(null, "错误的难度类型：" + name);
		}
		return difficulty.getId();
	}

	private Integer parseSecurityLevel(String name) throws ErrorMsgException {
		TSecurityLevel securityLevel = securityLevelService.selectSecurityLevelByName(name);
		if (securityLevel == null) {
			throw new ErrorMsgException(null, "错误的保密等级类型：" + name);
		}
		return securityLevel.getId();
	}

	private Integer parseAnswerPhotographId(String name) throws ErrorMsgException {
		if (StringUtils.isEmpty(name)) {
			return null;
		}
		Integer answerPhotographId;
		switch (name) {
		case "是":
			answerPhotographId = 1;
			break;
		case "否":
			answerPhotographId = 1;
			break;
		default:
			throw new ErrorMsgException(null, "错误的是否支持上传参数：" + name);
		}
		return answerPhotographId;
	}

	private Integer parseCorrectType(String name) throws ErrorMsgException {
		if (StringUtils.isEmpty(name)) {
			return null;
		}
		Integer correctType;
		switch (name) {
		case AUTOCORRECT:
			correctType = 1;
			break;
		case HUMANCORRECT:
			correctType = 0;
			break;
		default:
			throw new ErrorMsgException(null, "错误的批改方式参数：" + name);
		}
		return correctType;
	}

	private Integer parseQuestionAssessmentTarget(String name) throws ErrorMsgException {
		if (StringUtils.isEmpty(name)) {
			return null;
		}
		TQuestionAssessmentTarget questionAssessmentTarget = questionAssessmentTargetService
				.selectQuestionAssessmentTargetByName(name);
		if (questionAssessmentTarget == null) {
			throw new ErrorMsgException(null, "错误的考查要求类型：" + name);
		}
		return questionAssessmentTarget.getId();
	}

	private Integer parseQuestionSource(String name) throws ErrorMsgException {
		if (StringUtils.isEmpty(name)) {
			return null;
		}
		TQuestionSource questionSource = questionSourceService.selectQuestionSourceByName(name);
		if (questionSource == null) {
			throw new ErrorMsgException(null, "错误的试题来源类型：" + name);
		}
		return questionSource.getId();
	}

	private Integer parseQuestionPurpose(String name) throws ErrorMsgException {
		if (StringUtils.isEmpty(name)) {
			return null;
		}
		TQuestionPurpose questionPurpose = questionPurposeService.selectQuestionPurposeByName(name);
		if (questionPurpose == null) {
			throw new ErrorMsgException(null, "错误的试题用途类型：" + name);
		}
		return questionPurpose.getId();
	}

	private Integer parseEstimateDuration(String length) throws ErrorMsgException {
		if (StringUtils.isEmpty(length)) {
			return null;
		}
		try {
			return Integer.parseInt(length);
		} catch (NumberFormatException e) {
			throw new ErrorMsgException(null, "错误的时长参数：" + length);
		}

	}

	private String parseContentItem2stem(List<QuestionContentItem> contentItems, List<QuestionAnswerItem> answerItems) {
		if (contentItems == null || contentItems.size() == 0) {
			return null;
		}
		List<String> answerAtring = null;
		if (answerItems != null) {
			answerAtring = answerItems.stream().flatMap(x -> Arrays.asList(x.getAnswer().split("")).stream())
					.collect(Collectors.toList());
		}
		JSONArray arr = new JSONArray();
		for (int i = 0; i < contentItems.size(); i++) {
			QuestionContentItem contentItem = contentItems.get(i);
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("val", contentItem.getItemContent());
			String key = "" + (char) ('A' + i);
			jsonObject.put("key", key);
			if (answerAtring != null) {
				jsonObject.put("isAnswer", answerAtring.contains(key));
			}
			arr.add(jsonObject);
		}
		return arr.toJSONString();
	}

	private String parseAnswerItem2Answer(List<QuestionAnswerItem> answerItems) {
		JSONArray arr = new JSONArray();
		for (int i = 0; i < answerItems.size(); i++) {
			QuestionAnswerItem contentItem = answerItems.get(i);
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("val", contentItem.getAnswer());
			jsonObject.put("key", i);
			arr.add(jsonObject);
		}
		return arr.toJSONString();
	}

	private List<QuestionKnowledgeRelationVO> parseKnowledge(List<QuestionKnowledgeItem> knowledgeItems)
			throws ErrorMsgException {
		List<QuestionKnowledgeRelationVO> questionKnowledgeRelation = new ArrayList<QuestionKnowledgeRelationVO>();
		for (QuestionKnowledgeItem knowledgeItem : knowledgeItems) {
			QuestionKnowledgeRelationVO knowledgeRelationDTO = new QuestionKnowledgeRelationVO();
			String[] split = knowledgeItem.getKnowledgeString().split("-");
			TKnowledge knowledge = null;
			Integer pid = null;
			for (String name : split) {
				knowledge = knowledgeService.selectKnowledgeByName(name, pid);
				if (knowledge == null) {
					throw new ErrorMsgException(null, "错误的知识点参数：" + knowledgeItem.getKnowledgeString() + " 中的：" + name);
				}
				pid = knowledge.getKnowledgeId();
			}

			Integer knowledgeId = knowledge.getKnowledgeId();
			knowledgeRelationDTO.setKnowledgeId(knowledgeId);
			knowledgeRelationDTO.setKnowledgeName(knowledge.getKnowledgeName());
			knowledgeRelationDTO.setKnowledgePoints(Integer.parseInt(knowledgeItem.getWeight()));
			questionKnowledgeRelation.add(knowledgeRelationDTO);
		}
		return questionKnowledgeRelation;
	}
}
