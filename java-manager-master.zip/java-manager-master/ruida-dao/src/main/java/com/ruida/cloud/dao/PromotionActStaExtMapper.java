package com.ruida.cloud.dao;

import com.ruida.cloud.model.PromotionActDisSta;
import com.ruida.cloud.model.PromotionActSta;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

/**
 * @author admin
 * @description: ${TODO}
 * @Date 2020/4/15
 * @verion 1.0
 */
public interface PromotionActStaExtMapper {
    /**
     * 获取单个分销商的统计数据
     * @param paramMap
     * @return
     */
     Map<String,Object> getDistrbutorPromotionInfo(Map<String,Object> paramMap);

    /**
     * 营销活动列表
     * @return
     */
     List<PromotionActSta> listPromotionActSta(Map param);

    /**
     * 营销互动列表总数
     * @param paramMap
     * @return
     */
     Integer  countPromotionActSta(Map paramMap);

    /**
     * 分销明细
     * @param param
     * @return
     */
    List<PromotionActSta> detailDisList(Map param);
    @Select("SELECT\n" +
            "            b.distributor_id AS distributorId,\n" +
            "            a.role_id AS roleId,\n" +
            "            c.role_name AS roleName\n" +
            "            FROM sys_user_role a\n" +
            "            LEFT JOIN t_distributor b ON b.bind_account = a.user_id\n" +
            "            LEFT JOIN sys_role c ON a.role_id = c.role_id\n" +
            "            WHERE\n" +
            "            a.user_id =  #{userId}")
    Map getRoleIdByDis(@Param("userId") Integer userId);

    /**
     * 单分销商统计订单支付金额
     * @param param
     * @return
     */
    BigDecimal distributorPaySta(Map param);

    /**
     * 活动统计数据获取
     * @param param
     * @return
     */
    List<Map<String,Object>> promotionActVulSta(Map param);
    PromotionActSta promotionsingledisVulSta(Map param);
    @Select("SELECT GROUP_CONCAT(a.distributor_id) AS idList FROM t_distributor a WHERE a.isdelete = 0")
    String getDisIdList();
    List<PromotionActDisSta>  getDisListFresh(Map param);
    Integer countDisListFresh(Map param);
    Integer getUv(Map param);
    List<PromotionActDisSta> getdisvulStaFresh(Map param);

}
