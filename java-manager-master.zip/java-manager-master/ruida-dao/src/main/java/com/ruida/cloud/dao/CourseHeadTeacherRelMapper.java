package com.ruida.cloud.dao;

import com.ruida.cloud.model.CourseHeadTeacherRel;
import com.ruida.cloud.model.CourseHeadTeacherRelExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface CourseHeadTeacherRelMapper {
    long countByExample(CourseHeadTeacherRelExample example);

    int deleteByExample(CourseHeadTeacherRelExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(CourseHeadTeacherRel record);

    int insertSelective(CourseHeadTeacherRel record);

    List<CourseHeadTeacherRel> selectByExample(CourseHeadTeacherRelExample example);

    CourseHeadTeacherRel selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") CourseHeadTeacherRel record, @Param("example") CourseHeadTeacherRelExample example);

    int updateByExample(@Param("record") CourseHeadTeacherRel record, @Param("example") CourseHeadTeacherRelExample example);

    int updateByPrimaryKeySelective(CourseHeadTeacherRel record);

    int updateByPrimaryKey(CourseHeadTeacherRel record);

    /**
     * 列出该班主任的所有课程
     */
    List<Map<String, Object>> listAllClassTeacherCourse(@Param("userId") Integer userId);

    /**
     * 列出某门课的班主任信息
     * @param courseIds
     * @return
     */
    List<Map<String,Object>> listCourseHeadTeachers(@Param("list") List<String> courseIds);
}