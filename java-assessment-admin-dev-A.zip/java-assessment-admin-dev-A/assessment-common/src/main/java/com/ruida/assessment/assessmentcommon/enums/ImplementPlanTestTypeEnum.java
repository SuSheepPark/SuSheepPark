package com.ruida.assessment.assessmentcommon.enums;

/**
 * Created by xumingqi on 2021/9/2 13:44
 */
public enum ImplementPlanTestTypeEnum {
    PRACTICE(1, "模拟练习"),
    ONLINE_EXAM(2, "在线统考"),
    JUNIOR_UNION(3, "初中联考"),
    SENIOR_UNION(4, "高中联考");

    private Integer K;
    private String V;

    ImplementPlanTestTypeEnum(Integer k, String v) {
        K = k;
        V = v;
    }

    public Integer getK() {
        return K;
    }

    public void setK(Integer k) {
        K = k;
    }

    public String getV() {
        return V;
    }

    public void setV(String v) {
        V = v;
    }
}
