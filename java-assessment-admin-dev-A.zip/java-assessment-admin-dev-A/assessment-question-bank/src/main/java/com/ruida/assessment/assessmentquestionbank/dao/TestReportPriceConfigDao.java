package com.ruida.assessment.assessmentquestionbank.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.assessment.assessmentquestionbank.model.TTestReportPriceConfig;

/**
 * @description:
 * @author: kgz
 * @date: 2021/1/13
 */
public interface TestReportPriceConfigDao extends BaseMapper<TTestReportPriceConfig> {
}
