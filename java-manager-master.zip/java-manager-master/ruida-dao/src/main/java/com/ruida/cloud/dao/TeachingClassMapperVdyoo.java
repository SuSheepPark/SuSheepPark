package com.ruida.cloud.dao;

import com.ruida.cloud.model.TeachingClassVdyoo;

import java.util.List;

public interface TeachingClassMapperVdyoo {
    List<TeachingClassVdyoo> listTeachingClassVdyoo(int courseId);
}