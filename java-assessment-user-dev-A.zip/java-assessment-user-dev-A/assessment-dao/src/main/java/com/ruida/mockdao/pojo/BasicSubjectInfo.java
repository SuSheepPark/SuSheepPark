package com.ruida.mockdao.pojo;

import java.math.BigDecimal;

/**
 * @description: 科目基础信息
 * @author: chenjy
 * @create: 2021-01-19 16:02
 */
public class BasicSubjectInfo implements Comparable<BasicSubjectInfo>{
    private Integer subjectId;

    private String subjectName;

    private BigDecimal score;

    public Integer getSubjectId() {
        return subjectId;
    }

    public void setSubjectId(Integer subjectId) {
        this.subjectId = subjectId;
    }

    public String getSubjectName() {
        return subjectName;
    }

    public void setSubjectName(String subjectName) {
        this.subjectName = subjectName;
    }

    public BigDecimal getScore() {
        return score;
    }

    public void setScore(BigDecimal score) {
        this.score = score;
    }

    @Override
    public int compareTo(BasicSubjectInfo o) {
        if(this.score == null && o.getScore() == null){
            return 0;
        }else if(this.score == null && o.getScore() != null){
            return 1;
        }else if(this.score != null && o.getScore() == null){
            return -1;
        }

        return o.getScore().compareTo(score);
    }
}
