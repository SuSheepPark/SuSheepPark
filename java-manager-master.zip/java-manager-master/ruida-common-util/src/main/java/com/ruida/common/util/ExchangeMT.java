package com.ruida.common.util;

import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ExchangeMT {
	
	public static String date2StringIntact(Date d){
		try{
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			return sdf.format(d);	
		}catch(Exception e){
			return "";
		}
	}

	public static Date parse4Intact(String str){
		try{
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			return sdf.parse(str);
		}catch(Exception e){
			return null;
		}
	}
	public static String parse2StringShort(Date d){
		try{
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			return sdf.format(d);	
		}catch(Exception e){
			return "";
		}
	}

	public static Date parse4Short(String str){
		try{
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			return sdf.parse(str);
		}catch(Exception e){
			return null;
		}
	}
	public static Integer string2IntegerDefNull(String str){
		try{
			return Integer.valueOf(str);
		}catch(Exception e){
			return null;
		}
	}
	
	public static Integer string2Integer(String str,int def){
		try{
			return Integer.valueOf(str);
		}catch(Exception e){
			return def;
		}
	}
	
	public static String convert(String target,String oriCharset,String desCharset) {
        try {
            return new String(target.trim().getBytes(oriCharset), desCharset);
        } catch (UnsupportedEncodingException e) {
            return target;
        }
    }
}
