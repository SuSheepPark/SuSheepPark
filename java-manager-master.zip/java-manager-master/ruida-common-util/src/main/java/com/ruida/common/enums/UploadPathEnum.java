package com.ruida.common.enums;

import com.ruida.common.exception.CoreException;

/**
 * @author szl
 * @description: 文件上传路径类型
 * @Date 2019/1/15
 * @verion 1.0
 */
public enum UploadPathEnum {

    COVER_PIC(0),//课程封面图片
    COVER_RICH(1),//课程富文本
    COURSE_WARE(2),//资源库
    ROTATION_CHART(3),//门户轮播
    NEW_INFO(4),//门户首页富文本咨询富文本
    SCHOOL_LOGO(5),//学校logo
    STU_EXCEL(6),//导入学生excl文件上传路径
    COURSE_INTRO(7),//课程介绍哦啊
    COURSE_STORE(8),//课程收藏
    COURSE_CAMPUS(9),//学生排版导入
    KNOWLEDGE(10);//知识点上传
    private final int code;

    private UploadPathEnum(int code) {
        this.code = code;
    }


    public static UploadPathEnum forInt(int code) throws Exception {
        for (UploadPathEnum type : values()) {
            if (type.code == code) {
                return type;
            }
        }
        throw new CoreException(AppErrorEnum.E_10006);
    }


    public int getCode() {
        return code;
    }


}
