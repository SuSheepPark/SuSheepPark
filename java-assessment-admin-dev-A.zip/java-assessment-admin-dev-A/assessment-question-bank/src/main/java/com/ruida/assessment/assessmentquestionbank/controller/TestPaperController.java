package com.ruida.assessment.assessmentquestionbank.controller;

import com.ruida.assessment.assessmentcommon.result.*;
import com.ruida.assessment.assessmentquestionbank.annotaion.UserAuth;
import com.ruida.assessment.assessmentquestionbank.dto.*;
import com.ruida.assessment.assessmentquestionbank.service.DetailTableTestPaperService;
import com.ruida.assessment.assessmentquestionbank.service.TestPaperService;
import com.ruida.assessment.assessmentquestionbank.vo.QuestionInfoVO;
import com.ruida.assessment.assessmentquestionbank.vo.TestNodeQuestionRelVO;
import com.ruida.assessment.assessmentquestionbank.vo.TestNodeVO;
import com.ruida.assessment.assessmentquestionbank.vo.TestPaperVO;
import com.ruida.assessment.util.DownloadUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.UnsupportedEncodingException;
import java.util.List;

/**
 * @description: 试卷控制层
 * @author: kgz
 * @date: 2020/6/28
 */
@RequestMapping("/testPaper")
@RestController
@Api(value ="试卷相关接口")
public class TestPaperController {

    @Resource
    private TestPaperService testPaperService;
    @Resource
    DetailTableTestPaperService detailTableTestPaperService;

    @UserAuth
    @PostMapping("/save")
    @ApiOperation(value = "保存试卷信息", notes = "保存试卷信息")
    @ApiImplicitParam(name = "testPaperDTO", value = "试卷信息",
            required = true , dataType  = "TestPaperDTO",paramType = "body")
    public PojoResult saveTestPaper(@RequestBody TestPaperDTO testPaperDTO){
/*        PojoResult pojoResult = new PojoResult();
        pojoResult.setContent(testPaperService.saveTestPaper(testPaperDTO));*/
        return testPaperService.saveTestPaper(testPaperDTO);
    }

    @UserAuth
    @PostMapping("/testNode/add")
    @ApiOperation(value = "保存小节信息", notes = "保存小节信息")
    @ApiImplicitParam(name = "testNodeDTO", value = "小节信息",
            required = true , dataType  = "TestNodeDTO",paramType = "body")
    public PojoResult saveTestNode(@RequestBody TestNodeDTO testNodeDTO){
        PojoResult pojoResult = new PojoResult();
        pojoResult.setContent(testPaperService.saveTestNode(testNodeDTO));
        return pojoResult;
    }

    @UserAuth
    @PostMapping("/testNodeQuestionRel/add")
    @ApiOperation(value = "新增小节试题关联关系信息", notes = "新增小节试题关联关系信息")
    @ApiImplicitParam(name = "testNodeQuestionRelDTO", value = "小节与试题关联关系信息",
            required = true , dataType  = "list",paramType = "body")
    public PojoResult saveTestNodeQuestionRel(@RequestBody List<TestNodeQuestionRelDTO> testNodeQuestionRelDTO){
//        PojoResult pojoResult = new PojoResult();
//        pojoResult.setContent(testPaperService.saveTestNodeQuestionRel(testNodeQuestionRelDTO));
        return testPaperService.saveTestNodeQuestionRel(testNodeQuestionRelDTO);
    }

    @UserAuth
    @GetMapping("/getDetail/{id}")
    @ApiImplicitParam(name = "id", value = "试卷id",
            required = true , dataType  = "Integer",paramType = "path")
    public PojoResult getDetail(@PathVariable Integer id){
        PojoResult pojoResult = new PojoResult();
        TestPaperVO testPaperDetail = testPaperService.getTestPaperDetail(id);
        pojoResult.setContent(testPaperDetail);
        return pojoResult;
    }

    @UserAuth
    @PostMapping("/operation")
    @ApiImplicitParam(name = "testPaperOperationDTO", value = "试卷操作",
            required = true , dataType  = "TestPaperOperationDTO",paramType = "body")
    public MapResult operation(@RequestBody TestPaperOperationDTO testPaperOperationDTO){
/*        MapResult mapResult = new MapResult();
        mapResult.setMsg("操作成功");
        testPaperService.operationTestPaper(testPaperOperationDTO);
        mapResult.add(COLUMN_ID, testPaperOperationDTO.getTestPaperId());*/
        return testPaperService.operationTestPaper(testPaperOperationDTO);
    }
    @UserAuth
    @PostMapping("/rejQuestionRel")
    @ApiImplicitParam(name = "testPaperQuestionRelDTO", value = "退回试卷引用试题",
            required = true , dataType  = "TestPaperQuestionRelDTO",paramType = "body")
    public MapResult rejQuestionRel(@RequestBody TestPaperQuestionRelDTO testPaperQuestionRelDTO){
        return testPaperService.rejQuestionRel(testPaperQuestionRelDTO);
    }
    @UserAuth
    @PostMapping("/getRejRelReson")
    @ApiImplicitParam(name = "testPaperQuestionRelDTO", value = "退回试卷引用试题",
            required = true , dataType  = "TestPaperQuestionRelDTO",paramType = "body")
    public MapResult getRejRelReson(@RequestBody TestPaperQuestionRelDTO testPaperQuestionRelDTO){
        return testPaperService.getRejQueReson(testPaperQuestionRelDTO);
    }

    @PostMapping("/importDeatailTable")
    @UserAuth
    public PojoResult importDeatailTable(MultipartFile file, Integer testPaperId) {
        return detailTableTestPaperService.importDeatailTable(file, testPaperId);
    }

    @PostMapping("/nextQuestionList")
    @UserAuth
    public PageResult nextQuestion(@RequestBody QuestionQueryDTO questionQueryDTO) {
        PageResult result = new PageResult();
        Page<QuestionInfoVO> page = detailTableTestPaperService.nextQuestion(questionQueryDTO);
        result.setContent(page);
        return result;
    }

    @PostMapping("/saveNextQue")
    @UserAuth
    public PojoResult saveNextQue(@RequestBody SaveNextQueDTO saveNextQueDTO) {
        PojoResult<Boolean> result = new PojoResult<Boolean>();
        boolean isAck = detailTableTestPaperService.saveNextQue(saveNextQueDTO.getOriginId(), saveNextQueDTO.getNextId(), saveNextQueDTO.getTestPaperId());
        result.setContent(isAck);
        return result;
    }

    @UserAuth
    @GetMapping("/paperUseType/getList")
    @ApiOperation(value = "获取试卷性质下拉框列表", notes = "获取试卷性质下拉框列表")
    public ListResult getList(@RequestParam(required = false) Integer type){
        ListResult listResult = new ListResult();
        listResult.setContent(testPaperService.getPaperUseTypeList(type));
        return listResult;
    }

    @UserAuth
    @GetMapping("/answerWay/getList")
    @ApiOperation(value = "获取答题方式下拉框列表", notes = "获取答题方式下拉框列表")
    public ListResult getList(){
        ListResult listResult = new ListResult();
        listResult.setContent(testPaperService.getAnswerWayList());
        return listResult;
    }

    /**
     * 下载试卷
     *
     * @param
     */
    @RequestMapping("downloadTestPaper")
    @UserAuth
    @CrossOrigin
    public PojoResult downloadpdf(Integer testPaperId) {
        PojoResult result = new PojoResult();
        result.setContent(testPaperService.downloadTestPaper(testPaperId));
        return result;
    }
}
