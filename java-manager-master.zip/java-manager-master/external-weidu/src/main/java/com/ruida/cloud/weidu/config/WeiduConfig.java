package com.ruida.cloud.weidu.config;

public class WeiduConfig {

    /**=====================教室模块start====================*/
    /**
     * 查询公司下所有教室
     */
    public final static String findRoomByTenant = "/api/business/room/findRoomByTenant";
    /**
     * 根据教室ID查询教室信息
     */
    public final static String getRoomById = "/api/business/room/getRoomById";
    /**
     * 编辑教室地址
     */
    public final static String updateRoomById = "/api/business/room/updateRoom";
    /**=====================教室模块end=========================*/

    /**
     * 新增校区
     **/
    public final static String addDepartment = "/api/core/department/addDepartment";
    public final static String editDepartmentById = "/api/core/department/editDepartmentById";


    /**====================教师模块start=====================*/
    /**
     * 新增教师
     */
    public final static String addTeacher = "/api/business/teacher/addTeacher";
    /**
     * 删除教师
     */
    public final static String deleteTeacherById = "/api/business/teacher/deleteTeacherById";
    /**
     * 编辑教师信息
     */
    public final static String editTeacherById = "/api/business/teacher/editTeacherById";
    /**
     * 通过教师威渡id查询教师信息
     */
    public final static String findTeacherById = "/api/business/teacher/findTeacherById";
    /**
     * 查询所有教师信息
     */
    public final static String findAllTeacher = "/api/business/teacher/findTeacherByTenant";
    /**=======================教师模块end=====================*/

    /**==============================课程模块start===============================**/
    /**
     * 添加课程
     */
    public final static String addCourse = "/api/business/course/addCourse";
    /**
     * 根据id删除课程
     */
    public final static String deleteCourseById = "/api/business/course/deleteCourseById";
    /**
     * 编辑课程 根据课程Id
     */
    public final static String editCourseById = "/api/business/course/editCourseById";
    /*** 通过威渡课程Id 来查询课程信息*/
    public final static String findCourseById = "/api/business/course/findCourseById";
    /**
     * 查询全部的课程
     */
    public final static String findCourseClassByTenant = "/api/business/course/findCourseClassByTenant";

    /**==============================课程模块end===============================**/

    /**
     * 创建学生
     */
    public final static String addStudent = "/api/business/student/addStudent";

    /**
     * 创建班级学生
     */
    public final static String addClassStudent = "/api/business/student/addClassStudent";


    /**
     * 批量创建学生
     */
    public final static String addBatchStudent = "/api/business/student/addBatchStudent";
    /**
     * 删除学生(根据威渡id)
     */
    public final static String deleteStudentById = "/api/business/student/deleteStudentById";
    /**
     * 删除学生(根据学生本地id)
     */
    public final static String deleteStudentByPid = "/api/business/student/deleteStudentByPid";
    /**
     * 编辑学生信息(根据学生本地id)
     */
    public final static String editStudentByPid = "/api/business/student/editStudentByPid";
    /**
     * 根据ID查询学生
     */
    public final static String findStudentByid = "/api/business/student/findStudentByid";

    /**
     * 根据ID查询学生(根据学生本地pid)
     */
    public final static String findStudentByPid = "/api/business/student/findStudentByPid";
    /**
     * 查询公司下所有学生
     */
    public final static String findStudentByTenant = "/api/business/student/findStudentByTenant";
    /**
     * 添加班级成员（将学生与班级关联，游客->学生）
     */
    public final static String addClassMember = "/api/business/classmember/addClassMember";

    public final static String addClassMembers = "/api/business/classmember/addClassMembers";

    /**
     * 删除班级成员
     */
    public final static String deleteClassMemberById = "/api/business/classmember/deleteClassMemberById";
    public final static String deleteClassMember = "/api/business/classmember/deleteClassMember";

    /**
     * 创建教学科目
     */
    public final static String addSubject = "/api/business/subject/addSubject";
    /**
     * 根据教室ID查询教室信息
     */
    public final static String editSubjectById = "/api/business/subject/editSubjectById";
    /**
     * 删除教学科目
     */
    public final static String deleteSubjectById = "/api/business/subject/deleteSubjectById";

    /**
     * 查询公司下的所有教学科目
     */
    public final static String findSubjectByTenant = "/api/business/subject/findSubjectByTenant";
    /**
     * 创建课程班
     */
    public final static String addCourseClass = "/api/business/courseclass/addCourseClass";
    /**
     * 创建课程表
     */
    public final static String addSchedule = "/api/business/schedule/addSchedule";
    /**
     * 删除课程表
     */
    public final static String deleteSchedule = "/api/business/schedule/deleteSchedule";
    /**
     * 批量删除课程表
     */
    public final static String deleteSchedules = "/api/business/schedule/deleteSchedules";

    /**
     * 查询所有课程表
     */
    public final static String findScheduleByTenant = "/api/business/schedule/findScheduleByTenant";
    /**
     * 删除课程班
     */
    public final static String deleteCourseClassById = "/api/business/courseclass/deleteCourseClassById";
    /**
     * 编辑课程
     */
    public final static String editCourseClassById = "/api/business/courseclass/editCourseClassById";
    /**
     * 查询单个课程
     *
     * @param id
     */
    public final static String findCourseClassById = "/api/business/courseclass/editCourseClassById";

    /**
     * 查询公司下的课程
     */
    public final static String findCourseClassLessonTenant = "/api/business/courseclass/findCourseClassByTenant";
    /**
     * 删除 校区
     */
    public final static String deleteDepartmentById = "/api/core/department/deleteDepartmentById";
    /**
     * 创建班型（奥数班 火箭班）
     */
    public final static String addTenantClassType = "/api/business/tenantClassType/addTenantClassType";


    /**
     * 编辑班型
     */
    public final static String editTenantClassTypeById = "/api/business/tenantClassType/editTenantClassTypeById";
    /**
     * 查看班型的信息
     */
    public final static String findClassTypeById = "/api/business/tenantClassType/findClassTypeById";
    /**
     * 查看班型的信息
     */
    public final static String findClassTypeByTenant = "/api/business/tenantClassType/findClassTypeByTenant";
    /**
     * 创建教学班
     */
    public final static String addClasss = "/api/business/classs/addClasss";
    /**
     * 删除教学班级
     *
     * @param id
     */
    public final static String deleteClasssById = "/api/business/classs/deleteClasssById";
    /**
     * 编辑教学班级
     */
    public final static String editClasssById = "/api/business/classs/editClasssById";
    /**
     * 通过ID查询教学班级
     */
    public final static String findClassById = "/api/business/classs/findClassById";
    /**
     * 查询公司下全部教学班
     */
    public final static String findTeachingClassByTenant = "/api/business/classs/findTeachingClassByTenant";
    /**
     * 助教激活课表,学生自动签到
     */
    public final static String selectRoomScheduleAutoSingIn = "/api/answer/event/selectRoomScheduleAutoSingIn";
    /**
     * 互动发起
     */
    public final static String startExam = "/api/answer/event/startExam";
    /**
     * 结束互动
     */
    public final static String endExam = "/api/answer/event/endExam";
    /**
     * 红包操作
     */
    public final static String operateReadGift = "/api/answer/event/operateReadGift";
    /**
     * 获取学生列表（包含学生状态是否绑定）
     */
    public final static String findRoomScheduleStudents = "/api/answer/event/findRoomScheduleStudents";
    /**
     * 选择学生退出（解除绑定）
     */
    public final static String logoutStudents = "/api/answer/event/logoutStudents";
    /**
     * 学生签到
     */
    public final static String signInByMarker = "/api/answer/event/signInByMarker";
    /**
     * 学生的缺勤
     */
    public final static String signOutByMarker = "/api/answer/event/signOutByMarker";
    /**
     * 获取学生全部答题数据通过学生的ID来查询学生的答题情况
     */
    public final static String findStudentRedGiftBySchedule="findStudentRedGiftBySchedule";
    /**
     * 获取学生全部答题数据通过学生的ID来查询学生的答题情况
     */
    public final static String findStudentCountById="/api/business/studentcount/findStudentCountById";
    /**
     * 通过学生和试题类型 查出该学生的试题类型的答题情况
     */
    public final static String findStudentCountByIdByExamType="/api/business/studentcount/findStudentCountByIdByExamType";
    /**
     * 通过学生 课表 查出学生在教学计划答题情况
     */
    public final static String findStudentCountByIdBySchedule="/api/business/studentcount/findStudentCountByIdBySchedule";

    /**
     * 创建学期（春季班 秋季班）
     */
    public final static String addTenantTerm="/api/business/tenantTerm/addTenantTerm";
    /**
     * 编辑学期
     */
    public final static String editTenantTermById ="/api/business/tenantTerm/editTenantTermById";
    /**
     * 查看学期的信息
     */
    public final static String findTenantTermById ="/api/business/tenantTerm/findTenantTermById";
    /**
     * 查看全部的学期信息
     */
    public final static String findTenantTermByTenant ="/api/business/tenantTerm/findTenantTermByTenant";

    /**
     * 获取时间段
     */
    public final static String findTimeSlotByTenant ="/api/business/timeSlot/findTimeSlotByTenant";

    /**
     * 查询所有校区
     */
    public final static String findDepartmentByParentId ="/api/core/department/findDepartmentByParentId";

}
