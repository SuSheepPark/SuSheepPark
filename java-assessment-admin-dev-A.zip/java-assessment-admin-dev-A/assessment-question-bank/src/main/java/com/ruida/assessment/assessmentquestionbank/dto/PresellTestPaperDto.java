package com.ruida.assessment.assessmentquestionbank.dto;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.ruida.assessment.assessmentquestionbank.model.BaseColumn;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @author wy
 * @description 商品关联预售占位试卷
 * @date 2020/10/19
 */
@Data
public class PresellTestPaperDto extends BaseColumn implements Serializable {


    /**
     * 教材版本id
     */
    private Integer versionId;

    /**
     * 年级id
     */
    private Integer stageId;

    /**
     * 学科id
     */
    private Integer subjectId;

    /**
     * 年份
     */
    private Integer year;

    /*测试时长*/
    private Integer testDruation;

    private String testPaperName;

    /**
     * 试卷价格
     */
    private BigDecimal paperPrice;

    /**
     * 试卷ios价格
     */
    private BigDecimal paperIosPrice;

    /**
     * 报告价格
     */
    private BigDecimal reportPrice;

    /**
     * 报告ios价格
     */
    private BigDecimal reportIosPrice;


}
