package com.ruida.assessment.assessmentcommon.enums;

public enum CorrectStatusEnum {

    HAS_BEEN_CORRECTED(0,"已批改"),
    NO_CORRECTED(1,"未批改"),
    NULL_CORRECTED(2,""),//不需要批改
    ;

    private Integer K;
    private String V;

    CorrectStatusEnum(Integer k, String v) {
        K = k;
        V = v;
    }

    public Integer getK() {
        return K;
    }

    public void setK(Integer k) {
        K = k;
    }

    public String getV() {
        return V;
    }

    public void setV(String v) {
        V = v;
    }

    public static CorrectStatusEnum getValueById(Integer K){
        for(CorrectStatusEnum correctStatusEnum : CorrectStatusEnum.values() ){
            if(correctStatusEnum.getK().equals(K)){
                return  correctStatusEnum;
            }
        }
        return null;
    }
}
