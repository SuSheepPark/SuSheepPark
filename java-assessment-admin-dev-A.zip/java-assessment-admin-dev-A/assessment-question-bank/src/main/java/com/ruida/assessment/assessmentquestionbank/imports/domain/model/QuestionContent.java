package com.ruida.assessment.assessmentquestionbank.imports.domain.model;

import java.util.ArrayList;
import java.util.List;

public class QuestionContent {

	private String content;//题目
	private List<QuestionContentItem> items;//选项
	private List<QuestionBlock> blocks;//组合题模块
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public List<QuestionContentItem> getItems() {
		return items;
	}
	public void setItems(List<QuestionContentItem> items) {
		this.items = items;
	}
	public List<QuestionBlock> getBlocks() {
		return blocks;
	}
	public void setBlocks(List<QuestionBlock> blocks) {
		this.blocks = blocks;
	}
	
	public void addItems(QuestionContentItem item) {
		if(items==null) {
			items=new ArrayList<>();
		}
		items.add(item);
	}
	
	public void addBlock(QuestionBlock block) {
		if(blocks==null) {
			blocks=new ArrayList<>();
		}
		blocks.add(block);
	}
}
