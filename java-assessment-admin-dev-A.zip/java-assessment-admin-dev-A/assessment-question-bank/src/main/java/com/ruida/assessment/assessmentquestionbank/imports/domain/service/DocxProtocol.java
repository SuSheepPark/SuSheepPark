package com.ruida.assessment.assessmentquestionbank.imports.domain.service;

public class DocxProtocol {

	public static Boolean checkStart(String line) {
		return true;
	}
}
