package com.ruida.mockservice.service.impl;

import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.ruida.mockdao.dao.ErrorPracticeMapper;
import com.ruida.mockdao.model.ErrorPractice;
import com.ruida.mockservice.service.ErrorPracticeService;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 错题练习表 服务实现类
 * </p>
 *
 * @author chenjy
 * @since 2020-10-16
 */
@Service
public class ErrorPracticeServiceImpl extends ServiceImpl<ErrorPracticeMapper, ErrorPractice> implements ErrorPracticeService {

}
