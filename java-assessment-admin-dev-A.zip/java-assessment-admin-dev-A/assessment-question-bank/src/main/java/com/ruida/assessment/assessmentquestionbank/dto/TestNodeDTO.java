package com.ruida.assessment.assessmentquestionbank.dto;

import com.baomidou.mybatisplus.annotations.TableId;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.List;

/**
 * @description: 小节DTO
 * @author: kgz
 * @date: 2020/6/30
 */
@ApiModel(description = "小节信息")
public class TestNodeDTO {

    @ApiModelProperty(value = "小节id", name = "nodeId")
    private Integer nodeId;

    @ApiModelProperty(value = "小节标题", name = "nodeTitle")
    private String nodeTitle;

    @ApiModelProperty(value = "试卷id", name = "testPaperId")
    private Integer testPaperId;

    @ApiModelProperty(value = "小节排序", name = "sort")
    private Integer sort;

    @ApiModelProperty(value = "分值", name = "score")
    private double score;

    @ApiModelProperty(value = "漏选得分", name = "regressionScore")
    private Double regressionScore;

    private List<TestNodeQuestionRelDTO> testNodeQuestionRel;


    public Double getRegressionScore() {
        return regressionScore;
    }

    public void setRegressionScore(Double regressionScore) {
        this.regressionScore = regressionScore;
    }

    public Integer getNodeId() {
        return nodeId;
    }

    public void setNodeId(Integer nodeId) {
        this.nodeId = nodeId;
    }

    public String getNodeTitle() {
        return nodeTitle;
    }

    public void setNodeTitle(String nodeTitle) {
        this.nodeTitle = nodeTitle;
    }

    public Integer getTestPaperId() {
        return testPaperId;
    }

    public void setTestPaperId(Integer testPaperId) {
        this.testPaperId = testPaperId;
    }

    public Integer getSort() {
        return sort;
    }

    public void setSort(Integer sort) {
        this.sort = sort;
    }

    public double getScore() {
        return score;
    }

    public void setScore(double score) {
        this.score = score;
    }

    public List<TestNodeQuestionRelDTO> getTestNodeQuestionRel() {
        return testNodeQuestionRel;
    }

    public void setTestNodeQuestionRel(List<TestNodeQuestionRelDTO> testNodeQuestionRel) {
        this.testNodeQuestionRel = testNodeQuestionRel;
    }

    @Override
    public boolean equals(Object obj) {
        if(obj instanceof TestNodeDTO){
            TestNodeDTO testNode = (TestNodeDTO) obj;
            if(testNode.getNodeId() == null || this.getNodeId() == null){
                return false;
            }
            else{
                return this.getNodeId().equals(testNode.getNodeId());
            }
        }
        return false;
    }


}
