package com.ruida.mockdao.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.model.QuestionLibrary;
import com.ruida.mockdao.vo.QuestionVO;
import com.ruida.mockdao.vo.SelfCheckQuestionVO;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 题库表 Mapper 接口
 * </p>
 *
 * @author chenjy
 * @since 2020-07-09
 */
public interface QuestionLibraryMapper extends BaseMapper<QuestionLibrary> {

    QuestionVO getQuestionDetail(@Param("testPaperId") Integer testPaperId,
                                 @Param("questionId") String questionId);

    List<QuestionVO> getChildQuestionDetail(@Param("testPaperId") Integer testPaperId,
                                            @Param("questionId") String questionId);


    List<QuestionVO> selectChildQuestion(@Param("testPaperId") Integer testPaperId,
                                         @Param("questionId") String questionId, @Param("examRecordId") Integer examRecordId);

    /**
     * 只返回题目id和题号信息，给试卷详情用
     *
     * @param testPaperId
     * @param questionId
     * @return
	 */
	List<QuestionVO> selectChildQuestionBaseInfo(@Param("testPaperId") Integer testPaperId,
			@Param("questionId") String questionId);

	List<SelfCheckQuestionVO> selectSelfCheckChildQuestion(@Param("testPaperId") Integer testPaperId,
			@Param("questionId") String questionId);

	List<QuestionLibrary> selectChildByParentId(@Param("pid") String pid);

	/**
	 * 复合题考试记录答案
	 * @return
	 */
	List<QuestionVO> getCQTExamRecordByQuestionId(@Param("testPaperId") Integer testPaperId,@Param("examRecordId") Integer examRecordId,@Param("questionId") String questionId);
	/**
	 * 考试记录答案
	 * @return
	 */
	QuestionVO getExamRecordByQuestionId(@Param("examRecordId") Integer examRecordId,@Param("questionId") String questionId);
}
