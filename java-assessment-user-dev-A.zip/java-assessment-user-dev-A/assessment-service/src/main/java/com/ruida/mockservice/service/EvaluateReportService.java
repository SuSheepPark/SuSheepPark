package com.ruida.mockservice.service;

import com.ruida.mockcommon.result.Page;
import com.ruida.mockdao.vo.report.EvaluateReportVO;
import com.ruida.mockdao.vo.report.UpgradeReportRecordVO;

/**
 * @description:
 * @author: kgz
 * @date: 2020/12/15
 */
public interface EvaluateReportService {
    /**
     * 报告列表
     * @return
     * @param pageNum
     * @param pageSize
     * @param keyWords
     */
    Page<UpgradeReportRecordVO> getEvaluateReportList(Integer pageNum, Integer pageSize, String keyWords);


    /**
     * 获取升学选拔报告详情
     * type，0-过程性报告，1-综合报告
     * @param reportId
     * @param type
     * @return
     */
    EvaluateReportVO getEvaluateReportDetail(Integer reportId, Integer type);

    /**
     * 生成测试数据
     * @return
     */
    EvaluateReportVO setEvaluateReportDetailForTest();
}
