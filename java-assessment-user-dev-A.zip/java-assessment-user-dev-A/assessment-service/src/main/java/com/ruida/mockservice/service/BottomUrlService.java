package com.ruida.mockservice.service;


import com.baomidou.mybatisplus.service.IService;
import com.ruida.mockdao.model.BottomUrl;

import java.util.List;

/**
 * <p>
 * PC端底部网站链接表 服务类
 * </p>
 *
 * @author Bhj
 * @since 2020-08-07
 */
public interface BottomUrlService extends IService<BottomUrl> {

    List<BottomUrl> listBottomUrl(Integer column);

    BottomUrl getBottomUrl(Integer bottomUrlId);
}
