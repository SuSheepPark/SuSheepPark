package com.ruida.assessment.assessmentcommon.enums;

/**
 * @description:
 * @author: kgz
 * @date: 2020/7/23
 */
public enum AuthFilterEnum {
    NOT_FILTER(0,"不过滤"),
    FILTER(1,"过滤"),
    ;


    private Integer K;
    private String V;

    AuthFilterEnum(Integer k, String v) {
        K = k;
        V = v;
    }

    public Integer getK() {
        return K;
    }

    public void setK(Integer k) {
        K = k;
    }

    public String getV() {
        return V;
    }

    public void setV(String v) {
        V = v;
    }

    public static AuthFilterEnum getValueById(Integer K){
        for(AuthFilterEnum authFilterEnum : AuthFilterEnum.values() ){
            if(authFilterEnum.getK().equals(K)){
                return  authFilterEnum;
            }
        }
        return null;
    }
}
