package com.ruida.mockdao.model;

import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 实施计划表
 * </p>
 *
 * @author szl
 * @since 2021-07-22
 */
@TableName("t_implement_plan")
public class TImplementPlan extends Model<TImplementPlan> {

    private static final long serialVersionUID = 1L;

    /**
     * 计划id
     */
    @TableId(value = "plan_id", type = IdType.UUID)
    private String planId;

    /**
     * 计划名称
     */
    @TableField("plan_name")
    private String planName;

    /**
     * 产品id
     */
    @TableField("product_id")
    private Integer productId;

    /**
     * 是否生成总报告 0-否 1-是
     */
    @TableField("gen_report")
    private Integer genReport;

    /**
     * 考试产品类型, 1-模拟练习 2-在线统考 3-初中联考 4-高中联考
     */
    @TableField("test_type")
    private Integer testType;
    /**
     * 批改方式
     */
    @TableField("correct_type")
    private Integer correctType;
    /**
     * 测评前页id
     */
    @TableField("home_page_id")
    private Integer homePageId;
    /**
     * 报告生成方式
     */
    @TableField("report_create_type")
    private Integer reportCreateType;
    /**
     * 实施组织
     */
    @TableField("implement_org")
    private Integer implementOrg;
    /**
     * 开始时间
     */
    @TableField("start_time")
    private Date startTime;
    /**
     * 结束时间
     */
    @TableField("end_time")
    private Date endTime;
    /**
     * 创建时间
     */
    @TableField("create_time")
    private Date createTime;
    /**
     * 创建人
     */
    @TableField("create_by")
    private Integer createBy;
    /**
     * 更新时间
     */
    @TableField("update_time")
    private Date updateTime;
    /**
     * 更新人id
     */
    @TableField("update_by")
    private Integer updateBy;
    /**
     * 逻辑删除（0 存在， 1 已删除）
     */
    private Integer isdelete;


    public String getPlanId() {
        return planId;
    }

    public void setPlanId(String planId) {
        this.planId = planId;
    }

    public String getPlanName() {
        return planName;
    }

    public void setPlanName(String planName) {
        this.planName = planName;
    }

    public Integer getGenReport() {
        return genReport;
    }

    public void setGenReport(Integer genReport) {
        this.genReport = genReport;
    }

    public Integer getProductId() {
        return productId;
    }

    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    public Integer getTestType() {
        return testType;
    }

    public void setTestType(Integer testType) {
        this.testType = testType;
    }

    public Integer getCorrectType() {
        return correctType;
    }

    public void setCorrectType(Integer correctType) {
        this.correctType = correctType;
    }

    public Integer getHomePageId() {
        return homePageId;
    }

    public void setHomePageId(Integer homePageId) {
        this.homePageId = homePageId;
    }

    public Integer getReportCreateType() {
        return reportCreateType;
    }

    public void setReportCreateType(Integer reportCreateType) {
        this.reportCreateType = reportCreateType;
    }

    public Integer getImplementOrg() {
        return implementOrg;
    }

    public void setImplementOrg(Integer implementOrg) {
        this.implementOrg = implementOrg;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getCreateBy() {
        return createBy;
    }

    public void setCreateBy(Integer createBy) {
        this.createBy = createBy;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(Integer updateBy) {
        this.updateBy = updateBy;
    }

    public Integer getIsdelete() {
        return isdelete;
    }

    public void setIsdelete(Integer isdelete) {
        this.isdelete = isdelete;
    }

    @Override
    protected Serializable pkVal() {
        return this.planId;
    }

    @Override
    public String toString() {
        return "TImplementPlan{" +
                "planId='" + planId + '\'' +
                ", planName='" + planName + '\'' +
                ", productId=" + productId +
                ", genReport=" + genReport +
                ", testType=" + testType +
                ", correctType=" + correctType +
                ", homePageId=" + homePageId +
                ", reportCreateType=" + reportCreateType +
                ", implementOrg=" + implementOrg +
                ", startTime=" + startTime +
                ", endTime=" + endTime +
                ", createTime=" + createTime +
                ", createBy=" + createBy +
                ", updateTime=" + updateTime +
                ", updateBy=" + updateBy +
                ", isdelete=" + isdelete +
                '}';
    }
}
