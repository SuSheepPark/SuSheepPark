package com.ruida.assessment.assessmentquestionbank.annotaion;

import com.ruida.assessment.assessmentcommon.enums.OperateModuleEnum;
import com.ruida.assessment.assessmentcommon.enums.OperateTypeEnum;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * @description: 业务日志
 * @author: kgz
 * @date: 2020/8/11
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface OperateLog {
    /**
     * 模块
     * @return
     */
    OperateModuleEnum module();

    /**
     * 操作类型
     * @return
     */
    OperateTypeEnum operateType();
}

