package com.ruida.mockservice.service.impl;

import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.ruida.mockcommon.auth.context.BaseContextHandle;
import com.ruida.mockcommon.auth.pojo.JWTInfo;
import com.ruida.mockcommon.enums.AppErrorEnum;
import com.ruida.mockcommon.exception.CoreException;
import com.ruida.mockdao.dao.ExamRecordMapper;
import com.ruida.mockdao.model.ExamRecord;
import com.ruida.mockdao.vo.ExamRecordVO;
import com.ruida.mockservice.service.ExamRecordService;
import org.springframework.stereotype.Service;

import java.util.Arrays;

import javax.annotation.Resource;

/**
 * <p>
 * 考试记录表 服务实现类
 * </p>
 *
 * @author chenjy
 * @since 2020-07-15
 */
@Service
public class ExamRecordServiceImpl extends ServiceImpl<ExamRecordMapper, ExamRecord> implements ExamRecordService {

    @Resource
    ExamRecordMapper examRecordMapper;

    @Override
    public ExamRecordVO queryLatestExamInfo() {
        JWTInfo jwt = BaseContextHandle.getJWTInfo();
        if(jwt == null){
            throw new CoreException(AppErrorEnum.E_10018);
        }
        return examRecordMapper.queryLatestExamInfo(jwt.getUserId(),new Integer[] {0});
    }
}
