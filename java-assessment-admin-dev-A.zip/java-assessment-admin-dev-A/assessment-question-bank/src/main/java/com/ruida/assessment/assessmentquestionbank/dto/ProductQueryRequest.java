package com.ruida.assessment.assessmentquestionbank.dto;

import com.ruida.assessment.assessmentcommon.result.Page;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

/**
 * @author wy
 * @description 查询商品请求类
 * @date 2020/6/24
 */
@Data
public class ProductQueryRequest {


    private static final String PRODUCT_NO_REGEX = "^P(\\d{12})$";

    /*
       商品id
     */
    private Integer productId;

    private String productName;
    private String productNo;
    /*
     模糊查询字段  商品号或商品名称
     */
    private String searchWord;

    /*
   商品类型  是否是套卷 0-试卷 1-套卷
     */
//    private Integer iscompose;

    /*
        商品状态 0-已下架 1-已上架
     */
    private Integer status;

    /*
    价格区间 起
     */
    private BigDecimal priceStart;

    /*
    价格区间 止
     */
    private BigDecimal priceEnd;

    /*
    学段id
     */
    private Integer periodId;

    /*
    科目id
     */
    private Integer subjectId;
    private String subjectName;

    /*
    教材版本id
     */
    private Integer versionId;

    /*
    年级id
     */
    private Integer gradeId;

    /*
    年份
     */
    private String year;

    /*
   考试类型
    */
//    private Integer testType;

    /*
    试卷类型
     */
//    private Integer testPaperType;

    /*
    难度
     */
//    private Integer difficulty;

    /*是否设置置顶 0-未置顶 1-已置顶*/
    private Integer top;

    /*
        排序字段  默认创建时间排序倒序     */
    private String  orderStr = "product_no";

    /*
        排序方式 0-降序 1-升序 默认创建时间排序倒序
     */
    private Integer orderType = 0;

    private Page page;

    /*分页*/
    private Integer start;
    private Integer size;


    private Integer isdelete = 0;

    private List<Integer> ids;

    private Integer userId;
    private List<Integer> outIds;//赠送学员商品，查询商品列表时 不需要展示的商品id集合

    /*测验形式(0-平时练习 1-纸考(线下联考) 2-机房统考 3-在线统考)*/
    private Integer productTestWay;

    /*是否隐藏 0-否 1-是*/
    private Integer ishide;

    /*是否预售 0-否 1-是*/
//    private Integer ispresell;
    /**
     * 使用类型
     */
    @ApiModelProperty(value = "使用类型（0 科目选考-成绩测试推荐位置使用;）", name = "useType")
    private Integer useType;

    /* 地区id */
    @ApiModelProperty(value = "地区id", name = "parentId")
    private Integer parentId;

    /* 学校id */
    @ApiModelProperty(value = "学校id", name = "schoolId")
    private Integer schoolId;


    /* 班级id */
    @ApiModelProperty(value = "班级id", name = "classId")
    private Integer classId;


    @ApiModelProperty(value = "注册时间-开始时间", name = "startTime")
    private String startTime;

    @ApiModelProperty(value = "注册时间-结束时间", name = "endTime")
    private String endTime;



    private void setSearchWord(String searchWord){
        //正则匹配 查询的是商品号还是商品名称
        if(searchWord.matches(PRODUCT_NO_REGEX)){
            this.setProductNo(searchWord);
        }else{
            this.setProductName(searchWord);
        }
        this.searchWord = searchWord;
    }
}
