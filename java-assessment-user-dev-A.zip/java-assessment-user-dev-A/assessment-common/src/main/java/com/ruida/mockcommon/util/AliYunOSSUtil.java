package com.ruida.mockcommon.util;

import com.aliyun.oss.OSS;
import com.aliyun.oss.OSSClient;
import com.aliyun.oss.OSSClientBuilder;
import com.aliyun.oss.model.ObjectMetadata;
import com.aliyun.oss.model.PutObjectRequest;
import com.aliyuncs.DefaultAcsClient;
import com.aliyuncs.exceptions.ClientException;
import com.aliyuncs.http.MethodType;
import com.aliyuncs.profile.DefaultProfile;
import com.aliyuncs.profile.IClientProfile;
import com.aliyuncs.sts.model.v20150401.AssumeRoleRequest;
import com.aliyuncs.sts.model.v20150401.AssumeRoleResponse;
import com.ruida.mockcommon.enums.AppErrorEnum;
import com.ruida.mockcommon.exception.CoreException;
import lombok.extern.slf4j.Slf4j;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author xumingqi
 * @date 2020/12/16 17:22
 */
@Slf4j
public class AliYunOSSUtil {
    //临时凭证存活时间
    private static final Long durationSeconds = 3600L;

    /**
     * 获取OSS实例
     *
     * @param endpoint
     * @param accessKeyId
     * @param accessKeySecret
     * @return
     */
    public static OSS getOssClient(String endpoint, String accessKeyId, String accessKeySecret) {
        OSS ossClient = new OSSClientBuilder().build(endpoint, accessKeyId, accessKeySecret);
        return ossClient;
    }

    /**
     * 获取stsOSS实例
     *
     * @param endpoint
     * @param keyId
     * @param keySecret
     * @param securityToken
     * @return
     */
    public static OSS getOssClient(String endpoint, String keyId, String keySecret, String securityToken) {
        OSS ossClient = new OSSClient(endpoint, keyId, keySecret, securityToken);
        return ossClient;
    }

    public static String uploadFile(File file, String fileName, OSS ossClient, String bucketName) {
        // 上传文件到指定的存储空间（bucketName）并将其保存为指定的文件名称（objectName）。
        ossClient.putObject(bucketName, fileName, file);
        Date expiration = DateUtil.addMonths(new Date(), 48);
        String url = ossClient.generatePresignedUrl(bucketName, fileName, expiration).toString();
        // 关闭OSSClient
        ossClient.shutdown();
        return url;
    }

    public static String uploadFile(InputStream inputStream, String fileName, OSS ossClient, String bucketName) {

        // 上传文件到指定的存储空间（bucketName）并将其保存为指定的文件名称（objectName）。
        ossClient.putObject(bucketName, fileName, inputStream);
        Date expiration = DateUtil.addMonths(new Date(), 48);
        String url = ossClient.generatePresignedUrl(bucketName, fileName, expiration).toString();
        // 关闭OSSClient
        ossClient.shutdown();
        return url;
    }

    public static String uploadPic(InputStream inputStream, String fileName, OSS ossClient, String bucketName) throws IOException {
        //创建上传Object的Metadata
        ObjectMetadata objectMetadata = new ObjectMetadata();
        objectMetadata.setContentLength(inputStream.available());
        objectMetadata.setCacheControl("no-cache");
        objectMetadata.setHeader("Pragma", "no-cache");
        objectMetadata.setContentType(getContentType(fileName.substring(fileName.lastIndexOf("."))));
        objectMetadata.setContentDisposition("inline;filename=" + fileName);
        //上传文件
        ossClient.putObject(bucketName, fileName, inputStream, objectMetadata);
        Date expiration = DateUtil.addMonths(new Date(), 48);
        String url = ossClient.generatePresignedUrl(bucketName, fileName, expiration).toString();
        // 关闭OSSClient
        ossClient.shutdown();
        return url;
    }

    public static String getContentType(String FilenameExtension) {
        if (FilenameExtension.equalsIgnoreCase(".bmp")) {
            return "image/bmp";
        }
        if (FilenameExtension.equalsIgnoreCase(".gif")) {
            return "image/gif";
        }
        if (FilenameExtension.equalsIgnoreCase(".jpeg") ||
                FilenameExtension.equalsIgnoreCase(".jpg") ||
                FilenameExtension.equalsIgnoreCase(".png")) {
            return "image/jpg";
        }
        if (FilenameExtension.equalsIgnoreCase(".html")) {
            return "text/html";
        }
        if (FilenameExtension.equalsIgnoreCase(".txt")) {
            return "text/plain";
        }
        if (FilenameExtension.equalsIgnoreCase(".vsd")) {
            return "application/vnd.visio";
        }
        if (FilenameExtension.equalsIgnoreCase(".pptx") ||
                FilenameExtension.equalsIgnoreCase(".ppt")) {
            return "application/vnd.ms-powerpoint";
        }
        if (FilenameExtension.equalsIgnoreCase(".docx") ||
                FilenameExtension.equalsIgnoreCase(".doc")) {
            return "application/msword";
        }
        if (FilenameExtension.equalsIgnoreCase(".xml")) {
            return "text/xml";
        }
        return "image/jpg";
    }

    /**
     * 获取临时用户凭据
     *
     * @return
     */
    public static Map<String, String> getTempTickey(String stsEndpoint, String stsAccessKeyId, String stsAccessKeySecret,
                                                    String stsProduct, String roleArn, String roleSessionName) {
        Map<String, String> resultMap = new HashMap<>(4);
        // STS接入地址，例如sts.cn-hangzhou.aliyuncs.com。
        String endpoint = stsEndpoint;
        // 填写步骤1生成的访问密钥AccessKey ID和AccessKey Secret。
        String AccessKeyId = stsAccessKeyId;
        String accessKeySecret = stsAccessKeySecret;
        // 填写步骤3获取的角色ARN。
        try {
            // 添加endpoint。
            DefaultProfile.addEndpoint("", "", stsProduct, endpoint);
            // 构造default profile。
            IClientProfile profile = DefaultProfile.getProfile("", AccessKeyId, accessKeySecret);
            // 构造client。
            DefaultAcsClient client = new DefaultAcsClient(profile);
            final AssumeRoleRequest request = new AssumeRoleRequest();
            request.setMethod(MethodType.POST);
            request.setRoleArn(roleArn);
            request.setRoleSessionName(roleSessionName);
//            request.setPolicy(policy); // 如果policy为空，则用户将获得该角色下所有权限。
            request.setDurationSeconds(durationSeconds); // 设置临时访问凭证的有效时间为3600秒。
            final AssumeRoleResponse response = client.getAcsResponse(request);
            resultMap.put("KeyId", response.getCredentials().getAccessKeyId());
            resultMap.put("KeySecret", response.getCredentials().getAccessKeySecret());
            resultMap.put("SecurityToken", response.getCredentials().getSecurityToken());
        } catch (ClientException e) {
            log.error("aliyunOSSUtil-getTempTickey()异常:" + e.getErrMsg());
        }
        return resultMap;
    }

    /**
     * 上传文件（私有桶）
     *
     * @param inputStream
     * @param fileName
     */
    public static void upload(InputStream inputStream, String fileName, String uploadPath, OSS ossClient, String stsBucketName) {
        // 创建上传文件的元信息，可以通过文件元信息设置HTTP header。
        ObjectMetadata meta = new ObjectMetadata();
//        meta.setContentType("application/pdf");
        // 设置内容被下载时的名称。
        try {
            meta.setContentDisposition("attachment;filename=" + java.net.URLEncoder.encode(fileName, "UTF-8"));
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
            throw new CoreException(AppErrorEnum.E_10053);
        }
        // 设置内容被下载时的编码格式。
        meta.setContentEncoding("utf-8");
// 将本地文件exampletest.txt上传至目标存储空间examplebucket下的目录exampledir。
        PutObjectRequest putObjectRequest = new PutObjectRequest(stsBucketName, uploadPath, inputStream, meta);
// 上传文件。
        ossClient.putObject(putObjectRequest);
// 关闭OSSClient。
        ossClient.shutdown();
    }


    /**
     * 获取文件下载url
     *
     * @param objectName
     * @return
     */
    public static String getURL(String objectName, OSS ossClient, String stsBucketName) {
        // 设置签名URL过期时间9分钟。
        Date expiration = new Date(new Date().getTime() + 540 * 1000);
        // 生成以GET方法访问的签名URL，访客可以直接通过浏览器访问相关内容。
        URL url = ossClient.generatePresignedUrl(stsBucketName, objectName, expiration);
        // 关闭OSSClient。
        ossClient.shutdown();
        return url.toString();
    }

    /**
     * 开放桶上传
     *
     * @param inputStream
     * @param fileName
     * @return
     */
    public static void uploadOpenBucket(InputStream inputStream, String fileName, String uploadPath, OSS ossClient, String bucketName) {
        // 创建上传文件的元信息，可以通过文件元信息设置HTTP header。
        ObjectMetadata meta = new ObjectMetadata();
        // 设置内容被下载时的名称。
        try {
            meta.setContentDisposition("attachment;filename=" + java.net.URLEncoder.encode(fileName, "UTF-8"));
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
            throw new CoreException(AppErrorEnum.E_10053);
        }
        // 设置内容被下载时的编码格式。
        meta.setContentEncoding("utf-8");
        // 上传文件到指定的存储空间（bucketName）并将其保存为指定的文件名称（objectName）。
        ossClient.putObject(bucketName, uploadPath, inputStream, meta);
        // 关闭OSSClient
        ossClient.shutdown();
    }

    /**
     * 获取共有桶文件下载url
     *
     * @param objectName
     * @return
     */
    public static String getOpenBucketURL(String objectName, OSS ossClient, String bucketName) {
        // 设置签名URL过期时间为1个月。
        Date expiration = DateUtil.addMonths(new Date(), 1);
        String url = ossClient.generatePresignedUrl(bucketName, objectName, expiration).toString();
        // 关闭OSSClient。
        ossClient.shutdown();
        return url.toString();
    }
}
