package com.ruida.cloud.dao;

import com.ruida.cloud.model.StudentRelInfo;
import com.ruida.cloud.model.StudentRelInfoExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface StudentRelInfoMapper {
    int countByExample(StudentRelInfoExample example);

    int deleteByExample(StudentRelInfoExample example);

    int deleteByPrimaryKey(Integer rid);

    int insert(StudentRelInfo record);

    int insertSelective(StudentRelInfo record);

    List<StudentRelInfo> selectByExample(StudentRelInfoExample example);

    StudentRelInfo selectByPrimaryKey(Integer rid);

    int updateByExampleSelective(@Param("record") StudentRelInfo record, @Param("example") StudentRelInfoExample example);

    int updateByExample(@Param("record") StudentRelInfo record, @Param("example") StudentRelInfoExample example);

    int updateByPrimaryKeySelective(StudentRelInfo record);

    int updateByPrimaryKey(StudentRelInfo record);
}