package com.ruida.mockdao.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.model.TSubjectInterestQuestion;

/**
 * <p>
 * 科目兴趣调查文件试题 Mapper 接口
 * </p>
 *
 * @author 
 * @since 2021-01-11
 */
public interface SubjectInterestQuestionMapper extends BaseMapper<TSubjectInterestQuestion> {

}
