package com.ruida.mockdao.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.model.ExamImage;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author chenjy
 * @since 2020-07-14
 */
public interface ExamImageMapper extends BaseMapper<ExamImage> {

}
