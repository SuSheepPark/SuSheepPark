package com.ruida.cloud.dao;

import java.util.List;
import java.util.Map;

public interface DistributorMapperExt {
    List<Map<String, Object>> listSuperDistributor();

    List<Map<String, Object>> listSecondaryDistributor(Integer fid);

    List<Map<String, Object>> listAllDistributor();
}