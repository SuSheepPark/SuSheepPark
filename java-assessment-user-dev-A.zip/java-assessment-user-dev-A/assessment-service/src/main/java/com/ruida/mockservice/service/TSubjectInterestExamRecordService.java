package com.ruida.mockservice.service;

import com.baomidou.mybatisplus.service.IService;
import com.ruida.mockdao.model.TSubjectInterestExamRecord;

/**
 * <p>
 * 科目兴趣调查的答卷 服务类
 * </p>
 *
 * @author 
 * @since 2021-01-11
 */
public interface TSubjectInterestExamRecordService extends IService<TSubjectInterestExamRecord> {

	void upload(TSubjectInterestExamRecord record);
	
	String getNameById(String id);
}
