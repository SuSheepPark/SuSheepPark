package com.ruida.cloud.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ruida.common.SystemConstant;
import com.ruida.common.util.excel.ExcelAnnotation;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class Order implements Serializable {
    /**
     * 订单主键ID
     */
    private Integer orderId;

    /**
     * 订单编号
     */
    @ExcelAnnotation(title = "订单编号")
    private String orderNo;

    /**
     * 订单交易号
     */
    private String orderTransNo;

    /**
     * 主讲老师（行转列）
     */
    private String teacherName;
    /**
     * 辅课老师名字
     */
    private String assistantTeacherName;

    /**
     * 订单名称
     */
    @ExcelAnnotation(title = "订单名称")
    private String orderName;

    /**
     * 订单金额
     */
    @ExcelAnnotation(title = "订单金额")
    private BigDecimal orderAmount;

    /**订单真实金额*/
    private BigDecimal realOrderAmount;

    /**
     * 实付金额
     */
    private BigDecimal payAmount;

    /**
     * 实付金额
     */
    private BigDecimal saleAmount;

    /**
     * 购买人ID（关联sys_user表的user_id）
     */
    private Integer purchaserId;

    /**
     * 购买人联系电话
     */
    private String telephone;

    /**
     * 支付方式（0—微信支付；1—支付宝；2—Q钱包；3—网银支付）
     */
    private Byte paymentType;

    /**
     * 订单状态（0—待支付；1—已支付；2—已关闭）
     */
    private Byte status;

    /**
     * 订单来源（0—PC端；1—IOS端；2—Android端）
     */
    private Byte source;

    /**
     * 订单创建时间
     */
    @JsonFormat(pattern=SystemConstant.DATE_FORMAT,timezone=SystemConstant.TIME_ZONE)
    private Date createTime;

    /**
     * 订单更新时间
     */
    @JsonFormat(pattern= SystemConstant.DATE_FORMAT,timezone=SystemConstant.TIME_ZONE)
    private Date updateTime;

    /**
     * 订单付款时间
     */
    @JsonFormat(pattern=SystemConstant.DATE_FORMAT,timezone=SystemConstant.TIME_ZONE)
    private Date paymentTime;

    /**
     * 交易完成时间（保留字段，暂时不使用）
     */
    @JsonFormat(pattern=SystemConstant.DATE_FORMAT,timezone=SystemConstant.TIME_ZONE)
    private Date endTime;

    /**
     * 交易关闭时间
     */
    @JsonFormat(pattern=SystemConstant.DATE_FORMAT,timezone=SystemConstant.TIME_ZONE)
    private Date closeTime;

    /**
     * 是否删除（0：未删除；1：删除）
     */
    private Byte isdelete;

    private String purchaserName;

    private Integer campusId;

    private Integer recommendCampusId;

    private String shopCartNo;

    private byte orderType;

    private String paymentAccount;

    public BigDecimal getRealOrderAmount() {
        return realOrderAmount;
    }

    public void setRealOrderAmount(BigDecimal realOrderAmount) {
        this.realOrderAmount = realOrderAmount;
    }

    public String getPaymentAccount() {
        return paymentAccount;
    }

    public void setPaymentAccount(String paymentAccount) {
        this.paymentAccount = paymentAccount;
    }

    public Integer getRecommendCampusId() {
        return recommendCampusId;
    }

    public void setRecommendCampusId(Integer recommendCampusId) {
        this.recommendCampusId = recommendCampusId;
    }

    public byte getOrderType() {
        return orderType;
    }

    public void setOrderType(byte orderType) {
        this.orderType = orderType;
    }

    public String getShopCartNo() {
        return shopCartNo;
    }

    public void setShopCartNo(String shopCartNo) {
        this.shopCartNo = shopCartNo;
    }

    public Integer getCampusId() {
        return campusId;
    }

    public void setCampusId(Integer campusId) {
        this.campusId = campusId;
    }

    public String getPurchaserName() {
        return purchaserName;
    }

    public void setPurchaserName(String purchaserName) {
        this.purchaserName = purchaserName;
    }

    public BigDecimal getSaleAmount() {
        return saleAmount;
    }

    public void setSaleAmount(BigDecimal saleAmount) {
        this.saleAmount = saleAmount;
    }

    public Integer getOrderId() {
        return orderId;
    }

    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo == null ? null : orderNo.trim();
    }

    public String getOrderTransNo() {
        return orderTransNo;
    }

    public void setOrderTransNo(String orderTransNo) {
        this.orderTransNo = orderTransNo == null ? null : orderTransNo.trim();
    }

    public String getTeacherName() {
        return teacherName;
    }

    public void setTeacherName(String teacherId) {
        this.teacherName = teacherId == null ? null : teacherId.trim();
    }

    public String getOrderName() {
        return orderName;
    }

    public void setOrderName(String orderName) {
        this.orderName = orderName == null ? null : orderName.trim();
    }

    public BigDecimal getOrderAmount() {
        return orderAmount;
    }

    public void setOrderAmount(BigDecimal orderAmount) {
        this.orderAmount = orderAmount;
    }

    public BigDecimal getPayAmount() {
        return payAmount;
    }

    public void setPayAmount(BigDecimal payAmount) {
        this.payAmount = payAmount;
    }

    public Integer getPurchaserId() {
        return purchaserId;
    }

    public void setPurchaserId(Integer purchaserId) {
        this.purchaserId = purchaserId;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone == null ? null : telephone.trim();
    }

    public Byte getPaymentType() {
        return paymentType;
    }

    public void setPaymentType(Byte paymentType) {
        this.paymentType = paymentType;
    }

    public Byte getStatus() {
        return status;
    }

    public void setStatus(Byte status) {
        this.status = status;
    }

    public Byte getSource() {
        return source;
    }

    public void setSource(Byte source) {
        this.source = source;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Date getPaymentTime() {
        return paymentTime;
    }

    public void setPaymentTime(Date paymentTime) {
        this.paymentTime = paymentTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public Date getCloseTime() {
        return closeTime;
    }

    public void setCloseTime(Date closeTime) {
        this.closeTime = closeTime;
    }

    public Byte getIsdelete() {
        return isdelete;
    }

    public void setIsdelete(Byte isdelete) {
        this.isdelete = isdelete;
    }

    public String getAssistantTeacherName() {
        return assistantTeacherName;
    }

    public void setAssistantTeacherName(String assistantTeacherName) {
        this.assistantTeacherName = assistantTeacherName;
    }
}
