package com.ruida.mockservice.service;


import com.baomidou.mybatisplus.service.IService;
import com.ruida.mockdao.model.RotationChart;

import java.util.List;

/**
 * <p>
 * 轮播图表 服务类
 * </p>
 *
 * @author Bhj
 * @since 2020-07-10
 */
public interface RotationChartService extends IService<RotationChart> {
    /**
     * 获取banner列表
     *
     * @param locationType 位置类型(1-首页banner)
     * @param source       使用端口(0-web端;1-app端;2-小程序端)
     */
    List<RotationChart> getRotationList(Integer locationType, Integer source);
}
