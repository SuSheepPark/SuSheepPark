package com.ruida.cloud.model;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Objects;

/**
 * @description: 佣金扩展类
 * @author: chenjy
 * @create: 2020-04-16 11:43
 */
@Data
public class CommissionExt implements Serializable {

    /**
     * 一级分销商id
     */
    private Integer distributorLevelOne;

    /**
     * 一级分销商名称
     */
    private String distributorLevelOneName;

    /**
     * 一级分销商佣金比例
     */
    private BigDecimal distributorLevelOneRate;

    /**
     * 二级分销商id
     */
    private Integer distributorLevelTwo;

    /**
     * 二级分销商名称
     */
    private String distributorLevelTwoName;

    /**
     * 二级分销商佣金比例
     */
    private BigDecimal distributorLevelTwoRate;

    /**
     * 一级分销商自身佣金
     */
    private BigDecimal distributorLevelOneRateSelf;

    @Override
    public boolean equals(Object o) {
        if (this == o) {return true;}
        if (o == null || getClass() != o.getClass()) {return false;}
        CommissionExt that = (CommissionExt) o;

        if( null == distributorLevelTwo ){
            return that.distributorLevelOne.equals(distributorLevelOne);
        }else {
            return that.distributorLevelTwo.equals(distributorLevelTwo);
        }
    }

    @Override
    public int hashCode() {
        if( null == distributorLevelTwo ){
            return Objects.hash(distributorLevelOne);
        }else {
            return Objects.hash(distributorLevelTwo);
        }
    }
}
