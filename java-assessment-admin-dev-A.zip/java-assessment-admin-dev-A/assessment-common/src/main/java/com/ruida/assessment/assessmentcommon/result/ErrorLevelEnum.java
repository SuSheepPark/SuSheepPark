package com.ruida.assessment.assessmentcommon.result;
/**
 * @description:
 * @author szl
 * @Date 2018年12月10日
 * @verion 1.0
 */
public enum ErrorLevelEnum {

	
	FAULT("fault", "确认"),
 
	ERROR("error", "错误"),
 
	WARN("warn", "警告"),
 
	INFO("info", "info");

    private String value;

    private String desc;

    private ErrorLevelEnum(String value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public static ErrorLevelEnum findByValue(String value) {
        for (ErrorLevelEnum c : ErrorLevelEnum.values()) {
            if (value.equals(c.getValue())) {
                return c;
            }
        }
        return null;
    }


}
