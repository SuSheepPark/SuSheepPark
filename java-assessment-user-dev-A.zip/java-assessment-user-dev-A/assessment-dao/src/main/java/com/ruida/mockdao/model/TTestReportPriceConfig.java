package com.ruida.mockdao.model;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.FieldStrategy;

import java.io.Serializable;

/**
 * @description: 测试、报告价格设置数据库实体
 * @author: kgz
 * @date: 2021/1/13
 */
@TableName("t_test_report_price_config")
public class TTestReportPriceConfig extends BaseColumn implements Serializable {
    /**
     * 主键id
     */
    @TableId
    private Integer id;

    /**
     * 价格设置名称
     */
//    @TableField(exist = false)
    private String name;

    /**
     * 价格设置类型
     * 0-霍兰德测试价格设置， 1-霍兰德测试报告价格设置，2-科目选考推荐科目组合报告价格设置，3-志愿填报报告价格设置
     */
//    @TableField(exist = false)
    private Integer type;

    /**
     * 售价
     */
    @TableField(strategy = FieldStrategy.IGNORED)
    private Double price;

    /**
     * 原价
     */
    @TableField(strategy = FieldStrategy.IGNORED)
    private Double originPrice;

    /**
     * IOS价格
     */
    @TableField(strategy = FieldStrategy.IGNORED)
    private Double iosPrice;

    /**
     * 是否免费 0-否 1-是
     */
    private Integer isfree;
    /**
     * 初始化人数
     */
    @TableField(strategy = FieldStrategy.IGNORED)
    private Integer initialUserNum;
    /**
     * 状态（0—禁用；1—启用）
     */
    private Integer status;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public Double getOriginPrice() {
        return originPrice;
    }

    public void setOriginPrice(Double originPrice) {
        this.originPrice = originPrice;
    }

    public Double getIosPrice() {
        return iosPrice;
    }

    public void setIosPrice(Double iosPrice) {
        this.iosPrice = iosPrice;
    }

    public Integer getIsfree() {
        return isfree;
    }

    public void setIsfree(Integer isfree) {
        this.isfree = isfree;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getInitialUserNum() {
        return initialUserNum;
    }

    public void setInitialUserNum(Integer initialUserNum) {
        this.initialUserNum = initialUserNum;
    }

    @Override
    public String toString() {
        return "TTestReportPriceConfig{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", type=" + type +
                ", price=" + price +
                ", originPrice=" + originPrice +
                ", iosPrice=" + iosPrice +
                ", isfree=" + isfree +
                ", status=" + status +
                '}';
    }
}
