package com.ruida.assessment.assessmentquestionbank.dto;

import com.ruida.assessment.assessmentcommon.result.Page;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
@Data
@ApiModel(description = "班级学生信息")
public class ClassStuDTO implements Serializable {
    private static final long serialVersionUID = 1L;
    @ApiModelProperty(value = "学段", name = "periodId")
    private Integer periodId;
    @ApiModelProperty(value = "年级", name = "gradeId")
    private Integer gradeId;
    @ApiModelProperty(value = "班级id", name = "classId")
    private Integer classId;
    @ApiModelProperty(value = "分页对象", name = "page")
    private Page page;
}
