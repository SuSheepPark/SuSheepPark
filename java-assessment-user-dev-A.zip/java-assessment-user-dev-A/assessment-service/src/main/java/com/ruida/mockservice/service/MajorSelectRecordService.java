package com.ruida.mockservice.service;

import com.baomidou.mybatisplus.service.IService;
import com.ruida.mockdao.model.MajorSelectRecord;
import com.ruida.mockdao.vo.major.MajorGroupVO;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * 专业兴趣选择记录 服务类
 * </p>
 *
 * @author xumingqi
 * @since 2021-01-14
 */
public interface MajorSelectRecordService extends IService<MajorSelectRecord> {
    Boolean submitLikeMajor(String majorCodes);

    Boolean checkHaveReport(Integer userId);

    Map<String, Object> getMyMajorReport(Integer userId);

    List<MajorGroupVO> getMajorReportInfo(Integer userId);

    /**
     * 根据记录id查询专业意向信息
     * @param recordId
     * @return
     */
    List<MajorGroupVO> getMajorReportInfoByRecordId(Integer recordId);
}
