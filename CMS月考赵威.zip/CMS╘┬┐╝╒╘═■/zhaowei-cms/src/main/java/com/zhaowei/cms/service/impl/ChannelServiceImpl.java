/**   
 * Copyright © 2019 公司名. All rights reserved.
 * 
 * @Title: ChannelServiceImpl.java 
 * @Prject: zhaowei-cms
 * @Package: com.zhaowei.cms.service.impl 
 * @Description: TODO
 * @author: zw   
 * @date: 2019年9月17日 下午8:40:46 
 * @version: V1.0   
 */
package com.zhaowei.cms.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.zhaowei.cms.dao.ChannelMapper;
import com.zhaowei.cms.domain.Channel;
import com.zhaowei.cms.service.ChannelService;

/** 
 * @ClassName: ChannelServiceImpl 
 * @Description: TODO
 * @author: zw
 * @date: 2019年9月17日 下午8:40:46  
 */
@Service
public class ChannelServiceImpl implements ChannelService {

	
	@Resource
	private ChannelMapper channelMapper;

	
	@Override
	public List<Channel> selects() {
		return channelMapper.selects();
	}

}
