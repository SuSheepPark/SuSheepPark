package com.ruida.cloud.weidu.service.impl.data;

import com.ruida.cloud.weidu.utils.PropertyUtil;
import com.ruida.cloud.weidu.utils.VdyooUtil;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * @author taosh
 * @create 2019-04-24 11:00
 */
@Service
public class VdyooClassCountService {
    private String vdyooPath = PropertyUtil.getProperty("vdyooTestApi");

    /**
     * 获取学生全部答题数据通过学生的ID来查询学生的答题情况
     */
    public void findClassCountByclassId(String classId){
        String path = vdyooPath+"/api/business/classcount/findClassCountByclassId";

        Map<String, String> param = VdyooUtil.getSignMap();

        //教学班id
        param.put("classId", classId);

//        String response = HttpClientUtil.postMap(path, param);
//        System.out.println(response);
    }

    /**
     * 通过教学班和题目 查出该班的这道题答题情况
     */
    public void findClassCountByClassIdByExamType(String classId, String examNum, String scheduleId){
        String path = vdyooPath+"/api/business/classcount/findClassCountByClassIdByExamType";

        Map<String, String> param = VdyooUtil.getSignMap();

        //教学班id
        param.put("classId", classId);
        //题号
        param.put("examNum", examNum);
        //计划Id
        param.put("scheduleId", scheduleId);

//        String response = HttpClientUtil.postMap(path, param);
//        System.out.println(response);
    }


    /**
     * 通过教学班和试题类型 查出该班的试题类型答题情况
     */
    public void findClassCountByClassIdByExamType(String classId, String examType){
        String path = vdyooPath+"/api/business/classcount/findClassCountByClassIdByExamType";

        Map<String, String> param = VdyooUtil.getSignMap();

        //教学班id
        param.put("classId", classId);
        //题型, 选择题:"choice",多选题:"mutichoice",填空题:"completion",选错题:"choosewrong",带分数填空题:"fraction"
        param.put("examType", examType);


//        String response = HttpClientUtil.postMap(path, param);
//        System.out.println(response);
    }

    /**
     * 通过教学班，试题类型，课表 查出 该班级在这个课表的试题类型答题情况
     */
    public void findClassCountByClassIdByExamTypeBySchedule(String classId, String examType, String scheduleId){
        String path = vdyooPath+"/api/business/classcount/findClassCountByClassIdByExamTypeBySchedule";

        Map<String, String> param = VdyooUtil.getSignMap();

        //教学班id
        param.put("classId", classId);
        //题型, 选择题:"choice",多选题:"mutichoice",填空题:"completion",选错题:"choosewrong",带分数填空题:"fraction"
        param.put("examType", examType);
        //计划id
        param.put("scheduleId", scheduleId);

//        String response = HttpClientUtil.postMap(path, param);
//        System.out.println(response);
    }

    /**
     * 通过教学班和课表 查出该班在这课表中的答题情况
     */
    public void findClassCountBySchedule(String classId, String scheduleId){
        String path = vdyooPath+"/api/business/classcount/findClassCountBySchedule";

        Map<String, String> param = VdyooUtil.getSignMap();

        //教学班id
        param.put("classId", classId);
        //计划id
        param.put("scheduleId", scheduleId);

//        String response = HttpClientUtil.postMap(path, param);
//        System.out.println(response);
    }
}
