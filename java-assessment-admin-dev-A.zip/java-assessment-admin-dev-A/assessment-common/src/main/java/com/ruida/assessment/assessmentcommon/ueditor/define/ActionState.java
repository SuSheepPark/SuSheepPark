package com.ruida.assessment.assessmentcommon.ueditor.define;

public enum ActionState {
	UNKNOW_ERROR
}
