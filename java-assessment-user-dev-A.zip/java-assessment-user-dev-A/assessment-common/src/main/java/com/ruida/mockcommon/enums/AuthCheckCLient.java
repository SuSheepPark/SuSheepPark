package com.ruida.mockcommon.enums;

/**
 * 名为不同的登录客户端，实际意义为区分登录逻辑，与AuthCheckType的区别的AuthCheckType控制权限，而本枚举类型只在请求接口时对应不同的验证逻辑
 * @author mazhuang
 *
 */
public enum AuthCheckCLient {
	WEB, // web登录
	WX// 小程序
}
