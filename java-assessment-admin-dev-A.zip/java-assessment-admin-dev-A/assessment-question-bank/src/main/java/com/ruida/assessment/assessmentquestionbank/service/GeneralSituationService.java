package com.ruida.assessment.assessmentquestionbank.service;

import com.ruida.assessment.assessmentquestionbank.dto.BasicDataDTO;
import com.ruida.assessment.assessmentquestionbank.vo.BasicDataVO;

import java.util.Map;

/**
 * @description:
 * @author: kgz
 * @date: 2020/8/5
 */
public interface GeneralSituationService {
    /**
     * 获取首页概况数据
     * @return
     * @param basicDataDTO
     */
    BasicDataVO getGeneralSituation(BasicDataDTO basicDataDTO);

    /**
     * 获取趋势图数据
     * @param basicDataDTO
     * @return
     */
    Map getTrendData(BasicDataDTO basicDataDTO);
}
