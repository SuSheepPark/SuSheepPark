package com.ruida.mockcommon.mq.consumer;


import com.aliyun.openservices.ons.api.Message;

public interface MQConsumeService{

    /**
     * 消费消息，消费成功返回true，消费失败返回false
     * @param message
     * @return
     */
    boolean consume(Message message);
}
