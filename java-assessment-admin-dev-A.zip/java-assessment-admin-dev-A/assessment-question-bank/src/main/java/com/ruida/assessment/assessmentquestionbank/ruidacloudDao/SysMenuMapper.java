package com.ruida.assessment.assessmentquestionbank.ruidacloudDao;

import com.ruida.assessment.assessmentquestionbank.model.SysMenu;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.assessment.assessmentquestionbank.model.TreeNode;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * 菜单表 Mapper 接口
 * </p>
 *
 * @author szl
 * @since 2020-07-14
 */
public interface SysMenuMapper extends BaseMapper<SysMenu> {
    List<SysMenu> getAuthMenuList(Integer userId);

    /**
     * 获取菜单树
     * @return
     */
    List<TreeNode> menuTreeList(Map<String,Object> param);

    @Select("SELECT\n" +
            "\tGROUP_CONCAT(DISTINCT a.menu_id)\n" +
            "FROM\n" +
            "\tsys_role_menu a\n" +
            "LEFT JOIN sys_menu b ON a.menu_id = b.menu_id\n" +
            "WHERE\n" +
            "\ta.role_id = #{roleId} \n" +
            "AND FIND_IN_SET(b.menu_type,'0,1,2')\n" +
            "GROUP BY\n" +
            "\ta.role_id")
    String getMenuIdsByRoleId(@Param("roleId") Integer roleId);


    @Select("SELECT\n" +
            "\tGROUP_CONCAT(DISTINCT a.menu_id)\n" +
            "FROM\n" +
            "\tsys_role_menu a\n" +
            "LEFT JOIN sys_menu b ON a.menu_id = b.menu_id\n" +
            "WHERE\n" +
            "\ta.role_id = #{roleId} \n" +
            "AND b.menu_type = 3 \n" +
            "GROUP BY\n" +
            "\ta.role_id")
    String getFieldIdsByRoleId(@Param("roleId") Integer roleId);
    List<TreeNode>  getMenuListByUserRole(Map<String,Object> param);

    List<TreeNode> getMenuListByOptUserRole(Map<String,Object> param);

    @Select("select role_id AS roleId , role_type AS roleType , department_id AS departmentId  role_describe AS roleDescribe " +
            "sys_role where role_id = #{roleId} ")
    Map<String,Object> getRoleInfo(@Param("roleId") Integer roleId);


    List<TreeNode> getUserMenuList(@Param("userId") Integer userId);
}
