package com.ruida.cloud.dao;

import com.ruida.cloud.model.QuestionTypeActual;
import com.ruida.cloud.model.QuestionTypeActualExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface QuestionTypeActualMapper {
    long countByExample(QuestionTypeActualExample example);

    int deleteByExample(QuestionTypeActualExample example);

    int deleteByPrimaryKey(Integer questionTypeActualId);

    int insert(QuestionTypeActual record);

    int insertSelective(QuestionTypeActual record);

    List<QuestionTypeActual> selectByExample(QuestionTypeActualExample example);

    QuestionTypeActual selectByPrimaryKey(Integer questionTypeActualId);

    int updateByExampleSelective(@Param("record") QuestionTypeActual record, @Param("example") QuestionTypeActualExample example);

    int updateByExample(@Param("record") QuestionTypeActual record, @Param("example") QuestionTypeActualExample example);

    int updateByPrimaryKeySelective(QuestionTypeActual record);

    int updateByPrimaryKey(QuestionTypeActual record);
}