package com.ruida.assessment.assessmentcommon.enums;

/**
 * @author wy
 * @description 可用状态枚举类
 * @date 2020/6/13
 */
public enum UsableStatusEnum {
    STOP(0,"禁用"),
    START(1,"启用"),
    DELETE(2,"删除"),
    ROLL_BACK(3,"退回")
    ;

    private Integer K;
    private String V;

    UsableStatusEnum(Integer k, String v) {
        K = k;
        V = v;
    }

    public Integer getK() {
        return K;
    }

    public void setK(Integer k) {
        K = k;
    }

    public String getV() {
        return V;
    }

    public void setV(String v) {
        V = v;
    }

    public static DeleteStatusEnum getValueById(Integer K){
        for(DeleteStatusEnum deleteStatusEnum : DeleteStatusEnum.values() ){
            if(deleteStatusEnum.getK().equals(K)){
                return  deleteStatusEnum;
            }
        }
        return null;
    }
}
