package com.ruida.mockservice.service;

import com.baomidou.mybatisplus.service.IService;
import com.ruida.mockdao.model.OccupationInterestExamRecord;

/**
 * <p>
 * 霍兰德职业兴趣答题卡以及报告 服务类
 * </p>
 *
 * @author 
 * @since 2021-02-05
 */
public interface OccupationInterestExamRecordService extends IService<OccupationInterestExamRecord> {

	OccupationInterestExamRecord upload(OccupationInterestExamRecord record);

	/** 购买试卷后插入记录
	 * @param userId
	 */
	void createAfterBuyQuestion(Integer userId);
	void createFreeQuestion(Integer userId);
	
	/**购买报告后更新标志位
	 * @param recordId
	 */
	void updateAfterBuyReport(Integer recordId);
	
	/**判断是否有已购买未答题的试卷，true是有
	 * @param userId
	 * @return
	 */
	Boolean checkHasUndoPaper(Integer userId);
	
	/**
	 * 获取所有的提交答案的答题卡数量。
	 * @return
	 */
	Integer countAllUploadRecordNum();
	
	/**
	 * 检查目标用户是否有报告
	 * @param userId
	 * @return true if has report
	 */
	Boolean checkHasReport(Integer userId);
}
