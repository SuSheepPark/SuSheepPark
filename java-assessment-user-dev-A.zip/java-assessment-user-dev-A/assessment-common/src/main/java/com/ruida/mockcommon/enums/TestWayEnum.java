package com.ruida.mockcommon.enums;

/**
 * 考试方式
 */
public enum TestWayEnum {
    PRACTICE(0,"练习"),
    PAPER(1,"纸考"),
    COMPUTER(2,"机房考"),
    UNION(3,"统考");

    private int k;

    private String value;

    TestWayEnum(int k, String value) {
        this.k = k;
        this.value = value;
    }

    public int getK() {
        return k;
    }

    public String getValue() {
        return value;
    }
}
