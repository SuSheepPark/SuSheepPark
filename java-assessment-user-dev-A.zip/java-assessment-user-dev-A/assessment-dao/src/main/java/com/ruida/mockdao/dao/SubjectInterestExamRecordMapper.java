package com.ruida.mockdao.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.model.TSubjectInterestExamRecord;

/**
 * <p>
 * 科目兴趣调查的答卷 Mapper 接口
 * </p>
 *
 * @author 
 * @since 2021-01-11
 */
public interface SubjectInterestExamRecordMapper extends BaseMapper<TSubjectInterestExamRecord> {

}
