package com.ruida.mockdao.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

/**
 * <p>
 * 商品收藏
 * </p>
 *
 * @author jinhu
 * @since 2020-07-13
 */
@Data
@ApiModel(value="ProductCollect对象", description="商品收藏")
public class ProductCollectVO implements Serializable {


    private static final long serialVersionUID = 7990296461012803352L;


    @ApiModelProperty(value = "商品id")
    private Integer productId;

    @ApiModelProperty(value = "是否购收藏  0未收藏  1收藏")
    private Integer isCollect;





}
