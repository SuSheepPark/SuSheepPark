package com.ruida.cloud.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class CoursePurchase implements Serializable {
    private Integer coursePurchaseId;

    private Integer purchaserId;

    private Integer orderId;

    private Integer courseId;

    private String teacherId;

    private String courseTypeName;

    private Integer classTypeId;

    private String courseName;

    private BigDecimal coursePrice;

    private Byte courseSale;

    private String periodName;

    private String stageName;

    private String subjectName;

    private String coverPath;

    private String validTime;

    private Date startTime;

    private Date endTime;

    private Date paymentTime;

    private static final long serialVersionUID = 1L;

    public Integer getCoursePurchaseId() {
        return coursePurchaseId;
    }

    public void setCoursePurchaseId(Integer coursePurchaseId) {
        this.coursePurchaseId = coursePurchaseId;
    }

    public Integer getPurchaserId() {
        return purchaserId;
    }

    public void setPurchaserId(Integer purchaserId) {
        this.purchaserId = purchaserId;
    }

    public Integer getOrderId() {
        return orderId;
    }

    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    public Integer getCourseId() {
        return courseId;
    }

    public void setCourseId(Integer courseId) {
        this.courseId = courseId;
    }

    public String getTeacherId() {
        return teacherId;
    }

    public void setTeacherId(String teacherId) {
        this.teacherId = teacherId == null ? null : teacherId.trim();
    }

    public String getCourseTypeName() {
        return courseTypeName;
    }

    public void setCourseTypeName(String courseTypeName) {
        this.courseTypeName = courseTypeName == null ? null : courseTypeName.trim();
    }

    public Integer getClassTypeId() {
        return classTypeId;
    }

    public void setClassTypeId(Integer classTypeId) {
        this.classTypeId = classTypeId;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName == null ? null : courseName.trim();
    }

    public BigDecimal getCoursePrice() {
        return coursePrice;
    }

    public void setCoursePrice(BigDecimal coursePrice) {
        this.coursePrice = coursePrice;
    }

    public Byte getCourseSale() {
        return courseSale;
    }

    public void setCourseSale(Byte courseSale) {
        this.courseSale = courseSale;
    }

    public String getPeriodName() {
        return periodName;
    }

    public void setPeriodName(String periodName) {
        this.periodName = periodName == null ? null : periodName.trim();
    }

    public String getStageName() {
        return stageName;
    }

    public void setStageName(String stageName) {
        this.stageName = stageName == null ? null : stageName.trim();
    }

    public String getSubjectName() {
        return subjectName;
    }

    public void setSubjectName(String subjectName) {
        this.subjectName = subjectName == null ? null : subjectName.trim();
    }

    public String getCoverPath() {
        return coverPath;
    }

    public void setCoverPath(String coverPath) {
        this.coverPath = coverPath == null ? null : coverPath.trim();
    }

    public String getValidTime() {
        return validTime;
    }

    public void setValidTime(String validTime) {
        this.validTime = validTime == null ? null : validTime.trim();
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public Date getPaymentTime() {
        return paymentTime;
    }

    public void setPaymentTime(Date paymentTime) {
        this.paymentTime = paymentTime;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", coursePurchaseId=").append(coursePurchaseId);
        sb.append(", purchaserId=").append(purchaserId);
        sb.append(", orderId=").append(orderId);
        sb.append(", courseId=").append(courseId);
        sb.append(", teacherId=").append(teacherId);
        sb.append(", courseTypeName=").append(courseTypeName);
        sb.append(", classTypeId=").append(classTypeId);
        sb.append(", courseName=").append(courseName);
        sb.append(", coursePrice=").append(coursePrice);
        sb.append(", courseSale=").append(courseSale);
        sb.append(", periodName=").append(periodName);
        sb.append(", stageName=").append(stageName);
        sb.append(", subjectName=").append(subjectName);
        sb.append(", coverPath=").append(coverPath);
        sb.append(", validTime=").append(validTime);
        sb.append(", startTime=").append(startTime);
        sb.append(", endTime=").append(endTime);
        sb.append(", paymentTime=").append(paymentTime);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}