package com.ruida.assessment.assessmentquestionbank.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.assessment.assessmentcommon.result.Page;
import com.ruida.assessment.assessmentquestionbank.model.TStage;
import com.ruida.assessment.assessmentquestionbank.vo.BaseFieldVO;
import com.ruida.assessment.assessmentquestionbank.vo.StageVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * @description:
 * @author: kgz
 * @date: 2020/6/29
 */
@Mapper
public interface StageMapper extends BaseMapper<TStage> {
    /**
     * 根据类型获取年级选项数据
     * @param type
     * @return
     */
    List getStageList(@Param("type") Integer type);
    /**
     * 根据类型获取年级选项数据
     * @param periodId
     * @return
     */
    List getStageListByPeriod(@Param("periodId") Integer periodId);

    /**
     * 分页查询列表
     * @param page
     * @return
     */
    List<BaseFieldVO> queryList(@Param("page") Page page);

    /**
     * 列表数据条数
     * @return
     */
    Integer countQuerList();

    /**
     * 根据年级id查询学段
     * @param gradeId
     * @return
     */
    @Select("SELECT a.period_id FROM t_grade a WHERE a.grade_id = #{gradeId}")
    Integer getPeriodIdByGradeId(@Param("gradeId") Integer gradeId);
}
