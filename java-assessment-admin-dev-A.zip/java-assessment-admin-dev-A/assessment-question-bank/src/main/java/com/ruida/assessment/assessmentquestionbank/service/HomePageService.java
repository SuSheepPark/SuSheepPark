package com.ruida.assessment.assessmentquestionbank.service;

import com.ruida.assessment.assessmentquestionbank.dto.BasicDataDTO;
import com.ruida.assessment.assessmentquestionbank.vo.BasicDataVO;
import com.ruida.assessment.assessmentquestionbank.vo.DataTrendVO;

import java.util.List;

/**
 * @description: 首页业务层接口
 * @author: kgz
 * @date: 2020/8/5
 */
public interface HomePageService {
    /**
     * 获取基础数据
     * @return
     */
    BasicDataVO getBasicData();

    /**
     * 获取交易趋势数据
     * @param basicDataDTO
     * @return
     */
    List<DataTrendVO> getAmountTrendData(BasicDataDTO basicDataDTO);

    /**
     * 获取代办事项
     * @return
     */
    Integer getTask();
}
