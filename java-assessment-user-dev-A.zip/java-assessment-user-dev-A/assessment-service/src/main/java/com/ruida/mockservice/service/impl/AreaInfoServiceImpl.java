package com.ruida.mockservice.service.impl;


import com.ruida.mockdao.dao.AreainfoMapper;
import com.ruida.mockdao.model.Areainfo;
import com.ruida.mockdao.model.AreainfoExample;
import com.ruida.mockservice.service.AreaInfoService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * 地区操作服务
 */
@Service
public class AreaInfoServiceImpl implements AreaInfoService {
    @Resource
    AreainfoMapper areainfoDao;

    /**
     * 获取省份数据列表
     *
     * @return
     */
    public List<Areainfo> listProvince() {
        AreainfoExample example = new AreainfoExample();
        AreainfoExample.Criteria criteria = example.or();

        criteria.andAreaLevelEqualTo(new Byte("1"));

        List<Areainfo> areainfoList = areainfoDao.selectByExample(example);

        return areainfoList;
    }

    /**
     * 获取地区信息列表
     *
     * @param province
     * @return
     */
    public List<Areainfo> listCityByProvince(Integer province) {
        AreainfoExample example = new AreainfoExample();
        AreainfoExample.Criteria criteria = example.or();

        criteria.andParentIdEqualTo(province);

        List<Areainfo> areainfoList = areainfoDao.selectByExample(example);

        return areainfoList;
    }

    /**
     * 获取区信息列表
     *
     * @param city
     * @return
     */
    public List<Areainfo> listDistrictByCity(Integer city) {
        AreainfoExample example = new AreainfoExample();
        AreainfoExample.Criteria criteria = example.or();

        criteria.andParentIdEqualTo(city);

        List<Areainfo> areainfoList = areainfoDao.selectByExample(example);

        return areainfoList;
    }


}
