package com.ruida.common.util;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.StringUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * String 常用操作类
 * 
 * @ClassName: StringUtil
 * @Description: TODO(这里用一句话描述这个类的作用)
 * @author 秦冲
 * @date 2013-7-22 上午10:44:55
 * 
 */
public class StringUtil {
	
	public static final String allChar = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
	private static final String regEx_script = "<script[^>]*?>[\\s\\S]*?<\\/script>"; // 定义script的正则表达式  
    private static final String regEx_style = "<style[^>]*?>[\\s\\S]*?<\\/style>"; // 定义style的正则表达式  
    private static final String regEx_html = "<[^>]+>"; // 定义HTML标签的正则表达式

    /**
     *  <br>　　　　　2019年1月16日已知
    中国电信号段
        133,149,153,173,174,177,180,181,189,199
    中国联通号段
        130,131,132,145,146,155,156,166,175,176,185,186
    中国移动号段
        134(0-8),135,136,137,138,139,147,148,150,151,152,157,158,159,165,178,182,183,184,187,188,198
    上网卡专属号段（用于上网和收发短信，不能打电话）
        如中国联通的是145
    虚拟运营商
        电信：1700,1701,1702
        移动：1703,1705,1706
        联通：1704,1707,1708,1709,171
    卫星通信： 1349 <br>　　　　　未知号段：141、142、143、144、154
    */
    private static String telephone_regex = "^[1](([3|5|8][\\d])|([4][4,5,6,7,8,9])|([6][2,5,6,7])|([7][^9])|([9][1,8,9]))[\\d]{8}$";
	
    /**
	 * by zhangjun Html、javascript字符转义
	 * @Description: TODO
	 * @param srcStr    
	 * @return String     
	 * @throws
	 */
	public static String escapeStr(String srcStr)
	{
		//srcStr = StringEscapeUtils.escapeJavaScript(srcStr);
		srcStr = StringEscapeUtils.escapeHtml(srcStr);
		return srcStr;
	}
	
	/**
	 * by zhangjun Html、javascript字符反转义
	 * @Description: TODO
	 * @param srcStr    
	 * @return String     
	 * @throws
	 */
	public static String unEscapeStr(String srcStr)
	{
		srcStr = StringEscapeUtils.unescapeHtml(srcStr);
		srcStr = StringEscapeUtils.unescapeJavaScript(srcStr);
		return srcStr;
	}
	
	/**  
	    * 得到一个字符串的长度,显示的长度,一个汉字或日韩文长度为2,英文字符长度为1  
	    * @param s 需要得到长度的字符串
	    * @return int 得到的字符串长度  
	    */   
	   public static int getLetterLength(String s) {  
	       if (s == null) {
			   return 0;
		   }
	       char[] c = s.toCharArray();  
	       int len = 0;  
	       for (int i = 0; i < c.length; i++) {  
	           len++;  
	           if (!isLetter(c[i])) {  
	               len++;  
	           }  
	       }  
	       return len;  
	   } 
	   
	   
		public static boolean isLetter(char c) {   
		       int k = 0x80;   
		       return c / k == 0 ? true : false;   
		   }  
	
	/**
	 * 分割字符串
	 * 
	 * @param str
	 *            String 原始字符串
	 * @param splitsign
	 *            String 分隔符
	 * @return String[] 分割后的字符串数组
	 */
	@SuppressWarnings("unchecked")
	public static String[] split(String str, String splitsign) {
		int index;
		if (str == null || splitsign == null) {
			return null;
		}
		ArrayList al = new ArrayList();
		while ((index = str.indexOf(splitsign)) != -1) {
			al.add(str.substring(0, index));
			str = str.substring(index + splitsign.length());
		}
		al.add(str);
		return (String[]) al.toArray(new String[0]);
	}

	/**
	 * by 秦冲 比较验证码
	 * @Title: equalCode
	 * @Description: TODO
	 * @param @param comparand
	 * @param @param sessioncode
	 * @param @return    
	 * @return boolean    
	 * @throws
	 */
	public static boolean equalCode(String comparand ,String sessioncode)
	{
		if((comparand.toLowerCase()).equals(sessioncode))
		{
			return true;
			
		}
		return false;
	}
	
	
	/**
	 * 替换字符串
	 * 
	 * @param from
	 *            String 原始字符串
	 * @param to
	 *            String 目标字符串
	 * @param source
	 *            String 母字符串
	 * @return String 替换后的字符串
	 */
	public static String replace(String from, String to, String source) {
		if (source == null || from == null || to == null) {
			return null;
		}
		StringBuffer bf = new StringBuffer("");
		int index = -1;
		while ((index = source.indexOf(from)) != -1) {
			bf.append(source.substring(0, index) + to);
			source = source.substring(index + from.length());
			index = source.indexOf(from);
		}
		bf.append(source);
		return bf.toString();
	}

	/**
	 * 替换字符串，能能够在HTML页面上直接显示(替换双引号和小于号)
	 * 
	 * @param str
	 *            String 原始字符串
	 * @return String 替换后的字符串
	 */
	public static String htmlencode(String str) {
		if (str == null) {
			return null;
		}

		return replace("\"", "&quot;", replace("<", "&lt;", str));
	}

	/**
	 * 替换字符串，将被编码的转换成原始码（替换成双引号和小于号）
	 * 
	 * @param str
	 *            String
	 * @return String
	 */
	public static String htmldecode(String str) {
		if (str == null) {
			return null;
		}

		return replace("&quot;", "\"", replace("&lt;", "<", str));
	}

	private static final String _BR = "<br/>";

	/**
	 * 在页面上直接显示文本内容，替换小于号，空格，回车，TAB
	 * 
	 * @param str
	 *            String 原始字符串
	 * @return String 替换后的字符串
	 */
	public static String htmlshow(String str) {
		if (str == null) {
			return null;
		}

		str = replace("<", "&lt;", str);
		str = replace(" ", "&nbsp;", str);
		str = replace("\r\n", _BR, str);
		str = replace("\n", _BR, str);
		str = replace("\t", "&nbsp;&nbsp;&nbsp;&nbsp;", str);
		return str;
	}

	/**
	 * 返回指定字节长度的字符串
	 * 
	 * @param str
	 *            String 字符串
	 * @param length
	 *            int 指定长度
	 * @return String 返回的字符串
	 */
	public static String toLength(String str, int length) {
		if (str == null) {
			return null;
		}
		if (length <= 0) {
			return "";
		}
		try {
			if (str.getBytes("GBK").length <= length) {
				return str;
			}
		} catch (Exception ex) {
		}
		StringBuffer buff = new StringBuffer();

		int index = 0;
		char c;
		length -= 3;
		while (length > 0) {
			c = str.charAt(index);
			if (c < 128) {
				length--;
			} else {
				length--;
				length--;
			}
			buff.append(c);
			index++;
		}
		buff.append("...");
		return buff.toString();
	}

	/**
	 * 判断是否为整数
	 * 
	 * @param str
	 *            传入的字符串
	 * @return 是整数返回true,否则返回false
	 */
	public static boolean isInteger(String str) {
		Pattern pattern = Pattern.compile("^[-\\+]?[\\d]*$");
		return pattern.matcher(str).matches();
	}

	/**
	 * 判断是否为浮点数，包括double和float
	 * 
	 * @param str
	 *            传入的字符串
	 * @return 是浮点数返回true,否则返回false
	 */
	public static boolean isDouble(String str) {
		Pattern pattern = Pattern.compile("^[-\\+]?[.\\d]*$");
		return pattern.matcher(str).matches();
	}

	/**
	 * 判断输入的字符串是否符合Email样式.
	 * 
	 * @param str
	 *            传入的字符串
	 * @return 是Email样式返回true,否则返回false
	 */
	public static boolean isEmail(String str) {
		Pattern pattern = Pattern.compile("^\\w+([-+.]\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*$");
		return pattern.matcher(str).matches();
	}

	/**
	 * 判断输入的字符串是否为纯汉字
	 * 
	 * @param str
	 *            传入的字符窜
	 * @return 如果是纯汉字返回true,否则返回false
	 */
	public static boolean isChinese(String str) {
		Pattern pattern = Pattern.compile("[\u0391-\uFFE5]+$");
		return pattern.matcher(str).matches();
	}

	/**
	 * 是否为空白,包括null和""
	 * 
	 * @param str
	 * @return
	 */
	public static boolean isBlank(String str) {
		return str == null || str.trim().length() == 0;
	}

	/**
	 * 判断是不是合法手机 handset 手机号码
	 */
	public static boolean isHandset(String handset) {
		try {
			if (!handset.substring(0, 1).equals("1")) {
				return false;
			}
			if (handset == null || handset.length() != 11) {
				return false;
			}
			String check = "^[0123456789]+$";
			Pattern regex = Pattern.compile(check);
			Matcher matcher = regex.matcher(handset);
			boolean isMatched = matcher.matches();
			if (isMatched) {
				return true;
			} else {
				return false;
			}
		} catch (RuntimeException e) {
			return false;
		}
	}

	/**
	 * 首字母大写
	 * 
	 * @param oldString
	 * @return
	 */
	public static String initialUpperCase(String oldString) {
		if (oldString == null || oldString.equals("")) {
			return oldString;
		}
		String target = new StringBuffer()
				.append(oldString.substring(0, 1).toUpperCase())
				.append(oldString.substring(1)).toString();
		return target;
	}

	/**
	 * 获得字母出现最多的字母 2013-7-22
	 * 
	 * @Title: getCount
	 * @Description: TODO
	 * @param @param str
	 * @param @return
	 * @return String
	 * @throws
	 */
	public static String getCount(String str) {
		int maxSize = 0;

		ArrayList<String> list = new ArrayList<String>();

		while (str.length() > 0) {
			String str1 = str.replaceAll(String.valueOf(str.charAt(0)), "");
			int count = str.length() - str1.length();
			if (count > maxSize) {
				maxSize = count;
				list.clear();
				list.add(str.charAt(0) + "=" + count);
			} else if (str.length() - str1.length() == maxSize) {
				list.add(str.charAt(0) + "=" + count);
			}

			str = str1;
		}

		return (list.toString());
	}

	public static final String numberChar = "0123456789";

	/**
	 * 根据系统时间获得指定位数的随机数
	 * 
	 * @return 获得的随机数
	 */
	public static String getRandom() {

		Long seed = System.currentTimeMillis();// 获得系统时间，作为生成随机数的种子

		StringBuffer sb = new StringBuffer();// 装载生成的随机数

		Random random = new Random(seed);// 调用种子生成随机数

		for (int i = 0; i < 20; i++) {

			sb.append(numberChar.charAt(random.nextInt(numberChar.length())));
		}
		return sb.toString();

	}

	/**
	 * 
	 * @Title: getFirstLine
	 * @Description: 获取多长字符串中的第一行
	 * @param @param lineStr
	 * @param @return
	 * @return String
	 * @throws
	 */
	public static String getFirstLine(String lineStr) {
		String firstLine = "";
		if (lineStr != null) {
			String[] lines = lineStr.split("\n");
			if (null != lines && lines.length > 0) {
				firstLine = lines[0];
			}
		}
		return firstLine;
	}

	/**
	 * 
	 * @Title: getLastLine
	 * @Description: 获取多行字符串的最后一行
	 * @param @param output
	 * @param @return
	 * @return String
	 * @throws
	 */
	public static String getLastLine(String lineStr) {
		String lastLine = "";
		if (lineStr != null) {
			String[] lines = lineStr.split("\n");
			if (null != lines && lines.length > 0) {
				lastLine = lines[lines.length - 1];
			}
		}
		return lastLine;
	}

	/**
	 * 
	 * @Title: deleteFirstLine
	 * @Description: 删除多行记录中的第一行
	 * @param @param lineStr
	 * @param @return
	 * @return String
	 * @throws
	 */
	public static String deleteFirstLine(String lineStr) {
		String res = "";
		if (null != lineStr) {
			String[] lines = lineStr.split("\n");
			if (null != lines && lines.length > 0) {
				for (int i = 1; i < lines.length; i++) {
					res = res.concat(lines[i]);
				}
			}
		}
		return res;
	}

	/**
	 * 
	 * @Title: deleteFirstLine
	 * @Description: TODO
	 * @param @param lineStr
	 * @param @return
	 * @return String
	 * @throws
	 */
	public static String deleteLastLine(String lineStr) {
		String res = "";
		if (null != lineStr) {
			String[] lines = lineStr.split("\n");
			if (null != lines && lines.length > 0) {
				for (int i = 0; i < lines.length - 1; i++) {
					res = res.concat(lines[i]);
				}
			}
		}
		return res;
	}

	/**
	 * 检测字符串是否不为空(null,"","null")
	 * 
	 * @param s
	 * @return 不为空则返回true，否则返回false
	 */
	public static boolean notEmpty(String s) {
		return s != null && !"".equals(s) && !"null".equals(s);
	}

	/**
	 * 检测字符串是否为空(null,"","null")
	 * 
	 * @param s
	 * @return 为空则返回true，不否则返回false
	 */
	public static boolean isEmpty(String s) {
		return s == null || "".equals(s) || "null".equals(s);
	}
	
	/**
	 * 
	 * @author: baeqiuzhu
	 * @Title: encodeStrBase64
	 * @Description: 进行base64加密 
	 * @param s
	 * @return
	 * String    
	 *
	 */
	public static String encodeStrBase64(String s) {
		if (s == null) {
			return null;
		}
		byte[] b = s.getBytes();
		Base64 base64 = new Base64();
		b = base64.encode(b);
		String str = new String(b);
		return str;
	}

	/**
	 * 
	 * @author: baeqiuzhu
	 * @Title: getFromBASE64
	 * @Description: base64解码 
	 * @param s
	 * @return
	 * String    
	 *
	 */
	public static String decodeStrWithBase64(String s) {
		if(s == null) {
			return null;
		}
		byte[] b = s.getBytes();
		Base64 base64 = new Base64();
		b = base64.decode(b);
		String str = new String(b);
		return str;
	}

	public static String encEmail(String email) {
		String encEmail = "";
		if (!StringUtil.isBlank(email)) {
			String[] abbEmailArr = email.split("@");
			// 邮箱模糊
			encEmail = abbEmailArr[0].substring(0,1) + "***" + abbEmailArr[0].substring(abbEmailArr[0].length() - 1, abbEmailArr[0].length()) + "@" + abbEmailArr[1];
		} else {
			encEmail = "illEmail";
		}
		return encEmail;
	}

	public static String encPhone(String phone) {
		if (!StringUtil.isBlank(phone) && phone.length() == 11) { // 显示手机尾号
			phone = phone.substring(0, 3) + "*****" + phone.substring(8, 11);
		} else {
			phone = "illPhone";
		}
		return phone;
	}
	
	/**
	 * 
	 * @author: baieqiuzhu
	 * @Title: generateString
	 * @Description: TODO 
	 * @param length
	 * @return
	 * String    
	 *
	 */
	public static String generateString(int length) {
		StringBuffer sb = new StringBuffer();
		Random random = new Random();
		for (int i = 0; i < length; i++) {
			sb.append(allChar.charAt(random.nextInt(allChar.length())));
		}
		return sb.toString();     
	}  
	
	public static boolean matchLetter(String str) {
		if(StringUtils.isBlank(str)) {
			return false;
		}
		String regex=".*[a-zA-Z]+.*";
		Matcher m=Pattern.compile(regex).matcher(str);
		return m.matches();
	}
	
	public static String replaceBlank(String str) {
        String dest = "";
        if (str!=null) {
            Pattern p = Pattern.compile("\\s*|\t|\r|\n");
            Matcher m = p.matcher(str);
            dest = m.replaceAll("");
        }
        return dest;
    }

    public static String sortIntStr(String str){

		// 使用正则表达式进行分割
		String[] strs = str.split(",");
		int[] is = new int[strs.length];

		// 遍历String数组，赋值给int数组
		for (int i = 0; i < strs.length; i++) {
			is[i] = Integer.parseInt(strs[i]);
		}

		// 使用数组工具类进行排序，也可以自己使用冒泡或选择排序来进行排序
		Arrays.sort(is);

		StringBuffer sb = new StringBuffer();

		// 遍历进行拼接
		for (int i = 0; i < is.length; i++) {
			if (i == is.length - 1) {
				sb.append(is[i]);
			} else {
				sb.append(is[i] + ",");
			}
		}

		return sb.toString();
	}
	
	public static void main(String []args) {
		/*String param = "cW5LbzFyJnVzZXJOYW1lPemrmOerr eOqeWutjImZW1haWw9NzA1MjUyODgzQHFxLmNvbSZzZW5kVGltZT0yMDE0MDEwODE2MTYyNiZtZW1iZXJJRD01MTQ1JnJhbmRvbVN0cj1JSlI5bEk=";
		String param2 = "cW5LbzFyJnVzZXJOYW1lPemrmOerr+eOqeWutjImZW1haWw9NzA1MjUyODgzQHFxLmNvbSZzZW5kVGltZT0yMDE0MDEwODE2MTYyNiZtZW1iZXJJRD01MTQ1JnJhbmRvbVN0cj1JSlI5bEk=";
		String param3 = "cW5LbzFyJnVzZXJOYW1lPemrmOerr eOqeWutjImZW1haWw9NzA1MjUyODgzQHFxLmNvbSZzZW5kVGltZT0yMDE0MDEwODE2MTYyNiZtZW1iZXJJRD01MTQ1JnJhbmRvbVN0cj1JSlI5bEk=";
		try {
			String codeParam = URLEncoder.encode(param, "UTF-8");
			param = StringUtil.decodeStrWithBase64(codeParam);
			System.out.println(codeParam);
			System.out.println(param);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		String encodeStr = encodeStrBase64("&userName=高端玩家&email=xiaming.1688@163.com&sendTime=20131027011052&");
		System.out.println(encodeStr);
		String decodeStr = decodeStrWithBase64(encodeStr);
		System.out.println(decodeStr);*/
	}
	
	public static String delHTMLTag(String htmlStr) {  
        Pattern p_script = Pattern.compile(regEx_script, Pattern.CASE_INSENSITIVE);  
        Matcher m_script = p_script.matcher(htmlStr);  
        htmlStr = m_script.replaceAll(""); // 过滤script标签  
  
        Pattern p_style = Pattern.compile(regEx_style, Pattern.CASE_INSENSITIVE);  
        Matcher m_style = p_style.matcher(htmlStr);  
        htmlStr = m_style.replaceAll(""); // 过滤style标签  
  
        Pattern p_html = Pattern.compile(regEx_html, Pattern.CASE_INSENSITIVE);  
        Matcher m_html = p_html.matcher(htmlStr);  
        htmlStr = m_html.replaceAll(""); // 过滤html标签  
  
        return htmlStr.trim(); // 返回文本字符串  
    }  
      
    public static String getTextFromHtml(String htmlStr){  
        htmlStr = delHTMLTag(htmlStr);  
        htmlStr = htmlStr.replaceAll(" ", "");  
        htmlStr = htmlStr.substring(0, htmlStr.indexOf("。")+1);  
        return htmlStr;  
    }

    //已,分割的str转换成int类型的list
    public static List<Integer> StrToInt(String strs){
		List<String> idstrList = Arrays.asList(strs.split(","));
		//转换成int类型
		List<Integer> idList = idstrList.stream().map(Integer::parseInt).collect(Collectors.toList());

		return idList;
	}
}
