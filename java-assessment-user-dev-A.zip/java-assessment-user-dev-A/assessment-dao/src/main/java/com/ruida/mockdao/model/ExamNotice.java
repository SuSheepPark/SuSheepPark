package com.ruida.mockdao.model;

import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;
import com.fasterxml.jackson.annotation.JsonIgnore;

import java.io.Serializable;

/**
 * <p>
 * 考试注意事项表
 * </p>
 *
 * @author chenjy
 * @since 2020-08-03
 */
@TableName("t_exam_notice")
public class ExamNotice extends Model<ExamNotice> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键ID
     */
    @JsonIgnore
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;
    /**
     * 排序
     */
    private Integer sort;
    /**
     * 考试渠道(1-app；2-pc)
     */
    @JsonIgnore
    private Integer channel;
    /**
     * 注意事项名称
     */
    @TableField("notice_name")
    private String noticeName;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getSort() {
        return sort;
    }

    public void setSort(Integer sort) {
        this.sort = sort;
    }

    public Integer getChannel() {
        return channel;
    }

    public void setChannel(Integer channel) {
        this.channel = channel;
    }

    public String getNoticeName() {
        return noticeName;
    }

    public void setNoticeName(String noticeName) {
        this.noticeName = noticeName;
    }

    @Override
    protected Serializable pkVal() {
        return this.id;
    }

    @Override
    public String toString() {
        return "ExamNotice{" +
        ", id=" + id +
        ", sort=" + sort +
        ", channel=" + channel +
        ", noticeName=" + noticeName +
        "}";
    }
}
