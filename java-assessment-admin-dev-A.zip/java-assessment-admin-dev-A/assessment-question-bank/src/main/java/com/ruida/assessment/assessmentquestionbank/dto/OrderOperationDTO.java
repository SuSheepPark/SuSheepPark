package com.ruida.assessment.assessmentquestionbank.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * @description: 订单操作
 * @author: kgz
 * @date: 2020/8/3
 */
@ApiModel(description = "订单操作信息")
public class OrderOperationDTO {

    @ApiModelProperty(value = "订单id", name = "orderId", required = true)
    private Integer orderId;

    @ApiModelProperty(value = "操作id", name = "operationId", required = true)
    private Integer operationId;

    public Integer getOrderId() {
        return orderId;
    }

    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    public Integer getOperationId() {
        return operationId;
    }

    public void setOperationId(Integer operationId) {
        this.operationId = operationId;
    }

    @Override
    public String toString() {
        return "OrderOperationDTO{" +
                "orderId=" + orderId +
                ", operationId=" + operationId +
                '}';
    }
}
