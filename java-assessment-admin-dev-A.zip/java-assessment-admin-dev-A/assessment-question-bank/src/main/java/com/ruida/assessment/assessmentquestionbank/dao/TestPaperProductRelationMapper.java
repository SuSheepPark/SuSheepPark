package com.ruida.assessment.assessmentquestionbank.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.assessment.assessmentquestionbank.model.TTestPaperProductRel;
import com.ruida.assessment.assessmentquestionbank.vo.PresellTestPaperVo;
import com.ruida.assessment.assessmentquestionbank.vo.TestPaperProductRelVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author wy
 * @description 商品试卷关联mapper
 * @date 2020/6/24
 */
@Mapper
public interface TestPaperProductRelationMapper extends BaseMapper<TTestPaperProductRel> {


    /*
     *功能描述 根据商品id查询商品关联的试卷信息
     * @param
     * @return
     */
    List<TestPaperProductRelVo> queryTestPaperProductRelVosByProductId(@Param("productId") Integer productId);
    
    /*
     *功能描述 根据浏览量返回试卷id的排序列表
     * @param
     * @return
     */
    List<Integer> selectTestPaperIdsOrderByBrowse();


    /*
     *功能描述 查询商品中的未发布状态的试卷
     * @param
     * @return
     */
    List<TTestPaperProductRel> queryProductTestPaperIsPublish(@Param("productId") Integer productId);

    /**
     * 查询引用了某个试卷的商品数量
     * @param testPaperId
     * @param status
     * @return
     */
    int getProductUsedTestPaper(@Param("testPaperId") Integer testPaperId, @Param("status") Integer status);

    /*
     *功能描述 查询商品关联的预售试卷列表
     * @param
     * @return
     */
    List<PresellTestPaperVo> queryPresellTestPaperList(@Param("productId") Integer productId);
    /*
     *功能描述 查询商品中的已发布状态的非预售试卷
     * @param
     * @return
     */
    List<TTestPaperProductRel> queryProductTestPaperPublishAndNotPresell(@Param("productId") Integer productId);
}
