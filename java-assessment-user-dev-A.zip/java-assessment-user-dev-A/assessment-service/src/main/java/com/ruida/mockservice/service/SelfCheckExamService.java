package com.ruida.mockservice.service;

import com.ruida.mockdao.dto.TestPaperDTO;
import com.ruida.mockdao.vo.SelfCheckPaperVO;
import com.ruida.mockdao.vo.SelfCheckSubmitVO;

/**
 * Created by xumingqi on 2021/7/21 16:46
 */
public interface SelfCheckExamService {
    SelfCheckPaperVO getSelfCheckPaperInfo(String sceneId);

    SelfCheckSubmitVO submitSelfCheckAnswer(TestPaperDTO testPaperDTO);
}
