package com.ruida.mockdao.dto;

import lombok.Data;

import java.util.List;

/**
 * @description: 小节DTO
 * @author: chenjy
 * @create: 2020-07-14 17:04
 */
@Data
public class NodeDTO {

    /**
     * 小节id
     */
    private Integer nodeId;

    /**
     * 试题信息
     */
    List<QuestionDTO> questionList;

}
