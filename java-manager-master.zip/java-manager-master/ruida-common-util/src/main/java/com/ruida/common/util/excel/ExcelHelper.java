package com.ruida.common.util.excel;

import com.ruida.common.util.ValidateMT;
import com.ruida.common.util.excel.processor.TypeProcessor;
import com.ruida.common.util.excel.processor.TypeProcessorFactory;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFFormulaEvaluator;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFFormulaEvaluator;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.*;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Type;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by Administrator on 2017/4/18.
 */
public class ExcelHelper<T> {

    private static final String EXTENSION_XLS = "xls";
    private static final String EXTENSION_XLSX = "xlsx";

    Class<T> clazz;

    FormulaEvaluator evaluator;


    public ExcelHelper(Class<T> clazz) {
        this.clazz = clazz;

    }

    public List<ExcelResult<T>> importExcel(File file, int sheetNo, boolean includeErrorRows) {
        List<ExcelResult<T>> list = new ArrayList<>();
        InputStream is = null;
        try {
            is = new FileInputStream(file);
            String fileName = file.getName();
            Workbook book = getWorkBook(is, fileName);
            Sheet sheet = book.getSheetAt(sheetNo);
            Iterator<Row> rows = sheet.rowIterator();

            // 将所有@ExcelAnnotation 注解的属性，放入到map中，key为注解的exportName，value为属性的Set方法
            Map<String, FieldAnnoBean<T>> annoMap = getFieldAnnoBeanMap();

            // 得到第一行，也就是标题行,循环遍历，将标题的文字内容放入到List
            Row titleRow = rows.next();
            List<String> titleList = getTitleList(titleRow);

            // 循环遍历其他行，将每一行转换为对象
            while (rows.hasNext()) {
                Row dataRow = rows.next();
                ExcelResult oneResult = createInstance(dataRow, titleList, annoMap);
                if (includeErrorRows || oneResult.getSuccessRow() != null) {
                    list.add(oneResult);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        } finally {
            if (is != null) {
                try {
                    is.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return list;
    }

    public List<ExcelResult<T>> importExcel(Workbook book, FormulaEvaluator evaluator, int sheetNo, boolean includeErrorRows) {

        if (evaluator != null) {
            this.evaluator = evaluator;
        }

        List<ExcelResult<T>> list = new ArrayList<>();
        InputStream is = null;
        try {
            Sheet sheet = book.getSheetAt(sheetNo);
            Iterator<Row> rows = sheet.rowIterator();

            // 将所有@ExcelAnnotation 注解的属性，放入到map中，key为注解的exportName，value为属性的Set方法
            Map<String, FieldAnnoBean<T>> annoMap = getFieldAnnoBeanMap();

            // 得到第一行，也就是标题行,循环遍历，将标题的文字内容放入到List
            Row titleRow = rows.next();
            List<String> titleList = getTitleList(titleRow);

            // 循环遍历其他行，将每一行转换为对象
            while (rows.hasNext()) {
                Row dataRow = rows.next();
                ExcelResult oneResult = createInstance(dataRow, titleList, annoMap);
                if (includeErrorRows || oneResult.getSuccessRow() != null) {
                    list.add(oneResult);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        } finally {
            if (is != null) {
                try {
                    is.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return list;
    }


    /**
     * 批量处理导入的数据
     *
     * @param file
     * @param sheetNo
     * @return
     */
    public void importExcelBatch(File file, int sheetNo, ExcelBatchIntercepter<T> intercepter) {

        InputStream is = null;
        try {
            is = new FileInputStream(file);
            String fileName = file.getName();
            Workbook book = getWorkBook(is, fileName);
            Sheet sheet = book.getSheetAt(sheetNo);
            Iterator<Row> rows = sheet.rowIterator();

            // 将所有@ExcelAnnotation 注解的属性，放入到map中，key为注解的exportName，value为属性的Set方法
            Map<String, FieldAnnoBean<T>> annoMap = getFieldAnnoBeanMap();

            // 得到第一行，也就是标题行,循环遍历，将标题的文字内容放入到List
            Row titleRow = rows.next();
            List<String> titleList = getTitleList(titleRow);

            // 循环遍历其他行，将每一行转换为对象
            int index = 0;
            while (rows.hasNext()) {
                try {
                    Row dataRow = rows.next();
                    ExcelResult oneResult = createInstance(dataRow, titleList, annoMap);

                    boolean success = false;
                    if (oneResult.getSuccessRow() != null) {
                        success = true;
                    }
                    intercepter.onRowConvertComplete(success, (T) oneResult.getSuccessRow(),
                            oneResult.getOrginColumns(), oneResult.getErrorMsg(), index);
                } catch (Exception ex) {
                    ex.printStackTrace();
                }

                index++;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (is != null) {
                try {
                    is.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private Workbook getWorkBook(String fileName) {
        Workbook workbook = null;
        if (fileName.endsWith(EXTENSION_XLS)) {
            workbook = new HSSFWorkbook();
        } else if (fileName.endsWith(EXTENSION_XLSX)) {
            workbook = new XSSFWorkbook();
        }
        return workbook;
    }


    public Workbook getWorkBook(InputStream is, String fileName) throws IOException {
        Workbook workbook = null;

        if (fileName.endsWith(EXTENSION_XLS)) {
            workbook = new HSSFWorkbook(is);
            evaluator = new HSSFFormulaEvaluator((HSSFWorkbook) workbook);
        } else if (fileName.endsWith(EXTENSION_XLSX)) {
            workbook = new XSSFWorkbook(is);
            evaluator = new XSSFFormulaEvaluator((XSSFWorkbook) workbook);
        }
        return workbook;
    }


    private List<String> getTitleList(Row titleRow) {

        Iterator<Cell> titleCellIter = titleRow.cellIterator();
        List<String> titleList = new ArrayList<String>();
        while (titleCellIter.hasNext()) {
            Cell cell = titleCellIter.next();
            String value = cell.getStringCellValue();
            titleList.add(value);
        }

        return titleList;
    }

    /**
     * 将Excel的一行根据注解转换为实例，并保存到excelResult中，如果失败保存到excelResult的errorRows中
     *
     * @param dataRow
     * @param titleList
     * @param annoMap
     * @throws IllegalAccessException
     * @throws InstantiationException
     * @throws InvocationTargetException
     */
    private ExcelResult<T> createInstance(Row dataRow, List<String> titleList, Map<String, FieldAnnoBean<T>> annoMap) throws Exception {

        ExcelResult<T> oneResult = new ExcelResult<T>();

        int columTotalSize = titleList.size();
        List<String> orginColumns = new ArrayList<>();
        try {

            T instance = this.clazz.newInstance();
            // 遍历每一列
            for (int i = 0; i < columTotalSize; i++) {
                Cell cell = dataRow.getCell(i);
                String cellString = getValue(cell);
                orginColumns.add(cellString);
            }

            oneResult.setOrginColumns(orginColumns);

            // 将excel中的当前行数据转换为Object
            for (int i = 0; i < columTotalSize; i++) {
                String cellString = orginColumns.get(i);
                // 获取此列的对应的标题
                String title = titleList.get(i);
                // 如果这一列的标题和类中的某一列的Annotation相同，那么则调用此类的的set方法，进行设值
                if (annoMap.containsKey(title)) {
                    FieldAnnoBean<T> fieldAnnoBean = annoMap.get(title);
                    if (fieldAnnoBean != null) {
                        fieldAnnoBean.setInvoke(instance, cellString, title);
                    }
                }
            }

            oneResult.setSuccessRow(instance);

        } catch (ParseException ex) {
            oneResult.setErrorMsg(ex.getMessage());
        }

        return oneResult;
    }

    private String getValue(Cell cell) {
        if (cell == null)
            return "";
        else {
            if (cell.getCellType() == Cell.CELL_TYPE_NUMERIC) {
                return String.valueOf(cell.getNumericCellValue());
            } else if (cell.getCellType() == Cell.CELL_TYPE_STRING) {
                return cell.getStringCellValue() + "";
            } else if (cell.getCellType() == Cell.CELL_TYPE_BOOLEAN) {
                return cell.getBooleanCellValue() + "";
            } else if (cell.getCellType() == Cell.CELL_TYPE_FORMULA) {
                CellValue value = evaluator.evaluate(cell);
                return value.formatAsString();
            } else if (cell.getCellType() == Cell.CELL_TYPE_BLANK) {
                return "";
            } else {
                return "";
            }
        }
    }

    public Map<String, FieldAnnoBean<T>> getFieldAnnoBeanMap() throws Exception {
        List<FieldAnnoBean<T>> list = getFieldAnnoBeanList();
        Map<String, FieldAnnoBean<T>> map = new HashMap<>();
        for (FieldAnnoBean t : list) {
            map.put(t.getTitle(), t);
        }
        return map;
    }

    public List<FieldAnnoBean<T>> getFieldAnnoBeanList() throws Exception {
        Class clazz = this.clazz;
        List<Field> fieldsList = new ArrayList<Field>();
        while (clazz != null) {  // 遍历所有父类字节码对象
            Field[] declaredFields = clazz.getDeclaredFields();
            fieldsList.addAll(Arrays.asList(declaredFields));  //将`Filed[]`数组转换为`List<>`然后再将其拼接至`ArrayList`上

            clazz = clazz.getSuperclass();  // 获得父类的字节码对象
        }
//        Field filed[] = this.clazz.getDeclaredFields();
        List<FieldAnnoBean<T>> list = new ArrayList<>();

        for (int i = 0; i < fieldsList.size(); i++) {
            Field field = fieldsList.get(i);
            ExcelAnnotation excelAnnotation = field.getAnnotation(ExcelAnnotation.class);
            if (excelAnnotation != null) {

                String title = excelAnnotation.title();
                boolean require = excelAnnotation.require();
                int scale = excelAnnotation.scale();
                String dateFormat = excelAnnotation.dateFormat();
                int order = excelAnnotation.order();

                if (StringUtils.isBlank(title)) {
                    continue;
                }

                String fieldName = field.getName();
                String setMethodName = "set" + fieldName.substring(0, 1).toUpperCase() + fieldName.substring(1);
                String getMethodName = "get" + fieldName.substring(0, 1).toUpperCase() + fieldName.substring(1);

                Method setMethod;
                Method getMethod;

                if (fieldName.startsWith("is")) {
                    try {
                        String isSetMethodName = "set" + fieldName.substring(2, 3).toUpperCase() + fieldName.substring(3);
                        String isGetMethodName = "is" + fieldName.substring(2, 3).toUpperCase() + fieldName.substring(3);
                        setMethod = this.clazz.getMethod(isSetMethodName, new Class[]{field.getType()});
                        getMethod = this.clazz.getMethod(isGetMethodName);

                    } catch (Exception ex) {
                        setMethod = this.clazz.getMethod(setMethodName, new Class[]{field.getType()});
                        getMethod = this.clazz.getMethod(getMethodName);
                    }
                } else {
                    setMethod = this.clazz.getMethod(setMethodName, new Class[]{field.getType()});
                    getMethod = this.clazz.getMethod(getMethodName);
                }


                Type[] setParamters = setMethod.getGenericParameterTypes();
                String paramClassString = setParamters[0].toString();
                // 获取属性类型对应的转换器

                TypeProcessor processor = TypeProcessorFactory.getInstance().getProcessor(paramClassString, scale, dateFormat);

                if (setMethod == null) {
                    throw new Exception(fieldName + "无Set方法");
                }

                if (processor == null) {
                    throw new Exception(paramClassString + "类型没有定义对应的处理器");
                }

                FieldAnnoBean<T> fieldAnnoBean = new FieldAnnoBean<>();
                fieldAnnoBean.setSetMethod(setMethod);
                fieldAnnoBean.setGetMethod(getMethod);
                fieldAnnoBean.setTypeProcessor(processor);
                fieldAnnoBean.setRequire(require);
                fieldAnnoBean.setTitle(title);
                fieldAnnoBean.setOrder(order);
                list.add(fieldAnnoBean);
            }
        }

        Collections.sort(list);

        return list;
    }

    public static String generateFileName() {
        // 获得当前时间
        DateFormat format = new SimpleDateFormat("yyyyMMddHHmmss");
        // 转换为字符串
        String formatDate = format.format(new Date());
        // 随机生成文件编号
        int random = new Random().nextInt(10000);
        return new StringBuffer().append(formatDate).append(
                random).toString();
    }

    public List<String> getTitles(File file, int sheetNo) {
        InputStream is = null;
        try {
            is = new FileInputStream(file);
            String fileName = file.getName();
            Workbook book = getWorkBook(is, fileName);
            Sheet sheet = book.getSheetAt(sheetNo);
            Iterator<Row> rows = sheet.rowIterator();

            // 得到第一行，也就是标题行,循环遍历，将标题的文字内容放入到List
            Row titleRow = rows.next();
            List<String> titleList = getTitleList(titleRow);
            return titleList;
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            if (is != null) {
                try {
                    is.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return null;
    }

    public String exportExcel(String errorOutPath, String fileName, List<String> titles, List<List<String>> errorRows) {
        if (errorRows == null || errorRows.size() == 0) {
            return null;
        }
        File file = new File(errorOutPath + fileName);

        OutputStream outputStream = null;

        try {

            if (!file.getParentFile().exists()) {
                file.getParentFile().mkdirs();
            }

            if (!file.exists()) {
                file.createNewFile();
            }

            outputStream = new FileOutputStream(file);
            Workbook book = getWorkBook(fileName);

            Sheet sheet = book.createSheet("1");
            sheet.setDefaultColumnWidth(15);

            Row titleRow = sheet.createRow(0);
            for (int i = 0; i < titles.size(); i++) {
                Cell cell = titleRow.createCell(i);
                cell.setCellValue(titles.get(i));
            }

            for (int i = 0; i < errorRows.size(); i++) {
                List<String> rowData = errorRows.get(i);
                Row row = sheet.createRow(i + 1);
                for (int j = 0; j < rowData.size(); j++) {
                    Cell cell = row.createCell(j);
                    cell.setCellValue(rowData.get(j));
                }
            }

            book.write(outputStream);

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            if (outputStream != null) {
                try {
                    outputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return null;
    }

    public String exportExcel(String outputPath, String fileName, List<T> list) {
        File file = new File(outputPath + fileName);

        OutputStream outputStream = null;

        try {

            if (!file.getParentFile().exists()) {
                file.getParentFile().mkdirs();
            }

            if (!file.exists()) {
                file.createNewFile();
            }

            outputStream = new FileOutputStream(file);
            Workbook book = getWorkBook(fileName);
            Sheet sheet = book.createSheet("1");
            sheet.setDefaultColumnWidth(15);

            List<FieldAnnoBean<T>> annoList = getFieldAnnoBeanList();
            Row titleRow = sheet.createRow(0);
            for (int i = 0; i < annoList.size(); i++) {
                Cell cell = titleRow.createCell(i);
                cell.setCellValue(annoList.get(i).getTitle());
            }

            for (int i = 0; i < list.size(); i++) {
                T rowData = list.get(i);
                Row row = sheet.createRow(i + 1);

                int cellIndex = 0;
                for (FieldAnnoBean annoBean : annoList) {
                    Object value = annoBean.getInvoke(rowData);
                    String valueString = annoBean.getTypeProcessor().toString(value);
                    Cell cell = row.createCell(cellIndex++);
                    cell.setCellValue(valueString);
                }
            }

            book.write(outputStream);

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            if (outputStream != null) {
                try {
                    outputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return null;
    }

    /*创建工作簿 写数据*/
    public Workbook exportExcel(List<T> list) throws Exception {

        //  Workbook book = new HSSFWorkbook();
        Workbook book = new XSSFWorkbook();
        //创建单元格，并设置值表头 设置表头居中
        // HSSFCellStyle cellStyle = (HSSFCellStyle) book.createCellStyle();
        XSSFCellStyle cellStyle = (XSSFCellStyle) book.createCellStyle();
        cellStyle.setBottomBorderColor(HSSFColor.RED.index);

        Sheet sheet = book.createSheet("1");
        sheet.setDefaultColumnWidth(15);
        //设置字体
        XSSFFont font = ((XSSFWorkbook) book).createFont();
        font.setFontHeightInPoints((short) 12);
        font.setFontName("宋体");
        font.setItalic(true);
        font.setColor(HSSFColor.RED.index);
        //设置样式
        XSSFCellStyle style = ((XSSFWorkbook) book).createCellStyle();
        style.setFont(font);

        List<FieldAnnoBean<T>> annoList = getFieldAnnoBeanList();
        FieldAnnoBean outannoBean = annoList.get(0);
        int outClassType = 0;//导出类型
        if (outannoBean.getMethod.getDeclaringClass().getName().equals("com.ruida.cloud.model.KnowledgeImportPOJO")) {
            outClassType = 1;
        }
        Row titleRow = sheet.createRow(0);
        for (int i = 0; i < annoList.size(); i++) {
            Cell cell = titleRow.createCell(i);
            cell.setCellValue(annoList.get(i).getTitle());
        }
        int globalIndex = 0;//记录全局最大非空列
        for (int i = 0; i < list.size(); i++) {
            T rowData = list.get(i);
            Row row = sheet.createRow(i + 1);

            Boolean isRemark = false;
            for (FieldAnnoBean annoBean : annoList) {
                Object value = annoBean.getInvoke(rowData);
                //防止日期格式化等类型错误
                String title = annoBean.getTitle();
                if (i >= 0) {
                    if (title.equals("上传失败原因") && ValidateMT.isNotNull(value)) {
                        isRemark = true;
                    }
                }
            }
            int cellIndex = 0;
            int firstBlank = 0;//每一行第一个空列
            for (FieldAnnoBean annoBean : annoList) {
                Object value = annoBean.getInvoke(rowData);
                if (ValidateMT.isNull(value)) {

                    if (outClassType == 1) {
                        if (firstBlank == 0) {
                            firstBlank = cellIndex;
                        }
                        if (globalIndex == 0) {
                            globalIndex = cellIndex;
                        } else if (globalIndex < firstBlank) {
                            globalIndex = firstBlank;
                        }
                        if (globalIndex <= cellIndex) {
                            sheet.setColumnHidden(cellIndex, true);
                        } else {
                            sheet.setColumnHidden(cellIndex, false);
                        }
                    }

                } else {
                    sheet.setColumnHidden(cellIndex, false);
                }

                //防止日期格式化等类型错误
                String title = annoBean.getTitle();
//  String valueString = ValidateMT.isNull(value)?"":annoBean.getTypeProcessor().toString(value);
                String valueString = ValidateMT.isNull(value) ? "" : (String) value;
                Cell cell = row.createCell(cellIndex++);
                cell.setCellValue(valueString);
                if (i >= 0 && isRemark) {

                    cell.setCellStyle(style);///设置cell样式


                }


            }
        }

        return book;
    }


}
