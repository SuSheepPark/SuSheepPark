package com.ruida.mockdao.dao;

import com.ruida.mockdao.model.TCeeRank;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.vo.MaxAndMinScoreVO;

import java.util.List;
import java.util.Map;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author szl
 * @since 2021-06-02
 */
public interface TCeeRankMapper extends BaseMapper<TCeeRank> {
    /**
     * 两个年份的分数转换
     * @param param
     * @return
     */
   Double getScoreConversion(Map param);

    /**
     * 获取一分一段每年最高最低分
     * @return
     */
   List<MaxAndMinScoreVO> getMaxAndMinScore();
}
