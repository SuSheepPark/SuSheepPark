package com.ruida.mockdao.vo.report;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @description: 测试次数VO
 * @author: kgz
 * @date: 2021/7/27
 */
@Data
public class TestCountVO implements Serializable {

    /**
     * 报告id
     */
    private Integer id;

    /**
     * 创建时间
     */
    @JsonFormat(pattern= "yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date createTime;

    /**
     * 描述
     */
    private String description;
}
