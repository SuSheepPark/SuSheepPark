package com.ruida.mockservice.service;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.ruida.mockcommon.enums.AppErrorEnum;
import com.ruida.mockcommon.enums.ExamSubmitStatusEnum;
import com.ruida.mockcommon.enums.QuestionTypeEnum;
import com.ruida.mockcommon.exception.CoreException;
import com.ruida.mockdao.model.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.List;

/**
 * Created by xumingqi on 2021/8/2 11:09
 */
@Service
@Slf4j
public class ProductAsyncServiceImpl implements ProductAsyncService {
    @Resource
    TestPaperUserRelService testPaperUserRelService;
    @Resource
    ProductUserRelService productUserRelService;
    @Resource
    TestPaperProductRelService testPaperProductRelService;
    @Resource
    ProductService productService;
    @Resource
    ExamRecordService examRecordService;
    @Resource
    TestNodeQuestionRelService testNodeQuestionRelService;
    @Resource
    ExamDetailService examDetailService;

    @Override
    @Async
    public void saveAnswerRate(ExamRecord examRecord) {
        //找到这张试卷下所有题目的数量(组合题父题不算)
        EntityWrapper<TestNodeQuestionRel> entityWrapper = new EntityWrapper<>();
        entityWrapper.eq("test_paper_id", examRecord.getTestPaperId()).ne("question_type_id", QuestionTypeEnum.CQT.getK())
                .eq("isdelete", 0);
        int totalNum = testNodeQuestionRelService.selectCount(entityWrapper);
        //查询本次考试记录已答题的数量
        EntityWrapper<ExamDetail> wrapper = new EntityWrapper<>();
        wrapper.eq("exam_record_id", examRecord.getId())
                .isNull("pid")
                .isNotNull("answer")
                .eq("isdelete", 0);
        int answeredNum = examDetailService.selectCount(wrapper);
        BigDecimal rate = BigDecimal.valueOf(answeredNum).divide(BigDecimal.valueOf(totalNum), 2, 4);
        examRecord.setRate(rate);
        examRecordService.updateById(examRecord);

        // 在线统考 没有商品id
        if (examRecord.getProductId() != null) {
            TestPaperUserRel testPaperUserRel = testPaperUserRelService.selectOne(new EntityWrapper<TestPaperUserRel>()
                    .eq("user_id", examRecord.getCreateBy())
                    .eq("product_id", examRecord.getProductId())
                    .eq("test_paper_id", examRecord.getTestPaperId())
                    .eq("isdelete", 0));

            if (testPaperUserRel != null) {
                testPaperUserRel.setRate(rate);
                testPaperUserRelService.updateById(testPaperUserRel);
            }
        }
    }

    @Override
    @Async
    public void handlePaperRelAfterExam(int userId, int productId, int testPaperId, BigDecimal rate, int completeStatus) {

        TestPaperUserRel testPaperUserRel = testPaperUserRelService.selectOne(new EntityWrapper<TestPaperUserRel>()
                .eq("user_id", userId)
                .eq("product_id", productId)
                .eq("test_paper_id", testPaperId)
                .eq("isdelete", 0));

        if (null == testPaperUserRel) {
            return;
        }
        //未完成
        if (completeStatus == ExamSubmitStatusEnum.UN_SUBMIT.getK()) {
            testPaperUserRel.setRate(rate);
            testPaperUserRel.setCompleteStatus(completeStatus);
            boolean ret = testPaperUserRelService.updateById(testPaperUserRel);
            if (!ret) {
                throw new CoreException(AppErrorEnum.E_40019);
            }
        }
        //完成交卷
        else if (completeStatus == ExamSubmitStatusEnum.SUBMIT.getK()) {
            boolean ret = true;

            //更新试卷
            testPaperUserRel.setRate(rate);
            testPaperUserRel.setCompleteStatus(completeStatus);
            testPaperUserRel.setCompleteNum(testPaperUserRel.getCompleteNum() + 1);
            boolean ret1 = testPaperUserRelService.updateById(testPaperUserRel);
            if (!ret1) {
                ret = false;
            }

            //更新商品
            //第一次完成试卷，更新商品信息
            if (testPaperUserRel.getCompleteNum() == 1) {
                List<TestPaperUserRel> testPaperUserRels = testPaperUserRelService.selectList(new EntityWrapper<TestPaperUserRel>()
                        .eq("user_id", userId)
                        .eq("product_id", productId));

                int completePapers = 0;
                int allPapers = testPaperUserRels.size();
                for (TestPaperUserRel testPaperUserRel1 : testPaperUserRels) {
                    if (testPaperUserRel1.getCompleteNum() > 0) {
                        completePapers++;
                    }
                }
                DecimalFormat df = new DecimalFormat("0.00");//设置保留位数
                String newRate = df.format((float) completePapers / allPapers);

                ProductUserRel productUserRel = new ProductUserRel();
                productUserRel.setRate(new BigDecimal(newRate));
                boolean ret2 = productUserRelService.update(productUserRel, new EntityWrapper<ProductUserRel>()
                        .eq("user_id", userId)
                        .eq("product_id", productId)
                        .eq("isdelete", 0));
                if (!ret2) {
                    ret = false;
                }

                //更新试卷完成人数
                TestPaperProductRel testPaperProductRel = testPaperProductRelService.selectOne(new EntityWrapper<TestPaperProductRel>()
                        .eq("test_paper_id", testPaperId)
                        .eq("product_id", productId)
                        .eq("isdelete", 0));
                if (null != testPaperProductRel) {
                    testPaperProductRel.setInitTestNum(testPaperProductRel.getInitTestNum() == null ? 1 : testPaperProductRel.getInitTestNum() + 1);
                    boolean ret4 = testPaperProductRelService.updateById(testPaperProductRel);
                    if (!ret4) {
                        ret = false;
                    }
                }


                //更新商品完成人数
                if (completePapers == allPapers && completePapers > 0) {
                    Product product = productService.selectOne(new EntityWrapper<Product>()
                            .eq("product_id", productId));
                    product.setCompleteNum(product.getCompleteNum() + 1);
                    boolean ret3 = productService.updateById(product);
                    if (!ret3) {
                        ret = false;
                    }
                }
            }

            if (!ret) {
                throw new CoreException(AppErrorEnum.E_40019);
            }
        }
        return;
    }

}
