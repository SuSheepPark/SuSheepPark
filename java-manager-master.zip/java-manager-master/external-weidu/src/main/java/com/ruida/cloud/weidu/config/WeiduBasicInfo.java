package com.ruida.cloud.weidu.config;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

/**
 * @author mlzhang
 */
@Configuration
public class WeiduBasicInfo {
    @Value("#{common.vdyooTestApi}")
    public String vdyooTestApi;
    @Value("#{common.vdyooAppkey}")
    public String vdyooAppkey;
    @Value("#{common.vdyooTenantkey}")
    public String vdyooTenantkey;
    @Value("#{common.vdyooAppsecret}")
    public String vdyooAppsecret;
    @Value("#{common.vdyooV}")
    public String vdyooV;
}
