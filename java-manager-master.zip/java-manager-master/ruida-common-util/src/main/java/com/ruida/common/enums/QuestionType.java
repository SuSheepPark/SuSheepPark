package com.ruida.common.enums;

/**
 * @author mlzhang
 * @since 2019-04-04
 * desc  题目类型枚举类
 */
public enum QuestionType {
     CHOOSE(0,"单项选择题"),
     JUDDGE(1,"判断选择题")
    ;
    private Integer code;
    private String desc;

    QuestionType(Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

}
