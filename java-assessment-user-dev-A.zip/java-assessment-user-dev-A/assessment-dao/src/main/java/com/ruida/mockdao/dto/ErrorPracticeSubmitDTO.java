package com.ruida.mockdao.dto;

import lombok.Data;

import java.util.List;

/**
 * @description:
 * @author: chenjy
 * @create: 2020-10-19 16:24
 */
@Data
public class ErrorPracticeSubmitDTO {

    private Integer practiceId;

    private Integer duration;

    private List<QuestionDTO> questionList;
}
