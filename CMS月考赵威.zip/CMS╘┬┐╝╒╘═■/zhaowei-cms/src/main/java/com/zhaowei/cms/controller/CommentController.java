/**   
 * Copyright © 2019 公司名. All rights reserved.
 * 
 * @Title: CommentController.java 
 * @Prject: zhaowei-cms
 * @Package: com.zhaowei.cms.controller 
 * @Description: TODO
 * @author: zw   
 * @date: 2019年9月23日 下午8:34:14 
 * @version: V1.0   
 */
package com.zhaowei.cms.controller;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.github.pagehelper.PageInfo;
import com.zhaowei.cms.domain.Comment;
import com.zhaowei.cms.domain.User;
import com.zhaowei.cms.service.CommentService;
import com.zhaowei.cms.util.PageUtil;

/** 
 * @ClassName: CommentController 
 * @Description: TODO
 * @author: zw
 * @date: 2019年9月23日 下午8:34:14  
 */
@RequestMapping("comment")
@Controller
public class CommentController {

	@Resource
	private CommentService commentService;
	
	@GetMapping("selects")
	public String selects(Model model,@RequestParam(defaultValue = "1")Integer page,
			@RequestParam(defaultValue = "5")Integer pageSize,HttpServletRequest request) {
		HttpSession session = request.getSession(false);
		
		if(null==session) {
			return "redirect:/passport/login";//session是空的证明没有登陆或者过期了
		}
		User user = (User) session.getAttribute("user");
		PageInfo<Comment> info = commentService.selectsByUserId(user.getId(), page, pageSize);
		String pages = PageUtil.page(page, info.getPages(), "/comment/selects", pageSize);
		model.addAttribute("comments", info.getList());
		model.addAttribute("pages", pages);
		return "/my/comments";
	}
		
	
}
