package com.ruida.cloud.dao;

import com.ruida.cloud.model.StudentExt;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface StudentMapperExt {
    int countStudentByExample(Map condition);

    List<StudentExt> selectStudentByExample(Map condition);

    List<StudentExt> listStudentByExample(Map condition);
    /**根据组织架构查询班级学生列表*/
    List<StudentExt> listStudentByOrgS(Map condition);
    /**根据组织架构查询班级学生数量*/
    Integer countStudentByOrgS(Integer id);
    //根据名称获取学生信息（模糊查询）
    List<StudentExt> listStudentInfoByName(Map condition);
    //根据id获取学生信息
    StudentExt getStudentInfoById(Integer stuId);

    Map<String, Object> getStudentBroadcastRoomInfo(Map condition);

    List<Map<String, Object>> selectCourseStudentByExample(Map condition);

    int countCourseStudentByExample(Map condition);

    List<String> selectCourseHeadTeachers(Integer courseId);
    //根据id获取学生信息(加上省市区)
    StudentExt getStudentInfoTById(Integer stuId);
    //优惠券查询学生信息
    List<Map<String, Object>> selectCouponStudentByExample(Map condition);
    //优惠券查询学生信息条数
    int countCouponStudentByExample(Map condition);
    //该学生是否已经拥有优惠券
    Integer boolHaveCoupon(@Param("userId") Integer userId,@Param("couponId") Integer couponId);
}
