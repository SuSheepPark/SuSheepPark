package com.ruida.mockdao.vo;

import com.ruida.mockdao.pojo.BasicSubjectInfo;
import com.ruida.mockdao.pojo.ReportBasicInfo;
import com.ruida.mockdao.pojo.SubjectInfo;
import lombok.Data;

import java.util.List;

/**
 * @description: 以往成绩表现报告VO
 * @author: chenjy
 * @create: 2021-01-18 09:49
 */
@Data
public class FormerPerformanceReportVO extends ReportBasicInfo {

    private String subjectName = "综合";

    private List<BasicSubjectInfo> subjectScoreList;

    private List<SubjectInfo> subjectRankList;
}
