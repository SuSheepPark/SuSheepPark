package com.ruida.mockdao.vo.report;

import lombok.Data;

import java.util.List;


/**
 * @author xumingqi
 * @date 2021/3/3 17:04
 */
@Data
public class CollegePreferenceReportListVO {
    Integer id;
    String name;
    Double score;
    List<String> subjectList;
    Integer majorCount;
    String createTimeFormat;
}
