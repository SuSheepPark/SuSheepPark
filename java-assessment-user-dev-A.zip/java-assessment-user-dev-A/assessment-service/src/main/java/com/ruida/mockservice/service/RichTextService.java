package com.ruida.mockservice.service;

/**
 * @description: 富文本处理
 * @author: chenjy
 * @create: 2020-08-03 10:32
 */
public interface RichTextService {
    String getHtmlRTF(String rtf);
}
