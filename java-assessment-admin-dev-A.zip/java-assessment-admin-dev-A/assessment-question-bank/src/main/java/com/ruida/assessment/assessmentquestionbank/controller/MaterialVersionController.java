package com.ruida.assessment.assessmentquestionbank.controller;

import com.ruida.assessment.assessmentcommon.result.ListResult;
import com.ruida.assessment.assessmentquestionbank.service.MaterialVersionService;
import com.ruida.assessment.assessmentquestionbank.service.QuestionDifficultyService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * @description: 教材版本控制层
 * @author: kgz
 * @date: 2020/6/29
 */
@RequestMapping("/materialVersion")
@RestController
@Api(value ="教材版本接口")
public class MaterialVersionController {

    @Resource
    private MaterialVersionService materialVersionService;

    @GetMapping("/getList")
    @ApiOperation(value = "获取教材版本下拉框列表", notes = "获取教材版本下拉框列表")
    public ListResult getList(){
        ListResult listResult = new ListResult();
        listResult.setContent(materialVersionService.getList());
        return listResult;
    }
    @GetMapping("/getListByPeriodSubjectId")
    @ApiOperation(value = "获取教材版本下拉框列表", notes = "获取教材版本下拉框列表")
    public ListResult getListByPeriodSubjectId(Integer periodId, Integer subjectId){
        ListResult listResult = new ListResult();
        listResult.setContent(materialVersionService.getListByPeriodSubjectId(periodId,subjectId));
        return listResult;
    }

}
