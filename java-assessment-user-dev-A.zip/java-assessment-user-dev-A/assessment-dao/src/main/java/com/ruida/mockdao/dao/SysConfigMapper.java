package com.ruida.mockdao.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.model.SysConfig;
import org.apache.ibatis.annotations.Mapper;

/**
 * Created by xumingqi on 2021/5/11 11:39
 */
@Mapper
public interface SysConfigMapper extends BaseMapper<SysConfig> {
}
