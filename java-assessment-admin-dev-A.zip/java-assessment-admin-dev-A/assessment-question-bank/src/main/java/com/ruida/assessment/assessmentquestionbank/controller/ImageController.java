package com.ruida.assessment.assessmentquestionbank.controller;

import com.ruida.assessment.assessmentcommon.enums.ResultStatusCode;
import com.ruida.assessment.assessmentcommon.result.BaseResult;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;

@RestController
@Slf4j
public class ImageController {
    /**
     * 下载文件
     * @param
     * @param response
     */
    @RequestMapping("datadrive/ruidaceping/upload/**")
    @CrossOrigin
    public BaseResult downloadImg(HttpServletRequest request, HttpServletResponse response) {
        BaseResult result = new BaseResult();
        String filePath =  request.getRequestURI();
        String fileName = filePath.substring(filePath.lastIndexOf("/")+1);
        if (filePath != null) {
            //设置文件路径
            File file = new File(filePath);
            if (file.exists()) {
                // response.setContentType("application/force-download");// 设置强制下载不打开
                response.addHeader("Content-Disposition", "attachment;fileName="+fileName);// 设置文件名
                response.setContentLengthLong(file.length());
                byte[] buffer = new byte[1024];
                FileInputStream fis = null;
                BufferedInputStream bis = null;
                try {
                    fis = new FileInputStream(file);
                    bis = new BufferedInputStream(fis);
                    OutputStream os = response.getOutputStream();
                    int i = bis.read(buffer);
                    while (i != -1) {
                        os.write(buffer, 0, i);
                        i = bis.read(buffer);
                    }
                    log.debug("下载成功");
                    result.setMsg("下载成功！");
                } catch (Exception e) {
                    log.debug("下载失败");
                    result.setErrorMessage(ResultStatusCode.DEAL_FAIL.getCode(),"下载失败！");
                } finally {
                    if (bis != null) {
                        try {
                            bis.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                    if (fis != null) {
                        try {
                            fis.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        }
        return result;
    }
}
