package com.ruida.cloud.weidu.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.ruida.cloud.dao.WeiduTeachingClassRelMapper;
import com.ruida.cloud.model.WeiduTeachingClassRel;
import com.ruida.cloud.weidu.config.WeiduConfig;
import com.ruida.cloud.weidu.exception.VdyooException;
import com.ruida.cloud.weidu.service.BaseVdyooService;
import com.ruida.cloud.weidu.vo.VdyooEntity;
import com.ruida.common.context.BaseContextHandle;
import com.ruida.common.util.ValidateMT;
import lombok.extern.log4j.Log4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * 教学班关联信息：
 * 威渡教师id       assistantId
 * 威渡教室id       roomId
 * 课程班id         courseClassId
 *
 * @author taosh
 * @create 2019-04-23 15:10
 */
@Service
@Log4j
public class VdyooClassService extends BaseVdyooService {
    @Resource
    WeiduTeachingClassRelMapper weiduTeachingClassRelMapper;

    /**
     * 创建教学班
     * , propagation= Propagation.NESTED
     */
    @Transactional(rollbackFor = Exception.class,propagation=Propagation.NESTED)
    public String addClasses(Map<String, Object> param) {
        VdyooEntity entity = this.vdyooFactory.post(param, WeiduConfig.addClasss);
        boolean flag = false;
        if (entity.getSuccess()) {
            String id = null;
            try {
                WeiduTeachingClassRel rel = new WeiduTeachingClassRel();
                rel.setTeachingClassId((Integer) param.get("pid"));
                JSONObject jsonObject = (JSONObject) JSONObject.toJSON(entity.getPayload());
                rel.setWeiduTeachingClassId(jsonObject.getString("id"));
                rel.setIsdelete((byte) 0);
                rel.setCreateBy(BaseContextHandle.getUserId());
                rel.setUpdateBy(BaseContextHandle.getUserId());
                rel.setCreateTime(new Date());
                rel.setUpdateTime(new Date());
                rel.setIscommit((byte)0);
                flag = weiduTeachingClassRelMapper.insert(rel) > 0;

                id = jsonObject.getString("id");
                if (!flag) {
                    throw new VdyooException("500", "威渡教学班信息关联失败，请联系管理员或稍后再试");
                } else {
                    return id;
                }
            } catch (Exception e) {
                //回滚事务
                if(ValidateMT.isNotNull(id)){
                    this.deleteClassesById(id);
                }
                throw new VdyooException("500","教学班信息关联失败，请联系管理员或稍后再试");
            }
        }else {
            throw new VdyooException("500", entity.getMessage());
        }
    }

    /**
     * 删除教学班级
     *
     * @param id
     */
    public VdyooEntity deleteClassesById(String id) {
        Map<String, Object> param = new HashMap<>(1);
        //威渡id
        param.put("id", id);
        return this.vdyooFactory.post(param, WeiduConfig.deleteClasssById);
    }

    /**
     * 编辑教学班级
     */
    public boolean editClassesById(Map<String, Object> param) {

        // Map<String, Object> param = VdyooUtil.getSignMap();
        //威渡id
//        param.put("id", "123");
//        //教学班级名称
//        param.put("name", "roomId");
//        //班级默认的助教老师ID     todo   暂无
//        param.put("assistantId", "123");
//        //班级默认的教室ID     todo   暂无
//        param.put("roomId", "123");
//        //所属课程班的ID      todo   暂无
//        param.put("courseClassId", "roomId");

//        String response = HttpClientUtil.postMap(path, param);
//        System.out.println(response);
        return this.vdyooFactory.post(param, WeiduConfig.editClasssById).getSuccess();
    }

    /**
     * 通过ID查询教学班级
     */
    public boolean findClassById(Integer id) {

        Map<String, Object> param = new HashMap<>(1);
        //威渡id
        param.put("id", id);
        return this.vdyooFactory.post(param, WeiduConfig.findClassById).getSuccess();
    }

    /**
     * 查询公司下全部教学班
     */
    public boolean findTeachingClassByTenant() {
        VdyooEntity entity = this.vdyooFactory.post(WeiduConfig.findTeachingClassByTenant);

        System.out.println(entity.getPayload());

        return entity.getSuccess();
    }
}
