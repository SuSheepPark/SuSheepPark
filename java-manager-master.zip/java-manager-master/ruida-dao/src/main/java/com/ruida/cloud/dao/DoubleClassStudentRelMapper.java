package com.ruida.cloud.dao;

import com.ruida.cloud.model.DoubleClassStudentRel;
import com.ruida.cloud.model.DoubleClassStudentRelExample;
import java.util.List;

import com.ruida.cloud.model.DoubleStudent;
import org.apache.ibatis.annotations.Param;

public interface DoubleClassStudentRelMapper {
    int countByExample(DoubleClassStudentRelExample example);

    int deleteByExample(DoubleClassStudentRelExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(DoubleClassStudentRel record);

    int insertSelective(DoubleClassStudentRel record);

    List<DoubleClassStudentRel> selectByExample(DoubleClassStudentRelExample example);

    DoubleClassStudentRel selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") DoubleClassStudentRel record, @Param("example") DoubleClassStudentRelExample example);

    int updateByExample(@Param("record") DoubleClassStudentRel record, @Param("example") DoubleClassStudentRelExample example);

    int updateByPrimaryKeySelective(DoubleClassStudentRel record);

    int updateByPrimaryKey(DoubleClassStudentRel record);

    List<DoubleStudent> selectByClassId(@Param("classId") Integer classId,@Param("telephone") String telephone,@Param("studentName") String studentName,@Param("studentNo") String studentNo);
}