package com.ruida.cloud.model;

import lombok.Data;

@Data
public class DoubleStudentPOJO {

    private String studentName;
    private String studentNo;
    private String sex;
    private String telephone;

}
