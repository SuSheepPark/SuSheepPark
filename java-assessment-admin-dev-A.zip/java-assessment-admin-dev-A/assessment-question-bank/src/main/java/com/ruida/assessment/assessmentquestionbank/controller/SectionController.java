package com.ruida.assessment.assessmentquestionbank.controller;

import com.ruida.assessment.assessmentcommon.enums.ResultStatusCode;
import com.ruida.assessment.assessmentcommon.result.BaseResult;
import com.ruida.assessment.assessmentcommon.result.ListResult;
import com.ruida.assessment.assessmentcommon.result.PojoResult;
import com.ruida.assessment.assessmentquestionbank.annotaion.UserAuth;
import com.ruida.assessment.assessmentquestionbank.dto.BatchOperationRequest;
import com.ruida.assessment.assessmentquestionbank.dto.MoveTreeRequest;
import com.ruida.assessment.assessmentquestionbank.dto.SectionRequest;
import com.ruida.assessment.assessmentquestionbank.service.ISectionService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * @author wy
 * @description 章节管理业务层
 * @date 2020/6/10
 */
@RequestMapping("/section")
@RestController
public class SectionController {
    @Resource
    private ISectionService sectionService;

    /*
     *功能描述   查询章节树形结构
     * @param
     * @return
     */
    @UserAuth
    @PostMapping("query/sectionTree")
    public ListResult querySectionTree(@RequestBody SectionRequest request){
        return  sectionService.querySectionTreeList(request);
    }

    /*
     *功能描述   章节新增
     * @param
     * @return
     */
    @UserAuth
    @PostMapping("add/addSection")
    public PojoResult addSection(@RequestBody SectionRequest sectionRequest){
        return sectionService.addSection(sectionRequest);
    }

    /*
     *功能描述    章节编辑
     * @param
     * @return
     */
    @UserAuth
    @PostMapping("update/updateSection")
    public BaseResult updateSection(@RequestBody SectionRequest sectionRequest){

        BaseResult result = sectionService.updateSection(sectionRequest);
        return result;
    }

    /*
     *功能描述    批量禁用、启用
     * @param
     * @return
     */
    @UserAuth
    @PostMapping("stop/batchStopSection")
    public BaseResult batchStopSection(@RequestBody BatchOperationRequest batchOperationRequest){
        BaseResult result = new BaseResult();
        result.setMsg("操作成功");
        Boolean flag = sectionService.batchStopSection(batchOperationRequest);
        if (flag)
            return result;
        return result.setErrorMessage(ResultStatusCode.DEAL_FAIL.getCode(),"操作失败");
    }

    /*
     *功能描述    单个删除章节
     * @param
     * @return
     */
    @UserAuth
    @PostMapping("delete/deleteSection")
    public BaseResult deleteSection(@RequestBody SectionRequest sectionRequest){
        return sectionService.deleteSectionById(sectionRequest);
    }

    /*
     *功能描述   查询章节关联的知识点
     * @param
     * @return
     */
    @UserAuth
    @PostMapping("query/queryKnowledgeBySection")
    public ListResult queryknowledgeBySection(@RequestBody SectionRequest request){
        return  sectionService.queryknowledgeBySection(request);
    }

    /*
     *功能描述   章节批量添加知识点
     * @param
     * @return
     */
    @UserAuth
    @PostMapping("add/addSectionKnowledge")
    public BaseResult addSectionKnowledge(@RequestBody BatchOperationRequest batchOperationRequest){
        return sectionService.addSectionKnowledge(batchOperationRequest);
    }


    /*
     *功能描述    单个删除章节关联的知识点
     * @param
     * @return
     */
    @UserAuth
    @PostMapping("delete/deleteSectionKnowledgeById")
    public BaseResult deleteKnowledgeByRelationId(@RequestBody BatchOperationRequest request){
        return sectionService.deleteKnowledgeByRelationId(request);
    }


    /*
     *功能描述    结构树移动  上移、下移、升级
     * @param
     * @return
     */
    @UserAuth
    @PostMapping("exchange/moveSectionTree")
    public BaseResult moveKnowledgeTree(@RequestBody MoveTreeRequest moveTreeRequest){
        BaseResult result = new BaseResult();
        result.setMsg("操作成功");
        Boolean flag = sectionService.moveSectionTree(moveTreeRequest);
        if (flag)
            return result;
        return result.setErrorMessage(ResultStatusCode.DEAL_FAIL.getCode(),"操作失败");
    }

    /*
     * 功能描述   批量删除章节    (一期只实现父节点单选批量删除单个父节点及其所有子集)
     * @param
     * @return
     */
    @UserAuth
    @PostMapping("delete/batchDeleteSection")
    public ListResult batchDeleteSection(@RequestBody SectionRequest request){
        return sectionService.batchDeleteSection(request);
    }
}
