package com.ruida.assessment.assessmentquestionbank.dto;

import io.swagger.annotations.ApiModel;
import lombok.Data;

import java.util.List;

@Data
@ApiModel(value = "导入细目表DTO")
public class DetailTableFiledDTO {

    private Integer nodeId;
    private Integer questionTypeId;
    private Integer difficultyId;
    private String num;
    private String bigNum;
    private Double score;
    private Double regressionScore;
    private List<QuestionKnowledgeRelationDTO> questionKnowledgeRelationDTOList;
    private Integer assessmentTargetId;
}
