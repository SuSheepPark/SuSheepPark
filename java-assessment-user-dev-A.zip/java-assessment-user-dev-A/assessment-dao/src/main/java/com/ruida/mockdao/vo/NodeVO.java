package com.ruida.mockdao.vo;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import java.util.List;

/**
 * @description: 小节VO
 * @author: chenjy
 * @create: 2020-07-13 12:00
 */
@Data
public class NodeVO {

    /**
     * 小节id
     */
    private Integer nodeId;

    /**
     * 小节名称
     */
    private String nodeTitle;

    /**
     * 小节在试卷中顺序
     */
    private Integer nodeSort;

    /**
     * 小节分数
     */
    @JsonInclude(value = JsonInclude.Include.NON_NULL)
    private Double nodeScore;

    /**
     * 试题集合
     */
    private List<QuestionVO> questionList;
}
