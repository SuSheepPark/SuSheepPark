package com.ruida.cloud.dao;

import com.ruida.cloud.model.Ability;
import com.ruida.cloud.model.AbilityExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface AbilityMapper {
    int countByExample(AbilityExample example);

    int deleteByExample(AbilityExample example);

    int deleteByPrimaryKey(Integer abilityId);

    int insert(Ability record);

    int insertSelective(Ability record);

    List<Ability> selectByExample(AbilityExample example);

    Ability selectByPrimaryKey(Integer abilityId);

    int updateByExampleSelective(@Param("record") Ability record, @Param("example") AbilityExample example);

    int updateByExample(@Param("record") Ability record, @Param("example") AbilityExample example);

    int updateByPrimaryKeySelective(Ability record);

    int updateByPrimaryKey(Ability record);

    List<Ability> selectAbility(Ability ability);
}