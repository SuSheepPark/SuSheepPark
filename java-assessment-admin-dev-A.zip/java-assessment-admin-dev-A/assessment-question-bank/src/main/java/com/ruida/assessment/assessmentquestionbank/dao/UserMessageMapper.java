package com.ruida.assessment.assessmentquestionbank.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.assessment.assessmentcommon.result.Page;
import com.ruida.assessment.assessmentquestionbank.dto.QueryBaseDTO;
import com.ruida.assessment.assessmentquestionbank.model.TUserMessage;
import com.ruida.assessment.assessmentquestionbank.vo.MessageCustomVO;
import com.ruida.assessment.assessmentquestionbank.vo.UserMessageVO;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * @description:
 * @author: kgz
 * @date: 2020/7/24
 */
@Mapper
public interface UserMessageMapper extends BaseMapper<TUserMessage> {
}
