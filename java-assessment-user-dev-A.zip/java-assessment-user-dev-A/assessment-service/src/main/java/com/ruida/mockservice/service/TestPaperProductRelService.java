package com.ruida.mockservice.service;

import com.baomidou.mybatisplus.service.IService;
import com.ruida.mockdao.model.TestPaperProductRel;

import java.util.List;

/**
 * <p>
 * 商品-试卷关联表 服务类
 * </p>
 *
 * @author chenjy
 * @since 2020-07-17
 */
public interface TestPaperProductRelService extends IService<TestPaperProductRel> {
    List<TestPaperProductRel> getListByProductId(Integer productId);

    TestPaperProductRel getByProductIdAndTestPaperId(Integer productId, Integer testPaperId);
}
