package com.ruida.mockdao.model;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import lombok.Data;

/**
 * @description: 年级信息表
 */
@Data
public class TGrade {

    /**
     * 年级id
     */
    @TableId
    private Integer gradeId;

    /**
     * 年级名称
     */
    private String gradeName;

    /**
     * 状态（0—禁用；1—启用）
     */
    private Integer status;

    /**
     * 学段id
     */
    private Integer periodId;
}
