package com.ruida.assessment.assessmentquestionbank.dao;

import java.util.List;
import java.util.Map;

import com.ruida.assessment.assessmentquestionbank.vo.*;
import org.apache.ibatis.annotations.MapKey;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.ruida.assessment.assessmentquestionbank.dto.ReportDTO;

/**
 * @description:
 * @author: kgz
 * @date: 2020/10/19
 */
@Mapper
public interface ClassReportMapper {

	/**
	 * 获取班级得分情况
	 *
	 * @param reportDTO
	 * @return
	 */
	List<ClassReportVO> getClassReportScoreInfo(@Param("req") ReportDTO reportDTO);

	/**
	 * 获取排名情况 本校、9+1学校、全体学校
	 *
	 * @param reportDTO
	 * @return
	 */
	List<ReportRankVO> getReportClassRankInfo(@Param("req") ReportDTO reportDTO);

	/**
	 * 查询9+1学校班级
	 *
	 * @param reportDTO
	 * @return
	 */
	int getNineOneSchoolClass(@Param("req") ReportDTO reportDTO);
	
	/**
	 * 查询9+1学校数量
	 *
	 * @param reportDTO
	 * @return
	 */
	int countNineOneSchool(Integer testPaperId);
	
	/**
	 * 查询9+1学校数量
	 *
	 * @param reportDTO
	 * @return
	 */
	int countAllSchool(Integer testPaperId);

	/**
	 * 查询班级学员得分情况
	 *
	 * @param reportDTO
	 * @return
	 */
	List<ClassScoreVO> getClassStudentScore(@Param("req") ReportDTO reportDTO);

	/**
	 * 获取试题平均得分
	 *
	 * @param reportDTO
	 * @return
	 */
	@MapKey("questionId")
	Map<String,ReportAvgScoreVO> getReportAvgScore(@Param("req") ReportDTO reportDTO);

	/**
	 * 查询本班试题平均得分的排名
	 *
	 * @param reportDTO
	 * @return
	 */
	List<ReportRankVO> getReportQuestionAvgScoreRank(@Param("req") ReportDTO reportDTO);

	/**
	 * 查询学校范围内的试题平均得分的排名
	 *
	 * @param reportDTO
	 * @return
	 */
	List<ReportRankVO> getSchoolReportQuestionAvgScoreRank(@Param("req") ReportDTO reportDTO);

	/**
	 * 查询本班学员答题信息
	 *
	 * @param reportDTO
	 * @return
	 */
	List<StudentExamQuestionVO> getStudentExamQuestion(@Param("req") ReportDTO reportDTO);

	/**
	 * 查询报告中的知识点
	 *
	 * @param reportDTO
	 * @return
	 */
	List<KnowledgeStatVO> getReportKnowledge(@Param("req") ReportDTO reportDTO);

	/**
	 * 查询知识点得分情况
	 *
	 * @param reportDTO
	 * @return
	 */
	@MapKey("knowledgeId")
	Map<Integer,KnowledgeStatVO> getReportKnowledgeScore(@Param("req") ReportDTO reportDTO);

	/**
	 * 查询知识点得分率（平均得分）排名
	 *
	 * @param reportDTO
	 * @return
	 */
	List<ReportRankVO> getReportKnowledgeRank(@Param("req") ReportDTO reportDTO);

	/**
	 * 查询学校层面的知识点得分率（平均得分）排名，别问为什么在Class*里面
	 *
	 * @param reportDTO
	 * @return
	 */
	List<ReportRankVO> getSchoolReportKnowledgeRank(@Param("req") ReportDTO reportDTO);

	/**
	 * 查询参加考试的班级id
	 *
	 * @param reportDTO
	 * @return
	 */
	List<ClassVo> getReportClassIds(@Param("req") ReportDTO reportDTO);

	/**
	 * 查询班级学生知识点得分率情况
	 *
	 * @param reportDTO
	 * @return
	 */
	List<ClassRateVO> getStudentKnowledgeRateScore(@Param("req") ReportDTO reportDTO);

	/**
	 * 查询报告中的考察目标
	 *
	 * @param reportDTO
	 * @return
	 */
	List<TargetStatVO> getReportTarget(@Param("req") ReportDTO reportDTO);

	/**
	 * 查询考察目标得分情况
	 *
	 * @param reportDTO
	 * @return
	 */
	TargetStatVO getReportTargetScore(@Param("req") ReportDTO reportDTO);

	/**
	 * 查询考察目标排名信息
	 *
	 * @param reportDTO
	 * @return
	 */
	List<ReportRankVO> getReportTargeRank(@Param("req") ReportDTO reportDTO);

	/**
	 * 查询学校的考察目标排名信息
	 *
	 * @param reportDTO
	 * @return
	 */
	List<ReportRankVO> getSchoolReportTargeRank(@Param("req") ReportDTO reportDTO);

    /**
     * 查询班级学员考察目标得分率情况
     * @param classReportDTO
     * @return
     */
    List<ClassRateVO> getStudentTargetRateScore(@Param("req") ReportDTO classReportDTO);

    /**
     * 查询试卷的科目
     * @param testPaperId
     * @return
     */
    Integer getSubjectId(Integer testPaperId);
}
