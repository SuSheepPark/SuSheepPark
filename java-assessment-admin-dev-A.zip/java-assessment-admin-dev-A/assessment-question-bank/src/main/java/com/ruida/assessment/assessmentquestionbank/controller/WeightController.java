package com.ruida.assessment.assessmentquestionbank.controller;

import com.ruida.assessment.assessmentcommon.result.BaseResult;
import com.ruida.assessment.assessmentcommon.result.ListResult;
import com.ruida.assessment.assessmentcommon.util.ValidList;
import com.ruida.assessment.assessmentquestionbank.annotaion.UserAuth;
import com.ruida.assessment.assessmentquestionbank.dto.WeightDTO;
import com.ruida.assessment.assessmentquestionbank.model.Weight;
import com.ruida.assessment.assessmentquestionbank.service.WeightService;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * @description:
 * @author: chenjy
 * @create: 2020-12-16 16:32
 */
@RestController
@RequestMapping("/weight/")
public class WeightController {

    @Resource
    private WeightService weightService;

    @UserAuth
    @GetMapping("queryWeight")
    public ListResult<Weight> queryWeight(Integer reportId){
        ListResult<Weight> result = new ListResult<>();
        List<Weight> list = weightService.queryWeight(reportId);
        result.setContent(list);
        result.setTotalCount(list.size());
        result.setMsg("查询成功");
        return result;
    }

    @UserAuth
    @PostMapping("saveWeight")
    public BaseResult saveWeight(@RequestBody @Validated ValidList<Weight> weightList){
        BaseResult result = new BaseResult();
        boolean flag = weightService.saveProduct(weightList);
        if(flag){
            result.setMsg("保存成功");
        }else {
            result.setErrorMessage(500,"保存失败");
        }
        return result;
    }

    @UserAuth
    @PostMapping("product/stage")
    public ListResult<Weight> queryWeight(@RequestBody WeightDTO weightDTO){
        ListResult<Weight> result = new ListResult<>();
        List<Weight> list = weightService.getReportWeightStageList(weightDTO);
        result.setContent(list);
        result.setTotalCount(list.size());
        result.setMsg("查询成功");
        return result;
    }

    @UserAuth
    @GetMapping("deleteWeight")
    public BaseResult deleteWeight(Integer reportId){
        BaseResult result = new BaseResult();
        boolean flag = weightService.deleteWeight(reportId);
        if(flag){
            result.setMsg("删除成功");
        }else {
            result.setErrorMessage(500,"删除失败");
        }
        return result;
    }
}
