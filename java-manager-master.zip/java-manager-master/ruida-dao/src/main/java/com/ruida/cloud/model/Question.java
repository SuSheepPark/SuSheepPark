package com.ruida.cloud.model;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class Question implements Serializable {
    private TCourseQuestion courseQuestion;
    //是否有改动
    private Boolean zbupdate = false;
    //是否含有从表记录（当题目类型是单选题 则为true ）
    private Boolean items =false;
    //从表是否有改动
    private Boolean cbupdate = false;
    private List<TCourseQuestionItem> questionItemList ;
}
