package com.ruida.assessment.assessmentquestionbank.model;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;

import java.io.Serializable;

/**
 * @description: 小节数据库实体
 * @author: kgz
 * @date: 2020/6/29
 */
@TableName("t_test_node")
public class TTestNode extends BaseColumn implements Serializable {
    private static final long serialVersionUID = -8851900936551551811L;

    /**
     * 小节id
     */
    @TableId
    private Integer nodeId;

    /**
     * 试卷名称
     */
    private String nodeTitle;

    /**
     * 试卷id
     */
    private Integer testPaperId;

    /**
     * 小节排序
     */
    private Integer sort;

    /**
     * 分值
     */
    private Double score;

    public Integer getNodeId() {
        return nodeId;
    }

    public void setNodeId(Integer nodeId) {
        this.nodeId = nodeId;
    }

    public String getNodeTitle() {
        return nodeTitle;
    }

    public void setNodeTitle(String nodeTitle) {
        this.nodeTitle = nodeTitle;
    }

    public Integer getTestPaperId() {
        return testPaperId;
    }

    public void setTestPaperId(Integer testPaperId) {
        this.testPaperId = testPaperId;
    }

    public Integer getSort() {
        return sort;
    }

    public void setSort(Integer sort) {
        this.sort = sort;
    }

    public Double getScore() {
        return score;
    }

    public void setScore(Double score) {
        this.score = score;
    }

    @Override
    public String toString() {
        return "TTestNode{" +
                "nodeId=" + nodeId +
                ", nodeTitle='" + nodeTitle + '\'' +
                ", testPaperId=" + testPaperId +
                ", sort=" + sort +
                ", score=" + score +
                '}';
    }
}
