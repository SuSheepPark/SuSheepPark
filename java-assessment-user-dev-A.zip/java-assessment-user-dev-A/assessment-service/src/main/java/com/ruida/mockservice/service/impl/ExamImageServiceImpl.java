package com.ruida.mockservice.service.impl;

import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.ruida.mockdao.dao.ExamImageMapper;
import com.ruida.mockdao.model.ExamImage;
import com.ruida.mockservice.service.ExamImageService;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author chenjy
 * @since 2020-07-14
 */
@Service
public class ExamImageServiceImpl extends ServiceImpl<ExamImageMapper, ExamImage> implements ExamImageService {

}
