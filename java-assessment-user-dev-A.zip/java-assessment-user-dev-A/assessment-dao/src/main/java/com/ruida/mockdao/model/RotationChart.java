package com.ruida.mockdao.model;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 轮播图表
 * </p>
 *
 * @author Bhj
 * @since 2020-07-10
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@TableName("t_rotation_chart")
public class RotationChart implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 轮播图主键ID
     */
    @TableId(value = "rotation_chart_id", type = IdType.AUTO)
    private Integer rotationChartId;
    /**
     * 轮播图名称
     */
    @TableField("rotation_chart_name")
    private String rotationChartName;
    /**
     * 位置类型(1-首页banner)
     */
    @TableField("location_type")
    private Integer locationType;
    /**
     * 使用位置(0-web端;1-app端;2-小程序端)
     */
    @TableId(value = "source")
    private Integer source;
    /**
     * 轮播图路径
     */
    @TableField("image_url")
    private String imageUrl;
    /**
     * 跳转链接url
     */
    @TableField("link_url")
    private String linkUrl;
    /**
     * 图片排序
     */
    @TableField("image_sort")
    private Integer imageSort;
    /**
     * 状态(0-待上架 1-使用中 2-已下架)
     */
    @TableId(value = "status")
    private Integer status;
    /**
     * 上架时间
     */
    @TableField("up_time")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date upTime;
    /**
     * 下架时间
     */
    @TableField("down_time")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date downTime;
    /**
     * 创建者ID
     */
    @TableField("create_by")
    private Integer createBy;
    /**
     * 创建时间
     */
    @TableField("create_time")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date createTime;
    /**
     * 更新者ID
     */
    @TableField("update_by")
    private Integer updateBy;
    /**
     * 更新时间
     */
    @TableField("update_time")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date updateTime;
    /**
     * 是否删除（0：未删除；1：删除）
     */
    private Integer isdelete;

}
