package com.ruida.cloud.dao;

import com.ruida.cloud.model.StartschooltestExt;
import com.ruida.cloud.model.TStartSchoolTest;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * 入学诊断信息表 Mapper 接口
 * </p>
 *
 * @author mlzhang
 * @since 2019-12-16
 */
public interface TStartSchoolTestMapper {
    @Select("SELECT\n" +
            "\ta.id,\n" +
            "\ta.score,\n" +
            "\ta.question_library_id AS questionLibraryId,\n" +
            "\ta.serial_number AS serialNumber,\n" +
            "\tb.question_title AS questionTitle,\n" +
            "\tb.question_type_actual_id AS questionTypeActualId,\n" +
            "\tb.stem,\n" +
            "\tb.answer\n" +
            "FROM\n" +
            "\tt_startschooltest_question_rel a\n" +
            "LEFT JOIN t_question_library b ON a.question_library_id = b.question_library_id\n" +
            "WHERE\n" +
            "\ta.isdelete = 0\n" +
            "AND b.parent_id = b.question_library_id\n" +
            "AND a.start_school_test_id = #{id}\n" +
            "ORDER BY\n" +
            "\ta.serial_number")
    List<Map<String, Object>> getQuestionListByTestId(@Param("id") Integer id);

    @Select("SELECT\n" +
            "\ta.serial_number AS serialNumber,\n" +
            "\tb.stem,\n" +
            "\tb.answer,\n" +
            "\ta.question_library_id AS questionLibraryId,\n" +
            "\tb.question_title AS questionTitle,\n" +
            "\ta.score,\n" +
            "\tb.question_type_actual_id AS questionTypeActualId,\n" +
            "\ta.id\n" +
            "FROM\n" +
            "\tt_startschooltest_question_rel a\n" +
            "LEFT JOIN t_question_library b ON a.question_library_id = b.question_library_id\n" +
            "WHERE\n" +
            " b.parent_id = #{parentId} and a.start_school_test_id =#{testId}\n" +
            "and  b.question_library_id > b.parent_id\n" +
            "AND a.isdelete = 0 Order by b.question_sort  \n")
    List<Map<String, Object>> getQustionInfoByParentId(@Param("parentId") Integer parentId, @Param("testId") Integer testId);

    Integer insert(TStartSchoolTest tStartSchoolTest);

    Integer updateById(TStartSchoolTest tStartSchoolTest);

    int updateByPrimaryKeySelective(TStartSchoolTest tStartSchoolTest);

    TStartSchoolTest selectById(@Param("startSchoolTestId") Integer startSchoolTestId);
}
