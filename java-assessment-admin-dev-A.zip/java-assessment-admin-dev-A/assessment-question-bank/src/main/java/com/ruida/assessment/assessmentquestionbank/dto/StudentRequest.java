package com.ruida.assessment.assessmentquestionbank.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ruida.assessment.assessmentcommon.result.Page;
import com.ruida.assessment.assessmentquestionbank.SystemConstant;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;

/**
 * @author wy
 * @description 学员请求类
 * @date 2020/7/31
 */
@Data
public class StudentRequest {


        /*
        学生主键ID
         */
        private Integer stuId;

        /*
        用户id
         */
        private Integer userId;

        /*
        学生学号
         */
        private String stuNo;

        /*
        学生姓名
         */
        private String stuName;

        /*
       学生账号
       */
        private String stuAccount;

        /*
        昵称
         */
        private String nickname;

        private Integer age;

        private Integer sex;

        /*
        身份证号
         */
        private String idCard;

        private String telephone;

        /*
        渠道来源
         */
        private Integer sourceChannel;

        private Integer schoolId;

        private Integer periodId;

        private Integer gradeId;

        private Integer classId;

        private Integer productId;//商品id

        private String searchWord;

        private Integer district; // 地区、县ID

        @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
        @JsonFormat(pattern= "yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
        private Date startTime;

        @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
        @JsonFormat(pattern= "yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
        private Date endTime;


        /* 分页 */
        private Page page;
        private Integer start;
        private Integer size;

        private Integer type;// 如果是批量导入学员 type值为1
}
