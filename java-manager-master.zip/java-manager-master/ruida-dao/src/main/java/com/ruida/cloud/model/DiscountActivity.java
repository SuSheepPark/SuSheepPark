package com.ruida.cloud.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ruida.common.SystemConstant;

import java.io.Serializable;
import java.util.Date;

public class DiscountActivity implements Serializable {
    private Integer discountActivityId;

    private String discountName;

    /**
     * 优惠类型（0—联报优惠；1—带新优惠）
     */
    private Byte discountType;

    /**
     * 适用范围   （0—新生；1—老客户；2—全部）
     */
    private Byte applicationScope;

    /**
     * （如果是0，则表示通用，否则就是校区ID，用逗号连接）
     */
    private String applicationZone;

    @JsonFormat(pattern = "yyyy-MM-dd",timezone= SystemConstant.TIME_ZONE)
    private Date startDate;

    @JsonFormat(pattern = "yyyy-MM-dd",timezone= SystemConstant.TIME_ZONE)
    private Date endDate;

    private Byte status;

    private Integer createBy;

    private Date createTime;

    private Integer updateBy;

    private Date updateTime;

    private Byte isdelete;

    private static final long serialVersionUID = 1L;

    public Integer getDiscountActivityId() {
        return discountActivityId;
    }

    public void setDiscountActivityId(Integer discountActivityId) {
        this.discountActivityId = discountActivityId;
    }

    public String getDiscountName() {
        return discountName;
    }

    public void setDiscountName(String discountName) {
        this.discountName = discountName == null ? null : discountName.trim();
    }

    public Byte getStatus() {
        return status;
    }

    public void setStatus(Byte status) {
        this.status = status;
    }


    public Byte getDiscountType() {
        return discountType;
    }

    public void setDiscountType(Byte discountType) {
        this.discountType = discountType;
    }

    public Byte getApplicationScope() {
        return applicationScope;
    }

    public void setApplicationScope(Byte applicationScope) {
        this.applicationScope = applicationScope;
    }

    public String getApplicationZone() {
        return applicationZone;
    }

    public void setApplicationZone(String applicationZone) {
        this.applicationZone = applicationZone == null ? null : applicationZone.trim();
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public Integer getCreateBy() {
        return createBy;
    }

    public void setCreateBy(Integer createBy) {
        this.createBy = createBy;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(Integer updateBy) {
        this.updateBy = updateBy;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Byte getIsdelete() {
        return isdelete;
    }

    public void setIsdelete(Byte isdelete) {
        this.isdelete = isdelete;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", discountActivityId=").append(discountActivityId);
        sb.append(", discountName=").append(discountName);
        sb.append(", discountType=").append(discountType);
        sb.append(", applicationScope=").append(applicationScope);
        sb.append(", applicationZone=").append(applicationZone);
        sb.append(", startDate=").append(startDate);
        sb.append(", endDate=").append(endDate);
        sb.append(", createBy=").append(createBy);
        sb.append(", createTime=").append(createTime);
        sb.append(", updateBy=").append(updateBy);
        sb.append(", updateTime=").append(updateTime);
        sb.append(", isdelete=").append(isdelete);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}