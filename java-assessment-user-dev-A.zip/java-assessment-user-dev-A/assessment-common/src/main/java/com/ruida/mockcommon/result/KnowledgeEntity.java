package com.ruida.mockcommon.result;

import lombok.Data;

@Data
public class KnowledgeEntity {
    int status;
    String msg;
    int count;
    Object knowledgeInfo;
}
