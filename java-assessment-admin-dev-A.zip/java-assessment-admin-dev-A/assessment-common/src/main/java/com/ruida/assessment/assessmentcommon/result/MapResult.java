package com.ruida.assessment.assessmentcommon.result;

import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @description:
 * @author szl
 * @Date 2018年12月10日
 * @verion 1.0
 */
public class MapResult<K, V> extends BaseResult {

	private static final long serialVersionUID = 319981086482245382L;
	
	private Map<K, V> content;

	private List<Map<K, V>> msgDetail = new ArrayList<>();

	public MapResult<K, V> add(K key, V val) {
		if (content == null) {
			setContent(new HashMap<K, V>(16));
		}
		getContent().put(key, val);
		return this;
	}

	public Map<K, V> getContent() {
		return content;
	}

	public void setContent(Map<K, V> content) {
		this.content = content;
	}

	public List<Map<K, V>> getMsgDetail() {
		return msgDetail;
	}

	public void setMsgDetail(List<Map<K, V>> msgDetail) {
		this.msgDetail = msgDetail;
	}

	public void add(Map<K, V> msgMap){
		if (msgDetail != null) {
			msgDetail.add(msgMap);
		}
	}
}
