package com.ruida.mockservice.service;

import com.ruida.mockcommon.result.ListResult;
import com.ruida.mockcommon.result.MapResult;
import com.ruida.mockcommon.result.PageData;
import com.ruida.mockcommon.result.PojoResult;
import com.ruida.mockdao.dto.ExamRecordDTO;
import com.ruida.mockdao.dto.ReportDTO;
import com.ruida.mockdao.vo.FormerPerformanceReportVO;
import com.ruida.mockdao.vo.OptionalSubjectReportVO;
import com.ruida.mockdao.vo.report.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

public interface ReportService {

    /**
     * 查看个人报告
     * @param reportDTO
     * @return
     */
    ReportVO getReport(ReportDTO reportDTO);

    /**
     * 获取历次测试得分情况
     * @param reportDTO
     * @return
     */
    HistoryReportVO getHistoryReport(ReportDTO reportDTO);

    /**
     * 获取9+1个人报告
     * @param reportDTO
     * @param httpServletRequest
     * @return
     */
    ReportVO getNineOneReport(ReportDTO reportDTO, HttpServletRequest httpServletRequest);
    
    /**
     * 获取一分一赋的9+1个人报告
     * @param reportDTO
     * @param httpServletRequest
     * @return
     */
    ReportVO getNineOneInterval1Report(ReportDTO reportDTO, HttpServletRequest httpServletRequest);

    MapResult checkOptionalStatus(Integer userId);

    /**
     * 生成历史成绩报告
     * @return
     */
    FormerPerformanceReportVO genFormerReport();

    List<ExamRecordDTO> assignPoint(List<ExamRecordDTO> examRecordDTOS);

    /**
     * 生成科目选考报告中的以往成绩表现信息
     * @return
     */
    Integer genOptionalSubjectReport();

    /**
     * 获取科目选考报告中的以往成绩表现信息
     * @param id
     * @return
     */
    OptionalSubjectReportVO getOptionalSubjectReport(Integer id);

    /**
     * 获取初中联考报告
     * @param reportDTO
     * @return
     */
    ReportExtVO getUnionReport(ReportDTO reportDTO);

    /**
     * 查询学生报告详情
     * @param reportDTO
     * @return
     */
    PojoResult getStudentReport(ReportDTO reportDTO);

    /**
     * 查询测试次数
     * @param reportDTO
     * @return
     */
    List<TestCountVO> getTestCount(ReportDTO reportDTO);

    /**
     * 获取个人成绩报告
     * @param reportDTO
     * @return
     */
    PojoResult getPersonalReport(ReportDTO reportDTO);

    /**
     * 报告是否生成
     * @param reportDTO
     * @return
     */
    Boolean personalReportIsFinished(ReportDTO reportDTO);

    /**
     * 分页查询已经生成报告的实施计划列表
     * @param reportDTO
     * @return
     */
    PageData<ImplementPlanVO> getReportFinishedImplementPlanList(ReportDTO reportDTO);

    /**
     * 根据实施计划、准考证号查询场次科目列表
     * @param planId
     * @param stuId
     * @return
     */
    ListResult getSceneSubjectList(String planId, Integer stuId);

    /**
     * 根据场次、准考证号查询个人报告
     * @param sceneId
     * @param stuId
     * @return
     */
    PojoResult getSceneStudentReport(String sceneId, Integer stuId);
    

	/**
	 * 在线统考考试结束后，发送消息计算报告
	 * @param sceneId
	 * @param testPaperId
	 */
	void startCalculateUnifiedReport(String sceneId, Integer testPaperId);
}
