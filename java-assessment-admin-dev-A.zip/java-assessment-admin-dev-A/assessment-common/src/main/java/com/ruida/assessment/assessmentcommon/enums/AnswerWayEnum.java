package com.ruida.assessment.assessmentcommon.enums;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @description: 答题方式
 * @author: kgz
 * @date: 2021/6/30
 */
public enum AnswerWayEnum {
    ONLINE(1,"在线答题"),
    OFFLINE_PAPER(2,"纸面答题"),
    ;


    private Integer K;
    private String V;

    AnswerWayEnum(Integer k, String v) {
        K = k;
        V = v;
    }

    public static List<Map<String, Object>> getList() {
        List<Map<String, Object>> list = new ArrayList<>();
        for(AnswerWayEnum answerWayEnum : AnswerWayEnum.values() ){
            Map<String, Object> map = new HashMap<>();
            map.put("id", answerWayEnum.getK());
            map.put("name", answerWayEnum.getV());
            list.add(map);
        }
        return list;
    }

    public Integer getK() {
        return K;
    }

    public void setK(Integer k) {
        K = k;
    }

    public String getV() {
        return V;
    }

    public void setV(String v) {
        V = v;
    }


    public static AnswerWayEnum getValueById(Integer K){
        for(AnswerWayEnum answerWayEnum : AnswerWayEnum.values() ){
            if(answerWayEnum.getK().equals(K)){
                return  answerWayEnum;
            }
        }
        return null;
    }

}
