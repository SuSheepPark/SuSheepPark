package com.ruida.cloud.model;

import java.io.Serializable;
import java.util.Date;

public class Campus implements Serializable {
    /**
     * 校区ID，主键自增长
     */
    private Integer campusId;

    /**
     * 校区名称
     */
    private String campusName;

    /**
     * 学段ID（多个ID用逗号隔开）
     */
    private String periodId;

    /**
     * 校区省份ID
     */
    private Integer campusProvince;

    /**
     * 校区城市ID
     */
    private Integer campusCity;

    /**
     * 校区地区ID
     */
    private Integer campusDistrict;

    /**
     * 校区街道名称
     */
    private String campusStreet;

    /**
     * 校区详细地址
     */
    private String campusDetailAddr;

    /**
     * 双师负责人姓名
     */
    private String personInCharge;

    /**
     * 校区电话
     */
    private String campusTel;

    /**
     * 联系邮箱
     */
    private String email;

    /**
     * 创建者ID
     */
    private Integer createBy;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新者ID
     */
    private Integer updateBy;

    /**
     * 更新时间
     */
    private Date updateTime;

    /**
     * 是否删除（0：未删除；1：删除）
     */
    private Byte isdelete;

    public Integer getCampusId() {
        return campusId;
    }

    public void setCampusId(Integer campusId) {
        this.campusId = campusId;
    }

    public String getCampusName() {
        return campusName;
    }

    public void setCampusName(String campusName) {
        this.campusName = campusName == null ? null : campusName.trim();
    }

    public String getPeriodId() {
        return periodId;
    }

    public void setPeriodId(String periodId) {
        this.periodId = periodId == null ? null : periodId.trim();
    }

    public Integer getCampusProvince() {
        return campusProvince;
    }

    public void setCampusProvince(Integer campusProvince) {
        this.campusProvince = campusProvince;
    }

    public Integer getCampusCity() {
        return campusCity;
    }

    public void setCampusCity(Integer campusCity) {
        this.campusCity = campusCity;
    }

    public Integer getCampusDistrict() {
        return campusDistrict;
    }

    public void setCampusDistrict(Integer campusDistrict) {
        this.campusDistrict = campusDistrict;
    }

    public String getCampusStreet() {
        return campusStreet;
    }

    public void setCampusStreet(String campusStreet) {
        this.campusStreet = campusStreet == null ? null : campusStreet.trim();
    }

    public String getCampusDetailAddr() {
        return campusDetailAddr;
    }

    public void setCampusDetailAddr(String campusDetailAddr) {
        this.campusDetailAddr = campusDetailAddr == null ? null : campusDetailAddr.trim();
    }

    public String getPersonInCharge() {
        return personInCharge;
    }

    public void setPersonInCharge(String personInCharge) {
        this.personInCharge = personInCharge == null ? null : personInCharge.trim();
    }

    public String getCampusTel() {
        return campusTel;
    }

    public void setCampusTel(String campusTel) {
        this.campusTel = campusTel == null ? null : campusTel.trim();
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email == null ? null : email.trim();
    }

    public Integer getCreateBy() {
        return createBy;
    }

    public void setCreateBy(Integer createBy) {
        this.createBy = createBy;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(Integer updateBy) {
        this.updateBy = updateBy;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Byte getIsdelete() {
        return isdelete;
    }

    public void setIsdelete(Byte isdelete) {
        this.isdelete = isdelete;
    }
}