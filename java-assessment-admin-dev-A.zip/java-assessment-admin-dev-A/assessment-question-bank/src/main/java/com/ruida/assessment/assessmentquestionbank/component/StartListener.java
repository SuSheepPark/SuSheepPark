package com.ruida.assessment.assessmentquestionbank.component;

import com.ruida.assessment.assessmentquestionbank.dao.PeriodMapper;
import com.ruida.assessment.assessmentquestionbank.dao.StageMapper;
import com.ruida.assessment.assessmentquestionbank.model.TPeriod;
import com.ruida.assessment.assessmentquestionbank.model.TStage;
import com.ruida.assessment.assessmentquestionbank.model.Weight;
import com.ruida.assessment.assessmentquestionbank.service.WeightService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import javax.annotation.Resource;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * @description:
 * @author: chenjy
 * @create: 2020-12-16 15:21
 */
@Component
@Slf4j
public class StartListener implements ApplicationListener<ApplicationReadyEvent> {

    @Resource
    private WeightService weightService;
    @Resource
    private StageMapper stageMapper;
    @Resource
    private PeriodMapper periodMapper;

    private static Map<Integer,Integer> map = new LinkedHashMap<>();

    static {
        //小学
        map.put(1,5);
        map.put(2,5);
        map.put(3,5);
        map.put(4,5);
        map.put(5,5);
        map.put(6,5);
        map.put(7,10);
        map.put(8,10);
        map.put(9,10);
        map.put(10,10);
        map.put(11,15);
        map.put(12,15);

        //初中
        map.put(13,10);
        map.put(14,10);
        map.put(15,15);
        map.put(16,15);
        map.put(17,25);
        map.put(18,25);

        //高中
        map.put(19,10);
        map.put(20,10);
        map.put(21,15);
        map.put(22,15);
        map.put(23,25);
        map.put(24,25);
    }

    @Override
    public void onApplicationEvent(ApplicationReadyEvent applicationReadyEvent) {

        List<Weight> weightList = weightService.selectList(null);

        if(CollectionUtils.isEmpty(weightList)){
            //log.info("启动监听，设置权重默认值...");
            map.forEach((stageId,defaultWeight) -> {
                TStage stage = stageMapper.selectById(stageId);
                TPeriod period = periodMapper.getPeriodByGrade(stage.getGradeId());
                Weight weight = new Weight();
                weight.setPeriodId(period.getId());
                weight.setPeriodName(period.getPeriodName());
                weight.setStageId(stageId);
                weight.setStageName(stage.getStageName());
                weight.setWeight(defaultWeight);
                weight.setIsdefault(1);
                weight.setCreateTime(new Date());
                weightList.add(weight);
            });

            weightService.insertBatch(weightList);
        }

    }
}
