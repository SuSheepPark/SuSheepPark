package com.ruida.assessment.assessmentquestionbank.dto;

import io.swagger.annotations.ApiModelProperty;

/**
 * @description: 分页查询基础类
 * @author: kgz
 * @date: 2020/7/21
 */
public class QueryBaseDTO {
    @ApiModelProperty(value = "当前页，默认为1", name = "currentPage")
    private Integer currentPage = 1;

    @ApiModelProperty(value = "页大小，默认为10", name = "pageSize")
    private Integer pageSize = 10;

    public Integer getCurrentPage() {
        return currentPage;
    }

    public void setCurrentPage(Integer currentPage) {
        this.currentPage = currentPage;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public Integer getPageIndex() {
        return (this.currentPage - 1) * pageSize;
    }

    @Override
    public String toString() {
        return "QueryBaseDTO{" +
                "currentPage=" + currentPage +
                ", pageSize=" + pageSize +
                '}';
    }
}
