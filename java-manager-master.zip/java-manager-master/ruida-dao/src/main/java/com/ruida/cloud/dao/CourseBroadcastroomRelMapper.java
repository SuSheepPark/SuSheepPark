package com.ruida.cloud.dao;

import com.ruida.cloud.model.CourseBroadcastroomRel;
import com.ruida.cloud.model.CourseBroadcastroomRelExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface CourseBroadcastroomRelMapper {
    long countByExample(CourseBroadcastroomRelExample example);

    int deleteByExample(CourseBroadcastroomRelExample example);

    int deleteByPrimaryKey(Integer courseBroadcastroomId);

    int insert(CourseBroadcastroomRel record);

    int insertSelective(CourseBroadcastroomRel record);

    List<CourseBroadcastroomRel> selectByExample(CourseBroadcastroomRelExample example);

    CourseBroadcastroomRel selectByPrimaryKey(Integer courseBroadcastroomId);

    int updateByExampleSelective(@Param("record") CourseBroadcastroomRel record, @Param("example") CourseBroadcastroomRelExample example);

    int updateByExample(@Param("record") CourseBroadcastroomRel record, @Param("example") CourseBroadcastroomRelExample example);

    int updateByPrimaryKeySelective(CourseBroadcastroomRel record);

    int updateByPrimaryKey(CourseBroadcastroomRel record);

    /**
     * 批量插入数据
     */
    int insertBatch(List<CourseBroadcastroomRel> list);

    /**
     *
     */
    List<CourseBroadcastroomRel> listCourseBroadcastRoomByCourseId(Integer courseId);

    int deleteByCourseIdAndBoradcastRoomId(Integer courseBroadcastRoomRelId,Integer courseId);

    CourseBroadcastroomRel selectByCourseIdAndCampusId(Integer courseId, Integer campusId,Integer assistantTeacherId);

    List<CourseBroadcastroomRel> getBroadcastroomRelInfoByCampusId(@Param("courseId") Integer courseId,@Param("campusId") Integer campusId);

    int updateOnlineStuNum(@Param("courseId") Integer courseId,@Param("broadcastRoomId")  Integer broadcastRoomId,@Param("campusId")  Integer campusId,@Param("onlineStuNum")  Integer onlineStuNum);

    int updateOnlineStuNumMove(@Param("courseId") Integer courseId,@Param("broadcastRoomId")  Integer broadcastRoomId,@Param("onlineStuNum")  Integer onlineStuNum);
}