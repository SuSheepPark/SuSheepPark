package com.ruida.common.interceptor;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Created by Administrator on 2018/3/19.
 */
@Target({ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
public @interface LoggerRequire {

    public static final String OPER_TYPE_LOGIN = "1";   // 操作类型:登录操作
    public static final String OPER_TYPE_SAVE = "3";    // 操作类型:保存数据
    public static final String OPER_TYPE_DELETE = "4";  // 操作类型:删除数据
    public static final String OPER_TYPE_DOWNLOAD = "5";  // 操作类型:下载数据

    String operType() default "0";                      // 操作类型
    String moduleName() default "";                     // 模块名

}
