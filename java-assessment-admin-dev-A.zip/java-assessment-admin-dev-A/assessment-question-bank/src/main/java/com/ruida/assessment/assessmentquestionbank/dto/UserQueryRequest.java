package com.ruida.assessment.assessmentquestionbank.dto;

import com.ruida.assessment.assessmentcommon.result.Page;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

@Data
@ApiModel(description = "用户列表查询条件")
public class UserQueryRequest {

    /* 是否绑定考生 0-否 1-是 */
    @ApiModelProperty(value = "是否绑定考生 0-否 1-是", name = "isboundStu")
    private Integer isboundStu;

    /* 是否绑定微信 0-否 1-是 */
    @ApiModelProperty(value = "是否绑定微信 0-否 1-是 ", name = "isboundWeChat")
    private Integer isboundWeChat;

    /* 注册来源 */
    @ApiModelProperty(value = "注册来源", name = "source")
    private Integer source;

    /* 是否禁用 */
    @ApiModelProperty(value = "是否禁用 0-禁用 1-启用", name = "status")
    private Integer status;

    @ApiModelProperty(value = "注册时间-开始时间", name = "startTime")
    private String startTime;

    @ApiModelProperty(value = "注册时间-结束时间", name = "endTime")
    private String endTime;

    @ApiModelProperty(value = "最后登录时间-开始时间", name = "loginTimeStart")
    private String loginTimeStart;

    @ApiModelProperty(value = "最后登录时间-结束时间", name = "loginTimeEnd")
    private String loginTimeEnd;

    /* 模糊查询字段  昵称/手机号  手机号为精准查询*/
    @ApiModelProperty(value = "模糊查询字段", name = "searchWord")
    private String searchWord;

    /* 用户id集合 */
    @ApiModelProperty(value = "用户id集合", name = "userIds")
    List<Integer> userIds;

    @ApiModelProperty(value = "手机号-用于查询", name = "telephone")
    private String telephone;

    /* 分页 */
    private Page page;
    private Integer start;
    private Integer size;

    private Integer productId;
    /*
    是否赠送报告 0-否 1-是
     */
    private Integer isPresentReport;


}
