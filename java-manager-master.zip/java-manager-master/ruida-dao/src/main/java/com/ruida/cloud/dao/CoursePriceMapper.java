package com.ruida.cloud.dao;

import com.ruida.cloud.model.CoursePrice;
import com.ruida.cloud.model.CoursePriceExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface CoursePriceMapper {
    int countByExample(CoursePriceExample example);

    int deleteByExample(CoursePriceExample example);

    int deleteByPrimaryKey(Integer coursePriceId);

    int insert(CoursePrice record);

    int insertSelective(CoursePrice record);

    List<CoursePrice> selectByExample(CoursePriceExample example);

    CoursePrice selectByPrimaryKey(Integer coursePriceId);

    int updateByExampleSelective(@Param("record") CoursePrice record, @Param("example") CoursePriceExample example);

    int updateByExample(@Param("record") CoursePrice record, @Param("example") CoursePriceExample example);

    int updateByPrimaryKeySelective(CoursePrice record);

    int updateByPrimaryKey(CoursePrice record);

    //新方法
    List<Map<String, Object>> listCoursePriceByIds(String courseIds);

    //获取课包价格
    List<Map<String, Object>> listPackageCoursePriceByCourseId(Integer courseId);
}