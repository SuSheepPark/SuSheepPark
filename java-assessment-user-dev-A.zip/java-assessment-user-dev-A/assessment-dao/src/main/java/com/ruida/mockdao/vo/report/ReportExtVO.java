package com.ruida.mockdao.vo.report;

import lombok.Data;

import java.util.List;

/**
 * @author chenjy
 * @date 2021/3/9
 */
@Data
public class ReportExtVO {

    private Integer reportId;

    private Boolean needBuy;

    private ReportBaseInfo reportBaseInfo;

    private ScoreRank classScoreRank;

    private ScoreRank schoolScoreRank;

    private ScoreRank unionScoreRank;

    /**试题知识点维度*/
    private List<ReportQuestionKnowledgeVO> reportQuestionKnowledgeList;

    /**题型维度*/
    private List<ReportQuestionTypeVO> reportQuestionTypeList;

    /**知识点维度*/
    private ReportStatKnowledgeVO reportKnowledge;

    /**考察目标维度*/
    private ReportTargetStatVO reportTarget;

    @Data
    public static class ReportBaseInfo{

        private String reportName;

        private String studentName;

        private String className;

        private String schoolName;

        private String subjectName;

        private Double score;

        private Double totalScore;
    }

    @Data
    public static class ScoreRank{
        private Integer rank;

        private Integer count;

        private Double top;

        private Double avg;
    }
}

