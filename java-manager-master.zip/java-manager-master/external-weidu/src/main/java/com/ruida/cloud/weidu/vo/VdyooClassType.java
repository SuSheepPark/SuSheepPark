package com.ruida.cloud.weidu.vo;

/**
 * @author taosh
 * @create 2019-07-26 11:28
 */
public class VdyooClassType {
    private String name;

    private String pid;

    private String id;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPid() {
        return pid;
    }

    public void setPid(String pid) {
        this.pid = pid;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
