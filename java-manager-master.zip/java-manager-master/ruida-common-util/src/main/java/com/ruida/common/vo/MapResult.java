package com.ruida.common.vo;

import java.util.HashMap;
import java.util.Map;

/**
 * @description:
 * @author szl
 * @Date 2018年12月10日
 * @verion 1.0
 */
public class MapResult<K, V> extends ExtBaseResult {

	private static final long serialVersionUID = 319981086482245382L;

	private Map<K, V> content;

	public MapResult<K, V> add(K key, V val) {
		if (content == null) {
			setContent(new HashMap<K, V>(16));
		}
		getContent().put(key, val);
		return this;
	}

	public Map<K, V> getContent() {
		return content;
	}

	public void setContent(Map<K, V> content) {
		this.content = content;
	}

}
