package com.ruida.cloud.model;

import lombok.Data;

import java.util.List;

/**
 * @author wy
 * @description: 添加助教请求类
 */

@Data
public class DoubleListenClassRoomRequest {

    private Integer course_id;//双师课程id
    private List<DoubleStudentClassRequest> doubleStudentClassList;//听课教室集合
}