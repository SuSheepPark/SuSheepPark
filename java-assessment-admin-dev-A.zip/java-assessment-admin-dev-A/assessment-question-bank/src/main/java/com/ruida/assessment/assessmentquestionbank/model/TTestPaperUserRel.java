package com.ruida.assessment.assessmentquestionbank.model;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @author wy
 * @description 试卷-用户关联实体类
 * @date 2020/6/29
 */
@Data
@TableName("t_test_paper_user_rel")
public class TTestPaperUserRel extends BaseColumn implements Serializable {

    private static final long serialVersionUID = -2100623420441531072L;

    /**
     * 自增主键
     */
    @TableId
    private Integer relId;
    /**
     * 用户id
     */
    private Integer userId;

    /**
     * 考生id
     */
    private Integer stuId;

    /**
     * 试卷id
     */
    private Integer testPaperId;

    /**
     * 商品id
     */
    private Integer productId;

    /**
     * 是否购买了报告
     */
    private Integer buyReport;

    /**
     * 完成次数
     */
    private Integer completeNum;

    /**
     * 最近练习的完成状态 0-交卷 1-未交卷
     */
    private Integer completeStatus;
    /**
     * 完成比例
     */
    private BigDecimal rate;





}
