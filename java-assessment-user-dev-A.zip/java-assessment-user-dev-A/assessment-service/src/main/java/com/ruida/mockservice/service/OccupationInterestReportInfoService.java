package com.ruida.mockservice.service;

import com.alibaba.fastjson.JSONArray;
import com.baomidou.mybatisplus.service.IService;
import com.ruida.mockdao.model.OccupationInterestExamRecord;
import com.ruida.mockdao.model.OccupationInterestReportInfo;

/**
 * <p>
 * 职业兴趣测试报告文案表 服务类
 * </p>
 *
 * @author 
 * @since 2021-05-26
 */
public interface OccupationInterestReportInfoService extends IService<OccupationInterestReportInfo> {

	JSONArray getSimpleReport(OccupationInterestExamRecord record);
}
