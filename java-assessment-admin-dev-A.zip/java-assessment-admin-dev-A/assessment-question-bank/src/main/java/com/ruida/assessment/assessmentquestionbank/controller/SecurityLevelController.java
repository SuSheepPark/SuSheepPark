package com.ruida.assessment.assessmentquestionbank.controller;

import com.ruida.assessment.assessmentcommon.result.ListResult;
import com.ruida.assessment.assessmentquestionbank.service.SecurityLevelService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * @description: 保密等级控制层
 * @author: kgz
 * @date: 2020/6/10
 */
@RequestMapping("/securityLevel")
@RestController
@Api(value ="保密等级相关接口")
public class SecurityLevelController {
    @Resource
    private SecurityLevelService securityLevelService;

    @GetMapping("/getList")
    @ApiOperation(value = "获取保密等级下拉框列表", notes = "获取保密等级下拉框列表")
    public ListResult getList(){
        ListResult listResult = new ListResult();
        listResult.setContent(securityLevelService.getList());
        return listResult;
    }
}
