package com.ruida.mockdao.vo;

import lombok.Data;

/**
 * @description: 拍照上传实体类VO
 * @author: chenjy
 * @create: 2020-07-14 15:54
 */
@Data
public class AnswerImgVO {

    private Integer imageId;

    private String imagePath;

}
