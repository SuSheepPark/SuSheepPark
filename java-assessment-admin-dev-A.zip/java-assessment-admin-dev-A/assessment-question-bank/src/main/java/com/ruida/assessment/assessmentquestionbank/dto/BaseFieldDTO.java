package com.ruida.assessment.assessmentquestionbank.dto;

import com.ruida.assessment.assessmentcommon.result.Page;
import lombok.Data;

import java.util.List;

@Data
public class BaseFieldDTO {

    /* 查询类型 */
    private String queryType;

    /* 编辑时用的id */
    private Integer id;

    /* 新增、编辑时用的name */
    private String name;

    /* 状态 */
    private Integer status;

    /* 是否仅试题使用 */
    private Integer isTestQuestions;

    /* 学段 */
    private String periodId;

    /* 科目 */
    private String subjectId;

    /* 学段 + “,” + 科目 */
    private String periodIdAndSubjectId;


    /* 分页 */
    private Page page;
    private Integer start;
    private Integer size;

}
