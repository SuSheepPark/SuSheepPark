package com.ruida.common.enums;

import java.util.LinkedHashMap;
import java.util.Map;

public enum MenuType {

    menu("1","菜单"),button("2","按钮");

    public static final String SOURCE_KEY = "MenuType";

    private String k;
    private String v;

    MenuType(String k, String v) {
        this.k = k;
        this.v = v;
    }

    public static Map<String,String> map = new LinkedHashMap<>(2);
    static
    {
        for(MenuType type : MenuType.values())
        {
            map.put(type.getK(),type.getV());
        }
    }

    public String getK() {
        return k;
    }

    public void setK(String k) {
        this.k = k;
    }

    public String getV() {
        return v;
    }

    public void setV(String v) {
        this.v = v;
    }
}
