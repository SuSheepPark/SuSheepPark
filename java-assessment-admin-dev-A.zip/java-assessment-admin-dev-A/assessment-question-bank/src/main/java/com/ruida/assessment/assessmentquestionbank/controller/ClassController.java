package com.ruida.assessment.assessmentquestionbank.controller;

import com.ruida.assessment.assessmentcommon.result.BaseResult;
import com.ruida.assessment.assessmentcommon.result.PojoResult;
import com.ruida.assessment.assessmentquestionbank.annotaion.UserAuth;
import com.ruida.assessment.assessmentquestionbank.dto.ClassRequest;
import com.ruida.assessment.assessmentquestionbank.service.IClassService;
import com.ruida.assessment.assessmentquestionbank.vo.PeriodInfoVO;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * @author wy
 * @description 班级管理业务类
 * @date 2020/7/24
 */
@RequestMapping("/class")
@RestController
public class ClassController {

    @Resource
    private IClassService classService;


    /*
     * 功能描述   查询学校下班级列表信息
     * @param
     * @return
     */
    @GetMapping("query/classList")
    public PojoResult queryClassList(@RequestParam Integer schoolId){
        List<PeriodInfoVO> periodInfoVOS = classService.queryClassList(schoolId);
        PojoResult result = new PojoResult<>();
        result.setContent(periodInfoVOS);
        return result;
    }

    /*
     *功能描述    新增、编辑班级
     * @param
     * @return
     */
    @UserAuth
    @PostMapping("save/saveClass")
    public BaseResult saveClass(@RequestBody ClassRequest request){
        BaseResult result = classService.saveClass(request);
        return result;
    }


    /*
     *功能描述    删除班级
     * @param
     * @return
     */
    @UserAuth
    @DeleteMapping("delete/{classId}")
    public BaseResult deleteClass(@PathVariable Integer classId){
        BaseResult result = classService.deleteClass(classId);
        return result;
    }

    /**
     * 班级考生升级
     *
     * @param schoolIds
     * @return
     */
    @PostMapping("/upRankBySchool")
    @UserAuth
    public PojoResult upRankBySchool(String schoolIds) {
        PojoResult result = classService.upRankBySchool(schoolIds);
        return result;
    }


}
