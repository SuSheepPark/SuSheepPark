package com.ruida.common.enums;


/**
 * @author wy
 * @description 双师操作步骤 日志使用
 * @date 2021/6/8
 */
public enum DoubleOperateStepEnum {

    LOCAL_PROCESS(1,"本地处理"),
    DATA_SYNC(2,"数据同步"),
    ;

    private Integer id;
    private String name;

    DoubleOperateStepEnum(Integer id, String name) {
        this.id = id;
        this.name = name;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
