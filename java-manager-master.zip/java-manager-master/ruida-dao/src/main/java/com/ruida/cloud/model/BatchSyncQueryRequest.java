package com.ruida.cloud.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ruida.common.SystemConstant;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @author wy
 * @description: 请求类
 */

@Data
public class BatchSyncQueryRequest {

    private String className;

    private String campusName;//校区名称

    @DateTimeFormat(pattern="yyyy-MM-dd")
    @JsonFormat(pattern= "yyyy-MM-dd",timezone=SystemConstant.TIME_ZONE)
    private Date startDate;

    @DateTimeFormat(pattern="yyyy-MM-dd")
    @JsonFormat(pattern= "yyyy-MM-dd",timezone=SystemConstant.TIME_ZONE)
    private Date endDate;

    @DateTimeFormat(pattern="yyyy-MM-dd")
    @JsonFormat(pattern= "yyyy-MM-dd",timezone=SystemConstant.TIME_ZONE)
    private Date finishedStartDate;

    @DateTimeFormat(pattern="yyyy-MM-dd")
    @JsonFormat(pattern= "yyyy-MM-dd",timezone=SystemConstant.TIME_ZONE)
    private Date finishedEndDate;

    private Integer assistantTeacherId;//助教id   （未添加 -1 已添加 -2）

    private Integer source;//班级来源 0：校管家；1：本地创建

    private List<String> classNameList = new ArrayList<>();
}