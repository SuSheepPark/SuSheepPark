package com.ruida.mockservice.service;

import com.baomidou.mybatisplus.service.IService;
import com.ruida.mockdao.model.ImageBanner;

/**
 * <p>
 * banner图 服务类
 * </p>
 *
 * @author xumingqi
 * @since 2021-01-07
 */
public interface ImageBannerService extends IService<ImageBanner> {
    String getImageBannerUrl(Integer type, Integer source);
}
