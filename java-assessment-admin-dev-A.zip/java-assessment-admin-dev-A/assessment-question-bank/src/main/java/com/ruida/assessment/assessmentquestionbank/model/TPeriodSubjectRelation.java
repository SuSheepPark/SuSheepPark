package com.ruida.assessment.assessmentquestionbank.model;

import lombok.Data;

import java.io.Serializable;

/**
 * 学段科目关联表实体
 */
@Data
public class TPeriodSubjectRelation extends BaseColumn implements Serializable {



    /* id */
    private Integer id;

    /* 学段id */
    private Integer periodId;

    /* 科目id */
    private Integer subjectId;

    /* 创建人id */
    private Integer creatorId;

    /* 更新人id */
    private Integer updaterId;

}