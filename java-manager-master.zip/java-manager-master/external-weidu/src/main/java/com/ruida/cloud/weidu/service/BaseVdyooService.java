package com.ruida.cloud.weidu.service;

import com.ruida.cloud.weidu.dao.VdyooFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service
@Slf4j
public class BaseVdyooService {
    @Resource
    public VdyooFactory vdyooFactory;

}
