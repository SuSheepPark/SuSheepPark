package com.ruida.mockservice.mq.report;


import com.aliyun.openservices.ons.api.Message;
import com.ruida.mockcommon.mq.consumer.MQConsumeService;
import com.ruida.mockcommon.mq.consumer.MQConsumer;
import com.ruida.mockservice.service.ExamService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;


/**
 * Created by jinhu on 2020/8/3.
 * consumer 消费者ID
 * topic
 * tags 同一groupid下tag保持一致,弱化tag的作用,不用tag进行业务区分
 * 实现消息消费
 */
@Slf4j
@Service
//@MQConsumer(consumer = "GID-exam-report-stat-", topic = "start-exam-attention", tags = "exam-report-stat")
public class ReportStatConsumeService implements MQConsumeService {
    @Resource
    ExamService examService;
    @Value("${spring.profiles.active}")
    private String profiles;

    /**
     * 交卷后处理报告统计数据
     * 消费异常重新消费
     * 其他状态return
     * @param message
     * @return
     */
    @Override
    public boolean consume(Message message) {
        try{
            //业务处理
            String str = "recordId"+"_"+profiles+"_";
            String recordId = message.getKey().substring(str.length());
            log.info("普通订阅接收到的消息的topic是: ->" + message.getTopic() + "消息内容：->" + new String(message.getBody())+" 考试记录id：->"+recordId);

            boolean success = examService.handleQuestionStats(Integer.valueOf(recordId));
            if(!success){
                log.error("考试记录：{}计算知识点分值失败",recordId);
            }
            return true;
        }catch(Exception e){
            log.error("消费消息异常 key:{} message:{} ex:{}", new Object[]{message.getKey(),new String(message.getBody()),e});
            return false;
        }
    }
}
