package com.ruida.cloud.dao;

import com.ruida.cloud.model.SysUser;
import com.ruida.cloud.model.SysUserExample;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

public interface SysUserMapper {
    int countByExample(SysUserExample example);

    int deleteByExample(SysUserExample example);

    int deleteByPrimaryKey(Integer userId);

    int insert(SysUser record);

    int insertSelective(SysUser record);

    List<SysUser> selectByExample(SysUserExample example);

    SysUser selectByPrimaryKey(Integer userId);

    int updateByExampleSelective(@Param("record") SysUser record, @Param("example") SysUserExample example);

    int updateByExample(@Param("record") SysUser record, @Param("example") SysUserExample example);

    int updateByPrimaryKeySelective(SysUser record);

    int updateByPrimaryKey(SysUser record);

    @Select("SELECT\n" +
            "\ta.*, role.role_name AS roleName,\n" +
            "\tCASE\n" +
            "WHEN FIND_IN_SET(2, role.role_type)\n" +
            "AND c.teacher_type = 0 THEN\n" +
            "\t'主讲老师'\n" +
            "WHEN FIND_IN_SET(2, role.role_type)\n" +
            "AND c.teacher_type = 0\n" +
            "AND c.assistant_teacher_type = 0 THEN\n" +
            "\t'校区助教'\n" +
            "WHEN FIND_IN_SET(2, role.role_type)\n" +
            "AND c.teacher_type = 0\n" +
            "AND c.assistant_teacher_type = 1 THEN\n" +
            "\t'总部助教'\n" +
            "ELSE\n" +
            "\trole.role_type\n" +
            "END AS roleType\n" +
            "FROM\n" +
            "\t(\n" +
            "\t\tSELECT\n" +
            "\t\t\ta.user_id,\n" +
            "\t\t\tGROUP_CONCAT(b.role_type) AS role_type,\n" +
            "\t\t\tGROUP_CONCAT(b.role_name) AS role_name\n" +
            "\t\tFROM\n" +
            "\t\t\tsys_user_role a\n" +
            "\t\tLEFT JOIN sys_role b ON a.role_id = b.role_id\n" +
            "\t\tWHERE\n" +
            "\t\t\tb.isdelete = 0\n" +
            "\t\tAND b.role_type != 3\n" +
            "\t\tAND b.role_type != 4\n" +
            "\t\tGROUP BY\n" +
            "\t\t\ta.user_id\n" +
            "\t) role\n" +
            "LEFT JOIN sys_user a ON a.user_id = b.role.user_id\n" +
            "LEFT JOIN t_teacher c ON a.user_id = c.user_id\n" +
            "WHERE\n" +
            "\ta.isdelete = 0\n" +
            "AND (\n" +
            "\ta.user_name = #{username} \n" +
            "\tOR a.telephone = #{username} \n" +
            ")")
    Map<String,Object> getUserInfo(@Param("username") String username);

    @Select("SELECT real_name FROM sys_user where user_id=#{userId} and isdelete=0")
    String getUserNameById(@Param("userId")Integer bindAccount);

    @Select("SELECT\n" +
            "  c.user_id as userId,\n" +
            "  c.real_name as realName,\n" +
            "  c.telephone\n" +
            "FROM\n" +
            "  sys_role a\n" +
            "LEFT JOIN sys_user_role b ON a.role_id = b.role_id\n" +
            "LEFT JOIN sys_user c ON b.user_id = c.user_id\n" +
            "AND c.isdelete = 0\n" +
            "LEFT JOIN t_distributor d ON c.user_id = d.bind_account\n" +
            "WHERE\n" +
            "  a.role_name = #{roleName}\n" +
            "AND d.bind_account IS NULL")
    List<Map<String, Object>> getUserInfoByRoleName(@Param("roleName")String roleName);

    @Select("SELECT\n" +
            "  c.user_id as userId,\n" +
            "  c.real_name as realName,\n" +
            "  c.telephone\n" +
            "FROM\n" +
            "  sys_user c\n" +
            "LEFT JOIN t_distributor d ON c.user_id = d.bind_account\n" +
            "WHERE\n" +
            "  c.isdelete=0 And d.distributor_id=#{id}")
    Map<String, Object> getUserInfoById(@Param("id") Integer id);

    Integer getUserInfoByUserId(@Param("userId") Integer userId);
}
