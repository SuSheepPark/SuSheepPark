package com.ruida.cloud.dao;

import com.ruida.cloud.model.CourseNonPublicClass;

import java.util.List;

/**
 * @author taosh
 * @create 2019-02-21 14:38
 */
public interface CourseNonPublicClassMapper {
    List<CourseNonPublicClass> listNonPublicClass(Integer courseId);
}
