package com.ruida.assessment.assessmentquestionbank.dto;

import lombok.Data;

/**
 * @author wy
 * @description 网站信息请求类
 * @date 2020/8/14
 */
@Data
public class BottomInfoRequest {

    private Integer id;

    /*
    网站title
     */
    private String websiteTitle;

    private String appname;

    private String slogan;

    /*
    运营机构
     */
    private String operatingAgency;

    private String websiteAuthor;

    private String websiteKeyword;

    private String websiteDescription;

    private String email;

    private String telephone;

    private String workTime;

    /*
    版权以及备案号（网站底部）
     */
    private String version;
}
