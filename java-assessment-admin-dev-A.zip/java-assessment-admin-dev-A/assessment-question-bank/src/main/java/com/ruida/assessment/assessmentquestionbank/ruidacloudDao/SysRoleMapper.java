package com.ruida.assessment.assessmentquestionbank.ruidacloudDao;

import com.ruida.assessment.assessmentquestionbank.model.SysRole;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import org.apache.ibatis.annotations.*;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * 角色表 Mapper 接口
 * </p>
 *
 * @author szl
 * @since 2020-07-14
 */
public interface SysRoleMapper extends BaseMapper<SysRole> {
    /**
     * 获取角色信息
     *
     * @param userId
     * @return
     */
    List<SysRole> getUserRoleList(Integer userId);

    /**
     * 获取用户列表
     *
     * @param param
     * @return
     */
    List<Map<String, Object>> getUserList(Map<String, Object> param);

    /**
     * @param param
     * @return 获取总数
     */
    Integer getUserCount(Map<String, Object> param);

    /**
     * 获取角色信息
     *
     * @return
     */
    List<Map<String, Object>> getRoleList();

    /**
     * 获取部门信息
     *
     * @return
     */
    List<Map<String, Object>> getDeptList(Map<String,Object> param);

    /**
     * 获取角色列表（条件查询）
     *
     * @param param
     * @return
     */
    List<SysRole> selectRoleList(Map param);

    /**
     * @param telephone
     * @return 获取用户信息根据手机号码
     */
    Map<String, Object> getUserByTelephone(@Param("telephone") String telephone);

    /**
     * @param userId
     * @return 获取用户信息根据user_id
     */
    Map<String, Object> getUserByUserId(@Param("userId") Integer userId);

    //根据用户id删除该用户的所有角色和部门
    @Delete("delete from sys_user_role  where user_id =#{userId} ")
    Integer deleteRoleAndDeptByUserIdAndDeptId(@Param("userId") Integer userId
            , @Param("deptId") Integer deptId);

    @Insert("INSERT INTO sys_user_role (user_id, role_id, department_id,deadline) VALUES (#{userId}, #{roleId}, #{deptId},#{deadline}) ")
    Integer saveRoleAndDept(Map<String, Object> param);

    List<Map<String, Object>> getRoleListByDeptId(@Param("deptId") Integer deptId);

    List<Map<String, Object>> getDeptAndRoleListByUserId(@Param("userId") Integer userId);


    List<Map<String, Object>> getDeptListByUserId(@Param("userId") Integer userId);

    List<Map<String, Object>> getRoleListByDeptIdAndUserId(@Param("userId") Integer userId, @Param("deptId") Integer deptId);

    @Update("update sys_user set isdelete = 1  where user_id = #{userId} ")
    Integer deleteUser(@Param("userId") Integer userId);

    @Delete("delete from sys_user_role  where user_id = #{userId}")
    Integer deleteUserRole(@Param("userId") Integer userId);

    @Update("update sys_user set status =#{status} where  user_id =#{userId} ")
    Integer updateStatus(@Param("userId") Integer userId, @Param("status") Integer status);

    @Select("select role_type from sys_role where role_id =#{roleId}")
    Integer getRoleTypeByRoleId(@Param("roleId") Integer roleId);

    @Select("select department_id from sys_role where role_id =#{roleId}")
    Integer getDeptIdByRoleId(@Param("roleId") String roleId);

    @Select("SELECT\n" +
            "a.department_id as departmentId,a.role_id as roleId,a.role_type as roleType\n" +
            "FROM\n" +
            "\tsys_role a\n" +
            "LEFT JOIN sys_user_role b ON a.role_id = b.role_id\n" +
            "WHERE b.user_id = #{userId} AND (a.role_type = 0 OR a.role_type =1)")
    List<SysRole> selectRoleTypeForUser(@Param("userId") Integer userId);//根据角色类型和用户查询
    /**
     * 获取角色列表数量条件查询）
     *
     * @param param
     * @return
     */

    Integer selectRoleCount(Map param);


    @Select("select role_id from sys_user_role where user_id = #{userId} ")
    List<String> selectHasRoleLists(Integer userId);
    @Select("SELECT\n" +
            "\ta.period_id\n" +
            "FROM\n" +
            "\tt_user_period_subject a\n" +
            "WHERE\n" +
            "\ta.user_id = #{userId} AND role_id = #{roleId}\n" +
            "GROUP BY\n" +
            "\ta.period_id")
    List<Integer>getPeriodByUserRole(@Param("userId") Integer userId,@Param("roleId") Integer roleId);

    @Select("SELECT\n" +
        "\ta.subject_id as subjectId ,b.subject_name as subjectName\n" +
        "FROM\n" +
        "\tt_user_period_subject a LEFT JOIN t_subject b ON a.subject_id = b.id\n" +
        "WHERE\n" +
        "\ta.user_id = #{userId} AND a.period_id = #{periodId} AND role_id = #{roleId}\n" +
        "GROUP BY\n" +
        "\ta.subject_id")
    List<Map<String,Object>>getSubjectsByUserRolePeriod(@Param("userId") Integer userId,@Param("periodId") Integer periodId,@Param("roleId") Integer roleId);
    @Select("SELECT\n" +
            "GROUP_CONCAT(b.period_name,c.subject_name) AS subjectNames\n" +
            "FROM\n" +
            "\tt_user_period_subject a\n" +
            "LEFT JOIN t_period b ON a.period_id = b.id\n" +
            "LEFT JOIN t_subject c ON c.id = a.subject_id\n" +
            "WHERE\n" +
            "\ta.user_id = #{userId} AND role_id = #{roleId}\n"
           )
    String getSubjectNamesByUserRole(@Param("userId") Integer userId,@Param("roleId") Integer roleId);

}
