package com.ruida.assessment.assessmentquestionbank.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.assessment.assessmentquestionbank.dto.OrderQueryDTO;
import com.ruida.assessment.assessmentquestionbank.model.TOrder;
import com.ruida.assessment.assessmentquestionbank.vo.*;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * @description: 订单数据库层接口
 * @author: kgz
 * @date: 2020/7/31
 */
@Mapper
public interface OrderMapper extends BaseMapper<TOrder> {
    /**
     * 分页查询订单列表
     * @param orderQueryDTO
     * @return
     */
    List<OrderVO> getOrderList(OrderQueryDTO orderQueryDTO);

    /**
     * 分页查询充值记录列表
     * @param orderQueryDTO
     * @return
     */
    List<StudyCoinRecordVO> getRechargeList(OrderQueryDTO orderQueryDTO);

    /**
     * 查询订单总数
     * @param orderQueryDTO
     * @return
     */
    Integer getOrderCount(OrderQueryDTO orderQueryDTO);

    /**
     * 查询充值记录总数
     * @param orderQueryDTO
     * @return
     */
    Integer getRechargeCount(OrderQueryDTO orderQueryDTO);

    /**
     * 获取订单汇总信息
     * @param orderQueryDTO
     * @return
     */
    OrderVO getOrderSum(OrderQueryDTO orderQueryDTO);

    /**
     * 获取订单详情商品信息
     * @param orderId
     * @return
     */
    List<OrderItemProductVO> getOrderItemProductList(@Param("orderId") Integer orderId);

    /*
    查询用户购买记录列表
     */
    List<OrderListVO> queryOrderListByUserId(@Param("userId") Integer userId);

    /**
     * 获取实付金额
     * @param startTime
     * @param endTime
     * @return
     */
    Double getPayAmount(@Param("startTime") String startTime, @Param("endTime") String endTime, @Param("productType") Integer productType);

    /**
     * 获取支付金额
     * @param startTime
     * @param endTime
     * @return
     */
    List<DataTrendVO> getPayAmountTrendData(@Param("startTime") String startTime, @Param("endTime") String endTime);

    /**
     * 查询订单数
     * @param startTime
     * @param endTime
     * @return
     */
    Integer getOrderCountByDate(@Param("startTime") String startTime, @Param("endTime") String endTime);

    /*
    查询商品存在的待支付的订单
     */
    List<TOrder> queryUnpaidOrderByProductId(@Param("productId") Integer productId);

    /*
    查询学员购买的或待支付的商品Id集合
     */
//    List<Integer> queryStudentHaveProductIds(@Param("userId") Integer userId);

    /*
    查询该学员是否存在 已支付/待支付的该商品订单
     */
    Map<String, Object> getOrderInfo(@Param("productId") Integer productId, @Param("userId") Integer userId);


    /*
    查询某用户已经拥有的（已支付/待支付,已赠送）所有商品
     */
    List<Integer> queryUserOwnProductListByUserId(@Param("userId") Integer userId);

    /*
    查询某商品已经被拥有(已支付/待支付,已赠送)的所有用户
     */
    List<Integer> queryProductOwnedUserListByProductId(Integer productId);
}
