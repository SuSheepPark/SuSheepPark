package com.ruida.cloud.dao;

import com.ruida.cloud.model.WeiduClassTypeRel;
import com.ruida.cloud.model.WeiduClassTypeRelExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface WeiduClassTypeRelMapper {
    long countByExample(WeiduClassTypeRelExample example);

    int deleteByExample(WeiduClassTypeRelExample example);

    int deleteByPrimaryKey(Integer rid);

    int insert(WeiduClassTypeRel record);

    int insertSelective(WeiduClassTypeRel record);

    List<WeiduClassTypeRel> selectByExample(WeiduClassTypeRelExample example);

    WeiduClassTypeRel selectByPrimaryKey(Integer rid);

    int updateByExampleSelective(@Param("record") WeiduClassTypeRel record, @Param("example") WeiduClassTypeRelExample example);

    int updateByExample(@Param("record") WeiduClassTypeRel record, @Param("example") WeiduClassTypeRelExample example);

    int updateByPrimaryKeySelective(WeiduClassTypeRel record);

    int updateByPrimaryKey(WeiduClassTypeRel record);
}