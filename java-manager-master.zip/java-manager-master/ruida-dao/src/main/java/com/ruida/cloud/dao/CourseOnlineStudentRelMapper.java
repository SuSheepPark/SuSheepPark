package com.ruida.cloud.dao;

import com.ruida.cloud.model.CourseOnlineStudentRel;
import com.ruida.cloud.model.CourseOnlineStudentRelExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface CourseOnlineStudentRelMapper {
    long countByExample(CourseOnlineStudentRelExample example);

    int deleteByExample(CourseOnlineStudentRelExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(CourseOnlineStudentRel record);

    int insertSelective(CourseOnlineStudentRel record);

    List<CourseOnlineStudentRel> selectByExample(CourseOnlineStudentRelExample example);

    CourseOnlineStudentRel selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") CourseOnlineStudentRel record, @Param("example") CourseOnlineStudentRelExample example);

    int updateByExample(@Param("record") CourseOnlineStudentRel record, @Param("example") CourseOnlineStudentRelExample example);

    int updateByPrimaryKeySelective(CourseOnlineStudentRel record);

    int updateByPrimaryKey(CourseOnlineStudentRel record);

    /**批量更新**/
    int updateOnlineStudentRelBatch(List<CourseOnlineStudentRel> list);

    /**批量更新  删除**/
    int deleteOnlineStudentRelBatch(List<Integer> list);

    int  insertBatch(List<CourseOnlineStudentRel> list);

    /**按TeachingClassId分组*/
    List<CourseOnlineStudentRel> listCOSRGroupByTeachingIdByCourseId(Integer courseId);

    /**按studentId分组*/
    List<CourseOnlineStudentRel> listCOSRGroupByStudentByCourseId(Integer courseId);

    /**线上直播课程删除线上学生信息*/
    int deleteOnlineStudentRelBUserIdCourseId(Map<String, Object> filter);
}