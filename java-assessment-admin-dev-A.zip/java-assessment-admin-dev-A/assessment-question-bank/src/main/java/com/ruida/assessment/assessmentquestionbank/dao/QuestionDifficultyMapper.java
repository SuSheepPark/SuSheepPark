package com.ruida.assessment.assessmentquestionbank.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.assessment.assessmentcommon.result.Page;
import com.ruida.assessment.assessmentquestionbank.model.TQuestionDifficulty;
import com.ruida.assessment.assessmentquestionbank.vo.BaseFieldVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @description: 难度等级dao层接口
 * @author: kgz
 * @date: 2020/6/9
 */
@Mapper
public interface QuestionDifficultyMapper extends BaseMapper<TQuestionDifficulty> {

    /**
     * 分页查询列表
     * @param page
     * @return
     */
    List<BaseFieldVO> queryList(@Param("page") Page page);

    /**
     * 列表数据条数
     * @return
     */
    Integer countQueryList();
}
