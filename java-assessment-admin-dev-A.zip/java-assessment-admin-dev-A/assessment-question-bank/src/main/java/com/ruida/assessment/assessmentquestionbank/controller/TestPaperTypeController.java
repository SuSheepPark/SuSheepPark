package com.ruida.assessment.assessmentquestionbank.controller;

import com.ruida.assessment.assessmentcommon.result.ListResult;
import com.ruida.assessment.assessmentquestionbank.service.MaterialVersionService;
import com.ruida.assessment.assessmentquestionbank.service.TestPaperTypeService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * @description: 试卷类型控制层
 * @author: kgz
 * @date: 2020/7/6
 */
@RequestMapping("/testPaperType")
@RestController
@Api(value ="教材版本接口")
public class TestPaperTypeController {
    @Resource
    private TestPaperTypeService testPaperTypeService;

    @GetMapping("/getList")
    @ApiOperation(value = "获取试卷类型下拉框列表", notes = "获取试卷类型下拉框列表")
    public ListResult getList(){
        ListResult listResult = new ListResult();
        listResult.setContent(testPaperTypeService.getList());
        return listResult;
    }
}
