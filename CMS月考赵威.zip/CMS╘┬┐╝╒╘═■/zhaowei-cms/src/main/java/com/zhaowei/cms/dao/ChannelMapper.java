package com.zhaowei.cms.dao;

import java.util.List;

import com.zhaowei.cms.domain.Channel;
/**
 * @ClassName: ChannelMapper 
 * @Description: 栏目
 * @author: zw
 * @date: 2019年9月17日 下午8:26:17
 */
public interface ChannelMapper {
	
	/**
	 * @Title: selects 
	 * @Description:查询所有的栏目
	 * @return
	 * @return: List<Channel>
	 */
	List<Channel> selects();
	
    int deleteByPrimaryKey(Integer id);

    int insert(Channel record);

    int insertSelective(Channel record);

    Channel selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(Channel record);

    int updateByPrimaryKey(Channel record);
}