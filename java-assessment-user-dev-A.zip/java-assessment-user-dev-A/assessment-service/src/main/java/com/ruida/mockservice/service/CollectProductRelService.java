package com.ruida.mockservice.service;


import com.baomidou.mybatisplus.service.IService;
import com.ruida.mockcommon.result.PageData;
import com.ruida.mockdao.dto.ProductQueryRequest;
import com.ruida.mockdao.model.CollectProductRel;
import com.ruida.mockdao.vo.ProductCollectVO;
import com.ruida.mockdao.vo.ProductNewVO;
import com.ruida.mockdao.vo.ProductVO;

import java.util.List;

/**
 * <p>
 * 用户收藏商品关联表 服务类
 * </p>
 *
 * @author jinhu
 * @since 2020-07-08
 */
public interface CollectProductRelService extends IService<CollectProductRel> {


    ProductCollectVO collectProduct(Integer productId);

    PageData<ProductVO> queryProductCollectList(ProductQueryRequest request);
    PageData<ProductNewVO> queryProductCollectListNew(ProductQueryRequest request);


    boolean removeCollectBatch(List<String> productIds);

}
