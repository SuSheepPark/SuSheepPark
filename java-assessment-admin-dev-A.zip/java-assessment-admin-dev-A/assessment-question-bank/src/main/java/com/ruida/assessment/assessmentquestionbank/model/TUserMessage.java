package com.ruida.assessment.assessmentquestionbank.model;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;

import java.io.Serializable;

/**
 * @description: 用户消息数据库实体
 * @author: kgz
 * @date: 2020/7/24
 */
@TableName("t_user_message")
public class TUserMessage extends BaseColumn implements Serializable {
    private static final long serialVersionUID = -6624304762561471520L;
    /**
     * 用户消息id
     */
    @TableId
    private Integer userMessageId;

    /**
     * 用户id
     */
    private Integer userId;

    /**
     * 消息模板编号
     */
    private Integer messageTplNo;

    /**
     * 用户消息内容
     */
    private String messageParams;

    /**
     * 是否已读（0—未读；1—已读）
     */
    private Integer isread;

    public Integer getUserMessageId() {
        return userMessageId;
    }

    public void setUserMessageId(Integer userMessageId) {
        this.userMessageId = userMessageId;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getMessageParams() {
        return messageParams;
    }

    public void setMessageParams(String messageParams) {
        this.messageParams = messageParams;
    }

    public Integer getIsread() {
        return isread;
    }

    public void setIsread(Integer isread) {
        this.isread = isread;
    }

    public Integer getMessageTplNo() {
        return messageTplNo;
    }

    public void setMessageTplNo(Integer messageTplNo) {
        this.messageTplNo = messageTplNo;
    }

    @Override
    public String toString() {
        return "TUserMessage{" +
                "userMessageId=" + userMessageId +
                ", userId=" + userId +
                ", messageTplNo=" + messageTplNo +
                ", messageParams='" + messageParams + '\'' +
                ", isread=" + isread +
                '}';
    }
}
