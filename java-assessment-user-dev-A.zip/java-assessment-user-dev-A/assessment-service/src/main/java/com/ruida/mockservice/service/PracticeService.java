package com.ruida.mockservice.service;

import com.ruida.mockdao.dto.ErrorPracticeReq;

public interface PracticeService {

    /**
     * 生成错题练习
     * @param req
     * @return
     */
    Integer createPractice(ErrorPracticeReq req);
}
