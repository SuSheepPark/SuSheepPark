package com.ruida.assessment.assessmentquestionbank.dto;

import com.baomidou.mybatisplus.toolkit.CollectionUtils;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.apache.commons.lang.StringUtils;

import java.util.List;

/**
 * @description: 小节与试题关联关系
 * @author: kgz
 * @date: 2020/6/30
 */
@ApiModel(description = "小节试题关联关系")
public class TestNodeQuestionRelDTO implements Comparable<TestNodeQuestionRelDTO>{

    @ApiModelProperty(value = "小节与试题关联关系id", name = "relId")
    private Integer relId;

    @ApiModelProperty(value = "小节id", name = "nodeId")
    private Integer nodeId;

    @ApiModelProperty(value = "试卷id", name = "testPaperId")
    private Integer testPaperId;

    @ApiModelProperty(value = "试题id", name = "questionId")
    private String questionId;

    @ApiModelProperty(value = "题型", name = "questionTypeId")
    private Integer questionTypeId;

    @ApiModelProperty(value = "批改类型（0—主观题；1—客观题）", name = "correctType")
    private Integer correctType;

    @ApiModelProperty(value = "父级试题id", name = "parentId")
    private String parentId;

    @ApiModelProperty(value = "分值", name = "score")
    private Double score;

    @ApiModelProperty(value = "漏选得分", name = "regressionScore")
    private Double regressionScore;

    @ApiModelProperty(value = "排序", name = "sort")
    private Integer sort;

    @ApiModelProperty(value = "题号", name = "num")
    private String num;

    @ApiModelProperty(value = "赋分类型，填空题使用，0-每空给分，1-单空给分", name = "scoreType")
    private Integer scoreType;

    @ApiModelProperty(value = "每空分值，填空题使用", name = "scoreEachBlank")
    private String scoreEachBlank;

    @ApiModelProperty(value = "子级试题", name = "children")
    private List<TestNodeQuestionRelDTO> children;
    /**
     * 试题引用状态（0 非补位； 1 补位）
     */
    private Integer isfill;
    /**
     * 补位的范围
     */
    private Integer fillRange;

    /**
     * 根据此字段判断题号和排序
     */
    private Integer curLength;

    /**
     * 错误率
     */
    private Double ratio;


    public Integer getCurLength() {
        return curLength;
    }

    public void setCurLength(Integer curLength) {
        this.curLength = curLength;
    }

    public Double getRegressionScore() {
        return regressionScore;
    }

    public void setRegressionScore(Double regressionScore) {
        this.regressionScore = regressionScore;
    }

    public Integer getRelId() {
        return relId;
    }

    public void setRelId(Integer relId) {
        this.relId = relId;
    }

    public Integer getNodeId() {
        return nodeId;
    }

    public void setNodeId(Integer nodeId) {
        this.nodeId = nodeId;
    }

    public String getQuestionId() {
        return questionId;
    }

    public void setQuestionId(String questionId) {
        this.questionId = questionId;
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public Double getScore() {
        return score;
    }

    public void setScore(Double score) {
        this.score = score;
    }

    public Integer getSort() {
        return sort;
    }

    public void setSort(Integer sort) {
        this.sort = sort;
    }

    public List<TestNodeQuestionRelDTO> getChildren() {
        return children;
    }

    public void setChildren(List<TestNodeQuestionRelDTO> children) {
        this.children = children;
    }

    public Integer getQuestionTypeId() {
        return questionTypeId;
    }

    public void setQuestionTypeId(Integer questionTypeId) {
        this.questionTypeId = questionTypeId;
    }

    public Integer getTestPaperId() {
        return testPaperId;
    }

    public void setTestPaperId(Integer testPaperId) {
        this.testPaperId = testPaperId;
    }

    public String getNum() {
        return num;
    }

    public void setNum(String num) {
        this.num = num;
    }

    public Integer getIsfill() {
        return isfill;
    }

    public void setIsfill(Integer isfill) {
        this.isfill = isfill;
    }

    public Integer getFillRange() {
        return fillRange;
    }

    public void setFillRange(Integer fillRange) {
        this.fillRange = fillRange;
    }

    public Integer getScoreType() {
        return scoreType;
    }

    public void setScoreType(Integer scoreType) {
        this.scoreType = scoreType;
    }

    public String getScoreEachBlank() {
        return scoreEachBlank;
    }

    public void setScoreEachBlank(List<Double> scoreEachBlank) {
        if(CollectionUtils.isNotEmpty(scoreEachBlank)){
            this.scoreEachBlank = StringUtils.join(scoreEachBlank, ",");
        }
    }

    public Double getRatio() {
        return ratio;
    }

    public void setRatio(Double ratio) {
        this.ratio = ratio;
    }

    public Integer getCorrectType() {
        return correctType;
    }

    public void setCorrectType(Integer correctType) {
        this.correctType = correctType;
    }

    @Override
    public String toString() {
        return "TestNodeQuestionRelDTO{" +
                "relId=" + relId +
                ", nodeId=" + nodeId +
                ", testPaperId=" + testPaperId +
                ", questionId='" + questionId + '\'' +
                ", questionTypeId=" + questionTypeId +
                ", correctType=" + correctType +
                ", parentId='" + parentId + '\'' +
                ", score=" + score +
                ", regressionScore=" + regressionScore +
                ", sort=" + sort +
                ", num='" + num + '\'' +
                ", scoreType=" + scoreType +
                ", scoreEachBlank='" + scoreEachBlank + '\'' +
                ", children=" + children +
                ", isfill=" + isfill +
                ", fillRange=" + fillRange +
                ", curLength=" + curLength +
                ", ratio=" + ratio +
                '}';
    }

    @Override
    public int compareTo(TestNodeQuestionRelDTO o) {
        return o.getRatio().compareTo(ratio);
    }
}
