package com.ruida.cloud.dao;

import com.ruida.cloud.model.Order;
import com.ruida.cloud.model.OrderExample;
import com.ruida.cloud.model.OrderExt;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface OrderMapper {
    int countByExample(OrderExample example);

    int deleteByExample(OrderExample example);

    int deleteByPrimaryKey(Integer orderId);

    int insert(Order record);

    int insertSelective(Order record);

    List<Order> selectByExample(OrderExample example);

    Order selectByPrimaryKey(Integer orderId);

    int updateByExampleSelective(@Param("record") Order record, @Param("example") OrderExample example);

    int updateByExample(@Param("record") Order record, @Param("example") OrderExample example);

    int updateByPrimaryKeySelective(Order record);

    int updateByPrimaryKey(Order record);

    void batchUpdateOrderStatus(@Param("ids") List<Integer> orderIds, @Param("vo") OrderExt orderExt);
}