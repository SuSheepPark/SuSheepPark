package com.ruida.assessment.assessmentquestionbank.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.assessment.assessmentquestionbank.model.TAssessmentPeriodSubjectRel;
import com.ruida.assessment.assessmentquestionbank.model.TTestTypePeriodRel;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author wy
 * @description 考试类型-学段关联Mapper
 * @date 2020/9/14
 */
@Mapper
public interface TestTypePeriodRelMapper extends BaseMapper<TTestTypePeriodRel> {


}
