package com.ruida.mockdao.model;

import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 实施对象表
 * </p>
 *
 * @author szl
 * @since 2021-07-22
 */
@TableName("t_candidates")
public class TCandidates extends Model<TCandidates> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.UUID)
    private String id;
    /**
     * 用户id
     */
    @TableField("user_id")
    private Integer userId;

    @TableField("student_id")
    private Integer studentId;
    /**
     * 准考证号
     */
    @TableField("candidate_number")
    private String candidateNumber;
    /**
     * 姓名
     */
    @TableField("candidate_name")
    private String candidateName;

    /**
     * 已考次数
     */
    @TableField("finish_test_count")
    private Integer finishTestCount;
    /**
     * 班级id
     */
    @TableField("class_id")
    private Integer classId;
    /**
     * 学校id
     */
    @TableField("school_id")
    private Integer schoolId;

    /**
     * 实施计划id
     */
    @TableField("plan_id")
    private String planId;
    /**
     * 场次id
     */
    @TableField("scene_id")
    private String sceneId;
    /**
     * 创建时间
     */
    @TableField("create_time")
    private Date createTime;
    /**
     * 创建人id
     */
    @TableField("create_by")
    private Integer createBy;
    /**
     * 更新时间
     */
    @TableField("update_time")
    private Date updateTime;
    /**
     * 更新人id
     */
    @TableField("update_by")
    private Integer updateBy;
    /**
     * 逻辑删除（0 存在， 1 已删除）
     */
    private Integer isdelete;


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Integer getStudentId() {
        return studentId;
    }

    public void setStudentId(Integer studentId) {
        this.studentId = studentId;
    }

    public String getCandidateNumber() {
        return candidateNumber;
    }

    public void setCandidateNumber(String candidateNumber) {
        this.candidateNumber = candidateNumber;
    }

    public String getSceneId() {
        return sceneId;
    }

    public void setSceneId(String sceneId) {
        this.sceneId = sceneId;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getCreateBy() {
        return createBy;
    }

    public void setCreateBy(Integer createBy) {
        this.createBy = createBy;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(Integer updateBy) {
        this.updateBy = updateBy;
    }

    public Integer getIsdelete() {
        return isdelete;
    }

    public void setIsdelete(Integer isdelete) {
        this.isdelete = isdelete;
    }

    public String getCandidateName() {
        return candidateName;
    }

    public void setCandidateName(String candidateName) {
        this.candidateName = candidateName;
    }

    public Integer getFinishTestCount() {
        return finishTestCount;
    }

    public void setFinishTestCount(Integer finishTestCount) {
        this.finishTestCount = finishTestCount;
    }

    public Integer getClassId() {
        return classId;
    }

    public void setClassId(Integer classId) {
        this.classId = classId;
    }

    public Integer getSchoolId() {
        return schoolId;
    }

    public void setSchoolId(Integer schoolId) {
        this.schoolId = schoolId;
    }

    public String getPlanId() {
        return planId;
    }

    public void setPlanId(String planId) {
        this.planId = planId;
    }

    @Override
    protected Serializable pkVal() {
        return this.id;
    }

    @Override
    public String toString() {
        return "TCandidates{" +
                "id='" + id + '\'' +
                ", userId=" + userId +
                ", studentId=" + studentId +
                ", candidateNumber='" + candidateNumber + '\'' +
                ", candidateName='" + candidateName + '\'' +
                ", finishTestCount=" + finishTestCount +
                ", classId=" + classId +
                ", schoolId=" + schoolId +
                ", planId='" + planId + '\'' +
                ", sceneId='" + sceneId + '\'' +
                ", createTime=" + createTime +
                ", createBy=" + createBy +
                ", updateTime=" + updateTime +
                ", updateBy=" + updateBy +
                ", isdelete=" + isdelete +
                '}';
    }
}
