package com.ruida.mockdao.model;

import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 短信验证码表
 * </p>
 *
 * @author Bhj
 * @since 2020-07-09
 */
@TableName("t_sms_code")
public class SmsCode extends Model<SmsCode> {

    private static final long serialVersionUID = 1L;

    /**
     * 短信验证码id
     */
    @TableId(value = "sms_code_id", type = IdType.AUTO)
    private Integer smsCodeId;
    /**
     * 接收验证码的手机号
     */
    private String telephone;
    /**
     * 短信验证码
     */
    @TableField("sms_code")
    private String smsCode;
    /**
     * 生成时间
     */
    @TableField("create_time")
    private Date createTime;
    /**
     * 短信模板。0—用户注册；1—修改密码；2—用户登录（暂时不用）
     */
    @TableField("sms_templet")
    private Integer smsTemplet;


    public Integer getSmsCodeId() {
        return smsCodeId;
    }

    public void setSmsCodeId(Integer smsCodeId) {
        this.smsCodeId = smsCodeId;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public String getSmsCode() {
        return smsCode;
    }

    public void setSmsCode(String smsCode) {
        this.smsCode = smsCode;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getSmsTemplet() {
        return smsTemplet;
    }

    public void setSmsTemplet(Integer smsTemplet) {
        this.smsTemplet = smsTemplet;
    }

    @Override
    protected Serializable pkVal() {
        return this.smsCodeId;
    }

    @Override
    public String toString() {
        return "TSmsCode{" +
        ", smsCodeId=" + smsCodeId +
        ", telephone=" + telephone +
        ", smsCode=" + smsCode +
        ", createTime=" + createTime +
        ", smsTemplet=" + smsTemplet +
        "}";
    }
}
