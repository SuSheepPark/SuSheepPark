package com.ruida.common.util.excel.processor;

import java.text.ParseException;

/**
 * Created by Administrator on 2017/4/18.
 */
public interface TypeProcessor {
    /**
     * @param preValue    String值
     * @return
     */
    Object fromString(String preValue) throws ParseException;


    String toString(Object value) throws ParseException;
}
