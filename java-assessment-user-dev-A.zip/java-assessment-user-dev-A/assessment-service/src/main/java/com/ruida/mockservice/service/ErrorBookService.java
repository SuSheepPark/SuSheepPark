package com.ruida.mockservice.service;

import com.baomidou.mybatisplus.service.IService;
import com.ruida.mockcommon.entity.TreeNode;
import com.ruida.mockcommon.result.Page;
import com.ruida.mockdao.dto.ErrorBookDTO;
import com.ruida.mockdao.dto.PersonCenterDTO;
import com.ruida.mockdao.model.ErrorBook;
import com.ruida.mockdao.vo.QuestionVO;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * 错题表 服务类
 * </p>
 *
 * @author chenjy
 * @since 2020-07-16
 */
public interface ErrorBookService extends IService<ErrorBook> {

    boolean addErrorBook(ErrorBookDTO errorBookDTO);

    boolean removeQuestionFromErrorBook(String questionId,Integer userId);

    /**
     * 错题集
     * @param periodId
     * @return
     */
    Map<String, Object> queryErrorQuestionGroupSubject(Integer periodId);

    /**
     * 错题列表
     * @param page
     * @param req
     * @return
     */
    Page<QuestionVO> queryErrorBookList(Page page, @Param("req") PersonCenterDTO req);

    Map<String, Object> getQuestionStatsInfo(Integer userId);

    boolean deleteErrorQuestion(String questionIds);

    List<TreeNode> makeKnowledgeTree(Integer subjectId);
}
