package com.ruida.mockdao.model;

import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;
import com.fasterxml.jackson.annotation.JsonFormat;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 用户消息表
 * </p>
 *
 * @author Bhj
 * @since 2020-07-10
 */
@TableName("t_user_message")
public class UserMessage extends Model<UserMessage> {

    private static final long serialVersionUID = 1L;

    /**
     * 用户消息ID
     */
    @TableId(value = "user_message_id", type = IdType.AUTO)
    private Integer userMessageId;
    /**
     * 用户ID
     */
    @TableField("user_id")
    private Integer userId;
    /**
     * 消息模板ID,不填代表后台管理发送的系统信息
     */
    @TableField("message_tpl_no")
    private Integer messageTplNo;
    /**
     * 用户消息内容参数（使用json格式存储,系统消息直接填String内容）
     */
    @TableField("message_params")
    private String messageParams;
    /**
     * 是否已读（0—未读；1—已读）
     */
    private Integer isread;
    /**
     * 创建时间
     */
    @TableField("create_time")
    @JsonFormat(pattern= "yyyy-MM-dd HH:mm",timezone="GMT+8")
    private Date createTime;
    /**
     * 是否删除（0：未删除；1：删除）
     */
    private Integer isdelete;

    @TableField(exist = false)
    private String message;

    @TableField(exist = false)
    private String title;

    /**
     * 消息内容id（）
     */
    @TableField(exist = false)
    private String times;


    public String getTimes() {
        return times;
    }

    public void setTimes(String times) {
        this.times = times;
    }

    public Integer getMessageTplNo() {
        return messageTplNo;
    }

    public void setMessageTplNo(Integer messageTplNo) {
        this.messageTplNo = messageTplNo;
    }


    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Integer getUserMessageId() {
        return userMessageId;
    }

    public void setUserMessageId(Integer userMessageId) {
        this.userMessageId = userMessageId;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getMessageParams() {
        return messageParams;
    }

    public void setMessageParams(String messageParams) {
        this.messageParams = messageParams;
    }

    public Integer getIsread() {
        return isread;
    }

    public void setIsread(Integer isread) {
        this.isread = isread;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getIsdelete() {
        return isdelete;
    }

    public void setIsdelete(Integer isdelete) {
        this.isdelete = isdelete;
    }

    @Override
    protected Serializable pkVal() {
        return this.userMessageId;
    }

    @Override
    public String toString() {
        return "TUserMessage{" +
        ", userMessageId=" + userMessageId +
        ", userId=" + userId +
        ", messageTplNo" + messageTplNo +
        ", messageParams=" + messageParams +
        ", isread=" + isread +
        ", createTime=" + createTime +
        ", isdelete=" + isdelete +
        "}";
    }
}
