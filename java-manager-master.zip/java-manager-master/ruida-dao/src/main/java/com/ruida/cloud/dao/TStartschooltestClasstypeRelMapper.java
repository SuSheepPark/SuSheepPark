package com.ruida.cloud.dao;

import com.ruida.cloud.model.TStartschooltestClasstypeRel;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * 入学诊断、班型关联表 Mapper 接口
 * </p>
 *
 * @author mlzhang
 * @since 2019-12-16
 */
public interface TStartschooltestClasstypeRelMapper {
    Integer insert(TStartschooltestClasstypeRel tStartschooltestClasstypeRel);

    Integer updateById(TStartschooltestClasstypeRel tStartschooltestClasstypeRel);

    TStartschooltestClasstypeRel selectById(@Param("id") Integer id);

    @Select("select id , class_type_id AS classTypeId , " +
            "score from t_startschooltest_classtype_rel where isdelete = 0 and  start_school_test_id =#{testId}")
    List<Map<String, Object>> getClassTypeListByTestId(@Param("testId") Integer testId);

    Integer deleteById(@Param("") Integer id);

    Integer updateByPrimaryKeySelective(TStartschooltestClasstypeRel tStartschooltestClasstypeRel);

    @Update("update t_startschooltest_classtype_rel set isdelete = 1 where start_school_test_id  =#{testId}")
    Integer updateAllByTestId(@Param("testId") Integer testId );

    float getBigestScoreByTestId(Integer testId);
}
