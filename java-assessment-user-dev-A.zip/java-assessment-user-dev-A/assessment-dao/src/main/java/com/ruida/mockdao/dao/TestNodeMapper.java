package com.ruida.mockdao.dao;


import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.model.TestNode;
import org.apache.ibatis.annotations.Mapper;

/**
 * Created by xumingqi on 2021/7/21 17:42
 */
@Mapper
public interface TestNodeMapper extends BaseMapper<TestNode> {
}
