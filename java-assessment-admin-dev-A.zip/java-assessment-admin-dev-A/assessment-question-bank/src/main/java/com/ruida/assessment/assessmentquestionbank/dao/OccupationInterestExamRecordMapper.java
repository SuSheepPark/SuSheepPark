package com.ruida.assessment.assessmentquestionbank.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.assessment.assessmentquestionbank.dto.QuestionnaireStudentInfoDTO;
import com.ruida.assessment.assessmentquestionbank.model.OccupationInterestExamRecord;
import com.ruida.assessment.major.domain.dto.SelectRecordByStudentDTO;
import org.apache.ibatis.annotations.Param;

import java.util.Date;
import java.util.List;

/**
 * <p>
 * 霍兰德职业兴趣答题卡以及报告 Mapper 接口
 * </p>
 *
 * @author
 * @since 2021-02-05
 */
public interface OccupationInterestExamRecordMapper extends BaseMapper<OccupationInterestExamRecord> {
    List<QuestionnaireStudentInfoDTO> getStudentJobSelectRecord(
            @Param("keyWord") String keyWord, @Param("start") Integer start, @Param("pageSize") Integer pageSize, @Param("telephone") String telephone);

    Integer getStudentJobSelectRecordCount(@Param("keyWord") String keyWord, @Param("telephone") String telephone);

    List<SelectRecordByStudentDTO> getJobRecordByStudent(@Param("userId") Integer userId, @Param("minTime") Date minTime, @Param("maxTime") Date maxTime);
}
