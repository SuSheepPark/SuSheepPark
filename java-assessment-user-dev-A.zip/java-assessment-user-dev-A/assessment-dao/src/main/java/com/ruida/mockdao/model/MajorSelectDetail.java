package com.ruida.mockdao.model;

import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 专业兴趣选择详情表
 * </p>
 *
 * @author xumingqi
 * @since 2021-01-14
 */
@TableName("t_major_select_detail")
public class MajorSelectDetail extends Model<MajorSelectDetail> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;
    /**
     * t_major_select_record表的主键
     */
    @TableField("record_id")
    private Integer recordId;
    /**
     * 用户id
     */
    @TableField("user_id")
    private Integer userId;
    /**
     * 专业类代码
     */
    @TableField("major_category_code")
    private String majorCategoryCode;
    /**
     * 专业类名称
     */
    @TableField("major_category_name")
    private String majorCategoryName;
    /**
     * 学科门类代码
     */
    @TableField("subject_category_code")
    private String subjectCategoryCode;
    /**
     * 学科门类名称
     */
    @TableField("subject_category_name")
    private String subjectCategoryName;
    /**
     * 创建者ID
     */
    @TableField("create_by")
    private Integer createBy;
    /**
     * 创建时间
     */
    @TableField("create_time")
    private Date createTime;
    /**
     * 更新者ID
     */
    @TableField("update_by")
    private Integer updateBy;
    /**
     * 更新时间
     */
    @TableField("update_time")
    private Date updateTime;
    /**
     * 是否删除（0：未删除；1：删除）
     */
    private Integer isdelete;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getRecordId() {
        return recordId;
    }

    public void setRecordId(Integer recordId) {
        this.recordId = recordId;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getMajorCategoryCode() {
        return majorCategoryCode;
    }

    public void setMajorCategoryCode(String majorCategoryCode) {
        this.majorCategoryCode = majorCategoryCode;
    }

    public String getMajorCategoryName() {
        return majorCategoryName;
    }

    public void setMajorCategoryName(String majorCategoryName) {
        this.majorCategoryName = majorCategoryName;
    }

    public String getSubjectCategoryCode() {
        return subjectCategoryCode;
    }

    public void setSubjectCategoryCode(String subjectCategoryCode) {
        this.subjectCategoryCode = subjectCategoryCode;
    }

    public String getSubjectCategoryName() {
        return subjectCategoryName;
    }

    public void setSubjectCategoryName(String subjectCategoryName) {
        this.subjectCategoryName = subjectCategoryName;
    }

    public Integer getCreateBy() {
        return createBy;
    }

    public void setCreateBy(Integer createBy) {
        this.createBy = createBy;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(Integer updateBy) {
        this.updateBy = updateBy;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getIsdelete() {
        return isdelete;
    }

    public void setIsdelete(Integer isdelete) {
        this.isdelete = isdelete;
    }

    @Override
    protected Serializable pkVal() {
        return this.id;
    }

    @Override
    public String toString() {
        return "MajorSelectDetail{" +
                ", id=" + id +
                ", recordId=" + recordId +
                ", userId=" + userId +
                ", majorCategoryCode=" + majorCategoryCode +
                ", majorCategoryName=" + majorCategoryName +
                ", subjectCategoryCode=" + subjectCategoryCode +
                ", subjectCategoryName=" + subjectCategoryName +
                ", createBy=" + createBy +
                ", createTime=" + createTime +
                ", updateBy=" + updateBy +
                ", updateTime=" + updateTime +
                ", isdelete=" + isdelete +
                "}";
    }
}
