package com.ruida.assessment.assessmentcommon.enums;

public enum InformationColumnButtonEnum {

    UP(1,"上移"),
    DOWM(2,"下移"),
    HIDE(3,"隐藏"),
    REVEAL(4,"显示"),
    DELETE(5,"删除"),
    ;

    private Integer K;
    private String V;

    InformationColumnButtonEnum(Integer k, String v) {
        K = k;
        V = v;
    }

    public Integer getK() {
        return K;
    }

    public void setK(Integer k) {
        K = k;
    }

    public String getV() {
        return V;
    }

    public void setV(String v) {
        V = v;
    }

    public static DeleteStatusEnum getValueById(Integer K){
        for(DeleteStatusEnum deleteStatusEnum : DeleteStatusEnum.values() ){
            if(deleteStatusEnum.getK().equals(K)){
                return  deleteStatusEnum;
            }
        }
        return null;
    }
}
