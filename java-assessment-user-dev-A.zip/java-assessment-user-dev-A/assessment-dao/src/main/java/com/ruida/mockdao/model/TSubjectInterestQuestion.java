package com.ruida.mockdao.model;

import org.apache.commons.lang3.StringUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.enums.IdType;

/**
 * <p>
 * 科目兴趣调查文件试题
 * </p>
 *
 * @author
 * @since 2021-01-11
 */
public class TSubjectInterestQuestion {

	@TableId(value = "question_id", type = IdType.AUTO)
	private Integer questionId;
	/**
	 * 试题
	 */
	private String questionTitle;
	/**
	 * 选项
	 */
	private String stem;
	/**
	 * 题目编号
	 */
	private String questionNo;
	/**
	 * 题目排序
	 */
	private Integer sort;
	/**
	 * 是否删除（0：未删除；1：删除）
	 */
	private Integer isdelete;

	private Integer maxChooseNum;

	private Integer minChooseNum;
	
	private String subtitle;

	public Integer getQuestionId() {
		return questionId;
	}

	public void setQuestionId(Integer questionId) {
		this.questionId = questionId;
	}

	public String getQuestionTitle() {
		return questionTitle;
	}

	public void setQuestionTitle(String questionTitle) {
		this.questionTitle = questionTitle;
	}

	public String getStem() {
		return stem;
	}

	public void setStem(String stem) {
		this.stem = stem;
	}

	public String getQuestionNo() {
		return questionNo;
	}

	public void setQuestionNo(String questionNo) {
		this.questionNo = questionNo;
	}

	public Integer getSort() {
		return sort;
	}

	public void setSort(Integer sort) {
		this.sort = sort;
	}

	public Integer getIsdelete() {
		return isdelete;
	}

	public void setIsdelete(Integer isdelete) {
		this.isdelete = isdelete;
	}

	@Override
	public String toString() {
		return "TSubjectInterestQuestion{" + ", questionId=" + questionId + ", questionTitle=" + questionTitle
				+ ", stem=" + stem + ", questionNo=" + questionNo + ", sort=" + sort + ", isdelete=" + isdelete + "}";
	}

	public Integer getMaxChooseNum() {
		return maxChooseNum;
	}

	public void setMaxChooseNum(Integer maxChooseNum) {
		this.maxChooseNum = maxChooseNum;
	}

	public Integer getMinChooseNum() {
		return minChooseNum;
	}

	public void setMinChooseNum(Integer minChooseNum) {
		this.minChooseNum = minChooseNum;
	}

	public JSONArray getStemJsonArray() {
		if (StringUtils.isEmpty(getStem())) {
			return null;
		}
		return JSON.parseArray(getStem());
	}

	public String getSubtitle() {
		return subtitle;
	}

	public void setSubtitle(String subtitle) {
		this.subtitle = subtitle;
	}
}
