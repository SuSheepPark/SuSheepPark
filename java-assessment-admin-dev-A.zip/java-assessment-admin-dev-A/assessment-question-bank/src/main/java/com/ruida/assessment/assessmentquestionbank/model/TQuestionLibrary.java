package com.ruida.assessment.assessmentquestionbank.model;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.FieldStrategy;
import com.baomidou.mybatisplus.enums.IdType;

import java.io.Serializable;

/**
 * @description: 试题信息数据库实体
 * @author: kgz
 * @date: 2020/6/8
 */
@TableName("t_question_library")
public class TQuestionLibrary extends BaseColumn implements Serializable {

    private static final long serialVersionUID = -7828157324822336685L;

    /**
     * 试题id
     */
    @TableId(type = IdType.INPUT)
    private String id;

    /**
     * 学段id
     */
    private Integer periodId;

    /**
     * 科目id
     */
    private Integer subjectId;
    /**
     * 试题类型id
     */
    private Integer questionTypeId;

    /**
     * 父级id
     */
    private String parentId;

    /**
     * 难度等级id
     */
    private Integer difficultyId;

    /**
     * 保密等级id
     */
    private Integer securityLevelId;

    /**
     * 考核目标id
     */
    private Integer assessmentTargetId;

    /**
     * 试题来源id
     */
    private Integer questionSourceId;

    /**
     * 试题用途id
     */
    private Integer questionPurposeId;

    /**
     * 预计时长，分钟
     */
    private Integer estimateDuration;

    /**
     * 试题内容
     */
    private String questionTitle;

    /**
     * 试题音频地址
     */
    @TableField(strategy = FieldStrategy.IGNORED)
    private String questionAudioUrl;

    /**
     * 试题音频名称
     */
    @TableField(strategy = FieldStrategy.IGNORED)
    private String questionAudioName;

    /**
     * 试题音频时长
     */
    @TableField(strategy = FieldStrategy.IGNORED)
    private String questionAudioDuration;


    /**
     * 试题音频来源，1-本地上传，2-外部链接
     */
    @TableField(strategy = FieldStrategy.IGNORED)
    private Integer questionAudioSource;

    /**
     * 可播放次数
     */
    @TableField(strategy = FieldStrategy.IGNORED)
    private Integer playCount;

    /**
     * 题目设置
     */
    private Integer questionTitleSetting;

    /**
     * 题目序号（组合题使用）
     */
    private Integer questionSort;

    /**
     * 批改类型（0—主观题；1—客观题）
     */
    private Integer correctType;

    /**
     * 试题选项
     */
    private String stem;

    /**
     * 答案
     */
    private String answer;

    /**
     * 是否支持拍照上传答案
     */
    private Integer answerPhotographId;

    /**
     * 试题分析
     */
    @TableField(strategy = FieldStrategy.IGNORED)
    private String analysis;

    /**
     * 备注（已废弃）
     */
    @TableField(strategy = FieldStrategy.IGNORED)
    private String note;

    /**
     * 备注
     */
    @TableField(strategy = FieldStrategy.IGNORED)
    private String remark;

    /**
     * 拒绝原因
     */
    @TableField(strategy = FieldStrategy.IGNORED)
    private String rejectReason;

    /**
     * 评价
     */
    @TableField(strategy = FieldStrategy.IGNORED)
    private String evaluation;

    /**
     * 试题状态（1-草稿；2-提交（待审核）；3-已发布；4-取消发布）
     */
    private Integer questionStatus;

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getQuestionTypeId() {
        return questionTypeId;
    }

    public void setQuestionTypeId(Integer questionTypeId) {
        this.questionTypeId = questionTypeId;
    }

    public Integer getDifficultyId() {
        return difficultyId;
    }

    public void setDifficultyId(Integer difficultyId) {
        this.difficultyId = difficultyId;
    }

    public Integer getSecurityLevelId() {
        return securityLevelId;
    }

    public void setSecurityLevelId(Integer securityLevelId) {
        this.securityLevelId = securityLevelId;
    }

    public Integer getAssessmentTargetId() {
        return assessmentTargetId;
    }

    public void setAssessmentTargetId(Integer assessmentTargetId) {
        this.assessmentTargetId = assessmentTargetId;
    }

    public Integer getQuestionSourceId() {
        return questionSourceId;
    }

    public void setQuestionSourceId(Integer questionSourceId) {
        this.questionSourceId = questionSourceId;
    }

    public Integer getQuestionPurposeId() {
        return questionPurposeId;
    }

    public void setQuestionPurposeId(Integer questionPurposeId) {
        this.questionPurposeId = questionPurposeId;
    }

    public Integer getEstimateDuration() {
        return estimateDuration;
    }

    public void setEstimateDuration(Integer estimateDuration) {
        this.estimateDuration = estimateDuration;
    }

    public String getQuestionTitle() {
        return questionTitle;
    }

    public void setQuestionTitle(String questionTitle) {
        this.questionTitle = questionTitle;
    }

    public Integer getQuestionSort() {
        return questionSort;
    }

    public void setQuestionSort(Integer questionSort) {
        this.questionSort = questionSort;
    }

    public Integer getCorrectType() {
        return correctType;
    }

    public void setCorrectType(Integer correctType) {
        this.correctType = correctType;
    }

    public String getStem() {
        return stem;
    }

    public void setStem(String stem) {
        this.stem = stem;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public String getAnalysis() {
        return analysis;
    }

    public void setAnalysis(String analysis) {
        this.analysis = analysis;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public Integer getQuestionStatus() {
        return questionStatus;
    }

    public void setQuestionStatus(Integer questionStatus) {
        this.questionStatus = questionStatus;
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public Integer getAnswerPhotographId() {
        return answerPhotographId;
    }

    public void setAnswerPhotographId(Integer answerPhotographId) {
        this.answerPhotographId = answerPhotographId;
    }

    public Integer getQuestionTitleSetting() {
        return questionTitleSetting;
    }

    public void setQuestionTitleSetting(Integer questionTitleSetting) {
        this.questionTitleSetting = questionTitleSetting;
    }

    public Integer getPeriodId() {
        return periodId;
    }

    public void setPeriodId(Integer periodId) {
        this.periodId = periodId;
    }

    public Integer getSubjectId() {
        return subjectId;
    }

    public void setSubjectId(Integer subjectId) {
        this.subjectId = subjectId;
    }

    public String getRejectReason() {
        return rejectReason;
    }

    public void setRejectReason(String rejectReason) {
        this.rejectReason = rejectReason;
    }

    public String getEvaluation() {
        return evaluation;
    }

    public void setEvaluation(String evaluation) {
        this.evaluation = evaluation;
    }

    public String getQuestionAudioUrl() {
        return questionAudioUrl;
    }

    public void setQuestionAudioUrl(String questionAudioUrl) {
        this.questionAudioUrl = questionAudioUrl;
    }

    public Integer getPlayCount() {
        return playCount;
    }

    public void setPlayCount(Integer playCount) {
        this.playCount = playCount;
    }

    public Integer getQuestionAudioSource() {
        return questionAudioSource;
    }

    public void setQuestionAudioSource(Integer questionAudioSource) {
        this.questionAudioSource = questionAudioSource;
    }

    public String getQuestionAudioName() {
        return questionAudioName;
    }

    public void setQuestionAudioName(String questionAudioName) {
        this.questionAudioName = questionAudioName;
    }

    public String getQuestionAudioDuration() {
        return questionAudioDuration;
    }

    public void setQuestionAudioDuration(String questionAudioDuration) {
        this.questionAudioDuration = questionAudioDuration;
    }

    @Override
    public String toString() {
        return "TQuestionLibrary{" +
                "id=" + id +
                ", questionTypeId=" + questionTypeId +
                ", periodId=" + periodId +
                ", subjectId=" + subjectId +
                ", parentId=" + parentId +
                ", difficultyId=" + difficultyId +
                ", securityLevelId=" + securityLevelId +
                ", assessmentTargetId=" + assessmentTargetId +
                ", questionSourceId=" + questionSourceId +
                ", questionPurposeId=" + questionPurposeId +
                ", estimateDuration=" + estimateDuration +
                ", questionTitle='" + questionTitle + '\'' +
                ", questionAudioUrl='" + questionAudioUrl + '\'' +
                ", questionAudioName='" + questionAudioName + '\'' +
                ", questionAudioDuration='" + questionAudioDuration + '\'' +
                ", questionAudioSource='" + questionAudioSource + '\'' +
                ", playCount='" + playCount + '\'' +
                ", questionTitleSetting='" + questionTitleSetting + '\'' +
                ", questionSort=" + questionSort +
                ", correctType=" + correctType +
                ", stem='" + stem + '\'' +
                ", answer='" + answer + '\'' +
                ", answerPhotographId='" + answerPhotographId + '\'' +
                ", analysis='" + analysis + '\'' +
                ", note='" + note + '\'' +
                ", rejectReason='" + rejectReason + '\'' +
                ", evaluation='" + evaluation + '\'' +
                ", questionStatus=" + questionStatus +
                super.toString() +
                '}';
    }
}
