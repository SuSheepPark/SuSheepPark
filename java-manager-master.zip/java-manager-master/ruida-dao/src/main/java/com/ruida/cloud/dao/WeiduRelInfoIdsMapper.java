package com.ruida.cloud.dao;

import com.ruida.cloud.model.WeiduRelInfoIds;

import java.util.List;

public interface WeiduRelInfoIdsMapper {
    public List<WeiduRelInfoIds> listWeiduRelIds(Integer courseId);
}