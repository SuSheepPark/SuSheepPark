package com.ruida.common;

import com.ruida.common.util.PropertyMT;
import org.apache.shiro.crypto.hash.Md5Hash;

/**
 * 系统静态变量
 * @author Ciffer
 *
 */
public class SystemConstant {

	/**
	 * 应用部署路径的KEY
	 */
	public static String SESSION_USER = "SESSION_USER";
	public static final String SESSION_USERINFO="USERINFO";

	public static final String SESSION_ADMIN_MENUS="ADMIN_MENUS";

	public static final String SESSION_USER_MENUS="USER_MENUS";

	public static final String DEFAULT_PASSWORD = "ruida123";

	public static final Integer DEFAULT_PAGE_SIZE = 10;
	public static final String       DOWNLOAD_PROTOCAL          = "application/x-download";
	public static final String       UTF8                       = "UTF-8";
	public static final String       DATE_FORMAT                = "yyyy-MM-dd HH:mm";
	public static final String       TIME_ZONE                  = "GMT+8";
	public  static final String      MD5_SALT                   = "8F4470DB788FB93DFAF8D91393155921";
	/**文件路径管理*/
	public  static final String   UPLOAD_ROOT = "/datadrive";//主路径
	public  static final String   COVER_PIC = "/ruidacloud/upload/course/coverPic";//课程封面
	public  static final String   COVER_RICH = "/ruidacloud/upload/course/richText";//课程富文本
	public  static final String   COURSE_WARE = "/ruidacloud/upload/resourceLibrary/courseware";//资源库
	public  static final String   ROTATION_CHART = "/ruidacloud/upload/webHomePage/rotationChart";//门户首页轮播
	public  static final String   NEW_INFO = "/ruidacloud/upload/webHomePage/newsInfo";//门户首页资讯管理富文本附件存放路径
	public  static final String   SCHOOL_LOGO = "/ruidacloud/upload/schoolLogo";//学校logo
	public  static final String   STU_EXCEL   = "/ruidacloud/upload/stuExcel";//导入学生Excel存放
	public  static final String   COURSE_INTRO = "/ruidacloud/upload/courseIntro";//课程介绍
	public  static final String   COURSE_STORE = "/ruidacloud/upload/courseStore";//课程收藏
	public  static  final String RELOAD_ROOT = "/ruidaCloud/images";//文件访问主路径
	public  static  final String RESOURCE_ROOT = "/ruidaCloud/files";//资源库路径
	/**学生排班信息*/
	public static final String COURSE_CAMPUS = "/ruidacloud/upload/courseCampus";
	/**知识点上传路径*/
	public static final String KNOWLEDGE = "/ruidacloud/upload/knowledge";

	public static final String APP_FILE_PATH ="/ruidacloud/upload/apps/android/";


	public static final int COURSE_WARE_SIZE = 20971520;    //课件文件上传大小限制20M  20*1024*1024=20971520
	public static final int COURSE_COVER_SIZE = 2097152;    //课程封面 2M
	/**提示语管理*/
	public  static final String   TAPU_SUCCESS = "禁用成功";//禁用成功提示语
	public  static final String   RE_TAPU_SUCCESS = "启用成功";//启用成功提示语
	public  static final String   DEL_SUCCESS = "删除成功";//删除成功提示语
	public static final String HOT_SUCCESS = "推荐成功";
	/**课程热门推荐最大个数*/
	public static final int COURSE_HOT_COUNT = 6;
	public static final String  DEFAULT_USER_MSG = "恭喜您已成功分配睿达云课堂后台账号，您的账号为%s,默认密码%s，请您妥善保管";
	public static final String  DEFAULT_USER_STU_MSG = "恭喜您已成功注册睿达云课堂，您的账号为%s,默认密码%s，请尽快前往账号中心修改密码";

	public static final String  DEFAULT_USER_REF_MSG = "密码已经重置密码为%s,请您妥善保管";

	public static void main(String[] args) {
		System.out.println(new Md5Hash("23456",SystemConstant.MD5_SALT,1));
	}

    public static final String KAPTCHA_KEY =  "KAPTCHA_%s";

    public final static String REFUND_ORDER_KEY = "REFUND_ORDER_%s";

    public static final int KAPTCHA_KEY_TIME = 60*2  ;

	public static String[] orderStus = {"姓名","学生/家长手机","支付价","校区名称"};
	public static String[] orgStus = {"来源学校","年级","班级","姓名","学生/家长电话","老师电话"};
	public static String[] doubleStudents = {"学生名称","学号","性别","联系方式"};
}
