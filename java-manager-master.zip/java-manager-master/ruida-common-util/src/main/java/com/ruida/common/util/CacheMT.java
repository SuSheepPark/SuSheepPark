/**
 * Copyright &copy; 2015-2020  All rights reserved.
 */
package com.ruida.common.util;

import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;

import java.util.concurrent.ThreadPoolExecutor;

/**
 * Cache工具类
 * @author jeeplus
 * @version 2013-5-29
 */
public class CacheMT {
	
	private static CacheManager cacheManager = ((CacheManager) SpringBeanMT.getBean("cacheManager"));

	private static final long DEFAULT_TIMEOUT = 300000;
	private static final String SYS_CACHE = "sysCache";
	private static final String TIME_CACHE = "timeCache";
//	private static final String NON_PUBLIC_CACHE = "nonPublicCache";
//	private static final String DISCOUNT_USER_CACHE = "discountUserCache";
//	private static final String DICT_CACHE = "dictCache";

	/**
	 * 获取SYS_CACHE缓存
	 * @param key
	 * @return
	 */
	public static Object get(String key) {
		return get(SYS_CACHE, key);
	}
	
	/**
	 * 写入SYS_CACHE缓存
	 * @param key
	 * @return
	 */
	public static void put(String key, Object value) {
		put(SYS_CACHE, key, value);
	}
	
	/**
	 * 从SYS_CACHE缓存中移除
	 * @param key
	 * @return
	 */
	public static void remove(String key) {
		remove(SYS_CACHE, key);
	}
	
	/**
	 * 获取缓存
	 * @param cacheName
	 * @param key
	 * @return
	 */
	public static Object get(String cacheName, String key) {
		Element element = getCache(cacheName).get(key);
		return element==null?null:element.getObjectValue();
	}

	/**
	 * 写入缓存
	 * @param cacheName
	 * @param key
	 * @param value
	 */
	public static void put(String cacheName, String key, Object value) {
		Element element = new Element(key, value);
		getCache(cacheName).put(element);
	}

	/**
	 * 从缓存中移除
	 * @param cacheName
	 * @param key
	 */
	public static void remove(String cacheName, String key) {
		getCache(cacheName).remove(key);
	}

	public static void removeAll(String cacheName){
		getCache(cacheName).removeAll();
	}

//	public static void putTime(String key, long value){
//	    value = System.currentTimeMillis();
//	    put(TIME_CACHE, key, value);
//    }

	/**
	 * 获得一个Cache，没有则创建一个。
	 * @param cacheName
	 * @return
	 */
	private static Cache getCache(String cacheName){
		Cache cache = cacheManager.getCache(cacheName);
		if (cache == null){
			cacheManager.addCache(cacheName);
			cache = cacheManager.getCache(cacheName);
			cache.getCacheConfiguration().setEternal(true);
		}
		return cache;
	}

	private class ClearThread extends Thread {
	    private String key;
	    ClearThread(){
	        setName("clear cache thread");
        }

        @Override
        public void run() {
            while ( true ) {
                try {
                    long now = System.currentTimeMillis();
                    long old = (long) get(TIME_CACHE, key);
                    if ( now - old  >= DEFAULT_TIMEOUT){
                        synchronized ( this ){
                            remove(TIME_CACHE, key);
//                            remove(SYS_CACHE, key);
                        }
                    }

                    Thread.sleep(60000);
                }catch (  Exception e){
                    e.printStackTrace();
                }
            }
        }
    }

	public static CacheManager getCacheManager() {
		return cacheManager;
	}
	
}
