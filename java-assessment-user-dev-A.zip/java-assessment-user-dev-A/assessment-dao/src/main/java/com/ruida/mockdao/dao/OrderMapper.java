package com.ruida.mockdao.dao;


import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.model.Order;
import com.ruida.mockdao.vo.OrderPaperVO;
import com.ruida.mockdao.vo.OrderVO;
import com.ruida.mockdao.vo.UnifiedTestPaperVO;
import org.apache.ibatis.annotations.Param;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * 订单信息表 Mapper 接口
 * </p>
 *
 * @author Bhj
 * @since 2020-07-20
 */
public interface OrderMapper extends BaseMapper<Order> {

    List<OrderVO> listUserOrderByPage(Map<String, Object> param);

    Integer countUserOrderByPage(Map<String, Object> param);

    ArrayList<OrderPaperVO> listPaperByOrderId(Integer orderId);

    Integer getPurchaseNumByOrderId(Integer orderId);

    Map<String, Object> getOrderInfo(@Param("productId") Integer productId, @Param("userId") String userId, @Param("status") Integer status,
                                     @Param("orderTypeList") List<Integer> orderTypeList);

    Integer isBuyByUserId(Integer userId);

    OrderVO getOrderByOrderNo(String orderNo);

    Map<String, Object> getReportOrderInfo(@Param("productId") Integer productId, @Param("recordId") Integer recordId,
                                           @Param("userId") String userId, @Param("status") Integer status,
                                           @Param("reportOrderTypeList") List<Integer> reportOrderTypeList);

    Integer setIsPurchaseReport(@Param("orderId") Integer orderId, @Param("purchaserId") Integer purchaserId);

    Integer setIsPurchaseReportNew(@Param("orderId") Integer orderId);

    BigDecimal getPriceNumsByProductId(String productId);

    Order getOrderReportInfo(@Param("productId") Integer productId, @Param("purchaserId") Integer purchaserId,
                             @Param("orderTypeList") List<Integer> orderTypeList);

    List<UnifiedTestPaperVO> listUnifiedTestPaper(@Param("userId") String userId);
}
