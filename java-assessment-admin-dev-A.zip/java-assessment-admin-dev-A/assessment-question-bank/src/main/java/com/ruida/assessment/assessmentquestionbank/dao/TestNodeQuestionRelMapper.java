package com.ruida.assessment.assessmentquestionbank.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.assessment.assessmentquestionbank.model.TTestNodeQuestionRel;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * @description:
 * @author: kgz
 * @date: 2020/6/29
 */
@Mapper
public interface TestNodeQuestionRelMapper extends BaseMapper<TTestNodeQuestionRel> {
    @Select("SELECT\n" +
            "\ta.question_id \n" +
            "FROM\n" +
            "\tt_test_node_question_rel a\n" +
            "WHERE\n" +
            "\ta.test_paper_id = #{testPaperId}\n" +
            "AND a.question_type_id = #{queType}\n" +
            "AND a.isdelete = 0")
   List<String>  getQueIdsByTestPaperAndQueType(@Param("testPaperId") Integer testPaperId, @Param("queType") Integer queType);


    List<String> queryTestPaperQuestionIdList(@Param("testPaperId") Integer testPaperId);
}
