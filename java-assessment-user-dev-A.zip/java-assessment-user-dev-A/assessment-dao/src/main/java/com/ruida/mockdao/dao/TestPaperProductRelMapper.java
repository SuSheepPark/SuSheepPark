package com.ruida.mockdao.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.model.TestPaperProductRel;
import com.ruida.mockdao.vo.TestPaperStructureVO;
import org.apache.ibatis.annotations.Param;

/**
 * <p>
 * 商品-试卷关联表 Mapper 接口
 * </p>
 *
 * @author chenjy
 * @since 2020-07-17
 */
public interface TestPaperProductRelMapper extends BaseMapper<TestPaperProductRel> {

    TestPaperProductRel selectByProductAndPaperId(@Param("productId") Integer productId, @Param("testPaperId") Integer testPaperId);

    TestPaperStructureVO queryTestPaperStructure(@Param("productId") Integer productId,@Param("testPaperId") Integer testPaperId);
}
