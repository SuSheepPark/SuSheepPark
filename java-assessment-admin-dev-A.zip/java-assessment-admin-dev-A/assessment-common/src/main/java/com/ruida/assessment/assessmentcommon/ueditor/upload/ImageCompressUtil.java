package com.ruida.assessment.assessmentcommon.ueditor.upload;

import net.coobird.thumbnailator.Thumbnails;
import net.coobird.thumbnailator.geometry.Positions;
import net.coobird.thumbnailator.makers.ScaledThumbnailMaker;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * @author taosh
 * @create 2020-04-27 15:57
 */
public class ImageCompressUtil {
    /**
     * 流方式输入输出图片压缩
     *
     * @param src     文件输入流（单个）
     * @param target  压缩后文件输出流（单个）
     * @param quality 压缩质量
     * @throws IOException
     */
    public static void compress(InputStream src, OutputStream target, float quality) throws IOException {
        Thumbnails.of(src).scale(1)
                .outputQuality(quality).toOutputStream(target);
    }

    /**
     * 流方式输入输出图片压缩
     *
     * @param src     文件输入流（单个）
     * @param target  压缩后文件输出流（单个）
     * @param quality 压缩质量
     * @throws IOException
     */
    public static void compress(InputStream src, OutputStream target, float quality, String format) throws IOException {
        Thumbnails.of(src).scale(1)
                .outputFormat(format)//输出格式
                .outputQuality(quality).toOutputStream(target);
    }

    /**
     * 压缩并重置大小(流式)
     *
     * @param src
     * @param target
     * @param quality
     * @param width
     * @param height
     * @throws IOException
     */
    public static void compressAndsize(InputStream src, OutputStream target, float quality, int width, int height) throws IOException {
        Thumbnails.of(src).size(width, height).keepAspectRatio(false).outputQuality(quality).toOutputStream(target);
    }

    /**
     * @param src
     * @param target
     * @param quality
     * @param width
     * @param height
     * @param format
     * @throws IOException
     */
    public static void compressAndsize(InputStream src, OutputStream target, float quality, int width, int height, String format) throws IOException {
        Thumbnails.of(src).size(width, height).keepAspectRatio(false)
                .outputFormat(format)//输出格式
                .outputQuality(quality).toOutputStream(target);
    }

    /**
     * 根据宽比例压缩(流式)
     *
     * @param src
     * @param target
     * @param quality
     * @param width
     * @throws IOException
     */
    public static void compressAndsizeWidth(InputStream src, OutputStream target, float quality, int width) throws IOException {
        Thumbnails.of(src).width(width).keepAspectRatio(true).outputQuality(quality).toOutputStream(target);
    }

    /**
     * 根据宽比例压缩(流式)
     *
     * @param src
     * @param target
     * @param quality
     * @param width
     * @throws IOException
     */
    public static void compressAndsizeWidth(InputStream src, OutputStream target, float quality, int width, String format) throws IOException {
        Thumbnails.of(src).width(width).keepAspectRatio(true)
                .outputFormat(format)//输出格式
                .outputQuality(quality).toOutputStream(target);
    }


    /**
     * 根据宽比例压缩(流式)
     *
     * @param src
     * @param target
     * @param quality
     * @param height
     * @throws IOException
     */
    public static void compressAndsizeHeight(InputStream src, OutputStream target, float quality, int height) throws IOException {
        Thumbnails.of(src).height(height).keepAspectRatio(true).outputQuality(quality).toOutputStream(target);
    }

    /**
     * 根据宽比例压缩(流式)
     *
     * @param src
     * @param target
     * @param quality
     * @param height
     * @throws IOException
     */
    public static void compressAndsizeHeight(InputStream src, OutputStream target, float quality, int height, String format) throws IOException {
        Thumbnails.of(src).height(height).keepAspectRatio(true)
                .outputFormat(format)//输出格式
                .outputQuality(quality).toOutputStream(target);
    }

    /**
     * 压缩并添加图片水印(流式)
     *
     * @param src      原图
     * @param target   输出图
     * @param mark     水印图片
     * @param position 水印位置
     * @param opacity  水印透明度 0.0f-1.0f
     * @param quality  图片质量 0-1
     * @throws IOException
     */
    public static void compressAndWatermark(InputStream src, OutputStream target, InputStream mark, Positions position, float opacity, float quality) throws IOException {
        Thumbnails.of(src)
                .scale(1)
                .watermark(position, ImageIO.read(mark), opacity)
                .outputQuality(quality)
                .toOutputStream(target);
    }

    /**
     * 压缩并添加图片水印(流式)
     *
     * @param src      原图
     * @param target   输出图
     * @param mark     水印图片
     * @param position 水印位置
     * @param opacity  水印透明度 0.0f-1.0f
     * @param quality  图片质量 0-1
     * @throws IOException
     */
    public static void compressAndWatermark(InputStream src, OutputStream target, InputStream mark, Positions position, float opacity, float quality, String format) throws IOException {
        Thumbnails.of(src).scale(1)
                .watermark(position, ImageIO.read(mark), opacity)
                .outputFormat(format)//输出格式
                .outputQuality(quality).toOutputStream(target);
    }

    public static void main(String[] args) {
        try {

            BufferedImage img = ImageIO.read(new File("D:\\789.jpg"));
            BufferedImage bi = new ScaledThumbnailMaker().scale(1).imageType(BufferedImage.TYPE_3BYTE_BGR).make(img);
            ImageIO.write(bi,"jpg",new File("D:\\123-bk.jpg"));
//            FileInputStream src=new FileInputStream(new File("D:\\123.jpg"));
//            OutputStream target=new FileOutputStream(new File("D:\\123-size.jpg"));
//            compressAndsize(src, target, 0.3f, 3799, 7244,"jpg");
//            src.close();
//            target.close();


        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
