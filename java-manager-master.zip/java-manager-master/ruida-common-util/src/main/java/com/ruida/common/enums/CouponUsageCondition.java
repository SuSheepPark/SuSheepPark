package com.ruida.common.enums;

public enum CouponUsageCondition {
	FULLREDUCTION((byte) 0), COURSE((byte) 1);

	CouponUsageCondition(byte i) {
		this.dataValue = i;
	}

	byte dataValue;

	public byte getDataValue() {
		return dataValue;
	}

	public void setDataValue(byte dataValue) {
		this.dataValue = dataValue;
	}

	public static CouponUsageCondition valueOf(byte i) {
		switch (i) {
		case 0:
			return FULLREDUCTION;
		case 1:
			return COURSE;
		default:
			return FULLREDUCTION;
		}
	}
}
