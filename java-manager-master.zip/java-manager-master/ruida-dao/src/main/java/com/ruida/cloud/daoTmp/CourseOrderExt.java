package com.ruida.cloud.daoTmp;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ruida.cloud.model.Course;
import com.ruida.cloud.model.CourseExt;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author taosh
 * @create 2019-03-01 11:58
 */
@Data
public class CourseOrderExt extends Course implements Cloneable {
    /**
     * 课程主键ID
     */
    private Integer courseId;
    /**
     * 课程名称
     */
    private String courseName;
    /**
     * 授课方式（0—直播课；1—录播课）
     */
    private Byte teachingMethod;
    /**
     * 封面图片路径
     */
    private String coverPath;
    /**
     * 学段ID
     */
    private Integer periodId;
    /**
     * 年级ID
     */
    private Integer stageId;
    /**
     * 课程类型ID
     */
    private Integer courseTypeId;
    /**
     * 班级类型id
     */
    private Integer classTypeId;
    /**
     * 是否公开（0—不公开；1—公开）
     */
    private Byte ispublic;
    /**
     * 是否收费（0—不收费；1—收费）
     */
    private Byte ischarge;
    /**
     * 优惠额度（85，表示打八五折）
     */
    private Byte sale;
    /**
     * 是否试看（0—不试看；1—试看）
     */
    private Byte istryvideo;
    /**
     * 课程开始时间
     */

    private String   startTime;
    /**
     * 课程结束时间
     */

    private String endTime;
    /**
     * 课程有效期（0—1个月；1—3个月；2—6个月；3—9个月；4—12个月；5—2年；6—3年；7—无限期）
     */
    private String validDate;
    /**
     * 课程简介
     */
    private String summary;
    /**
     * 是否发布（0—未发布；1—已发布）
     */
    private Byte ispublish;
    private Integer lessonCount;
    /**第一节课次开课次间*/
    @JsonFormat(pattern= "yyyy-MM-dd HH:mm",timezone="GMT+8")
    private Date classBeginTime;
    /**最后一节课次结束时间*/
    @JsonFormat(pattern= "yyyy-MM-dd HH:mm",timezone="GMT+8")
    private Date classEedTime;
    private String classTypeName;
    /***
     * 难度
     */
    private String difficulty;
    private String stageName;
    private String periodName;
    private String teacherName;
    private BigDecimal underLinePriceSum;
    private BigDecimal underLineSalePriceSum;
    private BigDecimal onlinePriceSum;
    private BigDecimal onlineSalePrice;
    private String subjectName;
    private String schoolName;
    private String assistantName;
    private String courseTypeName;
    private Integer orderId;
    /**
     * 课程进行到第几课次（针对我的课程）
     */
    private Integer classHourNum;
    /**
     * 直播状态（1，未开始；2，直播中；3，已完结）
     */
    private int liveStatus;
    /**
     * 课程期限(1，剩余几天；2，已过期；3，无限期)
     */
    private int courseValid;

    /**
     * 课程有效期剩余天数
     */
    private Integer remainDays;

    /**
     * 是否已购买 (1,已购买)
     */
    private Byte isBuy;
    /**
     * 支付时间
     */
    private Date paymentTime;
    /**
     * findType 0= 线下双师 1= 录播课堂 ，2 = 在线直播
     */
    private Integer findType;
    /**
     * purchaseFindType 已购买的类型 0= 线下双师 1= 录播课堂 ，2 = 在线直播
     */
    private Integer purchaseFindType;

    private  Boolean isPurchase;
    private Integer purchaseNum;

    /**允许购买总数**/
    private Integer coureAllBuyNum;
    /**已经购买总数**/
    private Integer coureBuyNum;
    /**剩余购买总数**/
    private Integer coureSurplusNum;
    /**校区直播间名称**/
    private String  broadcastName;
    /**开始时间（年月日）**/
    private Date startDate;
    /**结束时间（年月日）**/
    private Date endDate;

    /**
     * 课程开始时间(具体时间（时分）)
     */

    private String  startTimeHs;
    /**
     * 课程结束时间(具体时间（时分）)
     */

    private String endTimeHs;

    private String wxShareUrl;
    @Override
    public Object clone() {
        CourseExt ext = null;
        try {
            ext = (CourseExt) super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }
        return ext;
    }

}
