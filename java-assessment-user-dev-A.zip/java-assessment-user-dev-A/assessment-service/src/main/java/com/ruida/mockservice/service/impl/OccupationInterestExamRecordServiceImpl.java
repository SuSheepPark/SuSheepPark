package com.ruida.mockservice.service.impl;

import java.util.Arrays;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.ruida.mockdao.dao.OccupationInterestExamRecordMapper;
import com.ruida.mockdao.model.OccupationInterestExamRecord;
import com.ruida.mockservice.service.OccupationInterestExamRecordService;

/**
 * <p>
 * 霍兰德职业兴趣答题卡以及报告 服务实现类
 * </p>
 *
 * @author
 * @since 2021-02-05
 */
@Service
public class OccupationInterestExamRecordServiceImpl
		extends ServiceImpl<OccupationInterestExamRecordMapper, OccupationInterestExamRecord>
		implements OccupationInterestExamRecordService {

	private static Map<Integer, Map<String, List<Integer>>> cache = new LinkedHashMap<>();
	static {
		Map<String, List<Integer>> map1 = new LinkedHashMap<>();
		map1.put("A", Arrays.asList(7, 19, 29, 39, 41, 51, 57));
		map1.put("B", Arrays.asList(5, 18, 40));
		Map<String, List<Integer>> map2 = new LinkedHashMap<>();
		map2.put("A", Arrays.asList(2, 13, 22, 36, 43));
		map2.put("B", Arrays.asList(14, 23, 44, 47, 48));
		Map<String, List<Integer>> map3 = new LinkedHashMap<>();
		map3.put("A", Arrays.asList(6, 8, 20, 30, 31, 42));
		map3.put("B", Arrays.asList(21, 55, 56, 58));
		Map<String, List<Integer>> map4 = new LinkedHashMap<>();
		map4.put("A", Arrays.asList(11, 24, 28, 35, 38, 46, 60));
		map4.put("B", Arrays.asList(3, 16, 25));
		Map<String, List<Integer>> map5 = new LinkedHashMap<>();
		map5.put("A", Arrays.asList(26, 37, 52, 59));
		map5.put("B", Arrays.asList(1, 12, 15, 27, 45, 53));
		Map<String, List<Integer>> map6 = new LinkedHashMap<>();
		map6.put("A", Arrays.asList(4, 9, 10, 17, 33, 34, 49, 50, 54));
		map6.put("B", Arrays.asList(32));
		cache.put(1, map1);
		cache.put(2, map2);
		cache.put(3, map3);
		cache.put(4, map4);
		cache.put(5, map5);
		cache.put(6, map6);
	}

	@Override
	public OccupationInterestExamRecord upload(OccupationInterestExamRecord record) {
		OccupationInterestExamRecord record2 = selectOne(new EntityWrapper<OccupationInterestExamRecord>()
				.eq("create_by", record.getCreateBy()).isNull("answer"));
		if (record2 == null) {
			record2 = record;
			record2.setRecordId(null);
			record2.setCheckBuyQuestion(false);
		} else {
			record2.setAnswer(record.getAnswer());
		}
		String answer = record.getAnswer();
		JSONArray answerArray = JSON.parseArray(answer);
		Map<Integer, Integer> scores = new LinkedHashMap<>();
		scores.put(5, 0);
		scores.put(1, 0);
		scores.put(3, 0);
		scores.put(6, 0);
		scores.put(4, 0);
		scores.put(2, 0);
		for (int i = 0; i < answerArray.size(); i++) {
			JSONObject object = answerArray.getJSONObject(i);
			Integer id = object.getInteger("key");
			String val = object.getString("val");
			for (Entry<Integer, Map<String, List<Integer>>> entry1 : cache.entrySet()) {
				Map<String, List<Integer>> value1 = entry1.getValue();
				for (Entry<String, List<Integer>> entry2 : value1.entrySet()) {
					String key2 = entry2.getKey();
					List<Integer> value2 = entry2.getValue();
					if (key2.equals(val) && value2.contains(id)) {
						Integer key1 = entry1.getKey();
						scores.put(key1, scores.get(key1) + 1);
					}
				}
			}
		}
		JSONArray report = new JSONArray();
		List<Entry<Integer, Integer>> sort = new LinkedList<>();
		for (Entry<Integer, Integer> entry : scores.entrySet()) {
			JSONObject object = new JSONObject();
			object.put("key", entry.getKey());
			object.put("name", getNameById(entry.getKey()));
			object.put("val", entry.getValue());
			object.put("status", 0);
			report.add(object);
			sort.add(entry);
		}
		sort.sort((y, x) -> x.getValue() - y.getValue());

		record2.setGroup(getNameById(sort.get(0).getKey()) + "+" + getNameById(sort.get(1).getKey()) + "+"
				+ getNameById(sort.get(2).getKey()));
		record2.setReport(report.toJSONString());
		record2.setStatus(1);
		record2.setUpdateTime(new Date());
		record.setCheckBuyReport(false);
		if (record2.getRecordId() == null) {
			insert(record2);
		} else {
			updateById(record2);
		}
		return record2;
	}

	public String getNameById(Integer id) {
		String name;
		switch (id) {
		case 1:
			name = "常规型(C)";
			break;
		case 2:
			name = "现实型(R)";
			break;
		case 3:
			name = "研究型(I)";
			break;
		case 4:
			name = "企业型(E)";
			break;
		case 5:
			name = "社会型(S)";
			break;
		case 6:
			name = "艺术型(A)";
			break;
		default:
			name = "无法选择";
			break;
		}
		return name;
	}

	@Override
	public void createAfterBuyQuestion(Integer userId) {
		OccupationInterestExamRecord record = new OccupationInterestExamRecord();
		record.setCreateBy(userId);
		record.setCheckBuyQuestion(true);
		record.setCreateTime(new Date());
		record.setCheckBuyReport(false);
		record.setIsdelete(0);
		insert(record);

	}

	@Override
	public void updateAfterBuyReport(Integer recordId) {
		OccupationInterestExamRecord record = selectById(recordId);
		record.setCheckBuyReport(true);
		updateById(record);
	}

	@Override
	public Boolean checkHasUndoPaper(Integer userId) {
		return selectCount(
				new EntityWrapper<OccupationInterestExamRecord>().eq("create_by", userId).isNull("answer")) != 0;
	}

	@Override
	public void createFreeQuestion(Integer userId) {
		OccupationInterestExamRecord record = new OccupationInterestExamRecord();
		record.setCreateBy(userId);
		record.setCheckBuyQuestion(false);
		record.setCreateTime(new Date());
		record.setCheckBuyReport(false);
		record.setIsdelete(0);
		insert(record);
	}

	@Override
	public Integer countAllUploadRecordNum() {
		return selectCount(new EntityWrapper<OccupationInterestExamRecord>().isNotNull("answer"));
	}

	@Override
	public Boolean checkHasReport(Integer userId) {
		Integer count = selectCount(
				new EntityWrapper<OccupationInterestExamRecord>().eq("create_by", userId).isNotNull("answer"));
		return count != 0;
	}

}
