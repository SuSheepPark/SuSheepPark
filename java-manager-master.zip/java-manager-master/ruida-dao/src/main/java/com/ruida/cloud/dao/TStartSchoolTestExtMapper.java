package com.ruida.cloud.dao;

import com.ruida.cloud.model.StartschooltestExt;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * 入学诊断信息表 Mapper 列表接口
 * </p>
 *
 * @author mlzhang
 * @since 2019-12-16
 */
public interface TStartSchoolTestExtMapper {
    int countStartSchoolTestByExample(Map condition);

    List<StartschooltestExt> selectStartSchoolTestByExample(Map condition);

    int countStartSchoolTestCommit(int startSchoolTestId);
}
