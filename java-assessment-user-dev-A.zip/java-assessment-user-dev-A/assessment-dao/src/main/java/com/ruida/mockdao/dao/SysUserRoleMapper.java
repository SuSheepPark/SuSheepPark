package com.ruida.mockdao.dao;


import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.model.SysUserRole;

/**
 * <p>
 * 用户角色表 Mapper 接口
 * </p>
 *
 * @author Bhj
 * @since 2020-07-09
 */
public interface SysUserRoleMapper extends BaseMapper<SysUserRole> {

}
