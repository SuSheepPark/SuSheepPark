package com.ruida.common.util.excel.processor.impl;

import com.ruida.common.util.excel.processor.TypeProcessor;
import org.apache.commons.lang3.StringUtils;

import java.text.ParseException;

/**
 * Created by Administrator on 2017/4/18.
 */
public class IntegerProcessorImpl implements TypeProcessor {

    @Override
    public Object fromString(String preValue) throws ParseException {
        if(StringUtils.isBlank(preValue)){
            return 0;
        }
        try{
            return Integer.parseInt(preValue);
        }catch (NumberFormatException ex){
            throw new ParseException(preValue + "无法转换为Int数字类型", 0);
        }
    }

    @Override
    public String toString(Object value) throws ParseException {
        if(value == null){
            return "";
        }

        return value.toString();
    }

}
