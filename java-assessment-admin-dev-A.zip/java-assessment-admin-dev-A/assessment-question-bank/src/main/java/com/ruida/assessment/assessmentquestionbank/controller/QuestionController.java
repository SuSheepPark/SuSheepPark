package com.ruida.assessment.assessmentquestionbank.controller;

import com.ruida.assessment.assessmentcommon.result.MapResult;
import com.ruida.assessment.assessmentcommon.result.Page;
import com.ruida.assessment.assessmentcommon.result.PageResult;
import com.ruida.assessment.assessmentcommon.result.PojoResult;
import com.ruida.assessment.assessmentquestionbank.annotaion.UserAuth;
import com.ruida.assessment.assessmentquestionbank.dto.QuestionInfoDTO;
import com.ruida.assessment.assessmentquestionbank.dto.QuestionOperationDTO;
import com.ruida.assessment.assessmentquestionbank.dto.QuestionQueryDTO;
import com.ruida.assessment.assessmentquestionbank.service.QuestionService;
import com.ruida.assessment.assessmentquestionbank.vo.QuestionInfoVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

/**
 * @description: 试题控制层
 * @author: kgz
 * @date: 2020/6/8
 */
@RequestMapping("/question")
@RestController
@Api(value ="试题相关接口")
public class QuestionController {

    private static final String COLUMN_ID = "questionId";

    @Resource
    private QuestionService questionService;

    @UserAuth
    @PostMapping("/save")
    @ApiOperation(value = "保存单个试题信息", notes = "保存单个试题信息")
    @ApiImplicitParam(name = "questionInfo", value = "单个试题信息",
            required = true , dataType  = "QuestionInfo",paramType = "body")
    public MapResult save(@RequestBody QuestionInfoDTO questionInfoDTO){
/*        MapResult mapResult = new MapResult();
        mapResult.add(COLUMN_ID, questionService.saveQuestion(questionInfoDTO));*/
        return questionService.saveQuestion(questionInfoDTO);
    }

    @UserAuth
    @PostMapping("/operation")
    public MapResult operation(@RequestBody QuestionOperationDTO questionOperationDTO){
/*        MapResult mapResult = new MapResult();
        questionService.operationQuestions(questionOperationDTO);
        mapResult.add(COLUMN_ID, questionOperationDTO.getQuestionId());*/
        return questionService.operationQuestions(questionOperationDTO);
    }

    @UserAuth
    @GetMapping("/getDetail/{id}")
    public PojoResult getDetail(@PathVariable String id){
        PojoResult pojoResult = new PojoResult();
        QuestionInfoVO questionDetail = questionService.getQuestionDetail(id);
        pojoResult.setContent(questionDetail);
        return pojoResult;
    }

    @UserAuth
    @PostMapping("/getList")
    @ApiOperation(value = "分页查询试题列表", notes = "分页查询试题列表")
    @ApiImplicitParam(name = "questionQueryDTO", value = "试题查询条件",
            required = false , dataType  = "QuestionQueryDTO",paramType = "body")
    public PageResult<QuestionInfoVO> getList(@RequestBody QuestionQueryDTO questionQueryDTO){
        PageResult<QuestionInfoVO> pageResult = new PageResult();
        pageResult.setContent(questionService.getQuestionList(questionQueryDTO));
        return pageResult;
    }
}
