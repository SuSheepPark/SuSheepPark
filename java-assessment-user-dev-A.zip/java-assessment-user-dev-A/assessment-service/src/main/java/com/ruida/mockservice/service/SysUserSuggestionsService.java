package com.ruida.mockservice.service;


import com.baomidou.mybatisplus.service.IService;
import com.ruida.mockdao.model.SysUserSuggestions;

/**
 * <p>
 * 用户意见反馈关联表 服务类
 * </p>
 *
 * @author Bhj
 * @since 2020-07-15
 */
public interface SysUserSuggestionsService extends IService<SysUserSuggestions> {

    Boolean insertSysUserSuggestions(String content, String contactMethod, String imageUrl);
}
