package com.ruida.cloud.dao;

import com.ruida.cloud.model.TStudyCoinRecord;
import com.ruida.cloud.model.TStudyCoinRecordExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface TStudyCoinRecordMapper {
    int countByExample(TStudyCoinRecordExample example);

    int deleteByExample(TStudyCoinRecordExample example);

    int deleteByPrimaryKey(Integer studyCoinRecordId);

    int insert(TStudyCoinRecord record);

    int insertSelective(TStudyCoinRecord record);

    List<TStudyCoinRecord> selectByExample(TStudyCoinRecordExample example);

    TStudyCoinRecord selectByPrimaryKey(Integer studyCoinRecordId);

    int updateByExampleSelective(@Param("record") TStudyCoinRecord record, @Param("example") TStudyCoinRecordExample example);

    int updateByExample(@Param("record") TStudyCoinRecord record, @Param("example") TStudyCoinRecordExample example);

    int updateByPrimaryKeySelective(TStudyCoinRecord record);

    int updateByPrimaryKey(TStudyCoinRecord record);

}