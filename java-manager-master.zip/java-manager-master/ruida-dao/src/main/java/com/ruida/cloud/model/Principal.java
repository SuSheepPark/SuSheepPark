package com.ruida.cloud.model;

public class Principal {
}
