package com.ruida.assessment.assessmentcommon.result;

/**
 * 基于MapResult进行了扩展，主要出发点是返回值会相对复杂，针对单一情况设计的返回值不够使用 提供了一套不同的api流程，操作起来更简洁
 * 
 * @author mazhuang
 *
 */
public class ResultApi2 extends MapResult<String, Object> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Page<?> page;

	public static ResultApi2 success() {
		ResultApi2 resultApi2 = new ResultApi2();
		resultApi2.setSuccess(true);
		resultApi2.setCode(0);
		return resultApi2;
	}

	public static ResultApi2 fail(Integer code, String msg) {
		ResultApi2 resultApi2 = new ResultApi2();
		resultApi2.setSuccess(false);
		resultApi2.setCode(code);
		resultApi2.setMsg(msg);
		return resultApi2;
	}

	public ResultApi2 page(Page<?> page) {
		this.page = page;
		return this;
	}

	public Page<?> getPage() {
		return page;
	}
}
