package com.ruida.mockdao.dao;


import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.model.ReportStudent;

/**
 * @description: 学生个人报告数据库层接口
 * @author: kgz
 * @date: 2021/5/14
 */
public interface ReportStudentMapper extends BaseMapper<ReportStudent> {
}
