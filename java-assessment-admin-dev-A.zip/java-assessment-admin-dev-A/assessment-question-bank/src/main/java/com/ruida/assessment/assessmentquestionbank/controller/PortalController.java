package com.ruida.assessment.assessmentquestionbank.controller;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RequestMapping("/portal")
@RestController
public class PortalController {

    @RequestMapping("/getName/{id}")
    public String getName(@PathVariable Integer id){
        return "zhangsan";
    }
}
