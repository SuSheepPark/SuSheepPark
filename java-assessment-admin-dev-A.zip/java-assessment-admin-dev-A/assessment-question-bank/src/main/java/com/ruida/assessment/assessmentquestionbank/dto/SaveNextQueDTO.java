package com.ruida.assessment.assessmentquestionbank.dto;

import lombok.Data;

@Data
public class SaveNextQueDTO {
   private String originId;
    private String nextId;
    private Integer testPaperId;
}
