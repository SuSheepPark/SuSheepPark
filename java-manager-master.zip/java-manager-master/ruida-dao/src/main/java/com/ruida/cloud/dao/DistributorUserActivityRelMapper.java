package com.ruida.cloud.dao;

import com.ruida.cloud.model.DistributorUserActivityRel;
import com.ruida.cloud.model.DistributorUserActivityRelExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface DistributorUserActivityRelMapper {
    long countByExample(DistributorUserActivityRelExample example);

    int deleteByExample(DistributorUserActivityRelExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(DistributorUserActivityRel record);

    int insertSelective(DistributorUserActivityRel record);

    List<DistributorUserActivityRel> selectByExample(DistributorUserActivityRelExample example);

    DistributorUserActivityRel selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") DistributorUserActivityRel record, @Param("example") DistributorUserActivityRelExample example);

    int updateByExample(@Param("record") DistributorUserActivityRel record, @Param("example") DistributorUserActivityRelExample example);

    int updateByPrimaryKeySelective(DistributorUserActivityRel record);

    int updateByPrimaryKey(DistributorUserActivityRel record);
}