package com.ruida.mockcommon.enums;

import lombok.Getter;

/**
 * @author chenjy
 * @since 2021/3/5 9:55
 */
@Getter
public enum ReportTypeEnum {
    /**
     * 个人成绩报告
     */
    PERSONAL(1,"个人成绩报告"),

    /**
     * 9+1个人报告
     */
    NINE(2,"9+1个人报告"),

    /**
     * 初中联考报告
     */
    UNION(3,"初中联考报告"),
	/**
     * 初中联考报告
     */
    NINEINTERVAL1(4,"9+1个人报告(1分1赋)"),
    /**
     * 初中联考报告
     */
    NINE2(5,"9+1个人报告(必考科目)"),

    /**
     * 9+1个人报告
     */
    NINE_PERSONAL(7,"9+1个人报告"),

    /**
     * 初中联考报告
     */
    UNION_PERSONAL(9,"初中联考报告"),
    /**
     * 初中联考报告
     */
    NINEINTERVAL1_PERSONAL(6,"9+1个人报告(1分1赋)"),
    /**
     * 初中联考报告
     */
    NINE2_PERSONAL(8,"9+1联考报告（必考科目）");

    private final int id;

    private final String name;

    ReportTypeEnum(int id, String name) {
        this.id = id;
        this.name = name;
    }

    public static ReportTypeEnum getTypeById(int id){
        for(ReportTypeEnum item:ReportTypeEnum.values()){
            if (item.getId() == id){
                return item;
            }
        }
        return null;
    }
}
