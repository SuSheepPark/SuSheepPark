package com.ruida.cloud.dao;

import com.ruida.cloud.model.StartPage;
import com.ruida.cloud.model.StartPageExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface StartPageMapper {
    int countByExample(StartPageExample example);

    int deleteByExample(StartPageExample example);

    int deleteByPrimaryKey(Integer startPageId);

    int insert(StartPage record);

    int insertSelective(StartPage record);

    List<StartPage> selectByExample(StartPageExample example);

    StartPage selectByPrimaryKey(Integer startPageId);

    int updateByExampleSelective(@Param("record") StartPage record, @Param("example") StartPageExample example);

    int updateByExample(@Param("record") StartPage record, @Param("example") StartPageExample example);

    int updateByPrimaryKeySelective(StartPage record);

    int updateByPrimaryKey(StartPage record);
}