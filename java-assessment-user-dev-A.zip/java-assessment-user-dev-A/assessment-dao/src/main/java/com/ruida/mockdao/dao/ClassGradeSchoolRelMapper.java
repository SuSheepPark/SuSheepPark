package com.ruida.mockdao.dao;


import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.model.ClassGradeSchoolRel;

/**
 * <p>
 * 班级与年级与学校关联表（班级、年级、学校） Mapper 接口
 * </p>
 *
 * @author Bhj
 * @since 2020-07-21
 */
public interface ClassGradeSchoolRelMapper extends BaseMapper<ClassGradeSchoolRel> {

}
