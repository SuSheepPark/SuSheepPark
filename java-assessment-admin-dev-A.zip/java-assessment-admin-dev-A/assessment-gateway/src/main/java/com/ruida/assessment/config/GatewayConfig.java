package com.ruida.assessment.config;

import com.ruida.assessment.filters.CheckGlobalFilter;
import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

//@Configuration
public class GatewayConfig {
//    @Bean
//    public RouteLocator customerRoute(RouteLocatorBuilder routeLocatorBuilder){
//        return  routeLocatorBuilder.routes().route(item->item.path("/**")
//                .filters(f->f.filter()).uri("").id("")).build();
//    }

}
