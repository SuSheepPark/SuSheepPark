package com.ruida.assessment.assessmentquestionbank.dto;

import io.swagger.models.auth.In;
import lombok.Data;

/**
 * @author wy
 * @description 新增知识点请求参数
 * @date 2020/6/10
 */
@Data
public class KnowledgeRequest {

    /*当前选中的知识点的id*/
    private Integer id;

    /*前选中的知识点的父节点id*/
    private Integer pid;

    /*当前选中的知识点的排序值*/
    private Integer sort;

    /*知识点名称*/
    private String knowledgeName;

    /*新增类型 1-同级 2-子级 3-父级 */
    private Integer type;

    /*学段id*/
    private Integer periodId;

    /*学段名称*/
    private String periodName;

    /*科目id*/
    private Integer subjectId;

    /*科目名称*/
    private String subjectName;

    /*考点id*/
    private Integer examplaceId;

    /*考点名称*/
    private String examplaceName;


}
