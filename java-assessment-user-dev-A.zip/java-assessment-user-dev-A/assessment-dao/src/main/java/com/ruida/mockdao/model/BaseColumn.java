package com.ruida.mockdao.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * @author wy
 * @description
 * @date 2020/6/10
 */
@Data
public class BaseColumn {

    @ApiModelProperty(value = "创建者id", name = "createBy", required = true)
    private Integer createBy;

    @ApiModelProperty(value = "创建时间", name = "createTime", required = true)
    private Date createTime;

    @ApiModelProperty(value = "更新者id", name = "updateBy", required = false)
    private Integer updateBy;

    @ApiModelProperty(value = "更新时间", name = "updateTime", required = false)
    private Date updateTime;

    @ApiModelProperty(value = "是否删除（0-未删除；1-删除）", name = "isdelete", required = false)
    private Integer isdelete;

    /**
     * 设置新增操作的相关信息，比如时间等
     */
    public void setBaseForAdd() {
        Date date = new Date();
        this.setUpdateTime(date);
        this.setCreateTime(date);
    }

    /**
     * 设置更新操作的相关信息，比如时间等
     */
    public void setBaseForUpdate() {
        this.setUpdateTime(new Date());
    }
}
