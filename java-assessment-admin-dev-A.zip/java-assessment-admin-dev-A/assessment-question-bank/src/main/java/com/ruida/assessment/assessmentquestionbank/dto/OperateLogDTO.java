package com.ruida.assessment.assessmentquestionbank.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * @description: 操作日志DTO
 * @author: kgz
 * @date: 2020/8/18
 */
@ApiModel(description = "操作日志查询条件")
public class OperateLogDTO extends QueryBaseDTO{

    @ApiModelProperty(value = "开始时间", name = "startTime")
    private String startTime;

    @ApiModelProperty(value = "结束时间", name = "endTime")
    private String endTime;

    @ApiModelProperty(value = "操作模块", name = "module")
    private String module;

    @ApiModelProperty(value = "关键字，操作人账号、操作人姓名", name = "keyWords")
    private String keyWords;

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public String getModule() {
        return module;
    }

    public void setModule(String module) {
        this.module = module;
    }

    public String getKeyWords() {
        return keyWords;
    }

    public void setKeyWords(String keyWords) {
        this.keyWords = keyWords;
    }

    @Override
    public String toString() {
        return "OperateLogDTO{" +
                "startTime='" + startTime + '\'' +
                ", endTime='" + endTime + '\'' +
                ", module='" + module + '\'' +
                ", keyWords='" + keyWords + '\'' +
                '}';
    }
}
