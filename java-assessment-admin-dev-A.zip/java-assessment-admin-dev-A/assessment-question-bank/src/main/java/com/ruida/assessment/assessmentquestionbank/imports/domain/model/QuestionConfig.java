package com.ruida.assessment.assessmentquestionbank.imports.domain.model;

public class QuestionConfig extends QuestionBaseConfig{

//	private String questionType;
	private String difficulty;
	private String publicLevel;
	private String score;
	private String source;
	private String use;
	private String length;
//	private String uploadPhoto;
//	private String autoCorrection;
	
//	public String getQuestionType() {
//		return questionType;
//	}
//	public void setQuestionType(String questionType) {
//		this.questionType = questionType;
//	}
	public String getPublicLevel() {
		return publicLevel;
	}
	public void setPublicLevel(String publicLevel) {
		this.publicLevel = publicLevel;
	}
	public String getScore() {
		return score;
	}
	public void setScore(String score) {
		this.score = score;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getUse() {
		return use;
	}
	public void setUse(String use) {
		this.use = use;
	}
	public String getLength() {
		return length;
	}
	public void setLength(String length) {
		this.length = length;
	}
	public String getDifficulty() {
		return difficulty;
	}
	public void setDifficulty(String difficulty) {
		this.difficulty = difficulty;
	}
//	public String getUploadPhoto() {
//		return uploadPhoto;
//	}
//	public void setUploadPhoto(String uploadPhoto) {
//		this.uploadPhoto = uploadPhoto;
//	}
//	public String getAutoCorrection() {
//		return autoCorrection;
//	}
//	public void setAutoCorrection(String autoCorrection) {
//		this.autoCorrection = autoCorrection;
//	}
}
