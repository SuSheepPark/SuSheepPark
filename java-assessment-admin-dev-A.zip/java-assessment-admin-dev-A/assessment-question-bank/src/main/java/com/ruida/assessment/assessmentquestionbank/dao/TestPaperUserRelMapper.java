package com.ruida.assessment.assessmentquestionbank.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.assessment.assessmentquestionbank.model.TTestPaperUserRel;

/**
 * @description: 试卷-用户 关联dao层接口
 * @author: wy
 * @date: 2020/8/11
 */
@Mapper
public interface TestPaperUserRelMapper extends BaseMapper<TTestPaperUserRel> {

	void insertBatchBySQL(List<TTestPaperUserRel> rels);
}
