package com.ruida.assessment.assessmentquestionbank.service;

import com.baomidou.mybatisplus.service.IService;
import com.ruida.assessment.assessmentquestionbank.model.SysConfig;

/**
 * Created by xumingqi on 2021/5/11 11:40
 */
public interface ISysConfigService extends IService<SysConfig> {
    String getValueByKey(String key);

    Boolean updateValueByKey(String key, String value, Integer userId);
}
