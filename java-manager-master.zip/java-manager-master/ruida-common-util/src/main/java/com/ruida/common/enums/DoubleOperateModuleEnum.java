package com.ruida.common.enums;


import java.util.ArrayList;
import java.util.List;

/**
 * @author wy
 * @description 双师操作业务类型 日志使用
 * @date 2021/6/8
 */
public enum DoubleOperateModuleEnum {

    ASSISTANT(1,"助教"),
    CLASS(2,"班级"),
    STUDENT(3,"学生"),
    COURSE(4,"课程"),
    COURSE_LESSON(5,"课次"),
    CLASS_STU_ASS(6,"班级&学生&助教"),
    ;

    private Integer id;
    private String module;

    DoubleOperateModuleEnum(Integer id, String module) {
        this.id = id;
        this.module = module;
    }

    public static List<String> getModules() {
        List<String> moduleList = new ArrayList<>();
        for (DoubleOperateModuleEnum doubleOperateModuleEnum : DoubleOperateModuleEnum.values()){
            moduleList.add(doubleOperateModuleEnum.getModule());
        }
        return moduleList;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getModule() {
        return module;
    }

    public void setModule(String module) {
        this.module = module;
    }
}
