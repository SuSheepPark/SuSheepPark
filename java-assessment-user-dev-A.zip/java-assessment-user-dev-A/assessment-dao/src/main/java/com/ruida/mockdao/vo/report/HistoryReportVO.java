package com.ruida.mockdao.vo.report;

import com.ruida.mockdao.vo.KnowledgeStatVO;
import com.ruida.mockdao.vo.KnowledgeVO;
import com.ruida.mockdao.vo.TargetStatVO;
import lombok.Data;

import java.util.List;
import java.util.Map;

/**
 * @description: 历次测评报告VO
 * @author: kgz
 * @date: 2020/10/9
 */
@Data
public class HistoryReportVO {

    /**
     * 历次测试得分情况
     */
    private List<ReportVO> reportList;

    /**
     * 一级知识点基本信息
     */
    private List<KnowledgeVO> firstKnowledgeList;

    /**
     * 二级知识点基本信息
     */
    private List<KnowledgeVO> secondKnowledgeList;

    /**
     * 考核目标
     */
    private List<TargetStatVO> targetList;

}
