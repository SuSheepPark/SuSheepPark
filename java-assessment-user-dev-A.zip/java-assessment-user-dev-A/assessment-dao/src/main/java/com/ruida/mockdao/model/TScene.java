package com.ruida.mockdao.model;

import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 场次表
 * </p>
 *
 * @author szl
 * @since 2021-07-22
 */
@TableName("t_scene")
public class TScene extends Model<TScene> {

    private static final long serialVersionUID = 1L;

    /**
     * 场次id
     */
    @TableId(value = "scene_id", type = IdType.UUID)
    private String sceneId;
    /**
     * 场次名字
     */
    @TableField("scene_name")
    private String sceneName;
    /**
     * 实施计划id
     */
    @TableField("plan_id")
    private String planId;
    /**
     * 试卷id
     */
    @TableField("test_paper_id")
    private Integer testPaperId;
    /**
     * 实施规则
     */
    @TableField("rule_id")
    private String ruleId;
    /**
     * 考试人数
     */
    @TableField("exam_count")
    private Integer examCount;
    /**
     * 考试地点
     */
    @TableField("exam_address")
    private String examAddress;
    /**
     * 登录方式
     */
    @TableField("login_type")
    private Integer loginType;
    /**
     * 监考信息
     */
    @TableField("invigilation_info")
    private String invigilationInfo;
    /**
     * 开始时间
     */
    @TableField("start_time")
    private Date startTime;
    /**
     * 结束时间
     */
    @TableField("end_time")
    private Date endTime;
    /**
     * 创建时间
     */
    @TableField("create_time")
    private Date createTime;
    /**
     * 创建人id
     */
    @TableField("create_by")
    private Integer createBy;
    /**
     * 更新时间
     */
    @TableField("update_time")
    private Date updateTime;
    /**
     * 更新人id
     */
    @TableField("update_by")
    private Integer updateBy;
    /**
     * 逻辑删除（0 存在， 1 已删除）
     */
    private Integer isdelete;
    /**
     * 考试时长（单位：分钟）
     */
    private Integer duration;
    /**
     * 答题方式(1-在线答题 2-纸面答题
     */
    @TableField("answer_way")
    private Integer answerWay;
    /**
     * 阅卷方式(1-自动批阅 2-后台批阅 3-自主批阅)，多个用英文逗号分隔
     */
    @TableField("correctWay")
    private String correctWay;
    /**
     * 科目id
     */
    @TableField("subject_id")
    private Integer subjectId;
    /**
     * 考生须知存放路径
     */
    @TableField("attention_path")
    private String attentionPath;
    /**
     * 是否有迟到限制（0-没有；1-有）
     */
    @TableField("allow_late")
    private Integer allowLate;
    /**
     * 科目
     */
    @TableField("subject_name")
    private String subjectName;
    /**
     * 学校ids
     */
    @TableField("school_ids")
    private String schoolIds;
    /**
     * 学校名字
     */
    @TableField("school_names")
    private String schoolNames;
    /**
     * 场次状态（0-未发布；1-未开始；2-进行中；3-已结束；）
     */
    private Integer status;


    public String getSceneId() {
        return sceneId;
    }

    public void setSceneId(String sceneId) {
        this.sceneId = sceneId;
    }

    public String getPlanId() {
        return planId;
    }

    public void setPlanId(String planId) {
        this.planId = planId;
    }

    public Integer getTestPaperId() {
        return testPaperId;
    }

    public void setTestPaperId(Integer testPaperId) {
        this.testPaperId = testPaperId;
    }

    public String getRuleId() {
        return ruleId;
    }

    public void setRuleId(String ruleId) {
        this.ruleId = ruleId;
    }

    public Integer getExamCount() {
        return examCount;
    }

    public void setExamCount(Integer examCount) {
        this.examCount = examCount;
    }

    public String getExamAddress() {
        return examAddress;
    }

    public void setExamAddress(String examAddress) {
        this.examAddress = examAddress;
    }

    public Integer getLoginType() {
        return loginType;
    }

    public void setLoginType(Integer loginType) {
        this.loginType = loginType;
    }

    public String getInvigilationInfo() {
        return invigilationInfo;
    }

    public void setInvigilationInfo(String invigilationInfo) {
        this.invigilationInfo = invigilationInfo;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getCreateBy() {
        return createBy;
    }

    public void setCreateBy(Integer createBy) {
        this.createBy = createBy;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(Integer updateBy) {
        this.updateBy = updateBy;
    }

    public Integer getIsdelete() {
        return isdelete;
    }

    public void setIsdelete(Integer isdelete) {
        this.isdelete = isdelete;
    }

    public String getSceneName() {
        return sceneName;
    }

    public void setSceneName(String sceneName) {
        this.sceneName = sceneName;
    }

    public Integer getDuration() {
        return duration;
    }

    public void setDuration(Integer duration) {
        this.duration = duration;
    }

    public Integer getAnswerWay() {
        return answerWay;
    }

    public void setAnswerWay(Integer answerWay) {
        this.answerWay = answerWay;
    }

    public String getCorrectWay() {
        return correctWay;
    }

    public void setCorrectWay(String correctWay) {
        this.correctWay = correctWay;
    }

    public Integer getSubjectId() {
        return subjectId;
    }

    public void setSubjectId(Integer subjectId) {
        this.subjectId = subjectId;
    }

    public String getAttentionPath() {
        return attentionPath;
    }

    public void setAttentionPath(String attentionPath) {
        this.attentionPath = attentionPath;
    }

    public Integer getAllowLate() {
        return allowLate;
    }

    public void setAllowLate(Integer allowLate) {
        this.allowLate = allowLate;
    }

    public String getSubjectName() {
        return subjectName;
    }

    public void setSubjectName(String subjectName) {
        this.subjectName = subjectName;
    }

    public String getSchoolIds() {
        return schoolIds;
    }

    public void setSchoolIds(String schoolIds) {
        this.schoolIds = schoolIds;
    }

    public String getSchoolNames() {
        return schoolNames;
    }

    public void setSchoolNames(String schoolNames) {
        this.schoolNames = schoolNames;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    @Override
    protected Serializable pkVal() {
        return this.sceneId;
    }

    @Override
    public String toString() {
        return "TScene{" +
                ", sceneId=" + sceneId +
                ", planId=" + planId +
                ", testPaperId=" + testPaperId +
                ", ruleId=" + ruleId +
                ", examCount=" + examCount +
                ", examAddress=" + examAddress +
                ", loginType=" + loginType +
                ", invigilationInfo=" + invigilationInfo +
                ", startTime=" + startTime +
                ", endTime=" + endTime +
                ", createTime=" + createTime +
                ", createBy=" + createBy +
                ", updateTime=" + updateTime +
                ", updateBy=" + updateBy +
                ", isdelete=" + isdelete +
                "}";
    }
}
