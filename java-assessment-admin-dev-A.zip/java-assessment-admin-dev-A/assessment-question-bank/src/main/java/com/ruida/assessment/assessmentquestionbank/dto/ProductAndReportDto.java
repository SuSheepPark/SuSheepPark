package com.ruida.assessment.assessmentquestionbank.dto;

import lombok.Data;

/**
 * @author wy
 * @description 赠送商品列表DTO
 * @date 2020/7/24
 */
@Data
public class ProductAndReportDto {

    private Integer productId;

    private Integer isPresentReport;//是否赠送报告 0-否 1-是

}
