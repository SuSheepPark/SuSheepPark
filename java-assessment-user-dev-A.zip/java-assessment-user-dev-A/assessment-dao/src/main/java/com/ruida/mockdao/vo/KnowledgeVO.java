package com.ruida.mockdao.vo;

import lombok.Data;

/**
 * @description: 知识点VO
 * @author: chenjy
 * @create: 2020-07-24 09:20
 */
@Data
public class KnowledgeVO {

    /**
     * 知识点id
     */
    private int knowledgeId;

    /**
     * 知识点名称
     */
    private String knowledgeName;
}
