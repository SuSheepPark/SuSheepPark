package com.ruida.mockdao.vo.report;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;

/**
 * @description: 年级得分情况VO
 * @author: kgz
 * @date: 2020/12/24
 */
@ApiModel(description = "年级得分情况VO")
public class StageScoreVO implements Serializable {

    @ApiModelProperty(value = "年级名称", name = "stageName")
    private String stageName;

    @ApiModelProperty(value = "得分", name = "score")
    private Double score;

    @ApiModelProperty(value = "满分", name = "totalScore")
    private Double totalScore;

    public String getStageName() {
        return stageName;
    }

    public void setStageName(String stageName) {
        this.stageName = stageName;
    }

    public Double getScore() {
        return score;
    }

    public void setScore(Double score) {
        this.score = score;
    }

    public Double getTotalScore() {
        return totalScore;
    }

    public void setTotalScore(Double totalScore) {
        this.totalScore = totalScore;
    }
}
