package com.ruida.common.util;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.poi.ss.formula.functions.T;

import java.lang.reflect.Field;
import java.util.*;

public class CollectionMT
{
	/**
	 * @param <T>
	 * @param list
	 * @param key
	 * @param value
	 * @return 返回第一个满足条件的数据
	 */
	public static <T>T searchByField(Collection<T> list,String key,Object value){
		for(T o : list){
			try {
	            Object v = BeanUtils.getProperty(o, key);
	            if(value.equals(v)){
	            	return o;
	            }
            } catch (Exception e) {
	            e.printStackTrace();
            } 
		}
		return null;
	}
	 
	
	/**
	 * @param <T>
	 * @param list
	 * @param key
	 * @param value
	 * @return 返回所有满足条件的数据
	 */
	public static <T>List<T> searchListByField(Collection<T> list,String key,Object value){
		List<T> res = new ArrayList<T>();
		
		for(T o : list){
			try {
	            Object v = BeanUtils.getProperty(o, key);
	            if(value.equals(v)){
	            	res.add(o);
	            }
            } catch (Exception e) {
	            e.printStackTrace();
            } 
		}
		return res;
	}
	
	/**
	 * list转成map
	 * @param <T>
	 * @param list
	 * @param key list属性值
	 * @return
	 */
	public static <T> Map<String,T> list2Map(Collection<T> list,String key){
		Map<String,T> res = new HashMap<String, T>();
		for(T o : list){
			try {
	            Object v = BeanUtils.getProperty(o, key);
	            if(v != null){
	            	res.put(v.toString(), o);
	            }
            } catch (Exception e) {
	            e.printStackTrace();
            } 
		}
		
		return res;
	}
	

	public static Map<String,String> list2Map(Collection<?> list,String key,String value){
		Map<String,String> res = new HashMap<String, String>();
		for(Object o : list){
			try {
	            Object v = BeanUtils.getProperty(o, key);
	            if(v != null){
	            	res.put(v.toString(), BeanUtils.getProperty(o, value).toString());
	            }
            } catch (Exception e) {
	            e.printStackTrace();
            } 
		}
		
		return res;
	}
	
	/**
	 * 保留排序
	 * @param <T>
	 * @param list
	 * @param key
	 * @return
	 */
	public static <T> Map<String,T> list2Map4Sort(Collection<T> list,String key){
		Map<String,T> res = new LinkedHashMap<String, T>();
		for(T o : list){
			try {
	            Object v = BeanUtils.getProperty(o, key);
	            if(v != null){
	            	res.put(v.toString(), o);
	            }
            } catch (Exception e) {
	            e.printStackTrace();
            } 
		}
		
		return res;
	}
	

	public static Map<String,String> list2Map4Sort(Collection<?> list,String key,String value){
		Map<String,String> res = new LinkedHashMap<String, String>();
		for(Object o : list){
			try {
	            Object v = BeanUtils.getProperty(o, key);
	            if(v != null){
	            	res.put(v.toString(), BeanUtils.getProperty(o, value).toString());
	            }
            } catch (Exception e) {
	            e.printStackTrace();
            } 
		}
		
		return res;
	}

	public static List<Integer> string2intList(String str,String split)
	{
		String[] arr = str.split(split);
		if(str != null && arr.length > 0)
		{
			List<Integer> idList = new ArrayList<>();
			for(String s : arr)
			{
				if(NumberUtils.isNumber(s))
				{
					idList.add(NumberUtils.toInt(s));
				}
			}
			return idList;
		}
		return Collections.EMPTY_LIST;
	}

	public static <T> List<T> transform2List(Object obj){
		if(obj instanceof Collection<?>){
			return (List<T>) obj;
		} else{
			return Collections.emptyList();
		}
	}

	/**
	 * 利用反射实体对象转成Map
	 * @param obj
	 * @return
	 */
	public static Map<String, String> FormToMap(Object obj) {
		Map<String, String> map = new HashMap<>();
		if (obj == null) {
			return map;
		}
		Class clazz = obj.getClass();
		Field[] fields = clazz.getDeclaredFields();
		try {
			for (Field field : fields) {
				field.setAccessible(true);
				map.put(field.getName(),String.valueOf(field.get(obj)) );
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return map;
	}

	/**
	 * 找出两个数组中相同的元素
	 * @param a
	 * @param b
	 * @return
	 */
	public static Set<T> getIds(T[] a, T[] b){

		//用来存放两个数组中相同的元素
		Set<T> same = new HashSet<T>();
		//用来存放数组a中的元素
		Set<T> temp = new HashSet<T>();

		for (int i = 0; i < a.length; i++) {
			//把数组a中的元素放到Set中，可以去除重复的元素
			temp.add(a[i]);
		}

		for (int j = 0; j < b.length; j++) {
			//把数组b中的元素添加到temp中
			//如果temp中已存在相同的元素，则temp.add（b[j]）返回false
			if(!temp.add(b[j])) {
				same.add(b[j]);
			}
		}
		return same;
	}

	/**
	 * 找出第二个数组中不相同的元素（与第一个比较）
	 * @param t1
	 * @param t2
	 * @param <T>
	 * @return
	 */
	public static <T> List<T> compare(T[] t1, T[] t2) {
		List<T> list1 = Arrays.asList(t1);
		List<T> list2 = new ArrayList<T>();
		for (T t : t2) {
			if (!list1.contains(t)) {
				list2.add(t);
			}
		}
		return list2;
	}
}
