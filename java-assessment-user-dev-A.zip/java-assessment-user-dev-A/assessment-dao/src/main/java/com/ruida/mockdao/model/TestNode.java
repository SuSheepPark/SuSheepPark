package com.ruida.mockdao.model;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import lombok.Data;

import java.io.Serializable;

/**
 * Created by xumingqi on 2021/7/21 17:45
 */
@Data
@TableName("t_test_node")
public class TestNode extends BaseColumn implements Serializable {
    /**
     * 小节id
     */
    @TableId
    private Integer nodeId;

    /**
     * 试卷名称
     */
    private String nodeTitle;

    /**
     * 试卷id
     */
    private Integer testPaperId;

    /**
     * 小节排序
     */
    private Integer sort;

    /**
     * 分值
     */
    private Double score;
}
