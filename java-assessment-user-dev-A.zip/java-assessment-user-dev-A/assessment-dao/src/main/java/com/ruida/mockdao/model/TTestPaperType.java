package com.ruida.mockdao.model;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;

import java.io.Serializable;

/**
 * @description: 试卷类型数据库实体
 * @author: kgz
 * @date: 2020/7/6
 */
@TableName("t_test_paper_type")
public class TTestPaperType implements Serializable {
    private static final long serialVersionUID = -7468293171534390762L;

    /**
     * 试卷类型id
     */
    @TableId
    private Integer id;

    /**
     * 试卷类型名称
     */
    private String name;

    /**
     * 状态（0—禁用；1—启用）
     */
    private Integer status;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "TTestPaperType{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", status=" + status +
                super.toString() +
                '}';
    }
}
