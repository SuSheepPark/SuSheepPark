package com.ruida.assessment.assessmentquestionbank.dto;

import lombok.Data;

import java.util.Date;

/**
 * @author xumingqi
 * @date 2021/1/18 11:17
 */
@Data
public class QuestionnaireStudentInfoDTO {
    String telephone;
    String stuNo;
    String stuAccount;
    String idCard;
    Integer userId;
    String stuName;
    Integer count;
    Date lastTime;
}
