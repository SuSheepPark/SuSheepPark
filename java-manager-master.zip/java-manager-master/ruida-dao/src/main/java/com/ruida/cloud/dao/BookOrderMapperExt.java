package com.ruida.cloud.dao;

import com.ruida.cloud.model.BookOrderExt;
import com.ruida.cloud.model.Order;
import com.ruida.cloud.model.OrderExt;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

/**
 * @author admin
 * @description: 图书订单模块统计
 * @Date 2019/1/21
 * @verion 1.0
 */
public interface BookOrderMapperExt extends OrderMapper{

    List<BookOrderExt> selectBookOrderByExample(Map condition);

    int countBookOrderByExample(Map condition);

    BookOrderExt selectBookOrderById(Map condition);

    List<BookOrderExt> selectBookOrderForExport(Map condition);

    Map totalBookOrderByExample(Map condition);
}
