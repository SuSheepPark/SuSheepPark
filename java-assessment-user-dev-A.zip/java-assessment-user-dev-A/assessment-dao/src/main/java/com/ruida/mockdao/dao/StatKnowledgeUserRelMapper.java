package com.ruida.mockdao.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.model.StatKnowledgeUserRel;
import com.ruida.mockdao.vo.KnowledgeStatVO;
import com.ruida.mockdao.vo.TargetStatVO;
import com.ruida.mockdao.vo.report.ReportRank;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * <p>
 * 知识点用户统计表 Mapper 接口
 * </p>
 *
 * @author jinhu
 * @since 2020-08-11
 */
public interface StatKnowledgeUserRelMapper extends BaseMapper<StatKnowledgeUserRel> {


    @Select(" SELECT " +
            " a.user_id,a.exam_record_id,a.knowledge_id,a.knowledge_name,a.full_score,a.real_score, b.pid" +
            " FROM " +
            " stat_knowledge_user_rel a" +
            " LEFT JOIN t_knowledge b ON a.knowledge_id = b.knowledge_id" +
            " WHERE" +
            " a.user_id = #{userId}" +
            " AND exam_record_id = #{examRecordId}" +
            " AND a.isdelete = 0" +
            " ORDER BY" +
            " b.sort ")
    List<KnowledgeStatVO> queryUserScoreByKnowledge(@Param("userId") String userId, @Param("examRecordId") Integer examRecordId);


    @Select(" select a.knowledge_id, SUM(a.full_score) full_score_class,SUM(a.real_score) real_score_class " +
            " from stat_knowledge_user_rel a" +
            " left join t_student_rel_info b on a.stu_id = b.student_id and b.status = 1 " +
            " left join t_exam_record c on a.exam_record_id = c.id" +
            " where b.class_id = #{classId} and c.test_paper_id = #{testPaperId} and a.isdelete = 0" +
            " and c.product_id = #{productId}" +
            " GROUP BY a.knowledge_id")
    List<KnowledgeStatVO> queryClassScoreByKnowledge(@Param("productId") Integer productId, @Param("classId") Integer classId, @Param("testPaperId") Integer testPaperId);

    @Select(" select a.knowledge_id, SUM(a.full_score) full_score_union,SUM(a.real_score) real_score_union " +
            " from stat_knowledge_user_rel a" +
            " left join t_student_rel_info b on a.stu_id = b.student_id and b.status = 1 " +
            " left join t_exam_record c on a.exam_record_id = c.id" +
            " where c.test_paper_id = #{testPaperId} and a.isdelete = 0" +
            " and c.product_id = #{productId}" +
            " GROUP BY a.knowledge_id")
    List<KnowledgeStatVO> queryUnionScoreByKnowledge(@Param("productId") Integer productId, @Param("testPaperId") Integer testPaperId);

    @Select(" select a.knowledge_id, SUM(a.full_score) full_score_school, SUM(a.real_score) real_score_school " +
            " from stat_knowledge_user_rel a " +
            " inner join t_student_rel_info b on a.stu_id = b.student_id and a.isdelete = 0 and b.status = 1 " +
            " inner join t_exam_record c on c.times = 1 AND c.isdelete=0 and a.exam_record_id = c.id and c.product_id = #{productId} and c.test_paper_id = #{testPaperId} and c.test_way = #{testWay} " +
            " INNER JOIN t_school s on s.school_id = b.school_id " +
            " INNER JOIN t_school_nine_one n on n.school_name = s.school_name " +
            " GROUP BY a.knowledge_id ")
    List<KnowledgeStatVO> queryNineOneSchoolScoreByKnowledge(@Param("productId") Integer productId, @Param("testWay") Integer testWay, @Param("testPaperId") Integer testPaperId);

    @Select(" SELECT " +
            " count(*) " +
            " FROM " +
            " stat_knowledge_user_rel a " +
            " LEFT JOIN t_student_rel_info b ON a.stu_id = b.student_id and b.status = 1 " +
            " left join t_exam_record c on a.exam_record_id = c.id" +
            " WHERE " +
            " b.class_id = #{classId} " +
            " AND c.product_id = #{productId}" +
            " AND c.test_paper_id = #{testPaperId} " +
            " AND a.isdelete = 0 " +
            " AND a.knowledge_id = #{knowledgeId} " +
            " AND a.real_score > #{realScore}")
    int queryClassRank(@Param("productId") Integer productId, @Param("classId") Integer classId,@Param("testPaperId") Integer testPaperId,
                       @Param("knowledgeId") Integer knowledgeId,@Param("realScore") Double realScore);

    @Select(" select a.knowledge_id, SUM(a.full_score) full_score_school,SUM(a.real_score) real_score_school " +
            " from stat_knowledge_user_rel a" +
            " left join t_student_rel_info b on a.stu_id = b.student_id and b.status = 1 " +
            " left join t_exam_record c on a.exam_record_id = c.id " +
            " where c.times = 1 AND c.isdelete = 0 and b.school_id = #{schoolId} and c.test_paper_id = #{testPaperId} and a.isdelete = 0" +
            " and c.product_id = #{productId}" +
            " GROUP BY a.knowledge_id")
    List<KnowledgeStatVO> querySchoolScoreByKnowledge(@Param("productId") Integer productId, @Param("schoolId") Integer schoolId, @Param("testPaperId") Integer testPaperId);

    @Select(" SELECT " +
            " count(*) " +
            " FROM " +
            " stat_knowledge_user_rel a " +
            " LEFT JOIN t_student_rel_info b ON a.stu_id = b.student_id and b.status = 1 " +
            " left join t_exam_record c on a.exam_record_id = c.id" +
            " WHERE " +
            " b.school_id = #{schoolId} " +
            " AND c.product_id = #{productId}" +
            " AND c.test_paper_id = #{testPaperId} " +
            " AND a.isdelete = 0 " +
            " AND a.knowledge_id = #{knowledgeId} " +
            " AND a.real_score > #{realScore}")
    int querySchoolRank(@Param("productId") Integer productId, @Param("schoolId") Integer schoolId,@Param("testPaperId") Integer testPaperId,
                       @Param("knowledgeId") Integer knowledgeId,@Param("realScore") Double realScore);

    @Select(" SELECT " +
            " count(*) " +
            " FROM " +
            " stat_knowledge_user_rel a " +
            " LEFT JOIN t_student_rel_info b ON a.stu_id = b.student_id and b.status = 1 " +
            " left join t_exam_record c on a.exam_record_id = c.id" +
            " WHERE " +
            " c.product_id = #{productId}" +
            " AND c.test_paper_id = #{testPaperId} " +
            " AND a.isdelete = 0 " +
            " AND a.knowledge_id = #{knowledgeId} " +
            " AND a.real_score > #{realScore}")
    int queryUnionRank(@Param("productId") Integer productId,@Param("testPaperId") Integer testPaperId,
                        @Param("knowledgeId") Integer knowledgeId,@Param("realScore") Double realScore);

    @Select("SELECT " +
            "e.create_by as userId, " +
            "e.real_score score, " +
            "@rank_counter := @rank_counter + 1, " +
            "IF ( @pre_score = e.real_score, @cur_rank, @cur_rank := @rank_counter ) rank, " +
            "@pre_score := e.real_score " +
            "FROM ( " +
            "SELECT  " +
            "c.create_by,a.real_score " +
            "FROM stat_knowledge_user_rel a " +
            "LEFT JOIN t_student_rel_info b ON a.stu_id = b.student_id and b.status = 1 " +
            "LEFT JOIN t_exam_record c ON a.exam_record_id = c.id " +
            "WHERE c.times = 1 AND c.isdelete = 0 and b.school_id = #{schoolId} AND c.product_id = #{productId} AND c.test_paper_id = #{testPaperId} AND a.isdelete = 0 AND a.knowledge_id = #{knowledgeId} ) e, " +
            "(SELECT @cur_rank := 0, @pre_score := NULL, @rank_counter := 0 ) r " +
            "ORDER BY e.real_score DESC ")
    List<ReportRank> querySchoolKnowledgeRank(@Param("productId") Integer productId, @Param("schoolId") Integer schoolId, @Param("testPaperId") Integer testPaperId,
                                              @Param("knowledgeId") Integer knowledgeId);

    @Select(" SELECT " +
            " count(*) " +
            " FROM " +
            " stat_knowledge_user_rel a " +
            " INNER JOIN t_student_rel_info b ON a.stu_id = b.student_id and b.status = 1 " +
            " INNER JOIN t_school s on b.school_id = s.school_id " +
            " INNER JOIN t_school_nine_one n on n.school_name = s.school_name " +
            " INNER join t_exam_record c on a.exam_record_id = c.id and c.times = 1 " +
            " WHERE " +
            " c.test_paper_id = #{testPaperId} " +
            " AND a.isdelete = 0 " +
            " AND a.knowledge_id = #{knowledgeId} " +
            " AND c.product_id = #{productId} " +
            " and c.test_way = #{testWay} " +
            " AND a.real_score > #{realScore}" +
            " AND c.isdelete=0")
    int queryNineOneSchoolRank(@Param("productId") Integer productId, @Param("testWay") Integer testWay, @Param("testPaperId") Integer testPaperId,
                        @Param("knowledgeId") Integer knowledgeId,@Param("realScore") Double realScore);


    @Select(" SELECT " +
            " c.assessment_target_id target_id, " +
            " d.question_assessment_target_name target_name, " +
            " SUM(IFNULL(a.score, 0)) real_score, " +
            " SUM(IFNULL(b.score, 0)) full_score " +
            " from t_exam_detail a " +
            " left join t_test_node_question_rel b on a.question_id = b.question_id and a.test_paper_id = b.test_paper_id " +
            " left join t_question_library c on a.question_id = c.id   " +
            " left join t_question_assessment_target d on c.assessment_target_id = d.id " +
            " where exam_record_id = #{examRecordId} and c.assessment_target_id is not null " +
            " group by c.assessment_target_id, d.question_assessment_target_name")
    List<TargetStatVO> queryUserTargetStat( @Param("examRecordId") Integer examRecordId);

    @Select(" SELECT " +
            " c.assessment_target_id target_id,  " +
            " d.question_assessment_target_name target_name,  " +
            " SUM(IFNULL(a.score, 0)) real_score,  " +
            " SUM(IFNULL(b.score, 0)) full_score  " +
            " from t_exam_detail a " +
            " inner join t_exam_record g on a.exam_record_id = g.id and g.times = 1 " +
            " left join t_test_node_question_rel b on a.question_id = b.question_id and a.test_paper_id = b.test_paper_id " +
            " left join t_question_library c on a.question_id = c.id   " +
            " left join t_question_assessment_target d on c.assessment_target_id = d.id " +
            " left join t_student e on a.create_by = e.user_id " +
            " left join t_student_rel_info f on e.stu_id = f.student_id and f.status = 1 " +
            " where a.test_paper_id = #{testPaperId} and  c.assessment_target_id is not null  and f.class_id = #{classId} " +
            " and g.product_id = #{productId} " +
            " group by c.assessment_target_id, d.question_assessment_target_name")
    List<TargetStatVO> queryClassTargetStat(@Param("productId") Integer productId, @Param("testPaperId") Integer testPaperId, @Param("classId") Integer classId);

    @Select(" SELECT " +
            " c.assessment_target_id target_id,  " +
            " d.question_assessment_target_name target_name,  " +
            " SUM(IFNULL(a.score, 0)) real_score,  " +
            " SUM(IFNULL(b.score, 0)) full_score  " +
            " from t_exam_detail a " +
            " inner join t_exam_record g on a.exam_record_id = g.id and g.times = 1 " +
            " left join t_test_node_question_rel b on a.question_id = b.question_id and a.test_paper_id = b.test_paper_id " +
            " left join t_question_library c on a.question_id = c.id   " +
            " left join t_question_assessment_target d on c.assessment_target_id = d.id " +
            " left join t_student e on a.create_by = e.user_id " +
            " left join t_student_rel_info f on e.stu_id = f.student_id and f.status = 1 " +
            " where a.test_paper_id = #{testPaperId} and  c.assessment_target_id is not null  and f.school_id = #{schoolId} " +
            " and g.product_id = #{productId}" +
            " group by c.assessment_target_id, d.question_assessment_target_name")
    List<TargetStatVO> querySchoolTargetStat(@Param("productId") Integer productId, @Param("testPaperId") Integer testPaperId, @Param("schoolId") Integer schoolId);

    @Select(" SELECT " +
            " c.assessment_target_id target_id,  " +
            " d.question_assessment_target_name target_name,  " +
            " SUM(IFNULL(a.score, 0)) real_score, " +
            " SUM(IFNULL(b.score, 0)) full_score  " +
            " from t_exam_detail a " +
            " INNER JOIN t_exam_record g on a.exam_record_id = g.id and g.test_way = #{testWay} " +
            " INNER JOIN t_test_node_question_rel b on a.question_id = b.question_id and a.test_paper_id = b.test_paper_id " +
            " INNER JOIN t_question_library c on a.question_id = c.id   " +
            " INNER JOIN t_question_assessment_target d on c.assessment_target_id = d.id " +
            " INNER JOIN t_student e on a.create_by = e.user_id " +
            " INNER JOIN t_student_rel_info f on e.stu_id = f.student_id and f.status = 1 " +
            " INNER JOIN t_school s on s.school_id = f.school_id " +
            " INNER JOIN t_school_nine_one n on n.school_name = s.school_name " +
            " where a.test_paper_id = #{testPaperId} and c.assessment_target_id is not null and g.product_id= #{productId} " +
            " and c.assessment_target_id = #{targetId} ")
    TargetStatVO queryNineOneSchoolTargetStat(@Param("productId") Integer productId, @Param("testPaperId") Integer testPaperId,
                                              @Param("testWay") Integer testWay, @Param("targetId") Integer targetId,
                                              @Param("schoolId") Integer schoolId);

    @Select(" select " +
            " count(1) " +
            " from (" +
            "   SELECT" +
            "       c.assessment_target_id target_id, " +
            "       SUM(IFNULL(a.score, 0)) real_score " +
            "   from t_exam_detail a " +
            "   inner join t_exam_record g on a.exam_record_id = g.id and g.times = 1 " +
            "   left join t_test_node_question_rel b on a.question_id = b.question_id and a.test_paper_id = b.test_paper_id " +
            "   left join t_question_library c on a.question_id = c.id " +
            "   left join t_question_assessment_target d on c.assessment_target_id = d.id " +
            "   left join t_student e on a.create_by = e.user_id " +
            "   left join t_student_rel_info f on e.stu_id = f.student_id and f.status = 1 " +
            "   where a.test_paper_id = #{testPaperId} and c.assessment_target_id = #{assessmentTargetId} " +
            "   and f.school_id = #{schoolId} " +
            "   and g.product_id= #{productId} " +
            "   group by c.assessment_target_id, d.question_assessment_target_name " +
            " ) m " +
            " where real_score > #{realScore} ")
    int querySchoolTargetRank(@Param("productId") Integer productId, @Param("testPaperId") Integer testPaperId, @Param("schoolId") Integer schoolId,
                              @Param("assessmentTargetId") Integer assessmentTargetId, @Param("realScore") Double realScore);
}
