package com.ruida.assessment.assessmentquestionbank.controller;

import com.ruida.assessment.assessmentcommon.result.ListResult;
import com.ruida.assessment.assessmentquestionbank.service.QuestionTypeService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * @description: 题型控制层
 * @author: kgz
 * @date: 2020/6/10
 */
@RequestMapping("/questionType")
@RestController
@Api(value ="题型相关接口")
public class QuestionTypeController {

    @Resource
    private QuestionTypeService questionTypeService;

    @GetMapping("/getList")
    @ApiOperation(value = "获取题型下拉框列表", notes = "获取题型下拉框列表")
    public ListResult getList(){
        ListResult listResult = new ListResult();
        listResult.setContent(questionTypeService.getList());
        return listResult;
    }
}
