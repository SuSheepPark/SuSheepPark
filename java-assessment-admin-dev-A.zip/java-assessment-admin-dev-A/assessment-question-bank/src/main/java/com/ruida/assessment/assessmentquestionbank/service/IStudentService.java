package com.ruida.assessment.assessmentquestionbank.service;

import com.baomidou.mybatisplus.service.IService;
import com.ruida.assessment.assessmentcommon.result.BaseResult;
import com.ruida.assessment.assessmentcommon.result.PageData;
import com.ruida.assessment.assessmentcommon.result.PojoResult;
import com.ruida.assessment.assessmentquestionbank.dto.*;
import com.ruida.assessment.assessmentquestionbank.model.TStudent;
import com.ruida.assessment.assessmentquestionbank.vo.ExamRecordListVo;
import com.ruida.assessment.assessmentquestionbank.vo.OrderListVO;
import com.ruida.assessment.assessmentquestionbank.vo.StudentInfoVo;
import com.ruida.assessment.assessmentquestionbank.vo.StudentVo;
import org.springframework.web.multipart.MultipartFile;

import java.util.HashMap;
import java.util.List;

/**
 * @author wy
 * @description
 * @date 2020/7/31  学员管理服务接口
 */

public interface IStudentService extends IService<TStudent> {

    /*
    分页查询考生列表
     */
    PageData<StudentVo> queryStudentDataList(StudentQueryRequest request);

    /*
        新增、编辑学员(旧)
     */
    PojoResult saveStudent(StudentRequest request);

    /**
     * 获取所有考生的id
     * @return
     */
    List<Integer> getAllStudentId();

    /*
   考生更换班级(新方案)
    */
    BaseResult newExchangeClass(NewExchangeClassDTO exchangeClassDTO );

    /*
    删除考生
     */
    BaseResult deleteStuendtByStuId(Integer stuId);


    /*
    获取用户虚拟考生
    */
    TStudent getStudentByUserId(Integer userId);
}
