package com.ruida.cloud.dao;

import com.ruida.cloud.model.CourseLesson;
import com.ruida.cloud.model.CourseLessonExample;
import com.ruida.cloud.model.CourseLessonExt;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

public interface CourseLessonMapper {
    long countByExample(CourseLessonExample example);

    int deleteByExample(CourseLessonExample example);

    int deleteByPrimaryKey(Integer courseLessonId);

    int insert(CourseLesson record);

    int insertSelective(CourseLesson record);

    List<CourseLesson> selectByExample(CourseLessonExample example);

    CourseLesson selectByPrimaryKey(Integer courseLessonId);

    int updateByExampleSelective(@Param("record") CourseLesson record, @Param("example") CourseLessonExample example);

    int updateByExample(@Param("record") CourseLesson record, @Param("example") CourseLessonExample example);

    int updateByPrimaryKeySelective(CourseLesson record);

    int updateByPrimaryKey(CourseLesson record);

    /**
     *
     * @return  根据课程获取课次
     */
    List<Map<String,Object>> getLessonListByCourseId(Map<String, Object> maps);
    @Select("select count(course_lesson_id) nums  from t_course_course_lesson_rel where course_id =#{courseId}")
    Integer getLessonListByCourseIdCount(Integer courseId);

    /**
     * 批量新增课程大纲信息
     */
    int insertCourseLessonBatch(List<CourseLesson> lessonList);

    /**
     * 根据id批量删除
     */
    int deleteCourseLessonBatch(List<Integer> list);


    /**
     * 批量新增课程大纲信息(新)
     */
    int insertNewCourseLessonBatch(List<CourseLesson> lessonList);

    List<Map<String,Object>> selectByCourseId(@Param("courseId") Integer courseId);

}