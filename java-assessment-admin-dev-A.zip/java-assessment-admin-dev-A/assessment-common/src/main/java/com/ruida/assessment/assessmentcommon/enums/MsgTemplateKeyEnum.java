package com.ruida.assessment.assessmentcommon.enums;

import org.apache.commons.lang3.StringUtils;

import java.util.Map;

/**
 * @description: 消息模板变量枚举
 * @author: kgz
 * @date: 2020/7/22
 */
public enum  MsgTemplateKeyEnum {
    PRODUCT_NAME("%productName","【商品名称】"),
    TEST_PAPER_NAME("%testPaperName","【试卷名称】"),
    SCHOOL_NAME("%schoolName","【学校名称】"),
    CLASS_NAME("%className","【班级名称】"),
    ;


    private String K;
    private String V;

    MsgTemplateKeyEnum(String k, String v) {
        K = k;
        V = v;
    }

    public String getK() {
        return K;
    }

    public void setK(String k) {
        K = k;
    }

    public String getV() {
        return V;
    }

    public void setV(String v) {
        V = v;
    }

    public static MsgTemplateKeyEnum getValueById(String K){
        for(MsgTemplateKeyEnum msgTemplateEnum : MsgTemplateKeyEnum.values() ){
            if(msgTemplateEnum.getK().equals(K)){
                return  msgTemplateEnum;
            }
        }
        return null;
    }

    /**
     * 替换字符串中的变量
     * @param str
     * @param map
     * @return
     */
    public static String replaceValue(String str, Map map){
        if(StringUtils.isNotEmpty(str) && map != null && map.size() > 0){
            for(MsgTemplateKeyEnum msgTemplateEnum : MsgTemplateKeyEnum.values() ){
                str = str.replace(msgTemplateEnum.getV(), String.valueOf(map.get(msgTemplateEnum.getK())));
            }
        }
        return str;
    }

}
