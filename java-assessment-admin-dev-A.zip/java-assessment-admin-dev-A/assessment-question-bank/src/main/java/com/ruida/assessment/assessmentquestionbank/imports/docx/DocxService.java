package com.ruida.assessment.assessmentquestionbank.imports.docx;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import org.apache.poi.openxml4j.opc.PackagePart;
import org.apache.poi.xwpf.usermodel.IBodyElement;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.apache.poi.xwpf.usermodel.XWPFTable;
import org.springframework.util.DigestUtils;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.ruida.assessment.assessmentquestionbank.SystemConstant;
import com.ruida.assessment.assessmentquestionbank.imports.util.DateUtil;
import com.ruida.assessment.util.ImageTransUtil;

import net.coobird.thumbnailator.Thumbnails;

public class DocxService {
	public static String getLineText(IBodyElement element) {
		if (element == null) {
			return null;
		}
		switch (element.getElementType()) {
		case PARAGRAPH:
			List<XWPFRun> runs = ((XWPFParagraph) element).getRuns();
			StringBuffer text = new StringBuffer();
			for (XWPFRun run : runs) {
				text.append(getText(run));
			}
			return text.toString();
		case TABLE:
			return ((XWPFTable) element).getText();
		default:
			return null;
		}

	}

	public static String getText(XWPFRun run) {
		Node runNode = run.getCTR().getDomNode();
		Node textNode = getChildNode(runNode, "w:t");
		if (textNode == null) {
			return "";
		}
		String text = textNode.getFirstChild().getNodeValue();
		return text;
	}

	public static String getMath(XWPFRun run) {
		Node runNode = run.getCTR().getDomNode();
		Node objectNode = getChildNode(runNode, "w:object");
		if (objectNode == null) {
			return "";
		}
		Node shapeNode = getChildNode(objectNode, "v:shape");
		if (shapeNode == null) {
			return "";
		}
		Node imageNode = getChildNode(shapeNode, "v:imagedata");
		if (imageNode == null) {
			return "";
		}
		Node binNode = getChildNode(objectNode, "o:OLEObject");
		if (binNode == null) {
			return "";
		}

		XWPFDocument word = run.getDocument();

		NamedNodeMap shapeAttrs = shapeNode.getAttributes();
		// 图片在Word中显示的宽高
		String style = shapeAttrs.getNamedItem("style").getNodeValue();

		NamedNodeMap imageAttrs = imageNode.getAttributes();
		// 图片在Word中的ID
		String imageRid = imageAttrs.getNamedItem("r:id").getNodeValue();
		// 获取图片信息
		PackagePart imgPart = word.getPartById(imageRid);

		Float width;
		if (style.matches(".*width:(.*?)pt.*")) {
			String widthString = style.replaceAll(".*width:(.*?)pt.*", "$1");
			width = Float.parseFloat(widthString);
			width = width * 20 / 15;
		} else {
			width = 250f;
		}
		InputStream inputStream = null;
		try {
			inputStream = imgPart.getInputStream();
			ByteArrayOutputStream baos =ImageTransUtil.wmf2Jpg(inputStream, width);
			byte[] bytes = baos.toByteArray();
			return saveFile(bytes);
//			return WmfToJpeg.convert(inputStream, width);
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		} finally {
			try {
				if (inputStream != null) {

					inputStream.close();

				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}

	public static String getPic(XWPFRun run) {
		Node runNode = run.getCTR().getDomNode();
		// drawing 一个绘画的图片
		Node drawingNode = getChildNode(runNode, "w:drawing");
		if (drawingNode == null) {
			return "";
		}
		// 绘画图片的宽和高
		Node extentNode = getChildNode(drawingNode, "wp:extent");
		NamedNodeMap extentAttrs = extentNode.getAttributes();
		Integer width = Integer.parseInt(extentAttrs.getNamedItem("cx").getNodeValue()) / 9525;
		Integer height = Integer.parseInt(extentAttrs.getNamedItem("cy").getNodeValue()) / 9525;

		// 绘画图片具体引用
		Node blipNode = getChildNode(drawingNode, "a:blip");
		NamedNodeMap blipAttrs = blipNode.getAttributes();
		String rid = blipAttrs.getNamedItem("r:embed").getNodeValue();
//		System.out.println("word中图片ID：".concat(rid));

		XWPFDocument word = run.getDocument();

		// 获取图片信息
		PackagePart imgPart = word.getPartById(rid);
		ByteArrayOutputStream baos =null;
//		ByteArrayInputStream swapStream = null;

		try {
			InputStream imgInputStream = imgPart.getInputStream();
			byte[] bytes;
			switch (imgPart.getContentTypeDetails().getSubType()) {
			case "x-emf":
				baos=ImageTransUtil.emf2Jpg(imgInputStream, width*1f);
				break;

			default:
				baos= new ByteArrayOutputStream();
				Thumbnails.of(imgInputStream).size(width, height).outputQuality(0.5f).toOutputStream(baos);
				break;
			}
			bytes= baos.toByteArray();
//			swapStream = new ByteArrayInputStream(baos.toByteArray());
			 

			return saveFile(bytes);
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		} finally {
			try {
				baos.close();
			} catch (IOException e) {
				e.printStackTrace();
			}

		}

	}

	private static Node getChildNode(Node node, String nodeName) {
		if (!node.hasChildNodes()) {
			return null;
		}
		NodeList childNodes = node.getChildNodes();
		for (int i = 0; i < childNodes.getLength(); i++) {
			Node childNode = childNodes.item(i);
			if (nodeName.equals(childNode.getNodeName())) {
				return childNode;
			}
			childNode = getChildNode(childNode, nodeName);
			if (childNode != null) {
				return childNode;
			}
		}
		return null;
	}

	private static String saveFile(byte[] bytes) {
		FileOutputStream os = null;
		try {
			String path = SystemConstant.QUESTION_IMPORT_APK;// 模块具体上传路径
			String curDate = DateUtil.getCurrentDateForUpload();// 当前日期“yyyy-mm-dd”

			String dateFile = SystemConstant.UPLOAD_ROOT;/** 主路径 */

			String filePath = dateFile + path + "/" + curDate + "/" + DigestUtils.md5DigestAsHex(bytes) + ".jpg";

			File file = new File(filePath);
			if (!file.getParentFile().exists()) {
				file.getParentFile().mkdirs();
			}
			os = new FileOutputStream(file);
			os.write(bytes);
			return filePath;
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		} finally {
			try {
				if (os != null) {
					os.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}

		}
	}
}
