package com.ruida.assessment.assessmentquestionbank.dto;

import lombok.Data;

import java.util.List;
@Data
public class NewExchangeClassDTO {
    private Integer schoolId;

    private Integer periodId;

    private Integer gradeId;

    private Integer classId;
    private List<Integer> stuIds;//学员id集合
}
