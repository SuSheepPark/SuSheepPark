package com.ruida.assessment.assessmentquestionbank.controller;

import com.ruida.assessment.assessmentcommon.result.ListResult;
import com.ruida.assessment.assessmentquestionbank.annotaion.UserAuth;
import com.ruida.assessment.assessmentquestionbank.service.SubjectService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * @description: 科目控制层
 * @author: kgz
 * @date: 2020/6/18
 */
@RequestMapping("/subject")
@RestController
@Api(value ="科目相关接口")
public class SubjectController {
    @Resource
    private SubjectService subjectService;

    @UserAuth
    @GetMapping(value = {"/getList/{periodId}/{all}", "/getList/{periodId}", "/getList"})
    @ApiOperation(value = "获取科目下拉框列表", notes = "获取科目下拉框列表")
    public ListResult getList(@PathVariable(required = false) Integer periodId, @PathVariable(required = false) Integer all){
        ListResult listResult = new ListResult();
        listResult.setContent(subjectService.getSubjectList(periodId, all));
        return listResult;
    }
}
