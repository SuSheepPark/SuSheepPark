package com.ruida.cloud.dao;

import com.ruida.cloud.model.TStage;
import com.ruida.cloud.model.TStageExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface TStageMapper {
    int countByExample(TStageExample example);

    int deleteByExample(TStageExample example);

    int deleteByPrimaryKey(Integer stageId);

    int insert(TStage record);

    int insertSelective(TStage record);

    List<TStage> selectByExample(TStageExample example);

    TStage selectByPrimaryKey(Integer stageId);

    int updateByExampleSelective(@Param("record") TStage record, @Param("example") TStageExample example);

    int updateByExample(@Param("record") TStage record, @Param("example") TStageExample example);

    int updateByPrimaryKeySelective(TStage record);

    int updateByPrimaryKey(TStage record);

    /**************/
    List<Map<String, Object>> listStageByPeriodId(int periodId);
}