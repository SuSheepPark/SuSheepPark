package com.ruida.mockdao.dto;

import lombok.Data;

/**
 * @description: 错题DTO
 * @author: chenjy
 * @create: 2020-07-16 10:28
 */
@Data
public class ErrorBookDTO {

    private Integer examRecordId;

    private Integer testPaperId;

    private String questionId;

    private Integer questionTypeId;

    private Integer periodId;

    private Integer subjectId;

    private Integer createBy;

}
