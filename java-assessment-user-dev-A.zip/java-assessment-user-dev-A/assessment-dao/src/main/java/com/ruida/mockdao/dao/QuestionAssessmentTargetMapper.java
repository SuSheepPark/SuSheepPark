package com.ruida.mockdao.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.model.QuestionAssessmentTarget;

/**
 * <p>
 * 考核目标表 Mapper 接口
 * </p>
 *
 * @author chenjy
 * @since 2021-03-04
 */
public interface QuestionAssessmentTargetMapper extends BaseMapper<QuestionAssessmentTarget> {

}
