package com.ruida.mockcommon.util;

import com.ruida.mockcommon.entity.TreeNode;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @description: 构造树
 * @author: chenjy
 * @create: 2020-08-12 16:39
 */
public class TreeHelper {

    public static List<? extends TreeNode> buildTree(List<? extends TreeNode> nodes) {
        Map<Integer, List<TreeNode>> children = nodes.stream().filter(node -> node.getPid() != 0).collect(Collectors.groupingBy(node -> node.getPid()));
        nodes.forEach(node -> node.setChildren(children.get(node.getId())));
        return nodes.stream().filter(node -> node.getPid() == 0).collect(Collectors.toList());
    }
}
