package com.ruida.cloud.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

@Data
public class CourseLessonExt implements Serializable {
    private Integer courseLessonId;

    private String courseLessonName;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date startDate;

    private String startTime;

    private String endTime;

    private Integer teacherId;
    /**
     * 直播间ID
     */
    private Integer broadcastRoomId;
    /***
     *直播间名字
     */
    private String broadcastRoomName;
    private String assistantTeacherId;
    private String assistantTeacherName;
    private Integer courseVideoId;


    /** 录播课保存课次时传的百家云视频ID 为了方便前端，区别于上面的courseVideoId (T ^ T) */
    private String recordCourseVideoId;
    /**
     * 录播课视频百家云地址
     */
    private String courseLessonVideoUrl;

    /**
     * 百家云播放token
     */
    private String baijiayunVideoToken;



    private Byte isdelete;

    private Integer courseId;

    //录播课排序
    private Integer orderNum;

    //临时--起止时间
    private String startEndTime;

    /**
     * 最后一节课结束时间
     */
    private Date lastLessonTime;
    /**
     * 最后一节课开始时间
     */
    private Date lastLessonStartTime;
    /**
     * 第一节课开始时间
     */
    private Date firstLessonTime;

    //临时--授课老师
    private String teacherName;

    //临时--状态
    private String statusName;
    private String status;

    private Integer courseGenseeId;
    private String roomId;
    //直播地址
    private String liveUrl;
    private String studentToken;

    //回放地址
    private String recordUrl;
    private String recordToken;

    private String nickname;

    //临时--课件名称
    private String libraryName;
    //临时--资源文件路径
    private String libraryPath;
    //表单提交-文件类型
    private String libraryType;
    //表单提交-文件大小
    private float librarySize;

    private ResourceLibrary resourceLibrary;

    //临时
    private String videoStatus;
    private String vid;
    private String courseVideoName;
    private CourseVideo courseVideo;
    /**
     *课次时长
     */
    private Long duration;
    /***
     * 课次编号
     */
    private String  courseLessonSn;
    /**
     * 直播课类型 (0—大班课；1—分组课)
     */
    private Byte liveType;

    /**
     * 课程分组数量
     */
    private Integer groupNum;

    /**
     * 校管家课时id
     */
    private String xiaogjLessonId;

    /**
     * 更新时间
     */
    private Date xiaogjUpdate;

}
