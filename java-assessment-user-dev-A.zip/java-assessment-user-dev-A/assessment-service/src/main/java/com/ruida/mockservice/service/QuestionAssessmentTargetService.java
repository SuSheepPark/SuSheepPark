package com.ruida.mockservice.service;

import com.baomidou.mybatisplus.service.IService;
import com.ruida.mockdao.model.QuestionAssessmentTarget;

/**
 * <p>
 * 考核目标表 服务类
 * </p>
 *
 * @author chenjy
 * @since 2021-03-04
 */
public interface QuestionAssessmentTargetService extends IService<QuestionAssessmentTarget> {

}
