/**   
 * Copyright © 2019 公司名. All rights reserved.
 * 
 * @Title: MyController.java 
 * @Prject: zhaowei-cms
 * @Package: com.zhaowei.cms.controller 
 * @Description: TODO
 * @author: zw   
 * @date: 2019年9月17日 上午8:29:23 
 * @version: V1.0   
 */
package com.zhaowei.cms.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

/** 
 * @ClassName: MyController 
 * @Description:个人中心
 * @author: zw
 * @date: 2019年9月17日 上午8:29:23  
 */
@RequestMapping("my")
@Controller
public class MyController {

	/**
	 * @Title: index 
	 * @Description: 个人中心的首页
	 * @return
	 * @return: String
	 */
	@GetMapping({"/","","/index"})
	public String index() {
		return "my/index";
	}
	
}
