package com.ruida.assessment.assessmentquestionbank.controller;

import com.ruida.assessment.assessmentcommon.result.BaseResult;
import com.ruida.assessment.assessmentcommon.result.PojoResult;
import com.ruida.assessment.assessmentquestionbank.annotaion.UserAuth;
import com.ruida.assessment.assessmentquestionbank.dto.BottomInfoRequest;
import com.ruida.assessment.assessmentquestionbank.service.IBottomInfoService;
import com.ruida.assessment.assessmentquestionbank.vo.BottomInfoVo;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

/**
 * @author wy
 * @description 底部网站信息业务类
 * @date 2020/8/14
 */
@RequestMapping("/bottom")
@RestController
public class BottomInfoController {

    @Resource
    private IBottomInfoService bottomInfoService;

    /*
     * 功能描述   查询网站信息
     * @param
     * @return
     */
    @GetMapping("query/websiteInfo")
    public PojoResult queryWebsiteInfo(@RequestParam Integer id){
        BottomInfoVo bottomInfoVo = bottomInfoService.queryWebsiteInfo(id);
        PojoResult result = new PojoResult<>();
        result.setContent(bottomInfoVo);
        result.setMsg("成功");
        return result;
    }

    /*
     *功能描述    新增、编辑、网站信息
     * @param
     * @return
     */
    @UserAuth
    @PostMapping("save/saveWebsiteInfo")
    public BaseResult saveWebsiteInfo(@RequestBody BottomInfoRequest request){
        BaseResult result = bottomInfoService.saveWebsiteInfo(request);
        return result;
    }

}
