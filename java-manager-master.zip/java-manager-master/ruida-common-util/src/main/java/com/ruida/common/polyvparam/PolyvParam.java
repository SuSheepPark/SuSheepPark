package com.ruida.common.polyvparam;

public class PolyvParam {
    //USERID
    public static String USERID = "1b0f19f441";
    //WRITETOKEN
    public static String WRITETOKEN = "8d3d46f3-8bd2-4746-8cb2-e49b28912423";
    //READTOKEN
    public static String READTOKEN = "9139279f-7f13-4a09-8152-d2832566aa6c";
    //SECRETKEY
    public static String SECRETKEY = "Tn0JxRhx3J";
}
