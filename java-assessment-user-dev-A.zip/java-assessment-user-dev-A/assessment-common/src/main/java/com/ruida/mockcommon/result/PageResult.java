package com.ruida.mockcommon.result;
/**
 * @description:
 * @author szl
 * @Date 2018年12月10日
 * @verion 1.0
 */
public class PageResult<T> extends BaseResult {

	private static final long serialVersionUID = 223599215383007066L;
	
	private Page<T> content;

	public Page<T> getContent() {
		return content;
	}

	public void setContent(Page<T> content) {
		this.content = content;
	}

}