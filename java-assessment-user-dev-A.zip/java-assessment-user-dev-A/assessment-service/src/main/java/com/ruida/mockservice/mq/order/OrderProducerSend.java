package com.ruida.mockservice.mq.order;

import com.aliyun.openservices.ons.api.Message;
import com.aliyun.openservices.ons.api.SendResult;
import com.ruida.mockcommon.mq.producer.MQUtil;
import com.ruida.mockcommon.mq.producer.ProducerListener;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;


@Service
@Slf4j
public class OrderProducerSend {


    @Resource
    private ProducerListener producerListener;
    @Value("${spring.profiles.active}")
    private String profiles;

    public boolean send(String orderId) {
        try {
            Message msg = new Message();
            // 设置消息需要被投递的时间
            msg.setTopic("order-status-topic");
            msg.setStartDeliverTime(System.currentTimeMillis() +  1800000);
            msg.setTag("order-assessment");
            msg.setKey("OrderId"+ profiles +"_" + orderId);
            msg.setBody("30MIN倒计时取消订单".getBytes());
            SendResult sendResult  = producerListener.getProducer(MQUtil.getRealId("GID-order-status-assessment-")).
                    send(msg);
            log.info("订单倒计时30MIN开始");
            if (sendResult != null) {
                return true;
            }
        } catch (Exception e) {
            log.error("发送消息异常，原因:{}", e);
        }
        return false;
    }
}
