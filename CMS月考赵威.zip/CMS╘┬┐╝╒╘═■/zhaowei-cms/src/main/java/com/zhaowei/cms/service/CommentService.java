/**   
 * Copyright © 2019 公司名. All rights reserved.
 * 
 * @Title: CommentService.java 
 * @Prject: zhaowei-cms
 * @Package: com.zhaowei.cms.service 
 * @Description: TODO
 * @author: zw   
 * @date: 2019年9月21日 下午8:48:51 
 * @version: V1.0   
 */
package com.zhaowei.cms.service;

import java.util.List;

import com.github.pagehelper.PageInfo;
import com.zhaowei.cms.domain.Comment;

/** 
 * @ClassName: CommentService 
 * @Description: TODO
 * @author: zw
 * @date: 2019年9月21日 下午8:48:51  
 */
public interface CommentService {

	/**
	 * @Title: selects 
	 * @Description:查询文章列表
	 * @return
	 * @return: List<Comment>
	 */
	PageInfo<Comment> selects(Integer articleId,Integer page,Integer pageSize);
	
	/**
	 * 
	 * @Title: insert 
	 * @Description:添加评论的方法
	 * @param comment
	 * @return
	 * @return: int
	 */
	int insert(Comment comment);

	/** 
	 * @Title: selectsByUserId 
	 * @Description: TODO
	 * @param id
	 * @param page
	 * @param pageSize
	 * @return
	 * @return: PageInfo<Comment>
	 */
	PageInfo<Comment> selectsByUserId(Integer id, Integer page, Integer pageSize);

}
