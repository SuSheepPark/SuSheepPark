package com.ruida.cloud.model;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

/**
 * @author wy
 * @description: 请求测试类
 */

@Data
public class DoublePersonDataRequest {

    private Integer assist_teacher_id;
    private String assist_teacher_name;
    private String assist_teacher_mobile;
    private Integer class_id;
    private String class_name;
    private List<DoubleStudentVo> student_list = new ArrayList<>();
}