package com.ruida.mockdao.vo;

import lombok.Data;

/**
 * <p>
 * 小节试题Vo
 * </p>
 *
 * @author wy
 * @since 2021-08-19
 */
@Data
public class TestNodeQuestionVo {

    /**
     * 试卷ID
     */
    private Integer testPaperId;
    /**
     * 小节ID
     */
    private Integer nodeId;
    /**
     * 父级试题ID（组合题使用）
     */
    private String parentId;
    /**
     * 试题ID
     */
    private String questionId;
    /**
     * 试题类型
     */
    private Integer questionTypeId;

    /**
     * 科目
     */
    private Integer subjectId;

}
