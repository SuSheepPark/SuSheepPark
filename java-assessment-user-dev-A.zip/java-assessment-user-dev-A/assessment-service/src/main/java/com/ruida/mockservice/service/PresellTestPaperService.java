package com.ruida.mockservice.service;

import com.baomidou.mybatisplus.service.IService;
import com.ruida.mockdao.model.PresellTestPaper;

/**
 * Created by xumingqi on 2021/7/1 15:04
 */
public interface PresellTestPaperService extends IService<PresellTestPaper> {
}
