package com.ruida.assessment.assessmentquestionbank.service;

import com.aliyun.oss.OSS;

import java.io.IOException;
import java.io.InputStream;

public interface AliyunOSSService {


    /**
     * 获取开放文件下载地址
     * @param objectName
     * @return
     */
     String getOpenUrl(String objectName);

    /**
     * 上传图片
     * @param inputStream
     * @param fileName
     * @return
     * @throws IOException
     */
      String uploadPic(InputStream inputStream, String fileName) throws IOException;

    /**
     * STS形式文件上传
     * @param inputStream
     * @param fileName
     * @param uploadPath
     */
     void stsUpload(InputStream inputStream, String fileName, String uploadPath);

    /**
     * sts形式获取文件下载路径
     * @param objectName
     * @return
     */
    String getStsURL(String objectName);

    /**
     * 普通形式上传文件
     * @param inputStream
     * @param fileName
     * @param uploadPath
     */
      void uploadOpenBucket(InputStream inputStream, String fileName,String uploadPath);

    /**
     * 公开读bucket上传文件
     * @param inputStream
     * @param fileName
     * @return
     */
    String uploadFile(InputStream inputStream, String fileName);
}
