package com.ruida.mockservice.service;


import com.baomidou.mybatisplus.service.IService;
import com.ruida.mockcommon.result.PageData;
import com.ruida.mockdao.dto.MyExamPaperRequest;
import com.ruida.mockdao.dto.SaveQuestionDTO;
import com.ruida.mockdao.dto.TestPaperDTO;
import com.ruida.mockdao.dto.TestPaperQueryRequest;
import com.ruida.mockdao.model.TScene;
import com.ruida.mockdao.model.TestPaper;
import com.ruida.mockdao.vo.*;
import com.ruida.mockdao.vo.product.PaperReportVO;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 试卷表 服务类
 * </p>
 *
 * @author jinhu
 * @since 2020-07-08
 */
public interface TestPaperService extends IService<TestPaper> {

    /**
     * 查询不包含试题详情的试卷信息。
     * 在第一次访问的时候会创建一条空考试记录，代表开始作答
     *
     * @param sceneId 场次id
     * @return
     */
    TestPaperVO queryPaperBaseInfo(String sceneId);

    /*
     *功能描述  查询商品列表
     * @param
     * @return
     */
    List<TestPaperInProductVO> queryPaperList(TestPaperQueryRequest request);

    void checkSceneInfo(TScene scene, Integer stuId);

    /**
     * 判断是否已购买试卷
     *
     * @param productId
     * @param testPaperId
     * @param userId
     */
    void checkUserBuyPaper(Integer productId, Integer testPaperId, Integer userId);

    /*
     *功能描述  查询商品列表
     * @param
     * @return
     */
    List<PaperReportVO> queryPaperListNew(TestPaperQueryRequest request);

    void saveQuestionAnswer(SaveQuestionDTO saveQuestionDTO);

    /**
     * 交卷(不涉及题目的保存)
     *
     * @param testPaperDTO
     * @return
     */
    SubmitVO submitTestPaper(TestPaperDTO testPaperDTO, Integer stuId, Integer userId);

    QuestionVO handleQuestionVO(QuestionVO questionVO);

    /**
     * 查询我的考试记录
     * @param req
     * @return
     */
    PageData<MyExamRecordVO> queryMyExamList(@Param("vo") MyExamPaperRequest req);

    /**
     * 测评中心考试页--题量卷量统计
     * @return
     */
    ExamStatVO getUserExamStat();

    /**
     * 查询试卷结构
     * @param productId   商品id
     * @param testPaperId 试卷id
     * @param channel     渠道(1-app；2-pc)
     * @return
     */
    TestPaperStructureVO queryTestPaperStructure(Integer productId,Integer testPaperId,Integer channel);


    /*
     *功能描述  查询预售试卷列表
     * @param
     * @return
     */
    List<TestPaperInProductVO> queryPreSellPaperList(TestPaperQueryRequest request);

    /**
     * 获取考试前页信息
     * @param type
     * @param channel
     * @return
     */
    TestPaperStructureVO queryHomePage(Integer type, Integer channel);

    /**
     * 获取当前试卷考试次数列表
     */
    List<MyTestPaperExamRecordVO> queryExamRecord(Integer productId, Integer testPaperId);
}
