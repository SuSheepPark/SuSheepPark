package com.ruida.mockdao.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.model.SysRole;

/**
 * <p>
 * 角色表 Mapper 接口
 * </p>
 *
 * @author Bhj
 * @since 2020-07-09
 */
public interface SysRoleMapper extends BaseMapper<SysRole> {
}
