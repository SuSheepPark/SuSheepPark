package com.ruida.cloud.dao;

import com.ruida.cloud.model.InfoManage;
import com.ruida.cloud.model.InfoManageExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface InfoManageMapper {
    int countByExample(InfoManageExample example);

    int deleteByExample(InfoManageExample example);

    int deleteByPrimaryKey(Integer infoManageId);

    int insert(InfoManage record);

    int insertSelective(InfoManage record);

    List<InfoManage> selectByExampleWithBLOBs(InfoManageExample example);

    List<InfoManage> selectByExample(InfoManageExample example);

    InfoManage selectByPrimaryKey(Integer infoManageId);

    int updateByExampleSelective(@Param("record") InfoManage record, @Param("example") InfoManageExample example);

    int updateByExampleWithBLOBs(@Param("record") InfoManage record, @Param("example") InfoManageExample example);

    int updateByExample(@Param("record") InfoManage record, @Param("example") InfoManageExample example);

    int updateByPrimaryKeySelective(InfoManage record);

    int updateByPrimaryKeyWithBLOBs(InfoManage record);

    int updateByPrimaryKey(InfoManage record);
}