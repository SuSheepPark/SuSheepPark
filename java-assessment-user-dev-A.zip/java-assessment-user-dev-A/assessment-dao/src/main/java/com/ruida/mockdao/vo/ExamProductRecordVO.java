package com.ruida.mockdao.vo;

import com.ruida.mockdao.pojo.BasicSubjectInfo;

import java.util.List;

/**
 * @description: 商品考试记录VO
 * @author: kgz
 * @date: 2021/2/24
 */
public class ExamProductRecordVO {

    /**
     * 商品考试记录列表
     */
    List<ExamProductSubjectRecordVO> subjectRecordList;

    /**
     * 表头
     */
    List<BasicSubjectInfo> subjectHeader;

    /**
     * 科目平均分
     */
    List<BasicSubjectInfo> subjectScoreAvgList;

    /**
     * 上次高考年份
     */
    private Integer year;

    public List<ExamProductSubjectRecordVO> getSubjectRecordList() {
        return subjectRecordList;
    }

    public void setSubjectRecordList(List<ExamProductSubjectRecordVO> subjectRecordList) {
        this.subjectRecordList = subjectRecordList;
    }

    public List<BasicSubjectInfo> getSubjectHeader() {
        return subjectHeader;
    }

    public void setSubjectHeader(List<BasicSubjectInfo> subjectHeader) {
        this.subjectHeader = subjectHeader;
    }

    public List<BasicSubjectInfo> getSubjectScoreAvgList() {
        return subjectScoreAvgList;
    }

    public void setSubjectScoreAvgList(List<BasicSubjectInfo> subjectScoreAvgList) {
        this.subjectScoreAvgList = subjectScoreAvgList;
    }

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }
}
