package com.ruida.cloud.dao;

import com.ruida.cloud.model.SchoolStageClassRel;
import com.ruida.cloud.model.SchoolStageClassRelExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface SchoolStageClassRelMapper {
    int countByExample(SchoolStageClassRelExample example);

    int deleteByExample(SchoolStageClassRelExample example);

    int deleteByPrimaryKey(Integer organizationalStructureId);

    int insert(SchoolStageClassRel record);

    int insertSelective(SchoolStageClassRel record);

    List<SchoolStageClassRel> selectByExample(SchoolStageClassRelExample example);

    SchoolStageClassRel selectByPrimaryKey(Integer organizationalStructureId);

    int updateByExampleSelective(@Param("record") SchoolStageClassRel record, @Param("example") SchoolStageClassRelExample example);

    int updateByExample(@Param("record") SchoolStageClassRel record, @Param("example") SchoolStageClassRelExample example);

    int updateByPrimaryKeySelective(SchoolStageClassRel record);

    int updateByPrimaryKey(SchoolStageClassRel record);

    List<SchoolStageClassRel> selectBySchoolIdExample(Integer schoolId);
}