package com.ruida.cloud.daoTmp;

import com.ruida.cloud.model.CourseBroadcastroomRel;
import com.ruida.cloud.model.TeachingClassExt;

import java.io.Serializable;
import java.util.List;

/**
 * @author taosh
 * @create 2019-09-24 17:25
 */
public class CourseBroadcastroomRelInfo implements Serializable {
    private Integer courseBroadcastroomId;

    private Integer courseId;

    private Integer campusId;
    /**
     * 校区名称
     */
    private String campusName;
    /**
     * 校区已报名人数
     */
    private Integer campusAlreadyNum;

    private Integer broadcastRoomId;

    private Integer broadcastRoomOnlineStuNum;

    /**剩余坐席*/
    private Integer broadcastRoomSurplusNum;
    private Integer campusSurplusNum;

    /**已排班人数*/
    private Integer alreadyNum;

    /**未排班人数*/
    private Integer broadcastRoomFreeNum;
    private Integer campusFreeNum;
    private Integer freeNum;

    private Integer broadcastRoomMaximum;
    private Integer campusMaximum;

    /**学生端信息(1:1)*/
    private List<TeachingClassExt> teachingClassList;

    /**线上可报名人数*/
    private Integer campusOnlineStuNum;

    /**线下 还可以 报名人数(学生端)*/
    private Integer broadcastroomUnderlineFreeStuNum;

    public String getCampusName() {
        return campusName;
    }

    public void setCampusName(String campusName) {
        this.campusName = campusName;
    }

    public Integer getFreeNum() {
        return freeNum;
    }

    public void setFreeNum(Integer freeNum) {
        this.freeNum = freeNum;
    }

    public Integer getBroadcastRoomSurplusNum() {
        return broadcastRoomSurplusNum;
    }

    public void setBroadcastRoomSurplusNum(Integer broadcastRoomSurplusNum) {
        this.broadcastRoomSurplusNum = broadcastRoomSurplusNum;
    }

    public Integer getCampusAlreadyNum() {
        return campusAlreadyNum;
    }

    public void setCampusAlreadyNum(Integer campusAlreadyNum) {
        this.campusAlreadyNum = campusAlreadyNum;
    }

    public Integer getCampusSurplusNum() {
        return campusSurplusNum;
    }

    public void setCampusSurplusNum(Integer campusSurplusNum) {
        this.campusSurplusNum = campusSurplusNum;
    }

    public Integer getBroadcastRoomFreeNum() {
        return broadcastRoomFreeNum;
    }

    public void setBroadcastRoomFreeNum(Integer broadcastRoomFreeNum) {
        this.broadcastRoomFreeNum = broadcastRoomFreeNum;
    }

    public Integer getCampusFreeNum() {
        return campusFreeNum;
    }

    public void setCampusFreeNum(Integer campusFreeNum) {
        this.campusFreeNum = campusFreeNum;
    }

    public Integer getBroadcastRoomMaximum() {
        return broadcastRoomMaximum;
    }

    public void setBroadcastRoomMaximum(Integer broadcastRoomMaximum) {
        this.broadcastRoomMaximum = broadcastRoomMaximum;
    }

    public Integer getCampusMaximum() {
        return campusMaximum;
    }

    public void setCampusMaximum(Integer campusMaximum) {
        this.campusMaximum = campusMaximum;
    }

    public Integer getAlreadyNum() {
        return alreadyNum;
    }

    public void setAlreadyNum(Integer alreadyNum) {
        this.alreadyNum = alreadyNum;
    }


    public List<TeachingClassExt> getTeachingClassList() {
        return teachingClassList;
    }

    public void setTeachingClassList(List<TeachingClassExt> teachingClassList) {
        this.teachingClassList = teachingClassList;
    }

    public Integer getCampusOnlineStuNum() {
        return campusOnlineStuNum;
    }

    public void setCampusOnlineStuNum(Integer campusOnlineStuNum) {
        this.campusOnlineStuNum = campusOnlineStuNum;
    }

    public Integer getBroadcastroomUnderlineFreeStuNum() {
        return broadcastroomUnderlineFreeStuNum;
    }

    public void setBroadcastroomUnderlineFreeStuNum(Integer broadcastroomUnderlineFreeStuNum) {
        this.broadcastroomUnderlineFreeStuNum = broadcastroomUnderlineFreeStuNum;
    }

    public Integer getCourseBroadcastroomId() {
        return courseBroadcastroomId;
    }

    public void setCourseBroadcastroomId(Integer courseBroadcastroomId) {
        this.courseBroadcastroomId = courseBroadcastroomId;
    }

    public Integer getCourseId() {
        return courseId;
    }

    public void setCourseId(Integer courseId) {
        this.courseId = courseId;
    }

    public Integer getCampusId() {
        return campusId;
    }

    public void setCampusId(Integer campusId) {
        this.campusId = campusId;
    }

    public Integer getBroadcastRoomId() {
        return broadcastRoomId;
    }

    public void setBroadcastRoomId(Integer broadcastRoomId) {
        this.broadcastRoomId = broadcastRoomId;
    }

    public Integer getBroadcastRoomOnlineStuNum() {
        return broadcastRoomOnlineStuNum;
    }

    public void setBroadcastRoomOnlineStuNum(Integer broadcastRoomOnlineStuNum) {
        this.broadcastRoomOnlineStuNum = broadcastRoomOnlineStuNum;
    }
}
