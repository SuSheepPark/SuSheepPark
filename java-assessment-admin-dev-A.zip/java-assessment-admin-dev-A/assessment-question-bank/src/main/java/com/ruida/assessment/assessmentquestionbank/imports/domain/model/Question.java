package com.ruida.assessment.assessmentquestionbank.imports.domain.model;

public class Question {
	private String questionName;
	private QuestionConfig config;
	private QuestionBlock block;

	public String getQuestionName() {
		return questionName;
	}

	public void setQuestionName(String questionName) {
		this.questionName = questionName;
	}

	public QuestionConfig getConfig() {
		return config;
	}

	public void setConfig(QuestionConfig config) {
		this.config = config;
	}

	public QuestionBlock getBlock() {
		return block;
	}

	public void setBlock(QuestionBlock block) {
		this.block = block;
	}
	
}
