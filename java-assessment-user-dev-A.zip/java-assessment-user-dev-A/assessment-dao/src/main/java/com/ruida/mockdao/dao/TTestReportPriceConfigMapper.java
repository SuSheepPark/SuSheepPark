package com.ruida.mockdao.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.model.TTestReportPriceConfig;

/**
 * <p>
 * 测试、报告价格设置表 Mapper 接口
 * </p>
 *
 * @author 
 * @since 2021-02-07
 */
public interface TTestReportPriceConfigMapper extends BaseMapper<TTestReportPriceConfig> {

}
