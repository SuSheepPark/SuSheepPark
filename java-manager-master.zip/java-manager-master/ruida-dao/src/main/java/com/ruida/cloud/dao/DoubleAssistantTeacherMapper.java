package com.ruida.cloud.dao;

import com.ruida.cloud.model.DoubleAssistantTeacher;
import com.ruida.cloud.model.DoubleAssistantTeacherExample;
import java.util.List;

import com.ruida.cloud.model.DoubleAssistantTeacherRequest;
import org.apache.ibatis.annotations.Param;

public interface DoubleAssistantTeacherMapper {
    int countByExample(DoubleAssistantTeacherExample example);

    int deleteByExample(DoubleAssistantTeacherExample example);

    int deleteByPrimaryKey(Integer assistantTeacherId);

    int insert(DoubleAssistantTeacher record);

    int insertSelective(DoubleAssistantTeacher record);

    List<DoubleAssistantTeacher> selectByExample(DoubleAssistantTeacherExample example);

    DoubleAssistantTeacher selectByPrimaryKey(Integer assistantTeacherId);

    int updateByExampleSelective(@Param("record") DoubleAssistantTeacher record, @Param("example") DoubleAssistantTeacherExample example);

    int updateByExample(@Param("record") DoubleAssistantTeacher record, @Param("example") DoubleAssistantTeacherExample example);

    int updateByPrimaryKeySelective(DoubleAssistantTeacher record);

    int updateByPrimaryKey(DoubleAssistantTeacher record);

    int batchInsertAssistantTeacher(@Param("list") List<DoubleAssistantTeacher> insertData);

    List<DoubleAssistantTeacher> getAssistantTeacherList(@Param("vo") DoubleAssistantTeacherRequest request);

    Long getAssistantTeacherListCount(@Param("vo") DoubleAssistantTeacherRequest request);
}