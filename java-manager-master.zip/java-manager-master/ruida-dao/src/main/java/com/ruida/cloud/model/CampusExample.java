package com.ruida.cloud.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class CampusExample  {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public CampusExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andCampusIdIsNull() {
            addCriterion("campus_id is null");
            return (Criteria) this;
        }

        public Criteria andCampusIdIsNotNull() {
            addCriterion("campus_id is not null");
            return (Criteria) this;
        }

        public Criteria andCampusIdEqualTo(Integer value) {
            addCriterion("campus_id =", value, "campusId");
            return (Criteria) this;
        }

        public Criteria andCampusIdNotEqualTo(Integer value) {
            addCriterion("campus_id <>", value, "campusId");
            return (Criteria) this;
        }

        public Criteria andCampusIdGreaterThan(Integer value) {
            addCriterion("campus_id >", value, "campusId");
            return (Criteria) this;
        }

        public Criteria andCampusIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("campus_id >=", value, "campusId");
            return (Criteria) this;
        }

        public Criteria andCampusIdLessThan(Integer value) {
            addCriterion("campus_id <", value, "campusId");
            return (Criteria) this;
        }

        public Criteria andCampusIdLessThanOrEqualTo(Integer value) {
            addCriterion("campus_id <=", value, "campusId");
            return (Criteria) this;
        }

        public Criteria andCampusIdIn(List<Integer> values) {
            addCriterion("campus_id in", values, "campusId");
            return (Criteria) this;
        }

        public Criteria andCampusIdNotIn(List<Integer> values) {
            addCriterion("campus_id not in", values, "campusId");
            return (Criteria) this;
        }

        public Criteria andCampusIdBetween(Integer value1, Integer value2) {
            addCriterion("campus_id between", value1, value2, "campusId");
            return (Criteria) this;
        }

        public Criteria andCampusIdNotBetween(Integer value1, Integer value2) {
            addCriterion("campus_id not between", value1, value2, "campusId");
            return (Criteria) this;
        }

        public Criteria andCampusNameIsNull() {
            addCriterion("campus_name is null");
            return (Criteria) this;
        }

        public Criteria andCampusNameIsNotNull() {
            addCriterion("campus_name is not null");
            return (Criteria) this;
        }

        public Criteria andCampusNameEqualTo(String value) {
            addCriterion("campus_name =", value, "campusName");
            return (Criteria) this;
        }

        public Criteria andCampusNameNotEqualTo(String value) {
            addCriterion("campus_name <>", value, "campusName");
            return (Criteria) this;
        }

        public Criteria andCampusNameGreaterThan(String value) {
            addCriterion("campus_name >", value, "campusName");
            return (Criteria) this;
        }

        public Criteria andCampusNameGreaterThanOrEqualTo(String value) {
            addCriterion("campus_name >=", value, "campusName");
            return (Criteria) this;
        }

        public Criteria andCampusNameLessThan(String value) {
            addCriterion("campus_name <", value, "campusName");
            return (Criteria) this;
        }

        public Criteria andCampusNameLessThanOrEqualTo(String value) {
            addCriterion("campus_name <=", value, "campusName");
            return (Criteria) this;
        }

        public Criteria andCampusNameLike(String value) {
            addCriterion("campus_name like", value, "campusName");
            return (Criteria) this;
        }

        public Criteria andCampusNameNotLike(String value) {
            addCriterion("campus_name not like", value, "campusName");
            return (Criteria) this;
        }

        public Criteria andCampusNameIn(List<String> values) {
            addCriterion("campus_name in", values, "campusName");
            return (Criteria) this;
        }

        public Criteria andCampusNameNotIn(List<String> values) {
            addCriterion("campus_name not in", values, "campusName");
            return (Criteria) this;
        }

        public Criteria andCampusNameBetween(String value1, String value2) {
            addCriterion("campus_name between", value1, value2, "campusName");
            return (Criteria) this;
        }

        public Criteria andCampusNameNotBetween(String value1, String value2) {
            addCriterion("campus_name not between", value1, value2, "campusName");
            return (Criteria) this;
        }

        public Criteria andPeriodIdIsNull() {
            addCriterion("period_id is null");
            return (Criteria) this;
        }

        public Criteria andPeriodIdIsNotNull() {
            addCriterion("period_id is not null");
            return (Criteria) this;
        }

        public Criteria andPeriodIdEqualTo(String value) {
            addCriterion("period_id =", value, "periodId");
            return (Criteria) this;
        }

        public Criteria andPeriodIdNotEqualTo(String value) {
            addCriterion("period_id <>", value, "periodId");
            return (Criteria) this;
        }

        public Criteria andPeriodIdGreaterThan(String value) {
            addCriterion("period_id >", value, "periodId");
            return (Criteria) this;
        }

        public Criteria andPeriodIdGreaterThanOrEqualTo(String value) {
            addCriterion("period_id >=", value, "periodId");
            return (Criteria) this;
        }

        public Criteria andPeriodIdLessThan(String value) {
            addCriterion("period_id <", value, "periodId");
            return (Criteria) this;
        }

        public Criteria andPeriodIdLessThanOrEqualTo(String value) {
            addCriterion("period_id <=", value, "periodId");
            return (Criteria) this;
        }

        public Criteria andPeriodIdLike(String value) {
            addCriterion("period_id like", value, "periodId");
            return (Criteria) this;
        }

        public Criteria andPeriodIdNotLike(String value) {
            addCriterion("period_id not like", value, "periodId");
            return (Criteria) this;
        }

        public Criteria andPeriodIdIn(List<String> values) {
            addCriterion("period_id in", values, "periodId");
            return (Criteria) this;
        }

        public Criteria andPeriodIdNotIn(List<String> values) {
            addCriterion("period_id not in", values, "periodId");
            return (Criteria) this;
        }

        public Criteria andPeriodIdBetween(String value1, String value2) {
            addCriterion("period_id between", value1, value2, "periodId");
            return (Criteria) this;
        }

        public Criteria andPeriodIdNotBetween(String value1, String value2) {
            addCriterion("period_id not between", value1, value2, "periodId");
            return (Criteria) this;
        }

        public Criteria andCampusProvinceIsNull() {
            addCriterion("campus_province is null");
            return (Criteria) this;
        }

        public Criteria andCampusProvinceIsNotNull() {
            addCriterion("campus_province is not null");
            return (Criteria) this;
        }

        public Criteria andCampusProvinceEqualTo(Integer value) {
            addCriterion("campus_province =", value, "campusProvince");
            return (Criteria) this;
        }

        public Criteria andCampusProvinceNotEqualTo(Integer value) {
            addCriterion("campus_province <>", value, "campusProvince");
            return (Criteria) this;
        }

        public Criteria andCampusProvinceGreaterThan(Integer value) {
            addCriterion("campus_province >", value, "campusProvince");
            return (Criteria) this;
        }

        public Criteria andCampusProvinceGreaterThanOrEqualTo(Integer value) {
            addCriterion("campus_province >=", value, "campusProvince");
            return (Criteria) this;
        }

        public Criteria andCampusProvinceLessThan(Integer value) {
            addCriterion("campus_province <", value, "campusProvince");
            return (Criteria) this;
        }

        public Criteria andCampusProvinceLessThanOrEqualTo(Integer value) {
            addCriterion("campus_province <=", value, "campusProvince");
            return (Criteria) this;
        }

        public Criteria andCampusProvinceIn(List<Integer> values) {
            addCriterion("campus_province in", values, "campusProvince");
            return (Criteria) this;
        }

        public Criteria andCampusProvinceNotIn(List<Integer> values) {
            addCriterion("campus_province not in", values, "campusProvince");
            return (Criteria) this;
        }

        public Criteria andCampusProvinceBetween(Integer value1, Integer value2) {
            addCriterion("campus_province between", value1, value2, "campusProvince");
            return (Criteria) this;
        }

        public Criteria andCampusProvinceNotBetween(Integer value1, Integer value2) {
            addCriterion("campus_province not between", value1, value2, "campusProvince");
            return (Criteria) this;
        }

        public Criteria andCampusCityIsNull() {
            addCriterion("campus_city is null");
            return (Criteria) this;
        }

        public Criteria andCampusCityIsNotNull() {
            addCriterion("campus_city is not null");
            return (Criteria) this;
        }

        public Criteria andCampusCityEqualTo(Integer value) {
            addCriterion("campus_city =", value, "campusCity");
            return (Criteria) this;
        }

        public Criteria andCampusCityNotEqualTo(Integer value) {
            addCriterion("campus_city <>", value, "campusCity");
            return (Criteria) this;
        }

        public Criteria andCampusCityGreaterThan(Integer value) {
            addCriterion("campus_city >", value, "campusCity");
            return (Criteria) this;
        }

        public Criteria andCampusCityGreaterThanOrEqualTo(Integer value) {
            addCriterion("campus_city >=", value, "campusCity");
            return (Criteria) this;
        }

        public Criteria andCampusCityLessThan(Integer value) {
            addCriterion("campus_city <", value, "campusCity");
            return (Criteria) this;
        }

        public Criteria andCampusCityLessThanOrEqualTo(Integer value) {
            addCriterion("campus_city <=", value, "campusCity");
            return (Criteria) this;
        }

        public Criteria andCampusCityIn(List<Integer> values) {
            addCriterion("campus_city in", values, "campusCity");
            return (Criteria) this;
        }

        public Criteria andCampusCityNotIn(List<Integer> values) {
            addCriterion("campus_city not in", values, "campusCity");
            return (Criteria) this;
        }

        public Criteria andCampusCityBetween(Integer value1, Integer value2) {
            addCriterion("campus_city between", value1, value2, "campusCity");
            return (Criteria) this;
        }

        public Criteria andCampusCityNotBetween(Integer value1, Integer value2) {
            addCriterion("campus_city not between", value1, value2, "campusCity");
            return (Criteria) this;
        }

        public Criteria andCampusDistrictIsNull() {
            addCriterion("campus_district is null");
            return (Criteria) this;
        }

        public Criteria andCampusDistrictIsNotNull() {
            addCriterion("campus_district is not null");
            return (Criteria) this;
        }

        public Criteria andCampusDistrictEqualTo(Integer value) {
            addCriterion("campus_district =", value, "campusDistrict");
            return (Criteria) this;
        }

        public Criteria andCampusDistrictNotEqualTo(Integer value) {
            addCriterion("campus_district <>", value, "campusDistrict");
            return (Criteria) this;
        }

        public Criteria andCampusDistrictGreaterThan(Integer value) {
            addCriterion("campus_district >", value, "campusDistrict");
            return (Criteria) this;
        }

        public Criteria andCampusDistrictGreaterThanOrEqualTo(Integer value) {
            addCriterion("campus_district >=", value, "campusDistrict");
            return (Criteria) this;
        }

        public Criteria andCampusDistrictLessThan(Integer value) {
            addCriterion("campus_district <", value, "campusDistrict");
            return (Criteria) this;
        }

        public Criteria andCampusDistrictLessThanOrEqualTo(Integer value) {
            addCriterion("campus_district <=", value, "campusDistrict");
            return (Criteria) this;
        }

        public Criteria andCampusDistrictIn(List<Integer> values) {
            addCriterion("campus_district in", values, "campusDistrict");
            return (Criteria) this;
        }

        public Criteria andCampusDistrictNotIn(List<Integer> values) {
            addCriterion("campus_district not in", values, "campusDistrict");
            return (Criteria) this;
        }

        public Criteria andCampusDistrictBetween(Integer value1, Integer value2) {
            addCriterion("campus_district between", value1, value2, "campusDistrict");
            return (Criteria) this;
        }

        public Criteria andCampusDistrictNotBetween(Integer value1, Integer value2) {
            addCriterion("campus_district not between", value1, value2, "campusDistrict");
            return (Criteria) this;
        }

        public Criteria andCampusStreetIsNull() {
            addCriterion("campus_street is null");
            return (Criteria) this;
        }

        public Criteria andCampusStreetIsNotNull() {
            addCriterion("campus_street is not null");
            return (Criteria) this;
        }

        public Criteria andCampusStreetEqualTo(String value) {
            addCriterion("campus_street =", value, "campusStreet");
            return (Criteria) this;
        }

        public Criteria andCampusStreetNotEqualTo(String value) {
            addCriterion("campus_street <>", value, "campusStreet");
            return (Criteria) this;
        }

        public Criteria andCampusStreetGreaterThan(String value) {
            addCriterion("campus_street >", value, "campusStreet");
            return (Criteria) this;
        }

        public Criteria andCampusStreetGreaterThanOrEqualTo(String value) {
            addCriterion("campus_street >=", value, "campusStreet");
            return (Criteria) this;
        }

        public Criteria andCampusStreetLessThan(String value) {
            addCriterion("campus_street <", value, "campusStreet");
            return (Criteria) this;
        }

        public Criteria andCampusStreetLessThanOrEqualTo(String value) {
            addCriterion("campus_street <=", value, "campusStreet");
            return (Criteria) this;
        }

        public Criteria andCampusStreetLike(String value) {
            addCriterion("campus_street like", value, "campusStreet");
            return (Criteria) this;
        }

        public Criteria andCampusStreetNotLike(String value) {
            addCriterion("campus_street not like", value, "campusStreet");
            return (Criteria) this;
        }

        public Criteria andCampusStreetIn(List<String> values) {
            addCriterion("campus_street in", values, "campusStreet");
            return (Criteria) this;
        }

        public Criteria andCampusStreetNotIn(List<String> values) {
            addCriterion("campus_street not in", values, "campusStreet");
            return (Criteria) this;
        }

        public Criteria andCampusStreetBetween(String value1, String value2) {
            addCriterion("campus_street between", value1, value2, "campusStreet");
            return (Criteria) this;
        }

        public Criteria andCampusStreetNotBetween(String value1, String value2) {
            addCriterion("campus_street not between", value1, value2, "campusStreet");
            return (Criteria) this;
        }

        public Criteria andCampusDetailAddrIsNull() {
            addCriterion("campus_detail_addr is null");
            return (Criteria) this;
        }

        public Criteria andCampusDetailAddrIsNotNull() {
            addCriterion("campus_detail_addr is not null");
            return (Criteria) this;
        }

        public Criteria andCampusDetailAddrEqualTo(String value) {
            addCriterion("campus_detail_addr =", value, "campusDetailAddr");
            return (Criteria) this;
        }

        public Criteria andCampusDetailAddrNotEqualTo(String value) {
            addCriterion("campus_detail_addr <>", value, "campusDetailAddr");
            return (Criteria) this;
        }

        public Criteria andCampusDetailAddrGreaterThan(String value) {
            addCriterion("campus_detail_addr >", value, "campusDetailAddr");
            return (Criteria) this;
        }

        public Criteria andCampusDetailAddrGreaterThanOrEqualTo(String value) {
            addCriterion("campus_detail_addr >=", value, "campusDetailAddr");
            return (Criteria) this;
        }

        public Criteria andCampusDetailAddrLessThan(String value) {
            addCriterion("campus_detail_addr <", value, "campusDetailAddr");
            return (Criteria) this;
        }

        public Criteria andCampusDetailAddrLessThanOrEqualTo(String value) {
            addCriterion("campus_detail_addr <=", value, "campusDetailAddr");
            return (Criteria) this;
        }

        public Criteria andCampusDetailAddrLike(String value) {
            addCriterion("campus_detail_addr like", value, "campusDetailAddr");
            return (Criteria) this;
        }

        public Criteria andCampusDetailAddrNotLike(String value) {
            addCriterion("campus_detail_addr not like", value, "campusDetailAddr");
            return (Criteria) this;
        }

        public Criteria andCampusDetailAddrIn(List<String> values) {
            addCriterion("campus_detail_addr in", values, "campusDetailAddr");
            return (Criteria) this;
        }

        public Criteria andCampusDetailAddrNotIn(List<String> values) {
            addCriterion("campus_detail_addr not in", values, "campusDetailAddr");
            return (Criteria) this;
        }

        public Criteria andCampusDetailAddrBetween(String value1, String value2) {
            addCriterion("campus_detail_addr between", value1, value2, "campusDetailAddr");
            return (Criteria) this;
        }

        public Criteria andCampusDetailAddrNotBetween(String value1, String value2) {
            addCriterion("campus_detail_addr not between", value1, value2, "campusDetailAddr");
            return (Criteria) this;
        }

        public Criteria andPersonInChargeIsNull() {
            addCriterion("person_in_charge is null");
            return (Criteria) this;
        }

        public Criteria andPersonInChargeIsNotNull() {
            addCriterion("person_in_charge is not null");
            return (Criteria) this;
        }

        public Criteria andPersonInChargeEqualTo(String value) {
            addCriterion("person_in_charge =", value, "personInCharge");
            return (Criteria) this;
        }

        public Criteria andPersonInChargeNotEqualTo(String value) {
            addCriterion("person_in_charge <>", value, "personInCharge");
            return (Criteria) this;
        }

        public Criteria andPersonInChargeGreaterThan(String value) {
            addCriterion("person_in_charge >", value, "personInCharge");
            return (Criteria) this;
        }

        public Criteria andPersonInChargeGreaterThanOrEqualTo(String value) {
            addCriterion("person_in_charge >=", value, "personInCharge");
            return (Criteria) this;
        }

        public Criteria andPersonInChargeLessThan(String value) {
            addCriterion("person_in_charge <", value, "personInCharge");
            return (Criteria) this;
        }

        public Criteria andPersonInChargeLessThanOrEqualTo(String value) {
            addCriterion("person_in_charge <=", value, "personInCharge");
            return (Criteria) this;
        }

        public Criteria andPersonInChargeLike(String value) {
            addCriterion("person_in_charge like", value, "personInCharge");
            return (Criteria) this;
        }

        public Criteria andPersonInChargeNotLike(String value) {
            addCriterion("person_in_charge not like", value, "personInCharge");
            return (Criteria) this;
        }

        public Criteria andPersonInChargeIn(List<String> values) {
            addCriterion("person_in_charge in", values, "personInCharge");
            return (Criteria) this;
        }

        public Criteria andPersonInChargeNotIn(List<String> values) {
            addCriterion("person_in_charge not in", values, "personInCharge");
            return (Criteria) this;
        }

        public Criteria andPersonInChargeBetween(String value1, String value2) {
            addCriterion("person_in_charge between", value1, value2, "personInCharge");
            return (Criteria) this;
        }

        public Criteria andPersonInChargeNotBetween(String value1, String value2) {
            addCriterion("person_in_charge not between", value1, value2, "personInCharge");
            return (Criteria) this;
        }

        public Criteria andCampusTelIsNull() {
            addCriterion("campus_tel is null");
            return (Criteria) this;
        }

        public Criteria andCampusTelIsNotNull() {
            addCriterion("campus_tel is not null");
            return (Criteria) this;
        }

        public Criteria andCampusTelEqualTo(String value) {
            addCriterion("campus_tel =", value, "campusTel");
            return (Criteria) this;
        }

        public Criteria andCampusTelNotEqualTo(String value) {
            addCriterion("campus_tel <>", value, "campusTel");
            return (Criteria) this;
        }

        public Criteria andCampusTelGreaterThan(String value) {
            addCriterion("campus_tel >", value, "campusTel");
            return (Criteria) this;
        }

        public Criteria andCampusTelGreaterThanOrEqualTo(String value) {
            addCriterion("campus_tel >=", value, "campusTel");
            return (Criteria) this;
        }

        public Criteria andCampusTelLessThan(String value) {
            addCriterion("campus_tel <", value, "campusTel");
            return (Criteria) this;
        }

        public Criteria andCampusTelLessThanOrEqualTo(String value) {
            addCriterion("campus_tel <=", value, "campusTel");
            return (Criteria) this;
        }

        public Criteria andCampusTelLike(String value) {
            addCriterion("campus_tel like", value, "campusTel");
            return (Criteria) this;
        }

        public Criteria andCampusTelNotLike(String value) {
            addCriterion("campus_tel not like", value, "campusTel");
            return (Criteria) this;
        }

        public Criteria andCampusTelIn(List<String> values) {
            addCriterion("campus_tel in", values, "campusTel");
            return (Criteria) this;
        }

        public Criteria andCampusTelNotIn(List<String> values) {
            addCriterion("campus_tel not in", values, "campusTel");
            return (Criteria) this;
        }

        public Criteria andCampusTelBetween(String value1, String value2) {
            addCriterion("campus_tel between", value1, value2, "campusTel");
            return (Criteria) this;
        }

        public Criteria andCampusTelNotBetween(String value1, String value2) {
            addCriterion("campus_tel not between", value1, value2, "campusTel");
            return (Criteria) this;
        }

        public Criteria andEmailIsNull() {
            addCriterion("email is null");
            return (Criteria) this;
        }

        public Criteria andEmailIsNotNull() {
            addCriterion("email is not null");
            return (Criteria) this;
        }

        public Criteria andEmailEqualTo(String value) {
            addCriterion("email =", value, "email");
            return (Criteria) this;
        }

        public Criteria andEmailNotEqualTo(String value) {
            addCriterion("email <>", value, "email");
            return (Criteria) this;
        }

        public Criteria andEmailGreaterThan(String value) {
            addCriterion("email >", value, "email");
            return (Criteria) this;
        }

        public Criteria andEmailGreaterThanOrEqualTo(String value) {
            addCriterion("email >=", value, "email");
            return (Criteria) this;
        }

        public Criteria andEmailLessThan(String value) {
            addCriterion("email <", value, "email");
            return (Criteria) this;
        }

        public Criteria andEmailLessThanOrEqualTo(String value) {
            addCriterion("email <=", value, "email");
            return (Criteria) this;
        }

        public Criteria andEmailLike(String value) {
            addCriterion("email like", value, "email");
            return (Criteria) this;
        }

        public Criteria andEmailNotLike(String value) {
            addCriterion("email not like", value, "email");
            return (Criteria) this;
        }

        public Criteria andEmailIn(List<String> values) {
            addCriterion("email in", values, "email");
            return (Criteria) this;
        }

        public Criteria andEmailNotIn(List<String> values) {
            addCriterion("email not in", values, "email");
            return (Criteria) this;
        }

        public Criteria andEmailBetween(String value1, String value2) {
            addCriterion("email between", value1, value2, "email");
            return (Criteria) this;
        }

        public Criteria andEmailNotBetween(String value1, String value2) {
            addCriterion("email not between", value1, value2, "email");
            return (Criteria) this;
        }

        public Criteria andCreateByIsNull() {
            addCriterion("create_by is null");
            return (Criteria) this;
        }

        public Criteria andCreateByIsNotNull() {
            addCriterion("create_by is not null");
            return (Criteria) this;
        }

        public Criteria andCreateByEqualTo(Integer value) {
            addCriterion("create_by =", value, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByNotEqualTo(Integer value) {
            addCriterion("create_by <>", value, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByGreaterThan(Integer value) {
            addCriterion("create_by >", value, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByGreaterThanOrEqualTo(Integer value) {
            addCriterion("create_by >=", value, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByLessThan(Integer value) {
            addCriterion("create_by <", value, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByLessThanOrEqualTo(Integer value) {
            addCriterion("create_by <=", value, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByIn(List<Integer> values) {
            addCriterion("create_by in", values, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByNotIn(List<Integer> values) {
            addCriterion("create_by not in", values, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByBetween(Integer value1, Integer value2) {
            addCriterion("create_by between", value1, value2, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByNotBetween(Integer value1, Integer value2) {
            addCriterion("create_by not between", value1, value2, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNull() {
            addCriterion("create_time is null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNotNull() {
            addCriterion("create_time is not null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeEqualTo(Date value) {
            addCriterion("create_time =", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotEqualTo(Date value) {
            addCriterion("create_time <>", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThan(Date value) {
            addCriterion("create_time >", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("create_time >=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThan(Date value) {
            addCriterion("create_time <", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThanOrEqualTo(Date value) {
            addCriterion("create_time <=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIn(List<Date> values) {
            addCriterion("create_time in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotIn(List<Date> values) {
            addCriterion("create_time not in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeBetween(Date value1, Date value2) {
            addCriterion("create_time between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotBetween(Date value1, Date value2) {
            addCriterion("create_time not between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andUpdateByIsNull() {
            addCriterion("update_by is null");
            return (Criteria) this;
        }

        public Criteria andUpdateByIsNotNull() {
            addCriterion("update_by is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateByEqualTo(Integer value) {
            addCriterion("update_by =", value, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByNotEqualTo(Integer value) {
            addCriterion("update_by <>", value, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByGreaterThan(Integer value) {
            addCriterion("update_by >", value, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByGreaterThanOrEqualTo(Integer value) {
            addCriterion("update_by >=", value, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByLessThan(Integer value) {
            addCriterion("update_by <", value, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByLessThanOrEqualTo(Integer value) {
            addCriterion("update_by <=", value, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByIn(List<Integer> values) {
            addCriterion("update_by in", values, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByNotIn(List<Integer> values) {
            addCriterion("update_by not in", values, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByBetween(Integer value1, Integer value2) {
            addCriterion("update_by between", value1, value2, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByNotBetween(Integer value1, Integer value2) {
            addCriterion("update_by not between", value1, value2, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNull() {
            addCriterion("update_time is null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNotNull() {
            addCriterion("update_time is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeEqualTo(Date value) {
            addCriterion("update_time =", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotEqualTo(Date value) {
            addCriterion("update_time <>", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThan(Date value) {
            addCriterion("update_time >", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("update_time >=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThan(Date value) {
            addCriterion("update_time <", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThanOrEqualTo(Date value) {
            addCriterion("update_time <=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIn(List<Date> values) {
            addCriterion("update_time in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotIn(List<Date> values) {
            addCriterion("update_time not in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeBetween(Date value1, Date value2) {
            addCriterion("update_time between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotBetween(Date value1, Date value2) {
            addCriterion("update_time not between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andIsdeleteIsNull() {
            addCriterion("isdelete is null");
            return (Criteria) this;
        }

        public Criteria andIsdeleteIsNotNull() {
            addCriterion("isdelete is not null");
            return (Criteria) this;
        }

        public Criteria andIsdeleteEqualTo(Byte value) {
            addCriterion("isdelete =", value, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteNotEqualTo(Byte value) {
            addCriterion("isdelete <>", value, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteGreaterThan(Byte value) {
            addCriterion("isdelete >", value, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteGreaterThanOrEqualTo(Byte value) {
            addCriterion("isdelete >=", value, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteLessThan(Byte value) {
            addCriterion("isdelete <", value, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteLessThanOrEqualTo(Byte value) {
            addCriterion("isdelete <=", value, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteIn(List<Byte> values) {
            addCriterion("isdelete in", values, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteNotIn(List<Byte> values) {
            addCriterion("isdelete not in", values, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteBetween(Byte value1, Byte value2) {
            addCriterion("isdelete between", value1, value2, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteNotBetween(Byte value1, Byte value2) {
            addCriterion("isdelete not between", value1, value2, "isdelete");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}