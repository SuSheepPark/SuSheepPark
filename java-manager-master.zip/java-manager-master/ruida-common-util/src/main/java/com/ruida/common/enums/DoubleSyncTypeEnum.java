package com.ruida.common.enums;


/**
 * @author wy
 * @description 双师同步类型 日志使用
 * @date 2021/6/8
 */
public enum DoubleSyncTypeEnum {

    HAND(1,"手动"),
    AUTO(2,"自动"),
    ;

    private Integer id;
    private String type;

    DoubleSyncTypeEnum(Integer id, String type) {
        this.id = id;
        this.type = type;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }}
