package com.ruida.assessment.assessmentcommon.enums;

/**
 * @author wy
 * @description  结构树移动枚举类
 * @date 2020/6/13
 */
public enum MoveTreeEnum {
    UP(0,"上移"),
    DOWN(1,"下移"),
    UPGRADE(2,"升级"),
    ;

    private Integer K;
    private String V;

    MoveTreeEnum(Integer k, String v) {
        K = k;
        V = v;
    }

    public Integer getK() {
        return K;
    }

    public void setK(Integer k) {
        K = k;
    }

    public String getV() {
        return V;
    }

    public void setV(String v) {
        V = v;
    }

    public static DeleteStatusEnum getValueById(Integer K){
        for(DeleteStatusEnum deleteStatusEnum : DeleteStatusEnum.values() ){
            if(deleteStatusEnum.getK().equals(K)){
                return  deleteStatusEnum;
            }
        }
        return null;
    }
}
