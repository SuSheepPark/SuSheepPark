package com.ruida.common.util.excel;

import java.util.List;

/**
 * Created by Administrator on 2017/4/19.
 */
public interface ExcelBatchIntercepter<T> {

    public void onRowConvertComplete(boolean success, T rowBean, List<String> orginColumns, String errorMsg, int index);
}
