package com.ruida.mockdao.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.dto.PersonCenterDTO;
import com.ruida.mockdao.model.QuestionMark;
import com.ruida.mockdao.vo.MarkQuestionVO;
import com.ruida.mockdao.vo.QuestionVO;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * 试题标记表 Mapper 接口
 * </p>
 *
 * @author chenjy
 * @since 2020-07-09
 */
public interface QuestionMarkMapper extends BaseMapper<QuestionMark> {

    /**
     * 列出每个科目的标记试题情况
     */
    List<Map<String,Object>> listSubjectMarks(@Param("userId") String userId,@Param("stageId") Integer stageId);

    /**
     * 删除标记的试题
     * @param questionIdList
     * @param userId
     * @return
     */
    int deleteMarkedQuestion(@Param("list") List<String> questionIdList, @Param("userId") String userId);

    /**
     * 分页查询标记的试题
     * @param req
     * @return
     */
    List<QuestionVO> listMarkedQuestion(@Param("req") PersonCenterDTO req);

    /**
     * 标记的试题总数
     * @param req
     * @return
     */
    int countMarkedQuestion(@Param("req") PersonCenterDTO req);

    /**
     * 查询标记的试题详情
     * @param questionId
     * @param userId
     * @return
     */
    QuestionVO getMarkedQuestionDetailById(@Param("questionId") String questionId,@Param("userId") String userId);

    /**
     * 查询标记试题的子题
     * @param param
     * @return
     */
    List<MarkQuestionVO> getMarkedQuestionChildren(Map param);

    /**
     * 查询标记的试题
     * @param questionId
     * @param userId
     * @return
     */
    QuestionMark selectQuestionMark(@Param("questionId") String questionId,@Param("userId") String userId);

}
