package com.ruida.mockservice.mq.order;


import com.aliyun.openservices.ons.api.Message;
import com.ruida.mockcommon.enums.OrderStatusEnum;
import com.ruida.mockcommon.mq.consumer.MQConsumeService;
import com.ruida.mockcommon.mq.consumer.MQConsumer;
import com.ruida.mockdao.model.Order;
import com.ruida.mockservice.service.OrderService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.Date;


/**
 * Created by jinhu on 2020/8/3.
 * consumer 消费者ID
 * topic
 * tags 同一groupid下tag保持一致,弱化tag的作用,不用tag进行业务区分
 * 实现消息消费
 */
@Slf4j
@Service
@MQConsumer(consumer = "GID-order-status-assessment-", topic = "order-status-topic", tags = "order-assessment")
public class OrderConsumeSend implements MQConsumeService {
    @Autowired
    OrderService orderService;
    @Value("${spring.profiles.active}")
    private String profiles;

    /**
     * 订单状态为待付款时进行消费
     * 消费异常重新消费
     * 其他状态return
     * @param message
     * @return
     */
    @Override
    public boolean consume(Message message) {
        try{
            String str = "OrderId"+ profiles +"_";
            String orderId = message.getKey().substring(str.length());
            log.info("普通订阅接收到的消息的topic是: ->" + message.getTopic() + "消息内容：->" + new String(message.getBody())+" 订单id：->"+orderId);
            Order order = orderService.selectById(orderId);

            if( order != null ){
                if( order.getStatus().equals(OrderStatusEnum.WAITING.getK()) ){
                    log.info("进入取消订单，订单状态：" + order.getStatus());
                    boolean ack = orderService.cancelOrderById(Integer.valueOf(orderId));
                    if (!ack){
                        log.error("订单取消失败 订单ID为:"+orderId);
                    }
                    log.info("更新未支付订单状态为关闭：orderId：" + orderId);
                }
                log.info("更新订单状态成功，订单号:"+orderId+",更新时间："+new Date()+"，原始订单状态");
            }

            return true;
        }catch(Exception e){
            log.error("消费消息异常 key:{} message:{} ex:{}", new Object[]{ message.getKey(),new String(message.getBody()),e});
            return false;
        }
    }
}
