package com.ruida.common.context;

import java.util.HashMap;
import java.util.Map;

public class BaseContextHandle {
    public static ThreadLocal<Map<String, Object>> threadLocal = new ThreadLocal<Map<String, Object>>();
    public static void set(String key, Object value) {
        Map<String, Object> map = threadLocal.get();
        if (map == null) {
            map = new HashMap<String, Object>();
        }
        map.put(key, value);
        threadLocal.set(map);
    }

    public static Object get(String key){
        Map<String, Object> map = threadLocal.get();
        if (map == null) {
            map = new HashMap<String, Object>();
        }
        return map.get(key);
    }

    public static void setUserId(Integer userId){
        set("userId",userId);
    }

    public static void setUserName(String userName){
        set("userName",userName);
    }
    public static Integer getUserId(){
       return (Integer)get("UserId");
    }

    public static String getUserName(){
        return (String)get("userName");
    }

}
