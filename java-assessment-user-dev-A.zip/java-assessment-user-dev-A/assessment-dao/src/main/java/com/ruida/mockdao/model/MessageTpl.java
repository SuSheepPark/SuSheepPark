package com.ruida.mockdao.model;

import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 消息模板表
 * </p>
 *
 * @author Bhj
 * @since 2020-07-09
 */
@TableName("t_message_tpl")
public class MessageTpl extends Model<MessageTpl> {

    private static final long serialVersionUID = 1L;

    /**
     * 消息模板ID
     */
    @TableId(value = "message_tpl_id", type = IdType.AUTO)
    private Integer messageTplId;
    /**
     * 标签
     */
    private String tag;
    /**
     * 消息模板类型(0—系统出发消息<需同时发送手机号码；1—主动推动消息>）
     */
    @TableField("message_tpl_type")
    private Integer messageTplType;
    /**
     * 消息模板编号（0—开课提醒；1—账号注册完成后系统通知；2—购买成功提醒；3—付款提醒）
     */
    @TableField("message_tpl_no")
    private Integer messageTplNo;
    /**
     * 消息模板信息
     */
    private String message;
    /**
     * 是否弹出消息模板（0—不弹出；1—弹出）
     */
    private Integer forpop;
    /**
     * 创建者ID
     */
    @TableField("create_by")
    private Integer createBy;
    /**
     * 创建时间
     */
    @TableField("create_time")
    private Date createTime;
    /**
     * 更新者ID
     */
    @TableField("update_by")
    private Integer updateBy;
    /**
     * 更新时间
     */
    @TableField("update_time")
    private Date updateTime;
    /**
     * 是否删除（0：未删除；1：删除）
     */
    private Integer isdelete;


    public Integer getMessageTplId() {
        return messageTplId;
    }

    public void setMessageTplId(Integer messageTplId) {
        this.messageTplId = messageTplId;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public Integer getMessageTplType() {
        return messageTplType;
    }

    public void setMessageTplType(Integer messageTplType) {
        this.messageTplType = messageTplType;
    }

    public Integer getMessageTplNo() {
        return messageTplNo;
    }

    public void setMessageTplNo(Integer messageTplNo) {
        this.messageTplNo = messageTplNo;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Integer getForpop() {
        return forpop;
    }

    public void setForpop(Integer forpop) {
        this.forpop = forpop;
    }

    public Integer getCreateBy() {
        return createBy;
    }

    public void setCreateBy(Integer createBy) {
        this.createBy = createBy;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(Integer updateBy) {
        this.updateBy = updateBy;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getIsdelete() {
        return isdelete;
    }

    public void setIsdelete(Integer isdelete) {
        this.isdelete = isdelete;
    }

    @Override
    protected Serializable pkVal() {
        return this.messageTplId;
    }

    @Override
    public String toString() {
        return "TMessageTpl{" +
        ", messageTplId=" + messageTplId +
        ", tag=" + tag +
        ", messageTplType=" + messageTplType +
        ", messageTplNo=" + messageTplNo +
        ", message=" + message +
        ", forpop=" + forpop +
        ", createBy=" + createBy +
        ", createTime=" + createTime +
        ", updateBy=" + updateBy +
        ", updateTime=" + updateTime +
        ", isdelete=" + isdelete +
        "}";
    }
}
