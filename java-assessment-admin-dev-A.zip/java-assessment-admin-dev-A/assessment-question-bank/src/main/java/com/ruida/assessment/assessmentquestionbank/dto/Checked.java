package com.ruida.assessment.assessmentquestionbank.dto;

import lombok.Data;

import java.io.Serializable;
import java.util.List;
@Data
public class Checked implements Serializable {
    List<Integer> content;
    Integer id;
}
