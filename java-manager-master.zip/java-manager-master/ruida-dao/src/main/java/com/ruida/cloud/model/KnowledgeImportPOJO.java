package com.ruida.cloud.model;

import com.ruida.common.util.excel.ExcelAnnotation;
import lombok.Data;

/**
 * @author admin
 * @description: ${TODO}
 * @Date 2019/6/28
 * @verion 1.0
 */
@Data
public class KnowledgeImportPOJO {
    @ExcelAnnotation(title = "一级知识点")
    private String stage1;
    @ExcelAnnotation(title = "二级知识点")
    private String stage2;
    @ExcelAnnotation(title = "三级知识点")
    private String stage3;
    @ExcelAnnotation(title = "四级知识点")
    private String stage4;
    @ExcelAnnotation(title = "五级知识点")
    private String stage5;
    @ExcelAnnotation(title = "六级知识点")
    private String stage6;
    @ExcelAnnotation(title = "七级知识点")
    private String stage7;
    @ExcelAnnotation(title = "八级知识点")
    private String stage8;
    @ExcelAnnotation(title = "九级知识点")
    private String stage9;
    @ExcelAnnotation(title = "十级知识点")
    private String stage10;
    @ExcelAnnotation(title = "十一级知识点")
    private String stage11;
    @ExcelAnnotation(title = "十二级知识点")
    private String stage12;
    @ExcelAnnotation(title = "上传结果")
    private String result;
    @ExcelAnnotation(title = "上传失败原因")
    private String reson;

}
