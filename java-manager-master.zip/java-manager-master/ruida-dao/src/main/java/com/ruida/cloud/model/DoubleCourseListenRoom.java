package com.ruida.cloud.model;

import lombok.Data;

@Data
public class DoubleCourseListenRoom {

    /*
    设备号（教室id）
     */
   private String device_id;
   private String class_name;

   /*
   身份 0:学生端 1:老师端
    */
   private Integer user_role;
   private Integer status;
   //听课校区
   private Integer zone_id;



}