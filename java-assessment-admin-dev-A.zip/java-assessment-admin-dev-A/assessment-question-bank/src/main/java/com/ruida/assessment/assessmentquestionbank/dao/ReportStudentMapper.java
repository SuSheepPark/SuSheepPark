package com.ruida.assessment.assessmentquestionbank.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.ruida.assessment.assessmentquestionbank.dto.ReportDTO;
import com.ruida.assessment.assessmentquestionbank.model.TTestPaperProductRel;
import com.ruida.assessment.assessmentquestionbank.vo.ReportKnowledgeInfoVO;
import com.ruida.assessment.assessmentquestionbank.vo.ReportStudentQuestionVO;
import com.ruida.assessment.assessmentquestionbank.vo.ReportVO;

/**
 * @description: 学生个人报告数据库层接口
 * @author: kgz
 * @date: 2021/5/12
 */
@Mapper
public interface ReportStudentMapper{

    /**
     *获取参与考试的用户id
     * @return
     */
    List<Integer> getReportUserIdList(@Param("productId") Integer productId, @Param("testPaperId") Integer testPaperId);


    /**
     * 查詢商品试卷关联信息
     * @param productId
     * @param testPaperId
     * @return
     */
    TTestPaperProductRel selectByProductAndPaperId(@Param("productId") Integer productId, @Param("testPaperId") Integer testPaperId);

    /**
     * 删除学生报告
     * @param productId
     * @param testPaperId
     * @return
     */
    Integer deleteStudentReport(@Param("productId") Integer productId, @Param("testPaperId") Integer testPaperId);

    /**
     * 报告基础信息
     * @param reportDTO
     * @return
     */
    List<ReportVO> selectReportBasicInfo(@Param("req") ReportDTO reportDTO);

    /**
     * 根据用户id查询9+1学校学生数量
     * @param reportDTO
     * @return
     */
    int getNineOneSchoolStudent(@Param("req") ReportDTO reportDTO);

    /**
     * 查询班级平均分、最高分
     * @param reportDTO
     * @return
     */
    List<ReportVO> selectClassAvgTopScore(@Param("req") ReportDTO reportDTO);

    /**
     * 查询学校平均分、最高分
     * @param reportDTO
     * @return
     */
    List<ReportVO> selectSchoolAvgTopScore(@Param("req") ReportDTO reportDTO);

    /**
     * 查询联考平均分、最高分
     * @param reportDTO
     * @return
     */
    ReportVO selectUnionAvgTopScore(@Param("req") ReportDTO reportDTO);

    /**
     * 查询试卷的9+1商品id
     * @param reportDTO
     * @return
     */
    Integer getNineOneProductId(@Param("req") ReportDTO reportDTO);

    /**
     * 查询9+1学校平均分、最高分
     * @param reportDTO
     * @return
     */
    ReportVO selectNineOneAvgTopScore(@Param("req") ReportDTO reportDTO);

    /**
     * 查询学生报告试题信息
     * @param reportDTO
     * @return
     */
    List<ReportStudentQuestionVO> selectReportQuestionInfo(@Param("req") ReportDTO reportDTO);

    /**
     * 查询9+1学校id
     * @return
     */
    List<Integer> getNineOneSchoolIdList();

    /**
     * 查询报告知识点掌握信息
     * @param reportDTO
     * @return
     */
    List<ReportKnowledgeInfoVO> selectReportKonwledgeInfo(@Param("req") ReportDTO reportDTO);
}
