package com.ruida.mockcommon.auth.utils;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.ruida.mockcommon.auth.CommonConstants;
import com.ruida.mockcommon.auth.JwtConstants;
import com.ruida.mockcommon.auth.pojo.JWTInfo;
import com.ruida.mockcommon.enums.AuthCheckCLient;
import com.ruida.mockcommon.enums.AuthCheckType;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

/**
 * token 工具类
 * 
 * @author mlzhang3
 */
public class JwtTokenUtil {
	/**
	 * 获取token中的用户信息
	 *
	 * @param token
	 * @return
	 * @throws Exception
	 */
	public static JWTInfo getInfoFromToken(String token) throws Exception {
		Jws<Claims> claimsJws = parserToken(token);
		Claims body = claimsJws.getBody();
		return new JWTInfo(StringHelper.getObjectValue(body.get(CommonConstants.JWT_KEY_NAME)),
				StringHelper.getObjectValue(body.get(CommonConstants.JWT_KEY_USER_ID)),
				StringHelper.getObjectValue(body.get(CommonConstants.JWT_KEY_SOURCE)));
	}

	/**
	 * 获取token中的用户信息
	 *
	 * @param token
	 * @return
	 * @throws Exception
	 */
	public static JWTInfo getStudentInfoFromToken(String token) throws Exception {
		Jws<Claims> claimsJws = parserToken(token);
		Claims body = claimsJws.getBody();
		return new JWTInfo(StringHelper.getObjectValue(body.get(CommonConstants.JWT_KEY_STUNO)),
				StringHelper.getObjectValue(body.get(CommonConstants.JWT_KEY_SOURCE)));
	}

	/**
	 * 解析token
	 * 
	 * @param token
	 * @return
	 * @throws Exception
	 */
	public static Jws<Claims> parserToken(String token) throws Exception {
		Jws<Claims> claimsJws = Jwts.parser().setSigningKey(JwtConstants.SECRET).parseClaimsJws(token);
		return claimsJws;
	}

	/**
	 * 获取用户名从token中
	 */
	public static String getUsernameFromToken(String token) {
		return getClaimFromToken(token).getSubject();
	}

	/**
	 * 获取jwt发布时间
	 */
	public static Date getIssuedAtDateFromToken(String token) {
		return getClaimFromToken(token).getIssuedAt();
	}

	/**
	 * 获取jwt失效时间
	 */
	public static Date getExpirationDateFromToken(String token) {
		return getClaimFromToken(token).getExpiration();
	}

	/**
	 * 获取jwt接收者
	 */
	public static String getAudienceFromToken(String token) {
		return getClaimFromToken(token).getAudience();
	}

	/**
	 * 获取私有的jwt claim
	 */
	public static String getPrivateClaimFromToken(String token, String key) {
		Object object = getClaimFromToken(token).get(key);
		return object == null ? null : object.toString();
	}

	/**
	 * 获取jwt的payload部分
	 */
	public static Claims getClaimFromToken(String token) {
		return Jwts.parser().setSigningKey(JwtConstants.SECRET).parseClaimsJws(token).getBody();
	}

	/**
	 * 解析token是否正确,不正确会报异常<br>
	 */
	public static void parseToken(String token) throws JwtException {
		Jwts.parser().setSigningKey(JwtConstants.SECRET).parseClaimsJws(token).getBody();
	}

	/**
	 * <pre>
	 *  验证token是否失效
	 *  true:过期   false:没过期
	 * </pre>
	 */
	public static Boolean isTokenExpired(String token) {
		try {
			final Date expiration = getExpirationDateFromToken(token);
			return expiration.before(new Date());
		} catch (ExpiredJwtException expiredJwtException) {
			return true;
		}
	}

	/**
	 * 生成token(通过用户名和签名时候用的随机数)
	 */
	public static String generateToken(JWTInfo jwtInfo) {
		return doGenerateToken(jwtInfo, JwtConstants.EXPIRATION * 1000, AuthCheckType.USER, AuthCheckCLient.WEB);
	}

	/**
	 * 生成token
	 */
	private static String doGenerateToken(JWTInfo jwtInfo, long time, AuthCheckType type, AuthCheckCLient client) {
		final Date createdDate = new Date();
		final Date expirationDate = new Date(createdDate.getTime() + time);

		return Jwts.builder().claim(CommonConstants.JWT_KEY_USER_ID, jwtInfo.getUserId())
				.claim(CommonConstants.JWT_KEY_NAME, jwtInfo.getUsername())
				.claim(CommonConstants.JWT_KEY_SOURCE, jwtInfo.getSource())
				.claim(CommonConstants.JWT_KEY_PERSONID, jwtInfo.getPersonId())
				.claim(CommonConstants.JWT_KEY_STUNO, jwtInfo.getStuId()).claim(CommonConstants.JWT_KEY_TYPE, type)
				.claim(CommonConstants.JWT_KEY_CLIENT, client).setSubject(jwtInfo.getUsername())
				.setIssuedAt(createdDate).setExpiration(expirationDate)
				.signWith(SignatureAlgorithm.HS512, JwtConstants.SECRET).compact();
	}

	/**
	 * 微信小程序生成token(通过用户名和签名时候用的随机数)
	 */
	public static String generateWXToken(JWTInfo jwtInfo) {
		Map<String, Object> claims = new HashMap<>();
		return doGenerateToken(jwtInfo, JwtConstants.EXPIRATION * 1000000, AuthCheckType.USER, AuthCheckCLient.WX);
	}

//    /**
//     * 生成token
//     */
//    private static String doGenerateWXToken(JWTInfo jwtInfo) {
//        final Date createdDate = new Date();
//        final Date expirationDate = new Date(createdDate.getTime() + JwtConstants.EXPIRATION * 1000000);
//
//        return Jwts.builder()
//                .claim(CommonConstants.JWT_KEY_USER_ID,jwtInfo.getUserId())
//                .claim(CommonConstants.JWT_KEY_NAME,jwtInfo.getUsername())
//                .claim(CommonConstants.JWT_KEY_SOURCE,jwtInfo.getSource())
//                .claim(CommonConstants.JWT_KEY_PERSONID,jwtInfo.getPersonId())
//                .setSubject(jwtInfo.getUsername())
//                .setIssuedAt(createdDate)
//                .setExpiration(expirationDate)
//                .signWith(SignatureAlgorithm.HS512, JwtConstants.SECRET)
//                .compact();
//    }

	/**
	 * 通过准考证登录的考生，无用户
	 */
	public static String generateStudentToken(JWTInfo jwtInfo, long time) {
		return doGenerateToken(jwtInfo, time, AuthCheckType.STUDENT, AuthCheckCLient.WEB);
	}
}
