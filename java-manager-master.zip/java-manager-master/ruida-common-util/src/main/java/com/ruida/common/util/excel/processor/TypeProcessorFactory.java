package com.ruida.common.util.excel.processor;

import com.ruida.common.util.excel.processor.impl.*;

/**
 * Created by Administrator on 2017/4/20.
 */
public class TypeProcessorFactory {

    private TypeProcessorFactory(){
    }

    public static class Singleton{
        public static TypeProcessorFactory instance = new TypeProcessorFactory();
    }

    public static TypeProcessorFactory getInstance(){
        return Singleton.instance;
    }

    public TypeProcessor getProcessor(String paramClassString, int scale, String dateFormat){
        if("class java.util.Date".equals(paramClassString)){
            return new DateProcessorImpl(dateFormat);
        }else if("class java.lang.Boolean".equals(paramClassString)){
            return new BooleanProcessorImpl();
        }else if("class java.lang.String".equals(paramClassString)){
            return new StringProcessorImpl();
        }else if("class java.lang.Integer".equals(paramClassString)){
            return new IntegerProcessorImpl();
        }else if("class java.lang.Long".equals(paramClassString)){
            return new LongProcessorImpl();
        }else if("class java.math.BigDecimal".equals(paramClassString)){
            return new BigDecimalProcessorImpl(scale);
        }
        return null;
    }

}
