package com.ruida.assessment.assessmentcommon.enums;

/**
 * @description: 班级学报告中各部分数据的类型
 * @author: kgz
 * @date: 2021/9/9
 */
public enum ReportPartTypeEnum {
    STUDENT_SCORE_INFOS("getStudentScoreInfos","班内学生本次考试得分情况"),
    COUNT_SCHOOL_GLOBAL_SCORE("countSchoolGlobalScore","本年级整体情况"),
    CLASS_SCORE_INFO("getClassScoreInfo","各班考试得分情况"),
    COUNT_CLASS_SCORE("countClassScore","各分数段的人数"),
    KNOWLEDGE_STATISTICS("getKnowledgeStatistics","知识掌握优势与不足诊断"),
    TARGET_STATISTICS("getTargetStatistics","考查要求掌握优势与不足诊断"),
    TOP_10_STUDENT_SCORE_INFO("getTop10StudentScoreInfo","本年级前10名学生名单"),
    QUESTION_SCORE_INFO("getQuestionScoreInfo","试题得分情况"),
    CHOICE_QUESTION_ANALYSIS("countSchoolClassChoiceQuestionAnalysis","选择题选项分析"),
    ;


    private String K;
    private String V;

    ReportPartTypeEnum(String k, String v) {
        K = k;
        V = v;
    }

    public String getK() {
        return K;
    }

    public void setK(String k) {
        K = k;
    }

    public String getV() {
        return V;
    }

    public void setV(String v) {
        V = v;
    }


    public static ReportPartTypeEnum getValueById(String K){
        for(ReportPartTypeEnum reportPartTypeEnum : ReportPartTypeEnum.values() ){
            if(reportPartTypeEnum.getK().equals(K)){
                return  reportPartTypeEnum;
            }
        }
        return null;
    }
}
