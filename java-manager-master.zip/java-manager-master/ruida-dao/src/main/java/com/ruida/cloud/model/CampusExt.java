package com.ruida.cloud.model;

import com.ruida.common.util.excel.ExcelAnnotation;
import org.omg.CORBA.PRIVATE_MEMBER;

import java.io.Serializable;
import java.util.List;

/**
 * @author taosh
 * @create 2019-05-09 11:10
 */
public class CampusExt extends Campus implements Serializable {
    @ExcelAnnotation(title = "校区名称")
    private String campusName;

    @ExcelAnnotation(title = "学段")
    private String periodName;

    @ExcelAnnotation(title = "双师负责人")
    private String personInCharge;

    @ExcelAnnotation(title = "联系方式")
    private String campusTel;

    private String campusProvinceName;

    private String campusCityName;

    private String campusDistrictName;

    private String campusDetailAddr;

    @ExcelAnnotation(title = "省市区")
    private String provinceCityDistrict;

    private String cityId;

    private List<CampusExt> campusExtList;

    @Override
    public String getCampusDetailAddr() {
        return campusDetailAddr;
    }

    @Override
    public void setCampusDetailAddr(String campusDetailAddr) {
        this.campusDetailAddr = campusDetailAddr;
    }

    public String getPeriodName() {
        return periodName;
    }

    public void setPeriodName(String periodName) {
        this.periodName = periodName;
    }

    public String getCityId() {
        return cityId;
    }

    public void setCityId(String cityId) {
        this.cityId = cityId;
    }

    public List<CampusExt> getCampusExtList() {
        return campusExtList;
    }

    public void setCampusExtList(List<CampusExt> campusExtList) {
        this.campusExtList = campusExtList;
    }

    @Override
    public String getPersonInCharge() {
        return personInCharge;
    }

    @Override
    public void setPersonInCharge(String personInCharge) {
        this.personInCharge = personInCharge;
    }

    @Override
    public String getCampusTel() {
        return campusTel;
    }

    @Override
    public void setCampusTel(String campusTel) {
        this.campusTel = campusTel;
    }

    public String getProvinceCityDistrict() {
        return provinceCityDistrict;
    }

    public void setProvinceCityDistrict(String provinceCityDistrict) {
        this.provinceCityDistrict = provinceCityDistrict;
    }

    public String getCampusProvinceName() {
        return campusProvinceName;
    }

    public void setCampusProvinceName(String campusProvinceName) {
        this.campusProvinceName = campusProvinceName;
    }

    public String getCampusCityName() {
        return campusCityName;
    }

    public void setCampusCityName(String campusCityName) {
        this.campusCityName = campusCityName;
    }

    public String getCampusDistrictName() {
        return campusDistrictName;
    }

    public void setCampusDistrictName(String campusDistrictName) {
        this.campusDistrictName = campusDistrictName;
    }

    @Override
    public String getCampusName() {
        return campusName;
    }

    @Override
    public void setCampusName(String campusName) {
        this.campusName = campusName;
    }
}
