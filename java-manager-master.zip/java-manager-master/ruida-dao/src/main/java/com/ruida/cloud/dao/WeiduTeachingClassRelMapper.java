package com.ruida.cloud.dao;

import com.ruida.cloud.model.WeiduTeachingClassRel;
import com.ruida.cloud.model.WeiduTeachingClassRelExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface WeiduTeachingClassRelMapper {
    long countByExample(WeiduTeachingClassRelExample example);

    int deleteByExample(WeiduTeachingClassRelExample example);

    int deleteByPrimaryKey(Integer rid);

    int insert(WeiduTeachingClassRel record);

    int insertSelective(WeiduTeachingClassRel record);

    List<WeiduTeachingClassRel> selectByExample(WeiduTeachingClassRelExample example);

    WeiduTeachingClassRel selectByPrimaryKey(Integer rid);

    int updateByExampleSelective(@Param("record") WeiduTeachingClassRel record, @Param("example") WeiduTeachingClassRelExample example);

    int updateByExample(@Param("record") WeiduTeachingClassRel record, @Param("example") WeiduTeachingClassRelExample example);

    int updateByPrimaryKeySelective(WeiduTeachingClassRel record);

    int updateByPrimaryKey(WeiduTeachingClassRel record);

    List<String> listWeiduTeachClassRel(Integer courseId);
}