package com.ruida.cloud.dao;

import com.ruida.cloud.model.CoursePurchase;
import com.ruida.cloud.model.CoursePurchaseExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface CoursePurchaseMapper {
    long countByExample(CoursePurchaseExample example);

    int deleteByExample(CoursePurchaseExample example);

    int deleteByPrimaryKey(Integer coursePurchaseId);

    int insert(CoursePurchase record);

    int insertSelective(CoursePurchase record);

    List<CoursePurchase> selectByExample(CoursePurchaseExample example);

    CoursePurchase selectByPrimaryKey(Integer coursePurchaseId);

    int updateByExampleSelective(@Param("record") CoursePurchase record, @Param("example") CoursePurchaseExample example);

    int updateByExample(@Param("record") CoursePurchase record, @Param("example") CoursePurchaseExample example);

    int updateByPrimaryKeySelective(CoursePurchase record);

    int updateByPrimaryKey(CoursePurchase record);

    /**
     * 批量插入
     */
    int insertPurchaseBatch(List<CoursePurchase> list);
}