package com.ruida.mockdao.vo.report;

import io.swagger.annotations.ApiModelProperty;

import java.util.List;

/**
 * @description: 历次学校组织的测试得分情况
 * @author: kgz
 * @date: 2020/12/31
 */
public class HisSchoolScoreInfoVO {

    @ApiModelProperty(value = "每个科目得分", name = "eachSubjectScoreInfo")
    private List<HisSchoolSubjectScoreInfoVO> eachSubjectScoreInfo;

    @ApiModelProperty(value = "语数英三科汇总得分", name = "threeSubjectScoreInfo")
    private HisSchoolSubjectScoreInfoVO threeSubjectScoreInfo;

    @ApiModelProperty(value = "所有科目汇总得分", name = "allSubjectScoreInfo")
    private HisSchoolSubjectScoreInfoVO allSubjectScoreInfo;

    public List<HisSchoolSubjectScoreInfoVO> getEachSubjectScoreInfo() {
        return eachSubjectScoreInfo;
    }

    public void setEachSubjectScoreInfo(List<HisSchoolSubjectScoreInfoVO> eachSubjectScoreInfo) {
        this.eachSubjectScoreInfo = eachSubjectScoreInfo;
    }

    public HisSchoolSubjectScoreInfoVO getThreeSubjectScoreInfo() {
        return threeSubjectScoreInfo;
    }

    public void setThreeSubjectScoreInfo(HisSchoolSubjectScoreInfoVO threeSubjectScoreInfo) {
        this.threeSubjectScoreInfo = threeSubjectScoreInfo;
    }

    public HisSchoolSubjectScoreInfoVO getAllSubjectScoreInfo() {
        return allSubjectScoreInfo;
    }

    public void setAllSubjectScoreInfo(HisSchoolSubjectScoreInfoVO allSubjectScoreInfo) {
        this.allSubjectScoreInfo = allSubjectScoreInfo;
    }
}
