package com.ruida.mockdao.vo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.ruida.mockdao.pojo.Choice;
import lombok.Data;

import java.util.List;

/**
 * Created by xumingqi on 2021/7/21 16:59
 */
@Data
@JsonIgnoreProperties(value = {"stem", "answer"})
public class SelfCheckQuestionVO {
    /**
     * 试题id
     */
    private String questionId;

    /**
     * 题号
     */
    private String questionNo;

    /**
     * 题型id
     */
    private Integer questionTypeId;
    /**
     * 题型名称
     */
    private String questionTypeName;

    /**
     * 试题在小节中的排序
     */
    private Integer sort;

    /**
     * 参考答案string
     */
    private String answer;

    /**
     * 参考答案
     */
    private List<Choice> stdAnswer;

    /**
     * 题目序号（组合题使用）
     */
    private Integer questionSort;

    /**
     * 分析
     */
    private String analysis;

    /**
     * 选项string
     */
    private String stem;

    /**
     * 选项 集合类型
     */
    private List<Choice> option;

    /**
     * 试题分数
     */
    private Double score;

    /**
     * 子题
     */
    private List<SelfCheckQuestionVO> child;
}
