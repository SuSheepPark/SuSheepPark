package com.ruida.cloud.model;

import lombok.Data;

/**
 * @author wy
 * @description: 添加课次请求类
 */

@Data
public class DoubleCourseAddLessonsRequest {

    private String title;//课程(课次)名称
    private String teacher_name;//主讲老师姓名
    private String room_id;//room_id
    private String device_id;//授课教室id (主讲设备id)
    private String device_ids;//听课教室id （听讲设备id） 多个教室用逗号,拼接
    private String start_time;//课次 课次 课次 的开始时间  时间戳！
    private String end_time;//课次 课次 课次的 的结束时间  时间戳！
}