package com.ruida.assessment.assessmentquestionbank.imports.domain.model;

import java.util.ArrayList;
import java.util.List;

public class QuestionAnswer {

	private String answerType;
	private List<QuestionAnswerItem> answerItems;
	public String getAnswerType() {
		return answerType;
	}
	public void setAnswerType(String answerType) {
		this.answerType = answerType;
	}
	public List<QuestionAnswerItem> getAnswerItems() {
		return answerItems;
	}
	public void setAnswerItems(List<QuestionAnswerItem> answerItems) {
		this.answerItems = answerItems;
	}
	
	public void addItem(QuestionAnswerItem item) {
		if(this.answerItems==null) {
			this.answerItems=new ArrayList<QuestionAnswerItem>();
		}
		answerItems.add(item);
	}
}
