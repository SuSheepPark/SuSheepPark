package com.ruida.common.util.excel.processor.impl;

import com.ruida.common.util.excel.processor.TypeProcessor;

import java.text.ParseException;

/**
 * Created by Administrator on 2017/4/18.
 */
public class StringProcessorImpl implements TypeProcessor {

    @Override
    public Object fromString(String preValue) throws ParseException {
        return preValue;
    }

    @Override
    public String toString(Object value) throws ParseException {
        if(value == null){
            return "";
        }

        return value.toString();
    }

}
