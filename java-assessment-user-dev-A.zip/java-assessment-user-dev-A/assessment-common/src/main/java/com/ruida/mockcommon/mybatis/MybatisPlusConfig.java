package com.ruida.mockcommon.mybatis;

import com.alibaba.druid.pool.DruidDataSource;
import com.baomidou.mybatisplus.plugins.PaginationInterceptor;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * @author  mlzhang
 */
@Configuration
@EnableTransactionManagement
@MapperScan(basePackages = {"com.ruida.mockdao.dao","com.ruida.mockdao.extdao"})
public class MybatisPlusConfig {
    /**
     * druid配置
     */
    @Bean
    @ConfigurationProperties(prefix = "spring.datasource")
    public DruidProperties druidProperties() {
        return new DruidProperties();
    }
    /**
     * 单数据源连接池配置
     */
    @Bean(name = "dataSource")
    public DruidDataSource dataSource(DruidProperties druidProperties) {
        DruidDataSource dataSource = new DruidDataSource();
        druidProperties.config(dataSource);
        return dataSource;
    }
    /**
     * mybatis-plus分页插件
     */
    @Bean
    public PaginationInterceptor paginationInterceptor() {
        return new PaginationInterceptor();
    }
//    @Bean(name = "sqlSessionFactory")
//    public SqlSessionFactory sqlSessionFactory(@Qualifier("dataSource") DruidDataSource dataSource) throws Exception {
//        MybatisSqlSessionFactoryBean sqlSessionFactoryBean = new MybatisSqlSessionFactoryBean();
//        sqlSessionFactoryBean.setDataSource(dataSource);
//        MybatisConfiguration mybatisConfiguration = new MybatisConfiguration();
//        mybatisConfiguration.setCallSettersOnNulls(true);
//        sqlSessionFactoryBean.setConfiguration(mybatisConfiguration);
//        ResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
//        sqlSessionFactoryBean
//                .setMapperLocations(resolver.getResources("classpath*:mybatis/*Mapper.xml"));
//        return sqlSessionFactoryBean.getObject();
//    }
//
//
//    @Bean
//    public DataSourceTransactionManager dataSourceTransactionManager(@Qualifier("dataSource") DruidDataSource dataSource){
//        return  new DataSourceTransactionManager(dataSource);
//    }

}
