package com.ruida.assessment.assessmentquestionbank.model;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;

import java.io.Serializable;
import java.lang.invoke.SerializedLambda;

/**
 * @description:
 * @author: kgz
 * @date: 2020/6/29
 */
@TableName("t_test_node_question_rel")
public class TTestNodeQuestionRel extends BaseColumn implements Serializable {
    private static final long serialVersionUID = -4628434079168921912L;
    /**
     * 小节与试题关联关系id
     */
    @TableId
    private Integer relId;

    /**
     * 小节id
     */
    private Integer nodeId;

    /**
     * 试卷id
     */
    private Integer testPaperId;

    /**
     * 试题id
     */
    private String questionId;

    /**
     * 题型
     */
    private Integer questionTypeId;

    /**
     * 父级试题id
     */
    private String parentId;

    /**
     * 题号
     */
    private String num;

    /**
     * 分值
     */
    private Double score;

    /**
     * 漏选得分
     */
    private Double regressionScore;
    /**
     * 排序
     */
    private Integer sort;
    /**
     * 试题引用状态（0 已引用； 1 退回引用）
     */
    private Integer relStatus;
    /**
     * 退回原因
     */
    private String rejectReason;
    /**
     * 试题引用状态（0 非补位； 1 补位）
     */
    private Integer isfill;
    /**
     * 补位的范围
     */
    private Integer fillRange;

    /**
     * 赋分类型，填空题使用，0-每空给分，1-单空给分
     */
    private Integer scoreType;

    /**
     * 每空分值，填空题使用，逗号分隔
     */
    private String scoreEachBlank;

    public Double getRegressionScore() {
        return regressionScore;
    }

    public void setRegressionScore(Double regressionScore) {
        this.regressionScore = regressionScore;
    }

    public Integer getRelId() {
        return relId;
    }

    public void setRelId(Integer relId) {
        this.relId = relId;
    }

    public Integer getNodeId() {
        return nodeId;
    }

    public void setNodeId(Integer nodeId) {
        this.nodeId = nodeId;
    }

    public String getQuestionId() {
        return questionId;
    }

    public void setQuestionId(String questionId) {
        this.questionId = questionId;
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public Double getScore() {
        return score;
    }

    public void setScore(Double score) {
        this.score = score;
    }

    public Integer getSort() {
        return sort;
    }

    public void setSort(Integer sort) {
        this.sort = sort;
    }

    public Integer getQuestionTypeId() {
        return questionTypeId;
    }

    public void setQuestionTypeId(Integer questionTypeId) {
        this.questionTypeId = questionTypeId;
    }

    public Integer getTestPaperId() {
        return testPaperId;
    }

    public void setTestPaperId(Integer testPaperId) {
        this.testPaperId = testPaperId;
    }

    public String getNum() {
        return num;
    }

    public void setNum(String num) {
        this.num = num;
    }
    public Integer getRelStatus() {
        return relStatus;
    }

    public void setRelStatus(Integer relStatus) {
        this.relStatus = relStatus;
    }

    public String getRejectReason() {
        return rejectReason;
    }

    public void setRejectReason(String rejectReason) {
        this.rejectReason = rejectReason;
    }

    public Integer getIsfill() {
        return isfill;
    }

    public void setIsfill(Integer isfill) {
        this.isfill = isfill;
    }

    public Integer getFillRange() {
        return fillRange;
    }

    public void setFillRange(Integer fillRange) {
        this.fillRange = fillRange;
    }

    public Integer getScoreType() {
        return scoreType;
    }

    public void setScoreType(Integer scoreType) {
        this.scoreType = scoreType;
    }

    public String getScoreEachBlank() {
        return scoreEachBlank;
    }

    public void setScoreEachBlank(String scoreEachBlank) {
        this.scoreEachBlank = scoreEachBlank;
    }

    @Override
    public String toString() {
        return "TTestNodeQuestionRel{" +
                "relId=" + relId +
                ", nodeId=" + nodeId +
                ", testPaperId=" + testPaperId +
                ", questionId='" + questionId + '\'' +
                ", questionTypeId=" + questionTypeId +
                ", parentId='" + parentId + '\'' +
                ", num='" + num + '\'' +
                ", score=" + score +
                ", regressionScore=" + regressionScore +
                ", sort=" + sort +
                ", relStatus=" + relStatus +
                ", rejectReason='" + rejectReason + '\'' +
                ", isfill=" + isfill +
                ", fillRange=" + fillRange +
                ", scoreType=" + scoreType +
                ", scoreEachBlank=" + scoreEachBlank +
                '}';
    }
}
