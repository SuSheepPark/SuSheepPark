package com.ruida.assessment.assessmentquestionbank.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.assessment.assessmentquestionbank.model.TQuestionKnowledgeRelation;
import org.apache.ibatis.annotations.Mapper;

/**
 * @description: 试题知识点关联关系dao层接口
 * @author: kgz
 * @date: 2020/6/12
 */
@Mapper
public interface QuestionKnowledgeRelationMapper extends BaseMapper<TQuestionKnowledgeRelation> {
}
