package com.ruida.assessment.assessmentquestionbank.controller;

import com.ruida.assessment.assessmentcommon.enums.ResultStatusCode;
import com.ruida.assessment.assessmentcommon.result.BaseResult;
import com.ruida.assessment.assessmentcommon.result.ListResult;
import com.ruida.assessment.assessmentcommon.result.PageData;
import com.ruida.assessment.assessmentcommon.result.PojoResult;
import com.ruida.assessment.assessmentquestionbank.annotaion.UserAuth;
import com.ruida.assessment.assessmentquestionbank.dto.BatchOperationRequest;
import com.ruida.assessment.assessmentquestionbank.dto.MaterialRequest;
import com.ruida.assessment.assessmentquestionbank.service.IMaterialService;
import com.ruida.assessment.assessmentquestionbank.vo.MaterialVo;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

/**
 * @author wy
 * @description 教材管理业务类
 * @date 2020/6/12
 */
@RequestMapping("/material")
@RestController
public class MaterialController {

    @Resource
    private IMaterialService materialService;

    /*
     * 功能描述   查询教材列表 分页
     * @param
     * @return
     */
    @UserAuth
    @PostMapping("query/materialList")
    public PojoResult queryMaterialList(@RequestBody MaterialRequest request){
        PageData<MaterialVo> pageList = materialService.queryMaterialList(request);
        PojoResult<PageData> result = new PojoResult<>();
        result.setContent(pageList);
        result.setMsg("成功");
        return result;
    }

    /*
     * 功能描述   新增教材
     * @param
     * @return
     */
    @UserAuth
    @PostMapping("insert/addMaterial")
    public BaseResult addMaterial(@RequestBody MaterialRequest request){
        BaseResult result = new BaseResult();
        result.setMsg("操作成功");
        Integer flag = materialService.addMaterial(request);
        if (flag > 0){
            return result;
        } else if (flag == -1) {
            return result.setErrorMessage(ResultStatusCode.MATERIAL_EXIT.getCode(),"该教材已存在,请勿重复添加！");
        }
        return result.setErrorMessage(ResultStatusCode.DEAL_FAIL.getCode(),"操作失败");
    }

    /*
     * 功能描述   单个删除、禁用、启用教材
     * @param
     * @return
     */
    @UserAuth
    @PostMapping("update/updateOrDeleteMaterial")
    public BaseResult updateOrDeleteMaterial(@RequestBody BatchOperationRequest request){
        return materialService.updateOrDeleteMaterial(request);
    }

    /*
     * 功能描述   批量删除、禁用、启用教材
     * @param
     * @return
     */
    @UserAuth
    @PostMapping("update/batchUpdateOrDeleteMaterial")
    public ListResult batchUpdateOrDeleteMaterial(@RequestBody BatchOperationRequest request){

        ListResult result = new ListResult();
        result.setMsg("操作成功");
        List<Integer> list = materialService.batchUpdateOrDeleteMaterial(request);
        result.setContent(list);
        result.setTotalCount(list.size());
        if (CollectionUtils.isEmpty(list)){
            return result;
        }
        return result.setErrorMessage(ResultStatusCode.RELATION_FAIL.getCode(),"删除失败,教材章节关联知识点无法删除");
    }



    /*
     *功能描述 查询可用的教材下拉框列表
     * @param
     * @return
     */
    @UserAuth
    @PostMapping("query/getUsableMaterialList")
    public ListResult getUsableMaterialList(@RequestBody MaterialRequest request){

        ListResult result = new ListResult();
        result.setMsg("成功");
        List<MaterialVo> list = materialService.getUsableMaterialList(request);
        result.setContent(list);
        result.setTotalCount(list.size());
        return result;
    }

}
