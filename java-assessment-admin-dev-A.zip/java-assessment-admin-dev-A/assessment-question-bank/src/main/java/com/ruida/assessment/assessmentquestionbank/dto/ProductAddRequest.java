package com.ruida.assessment.assessmentquestionbank.dto;

import com.ruida.assessment.assessmentquestionbank.model.TTestPaperProductRel;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

/**
 * @author wy
 * @description  添加商品请求类
 * @date 2020/6/24
 */
@Data
public class ProductAddRequest {

    /*
    商品id
     */
    private Integer  productId;

    /*
    商品名称
    */
    private String  productName;

    /*退回原因*/
    private String reason;

    /*
     商品状态 0-已下架 1-已上架
    */
    private Integer status;

    /*
    初始化购买量  不填默认为0
    */
    private Integer initBuyNum = 0;

    /*
    商品图片
    */
    private String productImg;

    /*
    商品描述 html格式
    */
    private String productInfoHtml;

    /*
    学段id  多个学段id用,拼接
    */
    private String periodIds;

    /*
    科目id   多个科目id用 , 分隔
    */
    private String subjectIds;

    /*
    教材版本id  多个教材版本id用,拼接
    */
    private String versionIds;

    /*
    年级id 多个年级id用,拼接 一年级上 一年级下
    */
    private String gradeIds;

    /*
    年份  多个年份用 , 分隔
    */
    private String years;

    /*
    商品添加的试卷集合
     */
    private List<TTestPaperProductRel> paperList = new ArrayList<>();

    /*
    商品添加的预售试卷集合
     */
    private List<PresellTestPaperDto> presellPaperList = new ArrayList<>();

    /*
    保存按钮类型 4-暂存 5-提交 6-删除 7-置顶
     */
    private Integer buttonType;

    /*
    测验形式(0-平时练习 1-纸考(线下联考) 2-机房统考 3-在线统考)
    */
    private Integer productTestWay;

    /*
    试卷份数
    */
    private Integer paperNum;

    /*
    是否隐藏 0-否 1-是
    */
    private Integer ishide;

}
