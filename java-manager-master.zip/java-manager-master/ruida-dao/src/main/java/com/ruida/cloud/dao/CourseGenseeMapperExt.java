package com.ruida.cloud.dao;

import com.ruida.cloud.model.CourseGenseeExt;

import java.util.List;

/**
 * @author szl
 * @description: 展示互动信息获取
 * @Date 2019/5/28
 * @verion 1.0
 */
public interface CourseGenseeMapperExt {
    /**
     * 获取创建课次计划后数据库存储的展示互动关联数据
     * @param courseId
     * @return
     */
    public List <CourseGenseeExt> selectCourseGseenInfoList(Integer courseId);
}
