package com.ruida.assessment.assessmentquestionbank.controller;

import com.ruida.assessment.assessmentcommon.result.MapResult;
import com.ruida.assessment.assessmentcommon.result.PojoResult;
import com.ruida.assessment.assessmentquestionbank.annotaion.UserAuth;
import com.ruida.assessment.assessmentquestionbank.dto.UploadCombinerDTO;
import com.ruida.assessment.assessmentquestionbank.service.AliyunOSSService;
import com.ruida.assessment.assessmentquestionbank.service.IUploadService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.ws.rs.GET;
import java.io.File;

@Controller
@RequestMapping(value = { "/uploadFile" })
public class UploadController {

//	private final Logger logger = LoggerFactory.getLogger(UploadController.class);
//
//	private final String SPRIT = "/";
//	private final String POINTER = "-";
//	private final String TRANSFER_POINTER = "\\.";
	@Resource
	private IUploadService uploadService;
	@Resource
	AliyunOSSService aliyunOSSService;


	/**
	 * 单个文件上传处理
	 *
	 * @param file 上传文件
	 * @param type 对应模块
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value = "/singleFileUpload")
	public MapResult singleFileUpload(@RequestParam MultipartFile file, String type) throws Exception {
		MapResult result = uploadService.singleFileUpload(file, type);
		return result;
	}

	/**
	 * 上传商品封面图
	 */
	@ResponseBody
	@RequestMapping(value = "/uploadProductPic")
	public MapResult uploadProductPic(@RequestParam MultipartFile file) throws Exception {
		MapResult result = uploadService.uploadProductPic(file);
		return result;
	}
	/**
	 * 上传试卷PDF
	 */
	@ResponseBody
	@RequestMapping(value = "/uploadTestPaperPDF")
	@UserAuth
	public MapResult uploadTestPaperPDF(@RequestParam MultipartFile file, Integer testPaperId) throws Exception {
		MapResult result = uploadService.uploadTestPaperPDF(file,testPaperId);
		return result;
	}
	/**
	 * 上传试卷PDF
	 */
	@ResponseBody
	@PostMapping(value = "/uploadCombiner")
//	@UserAuth
	public MapResult uploadCombiner( UploadCombinerDTO uploadCombinerDTO)   {
		MapResult result = uploadService.uploadCombiner(uploadCombinerDTO);
		return result;
	}
	/**
	 * 获取开放文件下载连接
	 */
	@ResponseBody
	@GetMapping(value = "/getOpenUrl")
//	@UserAuth
	public PojoResult getOpenUrl(String objectName)   {
		PojoResult result = new PojoResult();
		 result.setContent(aliyunOSSService.getOpenUrl(objectName));
		return result;
	}

}
