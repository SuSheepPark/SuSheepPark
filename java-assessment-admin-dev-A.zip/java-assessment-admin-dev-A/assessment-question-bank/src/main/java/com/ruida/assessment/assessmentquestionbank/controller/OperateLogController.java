package com.ruida.assessment.assessmentquestionbank.controller;

import com.ruida.assessment.assessmentcommon.result.ListResult;
import com.ruida.assessment.assessmentcommon.result.PageResult;
import com.ruida.assessment.assessmentquestionbank.annotaion.UserAuth;
import com.ruida.assessment.assessmentquestionbank.dto.OperateLogDTO;
import com.ruida.assessment.assessmentquestionbank.dto.OrderQueryDTO;
import com.ruida.assessment.assessmentquestionbank.dto.QueryBaseDTO;
import com.ruida.assessment.assessmentquestionbank.service.OperateLogService;
import com.ruida.assessment.assessmentquestionbank.vo.OperateLogVO;
import com.ruida.assessment.assessmentquestionbank.vo.OrderVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

/**
 * @description: 操作日志控制层
 * @author: kgz
 * @date: 2020/8/18
 */
@RequestMapping("/operateLog")
@RestController
@Api(value ="操作日志相关接口")
public class OperateLogController {

    @Resource
    private OperateLogService operateLogService;

    @UserAuth
    @PostMapping("/getList")
    @ApiOperation(value = "分页查询操作日志列表", notes = "分页查询操作日志列表")
    @ApiImplicitParam(name = "operateLogDTO", value = "查询条件",
            required = true , dataType  = "OperateLogDTO",paramType = "body")
    public PageResult<OperateLogVO> getList(@RequestBody OperateLogDTO operateLogDTO){
        PageResult<OperateLogVO> pageResult = new PageResult();
        pageResult.setContent(operateLogService.getOperateLogList(operateLogDTO));
        return pageResult;
    }

    @GetMapping("/getModuleList")
    @ApiOperation(value = "获取操作模块下拉框列表", notes = "获取操作模块下拉框列表")
    public ListResult getList(){
        ListResult listResult = new ListResult();
        listResult.setContent(operateLogService.getModuleList());
        return listResult;
    }

}
