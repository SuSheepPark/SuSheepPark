package com.ruida.mockcommon.enums;

/**
 * @description: 高校层次枚举
 * @author: kgz
 * @date: 2020/9/24
 */
public enum CollegeLevelEnum {
    FIRST(1,"清华北大"),
    SECOND(2,"华东五校"),
    THIRD(3,"一流大学(985)"),
    FOURTH(4,"一流学科(211)"),
    FIFTH(5,"一段线"),
    SIXTH(6,"二段线"),
    OUT(0,"二段线以下");


    private Integer K;
    private String V;

    CollegeLevelEnum(Integer k, String v) {
        K = k;
        V = v;
    }

    public Integer getK() {
        return K;
    }

    public void setK(Integer k) {
        K = k;
    }

    public String getV() {
        return V;
    }

    public void setV(String v) {
        V = v;
    }


    public static String getValueById(Integer K){
        for(CollegeLevelEnum collegeLevelEnum : CollegeLevelEnum.values() ){
            if(collegeLevelEnum.getK().equals(K)){
                return  collegeLevelEnum.getV();
            }
        }
        return null;
    }

}
