package com.ruida.assessment.assessmentquestionbank.model.ext;

import com.ruida.assessment.assessmentquestionbank.model.TDepartment;
import lombok.Data;

/**
 * @author admin
 * @description: ${TODO}
 * @Date 2019/6/5
 * @verion 1.0
 */
@Data
public class TDepartmentExt extends TDepartment {
    private Integer  departmentId;//部门id
    private String   departmentName;//部门名字
}
