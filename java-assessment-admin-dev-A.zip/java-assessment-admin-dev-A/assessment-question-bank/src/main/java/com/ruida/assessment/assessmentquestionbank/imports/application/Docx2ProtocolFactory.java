package com.ruida.assessment.assessmentquestionbank.imports.application;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import com.ruida.assessment.assessmentquestionbank.imports.docx.DocxReader;
import com.ruida.assessment.assessmentquestionbank.imports.docx.DocxService;
import com.ruida.assessment.assessmentquestionbank.imports.domain.model.ErrorMsgException;
import com.ruida.assessment.assessmentquestionbank.imports.domain.model.Question;
import com.ruida.assessment.assessmentquestionbank.imports.domain.service.DocxProtocol;

/**
 * word对象转换到协议对象的工厂
 * @author mazhuang
 *
 */
public class Docx2ProtocolFactory {

	DocxReader reader;

	public Docx2ProtocolFactory(InputStream inputStream) throws IOException {
		this.reader = new DocxReader(inputStream);
	}

	public List<Question> start() throws ErrorMsgException {
		boolean flag1 = isDocStart();
		if (flag1) {
			return getQuestions();
		} else {
			throw new ErrorMsgException(0, "文档不能正常开始");
		}
	}

	private boolean isDocStart() {
		boolean checkflag = false;
		while (reader.next()) {
			String line = DocxService.getLineText(reader.getLine());
			if (DocxProtocol.checkStart(line)) {
				checkflag = true;
				break;
			}
		}
		return checkflag;
	}

	private List<Question> getQuestions() {
		QuestionFactory questionFactory = new QuestionFactory(reader);
		List<Question> questions = new ArrayList<>();
		while (reader.hasNext()) {
			Question question = questionFactory.getQuestion();
			if (question != null) {
				questions.add(question);
			}
		}
		return questions;
	}
}
