package com.ruida.cloud.dao;

import com.ruida.cloud.model.DoubleStudentClass;
import com.ruida.cloud.model.DoubleStudentClassExample;
import java.util.List;

import com.ruida.cloud.model.DoubleStudentClassRequest;
import org.apache.ibatis.annotations.Param;

public interface DoubleStudentClassMapper {
    int countByExample(DoubleStudentClassExample example);

    int deleteByExample(DoubleStudentClassExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(DoubleStudentClass record);

    int insertSelective(DoubleStudentClass record);

    List<DoubleStudentClass> selectByExample(DoubleStudentClassExample example);

    DoubleStudentClass selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") DoubleStudentClass record, @Param("example") DoubleStudentClassExample example);

    int updateByExample(@Param("record") DoubleStudentClass record, @Param("example") DoubleStudentClassExample example);

    int updateByPrimaryKeySelective(DoubleStudentClass record);

    int updateByPrimaryKey(DoubleStudentClass record);

    int batchDeleteStudentClassRoom(@Param("oldDeviceList") List<DoubleStudentClass> oldDeviceList);

    int batchInsertStudentClassRoom(@Param("newDeviceList")List<DoubleStudentClass> newDeviceList);
}