package com.ruida.cloud.dao;

import java.util.List;
import java.util.Map;

/**
 * @author taosh
 * @create 2020-04-11 16:01
 */
public interface DiscountActivityMapperExt {

    int countDiscountActivityByExample(Map condition);

    List<Map<String, Object>> selectDiscountActivityByExample(Map condition);

    List<Map<String, Object>> listDiscountActivityItem(Integer discountActivityId);

    List<Map<String, Object>> listDiscountActivityItemForEdit(Integer discountActivityId);

    List<Map<String, Object>>listDiscountActivityCourseForEdit(Integer discountActivityId);

    Map<String, Object> getDiscountActivityById(Integer activityId);

    String listDiscountCourseIds(Integer activityId);
}
