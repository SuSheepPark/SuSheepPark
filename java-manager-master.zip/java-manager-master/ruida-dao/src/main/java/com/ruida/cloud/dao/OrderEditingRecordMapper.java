package com.ruida.cloud.dao;

import com.ruida.cloud.model.OrderEditingRecord;
import com.ruida.cloud.model.OrderEditingRecordExample;
import com.ruida.cloud.model.OrderEditingRecordExt;
import org.apache.ibatis.annotations.Param;
import java.util.List;
import java.util.Map;

public interface OrderEditingRecordMapper {
    int countByExample(OrderEditingRecordExample example);

    int deleteByExample(OrderEditingRecordExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(OrderEditingRecord record);

    int insertSelective(OrderEditingRecord record);

    List<OrderEditingRecord> selectByExample(OrderEditingRecordExample example);

    OrderEditingRecord selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") OrderEditingRecord record, @Param("example") OrderEditingRecordExample example);

    int updateByExample(@Param("record") OrderEditingRecord record, @Param("example") OrderEditingRecordExample example);

    int updateByPrimaryKeySelective(OrderEditingRecord record);

    int updateByPrimaryKey(OrderEditingRecord record);

    /**
     * 根据筛选条件查询操作订单记录列表
     * @param param
     * @return
     */
    List<OrderEditingRecordExt> selectByExampleSearch(Map<String,Object> param);

    int countByExampleSearch(Map<String,Object> param);
}