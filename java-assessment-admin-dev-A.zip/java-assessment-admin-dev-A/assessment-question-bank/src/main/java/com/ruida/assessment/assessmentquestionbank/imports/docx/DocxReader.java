package com.ruida.assessment.assessmentquestionbank.imports.docx;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.xwpf.usermodel.IBodyElement;
import org.apache.poi.xwpf.usermodel.XWPFDocument;

import com.ruida.assessment.assessmentquestionbank.imports.domain.model.ErrorMsgException;

public class DocxReader {

	private List<IBodyElement> elements;
	private int i = -1;

	public DocxReader(InputStream inputStream) throws IOException {
		XWPFDocument word;
		word = new XWPFDocument(inputStream);
		elements=word.getBodyElements();
		word.close();
	}

	public boolean hasNext() {
		return i < elements.size() - 1;
	}

	public boolean next() {
		if (i < elements.size() - 1) {
			i++;
			return true;
		} else {
			return false;
		}
	}

	public IBodyElement getLine() {
		if (-1 == i) {
			return null;//
		}
		return elements.get(i);
	}

	public String stepTo(String regex) {
		try {
			return stepTo(regex, null);
		} catch (ErrorMsgException e) {
			return null;
		}
	}

	public String stepTo(String regex, String errorPrefix) throws ErrorMsgException {
		String lineString = DocxService.getLineText(getLine());
		while (!lineString.matches(regex + ".*")
				&& (StringUtils.isEmpty(errorPrefix) || !lineString.startsWith(errorPrefix)) && next()) {
			lineString = DocxService.getLineText(getLine());
		}
		if ((!(StringUtils.isEmpty(errorPrefix) || !lineString.startsWith(errorPrefix)) || !hasNext())
				&& !lineString.matches(regex + ".*")) {
			throw new ErrorMsgException(getLineNum(), "错误的截止符，一直到" + errorPrefix + "或者文档末尾,都没有发现" + regex);
		}
		return lineString;
	}

	public Integer getLineNum() {
		return i + 1;
	}
}
