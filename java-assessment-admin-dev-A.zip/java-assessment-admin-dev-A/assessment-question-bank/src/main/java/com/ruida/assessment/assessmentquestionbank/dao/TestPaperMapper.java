package com.ruida.assessment.assessmentquestionbank.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.assessment.assessmentquestionbank.model.TTestPaper;
import com.ruida.assessment.assessmentquestionbank.vo.ExamRecordListVo;
import com.ruida.assessment.assessmentquestionbank.vo.TestNodeQuestionRelVO;
import com.ruida.assessment.assessmentquestionbank.vo.TestPaperVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @description:
 * @author: kgz
 * @date: 2020/6/28
 */
@Mapper
public interface TestPaperMapper extends BaseMapper<TTestPaper> {
    /**
     * 获取试卷no最大值
     * @return
     * @param date
     */
    String getMaxTestPaperNo(String date);

    /**
     * 获取试卷引用的试题
     * @param testPaperId
     * @param questionStatus
     * @return
     */
    int getTestPaperQuestion(@Param("testPaperId") Integer testPaperId, @Param("questionStatus") Integer questionStatus);
    /**
     * 获取试卷引用的试题没有被退回个数
     * @param testPaperId
     * @return
     */
    int getTestPaperQuestionRel(@Param("testPaperId") Integer testPaperId);

    /*
        根据试卷id查询试卷信息头
     */
    TestPaperVO selectTestPaperInfo(@Param("testPaperId") Integer testPaperId);

    /*
    查询学员测试记录列表
     */
    List<ExamRecordListVo> queryStudentExamRecordList(@Param("userId") Integer userId);

    /**
     * 获取试卷中试题当前最大题号
     * @param testPaperId
     * @return
     */
    int getTestPaperQuestionMaxNum(@Param("testPaperId") Integer testPaperId);

    /**
     * 根据题型获取试题
     * 包括子级试题满足要求的父级试题
     * @param nodeId
     * @param typeIdList
     * @return
     */
    List<TestNodeQuestionRelVO> getChoiceQuestionByNodeId(@Param("nodeId") Integer nodeId, @Param("typeIdList") List<Integer> typeIdList);

    /**
     * 获取试卷节点中子级试题
     * @param testPaperId
     * @param nodeId
     * @param questionId
     * @return
     */
    List<TestNodeQuestionRelVO> getChildrenQuestion(@Param("testPaperId") Integer testPaperId, @Param("nodeId") Integer nodeId, @Param("parentId") String parentId);
}
