package com.ruida.assessment.assessmentquestionbank.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.assessment.assessmentcommon.result.Page;
import com.ruida.assessment.assessmentquestionbank.dto.StudentQueryDTO;
import com.ruida.assessment.assessmentquestionbank.dto.StudentQueryRequest;
import com.ruida.assessment.assessmentquestionbank.model.TStudent;
import com.ruida.assessment.assessmentquestionbank.vo.ClassStuVO;
import com.ruida.assessment.assessmentquestionbank.vo.StudentInfoVo;
import com.ruida.assessment.assessmentquestionbank.vo.StudentVo;
import com.ruida.assessment.scene.web.StudentBySceneVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Update;

import java.util.List;

/**
 * @author wy
 * @description 学员管理Mapper
 * @date 2020/7/31
 */
@Mapper
public interface StudentMapper extends BaseMapper<TStudent> {

    /* 考生列表条件查询 */
    List<StudentVo> queryStudentDataList(@Param("dto") StudentQueryRequest request);

    /* 考生列表条数查询 */
    Integer countStudentDataList(@Param("dto") StudentQueryRequest request);

    /**
     * 获取所有学员的id
     * @return
     */
    List<Integer> getAllStudentId();

    List<TStudent> queryStudentByIdCard(@Param("idCard") String idCard);

    List<TStudent> queryStudentByStuNo(@Param("stuNo") String stuNo);

    List<StudentBySceneVo> queryAllStudentRelList();

    /**
     * 升级操作按班级更新
     * @param classId
     * @param periodId
     * @param gradeId
     * @return
     */
    @Update("UPDATE t_student_rel_info b SET b.`status` = 0,b.end_time = DATE_SUB(curdate(), INTERVAL 1 DAY) ,b.update_time = NOW(),b.update_by = #{userId}\n" +
          "WHERE b.class_id = #{classId} AND b.period_id = #{periodId} AND b.grade_id = #{gradeId}")
    Integer upRankStuInfo(@Param("userId") Integer userId,@Param("classId") Integer classId,@Param("periodId") Integer periodId,@Param("gradeId") Integer gradeId);

    /*
    查询用户绑定的考生（虚拟考生除外）
     */
    List<StudentVo> queryStuListByUserId(@Param("userId") Integer userId);
}
