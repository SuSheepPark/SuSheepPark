package com.ruida.assessment.assessmentquestionbank.dto;

import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

/**
 * 阿里云统一上传接口dto
 */
@Data
public class UploadCombinerDTO {
    /**
     * 文件
     */
    private MultipartFile file;
    /**
     * 最大尺寸
     */
    private Long maxSize;
    /**
     * 期望文件后缀
     */
    private String fileSuffix;
    /**
     * 桶类型（0-共有桶，1-私有桶）
     */
    private Integer bucketType;
    /**
     * 模块
     */
    private String module;
}
