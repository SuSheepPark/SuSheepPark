package com.ruida.common.tree;


import com.ruida.common.util.ValidateMT;

import java.util.Collection;

public class TreeConstant{
	public static String type(Collection<?> c){
		return ValidateMT.isNotNull(c) ? "folder" : "item";
	}
}
