package com.ruida.assessment.assessmentcommon.enums;

import lombok.Getter;

/**
 * Created by xumingqi on 2021/8/16 9:28
 */
@Getter
public enum RotationChartStatusEnum {
    CREATED(0, "待上架"),
    USING(1, "使用中"),
    REMOVED(2, "已下架");

    private final Integer k;
    private final String v;

    RotationChartStatusEnum(Integer k, String v) {
        this.k = k;
        this.v = v;
    }

    public static String getValueById(Integer K) {
        for (RotationChartStatusEnum statusEnum : RotationChartStatusEnum.values()) {
            if (statusEnum.getK().equals(K)) {
                return statusEnum.getV();
            }
        }
        return null;
    }

}
