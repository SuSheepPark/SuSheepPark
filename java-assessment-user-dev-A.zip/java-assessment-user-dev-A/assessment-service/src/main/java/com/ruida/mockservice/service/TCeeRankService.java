package com.ruida.mockservice.service;

import com.ruida.mockdao.model.TCeeRank;
import com.baomidou.mybatisplus.service.IService;

import java.util.Map;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author szl
 * @since 2021-06-02
 */
public interface TCeeRankService extends IService<TCeeRank> {
    /**
     * 两个年份的分数转换
     * @param score
     * @return
     */
    Double getScoreConversion(Double score);

    /**
     * 今天排名
     * @param score
     * @return
     */
    Map<String,Object> thisYearRank(Double score);

}
