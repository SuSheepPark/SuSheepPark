package com.ruida.assessment.assessmentquestionbank.controller;

import com.ruida.assessment.assessmentcommon.result.BaseResult;
import com.ruida.assessment.assessmentcommon.result.ListResult;
import com.ruida.assessment.assessmentcommon.result.PageData;
import com.ruida.assessment.assessmentcommon.result.PojoResult;
import com.ruida.assessment.assessmentquestionbank.annotaion.UserAuth;
import com.ruida.assessment.assessmentquestionbank.dto.BatchOperationRequest;
import com.ruida.assessment.assessmentquestionbank.dto.SchoolRequest;
import com.ruida.assessment.assessmentquestionbank.model.TGrade;
import com.ruida.assessment.assessmentquestionbank.model.TSchool;
import com.ruida.assessment.assessmentquestionbank.service.ISchoolService;
import com.ruida.assessment.assessmentquestionbank.vo.ClassVo;
import com.ruida.assessment.assessmentquestionbank.vo.SchoolClassTaskVO;
import com.ruida.assessment.assessmentquestionbank.vo.SchoolVo;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

/**
 * @author wy
 * @description 学校管理业务类
 * @date 2020/7/24
 */
@RequestMapping("/school")
@RestController
public class SchoolController {
    @Resource
    private ISchoolService schoolService;


    /*
     * 功能描述   查询学校列表 分页
     * @param
     * @return
     */
    @PostMapping("query/schoolList")
    public PojoResult querySchoolList(@RequestBody SchoolRequest request){
        PageData<SchoolVo> pageList = schoolService.querySchoolList(request);
        PojoResult<PageData> result = new PojoResult<>();
        result.setContent(pageList);
        return result;
    }

    /*
     *功能描述 禁用、启用、删除学校
     * @param
     * @return
     */
    @UserAuth
    @PostMapping("update/updateOrDeleteSchool")
    public BaseResult updateOrDeleteSchool(@RequestBody BatchOperationRequest request){
        return schoolService.updateOrDeleteSchool(request);
    }


    /*
     *功能描述 新增、修改学校
     * @param
     * @return
     */
    @UserAuth
    @PostMapping("save/saveSchool")
    public BaseResult saveSchool(@RequestBody SchoolRequest request){
        return schoolService.saveSchool(request);
    }

    /*
     * 功能描述   编辑时查询学校信息
     * @param
     * @return
     */
    @GetMapping("query/schoolInfo")
    public PojoResult querySchoolInfo(@RequestParam Integer schoolId){
        SchoolVo schoolVo = schoolService.querySchoolInfo(schoolId);
        PojoResult<SchoolVo> result = new PojoResult<>();
        result.setContent(schoolVo);
        return result;
    }

    /*
     * 功能描述   下拉框查询学校列表
     * @param
     * @return
     */
    @GetMapping("query/getSchoolInfo")
    public PojoResult getSchoolInfo(Integer periodId,Integer district){
        List<TSchool> schoolList = schoolService.querySchoolListInfo(periodId,district);
        PojoResult result = new PojoResult<>();
        result.setContent(schoolList);
        return result;
    }

    /*
     * 功能描述   根据学校id查询年级
     * @param
     * @return
     */
    @GetMapping("query/getGradeInfo")
    public PojoResult getGradeInfo(Integer schoolId){
        List<TGrade> gradeList = schoolService.queryGradeBySchoolId(schoolId);
        PojoResult result = new PojoResult<>();
        result.setContent(gradeList);
        return result;
    }

    /*
     * 功能描述   根据年级id查询班级
     * @param
     * @return
     */
    @GetMapping("query/getClassInfo")
    public PojoResult getClassInfo(Integer gradeId,Integer schoolId){
        List<ClassVo> classList = schoolService.queryClassByGradeId(gradeId,schoolId);
        PojoResult result = new PojoResult<>();
        result.setContent(classList);
        return result;
    }


    /*
     * 功能描述   查询学校和班级的代码
     * @param
     * @return
     */
    @PostMapping("query/getSchoolOrClassCode")
    public PojoResult getSchoolOrClassCode(@RequestBody BatchOperationRequest request){
        Map<String,String> map = schoolService.getSchoolOrClassCode(request.getSchoolId(),request.getClassId());
        PojoResult result = new PojoResult<>();
        result.setContent(map);
        return result;
    }

    /*
     * 查询学校班级待办信息
     * @param
     * @return
     */
    @PostMapping("/task")
    public ListResult getTask(@RequestBody SchoolRequest request){
        ListResult<SchoolClassTaskVO> result = new ListResult<>();
        result.setContent(schoolService.getTask(request));
        return result;
    }

    /*
     *功能描述 手动给某个学校新增学段、年级和班级
     * @param
     * @return
     */
    @GetMapping("/insert")
    public BaseResult insertClass(@RequestParam Integer schoolId,@RequestParam String periodId){
        return schoolService.insertClass(schoolId,periodId);
    }

}
