package com.ruida.assessment.assessmentquestionbank.controller;

import com.ruida.assessment.assessmentcommon.result.MapResult;
import com.ruida.assessment.assessmentcommon.result.PageResult;
import com.ruida.assessment.assessmentcommon.result.PojoResult;
import com.ruida.assessment.assessmentquestionbank.annotaion.UserAuth;
import com.ruida.assessment.assessmentquestionbank.dto.MsgTemplateDTO;
import com.ruida.assessment.assessmentquestionbank.dto.MsgTemplateOperationDTO;
import com.ruida.assessment.assessmentquestionbank.dto.QueryBaseDTO;
import com.ruida.assessment.assessmentquestionbank.model.TMsgTemplate;
import com.ruida.assessment.assessmentquestionbank.service.MsgTemplateService;
import com.ruida.assessment.assessmentquestionbank.vo.MsgTemplateVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

/**
 * @description: 消息模板控制层
 * @author: kgz
 * @date: 2020/7/21
 */
@RequestMapping("/messageTemplate")
@RestController
@Api(value ="消息模板相关接口")
public class MsgTemplateController {

    /**
     * 消息模板id
     */
    private static final String COLUMN_ID = "id";

    @Resource
    private MsgTemplateService msgTemplateService;

    @UserAuth
    @PostMapping("/save")
    @ApiOperation(value = "保存消息模板信息", notes = "保存消息模板信息")
    @ApiImplicitParam(name = "msgTemplateDTO", value = "消息模板信息",
            required = true , dataType  = "MsgTemplateDTO",paramType = "body")
    public MapResult save(@RequestBody MsgTemplateDTO msgTemplateDTO){
        MapResult mapResult = new MapResult();
        mapResult.add(COLUMN_ID, msgTemplateService.saveMsgTemplate(msgTemplateDTO));
        return mapResult;
    }

    @UserAuth
    @GetMapping("/getDetail/{id}")
    @ApiOperation(value = "获取消息模板信息详情", notes = "获取消息模板信息详情")
    @ApiImplicitParam(name = "id", value = "消息模板id",
            required = true , dataType  = "String", paramType = "path")
    public PojoResult getDetail(@PathVariable String id){
        PojoResult pojoResult = new PojoResult();
        MsgTemplateVO detail = msgTemplateService.getMsgTemplateDetail(id);
        pojoResult.setContent(detail);
        return pojoResult;
    }

    @UserAuth
    @PostMapping("/getList")
    @ApiOperation(value = "分页查询消息模板列表", notes = "分页查询消息模板列表")
    @ApiImplicitParam(name = "queryBaseDTO", value = "消息模板查询条件",
            required = true , dataType  = "QueryBaseDTO",paramType = "body")
    public PageResult<MsgTemplateVO> getList(@RequestBody QueryBaseDTO queryBaseDTO){
        PageResult<MsgTemplateVO> pageResult = new PageResult();
        pageResult.setContent(msgTemplateService.getMsgTemplateList(queryBaseDTO));
        return pageResult;
    }

    @UserAuth
    @PostMapping("/operation")
    @ApiOperation(value = "消息模板操作", notes = "消息模板操作，禁用、启用、删除")
    @ApiImplicitParam(name = "msgTemplateOperation", value = "消息模板操作",
            required = true , dataType  = "MsgTemplateOperationDTO",paramType = "body")
    public MapResult operation(@RequestBody MsgTemplateOperationDTO msgTemplateOperation){
        return msgTemplateService.operateMsgTemplate(msgTemplateOperation);
    }

}
