/*
 * Create Author  : bin.gong
 * Create Date    : 2015-03-05
 * Project        : process-parent
 * File Name      : QueryParamDTO.java
 *
 * Copyright (c) 2010-2015 by Shanghai HanTao Information Co., Ltd.
 * All rights reserved.
 *
 */

package com.ruida.common.model;


import org.codehaus.jackson.map.annotate.JsonSerialize;

import java.util.HashMap;
import java.util.Map;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class JsonDto<T> {
    private boolean result;
    private String msg;
    private Map<String, Object> datas;
    private T t;

    public boolean isResult() {
        return result;
    }

    public void setResult(boolean result) {
        this.result = result;
    }

    public String getMsg() {
        return msg;
    }

    public JsonDto setMsg(String msg) {
        this.msg = msg;
        return this;
    }

    public Map<String, Object> getDatas() {
        return datas;
    }

    public JsonDto setDatas(Map<String, Object> datas) {
        this.datas = datas;
        return this;
    }

    public JsonDto addData(String key, Object data) {
        if (this.datas == null) {
            this.datas = new HashMap<String, Object>();
        }
        this.datas.put(key, data);
        return this;
    }

    public T getT() {
        return t;
    }

    public JsonDto setT(T t) {
        this.t = t;
        return this;
    }

    public static JsonDto success() {
        JsonDto dto = new JsonDto();
        dto.setResult(true);
        dto.setMsg("操作成功");
        return dto;
    }

    public static JsonDto fail() {
        JsonDto dto = new JsonDto();
        dto.setResult(false);
        dto.setMsg("操作失败");
        return dto;
    }
}
