package com.ruida.cloud.weidu.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.ruida.cloud.dao.WeiduSubjectRelMapper;
import com.ruida.cloud.model.WeiduSubjectRel;
import com.ruida.cloud.weidu.config.WeiduConfig;
import com.ruida.cloud.weidu.exception.VdyooException;
import com.ruida.cloud.weidu.service.BaseVdyooService;
import com.ruida.cloud.weidu.utils.PropertyUtil;
import com.ruida.cloud.weidu.utils.VdyooUtil;
import com.ruida.cloud.weidu.vo.VdyooEntity;
import com.ruida.common.context.BaseContextHandle;
import com.ruida.common.util.ValidateMT;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * 关联信息：
 * 睿达学科科目id     pid
 * 威渡id            id
 *
 * @author taosh
 * @create 2019-04-23 15:10
 */
@Service
public class VdyooSubjectService extends BaseVdyooService {
    private String vdyooPath = PropertyUtil.getProperty("vdyooTestApi");
    @Resource
    private WeiduSubjectRelMapper weiduSubjectRelMapper;

    /**
     * 创建教学科目
     */
    public boolean addSubject(Map<String, Object> params) {
        VdyooEntity vdyooEntity = this.vdyooFactory.post(params, WeiduConfig.addSubject);
        boolean flag = false;
        if (vdyooEntity.getSuccess()) {
            Integer id = null;
            try {
                JSONObject object =(JSONObject)JSON.toJSON( vdyooEntity.getPayload());
                WeiduSubjectRel weiduSubjectRel = new WeiduSubjectRel();
                weiduSubjectRel.setSubjectId((Integer) params.get("pid"));
                weiduSubjectRel.setIsdelete((byte) 0);
                weiduSubjectRel.setWeiduSubjectId(object.getInteger("id"));
                weiduSubjectRel.setCreateBy(BaseContextHandle.getUserId());
                weiduSubjectRel.setCreateTime(new Date());
                weiduSubjectRel.setUpdateBy(BaseContextHandle.getUserId());
                weiduSubjectRel.setUpdateTime(new Date());
                id = object.getInteger("id");
                flag = weiduSubjectRelMapper.insert(weiduSubjectRel) > 0;
            } catch (Exception e) {
                //回滚到原始
                if(ValidateMT.isNotNull(id)){
                    this.deleteSubjectById(id);
                }
                throw new VdyooException("500","操作失败");
            }
        }
        return flag;
    }

    /**
     * 根据教室ID查询教室信息
     */
    public boolean editSubjectById(Map<String, Object> params) {
        return this.vdyooFactory.post(params, WeiduConfig.editSubjectById).getSuccess();
    }

    /**
     * 删除教学科目
     */
    public boolean deleteSubjectById(Integer id) {
        Map<String, Object> params = new HashMap<>();
        params.put("id", id);
        return this.vdyooFactory.post(params, WeiduConfig.deleteSubjectById).getSuccess();
    }

    /**
     * 根据ID查询科目
     */

    public final static String findSubjectById = "/api/business/subject/findSubjectById";

    public VdyooEntity findSubjectById(Integer id) {
        Map<String, Object> params = new HashMap<>();
        params.put("id", id);
        return this.vdyooFactory.post(params, WeiduConfig.deleteSubjectById);
    }

    /**
     * 查询公司下的所有教学科目
     */
    public final static String findSubjectByTenant = "/api/business/subject/findSubjectByTenant";

    public VdyooEntity findSubjectByTenant() {
        return this.vdyooFactory.post(WeiduConfig.findSubjectByTenant);
    }
}
