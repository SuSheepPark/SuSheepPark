package com.ruida.mockservice.service.impl;


import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.ruida.mockdao.dao.MajorSelectDetailMapper;
import com.ruida.mockdao.model.MajorSelectDetail;
import com.ruida.mockservice.service.MajorSelectDetailService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * <p>
 * 专业兴趣选择详情表 服务实现类
 * </p>
 *
 * @author xumingqi
 * @since 2021-01-14
 */
@Service
public class MajorSelectDetailServiceImpl extends ServiceImpl<MajorSelectDetailMapper, MajorSelectDetail> implements MajorSelectDetailService {
    @Resource
    MajorSelectDetailMapper majorSelectDetailMapper;

    @Override
    public Integer getMajorCountByRecordId(Integer recordId) {
        return majorSelectDetailMapper.countMajorCategoryCode(recordId);
    }
}
