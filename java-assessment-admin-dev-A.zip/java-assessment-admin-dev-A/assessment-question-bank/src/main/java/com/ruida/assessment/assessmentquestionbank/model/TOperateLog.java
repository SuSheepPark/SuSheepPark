package com.ruida.assessment.assessmentquestionbank.model;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import io.swagger.models.auth.In;

import java.io.Serializable;
import java.util.Date;

/**
 * @description: 操作日志数据库实体
 * @author: kgz
 * @date: 2020/8/12
 */
@TableName("t_operate_log")
public class TOperateLog implements Serializable {
    private static final long serialVersionUID = 5601151850959352618L;
    /**
     * 操作主键ID
     */
    @TableId
    private Integer id;

    /**
     * 操作模块
     */
    private String operateModule;

    /**
     * 操作模块id
     */
    private Integer moduleId;

    /**
     * 操作类型
     */
    private String operateType;

    /**
     * 操作描述
     */
    private String operateDesc;


    /**
     * 请求URI
     */
    private String operateUri;


    /**
     * 操作IP
     */
    private String operateIp;

    /**
     * 操作者id
     */
    private Integer operateUserId;

    /**
     * 操作者账号
     */
    private String operateUserName;

    /**
     * 操作者姓名
     */
    private String operateRealName;

    /**
     * 创建时间
     */
    private Date createTime;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getOperateModule() {
        return operateModule;
    }

    public void setOperateModule(String operateModule) {
        this.operateModule = operateModule;
    }

    public String getOperateType() {
        return operateType;
    }

    public void setOperateType(String operateType) {
        this.operateType = operateType;
    }

    public String getOperateDesc() {
        return operateDesc;
    }

    public void setOperateDesc(String operateDesc) {
        this.operateDesc = operateDesc;
    }

    public String getOperateUri() {
        return operateUri;
    }

    public void setOperateUri(String operateUri) {
        this.operateUri = operateUri;
    }

    public Integer getOperateUserId() {
        return operateUserId;
    }

    public void setOperateUserId(Integer operateUserId) {
        this.operateUserId = operateUserId;
    }

    public String getOperateUserName() {
        return operateUserName;
    }

    public void setOperateUserName(String operateUserName) {
        this.operateUserName = operateUserName;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getOperateIp() {
        return operateIp;
    }

    public void setOperateIp(String operateIp) {
        this.operateIp = operateIp;
    }

    public String getOperateRealName() {
        return operateRealName;
    }

    public void setOperateRealName(String operateRealName) {
        this.operateRealName = operateRealName;
    }

    public Integer getModuleId() {
        return moduleId;
    }

    public void setModuleId(Integer moduleId) {
        this.moduleId = moduleId;
    }
}
