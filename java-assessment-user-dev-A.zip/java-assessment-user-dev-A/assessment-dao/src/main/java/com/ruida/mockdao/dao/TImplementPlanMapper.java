package com.ruida.mockdao.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.model.TImplementPlan;

/**
 * <p>
 * 实施计划表 Mapper 接口
 * </p>
 *
 * @author szl
 * @since 2021-07-22
 */
public interface TImplementPlanMapper extends BaseMapper<TImplementPlan> {

}
