package com.ruida.assessment.assessmentquestionbank.service;

import com.baomidou.mybatisplus.service.IService;
import com.ruida.assessment.assessmentquestionbank.model.OccupationInterestExamRecord;

/**
 * <p>
 * 霍兰德职业兴趣答题卡以及报告 服务类
 * </p>
 *
 * @author
 * @since 2021-02-05
 */
public interface OccupationInterestExamRecordService extends IService<OccupationInterestExamRecord> {

}
