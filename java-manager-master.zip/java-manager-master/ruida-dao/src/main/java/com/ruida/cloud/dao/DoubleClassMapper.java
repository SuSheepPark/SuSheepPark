package com.ruida.cloud.dao;

import com.ruida.cloud.model.BatchSyncQueryRequest;
import com.ruida.cloud.model.DoubleClass;
import com.ruida.cloud.model.DoubleClassExample;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.ruida.cloud.model.DoubleClassStu;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Update;

public interface DoubleClassMapper {
    int countByExample(DoubleClassExample example);

    int deleteByExample(DoubleClassExample example);

    int deleteByPrimaryKey(Integer classId);

    int insert(DoubleClass record);

    int insertSelective(DoubleClass record);

    List<DoubleClass> selectByExample(DoubleClassExample example);

    DoubleClass selectByPrimaryKey(Integer classId);

    int updateByExampleSelective(@Param("record") DoubleClass record, @Param("example") DoubleClassExample example);

    int updateByExample(@Param("record") DoubleClass record, @Param("example") DoubleClassExample example);

    int updateByPrimaryKeySelective(DoubleClass record);

    int updateByPrimaryKey(DoubleClass record);

    List<DoubleClass> getDoubleClassList(Map courseMap);

    List getDoubleTeacherCampus();

    @Update("UPDATE t_double_class a set a.finished_date = #{finishedDate,jdbcType=TIMESTAMP} WHERE a.class_id = #{classId} ")
    Integer updateClassFinishedDate(@Param("classId") Integer classId,@Param("finishedDate") Date finishedDate);

    List<DoubleClass> getDoubleClassBatchSyncList(BatchSyncQueryRequest request);
    List<DoubleClassStu> getDoubleClassStuList(Map courseMap);
}