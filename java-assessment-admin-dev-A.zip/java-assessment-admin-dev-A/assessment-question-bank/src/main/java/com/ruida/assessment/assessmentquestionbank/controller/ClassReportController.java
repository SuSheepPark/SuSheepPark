package com.ruida.assessment.assessmentquestionbank.controller;

import com.ruida.assessment.assessmentcommon.result.PojoResult;
import com.ruida.assessment.assessmentquestionbank.annotaion.UserAuth;
import com.ruida.assessment.assessmentquestionbank.dto.ReportDTO;
import com.ruida.assessment.assessmentquestionbank.service.ClassReportService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

/**
 * @description: 班级成绩报告 控制层
 * @author: kgz
 * @date: 2020/10/19
 */
@RestController
@RequestMapping("/classReport/")
@Api(tags = "班级报告相关接口")
public class ClassReportController {

    @Resource
    private ClassReportService classReportService;

    //    @UserAuth
    @PostMapping("score/generalCondition")
    @ApiOperation(value = "考试得分整体情况", tags = "考试得分整体情况")
    @ApiImplicitParam(name = "reportDTO", value = "报告查询条件",
            required = true , dataType  = "ReportDTO",paramType = "body")
    public PojoResult getgeneralCondition(@RequestBody ReportDTO reportDTO){
        PojoResult result = new PojoResult();
        result.setContent(classReportService.getClassScoreInfo(reportDTO,null));
        result.setMsg("查询成功");
        return result;
    }

    //    @UserAuth
    @PostMapping("score/distribution")
    @ApiOperation(value = "各分数段的人数", tags = "各分数段的人数")
    @ApiImplicitParam(name = "reportDTO", value = "报告查询条件",
            required = true , dataType  = "ReportDTO",paramType = "body")
    public PojoResult getClassScoreDistribution(@RequestBody ReportDTO reportDTO){
        PojoResult result = new PojoResult();
        result.setContent(classReportService.getClassScoreDistribution(reportDTO));
        result.setMsg("查询成功");
        return result;
    }

    //    @UserAuth
    @PostMapping("score/question")
    @ApiOperation(value = "试题得分情况", tags = "试题得分情况")
    @ApiImplicitParam(name = "reportDTO", value = "报告查询条件",
            required = true , dataType  = "ReportDTO",paramType = "body")
    public PojoResult getQuestionScoreInfo(@RequestBody ReportDTO reportDTO){
        PojoResult result = new PojoResult();
        result.setContent(classReportService.getQuestionScoreInfo(reportDTO,new HashMap<String, Object>()));
        result.setMsg("查询成功");
        return result;
    }

    //    @UserAuth
    @PostMapping("choiceQuestion/analysis")
    @ApiOperation(value = "选择题选项分析情况", tags = "选择题选项分析情况")
    @ApiImplicitParam(name = "reportDTO", value = "报告查询条件",
            required = true , dataType  = "ReportDTO",paramType = "body")
    public PojoResult getChoiceQuestionAnalysis(@RequestBody ReportDTO reportDTO){
        PojoResult result = new PojoResult();
        result.setContent(classReportService.getChoiceQuestionAnalysis(reportDTO));
        result.setMsg("查询成功");
        return result;
    }

    //    @UserAuth
    @PostMapping("knowledge")
    @ApiOperation(value = "知识掌握优势与不足诊断情况", tags = "知识掌握优势与不足诊断情况")
    @ApiImplicitParam(name = "reportDTO", value = "报告查询条件",
            required = true , dataType  = "ReportDTO",paramType = "body")
    public PojoResult getKnowledgeStatistics(@RequestBody ReportDTO reportDTO){
        PojoResult result = new PojoResult();
        result.setContent(classReportService.getKnowledgeStatistics(reportDTO,new HashMap<String, Object>()));
        result.setMsg("查询成功");
        return result;
    }

    //    @UserAuth
    @PostMapping("target")
    @ApiOperation(value = "考查要求掌握优势与不足诊断", tags = "考查要求掌握优势与不足诊断")
    @ApiImplicitParam(name = "reportDTO", value = "报告查询条件",
            required = true , dataType  = "ReportDTO",paramType = "body")
    public PojoResult getTargetStatistics(@RequestBody ReportDTO reportDTO){
        PojoResult result = new PojoResult();
        result.setContent(classReportService.getTargetStatistics(reportDTO,new HashMap<String, Object>()));
        result.setMsg("查询成功");
        return result;
    }

}
