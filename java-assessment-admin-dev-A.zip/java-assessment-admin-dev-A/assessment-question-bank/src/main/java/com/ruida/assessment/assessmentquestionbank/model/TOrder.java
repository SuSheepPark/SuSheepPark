package com.ruida.assessment.assessmentquestionbank.model;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @description: 订单数据库实体
 * @author: kgz
 * @date: 2020/7/31
 */
@TableName("t_order")
public class TOrder implements Serializable {
    private static final long serialVersionUID = -5958714476970843151L;
    /**
     * 订单主键ID
     */
    @TableId
    private Integer orderId;

    /**
     * 订单编号
     */
    private String orderNo;

    private Integer productId;

    /**
     * 订单交易号
     */
    private String orderTransNo;

    /**
     * 是否购买报告(0-未购买; 1-已购买)
     */
    private Integer isPurchaseReport;

    /**
     * 订单类型（0—单商品订单; 1—组合商品订单）保留字段
     */
    private Integer orderType;

    /**
     * 订单名称
     */
    private String orderName;

    /**
     * 订单金额
     */
    private BigDecimal orderAmount;

    /**
     * 折扣金额
     */
    private BigDecimal saleAmount;

    /**
     * 实付金额
     */
    private BigDecimal payAmount;

    /**
     * 购买人ID
     */
    private Integer purchaserId;

    /**
     * 购买人姓名
     */
    private String purchaserName;

    /**
     * 购买人联系电话
     */
    private String telephone;

    /**
     * 支付方式（0—微信支付；1—支付宝；2—QQ钱包；3—网银支付；4—线下支付；5—免费; 6—学币抵扣;7-赠送）
     */
    private Integer paymentType;

    /**
     * 付款账号
     */
    private String paymentAccount;

    /**
     * 订单状态（0—待支付；1—已支付；2—已关闭;）
     */
    private Integer status;

    /**
     * 是否已退费（0—否；1—是）
     */
    private Integer refund;

    /**
     * 订单来源（0—PC端；1—IOS端；2—Android端；3—H5；4—线下交易；5—测试订单; 6—学币充值 ）
     */
    private Integer source;

    /**
     * 订单创建时间
     */
    private Date createTime;

    /**
     * 订单更新时间
     */
    private Date updateTime;

    /**
     * 订单付款时间
     */
    private Date paymentTime;

    /**
     * 交易关闭时间
     */
    private Date closeTime;

    /**
     * 是否删除（0：未删除；1：删除）
     */
    private Integer isdelete;

    public Integer getOrderId() {
        return orderId;
    }

    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public Integer getProductId() {
        return productId;
    }

    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    public String getOrderTransNo() {
        return orderTransNo;
    }

    public void setOrderTransNo(String orderTransNo) {
        this.orderTransNo = orderTransNo;
    }

    public Integer getIsPurchaseReport() {
        return isPurchaseReport;
    }

    public void setIsPurchaseReport(Integer isPurchaseReport) {
        this.isPurchaseReport = isPurchaseReport;
    }

    public Integer getOrderType() {
        return orderType;
    }

    public void setOrderType(Integer orderType) {
        this.orderType = orderType;
    }

    public String getOrderName() {
        return orderName;
    }

    public void setOrderName(String orderName) {
        this.orderName = orderName;
    }

    public BigDecimal getOrderAmount() {
        return orderAmount;
    }

    public void setOrderAmount(BigDecimal orderAmount) {
        this.orderAmount = orderAmount;
    }

    public BigDecimal getSaleAmount() {
        return saleAmount;
    }

    public void setSaleAmount(BigDecimal saleAmount) {
        this.saleAmount = saleAmount;
    }

    public BigDecimal getPayAmount() {
        return payAmount;
    }

    public void setPayAmount(BigDecimal payAmount) {
        this.payAmount = payAmount;
    }

    public Integer getPurchaserId() {
        return purchaserId;
    }

    public void setPurchaserId(Integer purchaserId) {
        this.purchaserId = purchaserId;
    }

    public String getPurchaserName() {
        return purchaserName;
    }

    public void setPurchaserName(String purchaserName) {
        this.purchaserName = purchaserName;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public Integer getPaymentType() {
        return paymentType;
    }

    public void setPaymentType(Integer paymentType) {
        this.paymentType = paymentType;
    }

    public String getPaymentAccount() {
        return paymentAccount;
    }

    public void setPaymentAccount(String paymentAccount) {
        this.paymentAccount = paymentAccount;
    }

    public Integer getSource() {
        return source;
    }

    public void setSource(Integer source) {
        this.source = source;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getIsdelete() {
        return isdelete;
    }

    public void setIsdelete(Integer isdelete) {
        this.isdelete = isdelete;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Date getPaymentTime() {
        return paymentTime;
    }

    public void setPaymentTime(Date paymentTime) {
        this.paymentTime = paymentTime;
    }

    public Date getCloseTime() {
        return closeTime;
    }

    public void setCloseTime(Date closeTime) {
        this.closeTime = closeTime;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getRefund() {
        return refund;
    }

    public void setRefund(Integer refund) {
        this.refund = refund;
    }

    @Override
    public String toString() {
        return "TOrder{" +
                "orderId=" + orderId +
                ", orderNo='" + orderNo + '\'' +
                ", productId=" + productId +
                ", orderTransNo='" + orderTransNo + '\'' +
                ", isPurchaseReport=" + isPurchaseReport +
                ", orderType=" + orderType +
                ", orderName='" + orderName + '\'' +
                ", orderAmount=" + orderAmount +
                ", saleAmount=" + saleAmount +
                ", payAmount=" + payAmount +
                ", purchaserId=" + purchaserId +
                ", purchaserName='" + purchaserName + '\'' +
                ", telephone='" + telephone + '\'' +
                ", paymentType=" + paymentType +
                ", paymentAccount='" + paymentAccount + '\'' +
                ", status=" + status +
                ", refund=" + refund +
                ", source=" + source +
                ", createTime=" + createTime +
                ", updateTime=" + updateTime +
                ", paymentTime=" + paymentTime +
                ", closeTime=" + closeTime +
                ", isdelete=" + isdelete +
                '}';
    }
}
