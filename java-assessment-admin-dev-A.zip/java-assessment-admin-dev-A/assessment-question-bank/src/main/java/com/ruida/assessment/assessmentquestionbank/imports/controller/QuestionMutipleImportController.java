package com.ruida.assessment.assessmentquestionbank.imports.controller;

import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.List;

import javax.inject.Inject;

import org.apache.poi.openxml4j.exceptions.NotOfficeXmlFileException;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.alibaba.fastjson.JSON;
import com.ruida.assessment.assessmentcommon.result.BaseResult;
import com.ruida.assessment.assessmentcommon.result.ResultApi2;
import com.ruida.assessment.assessmentquestionbank.annotaion.UserAuth;
import com.ruida.assessment.assessmentquestionbank.dto.QuestionInfoDTO;
import com.ruida.assessment.assessmentquestionbank.imports.application.Docx2ProtocolFactory;
import com.ruida.assessment.assessmentquestionbank.imports.application.Protocol2ModelFactory;
import com.ruida.assessment.assessmentquestionbank.imports.domain.model.ErrorMsg;
import com.ruida.assessment.assessmentquestionbank.imports.domain.model.ErrorMsgException;
import com.ruida.assessment.assessmentquestionbank.imports.domain.service.ErrorService;
import com.ruida.assessment.assessmentquestionbank.service.PeriodService;
import com.ruida.assessment.assessmentquestionbank.service.QuestionService;
import com.ruida.assessment.assessmentquestionbank.service.SubjectService;
import com.ruida.assessment.assessmentquestionbank.vo.QuestionInfoVO;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/question")
@Api(tags = "题库-题目管理-批量导入")
public class QuestionMutipleImportController {

	@Inject
	Protocol2ModelFactory protocol2ModelFactory;
	@Inject
	QuestionService questionService;
	@Inject
	PeriodService periodService;
	@Inject
	SubjectService subjectService;

	@RequestMapping(value = "/import/word", method = { RequestMethod.POST })
	@ApiOperation(value = "题库题目批量导入", notes = "返回参数：01：文件类型错误 。02：登录人尚未加入机构 。03：数据部分上传失败。04：上传文件数据格式异常")
	@UserAuth
	public BaseResult mutipleImport(@RequestParam("file") MultipartFile file, Integer periodId, Integer subjectId) {
		if (!file.getOriginalFilename().endsWith(".docx")) {
			return ResultApi2.fail(1, "上传的文件类型必须为docx");
		}
		InputStream inputStream;
		try {
			inputStream = file.getInputStream();
		} catch (IOException e) {
			return ResultApi2.fail(2, "文件读取失败，请另存为docx文件");
		}
		Docx2ProtocolFactory docx2ProtocolFactory = null;
		try {
			docx2ProtocolFactory = new Docx2ProtocolFactory(inputStream);
		} catch (IOException | NotOfficeXmlFileException e) {
			e.printStackTrace();
			return ResultApi2.fail(2, "文件读取失败，请另存为docx文件");
		}
		List<QuestionInfoVO> questionInfoVOs = null;
		try {
			questionInfoVOs = protocol2ModelFactory.parse2QuestionLibraries(docx2ProtocolFactory.start());
		} catch (ErrorMsgException e) {
			ErrorService.addError(null, null, "文档内没有读取到开始标识或者题目");
		} catch (Exception e) {
			e.printStackTrace();
			ErrorService.addError(null, null, "文档无法读取，请重新尝试");
		}
		List<ErrorMsg> errorMsgs = ErrorService.getMsgs();
		ErrorService.remove();
		if (errorMsgs.size() == 0) {
			String periodName=periodService.getNameById(periodId);
			String subjectName=subjectService.getNameById(subjectId);
			questionInfoVOs.forEach(x -> {
				x.setPeriodId(periodId);
				x.setPeriodName(periodName);
				x.setSubjectId(subjectId);
				x.setSubjectName(subjectName);
				String json=JSON.toJSONString(x);
				QuestionInfoDTO questionInfoDTO=JSON.parseObject(json, QuestionInfoDTO.class);
				questionService.saveQuestion(questionInfoDTO);
				x.setId(questionInfoDTO.getId());
				x.setCreateTime(new Date());
				x.setPaperCount(0);
			});
			return ResultApi2.success().add("questions", questionInfoVOs);
		} else {
			return ResultApi2.fail(3, "文件格式内容错误").add("failList", errorMsgs);
		}
	}
}
