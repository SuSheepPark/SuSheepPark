package com.ruida.cloud.dao;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

/**
 * @author
 * @description: 知识点和能力管理扩展dao
 * @Date 2019/9/27
 * @verion 1.0
 */
public interface KnowledgeExtDao {
    @Select("SELECT\n" +
            "\tCOUNT(*)\n" +
            "FROM\n" +
            "\tt_knowledge a,\n" +
            "\tt_question_library b\n" +
            "\n" +
            "WHERE\n" +
            "\tFIND_IN_SET(\n" +
            "\t\ta.knowledge_id,\n" +
            "\t\tb.knowledge_points\n" +
            "\t) AND a.knowledge_id = #{knowledgeId}")
    int countKnowledgeByQuestion(@Param("knowledgeId") Integer knowledgeId);//查询知识点是否在题库中使用
    @Select("SELECT\n" +
            "\tCOUNT(*)\n" +
            "FROM\n" +
            "\tt_ability a,\n" +
            "\tt_question_library b\n" +
            "WHERE\n" +
            "\tFIND_IN_SET(a.ability_id, b.ability_ids)\n" +
            "AND a.ability_id = #{abilityId}")
    int countAblityByQuestion(@Param("abilityId") Integer abilityId);//查询能力是否正在题库中使用

}
