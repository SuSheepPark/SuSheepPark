package com.ruida.cloud.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ruida.common.SystemConstant;
import com.ruida.common.util.excel.ExcelAnnotation;

import java.math.BigDecimal;
import java.util.Date;

public class BaijiayunIntegral {
    /**
     * 
     */
    private Long id;

    /**
     * 学校id
     */
    private Integer schoolZoneId;

    /**
     * 学校名字
     */
    @ExcelAnnotation(title = "学校")
    private String schoolZoneName;

    /**
     * 学生名字
     */
    @ExcelAnnotation(title = "学生姓名")
    private String stuName;

    /**
     * 学生id
     */
    private Integer stuId;

    /**
     * 学号
     */
    private Integer stuNumber;

    /**
     * 电话
     */
    private String mobile;
    private Integer isright;

    /**
     * 发生时间
     */
    @ExcelAnnotation(title = "创建时间")
    @JsonFormat(pattern= SystemConstant.DATE_FORMAT,timezone=SystemConstant.TIME_ZONE)
    private Date startTime;

    /**
     * 
     */
    private String answer;

    /**
     * 
     */
    private String rightAnswer;

    /**
     * 钱
     */
    private BigDecimal money;

    /**
     * 互动类型（0 投票；1红包）
     */
    private Byte interactType;

    /**
     * 
     */
    private Date createTime;
    /**
     * 设备号
     */
    private String deviceUnique;
    private String roomId;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getSchoolZoneId() {
        return schoolZoneId;
    }

    public void setSchoolZoneId(Integer schoolZoneId) {
        this.schoolZoneId = schoolZoneId;
    }

    public String getSchoolZoneName() {
        return schoolZoneName;
    }

    public void setSchoolZoneName(String schoolZoneName) {
        this.schoolZoneName = schoolZoneName == null ? null : schoolZoneName.trim();
    }

    public String getStuName() {
        return stuName;
    }

    public void setStuName(String stuName) {
        this.stuName = stuName == null ? null : stuName.trim();
    }

    public Integer getStuId() {
        return stuId;
    }

    public void setStuId(Integer stuId) {
        this.stuId = stuId;
    }

    public Integer getStuNumber() {
        return stuNumber;
    }

    public void setStuNumber(Integer stuNumber) {
        this.stuNumber = stuNumber;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer == null ? null : answer.trim();
    }

    public String getRightAnswer() {
        return rightAnswer;
    }

    public void setRightAnswer(String rightAnswer) {
        this.rightAnswer = rightAnswer == null ? null : rightAnswer.trim();
    }

    public BigDecimal getMoney() {
        return money;
    }

    public void setMoney(BigDecimal money) {
        this.money = money;
    }

    public Byte getInteractType() {
        return interactType;
    }

    public void setInteractType(Byte interactType) {
        this.interactType = interactType;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getIsright() {
        return isright;
    }

    public void setIsright(Integer isright) {
        this.isright = isright;
    }

    public String getDeviceUnique() {
        return deviceUnique;
    }

    public void setDeviceUnique(String deviceUnique) {
        this.deviceUnique = deviceUnique;
    }

    public String getRoomId() {
        return roomId;
    }

    public void setRoomId(String roomId) {
        this.roomId = roomId;
    }
}