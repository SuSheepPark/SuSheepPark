package com.ruida.cloud.dao;

import com.ruida.cloud.model.SysUserSuggestions;

import com.ruida.cloud.model.SysUserSuggestionsExample;
import com.ruida.cloud.model.SysUserSuggestionsExt;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface SysUserSuggestionsMapper {
    int countByExample(SysUserSuggestionsExample example);

    int deleteByExample(SysUserSuggestionsExample example);

    int deleteByPrimaryKey(Integer suggestionId);

    int insert(SysUserSuggestions record);

    int insertSelective(SysUserSuggestions record);

    List<SysUserSuggestions> selectByExample(SysUserSuggestionsExample example);

    SysUserSuggestions selectByPrimaryKey(Integer suggestionId);

    int updateByExampleSelective(@Param("record") SysUserSuggestions record, @Param("example") SysUserSuggestionsExample example);

    int updateByExample(@Param("record") SysUserSuggestions record, @Param("example") SysUserSuggestionsExample example);

    int updateByPrimaryKeySelective(SysUserSuggestions record);

    int updateByPrimaryKey(SysUserSuggestions record);

    int countSuggestionByExample(Map param);

    List<SysUserSuggestionsExt> selectSuggestionByExample(Map param);
}
