package com.ruida.mockdao.model;

import com.baomidou.mybatisplus.enums.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.enums.IdType;
import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableName;
import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author szl
 * @since 2021-06-02
 */
@TableName("t_cee_rank")
public class TCeeRank extends Model<TCeeRank> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;
    private Double score;
    /**
     * 当前名次
     */
    @TableField("current_rank")
    private Integer currentRank;
    /**
     * 累计排名
     */
    @TableField("accumulate_rank")
    private Integer accumulateRank;
    private Integer year;
    /**
     * 更新时间
     */
    @TableField("updatet_time")
    private Date updatetTime;
    /**
     * 创建时间
     */
    @TableField("create_time")
    private Date createTime;
    /**
     * 逻辑删除符号
     */
    private Integer isdelete;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Double getScore() {
        return score;
    }

    public void setScore(Double score) {
        this.score = score;
    }

    public Integer getCurrentRank() {
        return currentRank;
    }

    public void setCurrentRank(Integer currentRank) {
        this.currentRank = currentRank;
    }

    public Integer getAccumulateRank() {
        return accumulateRank;
    }

    public void setAccumulateRank(Integer accumulateRank) {
        this.accumulateRank = accumulateRank;
    }

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    public Date getUpdatetTime() {
        return updatetTime;
    }

    public void setUpdatetTime(Date updatetTime) {
        this.updatetTime = updatetTime;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getIsdelete() {
        return isdelete;
    }

    public void setIsdelete(Integer isdelete) {
        this.isdelete = isdelete;
    }

    @Override
    protected Serializable pkVal() {
        return this.id;
    }

    @Override
    public String toString() {
        return "TCeeRank{" +
        ", id=" + id +
        ", score=" + score +
        ", currentRank=" + currentRank +
        ", accumulateRank=" + accumulateRank +
        ", year=" + year +
        ", updatetTime=" + updatetTime +
        ", createTime=" + createTime +
        ", isdelete=" + isdelete +
        "}";
    }
}
