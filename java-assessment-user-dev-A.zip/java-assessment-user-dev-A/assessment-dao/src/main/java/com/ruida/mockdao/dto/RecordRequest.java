package com.ruida.mockdao.dto;

import lombok.Data;

/**
 * @description:
 * @author: chenjy
 * @create: 2020-10-22 15:42
 */
@Data
public class RecordRequest {

    private String keyword;

    private Integer stageId;

    private Integer subjectId;

    private Integer pageNo;

    private Integer pageSize;
}
