package com.ruida.mockdao.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.model.Subject;
import org.apache.ibatis.annotations.Mapper;

/**
 * Created by xumingqi on 2021/7/1 13:18
 */
@Mapper
public interface SubjectMapper extends BaseMapper<Subject> {
}
