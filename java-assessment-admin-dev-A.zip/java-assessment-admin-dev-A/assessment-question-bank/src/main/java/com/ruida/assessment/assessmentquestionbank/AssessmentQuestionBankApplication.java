package com.ruida.assessment.assessmentquestionbank;

import lombok.extern.slf4j.Slf4j;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.web.servlet.MultipartConfigFactory;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.util.unit.DataSize;
import org.springframework.util.unit.DataUnit;
import org.springframework.web.client.RestTemplate;
import springfox.documentation.builders.ParameterBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.schema.ModelRef;
import springfox.documentation.service.Parameter;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import javax.servlet.MultipartConfigElement;
import java.util.ArrayList;
import java.util.List;

@EnableDiscoveryClient
@EnableAspectJAutoProxy(proxyTargetClass = true, exposeProxy = true)
@MapperScan(basePackages = { "com.ruida.assessment.*.dao","com.ruida.assessment.*.mapper",
		"com.ruida.assessment.assessmentquestionbank.ruidacloudDao" })
@SpringBootApplication(scanBasePackages = "com.ruida.assessment", exclude = { DataSourceAutoConfiguration.class })
@EnableSwagger2
@EnableScheduling
@EnableFeignClients(basePackages = ("com.ruida.assessment"))
@EnableAsync
@Slf4j
public class AssessmentQuestionBankApplication {

	@Value("${swagger.switch}")
	private Boolean swaggerSwitch;
	public static void main(String[] args) {
		SpringApplication.run(AssessmentQuestionBankApplication.class, args);
		log.warn("application started successfully...");
	}

	@Bean
	public SimpleClientHttpRequestFactory httpRequestFactory() {
		SimpleClientHttpRequestFactory simpleClientHttpRequestFactory = new SimpleClientHttpRequestFactory();
		simpleClientHttpRequestFactory.setConnectTimeout(5000);
		simpleClientHttpRequestFactory.setReadTimeout(3000);
		return simpleClientHttpRequestFactory;
	}

	@Bean
	public RestTemplate restTemplate() {
		RestTemplate restTemplate = new RestTemplate(httpRequestFactory());
		return restTemplate;
	}

	@Bean
	public Docket createRestApi() {
		ParameterBuilder ticketPar = new ParameterBuilder();
		List<Parameter> pars = new ArrayList<Parameter>();
		ticketPar.name("Authorization").description("user ticket")// Token 以及Authorization
																	// 为自定义的参数，session保存的名字是哪个就可以写成那个
				.modelRef(new ModelRef("string"))
				.defaultValue(
						"Bearer eyJhbGciOiJIUzUxMiJ9.eyJ1c2VySWQiOiJ5bzAwMDAwMTciLCJuYW1lIjoiMTciLCJzb3VyY2UiOiIxIiwicGVyc29uSWQiOiIiLCJyb2xlVHlwZSI6IjIiLCJkZXB0SWQiOiIyIiwic3ViIjoiMTciLCJpYXQiOjE1OTc3MTI4NDIsImV4cCI6MTU5ODMxNzY0Mn0.Wmfr7FvvEYaQhTlnojbCZylwrmUntLnagw7D_c8x4Z8IvEBAs4NWbqR8NGulLIBGa2UJ4zlDVxrm2_iCbPcUHA")
				.parameterType("header").required(false).build(); // header中的ticket参数非必填，传空也可以
		pars.add(ticketPar.build()); // 根据每个方法名也知道当前方法在设置什么参数
		return new Docket(DocumentationType.SWAGGER_2).enable(swaggerSwitch).select()
				.apis(RequestHandlerSelectors.basePackage("com.ruida")).paths(PathSelectors.any()).build()
				.globalOperationParameters(pars);
	}

	@Bean
	public MultipartConfigElement multipartConfigElement() {
		MultipartConfigFactory factory = new MultipartConfigFactory();
		factory.setMaxRequestSize(DataSize.parse("1", DataUnit.GIGABYTES));
		factory.setMaxFileSize(DataSize.parse("1", DataUnit.GIGABYTES));
		return factory.createMultipartConfig();
	}
}
