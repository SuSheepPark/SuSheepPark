/**   
 * Copyright © 2019 公司名. All rights reserved.
 * 
 * @Title: ArticleServiceImpl.java 
 * @Prject: zhaowei-cms
 * @Package: com.zhaowei.cms.service.impl 
 * @Description: TODO
 * @author: zw   
 * @date: 2019年9月11日 上午10:26:05 
 * @version: V1.0   
 */
package com.zhaowei.cms.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.zhaowei.cms.dao.ArticleMapper;
import com.zhaowei.cms.domain.Article;
import com.zhaowei.cms.service.ArticleService;

/** 
 * @ClassName: ArticleServiceImpl 
 * @Description: TODO
 * @author: zw
 * @date: 2019年9月11日 上午10:26:05  
 */
@Service
public class ArticleServiceImpl implements ArticleService {

	@Resource
	private ArticleMapper articleMapper;
	
	@Override
	public PageInfo<Article> selects(Article article,Integer page,Integer pageSize){
		PageHelper.startPage(page, pageSize);
		List<Article> list = articleMapper.selects(article);
		return new PageInfo<Article>(list);
	}

	@Override
	public int insertSelective(Article record) {
		return articleMapper.insertSelective(record);
	}

	@Override
	public Article selectByPrimaryKey(Integer id) {
		return articleMapper.selectByPrimaryKey(id);
	}

	@Override
	public int updateByPrimaryKeySelective(Article article) {
		// TODO Auto-generated method stub
		return articleMapper.updateByPrimaryKeySelective(article);
	}

	@Override
	public Article selectPre(Article articled) {
		// TODO Auto-generated method stub
		return articleMapper.selectPre(articled);
	}

	@Override
	public Article selectNext(Article articled) {
		// TODO Auto-generated method stub
		return articleMapper.selectNext(articled);
	}

	@Override
	public PageInfo<Article> selectsByComments(Article article2, Integer page, Integer pageSize) {
		PageHelper.startPage(page, pageSize);
		List<Article> list = articleMapper.selectsByComments(article2);
		return new PageInfo<Article>(list);
	}

	@Override
	public PageInfo<Article> selectsByclick(Article article2, Integer page, Integer pageSize) {
		PageHelper.startPage(page, pageSize);
		List<Article> list = articleMapper.selectsByClick(article2);
		return new PageInfo<Article>(list);
	}

	/*
	 * @Override public boolean updateOnlyComments(@RequestParam(defaultValue =
	 * "")Integer comments,@RequestParam(defaultValue = "")Integer id) { return
	 * articleMapper.updateByOnlyComments(comments,id); }
	 */

}
