package com.ruida.mockdao.vo;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.ruida.mockdao.model.*;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * 首页学段条件列表
 */

@Data
@ApiModel(value="首页学段条件列表")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SelectPeriodVO {

    @ApiModelProperty(value = "学段年级")
    private List<TPeriod> period;

    private String periodName = "学段年级";


}
