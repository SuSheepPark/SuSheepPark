package com.ruida.assessment.assessmentquestionbank.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.assessment.assessmentquestionbank.model.TSchoolClassReportTemplate;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author wy
 * @description 班级学校报告模板mapper
 * @date 2021/3/4
 */
@Mapper
public interface SchoolClassReportTemplateMapper extends BaseMapper<TSchoolClassReportTemplate> {

}
