package com.ruida.cloud.model;

import java.io.Serializable;

public class CourseDiscountUser implements Serializable {
    private Integer discountId;

    private Integer courseId;

    private Integer schoolId;

    private Integer stageId;

    private Integer classId;

    private Integer studentId;

    private Byte studentSource;

    private static final long serialVersionUID = 1L;

    public Integer getDiscountId() {
        return discountId;
    }

    public void setDiscountId(Integer discountId) {
        this.discountId = discountId;
    }

    public Integer getCourseId() {
        return courseId;
    }

    public void setCourseId(Integer courseId) {
        this.courseId = courseId;
    }

    public Integer getSchoolId() {
        return schoolId;
    }

    public void setSchoolId(Integer schoolId) {
        this.schoolId = schoolId;
    }

    public Integer getStageId() {
        return stageId;
    }

    public void setStageId(Integer stageId) {
        this.stageId = stageId;
    }

    public Integer getClassId() {
        return classId;
    }

    public void setClassId(Integer classId) {
        this.classId = classId;
    }

    public Integer getStudentId() {
        return studentId;
    }

    public void setStudentId(Integer studentId) {
        this.studentId = studentId;
    }

    public Byte getStudentSource() {
        return studentSource;
    }

    public void setStudentSource(Byte studentSource) {
        this.studentSource = studentSource;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", discountId=").append(discountId);
        sb.append(", courseId=").append(courseId);
        sb.append(", schoolId=").append(schoolId);
        sb.append(", stageId=").append(stageId);
        sb.append(", classId=").append(classId);
        sb.append(", studentId=").append(studentId);
        sb.append(", studentSource=").append(studentSource);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}