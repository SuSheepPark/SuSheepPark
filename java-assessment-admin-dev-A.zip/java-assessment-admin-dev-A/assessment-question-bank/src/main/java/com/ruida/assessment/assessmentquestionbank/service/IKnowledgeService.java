package com.ruida.assessment.assessmentquestionbank.service;

import com.baomidou.mybatisplus.service.IService;
import com.ruida.assessment.assessmentcommon.result.BaseResult;
import com.ruida.assessment.assessmentcommon.result.ListResult;
import com.ruida.assessment.assessmentcommon.result.PojoResult;
import com.ruida.assessment.assessmentquestionbank.dto.BatchOperationRequest;
import com.ruida.assessment.assessmentquestionbank.dto.KnowledgeRequest;
import com.ruida.assessment.assessmentquestionbank.dto.MoveTreeRequest;
import com.ruida.assessment.assessmentquestionbank.model.TKnowledge;
import com.ruida.assessment.assessmentquestionbank.vo.KnowledgeTreeVo;

import java.util.List;

/**
 * @author wy
 * @description 知识点服务接口
 * @date 2020/6/10
 */
public interface IKnowledgeService extends IService<TKnowledge> {

    PojoResult addKnowledge(KnowledgeRequest knowledgeRequest);

    List<KnowledgeTreeVo> queryKnowledgeTreeList(KnowledgeRequest knowledgeRequest);

    BaseResult updateKnowledge(KnowledgeRequest knowledgeRequest);

    Boolean batchStopKnowledge(BatchOperationRequest batchOperationRequest);

    BaseResult deleteKnowledgeById(KnowledgeRequest knowledgeRequest);

    PojoResult moveKnowledgeTree(MoveTreeRequest moveTreeRequest);

    ListResult batchDeleteKnowledge(KnowledgeRequest request);

	TKnowledge selectKnowledgeByName(String name, Integer pid);

    void updateKnowledgeRedisData(KnowledgeRequest request);
}
