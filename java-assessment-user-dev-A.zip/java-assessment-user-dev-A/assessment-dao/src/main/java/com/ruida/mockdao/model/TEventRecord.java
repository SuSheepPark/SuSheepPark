package com.ruida.mockdao.model;

import com.baomidou.mybatisplus.enums.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.enums.IdType;
import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableName;
import java.io.Serializable;

/**
 * <p>
 * 事件点击记录
 * </p>
 *
 * @author szl
 * @since 2021-05-27
 */
@TableName("t_event_record")
public class TEventRecord extends Model<TEventRecord> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;
    /**
     * 事件id
     */
    @TableField("envent_id")
    private Integer enventId;
    /**
     * 事件来源（0-web,1-iOS,2-Android）
     */
    private Integer source;
    @TableField("user_id")
    private Integer userId;
    @TableField("create_time")
    private Date createTime;
    /**
     * 逻辑删除（0-有效 1-被删除）
     */
    private Integer isdelete;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getEnventId() {
        return enventId;
    }

    public void setEnventId(Integer enventId) {
        this.enventId = enventId;
    }

    public Integer getSource() {
        return source;
    }

    public void setSource(Integer source) {
        this.source = source;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getIsdelete() {
        return isdelete;
    }

    public void setIsdelete(Integer isdelete) {
        this.isdelete = isdelete;
    }

    @Override
    protected Serializable pkVal() {
        return this.id;
    }

    @Override
    public String toString() {
        return "TEventRecord{" +
        ", id=" + id +
        ", enventId=" + enventId +
        ", source=" + source +
        ", userId=" + userId +
        ", createTime=" + createTime +
        ", isdelete=" + isdelete +
        "}";
    }
}
