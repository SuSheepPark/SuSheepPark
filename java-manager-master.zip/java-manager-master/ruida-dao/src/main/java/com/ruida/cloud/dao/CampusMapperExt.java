package com.ruida.cloud.dao;

import com.ruida.cloud.model.Campus;
import com.ruida.cloud.model.CampusExt;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

/**
 * @author taosh
 * @create 2019-05-09 11:33
 */
public interface CampusMapperExt {
    int countCampusByExample(Map condition);

    List<CampusExt> selectCampusByExample(Map condition);

    List<CampusExt> listCampusByExample(Map condition);

    List<Integer> listCampusByName(String name);

    @Select("SELECT\n" +
            "\ta.campus_id as campusId,\n" +
            "\ta.campus_name as campusName\n" +
            "FROM\n" +
            "\tt_campus a\n" +
            "WHERE\n" +
            "\ta.isdelete = 0")
    List<Map<String, Object>> listCampusForDiscount();

    @Select("SELECT\n" +
            "\tGROUP_CONCAT(a.campus_name) as campusNames\n" +
            "FROM\n" +
            "\tt_campus a\n" +
            "WHERE\n" +
            "\tFIND_IN_SET(a.campus_id,#{campusIds})")
    String listCampusNameByIds(@Param("campusIds") String campusIds);

    /**
     * 优惠券根据登录用户列出校区
     * @param userId
     * @return
     */
    List<Map<String, Object>> listCampusForCoupon(Integer userId);

    List listClassifyCampus(Integer cityId);

    List selectcampusCityName();

    /**
     * 根据课程id获取校区信息
     * @param courseId
     * @return
     */
    List<Campus> listCampusByCourseId(Integer courseId);
}
