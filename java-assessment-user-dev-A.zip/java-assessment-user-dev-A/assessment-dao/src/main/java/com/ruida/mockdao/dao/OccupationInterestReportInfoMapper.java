package com.ruida.mockdao.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.model.OccupationInterestReportInfo;

/**
 * <p>
 * 职业兴趣测试报告文案表 Mapper 接口
 * </p>
 *
 * @author 
 * @since 2021-05-26
 */
public interface OccupationInterestReportInfoMapper extends BaseMapper<OccupationInterestReportInfo> {

}
