package com.ruida.assessment.assessmentquestionbank.service;

import com.ruida.assessment.assessmentquestionbank.model.TArea;

import java.util.List;

/**
 * @description:
 * @author: kgz
 * @date: 2020/7/7
 */
public interface AreaService extends QuestionBaseService {
    /**
     * 获取省份数据列表
     *
     * @return
     */
     List<TArea> listProvince() ;

    /**
     * 获取地区信息列表
     *
     * @param province
     * @return
     */
     List<TArea> listCityByProvince(Integer province);

    /**
     * 获取区信息列表
     *
     * @param city
     * @return
     */
     List<TArea> listDistrictByCity(Integer city) ;
}
