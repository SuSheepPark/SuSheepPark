package com.ruida.assessment.assessmentquestionbank.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.assessment.assessmentquestionbank.dto.UserFeedBackDTO;
import com.ruida.assessment.assessmentquestionbank.model.TUserFeedBack;
import com.ruida.assessment.assessmentquestionbank.vo.UserFeedBackVO;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * @description:
 * @author: kgz
 * @date: 2020/8/10
 */
@Mapper
public interface UserFeedBackMapper extends BaseMapper<TUserFeedBack> {
    /**
     * 分页查询用户反馈列表
     * @param userFeedBackDTO
     * @return
     */
    List<UserFeedBackVO> getUserFeedBackList(UserFeedBackDTO userFeedBackDTO);


    /**
     * 获取用户反馈总数
     * @param userFeedBackDTO
     * @return
     */
    Integer getUserFeedBackListCount(UserFeedBackDTO userFeedBackDTO);
}
