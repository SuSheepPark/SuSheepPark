package com.ruida.mockservice.service;

import com.baomidou.mybatisplus.service.IService;
import com.ruida.mockdao.dto.ReportDTO;
import com.ruida.mockdao.model.StatKnowledgeUserRel;
import com.ruida.mockdao.vo.TargetStatVO;
import com.ruida.mockdao.vo.report.ReportStatKnowledgeVO;
import com.ruida.mockdao.vo.report.ReportTargetStatVO;
import com.ruida.mockdao.vo.report.ReportVO;

import java.util.List;

/**
 * <p>
 * 知识点用户统计表 服务类
 * </p>
 *
 * @author jinhu
 * @since 2020-08-11
 */
public interface StatKnowledgeUserRelService extends IService<StatKnowledgeUserRel> {


    /**
     * 查询 用户报告 知识点维度
     * @param userId
     * @param examRecordId
     * @return
     */
    ReportStatKnowledgeVO queryUserReportByKnowledge(String userId, Integer productId, Integer examRecordId, Integer testPaperId);

    /**
     * 查询 用户报告 目标维度
     * @param userId
     * @param examRecordId
     * @param reportDTO
     * @return
     */
    ReportTargetStatVO queryUserReportByTarget(String userId, Integer examRecordId, ReportDTO reportDTO);

    /**
     * 查询 用户报告 知识点掌握率百分位
     * @param userId
     * @param examRecordId
     * @param schoolNum
     * @return
     */
    ReportStatKnowledgeVO queryKnowledgeRatePercentile(String userId, Integer productId, Integer examRecordId, Integer testPaperId, Integer schoolNum);

    /**
     * 查询 用户报告 考察目标掌握率百分位
     * @param userId
     * @param examRecordId
     * @param testPaperId
     * @param schoolNum
     * @return
     */
    List<TargetStatVO> queryTargetRatePercentile(String userId, Integer productId, Integer examRecordId, Integer testPaperId, Integer schoolNum);

    /**
     * 查询 9+1报告知识点掌握情况
     * @param userId
     * @param report
     * @param reportDTO
     * @return
     */
    ReportStatKnowledgeVO queryNineOneReportByKnowledge(String userId, ReportVO report, ReportDTO reportDTO);
}
