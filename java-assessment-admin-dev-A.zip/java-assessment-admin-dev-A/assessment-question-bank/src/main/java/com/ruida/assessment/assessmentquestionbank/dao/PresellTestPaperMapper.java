package com.ruida.assessment.assessmentquestionbank.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.assessment.assessmentquestionbank.model.TPresellTestPaper;
import com.ruida.assessment.assessmentquestionbank.model.TTestPaperProductRel;
import com.ruida.assessment.assessmentquestionbank.vo.PresellTestPaperVo;
import com.ruida.assessment.assessmentquestionbank.vo.TestPaperProductRelVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author wy
 * @description 商品预售试卷关联mapper
 * @date 2020/6/24
 */
@Mapper
public interface PresellTestPaperMapper extends BaseMapper<TPresellTestPaper> {


}
