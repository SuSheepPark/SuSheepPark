package com.ruida.mockdao.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.model.ConstConfig;

/**
 * 常量配置 Mapper 接口
 *
 * @author xumingqi
 * @since 2021-02-05
 */
public interface ConstConfigMapper extends BaseMapper<ConstConfig> {

}
