package com.ruida.cloud.dao;

import com.ruida.cloud.model.TCourseQuestion;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

public interface TCourseQuestionMapper {
    /**
     *
     * @param courseLessonId
     * @return 获取对应课次下的所有 问题
     */
    @Select("select course_question_id AS courseQuestionId,\n" +
            " course_lesson_id AS courseLessonId,\n" +
            " question_type AS questionType,\n" +
            " stem,\n" +
            " answer,\n" +
            " analysis\n" +
            " from t_course_question where isdelete = 0 and course_lesson_id =#{courseLessonId}")
    List<TCourseQuestion> getCourseQuestionList(@Param("courseLessonId") Integer courseLessonId);

    /**
     *
     * @param questionIds
     * @return 批量删除
     */
    @Update("update t_course_question set isdelete = 1 where  course_question_id in (#{questionIds})")
    Integer deleteQuestion(@Param("questionIds") String questionIds);

    /**
     * 新增问题
     * @param tCourseQuestion
     */
    void insertQuestion(TCourseQuestion tCourseQuestion);

    /**
     *
     * @param tCourseQuestion
     * @return 修改问题
     */
    Integer updateQuestion(TCourseQuestion tCourseQuestion);


}
