package com.ruida.mockdao.vo.order;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ruida.mockdao.vo.product.PaperReportVO;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;
import java.util.List;

/**
 * Created by xumingqi on 2021/7/2 15:11
 */
@Data
public class OrderDetailVO {
    @ApiModelProperty(value = "订单主键ID")
    private Integer orderId;

    @ApiModelProperty(value = "商品id")
    private Integer productId;

    @ApiModelProperty(value = "订单编号")
    private String orderNo;

    @ApiModelProperty(value = "订单类型")
    private Integer orderType;

    @ApiModelProperty(value = "订单类型")
    private String orderTypeName;

    @ApiModelProperty(value = "订单名称")
    private String orderName;

    @ApiModelProperty(value = "购买人姓名")
    private String purchaserName;

    @ApiModelProperty(value = "手机号")
    private String telephone;

    @ApiModelProperty(value = "订单状态（0—待支付；1—已支付；2—已关闭）")
    private Integer status;

    @ApiModelProperty(value = "状态名称")
    private String statusName;

    @ApiModelProperty(value = "订单总金额")
    private String orderAmount;

    @ApiModelProperty(value = "实付金额")
    private String payAmount;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @ApiModelProperty(value = "下单时间")
    private Date createTime;

    @ApiModelProperty(value = "付款时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date paymentTime;

    @ApiModelProperty(value = "支付方式")
    private Integer paymentType;

    @ApiModelProperty(value = "支付方式名称(0—微信支付；1—支付宝；5—免费领取; 6—学币抵扣; 7—平台赠送)")
    private String paymentTypeName;

    @ApiModelProperty(value = "订单关闭时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date closeTime;

    @ApiModelProperty(value = "商品图片")
    private String productImg;

    @ApiModelProperty(value = "试卷数量")
    private Integer testPaperNum;

    @ApiModelProperty(value = "报告数量")
    private Integer reportNum;

    @ApiModelProperty(value = "试卷目录")
    private List<PaperReportVO> paperList;

    //以下是兼容旧订单页面字段

    @ApiModelProperty(value = "实付金额")
    private String payAmountStr;
}
