package com.ruida.assessment.assessmentquestionbank.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.assessment.assessmentquestionbank.dto.VisitDTO;
import com.ruida.assessment.assessmentquestionbank.model.TUniqueVisitor;
import com.ruida.assessment.assessmentquestionbank.vo.VisitorVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * @description:
 * @author: kgz
 * @date: 2020/8/4
 */
@Mapper
public interface UniqueVisitorMapper extends BaseMapper<TUniqueVisitor> {
    /**
     * 获取访客信息
     * @param visitDTO
     * @return
     */
    VisitorVO getUniqueVisitorCount(VisitDTO visitDTO);

    /**
     * 获取访问量PV
     * @param startTime
     * @param endTime
     * @return
     */
    Integer getPageViewCount(@Param("startTime") String startTime, @Param("endTime") String endTime);

    /**
     * 获取访客数UV
     * @param startTime
     * @param endTime
     * @return
     */
    Integer getUniqueVisitor(@Param("startTime") String startTime, @Param("endTime") String endTime);
}
