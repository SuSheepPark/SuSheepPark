package com.ruida.common.util;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
import sun.misc.BASE64Encoder;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * 标记码生成
 * 
 * @author szl
 *
 */
public class ZxingUtil {

	/**
	 * 代理寄件标识码
	 *
	 * @param url
	 * @param width
	 * @return
	 * @throws Exception
	 */
	public static BufferedImage createQrCode( String url,  int width)
			throws Exception {
		int qrWidth = (int) (width * 0.4);
		int h = qrWidth;
		int brWidth = (int) (width * 0.6);
		int brHight = (int) (h * 0.4);
		int fontSize = (int) (width / 1000f * 30);
		Font font = new Font("宋体", Font.BOLD, fontSize);
		
//		String pathString = ZxingUtil.class.getResource("/font/simsun.ttc").getFile();
//		Font font = Font.createFont(Font.TRUETYPE_FONT, new File(pathString));
//		Font font = Font.createFont(Font.TRUETYPE_FONT, new File("d:/simsun.ttf"));
//		font.deriveFont(Font.BOLD, fontSize);
//		System.out.println(font.getFontName());
		
		int top = (int) (h / 200 * 13);

		// 生成二维码
		BufferedImage qr = encodeQrBufferedImage(url, qrWidth, h);

		return qr;
	}




	/**
	 * 
	 * @param contents
	 * @param width
	 * @param height
	 * @return
	 */
	private static BufferedImage encodeQrBufferedImage(String contents, int width, int height) {
		Map<EncodeHintType, Object> hints = new HashMap<EncodeHintType, Object>();
		// 指定纠错等级 分为四个等级：L/M/Q/H, 等级越高，容错率越高，识别速度降低。
		hints.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.H);
		// 指定编码格式 编码集，通常有中文，设置为 utf-8
		hints.put(EncodeHintType.CHARACTER_SET, "UTF-8");
		try {
			BitMatrix bitMatrix = new MultiFormatWriter().encode(contents, BarcodeFormat.QR_CODE, width, height, hints);
			return MatrixToImageWriter.toBufferedImage(bitMatrix);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}



	public static void main(String[] args) {
		try {

		/*	int width = 300;
			int height = 150;
			String bh = "weixin://wxpay/bizpayurl?pr=5eYQHKc";

			BufferedImage bi = createBarCode(bh, width, height);
			ImageIO.write(bi, "jpg", new File("d:/test_tmbs.jpg"));*/

			int width = 500;

			String url = "https://open.weixin.qq.com/connect/oauth2/authorize?appid=wx9fb94647a3c55e1e&redirect_uri=http%3a%2f%2fwww.ruida-edu.com%2fruidaStudent%2fwechat%3fdistrutorId%3d"+"254"+"&response_type=code&scope=snsapi_userinfo&state=123#wechat_redirect";

			BufferedImage bb = createQrCode(url,500);
			//BufferedImage bi = createQrCode(bh, url, strDls, strDesc, 500);
			ImageIO.write(bb, "jpg", new File("d:/test_bsm.jpg"));
		} catch (Exception e) {
			e.printStackTrace();
		}

		System.out.println((int) ((Math.random() * 9 + 1) * 10000000));

		
	}
	/**
	 * 图片base64编码
	 * @param bufferedImage
	 * @return
	 */
	public static String imageToBase64(BufferedImage bufferedImage) throws IOException {
		ByteArrayOutputStream outputStream = null;
		outputStream = new ByteArrayOutputStream();
		ImageIO.write(bufferedImage, "jpg", outputStream);
		BASE64Encoder encoder = new BASE64Encoder();
		return encoder.encode(outputStream.toByteArray()).replace("\r\n","");// 返回Base64编码过的字节数组字符串
	}
}
