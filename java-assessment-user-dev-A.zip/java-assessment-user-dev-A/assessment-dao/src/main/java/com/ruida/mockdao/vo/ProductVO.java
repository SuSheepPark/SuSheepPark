package com.ruida.mockdao.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * <p>
 * 商品实体
 * </p>
 *
 * @author jinhu
 * @since 2020-07-13
 */
@Data
@ApiModel(value="Product对象", description="商品")
//@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProductVO implements Serializable {

    private static final long serialVersionUID=1L;

    @ApiModelProperty(value = "商品id")
    private Integer productId;

    @ApiModelProperty(value = "商品号")
    private String productNo;

    @ApiModelProperty(value = "商品名称")
    private String productName;

    @ApiModelProperty(value = "商品原始价格 划线价")
    private BigDecimal productOriginPrice;

    @ApiModelProperty(value = "商品价格 安卓和PC")
    private BigDecimal productPrice;

    @ApiModelProperty(value = "商品价格 IOS")
    private BigDecimal productIosPrice;

    @ApiModelProperty(value = "是否需要单独买报告 0-不需要 1-需要")
    private Integer reportIsbuy;

    @ApiModelProperty(value = "报告价格 安卓和PC")
    private BigDecimal reportPrice;

    @ApiModelProperty(value = "报告价格 IOS")
    private BigDecimal reportIosPrice;

    @ApiModelProperty(value = "商品关联报告id,多个报告id用 , 拼接")
    private String reportIds;

    @ApiModelProperty(value = "初始化购买量")
    private Integer initBuyNum;

    @ApiModelProperty(value = "真实购买量")
    private Integer realBuyNum;

    @ApiModelProperty(value = "商品图片")
    private String productImg;

    @ApiModelProperty(value = "商品描述 html格式")
    private String productInfoHtml;

    @ApiModelProperty(value = "是否是套卷 0-试卷 1-套卷")
    private Integer iscompose;

    @ApiModelProperty(value = "单卷情况下题目数量")
    private Integer questionNum = 0;

    @ApiModelProperty(value = "学段id")
    private Integer periodId;

    @ApiModelProperty(value = "学段名称")
    private String periodName;

    @ApiModelProperty(value = "科目id，多个科目id用 , 拼接")
    private String subjectIds;

    @ApiModelProperty(value = "科目名称，多个科目名称用 , 拼接")
    private String subjectName;

    @ApiModelProperty(value = "教材版本id")
    private Integer versionId;

    @ApiModelProperty(value = "教材版本名称")
    private String versionName;

    @ApiModelProperty(value = "年级id")
    private Integer gradeId;

    @ApiModelProperty(value = "年级名称")
    private String gradeName;

    private Integer gradeTrueId;

    @ApiModelProperty(value = "年份,多个年份用 , 拼接")
    private String years;

    @ApiModelProperty(value = "难度")
    private Integer difficulty;

    @ApiModelProperty(value = "难度")
    private String difficultyName;

    @ApiModelProperty(value = "试卷类型")
    private Integer testPaperType;

    @ApiModelProperty(value = "试卷类型")
    private String testPaperTypeName;

    @ApiModelProperty(value = "考试类型")
    private Integer testType;

    @ApiModelProperty(value = "考试类型")
    private String testTypeName;

    @ApiModelProperty(value = "商品类型 0-试卷 1-套卷 2-职业兴趣问卷")
    private Integer productType;

    @ApiModelProperty(value = "浏览量")
    private Integer browse;

    @ApiModelProperty(value = "商品状态（0.已下架，1.已上架，2.草稿，3.待审核）")
    private Integer status;


    @ApiModelProperty(value = "是否购买  0未购买  1购买")
    private Integer isBuy = 0;

    @ApiModelProperty(value = "是否置顶  0未置顶  1置顶")
    private Integer top = 0;

    @ApiModelProperty(value = "是否购收藏  0未收藏  1收藏")
    private Integer isCollect;

    @ApiModelProperty(value = "完成人数")
    private Integer completeNum;

    @ApiModelProperty(value = "完成度")
    private BigDecimal completeRate;


    @ApiModelProperty(value = "试卷列表")
    private List<TestPaperInProductVO> testPapers;

    @ApiModelProperty(value = "联系电话")
    private String telephone;

    @ApiModelProperty(value = "商品考试方式 0-练习 3-统考")
    private String productTestWay;

    @ApiModelProperty(value = "统考开始时间")
    @JsonFormat(pattern= "yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date testStartTime;

    @ApiModelProperty(value = "统考结束时间")
    @JsonFormat(pattern= "yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date testEndTime;

    @ApiModelProperty(value = "已购买的试卷数量")
    private Integer purchasedTestPaperNum;

    @ApiModelProperty(value = "已完成的试卷数量")
    private Integer completeTestPaperNum;
}
