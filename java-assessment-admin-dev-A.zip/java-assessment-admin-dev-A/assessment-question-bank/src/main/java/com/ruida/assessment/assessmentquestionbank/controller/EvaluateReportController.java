package com.ruida.assessment.assessmentquestionbank.controller;

import com.ruida.assessment.assessmentcommon.result.PojoResult;
import com.ruida.assessment.assessmentquestionbank.annotaion.UserAuth;
import com.ruida.assessment.assessmentquestionbank.dto.EvaluateReportDTO;
import com.ruida.assessment.assessmentquestionbank.dto.ReportDTO;
import com.ruida.assessment.assessmentquestionbank.service.SelectionEvaluateReportService;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * @description: 升学评价报告
 * @author: kgz
 * @date: 2020/12/15
 */
@RestController
@RequestMapping("/evaluateReport/")
public class EvaluateReportController {

    @Resource
    private SelectionEvaluateReportService selectionEvaluateReportService;

    @UserAuth
    @PostMapping("calculate")
    @ApiOperation(value = "生成升学选拔报告", tags = "生成升学选拔报告")
    public PojoResult calculateReport(@RequestBody EvaluateReportDTO evaluateReportDTO){
        PojoResult result = new PojoResult();
        result.setContent(selectionEvaluateReportService.calculateReport(evaluateReportDTO));
        result.setMsg("生成报告成功");
        return result;
    }
}
