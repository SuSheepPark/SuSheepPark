package com.ruida.mockdao.vo.report;


import com.ruida.mockdao.vo.KnowledgeStatVO;
import io.swagger.annotations.ApiModel;
import lombok.Data;

import java.io.Serializable;
import java.util.List;


@Data
@ApiModel(value="报告页  学生报告统计")
public class ReportStatKnowledgeVO implements Serializable {


    List<KnowledgeStatVO> firstKnowledge;

    List<KnowledgeStatVO> secondKnowledge;

    List<KnowledgeStatVO> thirdKnowledge;


}
