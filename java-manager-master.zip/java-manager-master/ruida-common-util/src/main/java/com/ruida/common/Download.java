package com.ruida.common;

/**
 * @author admin
 * @description: ${瞎子啊}
 * @Date 2019/1/9
 * @verion 1.0
 */

import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;


@Component
public class Download {

    //下载模版工具类
    public void downloadFile(HttpServletRequest request,
                             HttpServletResponse response,String fileName,int type) throws Exception {
       // response.setContentType("text/html;charset=UTF-8");
        response.setContentType(SystemConstant.DOWNLOAD_PROTOCAL);
        BufferedInputStream in = null;
        BufferedOutputStream out = null;
        request.setCharacterEncoding(SystemConstant.UTF8);
        String rootpath = SystemConstant.UPLOAD_ROOT;
        if (type == 1){
            rootpath = SystemConstant.UPLOAD_ROOT+"/model2/custom";
        }else if( type == 3 ) {
            rootpath = SystemConstant.UPLOAD_ROOT+"/model2/courseCampus";
        }else if( type == 4){
            rootpath = SystemConstant.UPLOAD_ROOT+"/model2/doubleStudent";
        }else {
            rootpath = SystemConstant.UPLOAD_ROOT+"/model2/standard";
        }
       // String rootpath = request.getSession().getServletContext().getRealPath("/");
        try {
            System.out.println(rootpath+"/"+fileName);
            File f = new File(rootpath + "/" + fileName);
            response.setContentType("application/x-excel,application/pdf");
           // response.setContentType(SystemConstant.DOWNLOAD_PROTOCAL);
            response.setCharacterEncoding("UTF-8");
            response.setHeader("Content-Disposition", "attachment; filename=" + new String(fileName.getBytes("gbk"), "iso-8859-1"));
            response.setHeader("Content-Length", String.valueOf(f.length()));
            in = new BufferedInputStream(new FileInputStream(f));
            out = new BufferedOutputStream(response.getOutputStream());
            byte[] data = new byte[1024];
            int len = 0;
            while (-1 != (len = in.read(data, 0, data.length))) {
                out.write(data, 0, len);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (in != null) {
                in.close();
            }
            if (out != null) {
                out.close();
            }
        }


    }
}
