package com.ruida.assessment.assessmentquestionbank.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.assessment.assessmentcommon.result.Page;
import com.ruida.assessment.assessmentquestionbank.model.TQuestionAssessmentTarget;
import com.ruida.assessment.assessmentquestionbank.vo.BaseFieldVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @description: 考核目标dao层接口
 * @author: kgz
 * @date: 2020/6/10
 */
@Mapper
public interface QuestionAssessmentTargetMapper extends BaseMapper<TQuestionAssessmentTarget> {

    /**
     * 分页查询列表
     * @param page
     * @return
     */
    List<BaseFieldVO> queryList(@Param("page") Page page,@Param("pNameOrSName") String pNameOrSName);

    /**
     * 列表数据条数
     * @return
     */
    Integer countQueryList(@Param("pNameOrSName") String pNameOrSName);

    /*
     *功能描述  学段科目联动的下拉列表查询
     * @param
     * @return
     */
    List<TQuestionAssessmentTarget> queryRelList(@Param("periodId") Integer periodId, @Param("subjectId") Integer subjectId);
}
