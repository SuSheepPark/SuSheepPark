package com.ruida.assessment.assessmentquestionbank.model;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import io.swagger.annotations.ApiModel;
import lombok.Data;

import java.io.Serializable;

/**
 * @author wy
 * @description 班级学校报告模板实体类
 * @date 2021/3/4
 */
@Data
@ApiModel(description = "班级学校报告模板数据库实体")
@TableName("t_schoolclass_report_template")
public class TSchoolClassReportTemplate extends BaseColumn implements Serializable {


    private static final long serialVersionUID = 6393547289739597899L;

    @TableId
    private Integer id;

    private String reportName;

    private String reportPath;

    private Integer needConst;
}
