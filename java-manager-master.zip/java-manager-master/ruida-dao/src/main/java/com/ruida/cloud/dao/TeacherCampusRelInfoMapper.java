package com.ruida.cloud.dao;

import com.ruida.cloud.model.TeacherCampusRelInfo;
import com.ruida.cloud.model.TeacherCampusRelInfoExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface TeacherCampusRelInfoMapper {
    long countByExample(TeacherCampusRelInfoExample example);

    int deleteByExample(TeacherCampusRelInfoExample example);

    int deleteByPrimaryKey(Integer rid);

    int insert(TeacherCampusRelInfo record);

    int insertSelective(TeacherCampusRelInfo record);

    List<TeacherCampusRelInfo> selectByExample(TeacherCampusRelInfoExample example);

    TeacherCampusRelInfo selectByPrimaryKey(Integer rid);

    int updateByExampleSelective(@Param("record") TeacherCampusRelInfo record, @Param("example") TeacherCampusRelInfoExample example);

    int updateByExample(@Param("record") TeacherCampusRelInfo record, @Param("example") TeacherCampusRelInfoExample example);

    int updateByPrimaryKeySelective(TeacherCampusRelInfo record);

    int updateByPrimaryKey(TeacherCampusRelInfo record);
}