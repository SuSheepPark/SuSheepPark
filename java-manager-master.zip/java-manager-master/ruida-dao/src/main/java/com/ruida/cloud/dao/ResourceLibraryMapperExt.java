package com.ruida.cloud.dao;

import com.ruida.cloud.model.ResourceLibraryExt;

import java.util.List;
import java.util.Map;

/**
 * @author szl
 * @description: 资源库
 * @Date 2019/1/24
 * @verion 1.0
 */
public interface ResourceLibraryMapperExt {
    int countByExampleSearch();
    List<ResourceLibraryExt> selectByExampleSearch(Map condtion);
    ResourceLibraryExt  selectById(Integer id);
}
