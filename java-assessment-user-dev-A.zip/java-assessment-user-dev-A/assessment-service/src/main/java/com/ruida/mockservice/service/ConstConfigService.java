package com.ruida.mockservice.service;

import com.baomidou.mybatisplus.service.IService;
import com.ruida.mockdao.model.ConstConfig;

/**
 * 常模配置 服务类
 *
 * @author xumingqi
 * @since 2021-02-05
 */
public interface ConstConfigService extends IService<ConstConfig> {
}
