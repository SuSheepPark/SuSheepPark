package com.ruida.assessment.assessmentcommon.util;

import sun.misc.BASE64Encoder;

import java.security.MessageDigest;
import java.security.SecureRandom;

public class MD5Util {

    public static String generate(String password) {
//        生成随机盐，长度12位
    byte[] bytes = new byte[12];
    SecureRandom random = new SecureRandom();
    random.nextBytes(bytes);

    StringBuilder builder = new StringBuilder();
//        将字节数组变为字符串
    for (int i = 0; i < bytes.length; i++) {
//            将生成的值，全部映射到0-255 之间
        int val = ((int) bytes[i]) & 0xff;
        if (val < 16) {
//                为了控制盐的长度，这里小于16 的值，我们将它补为 大于16的值；
//                这样，生的盐的长度是固定的：bytes * 2 ;
            builder.append(Integer.toHexString(val + 16));
        } else {
            builder.append(Integer.toHexString(val));
        }
    }

//        最终的盐，长度是 12*2 = 24 ；
    String salt = builder.toString();


//        先加盐Md5一把，再将 MD5 转换成 24位的 base64 位编码
    password = md5Hex(password + salt);

    char[] cs = new char[salt.length() + password.length()];

    for (int i = 0; i < cs.length; i += 4) {

//            密码编码
        cs[i] = password.charAt(i / 2);
        cs[i + 2] = password.charAt(i / 2 + 1);
//            盐编码
        cs[i + 1] = salt.charAt(i / 2);
        cs[i + 3] = salt.charAt(i / 2 + 1);

    }
    return new String(cs);
}


    public static boolean verify(String password, String md5) {
//        解码密码
        char[] cs1 = new char[24];
//        解码盐
        char[] cs2 = new char[24];
//        从MD5 中取出盐
        for (int i = 0; i < md5.length(); i += 4) {
//            取出盐
            cs2[i / 2] = md5.charAt(i + 1);
            cs2[i / 2 + 1] = md5.charAt(i + 3);
//            取出密码的MD5值（经过Base64转换后的MD5）
            cs1[i / 2] = md5.charAt(i + 0);
            cs1[i / 2 + 1] = md5.charAt(i + 2);
        }

        String salt = new String(cs2);

        return md5Hex(password + salt).equals(new String(cs1));
    }

    /**
     * 获取十六进制字符串形式的MD5摘要
     */
    public static String md5Hex(String src) {
        try {
            MessageDigest md5 = MessageDigest.getInstance("MD5");
            byte[] bs = md5.digest(src.getBytes());
            return new String(new BASE64Encoder().encode(bs));
        } catch (Exception e) {
            return null;
        }
    }

}
