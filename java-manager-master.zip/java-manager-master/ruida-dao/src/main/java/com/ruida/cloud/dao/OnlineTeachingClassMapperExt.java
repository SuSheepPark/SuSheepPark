package com.ruida.cloud.dao;

import com.ruida.cloud.model.OnlineTeachingClass;
import com.ruida.cloud.model.TeachingClass;
import com.ruida.cloud.model.TeachingClassExt;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * @author taosh
 * @create 2019-07-24 10:49
 */
public interface OnlineTeachingClassMapperExt {

    int insertOnlineTeachingClassBatch(List<OnlineTeachingClass> classList);

    int deleteOnlineTeachingClassByLessonId(Map condition);

    int deleteOnlineTeachingClassByCourseId(Integer courseId);

    int updateOnlineTeachingClassByCourseId(Integer courseId);

    List<OnlineTeachingClass> listDeletedOnlineTeachingClassByCourseId(Integer courseId);

    int updateOnlineSchoolTaskBatch(List<OnlineTeachingClass> list);

    int updateOnlineStudentSchoolTaskRelBatch(List<OnlineTeachingClass> list);

    int updateOnlineClassRecordBatch(List<OnlineTeachingClass> list);

    int deleteDeletedOnlineTeachingClass(Integer courseId);

    int countNewOnlineTeachingClass(Integer courseId);

    int updateDeletedOnlineTeachingClass(Integer courseId);

    int updateOnlineTeacherCommendStudentBatch(List<OnlineTeachingClass> list);

    int updateOnlineStudentCommendTeacherBatch(List<OnlineTeachingClass> list);

    List<TeachingClass> selectClassByBroCamCor(@Param("courseId") Integer courseId,@Param("broadcastRoomId")  Integer broadcastRoomId,@Param("courseLessonId")  Integer courseLessonId,@Param("assistantTeacherId") Integer assistantTeacherId);
}
