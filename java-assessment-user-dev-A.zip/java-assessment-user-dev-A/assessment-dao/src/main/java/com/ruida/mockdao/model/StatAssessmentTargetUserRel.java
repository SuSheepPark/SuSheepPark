package com.ruida.mockdao.model;

import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 考察要求用户统计表
 * </p>
 *
 * @author chenjy
 * @since 2021-03-04
 */
@TableName("stat_assessment_target_user_rel")
public class StatAssessmentTargetUserRel extends Model<StatAssessmentTargetUserRel> {

    private static final long serialVersionUID = 1L;

    /**
     * 自增主键
     */
    @TableId(value = "rel_id", type = IdType.AUTO)
    private Integer relId;
    /**
     * 用户id
     */
    @TableField("user_id")
    private Integer userId;
    /**
     * 学生id
     */
    @TableField("stu_id")
    private Integer stuId;
    /**
     * 考试id
     */
    @TableField("exam_record_id")
    private Integer examRecordId;
    /**
     * 考察目标id
     */
    @TableField("assessment_target_id")
    private Integer assessmentTargetId;
    /**
     * 考察目标名称
     */
    @TableField("assessment_target_name")
    private String assessmentTargetName;
    /**
     * 满分
     */
    @TableField("full_score")
    private Double fullScore;
    /**
     * 实际得分
     */
    @TableField("real_score")
    private Double realScore;
    /**
     * 创建人
     */
    @TableField("create_by")
    private Integer createBy;
    /**
     * 创建时间
     */
    @TableField("create_time")
    private Date createTime;
    /**
     * 更新者
     */
    @TableField("update_by")
    private Integer updateBy;
    /**
     * 更新时间
     */
    @TableField("update_time")
    private Date updateTime;
    /**
     * 删除符号 0-未删除 1-删除
     */
    private Integer isdelete;


    public Integer getRelId() {
        return relId;
    }

    public void setRelId(Integer relId) {
        this.relId = relId;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Integer getStuId() {
        return stuId;
    }

    public void setStuId(Integer stuId) {
        this.stuId = stuId;
    }

    public Integer getExamRecordId() {
        return examRecordId;
    }

    public void setExamRecordId(Integer examRecordId) {
        this.examRecordId = examRecordId;
    }

    public Integer getAssessmentTargetId() {
        return assessmentTargetId;
    }

    public void setAssessmentTargetId(Integer assessmentTargetId) {
        this.assessmentTargetId = assessmentTargetId;
    }

    public String getAssessmentTargetName() {
        return assessmentTargetName;
    }

    public void setAssessmentTargetName(String assessmentTargetName) {
        this.assessmentTargetName = assessmentTargetName;
    }

    public Double getFullScore() {
        return fullScore;
    }

    public void setFullScore(Double fullScore) {
        this.fullScore = fullScore;
    }

    public Double getRealScore() {
        return realScore;
    }

    public void setRealScore(Double realScore) {
        this.realScore = realScore;
    }

    public Integer getCreateBy() {
        return createBy;
    }

    public void setCreateBy(Integer createBy) {
        this.createBy = createBy;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(Integer updateBy) {
        this.updateBy = updateBy;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getIsdelete() {
        return isdelete;
    }

    public void setIsdelete(Integer isdelete) {
        this.isdelete = isdelete;
    }

    @Override
    protected Serializable pkVal() {
        return this.relId;
    }

    @Override
    public String toString() {
        return "StatAssessmentTargetUserRel{" +
        ", relId=" + relId +
        ", userId=" + userId +
        ", stuId=" + stuId +
        ", examRecordId=" + examRecordId +
        ", assessmentTargetId=" + assessmentTargetId +
        ", assessmentTargetName=" + assessmentTargetName +
        ", fullScore=" + fullScore +
        ", realScore=" + realScore +
        ", createBy=" + createBy +
        ", createTime=" + createTime +
        ", updateBy=" + updateBy +
        ", updateTime=" + updateTime +
        ", isdelete=" + isdelete +
        "}";
    }
}
