package com.ruida.common.util;

import net.sf.json.JsonConfig;
import net.sf.json.processors.JsonValueProcessor;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Created by Administrator on 2018/11/14.
 */
public class JsonDateValueProcessor implements JsonValueProcessor{
    private String format = "yyyy-MM-dd";

    public JsonDateValueProcessor() {
    }

    public JsonDateValueProcessor(String format) {
        this.format = format;
    }

    @Override
    public Object processArrayValue(Object paramObject, JsonConfig paramJsonConfig) {
        return this.process(paramObject);
    }

    @Override
    public Object processObjectValue(String paramString, Object paramObject, JsonConfig paramJsonConfig) {
        return this.process(paramObject);
    }

    private Object process(Object value) {
        if(value instanceof Date) {
            SimpleDateFormat sdf = new SimpleDateFormat(this.format, Locale.CHINA);
            return sdf.format(value);
        } else {
            return value == null?"":value.toString();
        }
    }
}
