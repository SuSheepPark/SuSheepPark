package com.ruida.mockcommon.excel;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * CellNode 节点数据
 *
 * @author szl
 *
 */
public class CellNode implements Serializable {

	private static final long serialVersionUID = 8842191357772228473L;
	/**
	 * 单元格的内容
	 */
	private String value;
	/**
	 * 合并几列
	 */
	private int col = 1;
	/**
	 * 合并几行
	 */
	private int row = 1;
	/**
	 * 下一个单元格节点，合并的单元格的包含多个单元格，否则只有1个单元格
	 */
	private List<CellNode> childNodeList = new ArrayList<CellNode>();
	/**
	 * 父节点
	 */
	private CellNode parentNode;
	/**
	 * 链接
	 */
	private String link;

	/**
	 * 样式相关
	 */
	private short color;

	/**
	 * 标题设置字体样式
	 */
	private boolean isTitleCell;

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public int getCol() {
		return col;
	}

	public void setCol(int col) {
		this.col = col;
	}

	public int getRow() {
		return row;
	}

	public void setRow(int row) {
		this.row = row;
	}

	public CellNode getParentNode() {
		return parentNode;
	}

	public void setParentNode(CellNode parentNode) {
		this.parentNode = parentNode;
	}

	public List<CellNode> getChildNodeList() {
		return childNodeList;
	}

	public void addChild(CellNode childNode) {
		if (childNode != null) {
			this.childNodeList.add(childNode);
			childNode.parentNode = this;
		}
	}

	public void clearChildren() {
		this.childNodeList.clear();
	}

	public void increaseRowOfParent() {
		CellNode parent = this.parentNode;
		while (parent != null) {
			parent.increaseRow();
			parent = parent.parentNode;
		}
	}

	public void increaseRow() {
		this.row++;
	}

	public void increaseCol() {
		this.col++;
	}

	public short getColor() {
		return color;
	}

	public void setColor(short color) {
		this.color = color;
	}

	public boolean isTitleCell() {
		return isTitleCell;
	}

	public void setTitleCell(boolean isTitleCell) {
		this.isTitleCell = isTitleCell;
	}

	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}

	/**
	 * 获取N代子节点
	 *
	 * @param gener
	 *            代数，0:表示自身，1表示第一代子节点，以此类推
	 * @return
	 */
	public CellNode getFirstChildByGener(int gener) {
		CellNode node = this;
		for (int i = 0; i < gener; i++) {
			node = node.getChildNodeList().get(0);
		}
		return node;
	}
}
