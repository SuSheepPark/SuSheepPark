package com.ruida.mockdao.dao;

import com.ruida.mockdao.model.TMajorCollege;
import com.ruida.mockdao.model.TMajorRecommend;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * 选科方案-专业推荐记录表 Mapper 接口
 * </p>
 *
 * @author szl
 * @since 2021-02-23
 */
public interface TMajorRecommendMapper extends BaseMapper<TMajorRecommend> {
    /**
     * 清空学校录取分数表数据
     * @return
     */
    @Delete("DELETE FROM t_college_info")
    Integer deleteCollegeInfo();
    /**
     * 创建学校录取分数表数据
     * @return
     */
       @Insert("INSERT INTO t_college_info (\n" +
            "  college_code,\n" +
            "  admit_score,\n" +
            "  college_name\n" +
            ") SELECT\n" +
            "  a.college_code,\n" +
            "  MIN(a.min_score),\n" +
            "  a.college_name\n" +
            "FROM\n" +
            "  t_major_college a\n" +
            "GROUP BY\n" +
            "  a.college_code")
     Integer createCollegeInfo();

}
