package com.ruida.assessment.assessmentquestionbank.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.assessment.assessmentquestionbank.dto.ProductQueryRequest;
import com.ruida.assessment.assessmentquestionbank.model.TProduct;
import com.ruida.assessment.assessmentquestionbank.model.TReportTemplate;
import com.ruida.assessment.assessmentquestionbank.vo.ProductListVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;


import java.util.List;

/**
 * @author wy
 * @description 报告模板mapper
 * @date 2020/6/24
 */
@Mapper
public interface ReportTemplateMapper extends BaseMapper<TReportTemplate> {

}
