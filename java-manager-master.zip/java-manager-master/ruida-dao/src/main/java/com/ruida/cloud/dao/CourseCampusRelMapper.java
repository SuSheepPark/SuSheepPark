package com.ruida.cloud.dao;

import com.ruida.cloud.model.CourseCampusRel;
import com.ruida.cloud.model.CourseCampusRelExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface CourseCampusRelMapper {
    long countByExample(CourseCampusRelExample example);

    int deleteByExample(CourseCampusRelExample example);

    int deleteByPrimaryKey(Integer courseCampusId);

    int insert(CourseCampusRel record);

    int insertSelective(CourseCampusRel record);

    List<CourseCampusRel> selectByExample(CourseCampusRelExample example);

    CourseCampusRel selectByPrimaryKey(Integer courseCampusId);

    int updateByExampleSelective(@Param("record") CourseCampusRel record, @Param("example") CourseCampusRelExample example);

    int updateByExample(@Param("record") CourseCampusRel record, @Param("example") CourseCampusRelExample example);

    int updateByPrimaryKeySelective(CourseCampusRel record);

    int updateByPrimaryKey(CourseCampusRel record);
}