package com.ruida.common.util;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class DateMT {

	/**
	 * 获取年份
	 */
	public static String getYear() {
		return new SimpleDateFormat("yyyy").format(new Date());
	}

	/**
	 * 按yyyy-MM-dd样式获取当前日期
	 */
	public static String getDate() {
		return new SimpleDateFormat("yyyy-MM-dd").format(new Date());
	}

	/**
	 * 按yyyy-MM-dd HH:mm:ss样式获取当前时间
	 * @return
	 */
	public static String getTime() {
		return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
	}

	/**
	 * 根据样式获取当前日期
	 * @param format
	 * @return
	 */
	public static String getDate(String format) {
		return new SimpleDateFormat(format).format(new Date());
	}

	/**
	 * 获取1天时间范围
	 * @param day
	 * @return
     */
	public static Date[] oneDayRange(String day){
		try{
			String st = day + " 00:00:00";
			String ed = day + " 23:59:59";

			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			return  new Date[]{sdf.parse(st),sdf.parse(ed)};
		}catch(Exception e){
			return null;
		}
	}

	/**
	 * 本月
	 * @return
	 */
	public static Date[] oneMonthRange(){
		try{
			Calendar calendar1 = Calendar.getInstance();
			calendar1.set(Calendar.DAY_OF_MONTH, 1);
			calendar1.set(Calendar.HOUR_OF_DAY, 0);
			calendar1.set(Calendar.MINUTE, 0);
			calendar1.set(Calendar.SECOND, 0);

			Calendar calendar2 = Calendar.getInstance();
			calendar2.set(Calendar.DAY_OF_MONTH, calendar2.getActualMaximum(Calendar.DAY_OF_MONTH));
			calendar2.set(Calendar.HOUR_OF_DAY, 23);
			calendar2.set(Calendar.MINUTE, 59);
			calendar2.set(Calendar.SECOND, 59);
			return  new Date[]{calendar1.getTime(),calendar2.getTime()};
		}catch(Exception e){
			return null;
		}
	}

	/**
	 * 前一个月
	 * @return
     */
	public static Date[] preOneMonthRange(){
		try{
			//获取前一个月第一天
			Calendar calendar1 = Calendar.getInstance();
			calendar1.add(Calendar.MONTH, -1);
			calendar1.set(Calendar.DAY_OF_MONTH,1);
			calendar1.set(Calendar.HOUR_OF_DAY, 0);
			calendar1.set(Calendar.MINUTE, 0);
			calendar1.set(Calendar.SECOND, 0);
			//获取前一个月最后一天
			Calendar calendar2 = Calendar.getInstance();
			calendar2.set(Calendar.DAY_OF_MONTH, 0);
			calendar2.set(Calendar.HOUR_OF_DAY, 23);
			calendar2.set(Calendar.MINUTE, 59);
			calendar2.set(Calendar.SECOND, 59);
			return  new Date[]{calendar1.getTime(),calendar2.getTime()};
		}catch(Exception e){
			return null;
		}
	}
}
