package com.ruida.cloud.dao;

import com.ruida.cloud.model.TBroadcastRoomExt;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * 直播间表 Mapper 接口
 * </p>
 *
 * @author mlzhang
 * @since 2019-04-04
 */
public interface TBroadcastRoomMapperExt {

    int countBroadcastRoomByExample(Map condition);

    List<TBroadcastRoomExt> selectBroadcastRoomByExample(Map condition);

    List<Map<String ,Object>> getBroadcastRoomList(Map<String,Object> param);

    List<Map<String, Object>> getVdStudentIdAndClassRoomId(Map<String,Object> param);

    List<Map<String, Object>> getVdClassRoomIdForStu(Map<String,Object> param);

    List<Map<String, Object>> getCampusIdsByRoomIds(Map<String,Object> param);

    List<Map<String, Object>> getMinPersonNum(Integer roomId);

    TBroadcastRoomExt selectSurplusBroadcastNum(@Param("courseId") Integer courseId,@Param("broadcastRoomId") Integer broadcastRoomId);
}
