package com.ruida.cloud.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ruida.common.SystemConstant;
import com.ruida.common.util.excel.ExcelAnnotation;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

@Data
public class DoubleTeacherSchoolZone {

    /**
     * 双师校区id
     */
    private Integer zone_id;

    /**
     * 双师校区名称
     */
    private String name;

}