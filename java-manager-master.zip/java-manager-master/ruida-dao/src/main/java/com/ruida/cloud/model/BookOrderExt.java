package com.ruida.cloud.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ruida.common.SystemConstant;
import com.ruida.common.util.excel.ExcelAnnotation;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @author szl
 * @description: 订单扩展
 * @Date 2019/1/22
 * @verion 1.0
 */
@Data
public class BookOrderExt implements Serializable {
    private static final long serialVersionUID = 1301348948907189693L;
    /**
     * 订单主键ID
     */
    private Integer orderId;

    /**
     * 订单编号
     */
    @ExcelAnnotation(title = "订单编号")
    private String orderNo;

    /**购买人名字*/
    @ExcelAnnotation(title = "购买人")
    private String purchaseName;

    /**
     * 订单交易号
     */
    private String orderTransNo;

    /**
     * 订单名称
     */
    @ExcelAnnotation(title = "图书名称")
    private String orderName;

    /**
     * 订单金额
     */
    @ExcelAnnotation(title = "原价")
    private BigDecimal orderAmount;

    /**
     * 优惠金额
     */
    @ExcelAnnotation(title = "优惠价")
    private BigDecimal saleAmount;

    /**
     * 实付金额
     */
    @ExcelAnnotation(title = "支付价")
    private BigDecimal payAmount;


    /**
     * 购买人ID（关联sys_user表的user_id）
     */
    private Integer purchaserId;

    /**
     * 购买人联系电话
     */
    private String telephone;

    /**
     * 支付方式（0—微信支付；1—支付宝；2—Q钱包；3—网银支付）
     */
    private Byte paymentType;

    /**
     * 支付方式名字
     */
    @ExcelAnnotation(title = "支付方式")
    private  String paymentTypeName;

    /**
     * 订单状态（0—待支付；1—已支付；2—已关闭）
     */
    private Byte status;

    /**
     * 订单来源（0—PC端；1—IOS端；2—Android端）
     */
    private Byte source;

    /**
     * 订单创建时间
     */
    @JsonFormat(pattern= SystemConstant.DATE_FORMAT,timezone=SystemConstant.TIME_ZONE)
    private Date createTime;

    /**
     * 订单更新时间
     */
    @JsonFormat(pattern= SystemConstant.DATE_FORMAT,timezone=SystemConstant.TIME_ZONE)
    private Date updateTime;

    /**
     * 订单付款时间
     */
    @JsonFormat(pattern=SystemConstant.DATE_FORMAT,timezone=SystemConstant.TIME_ZONE)
    private Date paymentTime;

    /**
     * 交易完成时间（保留字段，暂时不使用）
     */
    @JsonFormat(pattern=SystemConstant.DATE_FORMAT,timezone=SystemConstant.TIME_ZONE)
    private Date endTime;

    /**
     * 交易关闭时间
     */
    @JsonFormat(pattern=SystemConstant.DATE_FORMAT,timezone=SystemConstant.TIME_ZONE)
    private Date closeTime;

    /**
     * 是否删除（0：未删除；1：删除）
     */
    private Byte isdelete;
    /**教师名字*/

    /**订单状态名*/
    @ExcelAnnotation(title = "订单状态")
    private String statusName;

    //图书id
    private Integer bookId;
    //筛选开始时间
    private long searchStartTime;
    //帅选结束时间
    private long searchEndTime;
    //筛选开始时间
    private long searchStartDate;
    //帅选结束时间
    private long searchEndDate;

    //订单类型
    private byte orderType;

//    public String getStatusName() {
//       switch (this.getStatus()){
//           case 0:
//               this.setStatusName("待支付");
//               break;
//           case 1:
//               this.setStatusName("已支付");
//               break;
//           case 2:
//               this.setStatusName("已关闭");
//               break;
//                   default:
//
//       }
//        return statusName;
//    }
}
