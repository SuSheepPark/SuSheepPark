package com.ruida.common.strategy;

import java.util.HashMap;
import java.util.Map;

/**
 * @author taosh
 * @create 2019-03-21 15:42
 */
public class ValidStrategy {
    public static final String UNLIMITED = "无限期";
    public static final String ONE_MONTH = "1个月";
    public static final String THREE_MONTH = "3个月";
    public static final String SIX_MONTH = "6个月";
    public static final String NINE_MONTH = "9个月";
    public static final String TWELVE_MONTH = "12个月";
    public static final String TWO_YEAR = "2年";
    public static final String THREE_YEAR = "3年";

    private static Map<String, Integer> validTime = new HashMap<>();

    static {
        validTime.put(UNLIMITED, 0);
        validTime.put(ONE_MONTH, 1);
        validTime.put(THREE_MONTH, 3);
        validTime.put(SIX_MONTH, 6);
        validTime.put(NINE_MONTH, 9);
        validTime.put(TWELVE_MONTH, 12);
        validTime.put(TWO_YEAR, 24);
        validTime.put(THREE_YEAR, 36);
    }

    public static Integer get(String valid){
        if( !validTime.containsKey(valid) ){
            return validTime.get(UNLIMITED);
        }
        return validTime.get(valid);
    }
}
