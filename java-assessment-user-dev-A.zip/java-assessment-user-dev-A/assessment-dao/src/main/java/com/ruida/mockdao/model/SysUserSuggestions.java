package com.ruida.mockdao.model;

import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 用户意见反馈关联表
 * </p>
 *
 * @author Bhj
 * @since 2020-07-15
 */
@TableName("sys_user_suggestions")
public class SysUserSuggestions extends Model<SysUserSuggestions> {

    private static final long serialVersionUID = 1L;

    /**
     * 用户意见反馈关联主键ID
     */
    @TableId(value = "suggestion_id", type = IdType.AUTO)
    private Integer suggestionId;
    /**
     * 用户ID
     */
    @TableField("user_id")
    private Integer userId;
    /**
     * 联系方式
     */
    @TableField("contact_method")
    private String contactMethod;
    /**
     * 上传图片路径
     */
    @TableField("image_url")
    private String imageUrl;
    /**
     * 是否解决（0—未回复；1—已回复）
     */
    private Integer status;
    /**
     * 意见反馈内容
     */
    @TableField("suggestion_content")
    private String suggestionContent;
    /**
     * 回复内容
     */
    @TableField("reply_content")
    private String replyContent;
    /**
     * 创建时间
     */
    @TableField("create_time")
    private Date createTime;
    /**
     * 更新者ID（关联user_id）
     */
    @TableField("update_by")
    private Integer updateBy;
    /**
     * 更新时间
     */
    @TableField("update_time")
    private Date updateTime;
    /**
     * 是否删除（0：未删除；1：删除）
     */
    private Integer isdelete;


    public Integer getSuggestionId() {
        return suggestionId;
    }

    public void setSuggestionId(Integer suggestionId) {
        this.suggestionId = suggestionId;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getContactMethod() {
        return contactMethod;
    }

    public void setContactMethod(String contactMethod) {
        this.contactMethod = contactMethod;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getSuggestionContent() {
        return suggestionContent;
    }

    public void setSuggestionContent(String suggestionContent) {
        this.suggestionContent = suggestionContent;
    }

    public String getReplyContent() {
        return replyContent;
    }

    public void setReplyContent(String replyContent) {
        this.replyContent = replyContent;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(Integer updateBy) {
        this.updateBy = updateBy;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getIsdelete() {
        return isdelete;
    }

    public void setIsdelete(Integer isdelete) {
        this.isdelete = isdelete;
    }

    @Override
    protected Serializable pkVal() {
        return this.suggestionId;
    }

    @Override
    public String toString() {
        return "SysUserSuggestions{" +
        ", suggestionId=" + suggestionId +
        ", userId=" + userId +
        ", contactMethod=" + contactMethod +
        ", imageUrl=" + imageUrl +
        ", status=" + status +
        ", suggestionContent=" + suggestionContent +
        ", replyContent=" + replyContent +
        ", createTime=" + createTime +
        ", updateBy=" + updateBy +
        ", updateTime=" + updateTime +
        ", isdelete=" + isdelete +
        "}";
    }
}
