package com.ruida.cloud.model;

/**
 * @author taosh
 * @create 2019-02-21 14:22
 */
public class CourseNonPublicClass extends CourseNonPublicUser {
    //学校名
    private String schoolName;
    //年级
    private String stageName;
    //班级
    private String className;
    //辅课老师
    private String assistantTeachers;
    //辅课老师学校
    private String teacherSchoolName;
    //辅课老师电话
    private String teacherTelephone;

    public String getSchoolName() {
        return schoolName;
    }

    public void setSchoolName(String schoolName) {
        this.schoolName = schoolName;
    }

    public String getStageName() {
        return stageName;
    }

    public void setStageName(String stageName) {
        this.stageName = stageName;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public String getAssistantTeachers() {
        return assistantTeachers;
    }

    public void setAssistantTeachers(String assistantTeachers) {
        this.assistantTeachers = assistantTeachers;
    }

    public String getTeacherSchoolName() {
        return teacherSchoolName;
    }

    public void setTeacherSchoolName(String teacherSchoolName) {
        this.teacherSchoolName = teacherSchoolName;
    }

    public String getTeacherTelephone() {
        return teacherTelephone;
    }

    public void setTeacherTelephone(String teacherTelephone) {
        this.teacherTelephone = teacherTelephone;
    }
}
