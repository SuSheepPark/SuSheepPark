/**   
 * Copyright © 2019 公司名. All rights reserved.
 * 
 * @Title: UserService2.java 
 * @Prject: zhaowei-cms
 * @Package: com.zhaowei.cms.service.impl 
 * @Description: TODO
 * @author: zw   
 * @date: 2019年9月10日 下午8:50:13 
 * @version: V1.0   
 */
package com.zhaowei.cms.service.impl;

import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.zhaowei.cms.dao.UserMapper;
import com.zhaowei.cms.domain.User;
import com.zhaowei.cms.service.UserService;
import com.zhaowei.cms.util.CMSEception;
import com.zhaowei.cms.util.Md5Util;
import com.zhaowei.cms.vo.UserVO;

/** 
 * @ClassName: UserService2 
 * @Description: TODO
 * @author: zw
 * @date: 2019年9月10日 下午8:50:13  
 */
@Service
public class UserServiceImpl implements UserService {

	@Resource
	private UserMapper userMapper;
	
	@Override
	public PageInfo<User> selects(String name,Integer page,Integer pageSize){
		PageHelper.startPage(page, pageSize);
		List<User> list = userMapper.selects(name);
		return new PageInfo<User>(list);
	}

	@Override
	public int insertSelective(UserVO userVO) {
		//判断用户的注册信息
		//两次密码是否一致
		if(!userVO.getPassword().equals(userVO.getRepassword())) {
			throw new CMSEception("两次密码输入不一致");
		}
		//判断注册的用户存在不存在
		User user = userMapper.selectsByUsername(userVO.getUsername());
		if(null!=user) {
			throw new CMSEception("注册用户已经存在，不能重复注册");
		}
		//3.对密码进行加密
		String md5Password = Md5Util.md5Encoding(userVO.getPassword());
				
		userVO.setPassword(md5Password);
				
		//4.用户去其他属性进行默认值处理
		userVO.setLocked(0);//不锁定
		userVO.setCreated(new Date());//注册时间
		userVO.setUpdated(new Date());//注册时间
		userVO.setNickname(userVO.getUsername());//用户昵称等于用户名
		return userMapper.insertSelective(userVO);
	}

	@Override
	public User selectByPrimaryKey(Integer id) {
		// TODO Auto-generated method stub
		return userMapper.selectByPrimaryKey(id);
	}

	@Override
	public int updateByPrimaryKeySelective(User record) {
		// TODO Auto-generated method stub
		return userMapper.updateByPrimaryKeySelective(record);
	}

	@Override
	public User login(User user) {
		//user对象不能为空
		if(null==user)
			throw new CMSEception("用户名不能为空");
		//用户民和密码都不能为空
		if(null==user.getUsername()||null==user.getPassword())
			throw new CMSEception("用户名和密码不能为空！");
		//判断用户是否存在
        User user2 = userMapper.selectByUsername(user.getUsername());
        if(null==user2) {
        throw new CMSEception("用户名不存在!");	 
        }else {
          if(!user2.getPassword().equals(Md5Util.md5Encoding(user.getPassword()))) {
          throw new CMSEception("密码错了!");
          }
        }
        if(user2.getLocked()==1) {
        	throw new CMSEception("用户被禁用,禁止开车不懂吗");
        }
		return user2;
	}

	@Override
	public int insertSelective(User record) {
		// TODO Auto-generated method stub
		return 0;
	}

}
