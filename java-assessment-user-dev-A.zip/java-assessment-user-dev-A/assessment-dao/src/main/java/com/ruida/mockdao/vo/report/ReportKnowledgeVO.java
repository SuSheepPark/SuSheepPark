package com.ruida.mockdao.vo.report;

import com.ruida.mockcommon.entity.TreeNode;
import lombok.Data;

import java.io.Serializable;
import java.util.Objects;

/**
 * @description: 报告知识点VO
 * @author: chenjy
 * @create: 2020-08-11 11:12
 */
@Data
public class ReportKnowledgeVO extends TreeNode implements Serializable {

    /*满分*/
    private Double totalScore;

    /*得分*/
    private Double score;

    /*班级平均分*/
    private Double classAvg;

    /*学校平均分*/
    private Double schoolAvg;

    /*9+1学校平均分*/
    private Double nineOneSchoolAvg;

    /*联考学校平均分*/
    private Double unionAvg;

    /*得分率*/
    private String scoreRate;

    /*学校得分率*/
    private String schoolScoreRate;

    /*9+1学校得分率*/
    private String nineOneSchoolScoreRate;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        ReportKnowledgeVO that = (ReportKnowledgeVO) o;
        return Objects.equals(super.getId(), that.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), super.getId());
    }
}
