package com.ruida.mockdao.model;

import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;

import java.io.Serializable;
import java.util.Date;

/**
 * @description: 选考科目成绩报告数据库实体
 * @author: kgz
 * @date: 2021/2/24
 */
@TableName("t_optional_subject_report")
public class OptionalSubjectReport extends Model<OptionalSubjectReport>{

    /**
     * 主键ID
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 选考科目成绩信息
     */
    private String optionalSubjectRecord;

    /**
     * 必考科目成绩信息
     */
    private String requiredSubjectRecord;

    /**
     * 选考科目小结信息
     */
    private String examRecordSummary;

    /**
     * 状态（0—禁用；1—启用）
     */
    private Integer status;

    /**
     * 创建者ID
     */
    private Integer createBy;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新者ID
     */
    private Integer updateBy;

    /**
     * 更新时间
     */
    private Date updateTime;

    /**
     * 是否删除（0：未删除；1：删除）
     */
    private Integer isdelete;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getOptionalSubjectRecord() {
        return optionalSubjectRecord;
    }

    public void setOptionalSubjectRecord(String optionalSubjectRecord) {
        this.optionalSubjectRecord = optionalSubjectRecord;
    }

    public String getRequiredSubjectRecord() {
        return requiredSubjectRecord;
    }

    public void setRequiredSubjectRecord(String requiredSubjectRecord) {
        this.requiredSubjectRecord = requiredSubjectRecord;
    }

    public String getExamRecordSummary() {
        return examRecordSummary;
    }

    public void setExamRecordSummary(String examRecordSummary) {
        this.examRecordSummary = examRecordSummary;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getCreateBy() {
        return createBy;
    }

    public void setCreateBy(Integer createBy) {
        this.createBy = createBy;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(Integer updateBy) {
        this.updateBy = updateBy;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getIsdelete() {
        return isdelete;
    }

    public void setIsdelete(Integer isdelete) {
        this.isdelete = isdelete;
    }

    @Override
    protected Serializable pkVal() {
        return this.id;
    }
}
