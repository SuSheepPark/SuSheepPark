package com.ruida.mockservice.service;

import com.baomidou.mybatisplus.service.IService;
import com.ruida.mockdao.model.ExamRecord;
import com.ruida.mockdao.vo.ExamRecordVO;

/**
 * <p>
 * 考试记录表 服务类
 * </p>
 *
 * @author chenjy
 * @since 2020-07-15
 */
public interface ExamRecordService extends IService<ExamRecord> {

    ExamRecordVO queryLatestExamInfo();

}
