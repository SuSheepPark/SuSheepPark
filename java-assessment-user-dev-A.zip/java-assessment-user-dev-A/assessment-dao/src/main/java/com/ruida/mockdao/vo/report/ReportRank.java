package com.ruida.mockdao.vo.report;

import lombok.Data;

import java.io.Serializable;

/**
 * @description:
 * @author: chenjy
 * @create: 2020-08-14 15:45
 */
@Data
public class ReportRank implements Serializable {

    /**
     * 用户id
     */
    private Integer userId;

    /**
     * 排名
     */
    private Integer rank;

    /**
     * 得分
     */
    private Double score;
}
