package com.ruida.mockdao.form;

import lombok.Data;

/**
 * @author admin
 * @description: ${TODO}
 * @Date 2019/6/3
 * @verion 1.0
 */
@Data
public class WXPayForm {

    /**
     * 订单主题
     */
    private String body;
    /**
     * 订单号
     */
    private String outTradeNo;
    /**
     * 支付类型 （APP app支付; NATIVE 扫码支付; JSAPI 微信内部支付; MWEB h5支付 ；LETAPP小程序支付  ）
     */
    private String tradeType;
    /**
     * //网页授权参数
     */
    private String openid;
}
