package com.ruida.cloud.weidu.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.ruida.cloud.dao.WeiduCampusRelMapper;
import com.ruida.cloud.model.WeiduCampusRel;
import com.ruida.cloud.weidu.config.WeiduConfig;
import com.ruida.cloud.weidu.dao.VdyooFactory;
import com.ruida.cloud.weidu.exception.VdyooException;
import com.ruida.cloud.weidu.service.BaseVdyooService;
import com.ruida.cloud.weidu.utils.PropertyUtil;
import com.ruida.cloud.weidu.utils.VdyooUtil;
import com.ruida.cloud.weidu.vo.VdyooEntity;
import com.ruida.common.context.BaseContextHandle;
import com.ruida.common.util.ValidateMT;
import com.sun.org.apache.xpath.internal.operations.Bool;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * 校区
 * 关联表信息：
 * * 睿达学校id      pid
 * * 威渡id         id
 *
 * @author taosh
 * @create 2019-04-23 15:09
 */
@Service
@Slf4j
public class VdyooSchoolService extends BaseVdyooService {
    @Resource
    private WeiduCampusRelMapper weiduCampusRelMapper;

    /**
     * 新增校区
     */
    public Boolean addDepartment(Map map) {
        Map<String, Object> param = new HashMap<>(3);
        //校区id
        param.put("pid", map.get("pid"));
        //父id       睿达暂无
        param.put("parentId", map.get("parentId"));
        //校区名称
        param.put("name", map.get("name"));
        VdyooEntity vdyooEntity = vdyooFactory.post(param, WeiduConfig.addDepartment);
        boolean flag = false;
        if (vdyooEntity.getSuccess()) {
            String id = null;
            try {
                WeiduCampusRel weiduCampusRel = new WeiduCampusRel();
                weiduCampusRel.setCampusId(Integer.parseInt(map.get("pid").toString()));
                JSONObject object =(JSONObject) JSON.toJSON(vdyooEntity.getPayload());
                weiduCampusRel.setWeiduCampusId(object.getString("id"));
                id = object.getString("id");
                weiduCampusRel.setIsdelete((byte) 0);
                weiduCampusRel.setCreateTime(new Date());
                weiduCampusRel.setCreateBy(BaseContextHandle.getUserId());
                weiduCampusRel.setUpdateBy(BaseContextHandle.getUserId());
                weiduCampusRel.setUpdateTime(new Date());
                flag = weiduCampusRelMapper.insert(weiduCampusRel) > 0;
            } catch (Exception e) {
                //回滚
                if (ValidateMT.isNotNull(id)) {
                    this.deleteDepartmentById(id);
                }
                e.printStackTrace();
                throw new VdyooException("500", "操作失败");
            }
        }
        //添加关联表
        return flag;
    }

    /**
     * 删除 校区
     *
     * @param id
     * @return
     */
    public boolean deleteDepartmentById(String id) {
        Map<String, Object> params = new HashMap<>(1);
        params.put("id", id);
        return this.vdyooFactory.post(params, WeiduConfig.deleteDepartmentById).getSuccess();
    }

    /**
     * 编辑校区
     */
    public Boolean editDepartmentById(Map map) {
        Map<String, Object> param = new HashMap<>(3);
        //校区id
        param.put("id", map.get("id").toString());
        //校区名称
        param.put("name", map.get("name"));
        return vdyooFactory.post(param, WeiduConfig.editDepartmentById).getSuccess();
    }

    /**
     * 查询所有校区
     */
    public Boolean findDepartmentByParentId() {
        Map<String, Object> param = new HashMap<>(1);
        //校区id
        param.put("parentId", "0");
        return vdyooFactory.post(param, WeiduConfig.findDepartmentByParentId).getSuccess();
    }
}
