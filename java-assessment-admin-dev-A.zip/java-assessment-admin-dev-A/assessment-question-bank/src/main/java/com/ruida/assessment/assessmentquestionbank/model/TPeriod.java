package com.ruida.assessment.assessmentquestionbank.model;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;

/**
 * @description: 学段数据库实体
 * @author: kgz
 * @date: 2020/6/18
 */
@TableName("t_period")
public class TPeriod extends BaseColumn implements Serializable {
    private static final long serialVersionUID = 4988017036536477851L;

    /**
     * 学段id
     */
    @TableId
    private Integer id;

    /**
     * 学段名称
     */
    private String periodName;

    /**
     * 状态（0—禁用；1—启用）
     */
    private String status;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getPeriodName() {
        return periodName;
    }

    public void setPeriodName(String periodName) {
        this.periodName = periodName;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
