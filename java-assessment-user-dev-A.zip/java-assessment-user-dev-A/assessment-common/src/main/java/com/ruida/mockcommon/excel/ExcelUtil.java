package com.ruida.mockcommon.excel;

import com.ruida.mockcommon.enums.WeekEnum;
import org.apache.poi.hssf.usermodel.DVConstraint;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFDataValidation;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.ss.util.CellRangeAddressList;
import org.apache.poi.ss.util.CellUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.*;
import java.util.Map.Entry;


/**
 * Excel 生成工具
 *
 * @author szl
 */
public class ExcelUtil {

	/**
	 * 日志记录
	 */
	private static final Logger logger = LoggerFactory.getLogger(ExcelUtil.class);

	private static final String TITLE_STYLE_KEY  = "titleStyle";

	private static final String RANGE_STYLE_KEY  = "rangeStyle";

	private static final String NORMAL_STYLE_KEY = "normalStyle";

	private static final String SUM_STYLE_KEY 	 = "sumStyle";

	/**
	 * 写入数据至Excel文件
	 *
	 * @param areas
	 * @param pickups
	 * @return
	 */
	public static Workbook writeToExcel(TreeMap<Integer, List<CellNode>> nodeMaps, String[] areas, String[] pickups) {
		// 创建一个工作簿
		Workbook wb = new HSSFWorkbook();
		for (Entry<Integer, List<CellNode>> entry : nodeMaps.entrySet()) {
			createSheet(wb, entry.getValue(), areas, pickups, WeekEnum.getNameById(entry.getKey()));
		}
		return wb;
	}

	/**
	 * Excel文件新建一个sheet template
	 *
	 * @param wb
	 * @param nodeList
	 * @param areas
	 * @param pickups
	 * @param sheetName
	 */
	public static void createSheet(Workbook wb, List<CellNode> nodeList, String[] areas, String[] pickups,
			String sheetName) {
		// 创建一个表
		Sheet sheet = wb.createSheet(sheetName);
		Map<String, CellStyle> cellStyleMap = new HashMap<String, CellStyle>(16);
		if (nodeList != null && nodeList.size() > 0) {
			createRows(sheet, nodeList, 0, 0, cellStyleMap);
		}
		// 设置区域下拉
		if (areas != null && areas.length > 0) {
			setValidationData(sheet, areas, 1, areas.length, 0, 0);
		}
		if (pickups != null && pickups.length > 0) {
			setValidationData(sheet, pickups, 1, areas.length, 1, sheet.getRow(0).getLastCellNum() - 1);
		}
		// 设置下拉
		autoSizeColumn(sheet);

	}

	/**
	 * 绑定下拉数据
	 *
	 * @param sheet
	 *            sheet
	 * @param dropDowdData
	 *            下拉数据
	 * @param firstRow
	 *            开始行
	 * @param lastRow
	 *            结束行
	 * @param firstCol
	 *            开始列
	 * @param lastCol
	 *            结束列
	 */
	private static void setValidationData(Sheet sheet, String[] dropDowdData, int firstRow, int lastRow, int firstCol,
			int lastCol) {
		if (dropDowdData != null && dropDowdData.length > 0) {
			// 设置指定区域的下拉
			CellRangeAddressList regions = new CellRangeAddressList(firstRow, lastRow, firstCol, lastCol);
			// 创建下拉列表数据
			DVConstraint constraint = DVConstraint.createExplicitListConstraint(dropDowdData);
			// 数据绑定
			HSSFDataValidation dataValidation = new HSSFDataValidation(regions, constraint);
			// 添加绑定数据至sheet
			sheet.addValidationData(dataValidation);
		}
	}

	/**
	 * 数据生成Excel文件
	 *
	 * @param nodeList
	 * @param sheetName
	 * @return
	 */
	public static Workbook writeToExcel(List<CellNode> nodeList, String sheetName) {
		// 创建一个工作簿
		Workbook wb = new HSSFWorkbook();
		createSheet(wb, nodeList, sheetName);
		return wb;
	}

	/**
	 * Excel文件新建一个sheet
	 *
	 * @param wb
	 * @param nodeList
	 * @param sheetName
	 */
	public static void createSheet(Workbook wb, List<CellNode> nodeList, String sheetName) {
		// 创建一个表
		Sheet sheet = wb.createSheet(sheetName);
		Map<String, CellStyle> cellStyleMap = new HashMap<String, CellStyle>(16);
		if (nodeList != null && nodeList.size() > 0) {
			createRows(sheet, nodeList, 0, 0, cellStyleMap);
		}
		autoSizeColumn(sheet);
	}

	/**
	 * 创建单元行
	 *
	 * @param sheet
	 * @param nodeList
	 * @param rowNum
	 * @param colNum
	 * @param cellStyleMap
	 */
	private static void createRows(Sheet sheet, List<CellNode> nodeList, int rowNum, int colNum,
			Map<String, CellStyle> cellStyleMap) {
		for (CellNode node : nodeList) {
			// 合并单元格
			CellRangeAddress range = null;
			if (node.getCol() > 1 || node.getRow() > 1) {
				range = new CellRangeAddress(rowNum, rowNum + node.getRow() - 1, colNum, colNum + node.getCol() - 1);
				sheet.addMergedRegion(range);
			}
			Row row = sheet.getRow(rowNum);
			if (row == null) {
				row = sheet.createRow(rowNum);
			}
			row.setHeightInPoints(18);
			// 设置当前单元格
			Cell cell = row.createCell(colNum, HSSFCell.CELL_TYPE_STRING);
			cell.setCellValue(node.getValue());

			// 设置样式
			setStyle(cell, node, range, cellStyleMap);

			// 创建下一个单元格
			createRows(sheet, node.getChildNodeList(), rowNum, colNum + node.getCol(), cellStyleMap);
			// 创建下一行
			rowNum = rowNum + node.getRow();
		}
	}

	/**
	 * 设置样式
	 *
	 * @param cell
	 * @param node
	 * @param range
	 * @param cellStyleMap
	 */
	private static void setStyle(Cell cell, CellNode node, CellRangeAddress range,
			Map<String, CellStyle> cellStyleMap) {
		if (cell == null || node == null || cellStyleMap == null) {
			return;
		}
		CellStyle cellStyle = null;
		// 标题样式
		if (node.isTitleCell()) {
			cellStyle = getCellStyle(cell.getSheet().getWorkbook(), TITLE_STYLE_KEY, cellStyleMap);
			// 设置背景色
			if (node.getColor() > 0) {
				CellStyleUtil.setForeGroundColor(cellStyle, node.getColor());
			}
			// 设置字体
			CellStyleUtil.setFont(cellStyle, cell.getSheet().getWorkbook().createFont());
		} else if (node.getColor() > 0) {
			cellStyle = getCellStyle(cell.getSheet().getWorkbook(), SUM_STYLE_KEY, cellStyleMap);
			CellStyleUtil.setForeGroundColor(cellStyle, node.getColor());
		} else if (range != null) {
			cellStyle = getCellStyle(cell.getSheet().getWorkbook(), RANGE_STYLE_KEY, cellStyleMap);
			CellStyleUtil.setAlign(cellStyle, CellStyle.ALIGN_LEFT, CellStyle.VERTICAL_CENTER);
			setRegionStyle(cell.getSheet(), range, cellStyle);
		} else {
			cellStyle = getCellStyle(cell.getSheet().getWorkbook(), NORMAL_STYLE_KEY, cellStyleMap);
		}
		// 设置边框
		CellStyleUtil.setBorder(cellStyle);

		// 设置居中，合并的单元格居中
		CellStyleUtil.setAlign(cellStyle, CellStyle.ALIGN_LEFT, CellStyle.VERTICAL_CENTER);

		cell.setCellStyle(cellStyle);
	}

	/**
	 * 获取样式
	 *
	 * @param wb
	 * @param key
	 * @param cellStyleMap
	 * @return
	 */
	private static CellStyle getCellStyle(Workbook wb, String key, Map<String, CellStyle> cellStyleMap) {
		CellStyle cellStyle = cellStyleMap.get(key);
		if (cellStyle == null) {
			cellStyle = wb.createCellStyle();
			cellStyleMap.put(key, cellStyle);
		}
		return cellStyle;
	}

	/**
	 * 设置被合并的单元格的样式
	 *
	 * @param sheet
	 * @param region
	 * @param cellStyle
	 */
	private static void setRegionStyle(Sheet sheet, CellRangeAddress region, CellStyle cellStyle) {
		if (sheet == null || region == null || cellStyle == null) {
			return;
		}
		for (int i = region.getFirstRow(); i <= region.getLastRow(); i++) {
			Row row = CellUtil.getRow(i, sheet);
			for (int j = region.getFirstColumn(); j <= region.getLastColumn(); j++) {
				Cell cell = CellUtil.getCell(row, j);
				cell.setCellStyle(cellStyle);
			}
		}
	}

	/**
	 * POI的自适应对中文有bug，使用设置列的宽度
	 *
	 * @param sheet
	 */
	private static void autoSizeColumn(Sheet sheet) {
		if (sheet == null) {
			return;
		}
		Map<Integer, Integer> maxColumnSizeMap = new HashMap<Integer, Integer>(16);
		int maxColNum = 0;
		Iterator<Row> rowIt = sheet.rowIterator();
		while (rowIt.hasNext()) {
			Row row = rowIt.next();
			Iterator<Cell> cellIt = row.cellIterator();
			int colIndex = 0;
			while (cellIt.hasNext()) {
				Cell cell = cellIt.next();
				String value = cell.getStringCellValue();
				int length = value == null ? 0 : value.getBytes().length;
				int maxLen = maxColumnSizeMap.get(colIndex) == null ? 0 : maxColumnSizeMap.get(colIndex);
				maxLen = maxLen < length ? length : maxLen;
				maxColumnSizeMap.put(colIndex, maxLen);
				colIndex++;
			}
			maxColNum = maxColNum < colIndex ? colIndex : maxColNum;
		}

		for (int i = 0; i < maxColNum; i++) {
			int maxLen = maxColumnSizeMap.get(i) == null ? 0 : maxColumnSizeMap.get(i);
			if (maxLen > 0) {
				sheet.setColumnWidth(i, maxLen * 256 + 1024);
			}
		}
	}

	/**
	 * 写入文件
	 *
	 * @param nodeList
	 * @param sheetName
	 * @param fileName
	 */
	public static void writeToFile(List<CellNode> nodeList, String sheetName, String fileName) {
		// 将工作簿输出到文件
		FileOutputStream fileOut = null;
		try {
			fileOut = new FileOutputStream(fileName);
			Workbook wb = writeToExcel(nodeList, sheetName);
			wb.write(fileOut);
			fileOut.close();
		} catch (Exception e) {
			logger.error("write to excel file error!", e);
		} finally {
			if (fileOut != null) {
				try {
					fileOut.close();
				} catch (IOException e) {
					logger.error("close FileOutputStream error !", e);
				}
			}
		}
	}

	/**
	 *
	 * @param nodeList
	 * @return
	 */
	public static List<List<CellNode>> toCellNodeList(List<CellNode> nodeList) {
		List<List<CellNode>> resultList = new ArrayList<List<CellNode>>();
		if (nodeList == null || nodeList.size() == 0) {
			return resultList;
		}
		createListRows(resultList, nodeList, 0);
		return resultList;
	}

	/**
	 *
	 * @param resultList
	 * @param nodeList
	 * @param rowNum
	 */
	private static void createListRows(List<List<CellNode>> resultList, List<CellNode> nodeList, int rowNum) {
		for (CellNode node : nodeList) {
			List<CellNode> oneList = new ArrayList<CellNode>();
			if (resultList.size() > rowNum) {
				oneList = resultList.get(rowNum);
			} else {
				resultList.add(oneList);
			}
			oneList.add(node);
			// 创建下一个单元格
			createListRows(resultList, node.getChildNodeList(), rowNum);
			// 创建下一行
			rowNum = rowNum + node.getRow();
		}
	}

}
