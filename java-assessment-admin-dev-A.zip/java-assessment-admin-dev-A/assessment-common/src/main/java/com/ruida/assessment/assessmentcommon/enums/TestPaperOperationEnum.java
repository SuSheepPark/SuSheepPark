package com.ruida.assessment.assessmentcommon.enums;

/**
 * @description: 试卷操作枚举
 * @author: kgz
 * @date: 2020/6/30
 */
public enum TestPaperOperationEnum {
    ROUGH_DRAFT(0,"存草稿"),
    SUBMIT(1,"提交"),
    RETURN(2,"退回"),
    RELEASE(3,"发布"),
    RELEASE_CANCEL(4,"取消发布"),
    STORE_UP(5,"收藏"),
    DELETE(6,"删除"),
    ;


    private Integer K;
    private String V;

    TestPaperOperationEnum(Integer k, String v) {
        K = k;
        V = v;
    }

    public Integer getK() {
        return K;
    }

    public void setK(Integer k) {
        K = k;
    }

    public String getV() {
        return V;
    }

    public void setV(String v) {
        V = v;
    }


    public static TestPaperOperationEnum getValueById(Integer K){
        for(TestPaperOperationEnum testPaperOperationEnum : TestPaperOperationEnum.values() ){
            if(testPaperOperationEnum.getK().equals(K)){
                return  testPaperOperationEnum;
            }
        }
        return null;
    }

}
