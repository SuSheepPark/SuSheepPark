package com.ruida.cloud.dao;

import com.ruida.cloud.model.CommissionExt;
import com.ruida.cloud.model.PromotionActivityCommission;
import com.ruida.cloud.model.PromotionActivityCommissionExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface PromotionActivityCommissionMapper {
    long countByExample(PromotionActivityCommissionExample example);

    int deleteByExample(PromotionActivityCommissionExample example);

    int deleteByPrimaryKey(Integer commissionId);

    int insert(PromotionActivityCommission record);

    int insertSelective(PromotionActivityCommission record);

    List<PromotionActivityCommission> selectByExample(PromotionActivityCommissionExample example);

    PromotionActivityCommission selectByPrimaryKey(Integer commissionId);

    int updateByExampleSelective(@Param("record") PromotionActivityCommission record, @Param("example") PromotionActivityCommissionExample example);

    int updateByExample(@Param("record") PromotionActivityCommission record, @Param("example") PromotionActivityCommissionExample example);

    int updateByPrimaryKeySelective(PromotionActivityCommission record);

    int updateByPrimaryKey(PromotionActivityCommission record);

    /**
     * 批量插入
     */
    public boolean insertBatch(List<PromotionActivityCommission> list);

    /**
     * 批量更新
     * @param list
     * @return
     */
    public boolean updateBatch(List<PromotionActivityCommission> list);

    /**
     * 查询推广活动佣金信息
     * @param id 活动id
     * @return
     */
    List<CommissionExt> selectCommissionExtByCondition(@Param("id") int id);
}