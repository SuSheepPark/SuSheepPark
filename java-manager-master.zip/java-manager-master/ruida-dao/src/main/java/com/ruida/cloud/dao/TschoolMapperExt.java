package com.ruida.cloud.dao;

import com.ruida.cloud.model.Tschool;

import java.util.List;
import java.util.Map;

/**
 * @author admin
 * @description: ${TODO}
 * @Date 2019/1/10
 * @verion 1.0
 */
public interface TschoolMapperExt {
    int countByExampleSearch(Map condtion);
    List<Tschool> selectByExampleSearch(Map condtion);

}
