package com.ruida.mockdao.model;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableLogic;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;
import lombok.Data;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 
 * </p>
 *
 * @author jinhu
 * @since 2020-08-07
 */
@Data
@Accessors(chain = true)
@TableName("t_recommend_app_frontpage")
public class RecommendAppFrontpage implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;
    /**
     * 年级id，可为空，空的时候为默认
     */
    @TableField("grade_id")
    private Integer gradeId;
    @TableField("stage_id")
    private Integer stageId;
    @TableField("product_id")
    private Integer productId;
    /**
     * 排序，从1开始，这样和页面上的序号对上
     */
    private Integer sort;
    @TableField("create_by")
    private Integer createBy;
    @TableField("create_time")
    private Date createTime;
    @TableField("update_by")
    private Integer updateBy;
    @TableField("update_time")
    private Date updateTime;
    @TableLogic
    private Integer isdelete;


}
