package com.ruida.mockservice.service;

import com.baomidou.mybatisplus.service.IService;
import com.ruida.mockdao.model.ExamDetail;
import com.ruida.mockdao.model.ExamRecord;
import com.ruida.mockdao.vo.NodeVO;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * 考试详情表 服务类
 * </p>
 *
 * @author chenjy
 * @since 2020-07-15
 */
public interface ExamDetailService extends IService<ExamDetail> {

    List<NodeVO> getAnswerSheet(Integer examRecordId);

    /**
     * 解析试卷/试题
     * @param examRecordId
     * @param productId
     * @param testPaperId
     * @param questionId
     * @return
     */
    Map getAnalysis(Integer examRecordId, Integer productId, Integer testPaperId, String questionId);

    /**
     * 检查是否包含未批的试题
     * @param record
     * @return
     */
    boolean containUncorrectQuestion(ExamRecord record);

}
