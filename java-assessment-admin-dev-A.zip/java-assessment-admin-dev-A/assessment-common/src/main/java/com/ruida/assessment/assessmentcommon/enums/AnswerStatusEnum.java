package com.ruida.assessment.assessmentcommon.enums;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * 答案状态枚举
 */
public enum AnswerStatusEnum {

    RIGHT(1,"答对"),
    WRONG(2,"答错"),
    HRHW(3,"半对半错"),// half right,half wrong
    UC(4,"未批");// uncorrected

    private int k;
    private String v;

    AnswerStatusEnum(int k, String v) {
        this.k = k;
        this.v = v;
    }

    public static Map<Integer,String> map = new LinkedHashMap<>();

    static{
        for(AnswerStatusEnum answerStatusEnum:AnswerStatusEnum.values()){
            map.put(answerStatusEnum.getK(),answerStatusEnum.getV());
        }
    }

    public static String getValueByK(int k){
        AnswerStatusEnum[] enums = AnswerStatusEnum.values();
        for(AnswerStatusEnum answerStatusEnum:enums){
            if(answerStatusEnum.getK() == k){
                return answerStatusEnum.getV();
            }
        }
        return "";
    }

    public int getK() {
        return k;
    }

    public void setK(int k) {
        this.k = k;
    }

    public String getV() {
        return v;
    }

    public void setV(String v) {
        this.v = v;
    }
}
