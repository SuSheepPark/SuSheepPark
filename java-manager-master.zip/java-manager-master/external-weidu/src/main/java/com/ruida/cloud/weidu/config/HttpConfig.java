package com.ruida.cloud.weidu.config;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.http.converter.FormHttpMessageConverter;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.ResourceHttpMessageConverter;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @author mlzhang
 */
@Configuration
public class HttpConfig {
    @Bean
    public SimpleClientHttpRequestFactory httpRequestFactory(){
        SimpleClientHttpRequestFactory simpleClientHttpRequestFactory = new SimpleClientHttpRequestFactory();
        simpleClientHttpRequestFactory.setConnectTimeout(60000);
        simpleClientHttpRequestFactory.setReadTimeout(60000);
        return simpleClientHttpRequestFactory;
    }
    @Bean
    public RestTemplate restTemplate(){

        RestTemplate restTemplate = new RestTemplate(httpRequestFactory());
//        FormHttpMessageConverter fc = new FormHttpMessageConverter();
//        StringHttpMessageConverter s = new StringHttpMessageConverter(StandardCharsets.UTF_8);
//        List<HttpMessageConverter<?>> partConverters = new ArrayList<HttpMessageConverter<?>>();
//        partConverters.add(s);
//        partConverters.add(new ResourceHttpMessageConverter());
//        fc.setPartConverters(partConverters);
//        restTemplate.getMessageConverters().addAll(Arrays.asList(fc, new MappingJackson2HttpMessageConverter()));
      //  reInitMessageConverter(restTemplate);
       //  restTemplate.getMessageConverters().set(1, new StringHttpMessageConverter(StandardCharsets.UTF_8));
        return restTemplate;
    }

    /*
     * 初始化RestTemplate，RestTemplate会默认添加HttpMessageConverter
     * 添加的StringHttpMessageConverter非UTF-8 所以先要移除原有的StringHttpMessageConverter，
     * 再添加一个字符集为UTF-8的StringHttpMessageConvert
     */
    private void reInitMessageConverter(RestTemplate restTemplate) {
        List<HttpMessageConverter<?>> converterList = restTemplate.getMessageConverters();
        if (!CollectionUtils.isEmpty(converterList)) {
            HttpMessageConverter<?> converterTarget = null;
            for (HttpMessageConverter<?> item : converterList) {
                if (item.getClass() == StringHttpMessageConverter.class) {
                    converterTarget = item;
                    break;
                }
            }
            if (converterTarget != null) {
                converterList.remove(converterTarget);
                HttpMessageConverter<?> converter = new StringHttpMessageConverter(StandardCharsets.UTF_8);
                converterList.add(converter);
            }
        }
    }
}
