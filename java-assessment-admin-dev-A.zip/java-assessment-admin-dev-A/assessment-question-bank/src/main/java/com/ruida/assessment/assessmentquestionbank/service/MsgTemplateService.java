package com.ruida.assessment.assessmentquestionbank.service;

import com.ruida.assessment.assessmentcommon.result.MapResult;
import com.ruida.assessment.assessmentcommon.result.Page;
import com.ruida.assessment.assessmentquestionbank.dto.MsgTemplateDTO;
import com.ruida.assessment.assessmentquestionbank.dto.MsgTemplateOperationDTO;
import com.ruida.assessment.assessmentquestionbank.dto.QueryBaseDTO;
import com.ruida.assessment.assessmentquestionbank.vo.MsgTemplateVO;

/**
 * @description: 消息模板业务层接口
 * @author: kgz
 * @date: 2020/7/21
 */
public interface MsgTemplateService {
    /**
     * 保存消息模板信息
     * @param msgTemplateDTO
     * @return
     */
    Integer saveMsgTemplate(MsgTemplateDTO msgTemplateDTO);

    /**
     * 分页查询消息模板列表
     * @param queryBaseDTO
     * @return
     */
    Page<MsgTemplateVO> getMsgTemplateList(QueryBaseDTO queryBaseDTO);

    /**
     * 获取消息模板信息详情
     * @param id
     * @return
     */
    MsgTemplateVO getMsgTemplateDetail(String id);

    /**
     * 操作消息模板
     * @param msgTemplateOperation
     * @return
     */
    MapResult operateMsgTemplate(MsgTemplateOperationDTO msgTemplateOperation);
}
