package com.ruida.common.enums;

public enum QuestionEnum {
    SCT(1,"单选题"),
    MCT(2,"多选题"),
    JDT(3,"判断题"),
    CT(4,"填空题"),
    SAT(5,"简答题"),
    CQT(6,"复合题"),
    ;


    private Integer K;
    private String V;

    QuestionEnum(Integer k, String v) {
        K = k;
        V = v;
    }

    public Integer getK() {
        return K;
    }

    public void setK(Integer k) {
        K = k;
    }

    public String getV() {
        return V;
    }

    public void setV(String v) {
        V = v;
    }


    public static QuestionEnum getValueById(Integer K){
        for(QuestionEnum questionEnum : QuestionEnum.values() ){
            if(questionEnum.getK() ==K){
                return  questionEnum;
            }
        }
        return null;
    }

}
