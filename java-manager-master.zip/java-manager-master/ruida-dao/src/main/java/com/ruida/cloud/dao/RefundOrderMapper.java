package com.ruida.cloud.dao;

import com.ruida.cloud.model.RefundOrder;
import com.ruida.cloud.model.RefundOrderExample;
import com.ruida.cloud.model.RefundOrderExt;
import com.ruida.cloud.vo.TotalRefundAmount;
import org.apache.ibatis.annotations.Param;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

public interface RefundOrderMapper {
    long countByExample(RefundOrderExample example);

    int deleteByExample(RefundOrderExample example);

    int deleteByPrimaryKey(Integer refundOrderId);

    int insert(RefundOrder record);

    int insertSelective(RefundOrder record);

    List<RefundOrder> selectByExample(RefundOrderExample example);

    RefundOrder selectByPrimaryKey(Integer refundOrderId);

    int updateByExampleSelective(@Param("record") RefundOrder record, @Param("example") RefundOrderExample example);

    int updateByExample(@Param("record") RefundOrder record, @Param("example") RefundOrderExample example);

    int updateByPrimaryKeySelective(RefundOrder record);

    int updateByPrimaryKey(RefundOrder record);

    List<RefundOrderExt> queryRefundOrderList(@Param("vo") RefundOrderExt refundOrderExt);

    Long queryRefundOrderPageCount(@Param("vo")RefundOrderExt refundOrderExt);

    int updateRefundOrder(@Param("vo") RefundOrderExt refundOrderExt);

    BigDecimal batchQueryTotalRefundAmount(@Param("vo") RefundOrderExt refundOrderExt);

    int batchUpdateRefund(@Param("ids") List refundOrderIds, @Param("vo") RefundOrderExt refundOrder);

    RefundOrder selectByOrderId(Integer orderId);
}