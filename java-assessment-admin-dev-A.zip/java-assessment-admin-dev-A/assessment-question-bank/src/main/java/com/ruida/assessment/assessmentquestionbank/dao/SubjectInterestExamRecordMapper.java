package com.ruida.assessment.assessmentquestionbank.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.assessment.assessmentquestionbank.dto.QuestionnaireStudentInfoDTO;
import com.ruida.assessment.assessmentquestionbank.model.TSubjectInterestExamRecord;
import com.ruida.assessment.major.domain.dto.SelectRecordByStudentDTO;
import org.apache.ibatis.annotations.Param;

import java.util.Date;
import java.util.List;

/**
 * <p>
 * 科目兴趣调查的答卷 Mapper 接口
 * </p>
 *
 * @author
 * @since 2021-01-11
 */
public interface SubjectInterestExamRecordMapper extends BaseMapper<TSubjectInterestExamRecord> {
    List<QuestionnaireStudentInfoDTO> getStudentSubjectSelectRecord(
            @Param("keyWord") String keyWord, @Param("start") Integer start, @Param("pageSize") Integer pageSize, @Param("telephone") String telephone);

    Integer getStudentSubjectSelectRecordCount(@Param("keyWord") String keyWord, @Param("telephone") String telephone);

    List<SelectRecordByStudentDTO> getSubjectRecordByStudent(@Param("userId") Integer userId, @Param("minTime") Date minTime, @Param("maxTime") Date maxTime);
}
