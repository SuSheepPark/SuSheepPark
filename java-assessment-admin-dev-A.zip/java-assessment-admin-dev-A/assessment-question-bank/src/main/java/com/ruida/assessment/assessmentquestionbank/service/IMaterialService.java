package com.ruida.assessment.assessmentquestionbank.service;

import com.baomidou.mybatisplus.service.IService;
import com.ruida.assessment.assessmentcommon.result.BaseResult;
import com.ruida.assessment.assessmentcommon.result.PageData;
import com.ruida.assessment.assessmentcommon.result.PageResult;
import com.ruida.assessment.assessmentquestionbank.dto.BatchOperationRequest;
import com.ruida.assessment.assessmentquestionbank.dto.MaterialRequest;
import com.ruida.assessment.assessmentquestionbank.model.TKnowledge;
import com.ruida.assessment.assessmentquestionbank.model.TMaterial;
import com.ruida.assessment.assessmentquestionbank.vo.MaterialVo;

import java.util.List;

/**
 * @author wy
 * @description
 * @date 2020/6/12  教材服务接口
 */

public interface IMaterialService extends IService<TMaterial> {

    PageData<MaterialVo> queryMaterialList(MaterialRequest request);

    Integer addMaterial(MaterialRequest request);

    BaseResult updateOrDeleteMaterial(BatchOperationRequest request);

    List<Integer> batchUpdateOrDeleteMaterial(BatchOperationRequest request);

    List<MaterialVo> getUsableMaterialList(MaterialRequest request);
}
