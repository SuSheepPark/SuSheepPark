package com.ruida.assessment.assessmentquestionbank.controller;

import com.ruida.assessment.assessmentcommon.result.PageResult;
import com.ruida.assessment.assessmentcommon.util.excel.ExportExcelUtils;
import com.ruida.assessment.assessmentquestionbank.dto.PreferenceEventStatDTO;
import com.ruida.assessment.assessmentquestionbank.dto.PreferenceFeedbackDTO;
import com.ruida.assessment.assessmentquestionbank.dto.PreferenceReportDataDTO;
import com.ruida.assessment.assessmentquestionbank.service.PreferenceDataService;
import com.ruida.assessment.assessmentquestionbank.vo.PreferenceEventStatVO;
import com.ruida.assessment.assessmentquestionbank.vo.PreferenceFeedbackVO;
import com.ruida.assessment.assessmentquestionbank.vo.PreferenceReportDataVO;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

/**
 * 志愿填报数据统计
 */
@RestController
@RequestMapping("/preference")
public class PreferenceDataController {
    @Resource
    PreferenceDataService preferenceDataService;

    @RequestMapping("/getPreferenceReportDataList")
    public PageResult<PreferenceReportDataVO> getPreferenceReportDataList(PreferenceReportDataDTO dto) {
        dto.setShowAll(0);
        return preferenceDataService.getPreferenceReportDataList(dto,false);
    }

    /**
     * 导出报告列表
     * @param response
     * @param dto
     */
    @RequestMapping("/exportPreferenceReportStat")
    public void exportPreferenceReportStat(HttpServletResponse response, PreferenceReportDataDTO dto) {
        dto.setShowAll(1);
        PageResult<PreferenceReportDataVO> result = preferenceDataService.getPreferenceReportDataList(dto,true);
        String excelName = "报告统计列表";
        ExportExcelUtils.export(excelName, result.getContent().getResult(), PreferenceReportDataVO.class, response);
    }

    /**
     * 反馈列表
     * @param dto
     * @return
     */
    @RequestMapping("/getFeebackList")
    public PageResult<PreferenceFeedbackVO> getFeebackList(PreferenceFeedbackDTO dto) {
        dto.setShowAll(0);
        return preferenceDataService.getFeebackList(dto,false);
    }
    /**
     * 反馈统计列表导出
     * @param response
     * @param dto
     */
    @RequestMapping("/exportFeebackStat")
    public void exportFeebackStat(HttpServletResponse response, PreferenceFeedbackDTO dto) {
        dto.setShowAll(1);
        PageResult<PreferenceFeedbackVO> result = preferenceDataService.getFeebackList(dto,true);
        String excelName = "反馈统计";
        ExportExcelUtils.export(excelName, result.getContent().getResult(), PreferenceFeedbackVO.class, response);
    }
    /**
     * 事件统计列表
     * @param dto
     * @return
     */
    @RequestMapping("/getEventStatList")
    public PageResult<PreferenceEventStatVO> getEventStatList(PreferenceEventStatDTO dto) {
        dto.setShowAll(0);
        return preferenceDataService.getEventStatList(dto);
    }
    /**
     * 反馈统计列表导出
     * @param response
     * @param dto
     */
    @RequestMapping("/exportEventStat")
    public void exportEventStat(HttpServletResponse response, PreferenceEventStatDTO dto) {
        dto.setShowAll(1);
        PageResult<PreferenceEventStatVO> result = preferenceDataService.getEventStatList(dto);
        String excelName = "事件统计列表";
        ExportExcelUtils.export(excelName, result.getContent().getResult(), PreferenceEventStatVO.class, response);
    }

}
