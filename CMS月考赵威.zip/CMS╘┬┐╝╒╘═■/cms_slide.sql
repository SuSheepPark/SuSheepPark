/*
Navicat MySQL Data Transfer

Source Server         : my
Source Server Version : 50557
Source Host           : 127.0.0.1:3306
Source Database       : 1705e_cms

Target Server Type    : MYSQL
Target Server Version : 50557
File Encoding         : 65001

Date: 2019-09-25 11:40:07
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `cms_slide`
-- ----------------------------
DROP TABLE IF EXISTS `cms_slide`;
CREATE TABLE `cms_slide` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) DEFAULT NULL,
  `picture` varchar(50) DEFAULT NULL,
  `url` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cms_slide
-- ----------------------------
INSERT INTO `cms_slide` VALUES ('1', 'JIAO AN PU', null, 'WeCh_20190905185235.jpg');
INSERT INTO `cms_slide` VALUES ('2', 'CANADA STATION', null, 'markus-spiske-Fk600Fgg_24-unsplash.jpg');
INSERT INTO `cms_slide` VALUES ('3', 'CANADA STATION', null, 'feih.jpg');
INSERT INTO `cms_slide` VALUES ('4', 'CANADA STATION', null, 'alina-gsnsplash.jpg');
INSERT INTO `cms_slide` VALUES ('6', 'ZHI AI FAN GAO', null, 'feih.jpg');
