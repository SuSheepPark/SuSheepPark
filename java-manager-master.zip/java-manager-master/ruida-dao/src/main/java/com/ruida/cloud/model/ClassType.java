package com.ruida.cloud.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ruida.common.SystemConstant;

import java.io.Serializable;
import java.util.Date;

public class ClassType implements Serializable {

    private Integer classTypeId;

    private String classTypeName;

    private String period;

    private Byte difficulty;

    private Byte status;

    private Integer createBy;

    @JsonFormat(pattern= SystemConstant.DATE_FORMAT,timezone=SystemConstant.TIME_ZONE)
    private Date createTime;

    private Integer updateBy;

    private Date updateTime;

    private Byte isdelete;

    private String periodName;

    private String forCrowd;

    private String classForm;

    private String courseFeature;

    private String learningGoal;

    public String getClassForm() {
        return classForm;
    }

    public String getForCrowd() {
        return forCrowd;
    }

    public void setForCrowd(String forCrowd) {
        this.forCrowd = forCrowd;
    }

    public void setClassForm(String classForm) {
        this.classForm = classForm;
    }

    public String getCourseFeature() {
        return courseFeature;
    }

    public void setCourseFeature(String courseFeature) {
        this.courseFeature = courseFeature;
    }

    public String getLearningGoal() {
        return learningGoal;
    }

    public void setLearningGoal(String learningGoal) {
        this.learningGoal = learningGoal;
    }

    public String getPeriodName() {
        return periodName;
    }

    public void setPeriodName(String periodName) {
        this.periodName = periodName;
    }

    private static final long serialVersionUID = 1L;

    public Integer getClassTypeId() {
        return classTypeId;
    }

    public void setClassTypeId(Integer classTypeId) {
        this.classTypeId = classTypeId;
    }

    public String getClassTypeName() {
        return classTypeName;
    }

    public void setClassTypeName(String classTypeName) {
        this.classTypeName = classTypeName == null ? null : classTypeName.trim();
    }

    public String getPeriod() {
        return period;
    }

    public void setPeriod(String period) {
        this.period = period == null ? null : period.trim();
    }

    public Byte getDifficulty() {
        return difficulty;
    }

    public void setDifficulty(Byte difficulty) {
        this.difficulty = difficulty;
    }

    public Byte getStatus() {
        return status;
    }

    public void setStatus(Byte status) {
        this.status = status;
    }

    public Integer getCreateBy() {
        return createBy;
    }

    public void setCreateBy(Integer createBy) {
        this.createBy = createBy;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(Integer updateBy) {
        this.updateBy = updateBy;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Byte getIsdelete() {
        return isdelete;
    }

    public void setIsdelete(Byte isdelete) {
        this.isdelete = isdelete;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", classTypeId=").append(classTypeId);
        sb.append(", classTypeName=").append(classTypeName);
        sb.append(", period=").append(period);
        sb.append(", difficulty=").append(difficulty);
        sb.append(", status=").append(status);
        sb.append(", createBy=").append(createBy);
        sb.append(", createTime=").append(createTime);
        sb.append(", updateBy=").append(updateBy);
        sb.append(", updateTime=").append(updateTime);
        sb.append(", isdelete=").append(isdelete);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}