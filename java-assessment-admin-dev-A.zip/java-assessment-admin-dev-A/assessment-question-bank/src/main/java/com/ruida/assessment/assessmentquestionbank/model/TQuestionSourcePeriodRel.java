package com.ruida.assessment.assessmentquestionbank.model;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import lombok.Data;

import java.io.Serializable;

/**
 * @author wy
 * @description  试题来源-学段关联实体类
 * @date 2020/9/14
 */
@Data
@TableName("t_question_source_period_rel")
public class TQuestionSourcePeriodRel implements Serializable {


    private static final long serialVersionUID = -2616442710601607835L;
    @TableId
    private Integer id;

    private Integer sourceId;
    private Integer periodId;
}
