package com.ruida.assessment.assessmentquestionbank.imports.domain.service;

import java.util.ArrayList;
import java.util.List;

import com.ruida.assessment.assessmentquestionbank.imports.domain.model.ErrorMsg;

public class ErrorService {

	static ThreadLocal<ErrorService> threadLocal=new ThreadLocal<ErrorService>();
	private List<ErrorMsg> errorMsgs=new ArrayList<ErrorMsg>();
	public static void addError(Integer errorLineNumber,String questionName,String errorMsg) {
		ErrorService service=threadLocal.get();
		if(service==null) {
			service=new ErrorService();
			threadLocal.set(service);
		}
		ErrorMsg msg=new ErrorMsg();
		msg.setFailInfo(errorMsg);
		msg.setLineNum(errorLineNumber);
		msg.setQuestionName(questionName);
		service.errorMsgs.add(msg);
	}
	
	public static List<ErrorMsg> getMsgs(){
		ErrorService service=threadLocal.get();
		if(service==null) {
			service=new ErrorService();
			threadLocal.set(service);
		}
		return service.errorMsgs;
	}
	
	public static void remove() {
		ErrorService service=threadLocal.get();
		if(service!=null) {
			threadLocal.remove();
		}
	}
}
