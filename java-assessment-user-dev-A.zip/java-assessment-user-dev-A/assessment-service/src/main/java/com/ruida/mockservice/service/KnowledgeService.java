package com.ruida.mockservice.service;

import com.ruida.mockdao.vo.KnowledgeVO;
import java.util.List;

/**
 * 知识点
 */
public interface KnowledgeService {

    /**
     * 查询业务知识点(目前针对错题和标记试题查询)
     * @param type
     * @return
     */
    List<KnowledgeVO> queryBizKnowledge(Integer type);
}
