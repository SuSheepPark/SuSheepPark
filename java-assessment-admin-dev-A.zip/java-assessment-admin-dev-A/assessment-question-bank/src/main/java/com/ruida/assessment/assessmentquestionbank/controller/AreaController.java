package com.ruida.assessment.assessmentquestionbank.controller;

import com.ruida.assessment.assessmentcommon.result.ListResult;
import com.ruida.assessment.assessmentquestionbank.service.AreaService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.models.auth.In;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * @description:
 * @author: kgz
 * @date: 2020/7/7
 */
@RequestMapping("/area")
@RestController
@Api(value ="区域接口")
public class AreaController {
    @Resource
    private AreaService areaService;

    @GetMapping("/getList")
    @ApiOperation(value = "获取区域下拉框列表", notes = "获取区域下拉框列表")
    public ListResult getList(){
        ListResult listResult = new ListResult();
        listResult.setContent(areaService.getList());
        return listResult;
    }
    @PostMapping("/getProvinceList")
    @ApiOperation(value = "获取省份下拉框列表", notes = "获取省份下拉框列表")
    public ListResult getProvinceList(){
        ListResult listResult = new ListResult();
        listResult.setContent(areaService.listProvince());
        return listResult;
    }
    @PostMapping("/getCityList")
    @ApiOperation(value = "获取城市下拉框列表", notes = "获取城市下拉框列表")
    public ListResult getCityList(Integer provinceId){
        ListResult listResult = new ListResult();
        listResult.setContent(areaService.listCityByProvince(provinceId));
        return listResult;
    }
    @PostMapping("/getDistrictList")
    @ApiOperation(value = "获取区下拉框列表", notes = "获取区下拉框列表")
    public ListResult getDistrictList(Integer cityId){
        ListResult listResult = new ListResult();
        listResult.setContent(areaService.listDistrictByCity(cityId));
        return listResult;
    }
}
