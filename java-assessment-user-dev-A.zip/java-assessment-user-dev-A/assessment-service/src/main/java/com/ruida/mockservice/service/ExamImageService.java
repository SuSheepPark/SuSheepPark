package com.ruida.mockservice.service;

import com.baomidou.mybatisplus.service.IService;
import com.ruida.mockdao.model.ExamImage;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author chenjy
 * @since 2020-07-14
 */
public interface ExamImageService extends IService<ExamImage> {

}
