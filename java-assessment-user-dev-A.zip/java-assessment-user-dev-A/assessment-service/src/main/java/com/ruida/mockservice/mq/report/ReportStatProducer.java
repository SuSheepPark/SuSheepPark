package com.ruida.mockservice.mq.report;

import com.alibaba.fastjson.JSON;
import com.aliyun.openservices.ons.api.Message;
import com.aliyun.openservices.ons.api.SendResult;
import com.aliyun.openservices.shade.com.alibaba.rocketmq.remoting.common.RemotingHelper;
import com.ruida.mockcommon.mq.producer.MQUtil;
import com.ruida.mockcommon.mq.producer.ProducerListener;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.UnsupportedEncodingException;
import java.util.Map;

import javax.annotation.Resource;

@Service
@Slf4j
public class ReportStatProducer {

	@Resource
	ProducerListener producerListener;

	@Value("${spring.profiles.active}")
	String profiles;

	public boolean send(Integer recordId) {
		Message msg = new Message();
		msg.setTopic("start-exam-attention");
		msg.setStartDeliverTime(System.currentTimeMillis() + 1000);
		msg.setTag("exam-report-stat-" + profiles);
		msg.setKey("recordId" + "_" + profiles + "_" + recordId);
		msg.setBody("第一次考试完成之后发消息计算知识点分值".getBytes());
		send(msg,MQUtil.getRealId("GID-exam-report-stat-"));
		return false;
	}

	public boolean sendUnifiedReport(String sceneId, Map<String, Object> body) {
		Message msg;
		try {
			msg = new Message("start-exam-unified-report", "report-unified-" + profiles,
					"sceneId_" + sceneId + "_" + profiles,
					JSON.toJSONString(body).getBytes(RemotingHelper.DEFAULT_CHARSET));
			send(msg,MQUtil.getRealId("GID-report-unified-"));
		} catch (UnsupportedEncodingException e) {
		}

		return false;
	}

	public boolean send(Message msg,String producerId) {
		try {
			SendResult sendResult = producerListener.getProducer(producerId).send(msg);
			log.info("考试记录id为:{}的考试发送消息到MQ", msg.getKey());
			if (sendResult != null) {
				return true;
			}
		} catch (Exception e) {
			log.error("考试记录id{},发送消息异常,原因:{}", msg.getKey(), e);
		}
		return false;
	}
}
