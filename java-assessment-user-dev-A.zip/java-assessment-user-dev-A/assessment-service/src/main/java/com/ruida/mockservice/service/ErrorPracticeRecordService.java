package com.ruida.mockservice.service;

import com.baomidou.mybatisplus.service.IService;
import com.ruida.mockcommon.result.Page;
import com.ruida.mockdao.dto.ErrorPracticeSubmitDTO;
import com.ruida.mockdao.dto.RecordRequest;
import com.ruida.mockdao.model.ErrorPracticeRecord;
import com.ruida.mockdao.vo.error.PracticeRecordVO;

/**
 * <p>
 * 错题练习记录表 服务类
 * </p>
 *
 * @author chenjy
 * @since 2020-10-19
 */
public interface ErrorPracticeRecordService extends IService<ErrorPracticeRecord> {

    Integer submit(ErrorPracticeSubmitDTO req);

    Page<PracticeRecordVO> queryPracticeRecord(Page page, RecordRequest req);
}
