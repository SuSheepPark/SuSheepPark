package com.ruida.assessment.assessmentquestionbank.dao;

import com.ruida.assessment.assessmentquestionbank.vo.BasicDataVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @description: 商品统计数据库层接口
 * @author: kgz
 * @date: 2020/8/7
 */
@Mapper
public interface ProductStatisticsMapper {
    /**
     * 获取商品付款数排行top5
     * @param startTime
     * @param endTime
     * @return
     */
    List<BasicDataVO> getRankData(@Param("startTime") String startTime, @Param("endTime") String endTime);
}
