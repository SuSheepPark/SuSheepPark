package com.ruida.assessment.assessmentquestionbank.dto;

import com.ruida.assessment.assessmentcommon.result.Page;
import com.ruida.assessment.assessmentquestionbank.model.TUserPeriodSubject;
import lombok.Data;
import java.util.List;

/**
 * @author wy
 * @description 教材管理请求类
 * @date 2020/6/13
 */
@Data
public class MaterialRequest {

    /*当前选中的教材的id*/
    private Integer id;

    /*学段id*/
    private Integer periodId;

    /*学段名称*/
    private String periodName;

    /*科目id*/
    private Integer subjectId;

    /*科目名称*/
    private String subjectName;

    /*教材版本id*/
    private Integer versionId;

    /*教材版本名称*/
    private String versionName;

    /*年级id*/
    private Integer gradeId;

    /*年级名称*/
    private String gradeName;

    /*状态  0-禁用 1-启用*/
    private Integer status;

    private Page page;
    private Integer isdelete = 0;

    /*分页*/
    private Integer start;
    private Integer size;

    private List<TUserPeriodSubject> userPeriodSubjects;
}
