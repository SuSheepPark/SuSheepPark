package com.ruida.assessment.assessmentquestionbank.controller;

import com.ruida.assessment.assessmentcommon.result.ListResult;
import com.ruida.assessment.assessmentquestionbank.service.QuestionAssessmentTargetService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

/**
 * @description: 考核目标控制层
 * @author: kgz
 * @date: 2020/6/10
 */
@RequestMapping("/questionAssessmentTarget")
@RestController
@Api(value ="考核目标相关接口")
public class QuestionAssessmentTargetController {
    @Resource
    private QuestionAssessmentTargetService questionAssessmentTargetService;

    @GetMapping("/getList")
    @ApiOperation(value = "获取考核目标下拉框列表", notes = "获取考核目标下拉框列表")
    public ListResult getList(){
        ListResult listResult = new ListResult();
        listResult.setContent(questionAssessmentTargetService.getList());
        return listResult;
    }

    @GetMapping("/queryList")
    @ApiOperation(value = "获取学段科目联动的下拉框列表", notes = "获取学段科目联动的下拉框列表")
    public ListResult queryList(@RequestParam Integer periodId,@RequestParam Integer subjectId){
        ListResult listResult = new ListResult();
        listResult.setContent(questionAssessmentTargetService.queryList(periodId,subjectId));
        return listResult;
    }
}
