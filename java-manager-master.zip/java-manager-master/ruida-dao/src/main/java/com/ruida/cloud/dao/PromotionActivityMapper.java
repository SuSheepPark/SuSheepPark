package com.ruida.cloud.dao;

import com.ruida.cloud.model.PromotionActivity;
import com.ruida.cloud.model.PromotionActivityExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface PromotionActivityMapper {
    long countByExample(PromotionActivityExample example);

    int deleteByExample(PromotionActivityExample example);

    int deleteByPrimaryKey(Integer promotionActivityId);

    int insert(PromotionActivity record);

    int insertSelective(PromotionActivity record);

    List<PromotionActivity> selectByExample(PromotionActivityExample example);

    PromotionActivity selectByPrimaryKey(Integer promotionActivityId);

    int updateByExampleSelective(@Param("record") PromotionActivity record, @Param("example") PromotionActivityExample example);

    int updateByExample(@Param("record") PromotionActivity record, @Param("example") PromotionActivityExample example);

    int updateByPrimaryKeySelective(PromotionActivity record);

    int updateByPrimaryKey(PromotionActivity record);
}