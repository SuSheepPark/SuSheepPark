package com.ruida.assessment.assessmentquestionbank.controller.system;

import com.ruida.assessment.assessmentcommon.enums.AppErrorEnum;
import com.ruida.assessment.assessmentcommon.enums.OperateModuleEnum;
import com.ruida.assessment.assessmentcommon.enums.OperateTypeEnum;
import com.ruida.assessment.assessmentcommon.exception.CoreException;
import com.ruida.assessment.assessmentcommon.result.BoolAlertResult;
import com.ruida.assessment.assessmentcommon.result.ListResult;
import com.ruida.assessment.assessmentcommon.result.PojoResult;
import com.ruida.assessment.assessmentcommon.util.ValidateMT;
import com.ruida.assessment.assessmentquestionbank.annotaion.OperateLog;
import com.ruida.assessment.assessmentquestionbank.annotaion.UserAuth;
import com.ruida.assessment.assessmentquestionbank.model.SysMenu;
import com.ruida.assessment.assessmentquestionbank.service.ruidaCloud.SysMenuService;
import io.swagger.models.auth.In;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

/**
 * @author admin
 * @description: ${TODO}
 * @Date 2019/5/30
 * @verion 1.0
 */
@RestController
@RequestMapping("/sys")

public class MenuController {
    @Resource
    SysMenuService sysMenuService;

    /**
     * 获取菜单树
     *
     * @return
     */
    @RequestMapping("/menuList")
    @ResponseBody
    @UserAuth
    public ListResult menuTreeList(String searchWord, String menuTypes,Integer type) {
        ListResult result = new ListResult();
        List<Map<String, Object>> list = sysMenuService.menuTreeList(searchWord, menuTypes, type);
        result.setContent(list);
        return result;
    }

    /**
     * 添加菜单
     *
     * @param menu
     * @return
     */
    @RequestMapping("/addMenu")
    @ResponseBody
    @UserAuth
    @OperateLog(module = OperateModuleEnum.MENU, operateType = OperateTypeEnum.ADD)
    public PojoResult addMenu(SysMenu menu) {
        PojoResult result = new PojoResult();
        SysMenu resultMenu = sysMenuService.addAndEditMenu(menu);
        result.setContent(resultMenu);
        return result;
    }

    /**
     * 编辑菜单
     *
     * @param menu 选择空 就传0过来默认顶级菜单
     * @return
     */
    @RequestMapping("/editMenu")
    @ResponseBody
    @UserAuth
    @OperateLog(module = OperateModuleEnum.MENU, operateType = OperateTypeEnum.EDIT)
    public PojoResult editMenu(SysMenu menu) {
        PojoResult result = new PojoResult();
        if (ValidateMT.isNull(menu.getMenuId())) {
            throw new CoreException(AppErrorEnum.E_10005);
        }
        SysMenu resultMenu = sysMenuService.addAndEditMenu(menu);
        result.setContent(resultMenu);
        return result;
    }

    /**
     * 删除菜单
     *
     * @param menuId
     * @return
     */
    @RequestMapping("/deleteMenu")
    @UserAuth
    @OperateLog(module = OperateModuleEnum.MENU, operateType = OperateTypeEnum.DELETE)
    public PojoResult deleteMenu(Integer menuId) {
        PojoResult pojoResult = new PojoResult();
        if (ValidateMT.isNull(menuId)) {
            throw new CoreException(AppErrorEnum.E_10005);
        }
        BoolAlertResult boolResult = sysMenuService.deleteMenu(menuId);
        pojoResult.setContent(boolResult.getMsg());
        return pojoResult;
    }

    /**
     * 启用/禁用菜单
     *
     * @param menuId
     * @return
     */
    @RequestMapping("/forbidAndStartMenu")
    @ResponseBody
    @UserAuth
    @OperateLog(module = OperateModuleEnum.MENU, operateType = OperateTypeEnum.STOP_START)
    public PojoResult forbidAndStartMenu(Integer menuId) {
        PojoResult pojoResult = new PojoResult();
        if (ValidateMT.isNull(menuId)) {
            throw new CoreException(AppErrorEnum.E_10005);
        }
        BoolAlertResult boolResult = sysMenuService.forbidAndAcceptMenu(menuId);
        pojoResult.setContent(boolResult.getMsg());
        return pojoResult;
    }

    /**
     * 根据菜单id获取菜单信息
     *
     * @param menuId
     * @return
     */
    @RequestMapping("getMenuInfo")
    @UserAuth
    public PojoResult getMenuInfoById(Integer menuId) {
        PojoResult pojoResult = new PojoResult();
        SysMenu menu = sysMenuService.getMenuInfoById(menuId);
        pojoResult.setContent(menu);
        return pojoResult;
    }

}
