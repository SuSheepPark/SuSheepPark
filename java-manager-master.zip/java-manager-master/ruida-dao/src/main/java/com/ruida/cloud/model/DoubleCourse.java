package com.ruida.cloud.model;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * 双师课程
 */
@Data
public class DoubleCourse {
    /**
     * 自增主键 课程id
     */
    private Integer courseId;

    /**
     * 校管家课程id
     */
    private String courseIdXgj;

    /**
     * 课程名称
     */
    private String courseName;

    /**
     * 年级id
     */
    private String stageId;

    /**
     * 年级名称
     */
    private String stageName;

    /**
     * 科目id
     */
    private String subjectId;

    /**
     * 科目名称
     */
    private String subjectName;

    /**
     * 状态 
     */
    private Byte status;

    /**
     * 校管家同步时间
     */
    private Date syncTimeXgj;

    /**
     * 百家云同步时间
     */
    private Date syncTimeBjy;

    /**
     * 课程封面路径
     */
    private String coverPath;

    /**
     * 班级类型id
     */
    private String classTypeId;

    /**
     * 班级类型名称
     */
    private String classTypeName;

    /**
     * 课程简介
     */
    private String summary;

    /**
     * html格式的课程简介
     */
    private String summaryHtml;

    /**
     * 课次数量
     */
    private Integer lessonNum;

    /**
     * 线下双师单价
     */
    private BigDecimal underLinePrice;

    /**
     * 线下双师优惠单价
     */
    private BigDecimal underLineSalePrice;

    /**
     * 是否上架（0—未上架；1—已上架） 
     */
    private Byte ispublish;

    /**
     * 课程开始日期
     */
    private Date startDate;

    /**
     * 课程结束日期
     */
    private Date endDate;

    /**
     * 课程开始时间
     */
    private String startTime;

    /**
     * 课程结束时间
     */
    private String endTime;

    /**
     * 开课的间隔天数
     */
    private Integer intervalDays;

    /**
     * 课程有效期（0—1个月；1—3个月；2—6个月；3—9个月；4—12个月；5—2年；6—3年；7—无限期）
     */
    private Byte validTime;

    /**
     * 校区id
     */
    private String schoolId;

    /**
     * 校区名称
     */
    private String schoolName;

    /**
     * 主讲老师id
     */
    private String teacherId;

    /**
     * 主讲老师名称
     */
    private String teacherName;

    /**
     * 授课教室id
     */
    private String teacherClassId;

    /**
     * 授课教室名称
     */
    private String teacherClassName;

    /**
     * 听课校区id（多个逗号隔开）
     */
    private String listenZoneIds;

    /**
     * 听课教室数量
     */
    private Integer hearClassNum;

    /**
     * 是否直播（0—关闭；1—开启） 
     */
    private Byte islive;

    /**
     * 是否删除
     */
    private Boolean isdelete;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新时间
     */
    private Date updateTime;

    /**
     * 创建者ID（关联user_id）
     */
    private Integer createBy;

    /**
     * 更新者ID（关联user_id）
     */
    private Integer updateBy;

}