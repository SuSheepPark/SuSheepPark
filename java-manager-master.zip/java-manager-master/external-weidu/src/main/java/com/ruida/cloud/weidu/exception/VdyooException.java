package com.ruida.cloud.weidu.exception;

import lombok.Data;

@Data
public class VdyooException extends RuntimeException{
    private static final long serialVersionUID = 5792816284203588336L;
    /**
     * 错误码 业务层面
     */
    private String errCode;
    /**
     * 错误消息
     */
    private String message;

    public VdyooException(String errCode, String message, Throwable cause) {
        super(message, cause);
        this.errCode = errCode;
        this.message = message;
    }

    public VdyooException(String errCode, String message) {
        super(message);
        this.errCode = errCode;
        this.message = message;
    }

}
