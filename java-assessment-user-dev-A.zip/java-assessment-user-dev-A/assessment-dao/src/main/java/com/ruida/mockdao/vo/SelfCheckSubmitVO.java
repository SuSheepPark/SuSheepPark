package com.ruida.mockdao.vo;

import lombok.Data;

/**
 * Created by xumingqi on 2021/7/22 14:29
 */
@Data
public class SelfCheckSubmitVO {
    /**
     * 得分
     */
    private String point;

    /**
     * 试卷满分
     */
    private String fullScore;

    /**
     * 考试记录id
     */
    private Integer examRecordId;
}
