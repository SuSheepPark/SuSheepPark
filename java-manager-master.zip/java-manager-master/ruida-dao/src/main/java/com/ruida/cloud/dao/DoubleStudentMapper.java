package com.ruida.cloud.dao;

import com.ruida.cloud.model.DoubleClass;
import com.ruida.cloud.model.DoubleStudent;
import com.ruida.cloud.model.DoubleStudentEXT;
import com.ruida.cloud.model.DoubleStudentExample;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

public interface DoubleStudentMapper {
    int countByExample(DoubleStudentExample example);

    int deleteByExample(DoubleStudentExample example);

    int deleteByPrimaryKey(Integer studentId);

    int insert(DoubleStudent record);

    int insertSelective(DoubleStudent record);

    List<DoubleStudent> selectByExample(DoubleStudentExample example);

    DoubleStudent selectByPrimaryKey(Integer studentId);

    int updateByExampleSelective(@Param("record") DoubleStudent record, @Param("example") DoubleStudentExample example);

    int updateByExample(@Param("record") DoubleStudent record, @Param("example") DoubleStudentExample example);

    int updateByPrimaryKeySelective(DoubleStudent record);

    int updateByPrimaryKey(DoubleStudent record);

    List<DoubleStudentEXT> getDoubleStudentList(Map courseMap);

    List<DoubleClass> getDoubleStudentClassList(Integer studentId);

    List<DoubleStudentEXT> getDoubleStudentByTelephone(@Param("classId") Integer classId,@Param("telephone") String telephone);

    List<DoubleStudent> selectByStudentNo(@Param("studentNo") String studentNo);

    List<DoubleStudent> getNotExistClassStudent(@Param("classId") Integer classId,@Param("telephone") String telephone);
}