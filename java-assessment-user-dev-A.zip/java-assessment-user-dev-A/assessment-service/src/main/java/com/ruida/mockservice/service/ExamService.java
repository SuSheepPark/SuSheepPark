package com.ruida.mockservice.service;

import com.ruida.mockcommon.result.Page;
import com.ruida.mockcommon.result.PageData;
import com.ruida.mockdao.model.ExamDetail;
import com.ruida.mockdao.vo.QueryScoreProductVO;
import com.ruida.mockdao.vo.UnifiedTestPaperVO;

import java.util.List;

/**
 * 考试接口
 */
public interface ExamService {

    /**
     * 自动批改试卷
     *
     * @param examDetailList 答题记录
     * @param isSelfCheck    是否自主阅卷
     */
    List<ExamDetail> correct(List<ExamDetail> examDetailList, boolean isSelfCheck);

    /**
     * 处理试题统计信息（知识点+考察要求分值计算）
     *
     * @param recordId 考试记录id
     * @return
     */
    boolean handleQuestionStats(Integer recordId);

    /**
     * 列出线上统考试卷
     * @return
     */
    List<UnifiedTestPaperVO> listUnifiedTestPaper();

    /**
     * 成绩查询
     * @param username
     * @return
     */
    List<QueryScoreProductVO> queryScore(String username);
    /**
     * 成绩查询
     * @return
     */
    PageData<QueryScoreProductVO> queryMyScore( Page page);
}
