package com.ruida.cloud.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class CourseVideoExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public CourseVideoExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andCourseVideoIdIsNull() {
            addCriterion("course_video_id is null");
            return (Criteria) this;
        }

        public Criteria andCourseVideoIdIsNotNull() {
            addCriterion("course_video_id is not null");
            return (Criteria) this;
        }

        public Criteria andCourseVideoIdEqualTo(Integer value) {
            addCriterion("course_video_id =", value, "courseVideoId");
            return (Criteria) this;
        }

        public Criteria andCourseVideoIdNotEqualTo(Integer value) {
            addCriterion("course_video_id <>", value, "courseVideoId");
            return (Criteria) this;
        }

        public Criteria andCourseVideoIdGreaterThan(Integer value) {
            addCriterion("course_video_id >", value, "courseVideoId");
            return (Criteria) this;
        }

        public Criteria andCourseVideoIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("course_video_id >=", value, "courseVideoId");
            return (Criteria) this;
        }

        public Criteria andCourseVideoIdLessThan(Integer value) {
            addCriterion("course_video_id <", value, "courseVideoId");
            return (Criteria) this;
        }

        public Criteria andCourseVideoIdLessThanOrEqualTo(Integer value) {
            addCriterion("course_video_id <=", value, "courseVideoId");
            return (Criteria) this;
        }

        public Criteria andCourseVideoIdIn(List<Integer> values) {
            addCriterion("course_video_id in", values, "courseVideoId");
            return (Criteria) this;
        }

        public Criteria andCourseVideoIdNotIn(List<Integer> values) {
            addCriterion("course_video_id not in", values, "courseVideoId");
            return (Criteria) this;
        }

        public Criteria andCourseVideoIdBetween(Integer value1, Integer value2) {
            addCriterion("course_video_id between", value1, value2, "courseVideoId");
            return (Criteria) this;
        }

        public Criteria andCourseVideoIdNotBetween(Integer value1, Integer value2) {
            addCriterion("course_video_id not between", value1, value2, "courseVideoId");
            return (Criteria) this;
        }

        public Criteria andCourseIdIsNull() {
            addCriterion("course_id is null");
            return (Criteria) this;
        }

        public Criteria andCourseIdIsNotNull() {
            addCriterion("course_id is not null");
            return (Criteria) this;
        }

        public Criteria andCourseIdEqualTo(Integer value) {
            addCriterion("course_id =", value, "courseId");
            return (Criteria) this;
        }

        public Criteria andCourseIdNotEqualTo(Integer value) {
            addCriterion("course_id <>", value, "courseId");
            return (Criteria) this;
        }

        public Criteria andCourseIdGreaterThan(Integer value) {
            addCriterion("course_id >", value, "courseId");
            return (Criteria) this;
        }

        public Criteria andCourseIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("course_id >=", value, "courseId");
            return (Criteria) this;
        }

        public Criteria andCourseIdLessThan(Integer value) {
            addCriterion("course_id <", value, "courseId");
            return (Criteria) this;
        }

        public Criteria andCourseIdLessThanOrEqualTo(Integer value) {
            addCriterion("course_id <=", value, "courseId");
            return (Criteria) this;
        }

        public Criteria andCourseIdIn(List<Integer> values) {
            addCriterion("course_id in", values, "courseId");
            return (Criteria) this;
        }

        public Criteria andCourseIdNotIn(List<Integer> values) {
            addCriterion("course_id not in", values, "courseId");
            return (Criteria) this;
        }

        public Criteria andCourseIdBetween(Integer value1, Integer value2) {
            addCriterion("course_id between", value1, value2, "courseId");
            return (Criteria) this;
        }

        public Criteria andCourseIdNotBetween(Integer value1, Integer value2) {
            addCriterion("course_id not between", value1, value2, "courseId");
            return (Criteria) this;
        }

        public Criteria andCourseLessonIdIsNull() {
            addCriterion("course_lesson_id is null");
            return (Criteria) this;
        }

        public Criteria andCourseLessonIdIsNotNull() {
            addCriterion("course_lesson_id is not null");
            return (Criteria) this;
        }

        public Criteria andCourseLessonIdEqualTo(Integer value) {
            addCriterion("course_lesson_id =", value, "courseLessonId");
            return (Criteria) this;
        }

        public Criteria andCourseLessonIdNotEqualTo(Integer value) {
            addCriterion("course_lesson_id <>", value, "courseLessonId");
            return (Criteria) this;
        }

        public Criteria andCourseLessonIdGreaterThan(Integer value) {
            addCriterion("course_lesson_id >", value, "courseLessonId");
            return (Criteria) this;
        }

        public Criteria andCourseLessonIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("course_lesson_id >=", value, "courseLessonId");
            return (Criteria) this;
        }

        public Criteria andCourseLessonIdLessThan(Integer value) {
            addCriterion("course_lesson_id <", value, "courseLessonId");
            return (Criteria) this;
        }

        public Criteria andCourseLessonIdLessThanOrEqualTo(Integer value) {
            addCriterion("course_lesson_id <=", value, "courseLessonId");
            return (Criteria) this;
        }

        public Criteria andCourseLessonIdIn(List<Integer> values) {
            addCriterion("course_lesson_id in", values, "courseLessonId");
            return (Criteria) this;
        }

        public Criteria andCourseLessonIdNotIn(List<Integer> values) {
            addCriterion("course_lesson_id not in", values, "courseLessonId");
            return (Criteria) this;
        }

        public Criteria andCourseLessonIdBetween(Integer value1, Integer value2) {
            addCriterion("course_lesson_id between", value1, value2, "courseLessonId");
            return (Criteria) this;
        }

        public Criteria andCourseLessonIdNotBetween(Integer value1, Integer value2) {
            addCriterion("course_lesson_id not between", value1, value2, "courseLessonId");
            return (Criteria) this;
        }

        public Criteria andCourseVideoTypeIsNull() {
            addCriterion("course_video_type is null");
            return (Criteria) this;
        }

        public Criteria andCourseVideoTypeIsNotNull() {
            addCriterion("course_video_type is not null");
            return (Criteria) this;
        }

        public Criteria andCourseVideoTypeEqualTo(Byte value) {
            addCriterion("course_video_type =", value, "courseVideoType");
            return (Criteria) this;
        }

        public Criteria andCourseVideoTypeNotEqualTo(Byte value) {
            addCriterion("course_video_type <>", value, "courseVideoType");
            return (Criteria) this;
        }

        public Criteria andCourseVideoTypeGreaterThan(Byte value) {
            addCriterion("course_video_type >", value, "courseVideoType");
            return (Criteria) this;
        }

        public Criteria andCourseVideoTypeGreaterThanOrEqualTo(Byte value) {
            addCriterion("course_video_type >=", value, "courseVideoType");
            return (Criteria) this;
        }

        public Criteria andCourseVideoTypeLessThan(Byte value) {
            addCriterion("course_video_type <", value, "courseVideoType");
            return (Criteria) this;
        }

        public Criteria andCourseVideoTypeLessThanOrEqualTo(Byte value) {
            addCriterion("course_video_type <=", value, "courseVideoType");
            return (Criteria) this;
        }

        public Criteria andCourseVideoTypeIn(List<Byte> values) {
            addCriterion("course_video_type in", values, "courseVideoType");
            return (Criteria) this;
        }

        public Criteria andCourseVideoTypeNotIn(List<Byte> values) {
            addCriterion("course_video_type not in", values, "courseVideoType");
            return (Criteria) this;
        }

        public Criteria andCourseVideoTypeBetween(Byte value1, Byte value2) {
            addCriterion("course_video_type between", value1, value2, "courseVideoType");
            return (Criteria) this;
        }

        public Criteria andCourseVideoTypeNotBetween(Byte value1, Byte value2) {
            addCriterion("course_video_type not between", value1, value2, "courseVideoType");
            return (Criteria) this;
        }

        public Criteria andVidIsNull() {
            addCriterion("vid is null");
            return (Criteria) this;
        }

        public Criteria andVidIsNotNull() {
            addCriterion("vid is not null");
            return (Criteria) this;
        }

        public Criteria andVidEqualTo(String value) {
            addCriterion("vid =", value, "vid");
            return (Criteria) this;
        }

        public Criteria andVidNotEqualTo(String value) {
            addCriterion("vid <>", value, "vid");
            return (Criteria) this;
        }

        public Criteria andVidGreaterThan(String value) {
            addCriterion("vid >", value, "vid");
            return (Criteria) this;
        }

        public Criteria andVidGreaterThanOrEqualTo(String value) {
            addCriterion("vid >=", value, "vid");
            return (Criteria) this;
        }

        public Criteria andVidLessThan(String value) {
            addCriterion("vid <", value, "vid");
            return (Criteria) this;
        }

        public Criteria andVidLessThanOrEqualTo(String value) {
            addCriterion("vid <=", value, "vid");
            return (Criteria) this;
        }

        public Criteria andVidLike(String value) {
            addCriterion("vid like", value, "vid");
            return (Criteria) this;
        }

        public Criteria andVidNotLike(String value) {
            addCriterion("vid not like", value, "vid");
            return (Criteria) this;
        }

        public Criteria andVidIn(List<String> values) {
            addCriterion("vid in", values, "vid");
            return (Criteria) this;
        }

        public Criteria andVidNotIn(List<String> values) {
            addCriterion("vid not in", values, "vid");
            return (Criteria) this;
        }

        public Criteria andVidBetween(String value1, String value2) {
            addCriterion("vid between", value1, value2, "vid");
            return (Criteria) this;
        }

        public Criteria andVidNotBetween(String value1, String value2) {
            addCriterion("vid not between", value1, value2, "vid");
            return (Criteria) this;
        }

        public Criteria andTitleIsNull() {
            addCriterion("title is null");
            return (Criteria) this;
        }

        public Criteria andTitleIsNotNull() {
            addCriterion("title is not null");
            return (Criteria) this;
        }

        public Criteria andTitleEqualTo(String value) {
            addCriterion("title =", value, "title");
            return (Criteria) this;
        }

        public Criteria andTitleNotEqualTo(String value) {
            addCriterion("title <>", value, "title");
            return (Criteria) this;
        }

        public Criteria andTitleGreaterThan(String value) {
            addCriterion("title >", value, "title");
            return (Criteria) this;
        }

        public Criteria andTitleGreaterThanOrEqualTo(String value) {
            addCriterion("title >=", value, "title");
            return (Criteria) this;
        }

        public Criteria andTitleLessThan(String value) {
            addCriterion("title <", value, "title");
            return (Criteria) this;
        }

        public Criteria andTitleLessThanOrEqualTo(String value) {
            addCriterion("title <=", value, "title");
            return (Criteria) this;
        }

        public Criteria andTitleLike(String value) {
            addCriterion("title like", value, "title");
            return (Criteria) this;
        }

        public Criteria andTitleNotLike(String value) {
            addCriterion("title not like", value, "title");
            return (Criteria) this;
        }

        public Criteria andTitleIn(List<String> values) {
            addCriterion("title in", values, "title");
            return (Criteria) this;
        }

        public Criteria andTitleNotIn(List<String> values) {
            addCriterion("title not in", values, "title");
            return (Criteria) this;
        }

        public Criteria andTitleBetween(String value1, String value2) {
            addCriterion("title between", value1, value2, "title");
            return (Criteria) this;
        }

        public Criteria andTitleNotBetween(String value1, String value2) {
            addCriterion("title not between", value1, value2, "title");
            return (Criteria) this;
        }

        public Criteria andTagIsNull() {
            addCriterion("tag is null");
            return (Criteria) this;
        }

        public Criteria andTagIsNotNull() {
            addCriterion("tag is not null");
            return (Criteria) this;
        }

        public Criteria andTagEqualTo(String value) {
            addCriterion("tag =", value, "tag");
            return (Criteria) this;
        }

        public Criteria andTagNotEqualTo(String value) {
            addCriterion("tag <>", value, "tag");
            return (Criteria) this;
        }

        public Criteria andTagGreaterThan(String value) {
            addCriterion("tag >", value, "tag");
            return (Criteria) this;
        }

        public Criteria andTagGreaterThanOrEqualTo(String value) {
            addCriterion("tag >=", value, "tag");
            return (Criteria) this;
        }

        public Criteria andTagLessThan(String value) {
            addCriterion("tag <", value, "tag");
            return (Criteria) this;
        }

        public Criteria andTagLessThanOrEqualTo(String value) {
            addCriterion("tag <=", value, "tag");
            return (Criteria) this;
        }

        public Criteria andTagLike(String value) {
            addCriterion("tag like", value, "tag");
            return (Criteria) this;
        }

        public Criteria andTagNotLike(String value) {
            addCriterion("tag not like", value, "tag");
            return (Criteria) this;
        }

        public Criteria andTagIn(List<String> values) {
            addCriterion("tag in", values, "tag");
            return (Criteria) this;
        }

        public Criteria andTagNotIn(List<String> values) {
            addCriterion("tag not in", values, "tag");
            return (Criteria) this;
        }

        public Criteria andTagBetween(String value1, String value2) {
            addCriterion("tag between", value1, value2, "tag");
            return (Criteria) this;
        }

        public Criteria andTagNotBetween(String value1, String value2) {
            addCriterion("tag not between", value1, value2, "tag");
            return (Criteria) this;
        }

        public Criteria andSwfLinkIsNull() {
            addCriterion("swf_link is null");
            return (Criteria) this;
        }

        public Criteria andSwfLinkIsNotNull() {
            addCriterion("swf_link is not null");
            return (Criteria) this;
        }

        public Criteria andSwfLinkEqualTo(String value) {
            addCriterion("swf_link =", value, "swfLink");
            return (Criteria) this;
        }

        public Criteria andSwfLinkNotEqualTo(String value) {
            addCriterion("swf_link <>", value, "swfLink");
            return (Criteria) this;
        }

        public Criteria andSwfLinkGreaterThan(String value) {
            addCriterion("swf_link >", value, "swfLink");
            return (Criteria) this;
        }

        public Criteria andSwfLinkGreaterThanOrEqualTo(String value) {
            addCriterion("swf_link >=", value, "swfLink");
            return (Criteria) this;
        }

        public Criteria andSwfLinkLessThan(String value) {
            addCriterion("swf_link <", value, "swfLink");
            return (Criteria) this;
        }

        public Criteria andSwfLinkLessThanOrEqualTo(String value) {
            addCriterion("swf_link <=", value, "swfLink");
            return (Criteria) this;
        }

        public Criteria andSwfLinkLike(String value) {
            addCriterion("swf_link like", value, "swfLink");
            return (Criteria) this;
        }

        public Criteria andSwfLinkNotLike(String value) {
            addCriterion("swf_link not like", value, "swfLink");
            return (Criteria) this;
        }

        public Criteria andSwfLinkIn(List<String> values) {
            addCriterion("swf_link in", values, "swfLink");
            return (Criteria) this;
        }

        public Criteria andSwfLinkNotIn(List<String> values) {
            addCriterion("swf_link not in", values, "swfLink");
            return (Criteria) this;
        }

        public Criteria andSwfLinkBetween(String value1, String value2) {
            addCriterion("swf_link between", value1, value2, "swfLink");
            return (Criteria) this;
        }

        public Criteria andSwfLinkNotBetween(String value1, String value2) {
            addCriterion("swf_link not between", value1, value2, "swfLink");
            return (Criteria) this;
        }

        public Criteria andSourcefileIsNull() {
            addCriterion("sourcefile is null");
            return (Criteria) this;
        }

        public Criteria andSourcefileIsNotNull() {
            addCriterion("sourcefile is not null");
            return (Criteria) this;
        }

        public Criteria andSourcefileEqualTo(String value) {
            addCriterion("sourcefile =", value, "sourcefile");
            return (Criteria) this;
        }

        public Criteria andSourcefileNotEqualTo(String value) {
            addCriterion("sourcefile <>", value, "sourcefile");
            return (Criteria) this;
        }

        public Criteria andSourcefileGreaterThan(String value) {
            addCriterion("sourcefile >", value, "sourcefile");
            return (Criteria) this;
        }

        public Criteria andSourcefileGreaterThanOrEqualTo(String value) {
            addCriterion("sourcefile >=", value, "sourcefile");
            return (Criteria) this;
        }

        public Criteria andSourcefileLessThan(String value) {
            addCriterion("sourcefile <", value, "sourcefile");
            return (Criteria) this;
        }

        public Criteria andSourcefileLessThanOrEqualTo(String value) {
            addCriterion("sourcefile <=", value, "sourcefile");
            return (Criteria) this;
        }

        public Criteria andSourcefileLike(String value) {
            addCriterion("sourcefile like", value, "sourcefile");
            return (Criteria) this;
        }

        public Criteria andSourcefileNotLike(String value) {
            addCriterion("sourcefile not like", value, "sourcefile");
            return (Criteria) this;
        }

        public Criteria andSourcefileIn(List<String> values) {
            addCriterion("sourcefile in", values, "sourcefile");
            return (Criteria) this;
        }

        public Criteria andSourcefileNotIn(List<String> values) {
            addCriterion("sourcefile not in", values, "sourcefile");
            return (Criteria) this;
        }

        public Criteria andSourcefileBetween(String value1, String value2) {
            addCriterion("sourcefile between", value1, value2, "sourcefile");
            return (Criteria) this;
        }

        public Criteria andSourcefileNotBetween(String value1, String value2) {
            addCriterion("sourcefile not between", value1, value2, "sourcefile");
            return (Criteria) this;
        }

        public Criteria andMp4IsNull() {
            addCriterion("mp4 is null");
            return (Criteria) this;
        }

        public Criteria andMp4IsNotNull() {
            addCriterion("mp4 is not null");
            return (Criteria) this;
        }

        public Criteria andMp4EqualTo(String value) {
            addCriterion("mp4 =", value, "mp4");
            return (Criteria) this;
        }

        public Criteria andMp4NotEqualTo(String value) {
            addCriterion("mp4 <>", value, "mp4");
            return (Criteria) this;
        }

        public Criteria andMp4GreaterThan(String value) {
            addCriterion("mp4 >", value, "mp4");
            return (Criteria) this;
        }

        public Criteria andMp4GreaterThanOrEqualTo(String value) {
            addCriterion("mp4 >=", value, "mp4");
            return (Criteria) this;
        }

        public Criteria andMp4LessThan(String value) {
            addCriterion("mp4 <", value, "mp4");
            return (Criteria) this;
        }

        public Criteria andMp4LessThanOrEqualTo(String value) {
            addCriterion("mp4 <=", value, "mp4");
            return (Criteria) this;
        }

        public Criteria andMp4Like(String value) {
            addCriterion("mp4 like", value, "mp4");
            return (Criteria) this;
        }

        public Criteria andMp4NotLike(String value) {
            addCriterion("mp4 not like", value, "mp4");
            return (Criteria) this;
        }

        public Criteria andMp4In(List<String> values) {
            addCriterion("mp4 in", values, "mp4");
            return (Criteria) this;
        }

        public Criteria andMp4NotIn(List<String> values) {
            addCriterion("mp4 not in", values, "mp4");
            return (Criteria) this;
        }

        public Criteria andMp4Between(String value1, String value2) {
            addCriterion("mp4 between", value1, value2, "mp4");
            return (Criteria) this;
        }

        public Criteria andMp4NotBetween(String value1, String value2) {
            addCriterion("mp4 not between", value1, value2, "mp4");
            return (Criteria) this;
        }

        public Criteria andPlayerwidthIsNull() {
            addCriterion("playerwidth is null");
            return (Criteria) this;
        }

        public Criteria andPlayerwidthIsNotNull() {
            addCriterion("playerwidth is not null");
            return (Criteria) this;
        }

        public Criteria andPlayerwidthEqualTo(Integer value) {
            addCriterion("playerwidth =", value, "playerwidth");
            return (Criteria) this;
        }

        public Criteria andPlayerwidthNotEqualTo(Integer value) {
            addCriterion("playerwidth <>", value, "playerwidth");
            return (Criteria) this;
        }

        public Criteria andPlayerwidthGreaterThan(Integer value) {
            addCriterion("playerwidth >", value, "playerwidth");
            return (Criteria) this;
        }

        public Criteria andPlayerwidthGreaterThanOrEqualTo(Integer value) {
            addCriterion("playerwidth >=", value, "playerwidth");
            return (Criteria) this;
        }

        public Criteria andPlayerwidthLessThan(Integer value) {
            addCriterion("playerwidth <", value, "playerwidth");
            return (Criteria) this;
        }

        public Criteria andPlayerwidthLessThanOrEqualTo(Integer value) {
            addCriterion("playerwidth <=", value, "playerwidth");
            return (Criteria) this;
        }

        public Criteria andPlayerwidthIn(List<Integer> values) {
            addCriterion("playerwidth in", values, "playerwidth");
            return (Criteria) this;
        }

        public Criteria andPlayerwidthNotIn(List<Integer> values) {
            addCriterion("playerwidth not in", values, "playerwidth");
            return (Criteria) this;
        }

        public Criteria andPlayerwidthBetween(Integer value1, Integer value2) {
            addCriterion("playerwidth between", value1, value2, "playerwidth");
            return (Criteria) this;
        }

        public Criteria andPlayerwidthNotBetween(Integer value1, Integer value2) {
            addCriterion("playerwidth not between", value1, value2, "playerwidth");
            return (Criteria) this;
        }

        public Criteria andPlayerheightIsNull() {
            addCriterion("playerheight is null");
            return (Criteria) this;
        }

        public Criteria andPlayerheightIsNotNull() {
            addCriterion("playerheight is not null");
            return (Criteria) this;
        }

        public Criteria andPlayerheightEqualTo(Integer value) {
            addCriterion("playerheight =", value, "playerheight");
            return (Criteria) this;
        }

        public Criteria andPlayerheightNotEqualTo(Integer value) {
            addCriterion("playerheight <>", value, "playerheight");
            return (Criteria) this;
        }

        public Criteria andPlayerheightGreaterThan(Integer value) {
            addCriterion("playerheight >", value, "playerheight");
            return (Criteria) this;
        }

        public Criteria andPlayerheightGreaterThanOrEqualTo(Integer value) {
            addCriterion("playerheight >=", value, "playerheight");
            return (Criteria) this;
        }

        public Criteria andPlayerheightLessThan(Integer value) {
            addCriterion("playerheight <", value, "playerheight");
            return (Criteria) this;
        }

        public Criteria andPlayerheightLessThanOrEqualTo(Integer value) {
            addCriterion("playerheight <=", value, "playerheight");
            return (Criteria) this;
        }

        public Criteria andPlayerheightIn(List<Integer> values) {
            addCriterion("playerheight in", values, "playerheight");
            return (Criteria) this;
        }

        public Criteria andPlayerheightNotIn(List<Integer> values) {
            addCriterion("playerheight not in", values, "playerheight");
            return (Criteria) this;
        }

        public Criteria andPlayerheightBetween(Integer value1, Integer value2) {
            addCriterion("playerheight between", value1, value2, "playerheight");
            return (Criteria) this;
        }

        public Criteria andPlayerheightNotBetween(Integer value1, Integer value2) {
            addCriterion("playerheight not between", value1, value2, "playerheight");
            return (Criteria) this;
        }

        public Criteria andDurationIsNull() {
            addCriterion("duration is null");
            return (Criteria) this;
        }

        public Criteria andDurationIsNotNull() {
            addCriterion("duration is not null");
            return (Criteria) this;
        }

        public Criteria andDurationEqualTo(String value) {
            addCriterion("duration =", value, "duration");
            return (Criteria) this;
        }

        public Criteria andDurationNotEqualTo(String value) {
            addCriterion("duration <>", value, "duration");
            return (Criteria) this;
        }

        public Criteria andDurationGreaterThan(String value) {
            addCriterion("duration >", value, "duration");
            return (Criteria) this;
        }

        public Criteria andDurationGreaterThanOrEqualTo(String value) {
            addCriterion("duration >=", value, "duration");
            return (Criteria) this;
        }

        public Criteria andDurationLessThan(String value) {
            addCriterion("duration <", value, "duration");
            return (Criteria) this;
        }

        public Criteria andDurationLessThanOrEqualTo(String value) {
            addCriterion("duration <=", value, "duration");
            return (Criteria) this;
        }

        public Criteria andDurationLike(String value) {
            addCriterion("duration like", value, "duration");
            return (Criteria) this;
        }

        public Criteria andDurationNotLike(String value) {
            addCriterion("duration not like", value, "duration");
            return (Criteria) this;
        }

        public Criteria andDurationIn(List<String> values) {
            addCriterion("duration in", values, "duration");
            return (Criteria) this;
        }

        public Criteria andDurationNotIn(List<String> values) {
            addCriterion("duration not in", values, "duration");
            return (Criteria) this;
        }

        public Criteria andDurationBetween(String value1, String value2) {
            addCriterion("duration between", value1, value2, "duration");
            return (Criteria) this;
        }

        public Criteria andDurationNotBetween(String value1, String value2) {
            addCriterion("duration not between", value1, value2, "duration");
            return (Criteria) this;
        }

        public Criteria andFilesizeIsNull() {
            addCriterion("filesize is null");
            return (Criteria) this;
        }

        public Criteria andFilesizeIsNotNull() {
            addCriterion("filesize is not null");
            return (Criteria) this;
        }

        public Criteria andFilesizeEqualTo(String value) {
            addCriterion("filesize =", value, "filesize");
            return (Criteria) this;
        }

        public Criteria andFilesizeNotEqualTo(String value) {
            addCriterion("filesize <>", value, "filesize");
            return (Criteria) this;
        }

        public Criteria andFilesizeGreaterThan(String value) {
            addCriterion("filesize >", value, "filesize");
            return (Criteria) this;
        }

        public Criteria andFilesizeGreaterThanOrEqualTo(String value) {
            addCriterion("filesize >=", value, "filesize");
            return (Criteria) this;
        }

        public Criteria andFilesizeLessThan(String value) {
            addCriterion("filesize <", value, "filesize");
            return (Criteria) this;
        }

        public Criteria andFilesizeLessThanOrEqualTo(String value) {
            addCriterion("filesize <=", value, "filesize");
            return (Criteria) this;
        }

        public Criteria andFilesizeLike(String value) {
            addCriterion("filesize like", value, "filesize");
            return (Criteria) this;
        }

        public Criteria andFilesizeNotLike(String value) {
            addCriterion("filesize not like", value, "filesize");
            return (Criteria) this;
        }

        public Criteria andFilesizeIn(List<String> values) {
            addCriterion("filesize in", values, "filesize");
            return (Criteria) this;
        }

        public Criteria andFilesizeNotIn(List<String> values) {
            addCriterion("filesize not in", values, "filesize");
            return (Criteria) this;
        }

        public Criteria andFilesizeBetween(String value1, String value2) {
            addCriterion("filesize between", value1, value2, "filesize");
            return (Criteria) this;
        }

        public Criteria andFilesizeNotBetween(String value1, String value2) {
            addCriterion("filesize not between", value1, value2, "filesize");
            return (Criteria) this;
        }

        public Criteria andFirstImageIsNull() {
            addCriterion("first_image is null");
            return (Criteria) this;
        }

        public Criteria andFirstImageIsNotNull() {
            addCriterion("first_image is not null");
            return (Criteria) this;
        }

        public Criteria andFirstImageEqualTo(String value) {
            addCriterion("first_image =", value, "firstImage");
            return (Criteria) this;
        }

        public Criteria andFirstImageNotEqualTo(String value) {
            addCriterion("first_image <>", value, "firstImage");
            return (Criteria) this;
        }

        public Criteria andFirstImageGreaterThan(String value) {
            addCriterion("first_image >", value, "firstImage");
            return (Criteria) this;
        }

        public Criteria andFirstImageGreaterThanOrEqualTo(String value) {
            addCriterion("first_image >=", value, "firstImage");
            return (Criteria) this;
        }

        public Criteria andFirstImageLessThan(String value) {
            addCriterion("first_image <", value, "firstImage");
            return (Criteria) this;
        }

        public Criteria andFirstImageLessThanOrEqualTo(String value) {
            addCriterion("first_image <=", value, "firstImage");
            return (Criteria) this;
        }

        public Criteria andFirstImageLike(String value) {
            addCriterion("first_image like", value, "firstImage");
            return (Criteria) this;
        }

        public Criteria andFirstImageNotLike(String value) {
            addCriterion("first_image not like", value, "firstImage");
            return (Criteria) this;
        }

        public Criteria andFirstImageIn(List<String> values) {
            addCriterion("first_image in", values, "firstImage");
            return (Criteria) this;
        }

        public Criteria andFirstImageNotIn(List<String> values) {
            addCriterion("first_image not in", values, "firstImage");
            return (Criteria) this;
        }

        public Criteria andFirstImageBetween(String value1, String value2) {
            addCriterion("first_image between", value1, value2, "firstImage");
            return (Criteria) this;
        }

        public Criteria andFirstImageNotBetween(String value1, String value2) {
            addCriterion("first_image not between", value1, value2, "firstImage");
            return (Criteria) this;
        }

        public Criteria andTimesIsNull() {
            addCriterion("times is null");
            return (Criteria) this;
        }

        public Criteria andTimesIsNotNull() {
            addCriterion("times is not null");
            return (Criteria) this;
        }

        public Criteria andTimesEqualTo(Integer value) {
            addCriterion("times =", value, "times");
            return (Criteria) this;
        }

        public Criteria andTimesNotEqualTo(Integer value) {
            addCriterion("times <>", value, "times");
            return (Criteria) this;
        }

        public Criteria andTimesGreaterThan(Integer value) {
            addCriterion("times >", value, "times");
            return (Criteria) this;
        }

        public Criteria andTimesGreaterThanOrEqualTo(Integer value) {
            addCriterion("times >=", value, "times");
            return (Criteria) this;
        }

        public Criteria andTimesLessThan(Integer value) {
            addCriterion("times <", value, "times");
            return (Criteria) this;
        }

        public Criteria andTimesLessThanOrEqualTo(Integer value) {
            addCriterion("times <=", value, "times");
            return (Criteria) this;
        }

        public Criteria andTimesIn(List<Integer> values) {
            addCriterion("times in", values, "times");
            return (Criteria) this;
        }

        public Criteria andTimesNotIn(List<Integer> values) {
            addCriterion("times not in", values, "times");
            return (Criteria) this;
        }

        public Criteria andTimesBetween(Integer value1, Integer value2) {
            addCriterion("times between", value1, value2, "times");
            return (Criteria) this;
        }

        public Criteria andTimesNotBetween(Integer value1, Integer value2) {
            addCriterion("times not between", value1, value2, "times");
            return (Criteria) this;
        }

        public Criteria andContextIsNull() {
            addCriterion("context is null");
            return (Criteria) this;
        }

        public Criteria andContextIsNotNull() {
            addCriterion("context is not null");
            return (Criteria) this;
        }

        public Criteria andContextEqualTo(String value) {
            addCriterion("context =", value, "context");
            return (Criteria) this;
        }

        public Criteria andContextNotEqualTo(String value) {
            addCriterion("context <>", value, "context");
            return (Criteria) this;
        }

        public Criteria andContextGreaterThan(String value) {
            addCriterion("context >", value, "context");
            return (Criteria) this;
        }

        public Criteria andContextGreaterThanOrEqualTo(String value) {
            addCriterion("context >=", value, "context");
            return (Criteria) this;
        }

        public Criteria andContextLessThan(String value) {
            addCriterion("context <", value, "context");
            return (Criteria) this;
        }

        public Criteria andContextLessThanOrEqualTo(String value) {
            addCriterion("context <=", value, "context");
            return (Criteria) this;
        }

        public Criteria andContextLike(String value) {
            addCriterion("context like", value, "context");
            return (Criteria) this;
        }

        public Criteria andContextNotLike(String value) {
            addCriterion("context not like", value, "context");
            return (Criteria) this;
        }

        public Criteria andContextIn(List<String> values) {
            addCriterion("context in", values, "context");
            return (Criteria) this;
        }

        public Criteria andContextNotIn(List<String> values) {
            addCriterion("context not in", values, "context");
            return (Criteria) this;
        }

        public Criteria andContextBetween(String value1, String value2) {
            addCriterion("context between", value1, value2, "context");
            return (Criteria) this;
        }

        public Criteria andContextNotBetween(String value1, String value2) {
            addCriterion("context not between", value1, value2, "context");
            return (Criteria) this;
        }

        public Criteria andOriginalDefinitionIsNull() {
            addCriterion("original_definition is null");
            return (Criteria) this;
        }

        public Criteria andOriginalDefinitionIsNotNull() {
            addCriterion("original_definition is not null");
            return (Criteria) this;
        }

        public Criteria andOriginalDefinitionEqualTo(String value) {
            addCriterion("original_definition =", value, "originalDefinition");
            return (Criteria) this;
        }

        public Criteria andOriginalDefinitionNotEqualTo(String value) {
            addCriterion("original_definition <>", value, "originalDefinition");
            return (Criteria) this;
        }

        public Criteria andOriginalDefinitionGreaterThan(String value) {
            addCriterion("original_definition >", value, "originalDefinition");
            return (Criteria) this;
        }

        public Criteria andOriginalDefinitionGreaterThanOrEqualTo(String value) {
            addCriterion("original_definition >=", value, "originalDefinition");
            return (Criteria) this;
        }

        public Criteria andOriginalDefinitionLessThan(String value) {
            addCriterion("original_definition <", value, "originalDefinition");
            return (Criteria) this;
        }

        public Criteria andOriginalDefinitionLessThanOrEqualTo(String value) {
            addCriterion("original_definition <=", value, "originalDefinition");
            return (Criteria) this;
        }

        public Criteria andOriginalDefinitionLike(String value) {
            addCriterion("original_definition like", value, "originalDefinition");
            return (Criteria) this;
        }

        public Criteria andOriginalDefinitionNotLike(String value) {
            addCriterion("original_definition not like", value, "originalDefinition");
            return (Criteria) this;
        }

        public Criteria andOriginalDefinitionIn(List<String> values) {
            addCriterion("original_definition in", values, "originalDefinition");
            return (Criteria) this;
        }

        public Criteria andOriginalDefinitionNotIn(List<String> values) {
            addCriterion("original_definition not in", values, "originalDefinition");
            return (Criteria) this;
        }

        public Criteria andOriginalDefinitionBetween(String value1, String value2) {
            addCriterion("original_definition between", value1, value2, "originalDefinition");
            return (Criteria) this;
        }

        public Criteria andOriginalDefinitionNotBetween(String value1, String value2) {
            addCriterion("original_definition not between", value1, value2, "originalDefinition");
            return (Criteria) this;
        }

        public Criteria andPreviewvidIsNull() {
            addCriterion("previewVid is null");
            return (Criteria) this;
        }

        public Criteria andPreviewvidIsNotNull() {
            addCriterion("previewVid is not null");
            return (Criteria) this;
        }

        public Criteria andPreviewvidEqualTo(String value) {
            addCriterion("previewVid =", value, "previewvid");
            return (Criteria) this;
        }

        public Criteria andPreviewvidNotEqualTo(String value) {
            addCriterion("previewVid <>", value, "previewvid");
            return (Criteria) this;
        }

        public Criteria andPreviewvidGreaterThan(String value) {
            addCriterion("previewVid >", value, "previewvid");
            return (Criteria) this;
        }

        public Criteria andPreviewvidGreaterThanOrEqualTo(String value) {
            addCriterion("previewVid >=", value, "previewvid");
            return (Criteria) this;
        }

        public Criteria andPreviewvidLessThan(String value) {
            addCriterion("previewVid <", value, "previewvid");
            return (Criteria) this;
        }

        public Criteria andPreviewvidLessThanOrEqualTo(String value) {
            addCriterion("previewVid <=", value, "previewvid");
            return (Criteria) this;
        }

        public Criteria andPreviewvidLike(String value) {
            addCriterion("previewVid like", value, "previewvid");
            return (Criteria) this;
        }

        public Criteria andPreviewvidNotLike(String value) {
            addCriterion("previewVid not like", value, "previewvid");
            return (Criteria) this;
        }

        public Criteria andPreviewvidIn(List<String> values) {
            addCriterion("previewVid in", values, "previewvid");
            return (Criteria) this;
        }

        public Criteria andPreviewvidNotIn(List<String> values) {
            addCriterion("previewVid not in", values, "previewvid");
            return (Criteria) this;
        }

        public Criteria andPreviewvidBetween(String value1, String value2) {
            addCriterion("previewVid between", value1, value2, "previewvid");
            return (Criteria) this;
        }

        public Criteria andPreviewvidNotBetween(String value1, String value2) {
            addCriterion("previewVid not between", value1, value2, "previewvid");
            return (Criteria) this;
        }

        public Criteria andPtimeIsNull() {
            addCriterion("ptime is null");
            return (Criteria) this;
        }

        public Criteria andPtimeIsNotNull() {
            addCriterion("ptime is not null");
            return (Criteria) this;
        }

        public Criteria andPtimeEqualTo(Date value) {
            addCriterion("ptime =", value, "ptime");
            return (Criteria) this;
        }

        public Criteria andPtimeNotEqualTo(Date value) {
            addCriterion("ptime <>", value, "ptime");
            return (Criteria) this;
        }

        public Criteria andPtimeGreaterThan(Date value) {
            addCriterion("ptime >", value, "ptime");
            return (Criteria) this;
        }

        public Criteria andPtimeGreaterThanOrEqualTo(Date value) {
            addCriterion("ptime >=", value, "ptime");
            return (Criteria) this;
        }

        public Criteria andPtimeLessThan(Date value) {
            addCriterion("ptime <", value, "ptime");
            return (Criteria) this;
        }

        public Criteria andPtimeLessThanOrEqualTo(Date value) {
            addCriterion("ptime <=", value, "ptime");
            return (Criteria) this;
        }

        public Criteria andPtimeIn(List<Date> values) {
            addCriterion("ptime in", values, "ptime");
            return (Criteria) this;
        }

        public Criteria andPtimeNotIn(List<Date> values) {
            addCriterion("ptime not in", values, "ptime");
            return (Criteria) this;
        }

        public Criteria andPtimeBetween(Date value1, Date value2) {
            addCriterion("ptime between", value1, value2, "ptime");
            return (Criteria) this;
        }

        public Criteria andPtimeNotBetween(Date value1, Date value2) {
            addCriterion("ptime not between", value1, value2, "ptime");
            return (Criteria) this;
        }

        public Criteria andCataidIsNull() {
            addCriterion("cataid is null");
            return (Criteria) this;
        }

        public Criteria andCataidIsNotNull() {
            addCriterion("cataid is not null");
            return (Criteria) this;
        }

        public Criteria andCataidEqualTo(String value) {
            addCriterion("cataid =", value, "cataid");
            return (Criteria) this;
        }

        public Criteria andCataidNotEqualTo(String value) {
            addCriterion("cataid <>", value, "cataid");
            return (Criteria) this;
        }

        public Criteria andCataidGreaterThan(String value) {
            addCriterion("cataid >", value, "cataid");
            return (Criteria) this;
        }

        public Criteria andCataidGreaterThanOrEqualTo(String value) {
            addCriterion("cataid >=", value, "cataid");
            return (Criteria) this;
        }

        public Criteria andCataidLessThan(String value) {
            addCriterion("cataid <", value, "cataid");
            return (Criteria) this;
        }

        public Criteria andCataidLessThanOrEqualTo(String value) {
            addCriterion("cataid <=", value, "cataid");
            return (Criteria) this;
        }

        public Criteria andCataidLike(String value) {
            addCriterion("cataid like", value, "cataid");
            return (Criteria) this;
        }

        public Criteria andCataidNotLike(String value) {
            addCriterion("cataid not like", value, "cataid");
            return (Criteria) this;
        }

        public Criteria andCataidIn(List<String> values) {
            addCriterion("cataid in", values, "cataid");
            return (Criteria) this;
        }

        public Criteria andCataidNotIn(List<String> values) {
            addCriterion("cataid not in", values, "cataid");
            return (Criteria) this;
        }

        public Criteria andCataidBetween(String value1, String value2) {
            addCriterion("cataid between", value1, value2, "cataid");
            return (Criteria) this;
        }

        public Criteria andCataidNotBetween(String value1, String value2) {
            addCriterion("cataid not between", value1, value2, "cataid");
            return (Criteria) this;
        }

        public Criteria andDefaultVideoIsNull() {
            addCriterion("default_video is null");
            return (Criteria) this;
        }

        public Criteria andDefaultVideoIsNotNull() {
            addCriterion("default_video is not null");
            return (Criteria) this;
        }

        public Criteria andDefaultVideoEqualTo(String value) {
            addCriterion("default_video =", value, "defaultVideo");
            return (Criteria) this;
        }

        public Criteria andDefaultVideoNotEqualTo(String value) {
            addCriterion("default_video <>", value, "defaultVideo");
            return (Criteria) this;
        }

        public Criteria andDefaultVideoGreaterThan(String value) {
            addCriterion("default_video >", value, "defaultVideo");
            return (Criteria) this;
        }

        public Criteria andDefaultVideoGreaterThanOrEqualTo(String value) {
            addCriterion("default_video >=", value, "defaultVideo");
            return (Criteria) this;
        }

        public Criteria andDefaultVideoLessThan(String value) {
            addCriterion("default_video <", value, "defaultVideo");
            return (Criteria) this;
        }

        public Criteria andDefaultVideoLessThanOrEqualTo(String value) {
            addCriterion("default_video <=", value, "defaultVideo");
            return (Criteria) this;
        }

        public Criteria andDefaultVideoLike(String value) {
            addCriterion("default_video like", value, "defaultVideo");
            return (Criteria) this;
        }

        public Criteria andDefaultVideoNotLike(String value) {
            addCriterion("default_video not like", value, "defaultVideo");
            return (Criteria) this;
        }

        public Criteria andDefaultVideoIn(List<String> values) {
            addCriterion("default_video in", values, "defaultVideo");
            return (Criteria) this;
        }

        public Criteria andDefaultVideoNotIn(List<String> values) {
            addCriterion("default_video not in", values, "defaultVideo");
            return (Criteria) this;
        }

        public Criteria andDefaultVideoBetween(String value1, String value2) {
            addCriterion("default_video between", value1, value2, "defaultVideo");
            return (Criteria) this;
        }

        public Criteria andDefaultVideoNotBetween(String value1, String value2) {
            addCriterion("default_video not between", value1, value2, "defaultVideo");
            return (Criteria) this;
        }

        public Criteria andDfIsNull() {
            addCriterion("df is null");
            return (Criteria) this;
        }

        public Criteria andDfIsNotNull() {
            addCriterion("df is not null");
            return (Criteria) this;
        }

        public Criteria andDfEqualTo(Integer value) {
            addCriterion("df =", value, "df");
            return (Criteria) this;
        }

        public Criteria andDfNotEqualTo(Integer value) {
            addCriterion("df <>", value, "df");
            return (Criteria) this;
        }

        public Criteria andDfGreaterThan(Integer value) {
            addCriterion("df >", value, "df");
            return (Criteria) this;
        }

        public Criteria andDfGreaterThanOrEqualTo(Integer value) {
            addCriterion("df >=", value, "df");
            return (Criteria) this;
        }

        public Criteria andDfLessThan(Integer value) {
            addCriterion("df <", value, "df");
            return (Criteria) this;
        }

        public Criteria andDfLessThanOrEqualTo(Integer value) {
            addCriterion("df <=", value, "df");
            return (Criteria) this;
        }

        public Criteria andDfIn(List<Integer> values) {
            addCriterion("df in", values, "df");
            return (Criteria) this;
        }

        public Criteria andDfNotIn(List<Integer> values) {
            addCriterion("df not in", values, "df");
            return (Criteria) this;
        }

        public Criteria andDfBetween(Integer value1, Integer value2) {
            addCriterion("df between", value1, value2, "df");
            return (Criteria) this;
        }

        public Criteria andDfNotBetween(Integer value1, Integer value2) {
            addCriterion("df not between", value1, value2, "df");
            return (Criteria) this;
        }

        public Criteria andFlv1IsNull() {
            addCriterion("flv1 is null");
            return (Criteria) this;
        }

        public Criteria andFlv1IsNotNull() {
            addCriterion("flv1 is not null");
            return (Criteria) this;
        }

        public Criteria andFlv1EqualTo(String value) {
            addCriterion("flv1 =", value, "flv1");
            return (Criteria) this;
        }

        public Criteria andFlv1NotEqualTo(String value) {
            addCriterion("flv1 <>", value, "flv1");
            return (Criteria) this;
        }

        public Criteria andFlv1GreaterThan(String value) {
            addCriterion("flv1 >", value, "flv1");
            return (Criteria) this;
        }

        public Criteria andFlv1GreaterThanOrEqualTo(String value) {
            addCriterion("flv1 >=", value, "flv1");
            return (Criteria) this;
        }

        public Criteria andFlv1LessThan(String value) {
            addCriterion("flv1 <", value, "flv1");
            return (Criteria) this;
        }

        public Criteria andFlv1LessThanOrEqualTo(String value) {
            addCriterion("flv1 <=", value, "flv1");
            return (Criteria) this;
        }

        public Criteria andFlv1Like(String value) {
            addCriterion("flv1 like", value, "flv1");
            return (Criteria) this;
        }

        public Criteria andFlv1NotLike(String value) {
            addCriterion("flv1 not like", value, "flv1");
            return (Criteria) this;
        }

        public Criteria andFlv1In(List<String> values) {
            addCriterion("flv1 in", values, "flv1");
            return (Criteria) this;
        }

        public Criteria andFlv1NotIn(List<String> values) {
            addCriterion("flv1 not in", values, "flv1");
            return (Criteria) this;
        }

        public Criteria andFlv1Between(String value1, String value2) {
            addCriterion("flv1 between", value1, value2, "flv1");
            return (Criteria) this;
        }

        public Criteria andFlv1NotBetween(String value1, String value2) {
            addCriterion("flv1 not between", value1, value2, "flv1");
            return (Criteria) this;
        }

        public Criteria andFlv2IsNull() {
            addCriterion("flv2 is null");
            return (Criteria) this;
        }

        public Criteria andFlv2IsNotNull() {
            addCriterion("flv2 is not null");
            return (Criteria) this;
        }

        public Criteria andFlv2EqualTo(String value) {
            addCriterion("flv2 =", value, "flv2");
            return (Criteria) this;
        }

        public Criteria andFlv2NotEqualTo(String value) {
            addCriterion("flv2 <>", value, "flv2");
            return (Criteria) this;
        }

        public Criteria andFlv2GreaterThan(String value) {
            addCriterion("flv2 >", value, "flv2");
            return (Criteria) this;
        }

        public Criteria andFlv2GreaterThanOrEqualTo(String value) {
            addCriterion("flv2 >=", value, "flv2");
            return (Criteria) this;
        }

        public Criteria andFlv2LessThan(String value) {
            addCriterion("flv2 <", value, "flv2");
            return (Criteria) this;
        }

        public Criteria andFlv2LessThanOrEqualTo(String value) {
            addCriterion("flv2 <=", value, "flv2");
            return (Criteria) this;
        }

        public Criteria andFlv2Like(String value) {
            addCriterion("flv2 like", value, "flv2");
            return (Criteria) this;
        }

        public Criteria andFlv2NotLike(String value) {
            addCriterion("flv2 not like", value, "flv2");
            return (Criteria) this;
        }

        public Criteria andFlv2In(List<String> values) {
            addCriterion("flv2 in", values, "flv2");
            return (Criteria) this;
        }

        public Criteria andFlv2NotIn(List<String> values) {
            addCriterion("flv2 not in", values, "flv2");
            return (Criteria) this;
        }

        public Criteria andFlv2Between(String value1, String value2) {
            addCriterion("flv2 between", value1, value2, "flv2");
            return (Criteria) this;
        }

        public Criteria andFlv2NotBetween(String value1, String value2) {
            addCriterion("flv2 not between", value1, value2, "flv2");
            return (Criteria) this;
        }

        public Criteria andFlv3IsNull() {
            addCriterion("flv3 is null");
            return (Criteria) this;
        }

        public Criteria andFlv3IsNotNull() {
            addCriterion("flv3 is not null");
            return (Criteria) this;
        }

        public Criteria andFlv3EqualTo(String value) {
            addCriterion("flv3 =", value, "flv3");
            return (Criteria) this;
        }

        public Criteria andFlv3NotEqualTo(String value) {
            addCriterion("flv3 <>", value, "flv3");
            return (Criteria) this;
        }

        public Criteria andFlv3GreaterThan(String value) {
            addCriterion("flv3 >", value, "flv3");
            return (Criteria) this;
        }

        public Criteria andFlv3GreaterThanOrEqualTo(String value) {
            addCriterion("flv3 >=", value, "flv3");
            return (Criteria) this;
        }

        public Criteria andFlv3LessThan(String value) {
            addCriterion("flv3 <", value, "flv3");
            return (Criteria) this;
        }

        public Criteria andFlv3LessThanOrEqualTo(String value) {
            addCriterion("flv3 <=", value, "flv3");
            return (Criteria) this;
        }

        public Criteria andFlv3Like(String value) {
            addCriterion("flv3 like", value, "flv3");
            return (Criteria) this;
        }

        public Criteria andFlv3NotLike(String value) {
            addCriterion("flv3 not like", value, "flv3");
            return (Criteria) this;
        }

        public Criteria andFlv3In(List<String> values) {
            addCriterion("flv3 in", values, "flv3");
            return (Criteria) this;
        }

        public Criteria andFlv3NotIn(List<String> values) {
            addCriterion("flv3 not in", values, "flv3");
            return (Criteria) this;
        }

        public Criteria andFlv3Between(String value1, String value2) {
            addCriterion("flv3 between", value1, value2, "flv3");
            return (Criteria) this;
        }

        public Criteria andFlv3NotBetween(String value1, String value2) {
            addCriterion("flv3 not between", value1, value2, "flv3");
            return (Criteria) this;
        }

        public Criteria andMp41IsNull() {
            addCriterion("mp4_1 is null");
            return (Criteria) this;
        }

        public Criteria andMp41IsNotNull() {
            addCriterion("mp4_1 is not null");
            return (Criteria) this;
        }

        public Criteria andMp41EqualTo(String value) {
            addCriterion("mp4_1 =", value, "mp41");
            return (Criteria) this;
        }

        public Criteria andMp41NotEqualTo(String value) {
            addCriterion("mp4_1 <>", value, "mp41");
            return (Criteria) this;
        }

        public Criteria andMp41GreaterThan(String value) {
            addCriterion("mp4_1 >", value, "mp41");
            return (Criteria) this;
        }

        public Criteria andMp41GreaterThanOrEqualTo(String value) {
            addCriterion("mp4_1 >=", value, "mp41");
            return (Criteria) this;
        }

        public Criteria andMp41LessThan(String value) {
            addCriterion("mp4_1 <", value, "mp41");
            return (Criteria) this;
        }

        public Criteria andMp41LessThanOrEqualTo(String value) {
            addCriterion("mp4_1 <=", value, "mp41");
            return (Criteria) this;
        }

        public Criteria andMp41Like(String value) {
            addCriterion("mp4_1 like", value, "mp41");
            return (Criteria) this;
        }

        public Criteria andMp41NotLike(String value) {
            addCriterion("mp4_1 not like", value, "mp41");
            return (Criteria) this;
        }

        public Criteria andMp41In(List<String> values) {
            addCriterion("mp4_1 in", values, "mp41");
            return (Criteria) this;
        }

        public Criteria andMp41NotIn(List<String> values) {
            addCriterion("mp4_1 not in", values, "mp41");
            return (Criteria) this;
        }

        public Criteria andMp41Between(String value1, String value2) {
            addCriterion("mp4_1 between", value1, value2, "mp41");
            return (Criteria) this;
        }

        public Criteria andMp41NotBetween(String value1, String value2) {
            addCriterion("mp4_1 not between", value1, value2, "mp41");
            return (Criteria) this;
        }

        public Criteria andMp42IsNull() {
            addCriterion("mp4_2 is null");
            return (Criteria) this;
        }

        public Criteria andMp42IsNotNull() {
            addCriterion("mp4_2 is not null");
            return (Criteria) this;
        }

        public Criteria andMp42EqualTo(String value) {
            addCriterion("mp4_2 =", value, "mp42");
            return (Criteria) this;
        }

        public Criteria andMp42NotEqualTo(String value) {
            addCriterion("mp4_2 <>", value, "mp42");
            return (Criteria) this;
        }

        public Criteria andMp42GreaterThan(String value) {
            addCriterion("mp4_2 >", value, "mp42");
            return (Criteria) this;
        }

        public Criteria andMp42GreaterThanOrEqualTo(String value) {
            addCriterion("mp4_2 >=", value, "mp42");
            return (Criteria) this;
        }

        public Criteria andMp42LessThan(String value) {
            addCriterion("mp4_2 <", value, "mp42");
            return (Criteria) this;
        }

        public Criteria andMp42LessThanOrEqualTo(String value) {
            addCriterion("mp4_2 <=", value, "mp42");
            return (Criteria) this;
        }

        public Criteria andMp42Like(String value) {
            addCriterion("mp4_2 like", value, "mp42");
            return (Criteria) this;
        }

        public Criteria andMp42NotLike(String value) {
            addCriterion("mp4_2 not like", value, "mp42");
            return (Criteria) this;
        }

        public Criteria andMp42In(List<String> values) {
            addCriterion("mp4_2 in", values, "mp42");
            return (Criteria) this;
        }

        public Criteria andMp42NotIn(List<String> values) {
            addCriterion("mp4_2 not in", values, "mp42");
            return (Criteria) this;
        }

        public Criteria andMp42Between(String value1, String value2) {
            addCriterion("mp4_2 between", value1, value2, "mp42");
            return (Criteria) this;
        }

        public Criteria andMp42NotBetween(String value1, String value2) {
            addCriterion("mp4_2 not between", value1, value2, "mp42");
            return (Criteria) this;
        }

        public Criteria andMp43IsNull() {
            addCriterion("mp4_3 is null");
            return (Criteria) this;
        }

        public Criteria andMp43IsNotNull() {
            addCriterion("mp4_3 is not null");
            return (Criteria) this;
        }

        public Criteria andMp43EqualTo(String value) {
            addCriterion("mp4_3 =", value, "mp43");
            return (Criteria) this;
        }

        public Criteria andMp43NotEqualTo(String value) {
            addCriterion("mp4_3 <>", value, "mp43");
            return (Criteria) this;
        }

        public Criteria andMp43GreaterThan(String value) {
            addCriterion("mp4_3 >", value, "mp43");
            return (Criteria) this;
        }

        public Criteria andMp43GreaterThanOrEqualTo(String value) {
            addCriterion("mp4_3 >=", value, "mp43");
            return (Criteria) this;
        }

        public Criteria andMp43LessThan(String value) {
            addCriterion("mp4_3 <", value, "mp43");
            return (Criteria) this;
        }

        public Criteria andMp43LessThanOrEqualTo(String value) {
            addCriterion("mp4_3 <=", value, "mp43");
            return (Criteria) this;
        }

        public Criteria andMp43Like(String value) {
            addCriterion("mp4_3 like", value, "mp43");
            return (Criteria) this;
        }

        public Criteria andMp43NotLike(String value) {
            addCriterion("mp4_3 not like", value, "mp43");
            return (Criteria) this;
        }

        public Criteria andMp43In(List<String> values) {
            addCriterion("mp4_3 in", values, "mp43");
            return (Criteria) this;
        }

        public Criteria andMp43NotIn(List<String> values) {
            addCriterion("mp4_3 not in", values, "mp43");
            return (Criteria) this;
        }

        public Criteria andMp43Between(String value1, String value2) {
            addCriterion("mp4_3 between", value1, value2, "mp43");
            return (Criteria) this;
        }

        public Criteria andMp43NotBetween(String value1, String value2) {
            addCriterion("mp4_3 not between", value1, value2, "mp43");
            return (Criteria) this;
        }

        public Criteria andHls1IsNull() {
            addCriterion("hls1 is null");
            return (Criteria) this;
        }

        public Criteria andHls1IsNotNull() {
            addCriterion("hls1 is not null");
            return (Criteria) this;
        }

        public Criteria andHls1EqualTo(String value) {
            addCriterion("hls1 =", value, "hls1");
            return (Criteria) this;
        }

        public Criteria andHls1NotEqualTo(String value) {
            addCriterion("hls1 <>", value, "hls1");
            return (Criteria) this;
        }

        public Criteria andHls1GreaterThan(String value) {
            addCriterion("hls1 >", value, "hls1");
            return (Criteria) this;
        }

        public Criteria andHls1GreaterThanOrEqualTo(String value) {
            addCriterion("hls1 >=", value, "hls1");
            return (Criteria) this;
        }

        public Criteria andHls1LessThan(String value) {
            addCriterion("hls1 <", value, "hls1");
            return (Criteria) this;
        }

        public Criteria andHls1LessThanOrEqualTo(String value) {
            addCriterion("hls1 <=", value, "hls1");
            return (Criteria) this;
        }

        public Criteria andHls1Like(String value) {
            addCriterion("hls1 like", value, "hls1");
            return (Criteria) this;
        }

        public Criteria andHls1NotLike(String value) {
            addCriterion("hls1 not like", value, "hls1");
            return (Criteria) this;
        }

        public Criteria andHls1In(List<String> values) {
            addCriterion("hls1 in", values, "hls1");
            return (Criteria) this;
        }

        public Criteria andHls1NotIn(List<String> values) {
            addCriterion("hls1 not in", values, "hls1");
            return (Criteria) this;
        }

        public Criteria andHls1Between(String value1, String value2) {
            addCriterion("hls1 between", value1, value2, "hls1");
            return (Criteria) this;
        }

        public Criteria andHls1NotBetween(String value1, String value2) {
            addCriterion("hls1 not between", value1, value2, "hls1");
            return (Criteria) this;
        }

        public Criteria andHls2IsNull() {
            addCriterion("hls2 is null");
            return (Criteria) this;
        }

        public Criteria andHls2IsNotNull() {
            addCriterion("hls2 is not null");
            return (Criteria) this;
        }

        public Criteria andHls2EqualTo(String value) {
            addCriterion("hls2 =", value, "hls2");
            return (Criteria) this;
        }

        public Criteria andHls2NotEqualTo(String value) {
            addCriterion("hls2 <>", value, "hls2");
            return (Criteria) this;
        }

        public Criteria andHls2GreaterThan(String value) {
            addCriterion("hls2 >", value, "hls2");
            return (Criteria) this;
        }

        public Criteria andHls2GreaterThanOrEqualTo(String value) {
            addCriterion("hls2 >=", value, "hls2");
            return (Criteria) this;
        }

        public Criteria andHls2LessThan(String value) {
            addCriterion("hls2 <", value, "hls2");
            return (Criteria) this;
        }

        public Criteria andHls2LessThanOrEqualTo(String value) {
            addCriterion("hls2 <=", value, "hls2");
            return (Criteria) this;
        }

        public Criteria andHls2Like(String value) {
            addCriterion("hls2 like", value, "hls2");
            return (Criteria) this;
        }

        public Criteria andHls2NotLike(String value) {
            addCriterion("hls2 not like", value, "hls2");
            return (Criteria) this;
        }

        public Criteria andHls2In(List<String> values) {
            addCriterion("hls2 in", values, "hls2");
            return (Criteria) this;
        }

        public Criteria andHls2NotIn(List<String> values) {
            addCriterion("hls2 not in", values, "hls2");
            return (Criteria) this;
        }

        public Criteria andHls2Between(String value1, String value2) {
            addCriterion("hls2 between", value1, value2, "hls2");
            return (Criteria) this;
        }

        public Criteria andHls2NotBetween(String value1, String value2) {
            addCriterion("hls2 not between", value1, value2, "hls2");
            return (Criteria) this;
        }

        public Criteria andHls3IsNull() {
            addCriterion("hls3 is null");
            return (Criteria) this;
        }

        public Criteria andHls3IsNotNull() {
            addCriterion("hls3 is not null");
            return (Criteria) this;
        }

        public Criteria andHls3EqualTo(String value) {
            addCriterion("hls3 =", value, "hls3");
            return (Criteria) this;
        }

        public Criteria andHls3NotEqualTo(String value) {
            addCriterion("hls3 <>", value, "hls3");
            return (Criteria) this;
        }

        public Criteria andHls3GreaterThan(String value) {
            addCriterion("hls3 >", value, "hls3");
            return (Criteria) this;
        }

        public Criteria andHls3GreaterThanOrEqualTo(String value) {
            addCriterion("hls3 >=", value, "hls3");
            return (Criteria) this;
        }

        public Criteria andHls3LessThan(String value) {
            addCriterion("hls3 <", value, "hls3");
            return (Criteria) this;
        }

        public Criteria andHls3LessThanOrEqualTo(String value) {
            addCriterion("hls3 <=", value, "hls3");
            return (Criteria) this;
        }

        public Criteria andHls3Like(String value) {
            addCriterion("hls3 like", value, "hls3");
            return (Criteria) this;
        }

        public Criteria andHls3NotLike(String value) {
            addCriterion("hls3 not like", value, "hls3");
            return (Criteria) this;
        }

        public Criteria andHls3In(List<String> values) {
            addCriterion("hls3 in", values, "hls3");
            return (Criteria) this;
        }

        public Criteria andHls3NotIn(List<String> values) {
            addCriterion("hls3 not in", values, "hls3");
            return (Criteria) this;
        }

        public Criteria andHls3Between(String value1, String value2) {
            addCriterion("hls3 between", value1, value2, "hls3");
            return (Criteria) this;
        }

        public Criteria andHls3NotBetween(String value1, String value2) {
            addCriterion("hls3 not between", value1, value2, "hls3");
            return (Criteria) this;
        }

        public Criteria andHlsindexIsNull() {
            addCriterion("hlsIndex is null");
            return (Criteria) this;
        }

        public Criteria andHlsindexIsNotNull() {
            addCriterion("hlsIndex is not null");
            return (Criteria) this;
        }

        public Criteria andHlsindexEqualTo(String value) {
            addCriterion("hlsIndex =", value, "hlsindex");
            return (Criteria) this;
        }

        public Criteria andHlsindexNotEqualTo(String value) {
            addCriterion("hlsIndex <>", value, "hlsindex");
            return (Criteria) this;
        }

        public Criteria andHlsindexGreaterThan(String value) {
            addCriterion("hlsIndex >", value, "hlsindex");
            return (Criteria) this;
        }

        public Criteria andHlsindexGreaterThanOrEqualTo(String value) {
            addCriterion("hlsIndex >=", value, "hlsindex");
            return (Criteria) this;
        }

        public Criteria andHlsindexLessThan(String value) {
            addCriterion("hlsIndex <", value, "hlsindex");
            return (Criteria) this;
        }

        public Criteria andHlsindexLessThanOrEqualTo(String value) {
            addCriterion("hlsIndex <=", value, "hlsindex");
            return (Criteria) this;
        }

        public Criteria andHlsindexLike(String value) {
            addCriterion("hlsIndex like", value, "hlsindex");
            return (Criteria) this;
        }

        public Criteria andHlsindexNotLike(String value) {
            addCriterion("hlsIndex not like", value, "hlsindex");
            return (Criteria) this;
        }

        public Criteria andHlsindexIn(List<String> values) {
            addCriterion("hlsIndex in", values, "hlsindex");
            return (Criteria) this;
        }

        public Criteria andHlsindexNotIn(List<String> values) {
            addCriterion("hlsIndex not in", values, "hlsindex");
            return (Criteria) this;
        }

        public Criteria andHlsindexBetween(String value1, String value2) {
            addCriterion("hlsIndex between", value1, value2, "hlsindex");
            return (Criteria) this;
        }

        public Criteria andHlsindexNotBetween(String value1, String value2) {
            addCriterion("hlsIndex not between", value1, value2, "hlsindex");
            return (Criteria) this;
        }

        public Criteria andSeedIsNull() {
            addCriterion("seed is null");
            return (Criteria) this;
        }

        public Criteria andSeedIsNotNull() {
            addCriterion("seed is not null");
            return (Criteria) this;
        }

        public Criteria andSeedEqualTo(Byte value) {
            addCriterion("seed =", value, "seed");
            return (Criteria) this;
        }

        public Criteria andSeedNotEqualTo(Byte value) {
            addCriterion("seed <>", value, "seed");
            return (Criteria) this;
        }

        public Criteria andSeedGreaterThan(Byte value) {
            addCriterion("seed >", value, "seed");
            return (Criteria) this;
        }

        public Criteria andSeedGreaterThanOrEqualTo(Byte value) {
            addCriterion("seed >=", value, "seed");
            return (Criteria) this;
        }

        public Criteria andSeedLessThan(Byte value) {
            addCriterion("seed <", value, "seed");
            return (Criteria) this;
        }

        public Criteria andSeedLessThanOrEqualTo(Byte value) {
            addCriterion("seed <=", value, "seed");
            return (Criteria) this;
        }

        public Criteria andSeedIn(List<Byte> values) {
            addCriterion("seed in", values, "seed");
            return (Criteria) this;
        }

        public Criteria andSeedNotIn(List<Byte> values) {
            addCriterion("seed not in", values, "seed");
            return (Criteria) this;
        }

        public Criteria andSeedBetween(Byte value1, Byte value2) {
            addCriterion("seed between", value1, value2, "seed");
            return (Criteria) this;
        }

        public Criteria andSeedNotBetween(Byte value1, Byte value2) {
            addCriterion("seed not between", value1, value2, "seed");
            return (Criteria) this;
        }

        public Criteria andStatusIsNull() {
            addCriterion("status is null");
            return (Criteria) this;
        }

        public Criteria andStatusIsNotNull() {
            addCriterion("status is not null");
            return (Criteria) this;
        }

        public Criteria andStatusEqualTo(String value) {
            addCriterion("status =", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotEqualTo(String value) {
            addCriterion("status <>", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusGreaterThan(String value) {
            addCriterion("status >", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusGreaterThanOrEqualTo(String value) {
            addCriterion("status >=", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusLessThan(String value) {
            addCriterion("status <", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusLessThanOrEqualTo(String value) {
            addCriterion("status <=", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusLike(String value) {
            addCriterion("status like", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotLike(String value) {
            addCriterion("status not like", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusIn(List<String> values) {
            addCriterion("status in", values, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotIn(List<String> values) {
            addCriterion("status not in", values, "status");
            return (Criteria) this;
        }

        public Criteria andStatusBetween(String value1, String value2) {
            addCriterion("status between", value1, value2, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotBetween(String value1, String value2) {
            addCriterion("status not between", value1, value2, "status");
            return (Criteria) this;
        }

        public Criteria andSourceFilesizeIsNull() {
            addCriterion("source_filesize is null");
            return (Criteria) this;
        }

        public Criteria andSourceFilesizeIsNotNull() {
            addCriterion("source_filesize is not null");
            return (Criteria) this;
        }

        public Criteria andSourceFilesizeEqualTo(Integer value) {
            addCriterion("source_filesize =", value, "sourceFilesize");
            return (Criteria) this;
        }

        public Criteria andSourceFilesizeNotEqualTo(Integer value) {
            addCriterion("source_filesize <>", value, "sourceFilesize");
            return (Criteria) this;
        }

        public Criteria andSourceFilesizeGreaterThan(Integer value) {
            addCriterion("source_filesize >", value, "sourceFilesize");
            return (Criteria) this;
        }

        public Criteria andSourceFilesizeGreaterThanOrEqualTo(Integer value) {
            addCriterion("source_filesize >=", value, "sourceFilesize");
            return (Criteria) this;
        }

        public Criteria andSourceFilesizeLessThan(Integer value) {
            addCriterion("source_filesize <", value, "sourceFilesize");
            return (Criteria) this;
        }

        public Criteria andSourceFilesizeLessThanOrEqualTo(Integer value) {
            addCriterion("source_filesize <=", value, "sourceFilesize");
            return (Criteria) this;
        }

        public Criteria andSourceFilesizeIn(List<Integer> values) {
            addCriterion("source_filesize in", values, "sourceFilesize");
            return (Criteria) this;
        }

        public Criteria andSourceFilesizeNotIn(List<Integer> values) {
            addCriterion("source_filesize not in", values, "sourceFilesize");
            return (Criteria) this;
        }

        public Criteria andSourceFilesizeBetween(Integer value1, Integer value2) {
            addCriterion("source_filesize between", value1, value2, "sourceFilesize");
            return (Criteria) this;
        }

        public Criteria andSourceFilesizeNotBetween(Integer value1, Integer value2) {
            addCriterion("source_filesize not between", value1, value2, "sourceFilesize");
            return (Criteria) this;
        }

        public Criteria andMd5checksumIsNull() {
            addCriterion("md5checksum is null");
            return (Criteria) this;
        }

        public Criteria andMd5checksumIsNotNull() {
            addCriterion("md5checksum is not null");
            return (Criteria) this;
        }

        public Criteria andMd5checksumEqualTo(String value) {
            addCriterion("md5checksum =", value, "md5checksum");
            return (Criteria) this;
        }

        public Criteria andMd5checksumNotEqualTo(String value) {
            addCriterion("md5checksum <>", value, "md5checksum");
            return (Criteria) this;
        }

        public Criteria andMd5checksumGreaterThan(String value) {
            addCriterion("md5checksum >", value, "md5checksum");
            return (Criteria) this;
        }

        public Criteria andMd5checksumGreaterThanOrEqualTo(String value) {
            addCriterion("md5checksum >=", value, "md5checksum");
            return (Criteria) this;
        }

        public Criteria andMd5checksumLessThan(String value) {
            addCriterion("md5checksum <", value, "md5checksum");
            return (Criteria) this;
        }

        public Criteria andMd5checksumLessThanOrEqualTo(String value) {
            addCriterion("md5checksum <=", value, "md5checksum");
            return (Criteria) this;
        }

        public Criteria andMd5checksumLike(String value) {
            addCriterion("md5checksum like", value, "md5checksum");
            return (Criteria) this;
        }

        public Criteria andMd5checksumNotLike(String value) {
            addCriterion("md5checksum not like", value, "md5checksum");
            return (Criteria) this;
        }

        public Criteria andMd5checksumIn(List<String> values) {
            addCriterion("md5checksum in", values, "md5checksum");
            return (Criteria) this;
        }

        public Criteria andMd5checksumNotIn(List<String> values) {
            addCriterion("md5checksum not in", values, "md5checksum");
            return (Criteria) this;
        }

        public Criteria andMd5checksumBetween(String value1, String value2) {
            addCriterion("md5checksum between", value1, value2, "md5checksum");
            return (Criteria) this;
        }

        public Criteria andMd5checksumNotBetween(String value1, String value2) {
            addCriterion("md5checksum not between", value1, value2, "md5checksum");
            return (Criteria) this;
        }

        public Criteria andImages1IsNull() {
            addCriterion("images1 is null");
            return (Criteria) this;
        }

        public Criteria andImages1IsNotNull() {
            addCriterion("images1 is not null");
            return (Criteria) this;
        }

        public Criteria andImages1EqualTo(String value) {
            addCriterion("images1 =", value, "images1");
            return (Criteria) this;
        }

        public Criteria andImages1NotEqualTo(String value) {
            addCriterion("images1 <>", value, "images1");
            return (Criteria) this;
        }

        public Criteria andImages1GreaterThan(String value) {
            addCriterion("images1 >", value, "images1");
            return (Criteria) this;
        }

        public Criteria andImages1GreaterThanOrEqualTo(String value) {
            addCriterion("images1 >=", value, "images1");
            return (Criteria) this;
        }

        public Criteria andImages1LessThan(String value) {
            addCriterion("images1 <", value, "images1");
            return (Criteria) this;
        }

        public Criteria andImages1LessThanOrEqualTo(String value) {
            addCriterion("images1 <=", value, "images1");
            return (Criteria) this;
        }

        public Criteria andImages1Like(String value) {
            addCriterion("images1 like", value, "images1");
            return (Criteria) this;
        }

        public Criteria andImages1NotLike(String value) {
            addCriterion("images1 not like", value, "images1");
            return (Criteria) this;
        }

        public Criteria andImages1In(List<String> values) {
            addCriterion("images1 in", values, "images1");
            return (Criteria) this;
        }

        public Criteria andImages1NotIn(List<String> values) {
            addCriterion("images1 not in", values, "images1");
            return (Criteria) this;
        }

        public Criteria andImages1Between(String value1, String value2) {
            addCriterion("images1 between", value1, value2, "images1");
            return (Criteria) this;
        }

        public Criteria andImages1NotBetween(String value1, String value2) {
            addCriterion("images1 not between", value1, value2, "images1");
            return (Criteria) this;
        }

        public Criteria andImages2IsNull() {
            addCriterion("images2 is null");
            return (Criteria) this;
        }

        public Criteria andImages2IsNotNull() {
            addCriterion("images2 is not null");
            return (Criteria) this;
        }

        public Criteria andImages2EqualTo(String value) {
            addCriterion("images2 =", value, "images2");
            return (Criteria) this;
        }

        public Criteria andImages2NotEqualTo(String value) {
            addCriterion("images2 <>", value, "images2");
            return (Criteria) this;
        }

        public Criteria andImages2GreaterThan(String value) {
            addCriterion("images2 >", value, "images2");
            return (Criteria) this;
        }

        public Criteria andImages2GreaterThanOrEqualTo(String value) {
            addCriterion("images2 >=", value, "images2");
            return (Criteria) this;
        }

        public Criteria andImages2LessThan(String value) {
            addCriterion("images2 <", value, "images2");
            return (Criteria) this;
        }

        public Criteria andImages2LessThanOrEqualTo(String value) {
            addCriterion("images2 <=", value, "images2");
            return (Criteria) this;
        }

        public Criteria andImages2Like(String value) {
            addCriterion("images2 like", value, "images2");
            return (Criteria) this;
        }

        public Criteria andImages2NotLike(String value) {
            addCriterion("images2 not like", value, "images2");
            return (Criteria) this;
        }

        public Criteria andImages2In(List<String> values) {
            addCriterion("images2 in", values, "images2");
            return (Criteria) this;
        }

        public Criteria andImages2NotIn(List<String> values) {
            addCriterion("images2 not in", values, "images2");
            return (Criteria) this;
        }

        public Criteria andImages2Between(String value1, String value2) {
            addCriterion("images2 between", value1, value2, "images2");
            return (Criteria) this;
        }

        public Criteria andImages2NotBetween(String value1, String value2) {
            addCriterion("images2 not between", value1, value2, "images2");
            return (Criteria) this;
        }

        public Criteria andImages3IsNull() {
            addCriterion("images3 is null");
            return (Criteria) this;
        }

        public Criteria andImages3IsNotNull() {
            addCriterion("images3 is not null");
            return (Criteria) this;
        }

        public Criteria andImages3EqualTo(String value) {
            addCriterion("images3 =", value, "images3");
            return (Criteria) this;
        }

        public Criteria andImages3NotEqualTo(String value) {
            addCriterion("images3 <>", value, "images3");
            return (Criteria) this;
        }

        public Criteria andImages3GreaterThan(String value) {
            addCriterion("images3 >", value, "images3");
            return (Criteria) this;
        }

        public Criteria andImages3GreaterThanOrEqualTo(String value) {
            addCriterion("images3 >=", value, "images3");
            return (Criteria) this;
        }

        public Criteria andImages3LessThan(String value) {
            addCriterion("images3 <", value, "images3");
            return (Criteria) this;
        }

        public Criteria andImages3LessThanOrEqualTo(String value) {
            addCriterion("images3 <=", value, "images3");
            return (Criteria) this;
        }

        public Criteria andImages3Like(String value) {
            addCriterion("images3 like", value, "images3");
            return (Criteria) this;
        }

        public Criteria andImages3NotLike(String value) {
            addCriterion("images3 not like", value, "images3");
            return (Criteria) this;
        }

        public Criteria andImages3In(List<String> values) {
            addCriterion("images3 in", values, "images3");
            return (Criteria) this;
        }

        public Criteria andImages3NotIn(List<String> values) {
            addCriterion("images3 not in", values, "images3");
            return (Criteria) this;
        }

        public Criteria andImages3Between(String value1, String value2) {
            addCriterion("images3 between", value1, value2, "images3");
            return (Criteria) this;
        }

        public Criteria andImages3NotBetween(String value1, String value2) {
            addCriterion("images3 not between", value1, value2, "images3");
            return (Criteria) this;
        }

        public Criteria andImages4IsNull() {
            addCriterion("images4 is null");
            return (Criteria) this;
        }

        public Criteria andImages4IsNotNull() {
            addCriterion("images4 is not null");
            return (Criteria) this;
        }

        public Criteria andImages4EqualTo(String value) {
            addCriterion("images4 =", value, "images4");
            return (Criteria) this;
        }

        public Criteria andImages4NotEqualTo(String value) {
            addCriterion("images4 <>", value, "images4");
            return (Criteria) this;
        }

        public Criteria andImages4GreaterThan(String value) {
            addCriterion("images4 >", value, "images4");
            return (Criteria) this;
        }

        public Criteria andImages4GreaterThanOrEqualTo(String value) {
            addCriterion("images4 >=", value, "images4");
            return (Criteria) this;
        }

        public Criteria andImages4LessThan(String value) {
            addCriterion("images4 <", value, "images4");
            return (Criteria) this;
        }

        public Criteria andImages4LessThanOrEqualTo(String value) {
            addCriterion("images4 <=", value, "images4");
            return (Criteria) this;
        }

        public Criteria andImages4Like(String value) {
            addCriterion("images4 like", value, "images4");
            return (Criteria) this;
        }

        public Criteria andImages4NotLike(String value) {
            addCriterion("images4 not like", value, "images4");
            return (Criteria) this;
        }

        public Criteria andImages4In(List<String> values) {
            addCriterion("images4 in", values, "images4");
            return (Criteria) this;
        }

        public Criteria andImages4NotIn(List<String> values) {
            addCriterion("images4 not in", values, "images4");
            return (Criteria) this;
        }

        public Criteria andImages4Between(String value1, String value2) {
            addCriterion("images4 between", value1, value2, "images4");
            return (Criteria) this;
        }

        public Criteria andImages4NotBetween(String value1, String value2) {
            addCriterion("images4 not between", value1, value2, "images4");
            return (Criteria) this;
        }

        public Criteria andImages5IsNull() {
            addCriterion("images5 is null");
            return (Criteria) this;
        }

        public Criteria andImages5IsNotNull() {
            addCriterion("images5 is not null");
            return (Criteria) this;
        }

        public Criteria andImages5EqualTo(String value) {
            addCriterion("images5 =", value, "images5");
            return (Criteria) this;
        }

        public Criteria andImages5NotEqualTo(String value) {
            addCriterion("images5 <>", value, "images5");
            return (Criteria) this;
        }

        public Criteria andImages5GreaterThan(String value) {
            addCriterion("images5 >", value, "images5");
            return (Criteria) this;
        }

        public Criteria andImages5GreaterThanOrEqualTo(String value) {
            addCriterion("images5 >=", value, "images5");
            return (Criteria) this;
        }

        public Criteria andImages5LessThan(String value) {
            addCriterion("images5 <", value, "images5");
            return (Criteria) this;
        }

        public Criteria andImages5LessThanOrEqualTo(String value) {
            addCriterion("images5 <=", value, "images5");
            return (Criteria) this;
        }

        public Criteria andImages5Like(String value) {
            addCriterion("images5 like", value, "images5");
            return (Criteria) this;
        }

        public Criteria andImages5NotLike(String value) {
            addCriterion("images5 not like", value, "images5");
            return (Criteria) this;
        }

        public Criteria andImages5In(List<String> values) {
            addCriterion("images5 in", values, "images5");
            return (Criteria) this;
        }

        public Criteria andImages5NotIn(List<String> values) {
            addCriterion("images5 not in", values, "images5");
            return (Criteria) this;
        }

        public Criteria andImages5Between(String value1, String value2) {
            addCriterion("images5 between", value1, value2, "images5");
            return (Criteria) this;
        }

        public Criteria andImages5NotBetween(String value1, String value2) {
            addCriterion("images5 not between", value1, value2, "images5");
            return (Criteria) this;
        }

        public Criteria andImages6IsNull() {
            addCriterion("images6 is null");
            return (Criteria) this;
        }

        public Criteria andImages6IsNotNull() {
            addCriterion("images6 is not null");
            return (Criteria) this;
        }

        public Criteria andImages6EqualTo(String value) {
            addCriterion("images6 =", value, "images6");
            return (Criteria) this;
        }

        public Criteria andImages6NotEqualTo(String value) {
            addCriterion("images6 <>", value, "images6");
            return (Criteria) this;
        }

        public Criteria andImages6GreaterThan(String value) {
            addCriterion("images6 >", value, "images6");
            return (Criteria) this;
        }

        public Criteria andImages6GreaterThanOrEqualTo(String value) {
            addCriterion("images6 >=", value, "images6");
            return (Criteria) this;
        }

        public Criteria andImages6LessThan(String value) {
            addCriterion("images6 <", value, "images6");
            return (Criteria) this;
        }

        public Criteria andImages6LessThanOrEqualTo(String value) {
            addCriterion("images6 <=", value, "images6");
            return (Criteria) this;
        }

        public Criteria andImages6Like(String value) {
            addCriterion("images6 like", value, "images6");
            return (Criteria) this;
        }

        public Criteria andImages6NotLike(String value) {
            addCriterion("images6 not like", value, "images6");
            return (Criteria) this;
        }

        public Criteria andImages6In(List<String> values) {
            addCriterion("images6 in", values, "images6");
            return (Criteria) this;
        }

        public Criteria andImages6NotIn(List<String> values) {
            addCriterion("images6 not in", values, "images6");
            return (Criteria) this;
        }

        public Criteria andImages6Between(String value1, String value2) {
            addCriterion("images6 between", value1, value2, "images6");
            return (Criteria) this;
        }

        public Criteria andImages6NotBetween(String value1, String value2) {
            addCriterion("images6 not between", value1, value2, "images6");
            return (Criteria) this;
        }

        public Criteria andImagesB1IsNull() {
            addCriterion("images_b1 is null");
            return (Criteria) this;
        }

        public Criteria andImagesB1IsNotNull() {
            addCriterion("images_b1 is not null");
            return (Criteria) this;
        }

        public Criteria andImagesB1EqualTo(String value) {
            addCriterion("images_b1 =", value, "imagesB1");
            return (Criteria) this;
        }

        public Criteria andImagesB1NotEqualTo(String value) {
            addCriterion("images_b1 <>", value, "imagesB1");
            return (Criteria) this;
        }

        public Criteria andImagesB1GreaterThan(String value) {
            addCriterion("images_b1 >", value, "imagesB1");
            return (Criteria) this;
        }

        public Criteria andImagesB1GreaterThanOrEqualTo(String value) {
            addCriterion("images_b1 >=", value, "imagesB1");
            return (Criteria) this;
        }

        public Criteria andImagesB1LessThan(String value) {
            addCriterion("images_b1 <", value, "imagesB1");
            return (Criteria) this;
        }

        public Criteria andImagesB1LessThanOrEqualTo(String value) {
            addCriterion("images_b1 <=", value, "imagesB1");
            return (Criteria) this;
        }

        public Criteria andImagesB1Like(String value) {
            addCriterion("images_b1 like", value, "imagesB1");
            return (Criteria) this;
        }

        public Criteria andImagesB1NotLike(String value) {
            addCriterion("images_b1 not like", value, "imagesB1");
            return (Criteria) this;
        }

        public Criteria andImagesB1In(List<String> values) {
            addCriterion("images_b1 in", values, "imagesB1");
            return (Criteria) this;
        }

        public Criteria andImagesB1NotIn(List<String> values) {
            addCriterion("images_b1 not in", values, "imagesB1");
            return (Criteria) this;
        }

        public Criteria andImagesB1Between(String value1, String value2) {
            addCriterion("images_b1 between", value1, value2, "imagesB1");
            return (Criteria) this;
        }

        public Criteria andImagesB1NotBetween(String value1, String value2) {
            addCriterion("images_b1 not between", value1, value2, "imagesB1");
            return (Criteria) this;
        }

        public Criteria andImagesB2IsNull() {
            addCriterion("images_b2 is null");
            return (Criteria) this;
        }

        public Criteria andImagesB2IsNotNull() {
            addCriterion("images_b2 is not null");
            return (Criteria) this;
        }

        public Criteria andImagesB2EqualTo(String value) {
            addCriterion("images_b2 =", value, "imagesB2");
            return (Criteria) this;
        }

        public Criteria andImagesB2NotEqualTo(String value) {
            addCriterion("images_b2 <>", value, "imagesB2");
            return (Criteria) this;
        }

        public Criteria andImagesB2GreaterThan(String value) {
            addCriterion("images_b2 >", value, "imagesB2");
            return (Criteria) this;
        }

        public Criteria andImagesB2GreaterThanOrEqualTo(String value) {
            addCriterion("images_b2 >=", value, "imagesB2");
            return (Criteria) this;
        }

        public Criteria andImagesB2LessThan(String value) {
            addCriterion("images_b2 <", value, "imagesB2");
            return (Criteria) this;
        }

        public Criteria andImagesB2LessThanOrEqualTo(String value) {
            addCriterion("images_b2 <=", value, "imagesB2");
            return (Criteria) this;
        }

        public Criteria andImagesB2Like(String value) {
            addCriterion("images_b2 like", value, "imagesB2");
            return (Criteria) this;
        }

        public Criteria andImagesB2NotLike(String value) {
            addCriterion("images_b2 not like", value, "imagesB2");
            return (Criteria) this;
        }

        public Criteria andImagesB2In(List<String> values) {
            addCriterion("images_b2 in", values, "imagesB2");
            return (Criteria) this;
        }

        public Criteria andImagesB2NotIn(List<String> values) {
            addCriterion("images_b2 not in", values, "imagesB2");
            return (Criteria) this;
        }

        public Criteria andImagesB2Between(String value1, String value2) {
            addCriterion("images_b2 between", value1, value2, "imagesB2");
            return (Criteria) this;
        }

        public Criteria andImagesB2NotBetween(String value1, String value2) {
            addCriterion("images_b2 not between", value1, value2, "imagesB2");
            return (Criteria) this;
        }

        public Criteria andImagesB3IsNull() {
            addCriterion("images_b3 is null");
            return (Criteria) this;
        }

        public Criteria andImagesB3IsNotNull() {
            addCriterion("images_b3 is not null");
            return (Criteria) this;
        }

        public Criteria andImagesB3EqualTo(String value) {
            addCriterion("images_b3 =", value, "imagesB3");
            return (Criteria) this;
        }

        public Criteria andImagesB3NotEqualTo(String value) {
            addCriterion("images_b3 <>", value, "imagesB3");
            return (Criteria) this;
        }

        public Criteria andImagesB3GreaterThan(String value) {
            addCriterion("images_b3 >", value, "imagesB3");
            return (Criteria) this;
        }

        public Criteria andImagesB3GreaterThanOrEqualTo(String value) {
            addCriterion("images_b3 >=", value, "imagesB3");
            return (Criteria) this;
        }

        public Criteria andImagesB3LessThan(String value) {
            addCriterion("images_b3 <", value, "imagesB3");
            return (Criteria) this;
        }

        public Criteria andImagesB3LessThanOrEqualTo(String value) {
            addCriterion("images_b3 <=", value, "imagesB3");
            return (Criteria) this;
        }

        public Criteria andImagesB3Like(String value) {
            addCriterion("images_b3 like", value, "imagesB3");
            return (Criteria) this;
        }

        public Criteria andImagesB3NotLike(String value) {
            addCriterion("images_b3 not like", value, "imagesB3");
            return (Criteria) this;
        }

        public Criteria andImagesB3In(List<String> values) {
            addCriterion("images_b3 in", values, "imagesB3");
            return (Criteria) this;
        }

        public Criteria andImagesB3NotIn(List<String> values) {
            addCriterion("images_b3 not in", values, "imagesB3");
            return (Criteria) this;
        }

        public Criteria andImagesB3Between(String value1, String value2) {
            addCriterion("images_b3 between", value1, value2, "imagesB3");
            return (Criteria) this;
        }

        public Criteria andImagesB3NotBetween(String value1, String value2) {
            addCriterion("images_b3 not between", value1, value2, "imagesB3");
            return (Criteria) this;
        }

        public Criteria andImagesB4IsNull() {
            addCriterion("images_b4 is null");
            return (Criteria) this;
        }

        public Criteria andImagesB4IsNotNull() {
            addCriterion("images_b4 is not null");
            return (Criteria) this;
        }

        public Criteria andImagesB4EqualTo(String value) {
            addCriterion("images_b4 =", value, "imagesB4");
            return (Criteria) this;
        }

        public Criteria andImagesB4NotEqualTo(String value) {
            addCriterion("images_b4 <>", value, "imagesB4");
            return (Criteria) this;
        }

        public Criteria andImagesB4GreaterThan(String value) {
            addCriterion("images_b4 >", value, "imagesB4");
            return (Criteria) this;
        }

        public Criteria andImagesB4GreaterThanOrEqualTo(String value) {
            addCriterion("images_b4 >=", value, "imagesB4");
            return (Criteria) this;
        }

        public Criteria andImagesB4LessThan(String value) {
            addCriterion("images_b4 <", value, "imagesB4");
            return (Criteria) this;
        }

        public Criteria andImagesB4LessThanOrEqualTo(String value) {
            addCriterion("images_b4 <=", value, "imagesB4");
            return (Criteria) this;
        }

        public Criteria andImagesB4Like(String value) {
            addCriterion("images_b4 like", value, "imagesB4");
            return (Criteria) this;
        }

        public Criteria andImagesB4NotLike(String value) {
            addCriterion("images_b4 not like", value, "imagesB4");
            return (Criteria) this;
        }

        public Criteria andImagesB4In(List<String> values) {
            addCriterion("images_b4 in", values, "imagesB4");
            return (Criteria) this;
        }

        public Criteria andImagesB4NotIn(List<String> values) {
            addCriterion("images_b4 not in", values, "imagesB4");
            return (Criteria) this;
        }

        public Criteria andImagesB4Between(String value1, String value2) {
            addCriterion("images_b4 between", value1, value2, "imagesB4");
            return (Criteria) this;
        }

        public Criteria andImagesB4NotBetween(String value1, String value2) {
            addCriterion("images_b4 not between", value1, value2, "imagesB4");
            return (Criteria) this;
        }

        public Criteria andImagesB5IsNull() {
            addCriterion("images_b5 is null");
            return (Criteria) this;
        }

        public Criteria andImagesB5IsNotNull() {
            addCriterion("images_b5 is not null");
            return (Criteria) this;
        }

        public Criteria andImagesB5EqualTo(String value) {
            addCriterion("images_b5 =", value, "imagesB5");
            return (Criteria) this;
        }

        public Criteria andImagesB5NotEqualTo(String value) {
            addCriterion("images_b5 <>", value, "imagesB5");
            return (Criteria) this;
        }

        public Criteria andImagesB5GreaterThan(String value) {
            addCriterion("images_b5 >", value, "imagesB5");
            return (Criteria) this;
        }

        public Criteria andImagesB5GreaterThanOrEqualTo(String value) {
            addCriterion("images_b5 >=", value, "imagesB5");
            return (Criteria) this;
        }

        public Criteria andImagesB5LessThan(String value) {
            addCriterion("images_b5 <", value, "imagesB5");
            return (Criteria) this;
        }

        public Criteria andImagesB5LessThanOrEqualTo(String value) {
            addCriterion("images_b5 <=", value, "imagesB5");
            return (Criteria) this;
        }

        public Criteria andImagesB5Like(String value) {
            addCriterion("images_b5 like", value, "imagesB5");
            return (Criteria) this;
        }

        public Criteria andImagesB5NotLike(String value) {
            addCriterion("images_b5 not like", value, "imagesB5");
            return (Criteria) this;
        }

        public Criteria andImagesB5In(List<String> values) {
            addCriterion("images_b5 in", values, "imagesB5");
            return (Criteria) this;
        }

        public Criteria andImagesB5NotIn(List<String> values) {
            addCriterion("images_b5 not in", values, "imagesB5");
            return (Criteria) this;
        }

        public Criteria andImagesB5Between(String value1, String value2) {
            addCriterion("images_b5 between", value1, value2, "imagesB5");
            return (Criteria) this;
        }

        public Criteria andImagesB5NotBetween(String value1, String value2) {
            addCriterion("images_b5 not between", value1, value2, "imagesB5");
            return (Criteria) this;
        }

        public Criteria andImagesB6IsNull() {
            addCriterion("images_b6 is null");
            return (Criteria) this;
        }

        public Criteria andImagesB6IsNotNull() {
            addCriterion("images_b6 is not null");
            return (Criteria) this;
        }

        public Criteria andImagesB6EqualTo(String value) {
            addCriterion("images_b6 =", value, "imagesB6");
            return (Criteria) this;
        }

        public Criteria andImagesB6NotEqualTo(String value) {
            addCriterion("images_b6 <>", value, "imagesB6");
            return (Criteria) this;
        }

        public Criteria andImagesB6GreaterThan(String value) {
            addCriterion("images_b6 >", value, "imagesB6");
            return (Criteria) this;
        }

        public Criteria andImagesB6GreaterThanOrEqualTo(String value) {
            addCriterion("images_b6 >=", value, "imagesB6");
            return (Criteria) this;
        }

        public Criteria andImagesB6LessThan(String value) {
            addCriterion("images_b6 <", value, "imagesB6");
            return (Criteria) this;
        }

        public Criteria andImagesB6LessThanOrEqualTo(String value) {
            addCriterion("images_b6 <=", value, "imagesB6");
            return (Criteria) this;
        }

        public Criteria andImagesB6Like(String value) {
            addCriterion("images_b6 like", value, "imagesB6");
            return (Criteria) this;
        }

        public Criteria andImagesB6NotLike(String value) {
            addCriterion("images_b6 not like", value, "imagesB6");
            return (Criteria) this;
        }

        public Criteria andImagesB6In(List<String> values) {
            addCriterion("images_b6 in", values, "imagesB6");
            return (Criteria) this;
        }

        public Criteria andImagesB6NotIn(List<String> values) {
            addCriterion("images_b6 not in", values, "imagesB6");
            return (Criteria) this;
        }

        public Criteria andImagesB6Between(String value1, String value2) {
            addCriterion("images_b6 between", value1, value2, "imagesB6");
            return (Criteria) this;
        }

        public Criteria andImagesB6NotBetween(String value1, String value2) {
            addCriterion("images_b6 not between", value1, value2, "imagesB6");
            return (Criteria) this;
        }

        public Criteria andCreateByIsNull() {
            addCriterion("create_by is null");
            return (Criteria) this;
        }

        public Criteria andCreateByIsNotNull() {
            addCriterion("create_by is not null");
            return (Criteria) this;
        }

        public Criteria andCreateByEqualTo(Integer value) {
            addCriterion("create_by =", value, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByNotEqualTo(Integer value) {
            addCriterion("create_by <>", value, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByGreaterThan(Integer value) {
            addCriterion("create_by >", value, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByGreaterThanOrEqualTo(Integer value) {
            addCriterion("create_by >=", value, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByLessThan(Integer value) {
            addCriterion("create_by <", value, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByLessThanOrEqualTo(Integer value) {
            addCriterion("create_by <=", value, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByIn(List<Integer> values) {
            addCriterion("create_by in", values, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByNotIn(List<Integer> values) {
            addCriterion("create_by not in", values, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByBetween(Integer value1, Integer value2) {
            addCriterion("create_by between", value1, value2, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByNotBetween(Integer value1, Integer value2) {
            addCriterion("create_by not between", value1, value2, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNull() {
            addCriterion("create_time is null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNotNull() {
            addCriterion("create_time is not null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeEqualTo(Date value) {
            addCriterion("create_time =", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotEqualTo(Date value) {
            addCriterion("create_time <>", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThan(Date value) {
            addCriterion("create_time >", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("create_time >=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThan(Date value) {
            addCriterion("create_time <", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThanOrEqualTo(Date value) {
            addCriterion("create_time <=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIn(List<Date> values) {
            addCriterion("create_time in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotIn(List<Date> values) {
            addCriterion("create_time not in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeBetween(Date value1, Date value2) {
            addCriterion("create_time between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotBetween(Date value1, Date value2) {
            addCriterion("create_time not between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andUpdateByIsNull() {
            addCriterion("update_by is null");
            return (Criteria) this;
        }

        public Criteria andUpdateByIsNotNull() {
            addCriterion("update_by is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateByEqualTo(Integer value) {
            addCriterion("update_by =", value, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByNotEqualTo(Integer value) {
            addCriterion("update_by <>", value, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByGreaterThan(Integer value) {
            addCriterion("update_by >", value, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByGreaterThanOrEqualTo(Integer value) {
            addCriterion("update_by >=", value, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByLessThan(Integer value) {
            addCriterion("update_by <", value, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByLessThanOrEqualTo(Integer value) {
            addCriterion("update_by <=", value, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByIn(List<Integer> values) {
            addCriterion("update_by in", values, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByNotIn(List<Integer> values) {
            addCriterion("update_by not in", values, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByBetween(Integer value1, Integer value2) {
            addCriterion("update_by between", value1, value2, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByNotBetween(Integer value1, Integer value2) {
            addCriterion("update_by not between", value1, value2, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNull() {
            addCriterion("update_time is null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNotNull() {
            addCriterion("update_time is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeEqualTo(Date value) {
            addCriterion("update_time =", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotEqualTo(Date value) {
            addCriterion("update_time <>", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThan(Date value) {
            addCriterion("update_time >", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("update_time >=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThan(Date value) {
            addCriterion("update_time <", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThanOrEqualTo(Date value) {
            addCriterion("update_time <=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIn(List<Date> values) {
            addCriterion("update_time in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotIn(List<Date> values) {
            addCriterion("update_time not in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeBetween(Date value1, Date value2) {
            addCriterion("update_time between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotBetween(Date value1, Date value2) {
            addCriterion("update_time not between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andIsdeleteIsNull() {
            addCriterion("isdelete is null");
            return (Criteria) this;
        }

        public Criteria andIsdeleteIsNotNull() {
            addCriterion("isdelete is not null");
            return (Criteria) this;
        }

        public Criteria andIsdeleteEqualTo(Byte value) {
            addCriterion("isdelete =", value, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteNotEqualTo(Byte value) {
            addCriterion("isdelete <>", value, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteGreaterThan(Byte value) {
            addCriterion("isdelete >", value, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteGreaterThanOrEqualTo(Byte value) {
            addCriterion("isdelete >=", value, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteLessThan(Byte value) {
            addCriterion("isdelete <", value, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteLessThanOrEqualTo(Byte value) {
            addCriterion("isdelete <=", value, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteIn(List<Byte> values) {
            addCriterion("isdelete in", values, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteNotIn(List<Byte> values) {
            addCriterion("isdelete not in", values, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteBetween(Byte value1, Byte value2) {
            addCriterion("isdelete between", value1, value2, "isdelete");
            return (Criteria) this;
        }

        public Criteria andIsdeleteNotBetween(Byte value1, Byte value2) {
            addCriterion("isdelete not between", value1, value2, "isdelete");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}