package com.ruida.common.util.excel;

import com.ruida.common.SystemConstant;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
public @interface ExcelAnnotation {

	// excel导出时标题显示的名字，如果没有设置Annotation属性，将不会被导出和导入
	public String title();
    // 是否必填
	public boolean require() default false;
    // 保留几位小数，-1时不做处理，仅对BigDecimal类型生效
    public int scale() default -1;
    // 日期格式化字符串，仅对Date类型生效
    public String dateFormat() default SystemConstant.DATE_FORMAT;
    // 导出时的排序
    public int order() default 0;

}

