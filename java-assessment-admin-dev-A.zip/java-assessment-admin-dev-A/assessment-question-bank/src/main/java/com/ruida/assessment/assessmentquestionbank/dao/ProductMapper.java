package com.ruida.assessment.assessmentquestionbank.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.assessment.assessmentquestionbank.dto.ProductQueryRequest;
import com.ruida.assessment.assessmentquestionbank.model.TProduct;
import com.ruida.assessment.assessmentquestionbank.vo.PresellTestPaperVo;
import com.ruida.assessment.assessmentquestionbank.vo.ProductInfoVo;
import com.ruida.assessment.assessmentquestionbank.vo.ProductListVo;
import com.ruida.assessment.assessmentquestionbank.vo.ProductVO;
import org.apache.ibatis.annotations.Param;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * @author wy
 * @description 商品管理mapper
 * @date 2020/6/24
 */
@Mapper
public interface ProductMapper extends BaseMapper<TProduct> {

    List<ProductVO> getFinishProductList(@Param("testWay") Integer testWay);

    /*
     *功能描述
     * @param 查询商品列表
     * @return
     */
    List<ProductListVo> queryProductList(@Param("vo") ProductQueryRequest req);

    /*
     *功能描述
     * @param 查询商品列表（科目选考推荐商品）
     * @return
     */
    List<ProductListVo> queryRecommendProductList(@Param("vo") ProductQueryRequest req);
    /*
     *功能描述
     * @param  查询商品列表总数
     * @return
     */
    Integer queryProductCount(@Param("vo") ProductQueryRequest req);
    /*
     *功能描述
     * @param  查询商品列表总数(科目选考推荐商品)
     * @return
     */
    Integer queryRecommendProductCount(@Param("vo") ProductQueryRequest req);


    /**
     * 获取购买了某个商品的学员id
     *
     * @param productIdList
     * @return
     */
    List<Integer> getStudentIdByProduct(@Param("productIdList") List<Integer> productIdList);


    /*
     *功能描述 查询商品详情信息
     * @param
     * @return
     */
    ProductInfoVo queryProductInfo(@Param("productId") Integer productId);
}
