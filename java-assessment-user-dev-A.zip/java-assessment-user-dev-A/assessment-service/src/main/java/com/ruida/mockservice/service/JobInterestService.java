package com.ruida.mockservice.service;


import com.ruida.mockdao.vo.jobInterest.JobInterestBuyInfoVO;

/**
 * @author xumingqi
 * @date 2021/2/5 16:30
 */
public interface JobInterestService {
    JobInterestBuyInfoVO getBuyInfoVO(Integer source);
}
