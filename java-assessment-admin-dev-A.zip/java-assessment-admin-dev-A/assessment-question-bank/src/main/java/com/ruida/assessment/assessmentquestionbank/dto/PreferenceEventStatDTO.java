package com.ruida.assessment.assessmentquestionbank.dto;

import lombok.Data;

@Data
public class PreferenceEventStatDTO extends QueryBaseDTO {
    private Integer source;//来源（0-pc 1-iOS 2-Android）
    private String searchWord;//搜索关键词
    private Integer showAll;//展示所有

}
