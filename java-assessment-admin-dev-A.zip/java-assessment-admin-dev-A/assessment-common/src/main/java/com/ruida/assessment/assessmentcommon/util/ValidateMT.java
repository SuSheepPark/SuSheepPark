package com.ruida.assessment.assessmentcommon.util;

import java.util.Collection;
import java.util.Map;

public class ValidateMT {
	public static boolean isNotNull(Object obj){
		
		if(obj instanceof String){
			if(obj == null || ((String)obj).length() == 0){
				return false;
			}
			return true;
		}
		else if(obj instanceof Collection<?>){
			if(obj == null || ((Collection<?>)obj).size() == 0){
				return false;
			}
			return true;
		}else if(obj instanceof Map<?,?>){
			if(obj == null || ((Map<?,?>)obj).isEmpty()){
				return false;
			}
			return true;
		}
		else{
			return obj != null;
		}
	}
	
	public static boolean isNull(Object obj){
		return !isNotNull(obj);
	}
	
	public static String rejectNull(String str){
		 return isNotNull(str) ? str : "";
	}

	public static String rejectNull(String str,String def){
		 return isNotNull(str) ? str : def;
	}
}
