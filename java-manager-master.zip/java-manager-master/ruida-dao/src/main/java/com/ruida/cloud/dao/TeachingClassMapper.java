package com.ruida.cloud.dao;

import com.ruida.cloud.model.TeachingClass;
import com.ruida.cloud.model.TeachingClassExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface TeachingClassMapper {
    long countByExample(TeachingClassExample example);

    int deleteByExample(TeachingClassExample example);

    int deleteByPrimaryKey(Integer teachingClassId);

    int insert(TeachingClass record);

    int insertSelective(TeachingClass record);

    List<TeachingClass> selectByExample(TeachingClassExample example);

    TeachingClass selectByPrimaryKey(Integer teachingClassId);

    int updateByExampleSelective(@Param("record") TeachingClass record, @Param("example") TeachingClassExample example);

    int updateByExample(@Param("record") TeachingClass record, @Param("example") TeachingClassExample example);

    int updateByPrimaryKeySelective(TeachingClass record);

    int updateByPrimaryKey(TeachingClass record);
}