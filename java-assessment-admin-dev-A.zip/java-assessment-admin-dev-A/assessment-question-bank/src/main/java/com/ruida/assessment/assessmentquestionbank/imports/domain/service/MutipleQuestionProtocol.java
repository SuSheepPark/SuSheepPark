package com.ruida.assessment.assessmentquestionbank.imports.domain.service;

import com.ruida.assessment.assessmentquestionbank.imports.application.QuestionProtocolFactory;
import com.ruida.assessment.assessmentquestionbank.imports.docx.DocxReader;
import com.ruida.assessment.assessmentquestionbank.imports.docx.DocxService;
import com.ruida.assessment.assessmentquestionbank.imports.domain.model.ErrorMsgException;
import com.ruida.assessment.assessmentquestionbank.imports.domain.model.QuestionBlock;
import com.ruida.assessment.assessmentquestionbank.imports.domain.model.QuestionBaseConfig;
import com.ruida.assessment.assessmentquestionbank.imports.domain.model.QuestionContent;

public class MutipleQuestionProtocol extends QuestionProtocol {

	public MutipleQuestionProtocol(DocxReader reader) {
		super(reader);
	}

	@Override
	public Boolean checkIdentification() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected QuestionContent getContent() throws ErrorMsgException{
		QuestionContent content = new QuestionContent();

		content.setContent(getContentString());
		String lineString;
		int number=1;
		do {
			reader.stepTo(BLOCK_START, QUESTION_START);
			QuestionBaseConfig config = QuestionProtocol.getQuestionBlockConfig(reader);
			QuestionProtocolFactory questionProtocolFactory = QuestionProtocolFactory.getFactory();
			QuestionProtocol protocol = questionProtocolFactory.getQuestionProtocol(reader, config.getQuestionType());
			QuestionBlock block = protocol.parseBlock(config);
			block.setBlockConfig(config);
			block.setNumber(number);
			content.addBlock(block);
			number++;
			lineString=DocxService.getLineText(reader.getLine());
		} while (!lineString.startsWith(QUESTION_START)&&reader.hasNext());
		return content;
	}

	@Override
	protected String formatAnswerItem(String lineString) {
		byte[] bytes = lineString.getBytes();
		if (bytes.length == 1) {
			if (bytes[0] > 64 && bytes[0] < 91) {
			} else if (bytes[0] > 96 && bytes[0] < 123) {
				bytes[0] = (byte) (bytes[0] - 32);
			}
		}
		return new String(bytes);
	}

	@Override
	public QuestionBlock parseBlock(QuestionBaseConfig config) throws ErrorMsgException {
		reader.stepTo(CONTENT_START, QUESTION_START);
		QuestionBlock block = new QuestionBlock();

		QuestionContent content = getContent();
		block.setContent(content);

		return block;
	}
}
