package com.ruida.mockservice.service;

import com.baomidou.mybatisplus.service.IService;
import com.ruida.mockcommon.result.MapResult;
import com.ruida.mockcommon.result.PojoResult;
import com.ruida.mockdao.dto.UserInfoDTO;
import com.ruida.mockdao.model.Student;
import com.ruida.mockdao.vo.StudentInfoVO;

/**
 * <p>
 * 学生信息表（包括学生和游客） 服务类
 * </p>
 *
 * @author Bhj
 * @since 2020-07-09
 */
public interface StudentService extends IService<Student> {

    MapResult getStudentInfo();

    StudentInfoVO getStudentInfoVO(Integer userId);

    Student getStudent(Integer userId);

    boolean updateStudentInfo(String headImg, String nickname);

    //boolean updateStudentAllInfo(String realName, String headImg, String stuNo, Integer sex, String nickname, String idCard, Integer periodId, Integer stageId, Integer classId, Integer schoolId);

    PojoResult<UserInfoDTO> getStudentInfoNew();
}
