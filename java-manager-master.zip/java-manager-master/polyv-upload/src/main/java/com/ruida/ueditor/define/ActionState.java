package com.ruida.ueditor.define;

public enum ActionState {
	UNKNOW_ERROR
}
