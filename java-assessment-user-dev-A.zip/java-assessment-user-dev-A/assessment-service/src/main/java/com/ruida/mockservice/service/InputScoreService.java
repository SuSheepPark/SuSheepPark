package com.ruida.mockservice.service;

import com.baomidou.mybatisplus.service.IService;
import com.ruida.mockdao.model.InputScore;
import com.ruida.mockdao.vo.report.InputScoreVO;

import java.util.List;

/**
 * <p>
 * 科目选考-手动输入成绩表 服务类
 * </p>
 *
 * @author chenjy
 * @since 2021-01-18
 */
public interface InputScoreService extends IService<InputScore> {

    boolean saveInputScore(List<InputScore> list);

    List<InputScoreVO> getPastScore(Integer userId);

}
