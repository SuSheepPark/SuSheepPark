package com.ruida.cloud.model;

import java.io.Serializable;
import java.util.Date;

/**
 * @author taosh
 * @create 2019-05-15 11:31
 */
public class CourseLessonVdyoo implements Serializable {
    //课次id
    private Integer courseLessonId;
    //课次名称
    private String courseLessonName;
    //主讲老师id
    private Integer teacherId;
    //开始时间
    private Date startDate;

    private Date endDate;

    private Date lessonStartDate;

    private String lessonStartTime;

    private String lessonEndTime;

    private String startTime;

    private String endTime;

    //课程id
    private Integer courseId;
    //直播间id
    private Integer studioId;
    //时间段id
    private Integer timeSlotId;
    //班级类型id
    private Integer classTypeId;
    //学期id
    private Integer tenantTermId;
    //年级类型
    private String gradeType;

    public Date getLessonStartDate() {
        return lessonStartDate;
    }

    public void setLessonStartDate(Date lessonStartDate) {
        this.lessonStartDate = lessonStartDate;
    }

    public String getLessonStartTime() {
        return lessonStartTime;
    }

    public void setLessonStartTime(String lessonStartTime) {
        this.lessonStartTime = lessonStartTime;
    }

    public String getLessonEndTime() {
        return lessonEndTime;
    }

    public void setLessonEndTime(String lessonEndTime) {
        this.lessonEndTime = lessonEndTime;
    }

    public Integer getCourseLessonId() {
        return courseLessonId;
    }

    public void setCourseLessonId(Integer courseLessonId) {
        this.courseLessonId = courseLessonId;
    }

    public String getCourseLessonName() {
        return courseLessonName;
    }

    public void setCourseLessonName(String courseLessonName) {
        this.courseLessonName = courseLessonName;
    }

    public Integer getTeacherId() {
        return teacherId;
    }

    public void setTeacherId(Integer teacherId) {
        this.teacherId = teacherId;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public Integer getCourseId() {
        return courseId;
    }

    public void setCourseId(Integer courseId) {
        this.courseId = courseId;
    }

    public Integer getStudioId() {
        return studioId;
    }

    public void setStudioId(Integer studioId) {
        this.studioId = studioId;
    }

    public Integer getTimeSlotId() {
        return timeSlotId;
    }

    public void setTimeSlotId(Integer timeSlotId) {
        this.timeSlotId = timeSlotId;
    }

    public Integer getClassTypeId() {
        return classTypeId;
    }

    public void setClassTypeId(Integer classTypeId) {
        this.classTypeId = classTypeId;
    }

    public Integer getTenantTermId() {
        return tenantTermId;
    }

    public void setTenantTermId(Integer tenantTermId) {
        this.tenantTermId = tenantTermId;
    }

    public String getGradeType() {
        return gradeType;
    }

    public void setGradeType(String gradeType) {
        this.gradeType = gradeType;
    }
}
