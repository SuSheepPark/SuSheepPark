package com.ruida.cloud.dao;

import com.ruida.cloud.model.CourseGensee;
import com.ruida.cloud.model.CourseGenseeExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface CourseGenseeMapper {
    int countByExample(CourseGenseeExample example);

    int deleteByExample(CourseGenseeExample example);

    int deleteByPrimaryKey(Integer courseGenseeId);

    int insert(CourseGensee record);

    int insertSelective(CourseGensee record);

    List<CourseGensee> selectByExample(CourseGenseeExample example);

    CourseGensee selectByPrimaryKey(Integer courseGenseeId);

    int updateByExampleSelective(@Param("record") CourseGensee record, @Param("example") CourseGenseeExample example);

    int updateByExample(@Param("record") CourseGensee record, @Param("example") CourseGenseeExample example);

    int updateByPrimaryKeySelective(CourseGensee record);

    int updateByPrimaryKey(CourseGensee record);

    /**
     * 根据id批量删除
     */
    int deleteGenseBatch(List<Integer> list);

    /**
     * 根据课程获取展示互动roomId
     */
    List<String> listRoomIdsByCourseId(Integer courseId);

}