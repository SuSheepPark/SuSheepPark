package com.ruida.mockservice.service;


import com.ruida.mockdao.model.Areainfo;

import java.util.List;

/**
 * 地区操作服务
 */
public interface AreaInfoService {

    /**
     * 获取省份数据列表
     *
     * @return
     */
    public List<Areainfo> listProvince() ;

    /**
     * 获取地区信息列表
     *
     * @param province
     * @return
     */
    public List<Areainfo> listCityByProvince(Integer province);

    /**
     * 获取区信息列表
     *
     * @param city
     * @return
     */
    public List<Areainfo> listDistrictByCity(Integer city) ;


}
