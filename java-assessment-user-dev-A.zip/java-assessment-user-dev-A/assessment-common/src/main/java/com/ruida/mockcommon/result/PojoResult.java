package com.ruida.mockcommon.result;

/**
 * @description:
 * @author szl
 * @Date 2018年12月10日
 * @verion 1.0
 */
public class PojoResult<T> extends BaseResult {

	private static final long serialVersionUID = -3798855953342189365L;

	private T content;

	public T getContent() {
		return content;
	}

	public void setContent(T content) {
		this.content = content;
	}

}
