package com.ruida.mockservice.service.impl;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.ruida.mockcommon.auth.context.BaseContextHandle;
import com.ruida.mockcommon.auth.pojo.JWTInfo;
import com.ruida.mockcommon.enums.AppErrorEnum;
import com.ruida.mockcommon.exception.CoreException;
import com.ruida.mockcommon.result.Page;
import com.ruida.mockcommon.result.PageData;
import com.ruida.mockcommon.util.ValidateMT;
import com.ruida.mockdao.dao.CollectProductRelMapper;
import com.ruida.mockdao.dto.ProductQueryRequest;
import com.ruida.mockdao.model.CollectProductRel;
import com.ruida.mockdao.model.Product;
import com.ruida.mockdao.vo.ProductCollectVO;
import com.ruida.mockdao.vo.ProductNewVO;
import com.ruida.mockdao.vo.ProductVO;
import com.ruida.mockservice.service.CollectProductRelService;
import com.ruida.mockservice.service.ProductService;
import com.ruida.mockservice.service.StageService;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.List;

/**
 * <p>
 * 用户收藏商品关联表 服务实现类
 * </p>
 *
 * @author jinhu
 * @since 2020-07-08
 */
@Service
public class CollectProductRelServiceImpl extends ServiceImpl<CollectProductRelMapper, CollectProductRel> implements CollectProductRelService {

    @Resource
    ProductService productService;
    @Resource
    StageService stageService;

    @Override
    public ProductCollectVO collectProduct(Integer productId) {

        JWTInfo jwt = BaseContextHandle.getJWTInfo();
        if (jwt == null) {
            throw new CoreException(AppErrorEnum.E_10018);
        }
        if (null == productId) {
            throw new CoreException(AppErrorEnum.E_10024);
        }

        EntityWrapper entityWrapper = new EntityWrapper();
        entityWrapper.eq("product_id",productId);
        Product product = productService.selectOne(entityWrapper);
        if(!product.getStatus().equals(1)){
            throw new CoreException(AppErrorEnum.E_40011);
        }

        String userId = BaseContextHandle.getUserID();

        List<CollectProductRel> collectProductRels = selectList(new EntityWrapper<CollectProductRel>()
                .eq("user_id",userId)
                .eq("product_id",productId));

        //收藏
        if(CollectionUtils.isEmpty(collectProductRels)){
            CollectProductRel collectProductRel = new CollectProductRel();
            collectProductRel.setIsdelete(0);
            collectProductRel.setUserId(Integer.valueOf(userId));
            collectProductRel.setProductId(productId);
            collectProductRel.setCreateBy(Integer.valueOf(userId));
            collectProductRel.setCreateTime(LocalDateTime.now());
            collectProductRel.setUpdateBy(Integer.valueOf(userId));
            collectProductRel.setUpdateTime(LocalDateTime.now());
            boolean ret = insert(collectProductRel);
            if(ret){
                ProductCollectVO productCollectVO = new ProductCollectVO();
                productCollectVO.setProductId(productId);
                productCollectVO.setIsCollect(1);
                return productCollectVO;
            }else{
                throw new CoreException(AppErrorEnum.E_30004);
            }
        }

        //取消收藏
        boolean ret = delete(new EntityWrapper<CollectProductRel>()
                .eq("user_id",userId)
                .eq("product_id",productId));

        if(!ret){
            throw new CoreException(AppErrorEnum.E_30003);
        }else{
            ProductCollectVO productCollectVO = new ProductCollectVO();
            productCollectVO.setProductId(productId);
            productCollectVO.setIsCollect(0);
            return productCollectVO;
        }
    }

    @Override
    public PageData<ProductVO> queryProductCollectList(ProductQueryRequest req) {
        JWTInfo jwt = BaseContextHandle.getJWTInfo();
        if (jwt == null) {
            throw new CoreException(AppErrorEnum.E_10018);
        }

        PageData<ProductVO> result = new PageData<>();
        Page page = req.getPage();
        if (ValidateMT.isNotNull(page)) {
            req.setStart(page.getOffset());
            req.setSize(page.getPageSize());
        }
        Integer[] statusArray = {0, 1};
        req.setProductStatusArray(statusArray);
        //req.setStatus(1);
        req.setUserId(jwt.getUserId());
        List<ProductVO> productListVos = this.baseMapper.queryProductCollectList(req);

        if (ValidateMT.isNotNull(page)) {
            Integer total = this.baseMapper.queryProductCollectCount(req);
            page.setTotalCount(total);
            result.setTotal(total);
            result.setCurrentPage(page.getCurrentPage());
            result.setPageSize(page.getPageSize());
            result.setTotalPage(page.getTotalPage());
        }
        result.setRows(productListVos);
        return result;


    }

    @Override
    public boolean removeCollectBatch(List<String> productIds) {

        if(CollectionUtils.isEmpty(productIds)){
            return false;
        }
        JWTInfo jwt = BaseContextHandle.getJWTInfo();
        if (jwt == null) {
            throw new CoreException(AppErrorEnum.E_10018);
        }

        return delete(new EntityWrapper<CollectProductRel>().eq("user_id",jwt.getUserId())
                .in("product_id",productIds));
    }

    @Override
    public PageData<ProductNewVO> queryProductCollectListNew(ProductQueryRequest req) {
        JWTInfo jwt = BaseContextHandle.getJWTInfo();
        if (jwt == null) {
            throw new CoreException(AppErrorEnum.E_10018);
        }

        PageData<ProductNewVO> result = new PageData<>();
        Page page = req.getPage();
        if (ValidateMT.isNotNull(page)) {
            req.setStart(page.getOffset());
            req.setSize(page.getPageSize());
        }
        Integer[] statusArray = {0, 1};
        req.setProductStatusArray(statusArray);
        //req.setStatus(1);
        req.setUserId(jwt.getUserId());
        List<ProductNewVO> productListVos = this.baseMapper.queryProductCollectListNew(req);

        if (ValidateMT.isNotNull(page)) {
            Integer total = this.baseMapper.queryProductCollectCountNew(req);
            page.setTotalCount(total);
            result.setTotal(total);
            result.setCurrentPage(page.getCurrentPage());
            result.setPageSize(page.getPageSize());
            result.setTotalPage(page.getTotalPage());
        }
        result.setRows(productListVos);
        return result;

    }
}
