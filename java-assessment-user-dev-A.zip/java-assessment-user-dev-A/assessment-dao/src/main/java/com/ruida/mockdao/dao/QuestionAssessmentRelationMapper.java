package com.ruida.mockdao.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.model.QuestionAssessmentRelation;

/**
 * <p>
 * 题目-考察要求关联表 Mapper 接口
 * </p>
 *
 * @author chenjy
 * @since 2021-03-04
 */
public interface QuestionAssessmentRelationMapper extends BaseMapper<QuestionAssessmentRelation> {

}
