package com.ruida.assessment.assessmentcommon.enums;

import java.util.Arrays;
import java.util.List;

/**
 * @description: 订单类型枚举
 * @author: kgz
 * @date: 2021/2/7
 */
public enum OrderTypeEnum {
    TEST_PAPER(0, "试卷"),
    WISH_FILLING_REPORT(8, "志愿填报推荐报告");

    private Integer K;
    private String V;

    OrderTypeEnum(Integer k, String v) {
        this.K = k;
        this.V = v;
    }

    public Integer getK() {
        return K;
    }

    public void setK(Integer k) {
        K = k;
    }

    public String getV() {
        return V;
    }

    public void setV(String v) {
        V = v;
    }

    public static OrderTypeEnum getValueById(Integer K) {
        //旧的报告类型
        List<Integer> oldType = Arrays.asList(1, 2, 3, 4, 5, 6, 7);
        for (OrderTypeEnum orderTypeEnum : OrderTypeEnum.values()) {
            if (orderTypeEnum.getK().equals(K)) {
                return orderTypeEnum;
            } else if (oldType.contains(K)) {
                return OrderTypeEnum.TEST_PAPER;
            }
        }
        return null;
    }
}
