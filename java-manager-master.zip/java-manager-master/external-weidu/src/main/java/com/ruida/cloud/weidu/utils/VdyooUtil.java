package com.ruida.cloud.weidu.utils;

import java.util.HashMap;
import java.util.Map;

/**
 * @author taosh
 * @create 2019-04-23 14:58
 */
public class VdyooUtil {
    private static String vdyooAppkey = PropertyUtil.getProperty("vdyooAppkey");
    private static String vdyooTenantkey = PropertyUtil.getProperty("vdyooTenantkey");
    private static String vdyooAppsecret = PropertyUtil.getProperty("vdyooAppsecret");
    private static String vdyooV = PropertyUtil.getProperty("vdyooV");

    public static Map<String, String> getSignMap(){
        long timestamp = System.currentTimeMillis();
        String data = "appkey="+vdyooAppkey+"&tenantkey="+vdyooTenantkey+"&timestamp="+timestamp;
        System.out.println(data+"  =====data");
        String sign = HMAC_SHA1.genHMAC(data, vdyooAppsecret);

        Map<String, String> info = new HashMap<>(5);
        info.put("tenantkey", vdyooTenantkey);
        info.put("appkey", vdyooAppkey);
        info.put("sign", sign);
        info.put("timestamp", ""+timestamp);
        info.put("v", vdyooV);
        return info;
    }

    public static void main(String[] args) {
        System.out.println(getSignMap());
    }
}
