package com.ruida.mockcommon.constant;

public class RedisConstant {

	public static final String DEFAULT_PASSWORD = "123456";

	public static final String HOT_PRODUCT_LIST = "assess:product:hotProduct";

	public static final String NEW_PRODUCT_LIST = "assess:product:newProduct";

	public static final String COLLEGE_PREFERENCE_REPORT_KEY = "college_preference_report_id:";

	public static final String CREATE_ORDER_RATE_REDIS_KEY = "order:createOrder:%s:%s";
	public static final String GET_FREE_PAPER_RATE_REDIS_KEY = "order:getFreePaper:%s:%s";

	public static final String SELF_CHECK_SUBMIT_REDIS_KEY = "exam:selfCheckSubmit:%s";
	public static final String EXAM_SUBMIT_REDIS_KEY = "exam:examSubmit:%s";
	// exam:saveQuestion:{userId}
	public static final String EXAM_SAVE_QUESTION_REDIS_KEY = "exam:saveQuestion:%s";

	// rotation_chart:{locationType}:{source}
	public static final String ROTATION_CHART_LIST_KEY = "rotation_chart:%s:%s";

	// assessment:exam_module:examRecordId:{examRecordId}
	public static final String EXAM_RECORD_KEY = "assessment:exam_module:examRecordId:%s";
	// assessment:exam_module:getExamRecordID:{sceneId}-{stuId}
	public static final String GET_EXAM_RECORD_ID_KEY = "assessment:exam_module:getExamRecordID:%s-%s";

	public static final String INFORMATION_CONTENT_NEWEST = "information:newest:%s";

	public static final String RECOMMEND_PRODUCTS = "recommend:front_page_products";

	public static final String EXAM_TESTPAPER_BASE = "paperBaseInfo:testPaperVO:%s";
	public static final String EXAM_TESTPAPER_REL = "paperBaseInfo:TestPaperProductRel:product_%s:testPaper_%s";

	// assessment:exam_module:questionDetail:{questionId}
	public static final String QUESTION_DETAIL = "assessment:exam_module:questionDetail:%s";
}
