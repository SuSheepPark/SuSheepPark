package com.ruida.cloud.dao;

import com.ruida.cloud.model.TeacherRelInfo;
import com.ruida.cloud.model.TeacherRelInfoExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface TeacherRelInfoMapper {
    int countByExample(TeacherRelInfoExample example);

    int deleteByExample(TeacherRelInfoExample example);

    int deleteByPrimaryKey(Integer rid);

    int insert(TeacherRelInfo record);

    int insertSelective(TeacherRelInfo record);

    List<TeacherRelInfo> selectByExample(TeacherRelInfoExample example);

    TeacherRelInfo selectByPrimaryKey(Integer rid);

    int updateByExampleSelective(@Param("record") TeacherRelInfo record, @Param("example") TeacherRelInfoExample example);

    int updateByExample(@Param("record") TeacherRelInfo record, @Param("example") TeacherRelInfoExample example);

    int updateByPrimaryKeySelective(TeacherRelInfo record);

    int updateByPrimaryKey(TeacherRelInfo record);
}