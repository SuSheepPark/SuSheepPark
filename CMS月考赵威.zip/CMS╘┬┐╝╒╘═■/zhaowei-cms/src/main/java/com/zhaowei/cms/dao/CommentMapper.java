/**   
 * Copyright © 2019 公司名. All rights reserved.
 * 
 * @Title: ConmmentMapper.java 
 * @Prject: zhaowei-cms
 * @Package: com.zhaowei.cms.dao 
 * @Description: TODO
 * @author: zw   
 * @date: 2019年9月21日 下午8:40:13 
 * @version: V1.0   
 */
package com.zhaowei.cms.dao;

import java.util.List;

import com.zhaowei.cms.domain.Comment;

/** 
 * @ClassName: ConmmentMapper 
 * @Description: TODO
 * @author: zw
 * @date: 2019年9月21日 下午8:40:13  
 */
public interface CommentMapper {
	/**
	 * @Title: selects 
	 * @Description:查询文章列表
	 * @return
	 * @return: List<Comment>
	 */
	List<Comment> selects(Integer articleId);
	
	/**
	 * 
	 * @Title: insert 
	 * @Description:添加评论的方法
	 * @param comment
	 * @return
	 * @return: int
	 */
	int insert(Comment comment);

	/** 
	 * @Title: selectsByUserId 
	 * @Description: 
	 * @param userId
	 * @return
	 * @return: List<Comment>
	 */
	List<Comment> selectsByUserId(Integer userId);
}
