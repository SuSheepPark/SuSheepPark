package com.ruida.assessment.assessmentquestionbank.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.apache.commons.lang.StringUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @description: 试题查询条件DTO
 * @author: kgz
 * @date: 2020/6/16
 */
@ApiModel(description = "试题查询条件")
public class QuestionQueryDTO extends QueryBaseDTO{

    /**
     * 试题id正则表达式
     * 以“T”开头，后面只有12位且都是数字，如“T202006170001”，其他情况视为“试题内容”的查询条件
     */
    private static final String QUESTION_ID_REGEX = "^T(\\d{12})$";

    @ApiModelProperty(value = "是否过滤数据权限", name = "filterAuthData")
    private Integer filterAuthData;

    @ApiModelProperty(value = "用户id", name = "userId")
    private Integer userId;

    @ApiModelProperty(value = "关键字", name = "keyWords")
    private String keyWords;

    @ApiModelProperty(value = "试题id", name = "id")
    private String id;

    @ApiModelProperty(value = "试卷id", name = "id")
    private Integer testPaperId;

    @ApiModelProperty(value = "学段id", name = "periodId")
    private Integer periodId;

    @ApiModelProperty(value = "科目id", name = "subjectId")
    private Integer subjectId;

    @ApiModelProperty(value = "试题内容", name = "questionTile")
    private String questionTile;

    @ApiModelProperty(value = "模糊查询内容", name = "remark")
    private String searchWord;

    @ApiModelProperty(value = "试题类型id", name = "questionTypeId")
    private Integer questionTypeId;

    @ApiModelProperty(value = "难度等级id", name = "difficultyId")
    private Integer difficultyId;

    @ApiModelProperty(value = "创建时间-开始时间", name = "startTime")
    private String startTime;

    @ApiModelProperty(value = "创建时间-结束时间", name = "startTime")
    private String endTime;

    @ApiModelProperty(value = "章节id", name = "sectionIds")
    private List<Integer> sectionIds;

    @ApiModelProperty(value = "知识点id", name = "knowledgeIds")
    private List<Integer> knowledgeIds;

    @ApiModelProperty(value = "试题状态（1-草稿；2-提交（待审核）；3-已发布；4-取消发布）", name = "questionStatus")
    private String questionStatus;

    @ApiModelProperty(value = "学段id", name = "periodIds")
    private List<Integer> periodIds;

    @ApiModelProperty(value = "科目id", name = "subjectIds")
    private List<Integer> subjectIds;

    @ApiModelProperty(value = "试题来源id", name = "questionSourceId")
    private Integer questionSourceId;

    @ApiModelProperty(value = "试题用途id", name = "questionPurposeId")
    private Integer questionPurposeId;

    @ApiModelProperty(value = "保密等级id", name = "securityLevelId")
    private Integer securityLevelId;

    @ApiModelProperty(value = "考察要求id", name = "assessmentTargetId")
    private Integer assessmentTargetId;

    @ApiModelProperty(value = "批改方式（0—主观题；1—客观题）", name = "correctType")
    private Integer correctType;

    @ApiModelProperty(value = "是否支持拍照上传", name = "answerPhotographId")
    private Integer answerPhotographId;
    @ApiModelProperty(value = "是否细目表换题操作", name = "isdetailTableNext")
    private Integer isdetailTableNext;
    @ApiModelProperty(value = "需要排除的试题ids", name = "queIds")
    private List <String>  queIds;
    private Integer iscombine;
    @ApiModelProperty(value = "知识点id", name = "knowledgeIds")
    private String knowledges;
    @ApiModelProperty(value = "知识点id范围", name = "knowledgeRange")
    private String knowledgeRange;
    @ApiModelProperty(value = "试题用途ids", name = "questionPurposeIds")
    private String questionPurposeIds;

    public String getSearchWord() {
        return searchWord;
    }

    public void setSearchWord(String searchWord) {
        this.searchWord = searchWord;
    }

    public String getKeyWords() {
        return keyWords;
    }

    public void setKeyWords(String keyWords) {
        if(keyWords.matches(QUESTION_ID_REGEX)){
            this.setId(keyWords);
        }else{
            this.setSearchWord(keyWords);//题干或备注模糊查询内容
            this.setQuestionTile(keyWords);
        }
        this.keyWords = keyWords;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getQuestionTypeId() {
        return questionTypeId;
    }

    public void setQuestionTypeId(Integer questionTypeId) {
        this.questionTypeId = questionTypeId;
    }

    public Integer getDifficultyId() {
        return difficultyId;
    }

    public void setDifficultyId(Integer difficultyId) {
        this.difficultyId = difficultyId;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public List<Integer> getSectionIds() {
        return sectionIds;
    }

    public void setSectionIds(List<Integer> sectionIds) {
        this.sectionIds = sectionIds;
    }

    public List<Integer> getKnowledgeIds() {
        return knowledgeIds;
    }

    public void setKnowledgeIds(List<Integer> knowledgeIds) {
        this.knowledgeIds = knowledgeIds;
    }

    public String getQuestionStatus() {
        return questionStatus;
    }

    /**
     * 获取状态列表，支持多状态查询
     * @return
     */
    public List<Integer> getQuestionStatusList() {
        List<Integer> questionStatusList = new ArrayList<>();
        if(StringUtils.isNotEmpty(this.questionStatus)){
            List<String> arr = Arrays.asList(this.questionStatus.split(","));
            questionStatusList = arr.stream().map(u -> Integer.valueOf(u)).collect(Collectors.toList());
        }
        return questionStatusList;
    }

    public void setQuestionStatus(String questionStatus) {
        this.questionStatus = questionStatus;
    }

    public String getQuestionTile() {
        return questionTile;
    }

    public void setQuestionTile(String questionTile) {
        this.questionTile = questionTile;
    }

    public Integer getPeriodId() {
        return periodId;
    }

    public void setPeriodId(Integer periodId) {
        this.periodId = periodId;
    }

    public Integer getSubjectId() {
        return subjectId;
    }

    public void setSubjectId(Integer subjectId) {
        this.subjectId = subjectId;
    }

    public Integer getTestPaperId() {
        return testPaperId;
    }

    public void setTestPaperId(Integer testPaperId) {
        this.testPaperId = testPaperId;
    }

    public Integer getFilterAuthData() {
        return filterAuthData;
    }

    public void setFilterAuthData(Integer filterAuthData) {
        this.filterAuthData = filterAuthData;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public List<Integer> getPeriodIds() {
        return periodIds;
    }

    public void setPeriodIds(List<Integer> periodIds) {
        this.periodIds = periodIds;
    }

    public List<Integer> getSubjectIds() {
        return subjectIds;
    }

    public void setSubjectIds(List<Integer> subjectIds) {
        this.subjectIds = subjectIds;
    }

    public Integer getQuestionSourceId() {
        return questionSourceId;
    }

    public void setQuestionSourceId(Integer questionSourceId) {
        this.questionSourceId = questionSourceId;
    }

    public Integer getQuestionPurposeId() {
        return questionPurposeId;
    }

    public void setQuestionPurposeId(Integer questionPurposeId) {
        this.questionPurposeId = questionPurposeId;
    }

    public Integer getSecurityLevelId() {
        return securityLevelId;
    }

    public void setSecurityLevelId(Integer securityLevelId) {
        this.securityLevelId = securityLevelId;
    }

    public Integer getAssessmentTargetId() {
        return assessmentTargetId;
    }

    public void setAssessmentTargetId(Integer assessmentTargetId) {
        this.assessmentTargetId = assessmentTargetId;
    }

    public Integer getCorrectType() {
        return correctType;
    }

    public void setCorrectType(Integer correctType) {
        this.correctType = correctType;
    }

    public Integer getAnswerPhotographId() {
        return answerPhotographId;
    }

    public void setAnswerPhotographId(Integer answerPhotographId) {
        this.answerPhotographId = answerPhotographId;
    }

    public Integer getIsdetailTableNext() {
        return isdetailTableNext;
    }

    public void setIsdetailTableNext(Integer isdetailTableNext) {
        this.isdetailTableNext = isdetailTableNext;
    }

    public List<String> getQueIds() {
        return queIds;
    }

    public void setQueIds(List<String> queIds) {
        this.queIds = queIds;
    }

    public Integer getIscombine() {
        return iscombine;
    }

    public void setIscombine(Integer iscombine) {
        this.iscombine = iscombine;
    }

    public String getKnowledges() {
        return knowledges;
    }

    public void setKnowledges(String knowledges) {
        this.knowledges = knowledges;
    }

    public String getKnowledgeRange() {
        return knowledgeRange;
    }

    public void setKnowledgeRange(String knowledgeRange) {
        this.knowledgeRange = knowledgeRange;
    }

    public String getQuestionPurposeIds() {
        return questionPurposeIds;
    }

    public void setQuestionPurposeIds(String questionPurposeIds) {
        this.questionPurposeIds = questionPurposeIds;
    }

    @Override
    public String toString() {
        return "QuestionQueryDTO{" +
                "filterAuthData=" + filterAuthData +
                ", userId=" + userId +
                ", keyWords='" + keyWords + '\'' +
                ", id='" + id + '\'' +
                ", testPaperId=" + testPaperId +
                ", periodId=" + periodId +
                ", subjectId=" + subjectId +
                ", questionTile='" + questionTile + '\'' +
                ", questionTypeId=" + questionTypeId +
                ", difficultyId=" + difficultyId +
                ", startTime='" + startTime + '\'' +
                ", endTime='" + endTime + '\'' +
                ", sectionIds=" + sectionIds +
                ", knowledgeIds=" + knowledgeIds +
                ", questionStatus='" + questionStatus + '\'' +
                ", periodIds=" + periodIds +
                ", subjectIds=" + subjectIds +
                ", questionSourceId=" + questionSourceId +
                ", questionPurposeId=" + questionPurposeId +
                ", securityLevelId=" + securityLevelId +
                ", assessmentTargetId=" + assessmentTargetId +
                ", correctType=" + correctType +
                ", answerPhotographId=" + answerPhotographId +
                super.toString() +
                '}';
    }
}
