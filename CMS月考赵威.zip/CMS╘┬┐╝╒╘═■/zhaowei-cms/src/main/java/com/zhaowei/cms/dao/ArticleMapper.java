package com.zhaowei.cms.dao;

import java.util.List;

import org.springframework.web.bind.annotation.RequestParam;

import com.zhaowei.cms.domain.Article;

public interface ArticleMapper {
	/**
	 * 
	 * @Title: selectPre 
	 * @Description: s上一篇
	 * @param articled
	 * @return
	 * @return: Article
	 */
	Article selectPre(Article articled);
	/**
	 * @Title: selectNext 
	 * @Description:下一篇
	 * @param id
	 * @return
	 * @return: Article
	 */
	Article selectNext(Article articled);
	
	
	/**
	 * @Title: selects 
	 * @Description: 文章的列表查询
	 * @param article
	 * @return
	 * @return: List<Article>
	 */
	List<Article> selects(Article article);
	
    int deleteByPrimaryKey(Integer id);

    int insert(Article record);

    int insertSelective(Article record);
/**
 * 
 * @Title: selectByPrimaryKey 
 * @Description: 根据id查询单个文章
 * @param id
 * @return
 * @return: Article
 */
    Article selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(Article record);

    int updateByPrimaryKeyWithBLOBs(Article record);

    int updateByPrimaryKey(Article record);
	/** 
	 * @Title: selectsByComments 
	 * @Description: TODO
	 * @param article2
	 * @return
	 * @return: List<Article>
	 */
	List<Article> selectsByComments(Article article2);
	/** 
	 * @Title: selectsByClick 
	 * @Description: TODO
	 * @param article2
	 * @return
	 * @return: List<Article>
	 */
	List<Article> selectsByClick(Article article2);
	/** 
	 * @Title: updateByOnlyComments 
	 * @Description: TODO
	 * @param comments
	 * @param id 
	 * @return: void
	 */
	//boolean updateByOnlyComments(@RequestParam(defaultValue = "0")Integer comments,@RequestParam(defaultValue = "0")Integer id);
}