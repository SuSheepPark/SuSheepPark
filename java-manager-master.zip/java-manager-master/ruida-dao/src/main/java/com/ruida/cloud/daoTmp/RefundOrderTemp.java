package com.ruida.cloud.daoTmp;

import com.ruida.common.util.excel.ExcelAnnotation;
import lombok.Data;
import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @author taosh
 * @create 2020-05-04 15:08
 */
@Data
public class RefundOrderTemp implements Serializable {

    /**
     * 订单号
     */
    @ExcelAnnotation(title = "订单编号" ,order = 1)
    private String orderNo;

    /**
     * 购买账号
     */
    @ExcelAnnotation(title = "购买人姓名/账号" ,order = 2)
    private String purchaserName;

    /**
     * 购买id
     */
    private String purchaserId;

    /**
     * 课程名称
     */
    private String courseName;

    /**
     * 订单金额
     */
    private BigDecimal orderPrice;

    /**
     * 实付金额
     */
    private BigDecimal payPrice;

    /**
     * 课次数
     */
    private Integer lessonNum;

    /**
     * 已上课数
     */
    private Integer endLessonNum;

    /**
     * 销课金额
     */
    private BigDecimal endLessonPrice;

    /**
     * 剩余金额
     */
    private BigDecimal surplusPrice;

    /**
     * 管理费
     */
    private BigDecimal managePrice;

    /**
     * 订单优惠金额
     */
    private BigDecimal preferencePrice;

    /**
     * 实际退还金额
     */
    private BigDecimal refundablePrice;

    @Override
    public String toString() {
        return "RefundOrderTemp{" +
                "orderNo='" + orderNo + '\'' +
                ", purchaserName='" + purchaserName + '\'' +
                ", courseName='" + courseName + '\'' +
                ", orderPrice=" + orderPrice +
                ", payPrice=" + payPrice +
                ", lessonNum=" + lessonNum +
                ", endLessonNum=" + endLessonNum +
                ", endLessonPrice=" + endLessonPrice +
                ", surplusPrice=" + surplusPrice +
                ", managePrice=" + managePrice +
                ", preferencePrice=" + preferencePrice +
                ", refundablePrice=" + refundablePrice +
                '}';
    }
}
