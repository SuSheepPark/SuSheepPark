package com.ruida.assessment.assessmentquestionbank.controller.system;

import com.ruida.assessment.assessmentcommon.enums.OperateModuleEnum;
import com.ruida.assessment.assessmentcommon.enums.OperateTypeEnum;
import com.ruida.assessment.assessmentcommon.result.BoolAlertResult;
import com.ruida.assessment.assessmentcommon.result.MapResult;
import com.ruida.assessment.assessmentcommon.result.PojoResult;
import com.ruida.assessment.assessmentcommon.util.ValidateMT;
import com.ruida.assessment.assessmentquestionbank.annotaion.OperateLog;
import com.ruida.assessment.assessmentquestionbank.annotaion.UserAuth;
import com.ruida.assessment.assessmentquestionbank.model.SysRole;
import com.ruida.assessment.assessmentquestionbank.service.ruidaCloud.SysMenuService;
import com.ruida.assessment.assessmentquestionbank.service.ruidaCloud.SysRoleService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author admin
 * @description: 角色管理控制
 * @Date 2019/5/31
 * @verion 1.0
 */
@RestController
@RequestMapping("/sys")
public class RoleController {
    @Resource
    SysRoleService sysRoleService;
    @Resource
    SysMenuService sysMenuService;

    /**
     * * 获取所有角色
     * (searchWord 搜索关键词 status 类型 0禁用 1启用)
     *
     * @param searchWord
     * @param status
     * @return
     */
    @RequestMapping("/getAllRole")
    @ResponseBody
    @UserAuth
    public MapResult selectRoleList(String searchWord, Integer status, Integer pageNo, Integer pageSize) {
        MapResult result = new MapResult();
        if (ValidateMT.isNull(pageNo)) {
            pageNo = 1;
        }
        if (ValidateMT.isNull(pageSize)) {
            pageSize = 10;
        }
        Map<String, Object> param = new HashMap<>();
        param.put("searchWord", searchWord);
        param.put("status", status);
        param.put("pageNo", pageSize * (pageNo - 1));
        param.put("pageSize", pageSize);
        List<SysRole> list = sysRoleService.selectRoleList(param);
        Integer count = sysRoleService.selectRoleCount(param);
        Map<String, Object> resultMap = new HashMap<>();
        resultMap.put("rows", list);
        resultMap.put("pageNo", pageNo);
        resultMap.put("pageSize", pageSize);
        resultMap.put("total", count);
        result.setContent(resultMap);
        return result;
    }

    /**F
     * 获取角色信息
     *
     * @return
     */
    @RequestMapping("/getRoleInfo")
    @ResponseBody
    @UserAuth
    public PojoResult getRoleInfo(Integer roleId) {
        PojoResult pojoResult = new PojoResult();
        pojoResult.setContent(sysMenuService.getRoleInfo(roleId));
        return pojoResult;
    }

    /**
     * 编辑角色时所所需要的菜单树
     *
     * @return
     */
    @RequestMapping("/getMenuListByUserRole")
    @ResponseBody
    @UserAuth
    public PojoResult getMenuListByUserRole(Integer roleId) {
        PojoResult pojoResult = new PojoResult();
        SysRole role = sysRoleService.getRoleInfoById(roleId);
        Map<String, Object> resultMap = new HashMap<>();
        resultMap.put("roleInfo", role);
        resultMap.put("menuIds", sysMenuService.getMenuIdsByRoleId(roleId));
        resultMap.put("fieldIds", sysMenuService.getFieldIdsByRoleId(roleId));
        pojoResult.setContent(resultMap);
        return pojoResult;
    }


    /**
     * 添加根据操作人，拉取其所有的菜单树
     * roleType 角色类型
     *
     * @return
     */
    @RequestMapping("/getMenuListByAddRole")
    @ResponseBody
    @UserAuth
    public MapResult getMenuListByAddRole() {
        //根据操作人，拉取其所有的菜单
        MapResult mapResult = new MapResult();
        mapResult.setContent( sysMenuService.getMenuListByAddRole());
        return mapResult;
    }

    /**
     * 添加角色
     *
     * @param role
     * @param menuIds
     * @return
     */
    @RequestMapping("/addRole")
    @UserAuth
    @OperateLog(module = OperateModuleEnum.ROLE, operateType = OperateTypeEnum.ADD)
    public PojoResult addRole(SysRole role, String menuIds,String fieldIds) {
        PojoResult pojoResult = new PojoResult();
        SysRole sysRole = sysRoleService.addAndEditRole(role, menuIds,fieldIds);
        pojoResult.setContent(sysRole);
        return pojoResult;
    }

    /**
     * 编辑角色
     *
     * @param role
     * @param menuIds
     * @return
     */
    @RequestMapping("/editRole")
    @UserAuth
    @OperateLog(module = OperateModuleEnum.ROLE, operateType = OperateTypeEnum.EDIT)
    public PojoResult editRole(SysRole role, String menuIds,String fieldIds) {
        PojoResult pojoResult = new PojoResult();
        SysRole sysRole = sysRoleService.addAndEditRole(role, menuIds,fieldIds);
        pojoResult.setContent(sysRole);
        return pojoResult;
    }

    /**
     * 删除角色
     *
     * @param roleId
     * @return
     */
    @RequestMapping("/deleteRole")
    @UserAuth
    @OperateLog(module = OperateModuleEnum.ROLE, operateType = OperateTypeEnum.DELETE)
    public PojoResult deleteRole(Integer roleId) {
        PojoResult pojoResult = new PojoResult();
        BoolAlertResult boolResult = sysRoleService.deleteRole(roleId);
        pojoResult.setContent(boolResult.getMsg());
        return pojoResult;
    }

    @RequestMapping("/forbidAndStart")
    @UserAuth
    @OperateLog(module = OperateModuleEnum.ROLE, operateType = OperateTypeEnum.STOP_START)
    public PojoResult forbidAndStart(Integer roleId) {
        PojoResult pojoResult = new PojoResult();
        BoolAlertResult alertResult = sysRoleService.forbidAndStart(roleId);
        pojoResult.setContent(alertResult.getMsg());
        return pojoResult;
    }


}
