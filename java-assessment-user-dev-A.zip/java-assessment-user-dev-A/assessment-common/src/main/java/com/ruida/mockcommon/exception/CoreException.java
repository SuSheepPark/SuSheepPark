package com.ruida.mockcommon.exception;

import com.ruida.mockcommon.enums.AppErrorEnum;

/**
 * @description: 业务核心异常定义
 * @author szl
 * @Date 2018年12月06日
 * @verion 1.0
 */
public class CoreException  extends  RuntimeException{
    /**  */
    private static final long serialVersionUID = 5792816284203588336L;
    /**
     * 错误码 业务层面
     */
    private String errCode;
    /**
     * 错误消息
     */
    private String message;

    /**
     * 业务错误信息
     */
    private String subErrCode;

    @Override
    public String getMessage() {
        return message;
    }

    public String getErrCode() {
        return errCode;
    }

    public String getSubErrCode() {
        return subErrCode;
    }

    public CoreException(String errCode, String message, Throwable cause) {
        super(message, cause);
        this.errCode = errCode;
        this.message = message;
    }

    public CoreException(String errCode, String message) {
        super(message);
        this.errCode = errCode;
        this.message = message;
    }

    public CoreException(AppErrorEnum aisCommonError) {
        this(aisCommonError.getErrorCode(), aisCommonError.getErrorMessage());
        this.subErrCode = aisCommonError.getErrorCode();
    }

    public CoreException(AppErrorEnum aisCommonError, String errMsg) {
        this(aisCommonError.getHttpStatus(), aisCommonError.getErrorMessage() + " " + errMsg);
        this.subErrCode = aisCommonError.getErrorCode();
    }

    public CoreException(String errMsg, AppErrorEnum aisCommonError) {
        this(aisCommonError.getHttpStatus(), errMsg + " " + aisCommonError.getErrorMessage());
        this.subErrCode = aisCommonError.getErrorCode();
    }
}
