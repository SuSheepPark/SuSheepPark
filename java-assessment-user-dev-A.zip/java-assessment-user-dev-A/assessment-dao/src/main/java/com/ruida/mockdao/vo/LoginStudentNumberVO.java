package com.ruida.mockdao.vo;

public class LoginStudentNumberVO {
	private String number;
	private String source;

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}
}
