package com.ruida.assessment.assessmentcommon.enums;

/**
 * 推荐位置枚举类
 */
public enum RecommenedEnum {
    RAF("t_recommend_app_frontpage","app首页热门推荐"),
    RSE("t_recommend_subject_exam","科目选考-成绩测试-统考场次设置"),
    RETP("t_recommend_excellent_test_paper","首页精品试卷")
    ;


    private String K;
    private String V;

    RecommenedEnum(String k, String v) {
        K = k;
        V = v;
    }

    public String getK() {
        return K;
    }

    public void setK(String k) {
        K = k;
    }

    public String getV() {
        return V;
    }

    public void setV(String v) {
        V = v;
    }


    public static RecommenedEnum getValueById(String K){
        for(RecommenedEnum recommenedEnum : RecommenedEnum.values() ){
            if(recommenedEnum.getK().equals(K)){
                return  recommenedEnum;
            }
        }
        return null;
    }

}
