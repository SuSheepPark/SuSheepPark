package com.ruida.mockdao.vo;

import lombok.Data;

import java.util.List;

/**
 * @description: 科目信息VO
 * @author: chenjy
 * @create: 2020-07-23 08:51
 */
@Data
public class SubjectVO {

    /**
     * 科目id
     */
    private Integer subjectId;

    /**
     * 科目名称
     */
    private String subjectName;

    /**
     * 试题集合
     */
    private List<SimpleQuestionVO> questionList;

}
