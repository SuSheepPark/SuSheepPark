package com.ruida.common.enums;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * 0—联报优惠；1—带新优惠
 */
public enum DiscountType {

    compose(0,"联报优惠"), withnew(1,"带新优惠");

    public static final String SOURCE_KEY = "DiscountType";

    private int k;
    private String v;

    DiscountType(int k, String v) {
        this.k = k;
        this.v = v;
    }

    public static Map<Integer, String> map = new LinkedHashMap<>(2);
    static
    {
        for(DiscountType type : DiscountType.values())
        {
            map.put(type.getK(),type.getV());
        }
    }

    public static String getSourceKey() {
        return SOURCE_KEY;
    }

    public int getK() {
        return k;
    }

    public void setK(int k) {
        this.k = k;
    }

    public String getV() {
        return v;
    }

    public void setV(String v) {
        this.v = v;
    }

    /***
     * 根据k获取v的值
     * @param k
     * @return
     */
    public static String getvByk(int k) {
        DiscountType[] list = DiscountType.values();
        for (DiscountType valid : list) {
            if (valid.getK() == k ) {
                return valid.getV();
            }
        }
        return "";
    }
}
