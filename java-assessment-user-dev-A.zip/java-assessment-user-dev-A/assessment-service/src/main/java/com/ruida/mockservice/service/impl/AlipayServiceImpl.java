package com.ruida.mockservice.service.impl;

import com.alipay.api.AlipayApiException;
import com.alipay.api.AlipayClient;
import com.alipay.api.DefaultAlipayClient;
import com.alipay.api.domain.AlipayTradeAppPayModel;
import com.alipay.api.request.AlipayTradeAppPayRequest;
import com.alipay.api.request.AlipayTradePagePayRequest;
import com.alipay.api.response.AlipayTradeAppPayResponse;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.ruida.mockcommon.redis.RedisManager;
import com.ruida.mockcommon.redis.RedisPrefix;
import com.ruida.mockdao.model.Order;
import com.ruida.mockservice.AlipayConfig;
import com.ruida.mockservice.service.AlipayService;
import com.ruida.mockservice.service.OrderService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

import static org.apache.catalina.manager.Constants.CHARSET;

@Slf4j
@Service
@PropertySource("classpath:common.properties")
public class AlipayServiceImpl implements AlipayService {
    @Value("${alipay.notiyUrl}")
    String notiyUrl;
    @Value("${alipay.appnotiyUrl}")
    String appnotiyUrl;
    @Value("${local.server.host}")
    private  String localHost;
    @Resource
    RedisManager redisManager;
    @Resource
    OrderService orderService;

    @Override
    public void doPost(HttpServletRequest httpRequest, HttpServletResponse httpResponse)
            throws IOException {
        String orderNo = httpRequest.getParameter("orderNo");
        String returnUrl = httpRequest.getParameter("returnUrl");
        //获取订单支付价格
        EntityWrapper<Order> entityWrapper = new EntityWrapper<>();
        entityWrapper.andNew().eq("order_no", orderNo);
        Order checkOrder = orderService.selectOne(entityWrapper);
        String pay = String.valueOf(checkOrder.getPayAmount());//订单支付价格
        // redisManager.set(RedisPrefix.ORDER_PAY_ING + orderNo, "ALIPAY", 10);//订单支付中 防止多个平台同时支付 时限30秒
        AlipayClient alipayClient = new DefaultAlipayClient(AlipayConfig.gatewayUrl, AlipayConfig.app_id, AlipayConfig.merchant_private_key, "json", AlipayConfig.charset, AlipayConfig.alipay_public_key, AlipayConfig.sign_type); //获得初始化的AlipayClient
        AlipayTradePagePayRequest alipayRequest = new AlipayTradePagePayRequest();//创建API对应的request
        alipayRequest.setNotifyUrl(localHost + notiyUrl);//在公共参数中设置回跳和通知地址
//        alipayRequest.setNotifyUrl("http://z4ytzv.natappfree.cc/alipay/notify");
        //返回的商品说明区分报告试卷
        String returnName = "测评试卷-" + checkOrder.getOrderName();

        /** 等前端部署好,解码URL*/
        alipayRequest.setReturnUrl(java.net.URLDecoder.decode(returnUrl, "UTF-8"));//本地调试使用 发布外网请注掉
        alipayRequest.setBizContent("{" +
                "    \"out_trade_no\":\"" + httpRequest.getParameter("orderNo") + "\"," +
                "    \"product_code\":\"FAST_INSTANT_TRADE_PAY\"," +
                "    \"total_amount\":" + pay + "," +
                "    \"subject\":\"" + returnName + "\"," +
                "    \"body\":\"" + returnName + "\"," +
                "    \"passback_params\":\"merchantBizType%3d3C%26merchantBizNo%3d2016010101111\"," +
                "    \"extend_params\":{" +
                "    \"sys_service_provider_id\":\"2088511833207846\"" +
                "    }" +
                "  }");//填充业务参数
        String form = "";
        try {

            form = alipayClient.pageExecute(alipayRequest).getBody(); //调用SDK生成表单
        } catch (AlipayApiException e) {
            e.printStackTrace();
        }
        httpResponse.setContentType("text/html;charset=" + CHARSET);
        httpResponse.getWriter().write(form);//直接将完整的表单html输出到页面
        httpResponse.getWriter().flush();
        httpResponse.getWriter().close();
    }

    /**
     * app支付订单返回
     *
     * @param httpRequest
     * @param httpResponse
     */
    public String orderAlipay(HttpServletRequest httpRequest,
                              HttpServletResponse httpResponse) {
        String orderNo = httpRequest.getParameter("orderNo");
        //获取订单支付价格
        EntityWrapper<Order> entityWrapper = new EntityWrapper<>();
        entityWrapper.andNew().eq("order_no", orderNo);
        Order checkOrder = orderService.selectOne(entityWrapper);
        String pay = String.valueOf(checkOrder.getPayAmount());//订单支付价格
        redisManager.set(  orderNo, "yes", RedisPrefix.ORDER_PAY_ING,30);//订单支付中
        AlipayClient alipayClient = new DefaultAlipayClient(AlipayConfig.gatewayUrl, AlipayConfig.app_id, AlipayConfig.merchant_private_key, "json", AlipayConfig.charset, AlipayConfig.alipay_public_key, AlipayConfig.sign_type);
        //实例化具体API对应的request类,类名称和接口名称对应,当前调用接口名称：alipay.trade.app.pay
        AlipayTradeAppPayRequest request = new AlipayTradeAppPayRequest();
        //SDK已经封装掉了公共参数，这里只需要传入业务参数。以下方法为sdk的model入参方式(model和biz_content同时存在的情况下取biz_content)。
        AlipayTradeAppPayModel model = new AlipayTradeAppPayModel();
        //返回的商品说明区分报告试卷
        String returnName = "测评试卷-" + checkOrder.getOrderName();
        model.setBody(returnName);
        model.setSubject(returnName);//支付主题
        model.setOutTradeNo(orderNo);
        model.setTimeoutExpress("30m");//支付超时30分钟
        model.setTotalAmount(pay);
        model.setProductCode("FAST_INSTANT_TRADE_PAY");
        request.setBizModel(model);
//        request.setNotifyUrl("http://43fezn.natappfree.cc/alipay/notify");
        request.setNotifyUrl(localHost + notiyUrl);
        log.info("orderAlipay请求支付,回调地址:" + localHost + notiyUrl);
        String result = null;
        try {
            //这里和普通的接口调用不同，使用的是sdkExecute
            AlipayTradeAppPayResponse response = alipayClient.sdkExecute(request);
            result = response.getBody();

        } catch (AlipayApiException e) {
            e.printStackTrace();
        }
        return result;
    }
}
