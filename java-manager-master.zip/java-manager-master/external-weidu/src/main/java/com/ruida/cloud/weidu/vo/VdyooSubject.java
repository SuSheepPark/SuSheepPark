package com.ruida.cloud.weidu.vo;

import java.io.Serializable;

/**
 * @author taosh
 * @create 2019-07-26 10:33
 */
public class VdyooSubject implements Serializable {
    private String name;

    private String pid;

    private String id;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPid() {
        return pid;
    }

    public void setPid(String pid) {
        this.pid = pid;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
