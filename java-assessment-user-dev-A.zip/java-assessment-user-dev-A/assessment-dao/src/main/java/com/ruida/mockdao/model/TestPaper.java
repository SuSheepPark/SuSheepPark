package com.ruida.mockdao.model;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableLogic;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * <p>
 * 试卷表
 * </p>
 *
 * @author jinhu
 * @since 2020-07-08
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("t_test_paper")
@ApiModel(value="TestPaper对象", description="试卷表")
public class TestPaper implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "试卷id")
    @TableId(value = "test_paper_id", type = IdType.AUTO)
    private Integer testPaperId;

    @ApiModelProperty(value = "试卷名称")
    private String testPaperName;

    @ApiModelProperty(value = "试卷分数")
    private Double score;

    @ApiModelProperty(value = "年级id")
    private Integer stageId;

    @ApiModelProperty(value = "科目id")
    private Integer subjectId;

    @ApiModelProperty(value = "教材版本id")
    private Integer materialVersionId;

    @ApiModelProperty(value = "年份")
    private Integer year;

    @ApiModelProperty(value = "省份id")
    private Integer provinceId;

    @ApiModelProperty(value = "考试类型id")
    private Integer testTypeId;

    @ApiModelProperty(value = "试卷类型id")
    private Integer testPaperTypeId;

    @ApiModelProperty(value = "试题难度id")
    private Integer difficultyId;

    @ApiModelProperty(value = "测试时常 单位分钟")
    private Integer testDruation;

    @ApiModelProperty(value = "试卷号 自动生成")
    private String testPaperNo;

    @ApiModelProperty(value = "创建人")
    private Integer createBy;

    @ApiModelProperty(value = "创建时间")
    private LocalDateTime createTime;

    @ApiModelProperty(value = "更新者")
    private Integer updateBy;

    @ApiModelProperty(value = "更新时间")
    private LocalDateTime updateTime;

    @ApiModelProperty(value = "是否删除（0：未删除；1：删除）")
    @TableLogic
    private Integer isdelete;

    @ApiModelProperty(value = "试卷状态（1.草稿2.待审核3.已发布4.已取消发布）")
    private Integer status;

    @ApiModelProperty(value = "退回原因")
    private String rejectReason;

    @ApiModelProperty(value = "试卷性质(1-练习卷 2-高中联考卷1分1赋 3-高中联考卷3分1赋 4-高中联考卷必考科目 5-初中联考卷)")
    private Integer paperUseType;

    @ApiModelProperty(value = "答题方式(1-在线答题 2-纸面答题)")
    private Integer answerWay;
    @ApiModelProperty(value = "试卷文件地址")
    private String testPaperPath;

}
