package com.ruida.mockcommon.enums;



public enum StudentTypeEnum {

    USER_DEFAULT_GENERATED(0, "默认用户生成的考生"),
    IMPORT_STUDENT(1, "导入的考生");

    private Integer k;
    private String v;

    StudentTypeEnum(Integer k, String v) {
        this.k = k;
        this.v = v;
    }

    public Integer getK() {
        return k;
    }

    public void setK(Integer k) {
        this.k = k;
    }

    public String getV() {
        return v;
    }

    public void setV(String v) {
        this.v = v;
    }

    public static StudentTypeEnum getValueById(Integer K) {
        if (K != null) {
            for (StudentTypeEnum studentTypeEnum : StudentTypeEnum.values()) {
                if (studentTypeEnum.getK().equals(K)) {
                    return studentTypeEnum;
                }
            }
        }
        return null;
    }


}
