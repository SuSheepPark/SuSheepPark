package com.ruida.mockdao.dao;


import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.dto.ProductQueryRequest;
import com.ruida.mockdao.model.CollectProductRel;
import com.ruida.mockdao.vo.ProductNewVO;
import com.ruida.mockdao.vo.ProductVO;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 用户收藏商品关联表 Mapper 接口
 * </p>
 *
 * @author jinhu
 * @since 2020-07-08
 */
public interface CollectProductRelMapper extends BaseMapper<CollectProductRel> {

    /*
     *功能描述
     * @param 查询用户收藏商品列表
     * @return
     */
    List<ProductVO> queryProductCollectList(@Param("vo") ProductQueryRequest req);


    /*
     *功能描述
     * @param  查询用户收藏商品列表总数
     * @return
     */
    Integer queryProductCollectCount(@Param("vo") ProductQueryRequest req);
    /*
     *功能描述
     * @param 查询用户收藏商品列表
     * @return
     */
    List<ProductNewVO> queryProductCollectListNew(@Param("vo") ProductQueryRequest req);


    /*
     *功能描述
     * @param  查询用户收藏商品列表总数
     * @return
     */
    Integer queryProductCollectCountNew(@Param("vo") ProductQueryRequest req);

}
