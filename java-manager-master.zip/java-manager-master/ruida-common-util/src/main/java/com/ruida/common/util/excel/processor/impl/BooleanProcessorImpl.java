package com.ruida.common.util.excel.processor.impl;

import com.ruida.common.util.excel.processor.TypeProcessor;
import org.apache.commons.lang3.StringUtils;

import java.text.ParseException;

/**
 * Created by Administrator on 2017/4/18.
 */
public class BooleanProcessorImpl implements TypeProcessor {

    @Override
    public Object fromString(String preValue) throws ParseException {
        if(StringUtils.isBlank(preValue)){
            return null;
        }

        if(preValue.equals("是") || preValue.equals("true")){
            return true;
        }else if(preValue.equals("否") || preValue.equals("false")){
            return false;
        }else{
            throw new ParseException(preValue + "无法转换为bool值", 0);
        }
    }

    @Override
    public String toString(Object value) throws ParseException {
        if(value == null){
            return "";
        }

        return value.toString();
    }

}
