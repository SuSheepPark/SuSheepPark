package com.ruida.cloud.dao;

import com.ruida.cloud.model.OnlineTeachingClass;
import com.ruida.cloud.model.OnlineTeachingClassExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface OnlineTeachingClassMapper {
    long countByExample(OnlineTeachingClassExample example);

    int deleteByExample(OnlineTeachingClassExample example);

    int deleteByPrimaryKey(Integer onlineTeachingClassId);

    int insert(OnlineTeachingClass record);

    int insertSelective(OnlineTeachingClass record);

    List<OnlineTeachingClass> selectByExample(OnlineTeachingClassExample example);

    OnlineTeachingClass selectByPrimaryKey(Integer onlineTeachingClassId);

    int updateByExampleSelective(@Param("record") OnlineTeachingClass record, @Param("example") OnlineTeachingClassExample example);

    int updateByExample(@Param("record") OnlineTeachingClass record, @Param("example") OnlineTeachingClassExample example);

    int updateByPrimaryKeySelective(OnlineTeachingClass record);

    int updateByPrimaryKey(OnlineTeachingClass record);
}