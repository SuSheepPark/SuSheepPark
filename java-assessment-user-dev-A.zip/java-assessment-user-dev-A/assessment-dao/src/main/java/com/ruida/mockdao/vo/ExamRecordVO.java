package com.ruida.mockdao.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.util.Date;

/**
 * @description: 考试记录
 * @author: chenjy
 * @create: 2020-07-27 15:17
 */
@Data
public class ExamRecordVO {

    private Integer examRecordId;

    private String sceneId;

    private Integer productId;

    private Integer testPaperId;

    private String testPaperName;

    private Integer status;

    @JsonFormat(pattern = "yyyy.MM.dd")
    private Date createTime;
}
