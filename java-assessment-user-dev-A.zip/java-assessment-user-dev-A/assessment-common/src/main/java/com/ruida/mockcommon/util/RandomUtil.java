package com.ruida.mockcommon.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Created by xumingqi on 2021/8/10 17:50
 */
public class RandomUtil {
    /*
     * 生成任意位数不同的随机数 nums：位数 start：开始数字 end：结束数字 比如：生成范围为[0,100)的10个随机数
     * System.out.println(generateRandomNum(10,0,100));
     */
    public static String generateRandomNum(int nums, int start, int end) {
        // 1.创建集合容器对象
        List<Integer> list = new ArrayList<Integer>();

        // 2.创建Random对象
        Random r = new Random();

        // 循环将得到的随机数进行判断，如果随机数不存在于集合中，则将随机数放入集合中，如果存在，则将随机数丢弃不做操作，进行下一次循环，直到集合长度等于nums
        while (list.size() != nums) {
            int num = r.nextInt(end - start) + start;
            if (!list.contains(num)) {
                list.add(num);
            }
        }

        StringBuilder sbBuilder = new StringBuilder();
        for (int i = 0; i < list.size(); i++) {
            String numString = String.valueOf(list.get(i));
            sbBuilder.append(numString);
        }
        return sbBuilder.toString();
    }
}
