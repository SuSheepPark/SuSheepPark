package com.ruida.common.model;

import java.io.Serializable;

/**
 * @author wy
 * @description
 * @date 2020/5/22
 */
public class PageableRequest<T> implements Serializable{
    private static final long serialVersionUID = -2309936481470941045L;
    private int current = 1;
    private int size = 10;
    private String sort;
    private T data;

    public PageableRequest() {
    }

    public String getSort() {
        return this.sort;
    }

    public void setSort(String sort) {
        this.sort = sort;
    }

    public int getCurrent() {
        return this.current;
    }

    public void setCurrent(int current) {
        this.current = current;
    }

    public int getSize() {
        return this.size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public T getData() {
        return this.data;
    }

    public void setData(T data) {
        this.data = data;
    }
}
