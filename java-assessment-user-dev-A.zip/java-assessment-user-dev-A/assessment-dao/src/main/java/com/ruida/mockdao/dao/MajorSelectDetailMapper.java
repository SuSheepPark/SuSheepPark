package com.ruida.mockdao.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.model.MajorSelectDetail;
import com.ruida.mockdao.vo.major.MajorGroupVO;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 专业兴趣选择详情表 Mapper 接口
 * </p>
 *
 * @author xumingqi
 * @since 2021-01-14
 */
public interface MajorSelectDetailMapper extends BaseMapper<MajorSelectDetail> {
    List<MajorGroupVO> getMyMajorReport(@Param("recordId") Integer recordId);

    Integer countMajorCategoryCode(@Param("recordId") Integer recordId);
}
