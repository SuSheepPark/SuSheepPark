package com.ruida.mockcommon.redis;

/**
 * @author szl
 * @description: redis 前缀管理
 * @Date 2019/4/17
 * @verion 1.0
 */
public class RedisPrefix {
    public static String ORDER_PAY_ING = "order_pay_ing_";/**订单支付中*/
}
