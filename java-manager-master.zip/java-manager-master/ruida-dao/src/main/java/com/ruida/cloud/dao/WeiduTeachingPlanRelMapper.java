package com.ruida.cloud.dao;

import com.ruida.cloud.model.WeiduTeachingPlanRel;
import com.ruida.cloud.model.WeiduTeachingPlanRelExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface WeiduTeachingPlanRelMapper {
    long countByExample(WeiduTeachingPlanRelExample example);

    int deleteByExample(WeiduTeachingPlanRelExample example);

    int deleteByPrimaryKey(Integer rid);

    int insert(WeiduTeachingPlanRel record);

    int insertSelective(WeiduTeachingPlanRel record);

    List<WeiduTeachingPlanRel> selectByExample(WeiduTeachingPlanRelExample example);

    WeiduTeachingPlanRel selectByPrimaryKey(Integer rid);

    int updateByExampleSelective(@Param("record") WeiduTeachingPlanRel record, @Param("example") WeiduTeachingPlanRelExample example);

    int updateByExample(@Param("record") WeiduTeachingPlanRel record, @Param("example") WeiduTeachingPlanRelExample example);

    int updateByPrimaryKeySelective(WeiduTeachingPlanRel record);

    int updateByPrimaryKey(WeiduTeachingPlanRel record);

    /**删除**/
    int deleteWeiduTeachPlanRel(String planIds);
}