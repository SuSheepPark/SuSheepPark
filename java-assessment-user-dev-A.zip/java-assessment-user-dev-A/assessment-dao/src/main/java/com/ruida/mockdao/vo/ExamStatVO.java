package com.ruida.mockdao.vo;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;


@Data
@ApiModel(value="考试页  题量卷量统计")
public class ExamStatVO {

    @ApiModelProperty(value = "做题量")
    private int questionNum;

    @ApiModelProperty(value = "做卷量")
    private int paperNum;

    @ApiModelProperty(value = "正确率")
    private double correctRate;
}
