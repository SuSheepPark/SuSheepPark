package com.ruida.assessment.assessmentquestionbank.controller;

import com.ruida.assessment.assessmentcommon.result.ListResult;
import com.ruida.assessment.assessmentquestionbank.service.QuestionPurposeService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * @description:
 * @author: kgz
 * @date: 2020/6/10
 */
@RequestMapping("/questionPurpose")
@RestController
@Api(value ="试题用途相关接口")
public class QuestionPurposeController {
    @Resource
    private QuestionPurposeService questionPurposeService;

    @GetMapping("/getList")
    @ApiOperation(value = "获取难度等级下拉框列表", notes = "获取难度等级下拉框列表")
    public ListResult getList(){
        ListResult listResult = new ListResult();
        listResult.setContent(questionPurposeService.getList());
        return listResult;
    }
}
