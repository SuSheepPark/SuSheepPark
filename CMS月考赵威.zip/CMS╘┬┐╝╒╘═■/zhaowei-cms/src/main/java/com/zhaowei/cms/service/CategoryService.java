/**   
 * Copyright © 2019 公司名. All rights reserved.
 * 
 * @Title: CategoryService.java 
 * @Prject: zhaowei-cms
 * @Package: com.zhaowei.cms.service 
 * @Description: TODO
 * @author: zw   
 * @date: 2019年9月17日 下午8:43:06 
 * @version: V1.0   
 */
package com.zhaowei.cms.service;

import java.util.List;

import com.zhaowei.cms.domain.Category;

/** 
 * @ClassName: CategoryService 
 * @Description: TODO
 * @author: zw
 * @date: 2019年9月17日 下午8:43:06  
 */
public interface CategoryService {

	
	/**
	 * 
	 * @Title: selectsByChannel 
	 * @Description:根据栏目查询旗下所有分类
	 * @param cid
	 * @return
	 * @return: List<Category>
	 */
	List<Category> selectsByChannelId(Integer cid);
	
}
