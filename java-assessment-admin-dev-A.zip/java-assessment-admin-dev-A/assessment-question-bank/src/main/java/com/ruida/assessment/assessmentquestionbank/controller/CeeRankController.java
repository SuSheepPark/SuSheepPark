package com.ruida.assessment.assessmentquestionbank.controller;

import com.ruida.assessment.assessmentcommon.result.PojoResult;
import com.ruida.assessment.assessmentcommon.util.ValidateMT;
import com.ruida.assessment.assessmentquestionbank.annotaion.UserAuth;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * 一分一段
 */
@RestController
@RequestMapping("/ceeRank")
public class CeeRankController {

//    @Resource
//    StringRedisTemplate stringRedisTemplate;
//
//    /**
//     * 是否开启一分一段分数转换
//     *
//     * @return
//     */
//    @RequestMapping("/getSwitchScoreConversion")
//    @UserAuth
//    public PojoResult getSwitchScoreConversion() {
//        PojoResult result = new PojoResult();
//        String isSwitch = stringRedisTemplate.opsForValue().get("switch_score_conversion");
//        if (ValidateMT.isNull(isSwitch)) {
//            isSwitch = "0";
//        }
//        result.setContent(Integer.valueOf(isSwitch));
//        return result;
//    }
//
//    /**
//     * 开启和关闭一分一段分数转换
//     *
//     * @return
//     */
//    @RequestMapping("/handleOnOrOff")
//    @UserAuth
//    public PojoResult handleOnOrOff() {
//        PojoResult result = new PojoResult();
//        String isSwitch = stringRedisTemplate.opsForValue().get("switch_score_conversion");
//        if (ValidateMT.isNull(isSwitch)) {
//            stringRedisTemplate.opsForValue().set("switch_score_conversion", "1");
//            isSwitch = "1";
//        } else if (StringUtils.equals("0", isSwitch)) {
//            stringRedisTemplate.opsForValue().set("switch_score_conversion", "1");
//            isSwitch = "1";
//        } else {
//            stringRedisTemplate.opsForValue().set("switch_score_conversion", "0");
//            isSwitch = "0";
//        }
//        result.setContent(Integer.valueOf(isSwitch));
//        return result;
//    }
}
