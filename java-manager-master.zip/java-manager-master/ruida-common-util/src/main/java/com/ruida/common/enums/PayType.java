package com.ruida.common.enums;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * @author szl
 * @description: ${TODO}
 * @Date 2019/3/11
 * @verion 1.0
 */
public enum PayType {
     WECHAT(0,"微信"), ALIPAY(1,"支付宝"), QQPAY(2,"QQ钱包"),UNIONPAY(3,"网银支付"),UNDERLINE(4,"线下支付"),FREE(5,"免费");

    public static final String SOURCE_KEY = "Bool";
    private Integer k;
    private String v;

    PayType(Integer k, String v) {
        this.k = k;
        this.v = v;
    }

    public static Map<Integer,String> map = new LinkedHashMap<>(2);
    static
    {
        for(PayType type : PayType.values())
        {
            map.put(type.getK(),type.getV());
        }
    }

    /***
     * 获取支付方式
     * @return
     */
    public static String getValueForK(Integer k){
      PayType[] ary = PayType.values();
        for (PayType payType : ary) {
            if (payType.k == k){
                return payType.v;
            }
        }
        return "";
    }

    public Integer getK() {
        return k;
    }

    public void setK(Integer k) {
        this.k = k;
    }

    public String getV() {
        return v;
    }

    public void setV(String v) {
        this.v = v;
    }
}
