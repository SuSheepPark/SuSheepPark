package com.ruida.mockcommon.util;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 加密解密工具类
 * 
 * @author yangmc
 */
public class CryptoUtil {

	private static Logger logger = LoggerFactory.getLogger(CryptoUtil.class);

	public static final String SIGN_ALGORITHMS = "SHA1PRNG";
	public static final String TRANSFORMATION = "AES/ECB/PKCS5Padding";
	public static final String ALGORITHM = "AES";

	/*
	 * 加密 1.构造密钥生成器 2.根据ecnodeRules规则初始化密钥生成器 3.产生密钥 4.创建和初始化密码器 5.内容加密 6.返回字符串
	 */
	public static String AESEncode(String password, String content) {
		if (StringUtils.isEmpty(content)) {
			return null;
		}
		try {
			// 4.获得原始对称密钥的字节数组
			byte[] raw;
			if (password.getBytes().length == 16) {
				raw = password.getBytes();
			} else {
				raw = new byte[16];
				for (int i = 0; i < 16; i++) {
					raw[i] = i < password.getBytes().length ? password.getBytes()[i] : 0;
				}
			}
			// 5.根据字节数组生成AES密钥
			SecretKey key = new SecretKeySpec(raw, ALGORITHM);
			// 6.根据指定算法AES自成密码器
			Cipher cipher = Cipher.getInstance(TRANSFORMATION);
			// 7.初始化密码器，第一个参数为加密(Encrypt_mode)或者解密解密(Decrypt_mode)操作，第二个参数为使用的KEY
			cipher.init(Cipher.ENCRYPT_MODE, key);
			// 8.获取加密内容的字节数组(这里要设置为utf-8)不然内容中如果有中文和英文混合中文就会解密为乱码
			byte[] byte_encode = content.getBytes("utf-8");
			// 9.根据密码器的初始化方式--加密：将数据加密
			byte[] byte_AES = cipher.doFinal(byte_encode);
			// 10.将加密后的数据转换为字符串
			// 这里用Base64Encoder中会找不到包
			// 解决办法：
			// 在项目的Build path中先移除JRE System Library，再添加库JRE System Library，重新编译后就一切正常了。
//			String AES_encode = new String(Base64.getEncoder().encodeToString(byte_AES));
			String AES_encode = byteToHex(byte_AES);
			// 11.将字符串返回
			return AES_encode;
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (NoSuchPaddingException e) {
			e.printStackTrace();
		} catch (InvalidKeyException e) {
			e.printStackTrace();
		} catch (IllegalBlockSizeException e) {
			e.printStackTrace();
		} catch (BadPaddingException e) {
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}

		// 如果有错就返加nulll
		return null;
	}

	/*
	 * 解密 解密过程： 1.同加密1-4步 2.将加密后的字符串反纺成byte[]数组 3.将加密内容解密
	 */
	public static String AESDncode(String password, String content) {
		if (StringUtils.isEmpty(content)) {
			return null;
		}
		try {
			// 4.获得原始对称密钥的字节数组
			byte[] raw;
			if (password.getBytes().length == 16) {
				raw = password.getBytes();
			} else {
				raw = new byte[16];
				for (int i = 0; i < 16; i++) {
					raw[i] = i < password.getBytes().length ? password.getBytes()[i] : 0;
				}
			}
			// 5.根据字节数组生成AES密钥
			SecretKey key = new SecretKeySpec(raw, ALGORITHM);
			// 6.根据指定算法AES自成密码器
			Cipher cipher = Cipher.getInstance(TRANSFORMATION);
			// 7.初始化密码器，第一个参数为加密(Encrypt_mode)或者解密(Decrypt_mode)操作，第二个参数为使用的KEY
			cipher.init(Cipher.DECRYPT_MODE, key);
			// 8.将加密并编码后的内容解码成字节数组
//			byte[] byte_content = Base64.getDecoder().decode(content);
			byte[] byte_content = hexToByte(content);
			/*
			 * 解密
			 */
			byte[] byte_decode = cipher.doFinal(byte_content);
			String AES_decode = new String(byte_decode, "utf-8");
			return AES_decode;
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (NoSuchPaddingException e) {
			e.printStackTrace();
		} catch (InvalidKeyException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (IllegalBlockSizeException e) {
			e.printStackTrace();
		} catch (BadPaddingException e) {
			e.printStackTrace();
		}

		// 如果有错就返加nulll
		return null;
	}

	/**
	 * hex转byte数组
	 * 
	 * @param hex
	 * @return
	 */
	public static byte[] hexToByte(String hex) {
		int m = 0, n = 0;
		int byteLen = hex.length() / 2; // 每两个字符描述一个字节
		byte[] ret = new byte[byteLen];
		for (int i = 0; i < byteLen; i++) {
			m = i * 2 + 1;
			n = m + 1;
			int intVal = Integer.decode("0x" + hex.substring(i * 2, m) + hex.substring(m, n));
			ret[i] = Byte.valueOf((byte) intVal);
		}
		return ret;
	}

	/**
	 * byte数组转hex
	 * 
	 * @param bytes
	 * @return
	 */
	public static String byteToHex(byte[] bytes) {
		String strHex = "";
		StringBuilder sb = new StringBuilder("");
		for (int n = 0; n < bytes.length; n++) {
			strHex = Integer.toHexString(bytes[n] & 0xFF);
			sb.append((strHex.length() == 1) ? "0" + strHex : strHex); // 每个字节由两个字符表示，位数不够，高位补0
		}
		return sb.toString().trim();
	}

	public static void main(String[] args) {
		String encode = AESEncode("Ruida@2021", "12345678910");
		String decode = AESDncode("Ruida@2021", "A33277BA2F02236524B8B29860F359D0");
		System.err.println(encode);
		System.err.println(decode);
	}


	/**
	 * AES加密
	 * @param content 明文
	 * @param encryptKey 秘钥
	 * @return 密文
	 * @throws Exception
	 */
	public static String aesEncrypt(String content, String encryptKey) {
		if (StringUtils.isEmpty(content) || StringUtils.isEmpty(encryptKey)) {
			return null;
		}

		byte[] encryptStr = new byte[0];
		try {
			Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
			cipher.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(encryptKey.getBytes(), "AES"));
			encryptStr = cipher.doFinal(content.getBytes(StandardCharsets.UTF_8));
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (NoSuchPaddingException e) {
			e.printStackTrace();
		} catch (InvalidKeyException e) {
			e.printStackTrace();
		} catch (IllegalBlockSizeException e) {
			e.printStackTrace();
		} catch (BadPaddingException e) {
			e.printStackTrace();
		}
		return Base64.getEncoder().encodeToString(encryptStr);
	}



	/**
	 * AES解密
	 * @param encryptStr 密文
	 * @param decryptKey 秘钥
	 * @return 明文
	 * @throws Exception
	 */
	public static String aesDecrypt(String encryptStr, String decryptKey) {
		if (StringUtils.isEmpty(encryptStr) || StringUtils.isEmpty(decryptKey)) {
			return null;
		}

		byte[] encryptByte = Base64.getDecoder().decode(encryptStr);
		byte[] decryptBytes = new byte[0];
		try {
			Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
			cipher.init(Cipher.DECRYPT_MODE, new SecretKeySpec(decryptKey.getBytes(), "AES"));
			decryptBytes = cipher.doFinal(encryptByte);
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (NoSuchPaddingException e) {
			e.printStackTrace();
		} catch (InvalidKeyException e) {
			e.printStackTrace();
		} catch (IllegalBlockSizeException e) {
			e.printStackTrace();
		} catch (BadPaddingException e) {
			e.printStackTrace();
		}
		return new String(decryptBytes);
	}

}