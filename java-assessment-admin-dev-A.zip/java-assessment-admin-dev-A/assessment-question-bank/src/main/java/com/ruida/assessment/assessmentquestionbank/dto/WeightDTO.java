package com.ruida.assessment.assessmentquestionbank.dto;

import io.swagger.annotations.ApiModelProperty;

import java.util.List;

/**
 * @description: 权重DTO
 * @author: kgz
 * @date: 2021/3/30
 */
public class WeightDTO {

    @ApiModelProperty(value = "上传记录id", name = "uploadId")
    private List<Integer> uploadId;

    @ApiModelProperty(value = "商品id", name = "productId")
    private List<Integer> productId;

    public List<Integer> getUploadId() {
        return uploadId;
    }

    public void setUploadId(List<Integer> uploadId) {
        this.uploadId = uploadId;
    }

    public List<Integer> getProductId() {
        return productId;
    }

    public void setProductId(List<Integer> productId) {
        this.productId = productId;
    }
}
