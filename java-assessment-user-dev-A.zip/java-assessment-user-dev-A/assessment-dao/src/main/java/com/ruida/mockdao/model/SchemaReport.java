package com.ruida.mockdao.model;

import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;
import com.ruida.mockcommon.util.DateFormatUtil;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 选科方案报告
 * </p>
 *
 * @author chenjy
 * @since 2021-02-23
 */
@TableName("t_schema_report")
public class SchemaReport extends Model<SchemaReport> {

    private static final long serialVersionUID = 1L;

    /**
     * 报告id
     */
    @TableId(value = "report_id", type = IdType.AUTO)
    private Integer reportId;
    /**
     * 用户id
     */
    @TableField("user_id")
    private Integer userId;

    /**
     * 订单id
     */
    @TableField("order_no")
    private String orderNo;
    /**
     * 类型(1-推荐；2-自选)
     */
    private Integer type;
    /**
     * 历史成绩
     */
    @TableField("former_record_id")
    private Integer formerRecordId;

    /**
     * 考试次数
     */
    @TableField("exam_record_times")
    private Integer examRecordTimes;
    /**
     * 科目记录
     */
    @TableField("subject_record_id")
    private Integer subjectRecordId;
    /**
     * 专业记录
     */
    @TableField("major_record_id")
    private Integer majorRecordId;
    /**
     * 职业兴趣
     */
    @TableField("occupation_record_id")
    private Integer occupationRecordId;
    /**
     * 科目
     */
    @TableField("subject_name")
    private String subjectName;
    /**
     * 剩余自选次数
     */
    @TableField("surplus_times")
    private Integer surplusTimes;
    /**
     * 创建人
     */
    @TableField("create_by")
    private Integer createBy;
    /**
     * 创建时间
     */
    @TableField("create_time")
    private Date createTime;
    /**
     * 修改人
     */
    @TableField("update_by")
    private Integer updateBy;
    /**
     * 修改时间
     */
    @TableField("update_time")
    private Date updateTime;
    /**
     * 删除标志
     */
    private Integer isdelete;
    /**
     * 提档线分数年份
     */
    private Integer year;


    public Integer getReportId() {
        return reportId;
    }

    public void setReportId(Integer reportId) {
        this.reportId = reportId;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public Integer getFormerRecordId() {
        return formerRecordId;
    }

    public void setFormerRecordId(Integer formerRecordId) {
        this.formerRecordId = formerRecordId;
    }

    public Integer getExamRecordTimes() {
        return examRecordTimes;
    }

    public void setExamRecordTimes(Integer examRecordTimes) {
        this.examRecordTimes = examRecordTimes;
    }

    public Integer getSubjectRecordId() {
        return subjectRecordId;
    }

    public void setSubjectRecordId(Integer subjectRecordId) {
        this.subjectRecordId = subjectRecordId;
    }

    public Integer getMajorRecordId() {
        return majorRecordId;
    }

    public void setMajorRecordId(Integer majorRecordId) {
        this.majorRecordId = majorRecordId;
    }

    public Integer getOccupationRecordId() {
        return occupationRecordId;
    }

    public void setOccupationRecordId(Integer occupationRecordId) {
        this.occupationRecordId = occupationRecordId;
    }

    public String getSubjectName() {
        return subjectName;
    }

    public void setSubjectName(String subjectName) {
        this.subjectName = subjectName;
    }

    public Integer getSurplusTimes() {
        return surplusTimes;
    }

    public void setSurplusTimes(Integer surplusTimes) {
        this.surplusTimes = surplusTimes;
    }

    public Integer getCreateBy() {
        return createBy;
    }

    public void setCreateBy(Integer createBy) {
        this.createBy = createBy;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(Integer updateBy) {
        this.updateBy = updateBy;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getIsdelete() {
        return isdelete;
    }

    public void setIsdelete(Integer isdelete) {
        this.isdelete = isdelete;
    }

    public String getCreateTimeFormat() {
        return DateFormatUtil.getDateFormat(createTime);
    }

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    @Override
    protected Serializable pkVal() {
        return this.reportId;
    }

    @Override
    public String toString() {
        return "SchemaReport{" +
                ", reportId=" + reportId +
        ", userId=" + userId +
        ", orderNo=" + orderNo +
        ", type=" + type +
        ", formerRecordId=" + formerRecordId +
        ", subjectRecordId=" + subjectRecordId +
        ", majorRecordId=" + majorRecordId +
        ", occupationRecordId=" + occupationRecordId +
        ", subjectName=" + subjectName +
        ", createBy=" + createBy +
        ", createTime=" + createTime +
        ", updateBy=" + updateBy +
        ", updateTime=" + updateTime +
        ", isdelete=" + isdelete +
        "}";
    }
}
