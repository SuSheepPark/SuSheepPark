package com.ruida.mockdao.vo;

import java.util.Date;

/**
 * @description: 选考科目成绩报告VO
 * @author: kgz
 * @date: 2021/2/26
 */
public class OptionalSubjectReportVO {

    /**
     * 主键ID
     */
    private Integer id;

    /**
     * 选考科目成绩信息
     */
    private ExamProductRecordVO productOptionalSubjectRecord;

    /**
     * 必考科目成绩信息
     */
    private ExamProductRecordVO productRequiredSubjectRecord;

    /**
     * 选考科目小结信息
     */
    private ExamRecoreSummaryVO examRecoreSummary;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public ExamProductRecordVO getProductOptionalSubjectRecord() {
        return productOptionalSubjectRecord;
    }

    public void setProductOptionalSubjectRecord(ExamProductRecordVO productOptionalSubjectRecord) {
        this.productOptionalSubjectRecord = productOptionalSubjectRecord;
    }

    public ExamProductRecordVO getProductRequiredSubjectRecord() {
        return productRequiredSubjectRecord;
    }

    public void setProductRequiredSubjectRecord(ExamProductRecordVO productRequiredSubjectRecord) {
        this.productRequiredSubjectRecord = productRequiredSubjectRecord;
    }

    public ExamRecoreSummaryVO getExamRecoreSummary() {
        return examRecoreSummary;
    }

    public void setExamRecoreSummary(ExamRecoreSummaryVO examRecoreSummary) {
        this.examRecoreSummary = examRecoreSummary;
    }
}
