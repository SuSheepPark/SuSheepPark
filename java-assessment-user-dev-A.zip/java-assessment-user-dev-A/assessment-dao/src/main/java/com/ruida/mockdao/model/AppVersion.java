package com.ruida.mockdao.model;

import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * APP版本信息表
 * </p>
 *
 * @author Bhj
 * @since 2020-07-17
 */
@TableName("t_app_version")
public class AppVersion extends Model<AppVersion> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键ID
     */
    @TableId(value = "app_version_id", type = IdType.AUTO)
    private Integer appVersionId;
    /**
     * 类型（1—安卓；2—IOS）
     */
    private Integer type;
    /**
     * 大版本号
     */
    @TableField("version_code")
    private String versionCode;
    /**
     * 详细版本号
     */
    private String version;
    /**
     * 下载路径
     */
    private String url;
    /**
     * 下载路径配置方式(0-本地上传地址;1-第三方商店地址)
     */
    @TableField("path_config_method")
    private Integer pathConfigMethod;
    /**
     * 文件名称
     */
    @TableField("file_name")
    private String fileName;
    /**
     * 是否强制更新（0：不强制；1：强制）
     */
    private Integer isupdate;
    /**
     * 创建者ID
     */
    @TableField("create_by")
    private Integer createBy;
    /**
     * 创建时间
     */
    @TableField("create_time")
    private Date createTime;
    /**
     * 更新者ID
     */
    @TableField("update_by")
    private Integer updateBy;
    /**
     * 更新时间
     */
    @TableField("update_time")
    private Date updateTime;
    /**
     * 是否删除（0：否；1：是）
     */
    private Integer isdelete;
    /**
     * 更新描述


     */
    private String remark;


    public Integer getAppVersionId() {
        return appVersionId;
    }

    public void setAppVersionId(Integer appVersionId) {
        this.appVersionId = appVersionId;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public String getVersionCode() {
        return versionCode;
    }

    public void setVersionCode(String versionCode) {
        this.versionCode = versionCode;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Integer getPathConfigMethod() {
        return pathConfigMethod;
    }

    public void setPathConfigMethod(Integer pathConfigMethod) {
        this.pathConfigMethod = pathConfigMethod;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public Integer getIsupdate() {
        return isupdate;
    }

    public void setIsupdate(Integer isupdate) {
        this.isupdate = isupdate;
    }

    public Integer getCreateBy() {
        return createBy;
    }

    public void setCreateBy(Integer createBy) {
        this.createBy = createBy;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(Integer updateBy) {
        this.updateBy = updateBy;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getIsdelete() {
        return isdelete;
    }

    public void setIsdelete(Integer isdelete) {
        this.isdelete = isdelete;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    @Override
    protected Serializable pkVal() {
        return this.appVersionId;
    }

    @Override
    public String toString() {
        return "AppVersion{" +
        ", appVersionId=" + appVersionId +
        ", type=" + type +
        ", versionCode=" + versionCode +
        ", version=" + version +
        ", url=" + url +
        ", pathConfigMethod=" + pathConfigMethod +
        ", fileName=" + fileName +
        ", isupdate=" + isupdate +
        ", createBy=" + createBy +
        ", createTime=" + createTime +
        ", updateBy=" + updateBy +
        ", updateTime=" + updateTime +
        ", isdelete=" + isdelete +
        ", remark=" + remark +
        "}";
    }
}
