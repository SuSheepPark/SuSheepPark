package com.ruida.mockdao.vo;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

/**
 * @author xumingqi
 * @date 2021/1/15 13:12
 */
@Data
public class StudentInfoVO {

    /**
     * 学生姓名
     */
    private String stuName;
    private String subjectName;

    /**
     * 班级
     */
    private Integer classId;
    private String className;


    /**
     * 年级
     */
    private Integer gradeId;
    private String gradeName;



    /**
     * 学校
     */
    private Integer schoolId;
    private String schoolName;

    /**
     * 准考证号
     */
    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    String candidateNumber;

    /**
     * 考生id
     */
    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    Integer stuId;

    /**
     * 用户的考生序号名称 ，例 "考生一"，"考生二"
     */
    private String userStuNumName;


}
