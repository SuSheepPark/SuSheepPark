package com.ruida.assessment.assessmentquestionbank.model;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import lombok.Data;

import java.io.Serializable;

/**
 * @author wy
 * @description  教材版本-学段-科目关联实体类
 * @date 2020/9/14
 */
@Data
@TableName("t_material_version_period_subject_rel")
public class TMaterialVersionPeriodSubjectRel implements Serializable {


    private static final long serialVersionUID = 1753161771395723850L;

    @TableId
    private Integer id;

    private Integer versionId;
    private Integer periodId;
    private Integer subjectId;
}
