package com.ruida.mockservice.service;

import com.baomidou.mybatisplus.service.IService;
import com.ruida.mockcommon.result.BaseResult;
import com.ruida.mockcommon.result.MapResult;
import com.ruida.mockdao.model.SysUser;
import com.ruida.mockdao.vo.BindingStuNoVO;

import java.util.List;

/**
 * <p>
 * 用户表 服务类
 * </p>
 *
 * @author Bhj
 * @since 2020-07-09
 */
public interface SysUserService extends IService<SysUser> {
    /**
     *
     * @param telephone
     * @param password
     * @param source
     * @return  登录认证
     */
    MapResult<String, Object> login(String telephone, String password, String source, boolean isExistenceLogin, String deviceNo) throws Exception;

    MapResult<String, Object> loginBytel(String telephone, String code, String source, Boolean isExistenceLogin, String deviceNo);

    SysUser register(String telephone, String code, Integer sourceChannel);

    SysUser userbasicCheckByUserhas(String telephone);

    boolean loginout();

    void findPasswordFristCheckCard(String telephone, String code);

    boolean revisePassword(String telephone, String newPwd) throws Exception;

    boolean bindMobile(String telephone, String code);

    boolean updateMobileFirstStep(String telephone, String code);

    boolean updateMobileSecondStep(String telephone, String code);

    boolean updateNewPassword(String oldPwd, String newPwd) throws Exception;

    BaseResult confirmIdentify(String telephone, String code);

    /**
     * 不需要密码的登录(统考需求，主要为了获取token)
     * @param username         用户名(准考证号或者学号)
     * @param source           来源(1=PC；2=安卓；3=iOS)
     * @param isExistenceLogin 是否强制登录，默认true
     * @return
     */
    @Deprecated
    MapResult<String,Object> loginWithoutPwd(String username,String source,boolean isExistenceLogin);

    /**
     * 使用准考证号登录，用于在线统考，和测评系统权限不通用
     * @param studentNumber
     * @return
     */
    MapResult<String,Object> loginByStudentNumber(String studentNumber,String source);
    
    SysUser checkUser(String username);


    /**
     * 小程序登录
     * @param telephone
     * @param code
     * @param encryptedData
     * @param iv
     * @return
     */
    MapResult<String, Object> wxLogin(String telephone,String code,String encryptedData,String iv,String telephoneCode);

    /**
     * 重置token时间
     * @return
     */
    BaseResult resetWXLoginToken();

    /**
     * 获取当前用户的准考证号列表
     * @return
     */
    List getCandidateNumberList();

    /**
     * 是否未绑定准考证号接口
     * @return
     */
    BaseResult isBondedStuNo();

    /**
     * 用户绑定准考证号
     * @param bindingStuNoVO
     * @return
     */
    BaseResult bindingStuNo(BindingStuNoVO bindingStuNoVO);
}
