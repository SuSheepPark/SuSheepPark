package com.ruida.assessment.assessmentquestionbank.dto;

import com.ruida.assessment.assessmentquestionbank.model.TSectionKnowledge;
import lombok.Data;

import java.util.List;

/**
 * @author wy
 * @description 批量操作请求类
 * @date 2020/6/12
 */
@Data
public class BatchOperationRequest {

    private List<Integer> ids;//批量操作时id集合
    private Integer buttonType;//按钮类型  0-禁用 1-启用 2-删除
    private Integer id;//单条操作时选中的id
    private List<TSectionKnowledge> dataList;
    private Integer schoolId;
    private Integer classId;
    private Integer periodId;
    private Integer gradeId;
    private Integer subjectId;

    private Integer productId;//商品id
    private Integer isPresentReport;//是否需要赠送报告 0-否 1-是
    private List<Integer> userIds;//用户id集合

    private Integer userId;//用户id
    private List<Integer> stuIds;//学员id集合
    private List<ProductAndReportDto> productList;//赠送商品列表

    private Integer type;//赠送类型   0-单个商品赠送给多个用户  1-单个用户赠送多个商品

}
