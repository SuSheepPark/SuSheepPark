package com.ruida.assessment.assessmentquestionbank.model;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;

import java.io.Serializable;

/**
 * @description:
 * @author: kgz
 * @date: 2020/7/6
 */
@TableName("t_test_type")
public class TTestType extends BaseColumn implements Serializable {
    private static final long serialVersionUID = -5745131440023466760L;
    /**
     * 考试类型id
     */
    @TableId
    private Integer id;

    /**
     * 考试类型名称
     */
    private String name;

    /**
     * 状态（0—禁用；1—启用）
     */
    private Integer status;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }
}
