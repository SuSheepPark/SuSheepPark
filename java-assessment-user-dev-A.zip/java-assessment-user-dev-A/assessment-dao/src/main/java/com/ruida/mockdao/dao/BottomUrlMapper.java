package com.ruida.mockdao.dao;


import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.model.BottomUrl;

/**
 * <p>
 * PC端底部网站链接表 Mapper 接口
 * </p>
 *
 * @author Bhj
 * @since 2020-08-07
 */
public interface BottomUrlMapper extends BaseMapper<BottomUrl> {

}
