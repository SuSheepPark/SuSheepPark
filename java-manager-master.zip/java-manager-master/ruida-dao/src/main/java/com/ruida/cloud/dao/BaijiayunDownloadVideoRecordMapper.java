package com.ruida.cloud.dao;


import com.ruida.cloud.model.BaijiayunDownloadVideoRecord;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @description:
 * @author: wy
 * @date: 2021/1/29
 */

public interface BaijiayunDownloadVideoRecordMapper{


    List<String> queryAllDownloadVideoRecordList();

    Integer insertDownloadVideoRecord(@Param("list") List<BaijiayunDownloadVideoRecord> baijiayunDownloadVideoRecords);
}
