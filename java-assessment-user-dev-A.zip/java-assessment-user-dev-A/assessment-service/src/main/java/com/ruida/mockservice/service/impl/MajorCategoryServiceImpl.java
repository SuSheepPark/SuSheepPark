package com.ruida.mockservice.service.impl;


import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.ruida.mockcommon.auth.context.BaseContextHandle;
import com.ruida.mockcommon.result.MapResult;
import com.ruida.mockcommon.result.PojoResult;
import com.ruida.mockdao.dao.MajorCategoryMapper;
import com.ruida.mockdao.model.MajorCategory;
import com.ruida.mockdao.vo.major.MajorGroupVO;
import com.ruida.mockservice.service.MajorCategoryService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * 大学专业类表（不是专业表） 服务实现类
 * </p>
 *
 * @author xumingqi
 * @since 2021-01-14
 */
@Service
public class MajorCategoryServiceImpl extends ServiceImpl<MajorCategoryMapper, MajorCategory> implements MajorCategoryService {
    @Resource
    MajorCategoryMapper majorCategoryMapper;


    @Override
    public List<MajorGroupVO> getAllMajorGroup() {
        return majorCategoryMapper.getAllMajorGroup();
    }

    @Override
    public PojoResult getAllMajorGroupByUser() {
        PojoResult result = new PojoResult();
        Map resultMap = new HashMap();
        result.setContent(resultMap);
        String userId =  BaseContextHandle.getJWTInfo().getUserId();
        List<MajorGroupVO> list = majorCategoryMapper.getAllMajorGroupByUser(Integer.valueOf(userId));
        Integer count = majorCategoryMapper.countAllMajorGroupByUser(Integer.valueOf(userId));
        resultMap.put("list",list);
        resultMap.put("count",count);
        return result;
    }
}
