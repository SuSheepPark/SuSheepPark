package com.ruida.cloud.weidu.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.ruida.cloud.dao.WeiduCourseLessonRelMapper;
import com.ruida.cloud.dao.WeiduTeachingPlanRelMapper;
import com.ruida.cloud.model.WeiduCourseLessonRel;
import com.ruida.cloud.model.WeiduCourseLessonRelExample;
import com.ruida.cloud.model.WeiduTeachingPlanRel;
import com.ruida.cloud.weidu.config.WeiduConfig;
import com.ruida.cloud.weidu.exception.VdyooException;
import com.ruida.cloud.weidu.service.BaseVdyooService;
import com.ruida.cloud.weidu.utils.PropertyUtil;
import com.ruida.cloud.weidu.utils.VdyooUtil;
import com.ruida.cloud.weidu.vo.VdyooEntity;
import com.ruida.common.context.BaseContextHandle;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 关联表：
 *          威渡课班ID              courseClassId
 *          课表（计划）威渡id       id
 * @author taosh
 * @create 2019-04-23 17:41
 */
@Service
public class VdyooCourseLessonService extends BaseVdyooService {
    private String vdyooPath = PropertyUtil.getProperty("vdyooTestApi");
    @Resource
    private WeiduTeachingPlanRelMapper weiduTeachingPlanRelMapper;
    @Resource
    private WeiduCourseLessonRelMapper weiduCourseLessonRelMapper;

    /**
     * 创建课程表
     * , propagation= Propagation.NESTED
     */
    @Transactional(rollbackFor = Exception.class,propagation=Propagation.NESTED)
    public String addSchedule(Map<String, Object> param){
        VdyooEntity vdyooEntity =  this.vdyooFactory.post(param, WeiduConfig.addSchedule);
        boolean flag = false;
        if(vdyooEntity.getSuccess()){
            String id = "";
            try {
                if ( param.get("courseClassId") != null ) {
                    String courseClassId = (String) param.get("courseClassId");
                    WeiduCourseLessonRelExample example = new WeiduCourseLessonRelExample();
                    WeiduCourseLessonRelExample.Criteria wc = example.createCriteria();

                    wc.andWeiduCourseLessonIdEqualTo(courseClassId);

                    List<WeiduCourseLessonRel> relList = weiduCourseLessonRelMapper.selectByExample(example);
                    if( relList != null && relList.size() > 0 ){
                        WeiduCourseLessonRel rel = relList.get(0);

                        WeiduTeachingPlanRel teachingPlanRel = new WeiduTeachingPlanRel();
                        teachingPlanRel.setCourseLessonId(rel.getCourseLessonId());

                        JSONObject object = (JSONObject) JSON.toJSON(vdyooEntity.getPayload());
                        teachingPlanRel.setWeiduTeachingPlanId(object.getString("id"));
                        id = object.getString("id");

                        teachingPlanRel.setCreateBy(BaseContextHandle.getUserId());
                        teachingPlanRel.setCreateTime(new Date());
                        teachingPlanRel.setIsdelete((byte) 0);
                        teachingPlanRel.setUpdateBy(BaseContextHandle.getUserId());
                        teachingPlanRel.setUpdateTime(new Date());
                        flag = weiduTeachingPlanRelMapper.insert(teachingPlanRel) > 0;

                        if (!flag) {
                            throw new VdyooException("500", "教学计划信息关联失败，请联系管理员或稍后再试");
                        } else {
                            return id;
                        }
                    }else{
                        throw new VdyooException("500", "威渡课程班关联失败，请联系管理员或稍后再试");
                    }
                }else{
                    throw new VdyooException("500", "威渡教学班关联失败，请联系管理员或稍后再试");
                }
            }catch (Exception e){
                throw new VdyooException("500", "威渡教学计划信息关联失败，请联系管理员或稍后再试");
            }
        }else{
            throw new VdyooException("500", vdyooEntity.getMessage());
        }
    }

    /**
     * 批量创建课程表
     */
    public void addSchedules(){
        String path = vdyooPath+"/api/business/schedule/addSchedules";

        Map<String, String> param = VdyooUtil.getSignMap();

        //todo
        // "schedules":[{"courseClassId":42,"startTime":"1520298000000","endTime":"1520301600000"}]

        String json = JSON.toJSONString(param);

//        String response = HttpClientUtil.postJson(path, json);
//        System.out.println(response);
    }

    /**
     * 删除教学计划
     */
    public boolean deleteSchedule(Map<String, Object> param){
        boolean flag = this.vdyooFactory.post(param, WeiduConfig.deleteSchedule).getSuccess();

        return flag;
    }

    /**
     * 批量删除教学计划
     */
    public boolean deleteSchedules(String ids){
        Map<String, Object> param = new HashMap<>(1);
        param.put("ids", ids);
        boolean flag = this.vdyooFactory.post(param, WeiduConfig.deleteSchedules).getSuccess();
        return flag;
    }

    /**
     * 编辑教学计划
     */
    public void editSchedule(){
        String path = vdyooPath+"/api/business/schedule/editSchedule";

        Map<String, String> param = VdyooUtil.getSignMap();

        //威渡id
        param.put("id", "123");
        //直播间id
        param.put("studioId", "123");
        //主讲老师id
        param.put("teacherId", "123");
        //计划开始时间
        param.put("startTime", "123");
        //计划结束时间
        param.put("endTime", "123");

//        String response = HttpClientUtil.postMap(path, param);
//        System.out.println(response);
    }

    /**
     * 根据id查询出单个计划信息
     */
    public void findScheduleById(String id){
        String path = vdyooPath+"/api/business/schedule/findScheduleById";

        Map<String, String> param = VdyooUtil.getSignMap();

        //威渡id
        param.put("id", "123");

//        String response = HttpClientUtil.postMap(path, param);
//        System.out.println(response);
    }

    /**
     * 查询公司下所有课程表
     */
    public boolean findScheduleByTenant(){
        Map<String, Object> param = new HashMap<>();
        VdyooEntity vdyooEntity =  this.vdyooFactory.post(param, WeiduConfig.findScheduleByTenant);

        System.out.println(vdyooEntity.getPayload());
        return vdyooEntity.getSuccess();

    }

    /**
     * 添加临时班
     */
    public void addClassSchedule(){
        String path = vdyooPath+"/api/business/schedule/addClassSchedule";

        Map<String, String> param = VdyooUtil.getSignMap();

        //课程表威渡id
        param.put("scheduleId", "");
        //教学班的id
        param.put("classId", "");
        //教室的Id
        param.put("roomId", "");
        //助教的Id
        param.put("teacherId", "");

//        String response = HttpClientUtil.postMap(path, param);
//        System.out.println(response);
    }

    /**
     * 删除参加这个课表的班级
     */
    public void deleteClassSchedule(String scheduleId, String classId){
        String path = vdyooPath+"/api/business/schedule/deleteClassSchedule";

        Map<String, String> param = VdyooUtil.getSignMap();

        //课程表威渡id
        param.put("scheduleId", scheduleId);
        //教学班的id
        param.put("classId", classId);

//        String response = HttpClientUtil.postMap(path, param);
//        System.out.println(response);
    }

    /**
     * 开始教学计划
     */
    public void beginTeaching(String scheduleId){
        String path = vdyooPath+"/api/business/schedule/beginTeaching";

        Map<String, String> param = VdyooUtil.getSignMap();

        //课程表的id
        param.put("scheduleId", scheduleId);

//        String response = HttpClientUtil.postMap(path, param);
//        System.out.println(response);
    }

    /**
     * 结束教学计划
     */
    public void endTeaching(String scheduleId){
        String path = vdyooPath+"/api/business/schedule/endTeaching";

        Map<String, String> param = VdyooUtil.getSignMap();

        //课程表的id
        param.put("scheduleId", scheduleId);

//        String response = HttpClientUtil.postMap(path, param);
//        System.out.println(response);
    }

    /**
     * 结束教学计划
     */
    public void editScheduleClasss(){
        String path = vdyooPath+"/api/business/schedule/editScheduleClasss";

        Map<String, String> param = VdyooUtil.getSignMap();

        //课程表的id
        param.put("scheduleId", "");
        //班级ID
        param.put("classId", "");
        //教室ID
        param.put("roomId", "");
        //老师ID
        param.put("teacherId", "");

//        String response = HttpClientUtil.postMap(path, param);
//        System.out.println(response);
    }
}
