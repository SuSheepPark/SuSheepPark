package com.ruida.mockservice.service.impl;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.ruida.mockcommon.auth.context.BaseContextHandle;
import com.ruida.mockcommon.enums.AnswerStatusEnum;
import com.ruida.mockcommon.enums.QuestionTypeEnum;
import com.ruida.mockcommon.exception.CoreException;
import com.ruida.mockcommon.result.Page;
import com.ruida.mockdao.dao.ErrorPracticeMapper;
import com.ruida.mockdao.dao.ErrorPracticeRecordMapper;
import com.ruida.mockdao.dao.QuestionLibraryMapper;
import com.ruida.mockdao.dto.ErrorPracticeSubmitDTO;
import com.ruida.mockdao.dto.QuestionDTO;
import com.ruida.mockdao.dto.RecordRequest;
import com.ruida.mockdao.model.ErrorPractice;
import com.ruida.mockdao.model.ErrorPracticeDetail;
import com.ruida.mockdao.model.ErrorPracticeRecord;
import com.ruida.mockdao.model.QuestionLibrary;
import com.ruida.mockdao.pojo.Choice;
import com.ruida.mockdao.vo.error.PracticeRecordVO;
import com.ruida.mockservice.service.ErrorPracticeDetailService;
import com.ruida.mockservice.service.ErrorPracticeRecordService;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.*;

/**
 * <p>
 * 错题练习记录表 服务实现类
 * </p>
 *
 * @author chenjy
 * @since 2020-10-19
 */
@Service
public class ErrorPracticeRecordServiceImpl extends ServiceImpl<ErrorPracticeRecordMapper, ErrorPracticeRecord> implements ErrorPracticeRecordService {

    private static final String REG_EX = "</?[^>]+>";

    @Resource
    private QuestionLibraryMapper questionLibraryMapper;
    @Resource
    private ErrorPracticeRecordMapper errorPracticeRecordMapper;
    @Resource
    private ErrorPracticeDetailService errorPracticeDetailService;
    @Resource
    private ErrorPracticeMapper errorPracticeMapper;

    @Transactional(rollbackFor = Exception.class)
    @Override
    public Integer submit(ErrorPracticeSubmitDTO req) {
        Integer userId = Integer.valueOf(BaseContextHandle.getUserID());

        ErrorPractice ep = errorPracticeMapper.selectById(req.getPracticeId());
        if(ep == null){
            throw new CoreException("500","错题练习id有误");
        }
        ErrorPracticeRecord record = new ErrorPracticeRecord();
        record.setUserId(userId);
        record.setPracticeId(req.getPracticeId());
        record.setPeriodId(ep.getPeriodId());
        record.setSubjectId(ep.getSubjectId());
        record.setDuration(req.getDuration());
        record.setRate(calcFinishedRate(req));
        record.setCreateTime(new Date());
        errorPracticeRecordMapper.insert(record);

        List<ErrorPracticeDetail> list = new ArrayList<>();
        req.getQuestionList().forEach(q -> saveErrorPracticeDetail(q, record, null, list));
        errorPracticeDetailService.insertBatch(correct(list));

        return record.getId();
    }

    private String calcFinishedRate(ErrorPracticeSubmitDTO req) {
        //试题总量
        long total = req.getQuestionList().size();

        int undo = 0;
        for (QuestionDTO dto : req.getQuestionList()) {
            if (dto.getChild().size() == 0) {
                if (StringUtils.isEmpty(dto.getImageId()) && dto.getUserAnswer().size() == 0) {
                    undo++;
                }
            } else {
                List<QuestionDTO> child = dto.getChild();
                if (child.stream().allMatch(x -> StringUtils.isEmpty(x.getImageId()) && x.getUserAnswer().size() == 0))
                    undo++;
            }
        }

        return (total - undo) + "/" + total;
    }

    private void saveErrorPracticeDetail(QuestionDTO questionDTO, ErrorPracticeRecord record, String pid, List<ErrorPracticeDetail> list) {
        QuestionLibrary question = questionLibraryMapper.selectById(questionDTO.getQuestionId());

        ErrorPracticeDetail detail = new ErrorPracticeDetail();
        detail.setRecordId(record.getId());
        detail.setQuestionId(questionDTO.getQuestionId());
        detail.setPid(pid);
        detail.setQuestionTypeId(question.getQuestionTypeId());
        detail.setSubjectId(question.getSubjectId());
        detail.setImageId(questionDTO.getImageId());
        detail.setAnswer(questionDTO.getUserAnswer().size() != 0 ? JSON.toJSONString(questionDTO.getUserAnswer()) : null);
        detail.setAudioPlayCount(questionDTO.getAudioPlayCount());
        detail.setCreateBy(record.getUserId());
        detail.setCreateTime(new Date());
        list.add(detail);

        if (!CollectionUtils.isEmpty(questionDTO.getChild())) {
            questionDTO.getChild().forEach(c -> saveErrorPracticeDetail(c, record, questionDTO.getQuestionId(), list));
        }
    }

    public List<ErrorPracticeDetail> correct(List<ErrorPracticeDetail> list) {

        // 先处理非组合题
        list.stream().filter(x -> !x.getQuestionTypeId().equals(QuestionTypeEnum.CQT.getK())).forEach(e -> {
            QuestionLibrary question = questionLibraryMapper.selectById(e.getQuestionId());

            if (StringUtils.isNotEmpty(e.getImageId())) {
                e.setStatus(AnswerStatusEnum.UC.getK());
            } else {
                // 参考答案
                List<Choice> answer = JSON.parseArray(question.getAnswer(), Choice.class);

                // 用户给出的答案
                List<Choice> userAnswer = JSON.parseArray(e.getAnswer(), Choice.class);

                // 没有作答的题目状态直接置为错误
                if (CollectionUtils.isEmpty(userAnswer)) {
                    e.setStatus(AnswerStatusEnum.WRONG.getK());
                } else {
                    // 自动批阅只针对客观题
                    if (question.getCorrectType() == 1 && !question.getQuestionTypeId().equals(QuestionTypeEnum.CQT.getK())) {
                        if (answer.size() == 1) {
                            if (userAnswer.size() != 0 && answer.get(0).getKey().equals(userAnswer.get(0).getKey())) {
                                if (answer.get(0).getVal().replaceAll(REG_EX, "").trim().equals(userAnswer.get(0).getVal().trim())) {
                                    userAnswer.get(0).setStatus(AnswerStatusEnum.RIGHT.getK());
                                    e.setStatus(AnswerStatusEnum.RIGHT.getK());
                                } else {
                                    userAnswer.get(0).setStatus(AnswerStatusEnum.WRONG.getK());
                                    e.setStatus(AnswerStatusEnum.WRONG.getK());
                                }
                            }
                        } else {
                            int count = 0; // 记录答对题的数量
                            for (int i = 0; i < userAnswer.size(); i++) {
                                if (answer.get(i).getKey().equals(userAnswer.get(i).getKey())) {
                                    if (answer.get(i).getVal().replaceAll(REG_EX, "").trim().equals(userAnswer.get(i).getVal().trim())) {
                                        userAnswer.get(i).setStatus(AnswerStatusEnum.RIGHT.getK());
                                        count++;
                                    } else {
                                        userAnswer.get(i).setStatus(AnswerStatusEnum.WRONG.getK());
                                    }
                                }
                            }
                            if (count == answer.size()) {
                                // 本道题所有的空都答对
                                e.setStatus(AnswerStatusEnum.RIGHT.getK());

                            } else if (count == 0) {
                                // 本道题所有的空都答错
                                e.setStatus(AnswerStatusEnum.WRONG.getK());
                            } else {
                                // 部分对、部分错
                                e.setStatus(AnswerStatusEnum.HRHW.getK());
                            }
                        }
                        e.setAnswer(userAnswer.size() == 0 ? null : JSON.toJSONString(userAnswer));
                    } else {
                        // 主观题的试题状态置为未批
                        e.setStatus(AnswerStatusEnum.UC.getK());
                    }
                }
            }
        });

        // 处理组合题
        list.stream().filter(x -> x.getQuestionTypeId().equals(QuestionTypeEnum.CQT.getK())).forEach(x -> x.setStatus(handleComposeQuestion(x, list)));

        return list;
    }

    private Integer handleComposeQuestion(ErrorPracticeDetail detail, List<ErrorPracticeDetail> list) {

        //该组合题下的子题
        List<ErrorPracticeDetail> detailsList = new ArrayList<>();
        list.forEach(x -> {
            if (detail.getQuestionId().equals(x.getPid())) {
                detailsList.add(x);
            }
        });

        int status;
        if (detailsList.stream().allMatch(x -> x.getStatus() == AnswerStatusEnum.RIGHT.getK())) {
            // 子题全对，父题才对
            status = AnswerStatusEnum.RIGHT.getK();
        } else if (detailsList.stream().anyMatch(x -> x.getStatus() == AnswerStatusEnum.UC.getK())) {
            // 子题存在一个未批的，父题的状态就是未批
            status = AnswerStatusEnum.UC.getK();
        } else if (detailsList.stream().allMatch(x -> x.getStatus() == AnswerStatusEnum.WRONG.getK())) {
            // 子题全错，父题才错
            status = AnswerStatusEnum.WRONG.getK();
        } else {
            // 其他情况，父题是半对半错
            status = AnswerStatusEnum.HRHW.getK();
        }

        return status;
    }

    @Override
    public Page<PracticeRecordVO> queryPracticeRecord(Page page, RecordRequest req) {
        Map<String,Object> map = new HashMap<>();
        String userId = BaseContextHandle.getUserID();
        map.put("userId",userId);
        map.put("pageStart",page.getOffset());
        map.put("pageSize",page.getPageSize());
        map.put("subjectId",req.getSubjectId());
        map.put("keyword",req.getKeyword());

        Integer periodId = errorPracticeRecordMapper.queryPeriodId(req.getStageId());
        map.put("periodId",periodId);

        List<PracticeRecordVO> list = errorPracticeRecordMapper.queryPracticeRecord(map);

        if(!CollectionUtils.isEmpty(list)){
            list.forEach(r ->{
                int index = r.getRate().lastIndexOf("/");
                String rate = r.getRate();
                r.setFinished(Integer.valueOf(rate.substring(0,index)));
                r.setTotal(Integer.valueOf(rate.substring(index+1)));
            });
        }

        Integer count = errorPracticeRecordMapper.queryRecordCount(map);

        page.setResult(list);
        page.setNowTime(new Date());
        page.setTotalCount(count);
        return page;
    }
}
