package com.ruida.cloud.dao;

import com.ruida.cloud.model.Period;
import com.ruida.cloud.model.PeriodExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface PeriodMapper {
    int countByExample(PeriodExample example);

    int deleteByExample(PeriodExample example);

    int deleteByPrimaryKey(Integer periodId);

    int insert(Period record);

    int insertSelective(Period record);

    List<Period> selectByExample(PeriodExample example);

    Period selectByPrimaryKey(Integer periodId);

    int updateByExampleSelective(@Param("record") Period record, @Param("example") PeriodExample example);

    int updateByExample(@Param("record") Period record, @Param("example") PeriodExample example);

    int updateByPrimaryKeySelective(Period record);

    int updateByPrimaryKey(Period record);

    /************/
    List<Map<String, Object>> listPeriodInfoByClassTypeId(int classTypeId);
}