package com.ruida.mockdao.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ruida.mockdao.model.ErrorPractice;

/**
 * <p>
 * 错题练习表 Mapper 接口
 * </p>
 *ErrorPracticeMapper.xml
 * @author chenjy
 * @since 2020-10-16
 */
public interface ErrorPracticeMapper extends BaseMapper<ErrorPractice> {

}
