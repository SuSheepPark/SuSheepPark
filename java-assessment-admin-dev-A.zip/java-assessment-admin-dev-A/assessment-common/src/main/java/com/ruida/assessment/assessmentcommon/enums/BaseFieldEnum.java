package com.ruida.assessment.assessmentcommon.enums;

import com.ruida.assessment.assessmentcommon.exception.CoreException;

public enum BaseFieldEnum {

    /**
     * 学段
     */
    PERIOD(0),
    /**
     * 年级
     */
    GRADE(1),
    /**
     * 科目
     */
    SUBJECT(2),
    /**
     * 教材版本
     */
    VERSION(3),
    /**
     * 难度
     */
    QUESTION_DIFFICULTY(4),
    /**
     * （试题）保密等级
     */
    QUESTION_SECURITY_LEVEL(5),
    /**
     * （试题）题型
     */
    QUESTION_TYPE(6),
    /**
     * （试题）考察要求
     */
    QUESTION_ASSESSMENT_TARFET(7),
    /**
     * （试题）试题来源
     */
    QUESTION_SOURCE(8),
    /**
     * （试题）试题用途
     */
    QUESTION_PURPOSE(9),
    /**
     * （试卷）考试类型
     */
    TEST_TYPE(10),
    /**
     * （试卷）试卷类型
     */
    TEST_PAPER_TYPE(11);

    private final int code;


    public static BaseFieldEnum forInt(int code) throws Exception {
        for (BaseFieldEnum type : values()) {
            if (type.code == code) {
                return type;
            }
        }
        throw new CoreException(AppErrorEnum.E_10005);
    }

    BaseFieldEnum(int code) {
        this.code = code;
    }

    public int getCode() {
        return code;
    }

}
