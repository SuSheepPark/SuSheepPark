package com.ruida.assessment.assessmentquestionbank.annotaion;

import com.ruida.assessment.assessmentcommon.enums.QuestionEnum;
import com.ruida.assessment.assessmentcommon.enums.UserAuthCEnum;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 用户认证注解
 */
@Target({ElementType.METHOD,ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
public @interface UserAuth {
    String name() default "";

    UserAuthCEnum type() default UserAuthCEnum.PASS;
}
