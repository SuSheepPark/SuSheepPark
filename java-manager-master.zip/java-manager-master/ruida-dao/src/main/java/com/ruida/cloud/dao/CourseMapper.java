package com.ruida.cloud.dao;

import com.ruida.cloud.model.Course;
import com.ruida.cloud.model.CourseExample;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

public interface CourseMapper {
    long countByExample(CourseExample example);

    int deleteByExample(CourseExample example);

    int deleteByPrimaryKey(Integer courseId);

    int insert(Course record);

    int insertSelective(Course record);

    List<Course> selectByExampleWithBLOBs(CourseExample example);

    List<Course> selectByExample(CourseExample example);

    Course selectByPrimaryKey(Integer courseId);

    int updateByExampleSelective(@Param("record") Course record, @Param("example") CourseExample example);

    int updateByExampleWithBLOBs(@Param("record") Course record, @Param("example") CourseExample example);

    int updateByExample(@Param("record") Course record, @Param("example") CourseExample example);

    int updateByPrimaryKeySelective(Course record);

    int updateByPrimaryKeyWithBLOBs(Course record);

    int updateByPrimaryKey(Course record);

    @Select("SELECT\n" +
            "\tcourse_id AS courseId,\n" +
            "\tcourse_name AS courseName,\n" +
            "\tstart_date as startDate,\n" +
            "\tend_date as endDate,\n" +
            "\tstart_time AS startTime,\n" +
            "\tend_time AS endTime\n" +
            "FROM\n" +
            "\tt_course\n" +
            "WHERE\n" +
            "\tcourse_id = #{courseId}")
    Map<String ,Object> getCourseInfoById(@Param("courseId") Integer courseId);

    @Select("select group_concat(head_teacher_id) from t_course_head_teacher_rel where course_id=#{courseId} group by course_id")
    String getClassTeacherIdsByCourseId(@Param("courseId") Integer courseId);
}
