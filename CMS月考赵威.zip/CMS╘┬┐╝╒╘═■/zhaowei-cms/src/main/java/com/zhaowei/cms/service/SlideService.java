/**   
 * Copyright © 2019 公司名. All rights reserved.
 * 
 * @Title: SlideService.java 
 * @Prject: zhaowei-cms
 * @Package: com.zhaowei.cms.service 
 * @Description: TODO
 * @author: zw   
 * @date: 2019年9月21日 上午11:20:43 
 * @version: V1.0   
 */
package com.zhaowei.cms.service;

import java.util.List;

import com.zhaowei.cms.domain.Slide;

/** 
 * @ClassName: SlideService 
 * @Description: TODO
 * @author: zw
 * @date: 2019年9月21日 上午11:20:43  
 */
public interface SlideService {

	List<Slide> selects();
	
}
