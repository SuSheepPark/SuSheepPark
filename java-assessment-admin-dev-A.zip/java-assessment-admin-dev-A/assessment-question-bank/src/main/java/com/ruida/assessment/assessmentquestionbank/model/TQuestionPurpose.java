package com.ruida.assessment.assessmentquestionbank.model;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;

/**
 * @description: 试题用途数据库实体
 * @author: kgz
 * @date: 2020/6/10
 */
@TableName("t_question_purpose")
public class TQuestionPurpose extends BaseColumn implements Serializable {
    private static final long serialVersionUID = -4520567039371182766L;

    /**
     * 试题用途id
     */
    @TableId
    private Integer id;

    /**
     * 试题用途名称
     */
    private String questionPurposeName;

    /**
     * 状态（0—禁用；1—启用）
     */
    private String status;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getQuestionPurposeName() {
        return questionPurposeName;
    }

    public void setQuestionPurposeName(String questionPurposeName) {
        this.questionPurposeName = questionPurposeName;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "TQuestionPurpose{" +
                "id=" + id +
                ", questionPurposeName='" + questionPurposeName + '\'' +
                ", status='" + status + '\'' +
                super.toString() +
                '}';
    }
}
