package com.ruida.cloud.dao;

import com.ruida.cloud.model.WeiduCourseRel;
import com.ruida.cloud.model.WeiduCourseRelExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface WeiduCourseRelMapper {
    long countByExample(WeiduCourseRelExample example);

    int deleteByExample(WeiduCourseRelExample example);

    int deleteByPrimaryKey(Integer rid);

    int insert(WeiduCourseRel record);

    int insertSelective(WeiduCourseRel record);

    List<WeiduCourseRel> selectByExample(WeiduCourseRelExample example);

    WeiduCourseRel selectByPrimaryKey(Integer rid);

    int updateByExampleSelective(@Param("record") WeiduCourseRel record, @Param("example") WeiduCourseRelExample example);

    int updateByExample(@Param("record") WeiduCourseRel record, @Param("example") WeiduCourseRelExample example);

    int updateByPrimaryKeySelective(WeiduCourseRel record);

    int updateByPrimaryKey(WeiduCourseRel record);
}