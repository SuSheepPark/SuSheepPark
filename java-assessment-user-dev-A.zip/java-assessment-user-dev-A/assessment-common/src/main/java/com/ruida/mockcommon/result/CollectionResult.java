package com.ruida.mockcommon.result;

import java.util.Collection;

/**
 * @description:
 * @author szl
 * @Date 2018年12月10日
 * @verion 1.0
 */
public class CollectionResult<T> extends BaseResult {
	
	private static final long serialVersionUID = 5609093394695319351L;

	private Collection<T> content;

	private Integer totalCount;

	public CollectionResult() {

	}

	public CollectionResult(Collection<T> content) {
		setContent(content);
		if (content != null) {
			setTotalCount(content.size());
		}
	}

	public Integer getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(Integer totalCount) {
		this.totalCount = totalCount;
	}

	public Collection<T> getContent() {
		return content;
	}

	public void setContent(Collection<T> content) {
		this.content = content;
	}

}
