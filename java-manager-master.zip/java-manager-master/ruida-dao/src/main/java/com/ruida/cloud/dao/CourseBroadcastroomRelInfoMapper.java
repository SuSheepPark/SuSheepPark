package com.ruida.cloud.dao;

import com.ruida.cloud.daoTmp.CourseBroadcastroomRelInfo;

import java.util.List;
import java.util.Map;

public interface CourseBroadcastroomRelInfoMapper {
    List<CourseBroadcastroomRelInfo> listCourseBroadcastRoomByCourseId(Integer courseId);

    List<Map<String ,Object>> getLimitOnlineNum(Map<String, Object> param);

    List<Map<String ,Object>> listCourseOrderNum(Map<String, Object> param);

    List<Map<String ,Object>> listCampusOrderNum(Map<String, Object> param);

    List<CourseBroadcastroomRelInfo> listBroadcastRoomRelInfoByInfo(Map<String, Object> param);

    List<CourseBroadcastroomRelInfo> listCampusInfoByInfo(Map<String, Object> param);

    List<Map<String, Object>> getLimitOnlineNumByCampusId(Map<String, Object> param);

    List<CourseBroadcastroomRelInfo> listBroadcastRoomRelInfoByCampusId(Map<String, Object> param);

    List<CourseBroadcastroomRelInfo> listBroadcastRoomRelInfoByInfoByCampusId(Map<String, Object> param);
}